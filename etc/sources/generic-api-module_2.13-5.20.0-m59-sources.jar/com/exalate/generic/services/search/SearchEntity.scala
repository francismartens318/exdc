package com.exalate.generic.services.search

case class SearchEntity(
    id: String,
    urn: String,
    title: Option[String] = None,
    issueType: Option[String] = None
)
