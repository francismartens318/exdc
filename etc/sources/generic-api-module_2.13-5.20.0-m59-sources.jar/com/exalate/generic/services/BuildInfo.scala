package com.exalate.generic.services

case class BuildInfo(version: String, name: String, buildTime: Long, exaCompVersion: String)
