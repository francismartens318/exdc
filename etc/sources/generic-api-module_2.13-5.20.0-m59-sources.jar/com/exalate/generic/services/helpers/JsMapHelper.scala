package com.exalate.generic.services.helpers

import play.api.libs.json.{JsBoolean, JsNumber, JsObject, JsString, JsValue}

import scala.collection.JavaConverters

/** This Object helps to transform values of GenericEntity: Map[String, JsValue] into Map[String,
  * Object]
  */
object JsMapHelper {
  val MAX_DEPTH_EVALUATION_LEVEL = 3

  def resolveJsMap(
      m: scala.collection.Map[String, JsValue],
      currentDepth: Int = 0
  ): scala.collection.Map[String, Object] = {
    if (currentDepth == MAX_DEPTH_EVALUATION_LEVEL) {
      // To avoid an infinite execution, we limit the depth evaluation of the map to 3 levels
      return m
    }
    m.flatMap {
      case (k, v: JsString)  => Some(k -> v.value)
      case (k, v: JsBoolean) => Some(k -> new java.lang.Boolean(v.value))
      case (k, v: JsNumber)  => Some(k -> v.value)
      case (k, v: JsObject)  =>
        Some(k -> JavaConverters.mapAsJavaMap(resolveJsMap(v.value, currentDepth + 1)))
      //                case (k, v: JsNumber) => Some(k -> new java.lang.Double(v.value.bigDecimal))
      case _                 => None
    }
  }

}
