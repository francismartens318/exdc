package com.exalate.generic.services

trait EntityContext {}
