package com.exalate.generic.services.health

import akka.Done
import akka.actor.{ActorSystem, Props}
import akka.pattern.ask
import akka.util.Timeout
import com.exalate.generic.services.health.HealthCheckActor.HealthCheck
import play.api.cache.AsyncCacheApi
import play.api.inject.ApplicationLifecycle
import play.api.{Configuration, Logger}

import javax.inject.{Inject, Singleton}
import scala.concurrent.duration.DurationInt
import scala.concurrent.{ExecutionContextExecutor, Future}

@Singleton
class HeathCheckService @Inject() (
    config: Configuration,
    system: ActorSystem,
    cache: AsyncCacheApi,
    lifecycle: ApplicationLifecycle,
    trackerHealthService: ITrackerHealthService
) {

  private val HEALTH_CHECK_ENABLED =
    config.getOptional[Boolean]("com.exalate.feature.new-healthcheck").getOrElse(false)

  implicit private val ec: ExecutionContextExecutor = system.dispatcher
  private val LOG = Logger(classOf[HeathCheckService])
  private val HEALTH_KEY = "healthy"
  private val healthCheckActor = system.actorOf(Props[HealthCheckActor])

  def healthCheck: Future[Boolean] = cache.get[Boolean](HEALTH_KEY).map(_.getOrElse(false))

  if (HEALTH_CHECK_ENABLED) {
    // The cache is going to be refreshed every 30 seconds
    val scheduleAction =
      system.scheduler.scheduleAtFixedRate(initialDelay = 0.seconds, interval = 30.seconds)(
        healthCheckRunner
      )
    lifecycle.addStopHook(() => Future.successful(scheduleAction.cancel()))
  }

  private[health] lazy val healthCheckRunner: Runnable = () => {
    val check = for {
      _ <- trackerHealthService.healthCheck()
      _ <- createAndCheckHealthActor
      actorSystemHealthy = checkActorSystem()
      _ <- cache.set(HEALTH_KEY, actorSystemHealthy, expiration = 60.seconds)
    } yield ()

    check.recoverWith {
      case e =>
        LOG.error("Failed to check node Health", e)
        cache.remove(HEALTH_KEY)
    }
  }

  private[health] def createAndCheckHealthActor: Future[Done] = {
    implicit val timeout: Timeout = Timeout(5.seconds)
    (healthCheckActor ? HealthCheck).mapTo[Done]
  }

  private def checkActorSystem(): Boolean =
    !system.whenTerminated.isCompleted

}
