package com.exalate.generic.services.health

import akka.Done
import akka.actor.Actor
import com.exalate.generic.services.health.HealthCheckActor.HealthCheck

class HealthCheckActor extends Actor {

  override def receive: Receive = {
    case HealthCheck =>
      // Perform checks here and respond with the status
      sender() ! Done
  }

}

object HealthCheckActor {
  case object HealthCheck
}
