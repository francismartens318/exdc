package com.exalate.generic.services.health

import akka.Done

import scala.concurrent.Future

trait ITrackerHealthService {
  def healthCheck(): Future[Done]
}
