package com.exalate.generic.services

import com.exalate.api.domain.auditlog.IAuditLog

sealed trait AuditInfo {
  def value: IAuditLog
}

/** We use these case classes for creating comments or worklogs
  */
case class FullAuditInfo(value: IAuditLog) extends AuditInfo
case class PartialAuditInfo(value: IAuditLog) extends AuditInfo
