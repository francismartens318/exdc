package com.exalate.generic.services.oauth

import com.exalate.domain.{GeneralSettings, InferredGeneralSettings}

import scala.concurrent.Future

trait INodeOAuthHelper {

  /** Check if gs already contain required data to start oauth flow, where oauth is supported.
    * @return
    */
  def hasOauthContext: Future[Boolean] = Future.successful(false)

  /** Checks if oauth flow should be restarted after updating general settings. It is useful when
    * fields that affect tokens are changed such as client id, client secret, etc
    * @return
    */
  def shouldRemoveOauthTokens(oldGs: InferredGeneralSettings, newGs: GeneralSettings): Boolean =
    false

}
