package com.exalate.generic.services.api

import com.exalate.domain.values.v4.GeneralSettingsJson

import scala.concurrent.Future

/** This trait used to check if all general settings info are already stored in DB and get UI
  * related info about GS. In some cases we need to provide more info (PAT/proxy user/token..) -
  * then this trait needs to be implemented inside node, checking those extra values.
  */
trait ITrackerGeneralSettingsService {

  def isGeneralSettingsConfigured: Future[Boolean]

  /** This method returns Future of Option of GS fields without values, as it's used in non
    * authenticated call. This helps to know what extra fields should be rendered on UI for General
    * Settings screens.
    *
    * { exalateUrl: { "type": "TEXT", "required": true, "decrypt":false, "editable":true,
    * "label":"Exalate Url" }, issueTrackerUrl: { "type": "TEXT", "required": true, "decrypt":false,
    * "editable":true, "label":"Azure DevOps URL" }, "fieldValues": { "username": { "type": "TEXT",
    * "required": true, "decrypt":false, "editable":true, "label":"username" }, "password": {
    * "type": "TEXT", "required": true, "decrypt":true, "editable":true, "label":"password" } } }
    */
  def getUIGeneralSettingsFields: Future[Option[GeneralSettingsJson]]

  /** All values that are stored encrypted, should be returned decrypted. This is to avoid the get
    * -> update problem on the general settings update page { exalateUrl: { "value":
    * "http://localhost:9002"", "type": "TEXT", "required": true, "decrypt":false, "editable":true,
    * "label":"Exalate Url" }, ... }
    */
  def getUIGeneralSettingsWithFieldValues: Future[Option[GeneralSettingsJson]]
}
