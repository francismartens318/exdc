package com.exalate.generic.services.api

import play.api.mvc.RequestHeader

trait IJwtTrackerService {

  /** Get jwt from request & validation with provided user rights
    *
    * @param userAccessRights
    *   : USER or ADMIN
    * @return
    *   Option[true] or None
    */
  def validateTrackerJwt(request: RequestHeader, userAccessRights: String): Boolean

  def shouldValidateTrackerJwt(): Boolean

}
