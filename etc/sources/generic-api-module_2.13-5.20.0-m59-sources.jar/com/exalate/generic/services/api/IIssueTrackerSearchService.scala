package com.exalate.generic.services.api

import com.exalate.api.domain.IIssueKey
import com.exalate.api.domain.connection.IConnection
import com.exalate.basic.domain.hubobject.v1.UpdateBasicHubIssue
import com.exalate.generic.services.EntityContext
import com.exalate.generic.services.search.SearchEntity

import java.util.Date
import scala.concurrent.Future

/** Implementation is required from each node for triggers.
  */
trait IIssueTrackerSearchService {

  // TODO: check why query is not Option
  def isIssueInSearchResults[T <: EntityContext](
      issueKey: IIssueKey,
      query: String,
      connection: IConnection,
      fieldValues: Map[String, Object],
      entityContext: Option[T],
      updateHubIssueOption: Option[UpdateBasicHubIssue] = None
  ): Future[Boolean]

  def isSearchQueryValid(
      query: Option[String],
      connection: IConnection,
      entityType: String,
      fieldValues: Map[String, Object]
  ): Future[Seq[String]]

  /** When polling is it necessary for nodes to form query using creation time
    * @param query
    *   user input query if any
    * @param connection
    * @param entityType
    * @param fieldValues
    * @param lastPairPollingDateOrCreation
    *   timestamp of last polling action
    * @return
    */
  def getEntityKeysUnderSearchQuery(
      query: Option[String],
      connection: IConnection,
      entityType: String,
      fieldValues: Map[String, Object],
      lastPairPollingDateOrCreation: Option[Date] = None
  ): Future[Seq[IIssueKey]]

  def getEntityCountUnderSearchQuery(
      query: Option[String],
      connection: IConnection,
      entityType: String,
      fieldValues: Map[String, Object]
  ): Future[Long]

  def searchEntities(
      connection: IConnection,
      entityType: String,
      search: String,
      triggerQuery: Option[String],
      limit: Int
  ): Future[Seq[SearchEntity]]

}
