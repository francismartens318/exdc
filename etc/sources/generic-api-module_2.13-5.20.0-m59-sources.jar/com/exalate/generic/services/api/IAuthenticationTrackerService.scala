package com.exalate.generic.services.api

import com.exalate.domain.GeneralSettings
import com.exalate.domain.values.AuthenticationFailureValue

import scala.concurrent.Future

/** Each node should implement this interface to check if user is valid and admin on tracker.
  */
trait IAuthenticationTrackerService {

  def checkIfAdmin(user: String, password: String): Future[Option[AuthenticationFailureValue]]

  def checkIfAdmin(token: String): Future[Option[AuthenticationFailureValue]]

  def checkIfValidUser(user: String, password: String): Future[Option[AuthenticationFailureValue]]

  def checkIfValidUser(token: String): Future[Option[AuthenticationFailureValue]]

  def validateGs(gs: GeneralSettings): Future[Option[AuthenticationFailureValue]]
}
