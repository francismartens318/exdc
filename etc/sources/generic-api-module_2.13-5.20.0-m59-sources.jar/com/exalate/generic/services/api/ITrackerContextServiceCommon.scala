package com.exalate.generic.services.api

import com.exalate.api.domain.{IBlobMetadata, IIssueKey}
import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.hubobject.IHubIssueReplica
import com.exalate.api.domain.twintrace.INonPersistentTrace

import java.util

trait ITrackerContextServiceCommon {

  def getDataFilterContextCommon(
      connection: IConnection,
      localIssueKey: IIssueKey,
      entity: IHubIssueReplica,
      replica: IHubIssueReplica
  ): util.HashMap[String, Object]

  def getCreateProcessorContextCommon(
      connection: IConnection,
      entities: Seq[IHubIssueReplica],
      replica: IHubIssueReplica,
      traces: util.ArrayList[INonPersistentTrace],
      blobMetadataSeq: Seq[IBlobMetadata],
      issueBeforeUpdating: Seq[IHubIssueReplica]
  ): util.HashMap[String, Object]

  def getChangeProcessorContextCommon(
      relation: IConnection,
      localIssueKey: IIssueKey,
      issue: IHubIssueReplica,
      previous: IHubIssueReplica,
      replica: IHubIssueReplica,
      traces: util.ArrayList[INonPersistentTrace],
      blobMetadataSeq: Seq[IBlobMetadata],
      issueBeforeUpdating: IHubIssueReplica
  ): util.HashMap[String, Object]

}
