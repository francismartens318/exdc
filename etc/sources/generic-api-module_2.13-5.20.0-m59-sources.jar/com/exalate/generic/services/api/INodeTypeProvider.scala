package com.exalate.generic.services.api

/** It's preferable, that new nodes implement this interface on their own implementation, since: a)
  * in some nodes (JIRANODE) one can't inject NodeType, b) one doesn't have to change NodeType enum
  * in EXACOMP in order to implement a new connector
  */
trait INodeTypeProvider {
  def getNodeType: String
}
