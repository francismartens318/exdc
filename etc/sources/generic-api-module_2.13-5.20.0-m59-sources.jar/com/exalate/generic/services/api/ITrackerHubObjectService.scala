package com.exalate.generic.services.api

import akka.stream.scaladsl.Source
import akka.util.ByteString
import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.hubobject.{EntityType, IHubIssueReplica, IHubPayload}
import com.exalate.api.domain.request.ISyncRequest
import com.exalate.api.domain.twintrace.{INonPersistentTrace, ITrace, TraceType}
import com.exalate.api.domain.{IBlobMetadata, IIssueKey}
import com.exalate.basic.domain.hubobject.v1.UpdateBasicHubIssue
import play.api.libs.json.JsValue

import java.util
import scala.concurrent.{ExecutionContext, Future}

/** Each node should implement this trait. Use TrackerClient to communicate with tracker, and
  * convert data to expected result.
  */
trait ITrackerHubObjectService {

  /** Find the local issue key given the issue URN and the connection
    *
    * @return
    *   None if issue with such urn and connection does not exist
    */
  def getLocalKey(
      localIssueUrn: String,
      connection: IConnection,
      entityType: String,
      fieldValues: Map[String, String]
  ): Future[Option[IIssueKey]]

  /** Find the local issue key given the issue ID (globally unique for the entity) and the
    * connection
    *
    * @return
    *   None if issue with such id and connection does not exist
    */
  def getLocalKeyById(
      issueId: String,
      connection: IConnection,
      entityType: String
  ): Future[Option[IIssueKey]]

  /** Find the local issue key given a issue URN and the connection field values.
    *
    * @param fieldValues
    *   are specific to the issue tracker type which the exalate node is supporting Note: Usually
    *   implementation is similar to the getLocalKey(String, IConnection) implementation
    */
  def getLocalKeyForFieldValues(
      localIssueUrn: String,
      fieldValues: Map[String, String],
      entityType: String
  ): Future[Option[IIssueKey]]

  def getEntityJsValue(localEntityUrn: String, entityType: String): Future[Option[JsValue]]

  /** Returns an array of initialized entities supported by the tracker. This entities are provided
    * to the incoming script for the first sync
    */
  def getHubEntitiesTemplate(connection: IConnection): Future[Seq[IHubIssueReplica]]

  /*
   Use by the UI to know which entities should be rendered in menus that need them
   */
  def getSupportedEntityTypes(entityNameOpt: Option[String] = None): Future[Seq[EntityType]]

  /** Important! Uses persistence to get non-unique issue id via unique id
    *
    * @return
    *   a future of sequence of pairs of hub issue to it's unique id
    * @param issueKey
    * @param connection
    * @param issue
    *   an optional value which could be obtained from webhook. in that case when we have it, we do
    *   not make a request to instance
    * @return
    */
  def getHubPayloadFromTracker(
      issueKey: IIssueKey,
      connection: IConnection,
      issue: Option[UpdateBasicHubIssue] = None
  ): Future[Option[IHubPayload]]

  /** We need to return 2 payloads for ChangeIssueProcessor to have: issueBeforeUpdatingPayload and
    * hubPayload Always return 2 payloads that are the same Note: The reason we don't just use
    * getHubPayloadFromTracker twice is that most of the time you can generate 2 payloads in a more
    * efficient way (ex: perform only the rest calls once and build 2 entities from there)
    *
    * @return
    */
  def get2HubPayloadsFromTracker(
      issueKey: IIssueKey,
      connection: IConnection
  ): Future[Option[(IHubPayload, IHubPayload)]]

  /** @param issueBeforeUpdating
    *   issue generated from @getHubIssueTemplate method.
    * @param hubIssue
    *   issue resulted after executing the incoming processor
    * @param syncRequest
    *   related to the sync
    * @param blobMetadataSeq
    *   contain attachments info, used to create attachments
    * @return
    *   A tuple of the created issue key and the new traces
    */
  def createEntity(
      issueBeforeUpdating: IHubIssueReplica,
      hubIssue: IHubIssueReplica,
      syncRequest: ISyncRequest,
      blobMetadataSeq: Seq[IBlobMetadata],
      customHttpHeaders: Seq[(String, String)] = Nil
  ): Future[(IIssueKey, Seq[INonPersistentTrace])]

  /** @param issueBeforeUpdating
    *   this issue doesn't contain values as there was not issue on the system
    * @param hubIssue
    *   issue resulted after executing the incoming processor
    * @param issueKey
    *   issue key of the issue being updated
    * @param syncRequest
    *   related to the sync
    * @param blobMetadataSeq
    *   contain attachments info, used to create attachments
    * @return
    *   updated traces after performin changes
    */
  def updateEntity(
      issueBeforeUpdating: IHubIssueReplica,
      hubIssue: IHubIssueReplica,
      syncRequest: ISyncRequest,
      issueKey: IIssueKey,
      blobMetadataSeq: Seq[IBlobMetadata],
      fieldTraces: Map[TraceType, Seq[ITrace]],
      customHttpHeaders: Seq[(String, String)] = Nil
  ): Future[Seq[INonPersistentTrace]]

  def updateEntityLinkField(
      connection: IConnection,
      fieldName: String,
      localIssueKey: IIssueKey,
      remoteIssueKey: IIssueKey
  ): Future[None.type] = Future.successful(None)

  def removeEntityLinkField(
      connection: IConnection,
      fieldName: String,
      localIssueKey: IIssueKey
  ): Future[None.type] = Future.successful(None)

  def getAttachmentBodyStream(
      blobId: String,
      connection: IConnection,
      entityKey: IIssueKey
  ): Future[Option[Source[ByteString, _]]] = Future.successful(None)

  /** @return
    *   map with variables that will be accessible on the outgoing sync script
    */
  def getDataFilterContext(
      connection: IConnection,
      localIssueKey: IIssueKey,
      entity: IHubIssueReplica,
      replica: IHubIssueReplica
  ): util.HashMap[String, Object]

  /** @return
    *   map with variables that will be accessible on the incoming sync script for update events
    */
  def getChangeProcessorContext(
      connection: IConnection,
      localIssueKey: IIssueKey,
      entity: IHubIssueReplica,
      previous: IHubIssueReplica,
      replica: IHubIssueReplica,
      traces: util.ArrayList[INonPersistentTrace],
      blobMetadataSeq: Seq[IBlobMetadata],
      issueBeforeUpdating: IHubIssueReplica
  ): util.HashMap[String, Object]

  /** @return
    *   map with variables that will be accessible on the incoming sync script for create events
    *   (first sync for issue)
    */
  def getCreateProcessorContext(
      connection: IConnection,
      entities: Seq[IHubIssueReplica],
      replica: IHubIssueReplica,
      traces: util.ArrayList[INonPersistentTrace],
      blobMetadataSeq: Seq[IBlobMetadata],
      issueBeforeUpdating: Seq[IHubIssueReplica]
  ): util.HashMap[String, Object]

  @Deprecated
  def getEntityUrl(twinTraceId: Int): Future[Option[String]] = Future.successful(None)

  /** @return
    *   entity url used by remote instance to generate a link to this instance entity
    */
  def getEntityUrl(issueKey: IIssueKey, connection: IConnection): Future[Option[String]] =
    Future.successful(None)

  def getEntityUrl(
      issueUrn: String,
      fieldValues: Option[Map[String, String]],
      entityType: Option[String] = None
  ): Future[Option[String]] = Future.successful(None)

  def getMainEntityType: String = "issue"

  /** Used in Github node. Parse connectIssueUrn from CSV file.
    * @param connectIssueUrn
    *   looks like Exalate-team/qa-3" in order to be consistent with Jira issue key Proj-1
    * @return
    *   IssueUrn and field values - info about repo
    */
  def getIssueKeyAndFieldValuesForConnect(connectIssueUrn: String): (String, Map[String, String]) =
    (connectIssueUrn, Map())

  /** Should get localKey And hubPayload from tracker. It is a combination of 2 methods:
    * {@link getLocalKey} and {@link getHubPayloadFromTracker} . the aim of it is to optimise these
    * 2 methods since they make similar requests - checking whether issue exists and returns either
    * entity key or entire entity info Mainly, currently, it is used for connect/bulk connect
    * operations
    * @param localIssueUrn
    * @param connection
    * @param entityType
    * @param fieldValues
    * @return
    *   Tuple2(IIssueKey, IHubPayload)
    */
  def getLocalKeyAndHubPayloadFromTracker(
      localIssueUrn: String,
      connection: IConnection,
      entityType: String,
      fieldValues: Map[String, String]
  )(implicit ec: ExecutionContext): Future[(Option[IIssueKey], Option[IHubPayload])] =
    for {
      keyOpt <- getLocalKey(localIssueUrn, connection, entityType, fieldValues)
      payloadOpt <- keyOpt
        .map(getHubPayloadFromTracker(_, connection))
        .getOrElse(Future.successful(None))
    } yield (keyOpt, payloadOpt)

}
