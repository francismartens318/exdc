package com.exalate.generic.services.api

import com.exalate.domain.values.connection.ConnectionValue
import play.api.mvc.{AnyContent, Request, Result}

import scala.concurrent.Future

/** This trait should be implemented by each node. It should render UI using template or other ways.
  * It's also node's responsibility to check if oauth should be started (if supported).
  */
trait INodeAssetsService {
  def getUI(request: Request[AnyContent]): Future[Result]

  def getUIWithPossibleCallback(
      request: Request[AnyContent],
      connectionOpt: Option[ConnectionValue]
  ): Future[Result]

  def getAuthorizationUI(request: Request[AnyContent]): Future[Result]

  def isMemberOfExalateConsoleAdminGroup(accountIdOpt: Option[String]): Future[Boolean]
}
