package com.exalate.generic.services.api

import play.api.libs.json.JsValue

import scala.concurrent.Future

/** Trait should be implemented if node supports visual triggers.
  */
class IEntityFieldsService {
  def getFieldsForEntity(entityType: String): Future[Seq[JsValue]] = Future.successful(Nil)
}
