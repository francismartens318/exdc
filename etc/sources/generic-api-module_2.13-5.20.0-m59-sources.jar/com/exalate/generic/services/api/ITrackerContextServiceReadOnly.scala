package com.exalate.generic.services.api

import com.exalate.api.domain.{IBlobMetadata, IIssueKey}
import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.hubobject.IHubIssueReplica
import com.exalate.api.domain.twintrace.INonPersistentTrace

import java.util

/** Service which forms variables for script execution in Exalate for the tracker specifically . The
  * context generated here has read only property. It means that during the script execution it will
  * have not affect on the instance itself (etc, no data creation, no data update on the instance)
  */
trait ITrackerContextServiceReadOnly {

  def getDataFilterContextReadOnly(
      connection: IConnection,
      localIssueKey: IIssueKey,
      entity: IHubIssueReplica,
      replica: IHubIssueReplica,
      isAIScript: Boolean = false
  ): util.HashMap[String, Object]

  def getCreateProcessorContextReadOnly(
      relation: IConnection,
      entities: Seq[IHubIssueReplica],
      replica: IHubIssueReplica,
      traces: util.ArrayList[INonPersistentTrace],
      blobMetadataSeq: Seq[IBlobMetadata],
      entitiesBeforeUpdating: Seq[IHubIssueReplica],
      isAIScript: Boolean = false
  ): util.HashMap[String, Object]

  def getChangeProcessorContextReadOnly(
      relation: IConnection,
      localIssueKey: IIssueKey,
      issue: IHubIssueReplica,
      previous: IHubIssueReplica,
      replica: IHubIssueReplica,
      traces: util.ArrayList[INonPersistentTrace],
      blobMetadataSeq: Seq[IBlobMetadata],
      entitiesBeforeUpdating: IHubIssueReplica,
      isAIScript: Boolean = false
  ): util.HashMap[String, Object]

}
