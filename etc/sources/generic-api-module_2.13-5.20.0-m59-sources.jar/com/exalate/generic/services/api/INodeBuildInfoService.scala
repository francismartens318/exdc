package com.exalate.generic.services.api

import com.exalate.generic.services.BuildInfo

/** Each node should implement, taking values from BuildInfo, that is built on project compilation.
  * You may check 'build-info generation' in [build.sbt]
  */
trait INodeBuildInfoService {

  def getBuildInfo: BuildInfo
}
