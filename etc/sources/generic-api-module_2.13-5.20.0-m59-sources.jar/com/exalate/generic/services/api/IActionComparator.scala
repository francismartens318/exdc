package com.exalate.generic.services.api

import com.exalate.api.domain.webhook.{INonPersistentWebhookInfo, IWebhookInfo}
import com.exalate.generic.services.FullAuditInfo

/** Used for impersonation. If impersonation is supported in tracker, this trait needs to be
  * implemented inside node. Using default implementation for nodes that support implementation
  * might lead to duplication of comments/attachments..
  */
trait IActionComparator {

  def isSameAction(webhookInfo: IWebhookInfo)(auditLog: FullAuditInfo): Boolean

  def isSameAction(webhookInfo: INonPersistentWebhookInfo)(auditLog: FullAuditInfo): Boolean

}
