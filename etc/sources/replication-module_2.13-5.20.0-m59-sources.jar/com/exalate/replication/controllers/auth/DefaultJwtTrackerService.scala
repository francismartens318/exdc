package com.exalate.replication.controllers.auth

import com.exalate.generic.services.api.IJwtTrackerService
import play.api.mvc.RequestHeader

import javax.inject.Inject
import scala.concurrent.ExecutionContext

class DefaultJwtTrackerService @Inject() ()(implicit ec: ExecutionContext)
    extends IJwtTrackerService {

  override def validateTrackerJwt(request: RequestHeader, userAccessRights: String): Boolean = false

  override def shouldValidateTrackerJwt(): Boolean = false
}
