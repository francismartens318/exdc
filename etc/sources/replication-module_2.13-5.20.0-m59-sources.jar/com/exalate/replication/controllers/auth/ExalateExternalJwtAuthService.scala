package com.exalate.replication.controllers.auth

import java.time.Instant
import com.exalate.api.domain.connection.IConnection
import com.exalate.api.persistence.relation.IRelationRepository
import com.exalate.error.services.api.IBugExceptionCategoryService
import com.exalate.replication.controllers.auth.ExalateExternalJwtConstants.{
  JWT_CONNECTION_KEY_PROP,
  JWT_KEY,
  MAX_AGE
}
import com.exalate.replication.services.config.ConnectionService.SECRET_LENGTH
import com.google.inject.{Inject, Singleton}
import org.apache.commons.lang3.StringUtils
import pdi.jwt.{JwtAlgorithm, JwtJson, JwtOptions}
import play.api.Logger
import play.api.http.Status.{FORBIDDEN, UNAUTHORIZED}
import play.api.libs.json.Json
import play.api.libs.ws.{StandaloneWSRequest, WSResponse}
import play.api.mvc.{Cookies, Headers, Request, RequestHeader}

import scala.collection.mutable
import scala.concurrent.{ExecutionContext, Future}
import scala.util.Try

@Singleton
class ExalateExternalJwtAuthService @Inject() (
    relationRepository: IRelationRepository,
    bugExceptionCategoryService: IBugExceptionCategoryService
)(implicit ec: ExecutionContext) {

  val LOG: Logger = Logger("application.controllers.utils.ExalateExternalJwtAuthService")

  private val secretsWithPadding = mutable.Map[Int, Boolean]()

  /** Validate jwt from Request
    * @param request
    * @tparam T
    * @return
    *   None or failed
    */
  def validateJwt[T](request: Request[T]): Future[None.type] =
    validateJwt(request.cookies, request.headers)

  /** Validate jwt from RequestHeader
    * @param request
    * @return
    *   None or failed
    */
  def validateJwt(request: RequestHeader): Future[None.type] =
    validateJwt(request.cookies, request.headers)

  /** Firstly Tries to validate jwt from cookies, if it failed then from headers
    * @param cookies
    * @param headers
    * @return
    *   None or failed
    */
  private def validateJwt(cookies: Cookies, headers: Headers) =
    validateJwtFromCookies(cookies)
      .recoverWith {
        case e: Exception => validateJwtFromHeaders(headers)
      }
      .recoverWith {
        case e: Exception =>
          LOG.warn(s"Error on validating JWT: ${e.getMessage()}", e)
          Future.failed(e)
      }

  private def validateJwtFromHeaders(headers: Headers): Future[None.type] =
    validateJwt(headers.toSimpleMap.get(JWT_KEY))

  private def validateJwtFromCookies[T](cookies: Cookies): Future[None.type] =
    validateJwt(cookies.get(JWT_KEY).map(_.value))

  /** Jwt validation.
    * @param jwtOpt
    * @return
    *   None or failed
    */
  private def validateJwt(jwtOpt: Option[String]): Future[None.type] =
    jwtOpt.flatMap { jwt =>
      LOG.trace(s"Validating jwt $jwt")
      JwtJson
        .decodeJson(jwt, JwtOptions(signature = false))
        .toOption
        .map(json => (json \ JWT_CONNECTION_KEY_PROP).as[String])
        .map(connectionKey => (jwt, connectionKey))
    } match {
      case Some((jwt, connectionKey)) =>
        relationRepository.getConnectionFuture(connectionKey).flatMap {
          case Some(connection) =>
            Future
              .fromTry(
                Try(JwtJson.validate(jwt, connection.getInvitationSecret, Seq(JwtAlgorithm.HS256)))
                  .orElse(
                    Try(
                      JwtJson.validate(
                        jwt,
                        addPadding(connection.getInvitationSecret),
                        Seq(JwtAlgorithm.HS256)
                      )
                    )
                  )
              )
              .map(_ => None)
          case None             =>
            val exception = bugExceptionCategoryService
              .generateNoConnectionForReceivedJWTBugException(connectionKey)
            LOG.error(
              s"Couldn't find connection $connectionKey when authenticating incoming external JWT"
            )
            Future.failed(exception)
        }
      case None                       =>
        val exception = bugExceptionCategoryService.generateNoExternalJWTFoundBugException()
        Future.failed(exception)
    }

  /*
   * This set of methods is a temporary decision for upgrading all connection secrets to have a length of 32
   * We cannot directly apply addPadding() for short secrets, cause this will break connections with nodes that are not yet upgraded
   * So in this temporary phase we ensure both backward and forward compatibility
   * For incoming JWTs we check both original secret and addPadding(secret)
   * For outgoing JWTs we try sending original secret and if we get 401 or 403 then addPadding(secret). Or visa versa if last successful attempt was with padded version.
   */

  def processWithShortSecretRetry(
      connection: IConnection,
      doRequest: => Future[WSResponse]
  ): Future[WSResponse] =
    doRequest.flatMap {
      case response if response.status == UNAUTHORIZED || response.status == FORBIDDEN =>
        if (shouldRetryAuth(connection))
          doRequest
        else
          Future.successful(response)
      case response => Future.successful(response)
    }

  private def shouldRetryAuth(connection: IConnection): Boolean =
    connection.getInvitationSecret match {
      case secret if secret.length < SECRET_LENGTH =>
        val lastTry = secretsWithPadding.getOrElse(connection.getID, false)
        LOG.warn(
          s"Auth failed for deprecated secret of connection ${connection.getName}, " +
            s"will switch padding from $lastTry to ${!lastTry}"
        )
        secretsWithPadding.put(connection.getID, !lastTry)
        true
      case _                                       => false
    }

  /** Extract connection from request, i.e. takes jwt from the input request, parse it and gets
    * connection from DB by name
    * @param request
    * @tparam T
    * @return
    */
  def getConnectionFromRequest[T](request: Request[T]): Future[IConnection] = {
    def getConnectionFromJwt(jwtOpt: Option[String]): Future[IConnection] =
      jwtOpt.flatMap { jwt =>
        JwtJson
          .decodeJson(jwt, JwtOptions(signature = false))
          .toOption
          .map(json => (json \ JWT_CONNECTION_KEY_PROP).as[String])
      } match {
        case Some(connectionKey) =>
          relationRepository.getConnectionFuture(connectionKey).flatMap {
            case Some(connection) => Future.successful(connection)
            case None             =>
              LOG.error(
                s"Couldn't find connection $connectionKey when authenticating incoming external JWT"
              )
              val exception = bugExceptionCategoryService
                .generateNoConnectionForReceivedJWTBugException(connectionKey)
              Future.failed(exception)
          }
        case None                =>
          val exception = bugExceptionCategoryService.generateNoExternalJWTFoundBugException()
          Future.failed(exception)
      }
    getConnectionFromJwt(request.cookies.get(JWT_KEY).map(_.value))
      .recoverWith {
        case e: Exception => getConnectionFromJwt(request.headers.toSimpleMap.get(JWT_KEY))
      }
      .recoverWith {
        case e: Exception =>
          LOG.trace(s"Error on getting connection from JWT: ${e.getMessage()}", e)
          Future.failed(e)
      }
  }

  def addExternalJwt[R <: StandaloneWSRequest](request: R, connection: IConnection): R =
    Option(connection.getInvitationSecret).fold {
      request
    } { invitationSecret =>
      val withPadding = invitationSecret.length >= SECRET_LENGTH || secretsWithPadding.getOrElse(
        connection.getID,
        false
      )
      val claim = Json.obj(
        (JWT_CONNECTION_KEY_PROP, connection.getName),
        ("exp", Instant.now().plusSeconds(MAX_AGE).toEpochMilli)
      )
      val algo = JwtAlgorithm.HS256
      val jwt = JwtJson.encode(
        claim,
        if (withPadding) addPadding(invitationSecret) else invitationSecret,
        algo
      )
      request
        .addHttpHeaders(JWT_KEY -> jwt)
        .asInstanceOf[R]
    }

  def addPadding(secret: String): String = StringUtils.rightPad(secret, SECRET_LENGTH, '=')

}
