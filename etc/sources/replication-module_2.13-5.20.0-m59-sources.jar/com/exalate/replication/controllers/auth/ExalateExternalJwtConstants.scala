package com.exalate.replication.controllers.auth

object ExalateExternalJwtConstants {
  val JWT_KEY = "X-external-exalate-jwt"
  val JWT_CONNECTION_KEY_PROP = "connectionKey"
  val MAX_AGE = 1000
}
