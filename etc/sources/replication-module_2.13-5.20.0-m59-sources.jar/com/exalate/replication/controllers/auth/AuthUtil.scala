package com.exalate.replication.controllers.auth

import akka.util.ByteString
import com.exalate.replication.controllers.auth.UserAccessRights.{
  ADMIN,
  PROJECT_ADMIN_WITHOUT_ACCESS,
  PROJECT_ADMIN_WITH_ACCESS,
  USER,
  UserAccessRights
}
import pdi.jwt.{JwtAlgorithm, JwtJson, JwtOptions}
import play.api.Logger
import play.api.http.HttpEntity
import play.api.libs.json.{JsObject, JsSuccess}
import play.api.mvc.{Request, ResponseHeader, Result}

import scala.concurrent.Future

object AuthUtil {

  val LOG: Logger = Logger("controllers.utils.auth.AuthUtil")

  def decodeJwt(jwt: String, secret: String): Option[JsObject] =
    JwtJson.decodeJson(jwt, secret, Seq(JwtAlgorithm.HS256), JwtOptions(leeway = 30)).toOption

  /** Validation of decoded jwt with provided UserAccessRights
    *
    * @param jwtObj
    * @param userAccessRights
    * @return
    *   Option[true] or None
    */
  def validateDecodedJwtObjResult(jwtObj: JsObject, userAccessRights: UserAccessRights): Boolean = {
    val expectedRole = Role(userAccessRights)
    ((jwtObj \ "role").validate[Role], (jwtObj \ "nickname").validate[String]) match {
      case (JsSuccess(actualRole, _), _) =>
        validateUserAccessRights(expectedRole, actualRole)
      case (
            _,
            JsSuccess(nickname, _)
          ) => // For backwards compatibility if we fail to get role we check if nickname is available in jwt
        UserAccessRights.withNameOpt(nickname) match {
          case Some(userAccessRights) =>
            validateUserAccessRights(expectedRole, Role(userAccessRights))
          case _                      =>
            LOG.error(
              s"Unknown `nickname` value in claim from the exalate internal JWT object: $jwtObj"
            )
            false
        }
      case _                             =>
        LOG.error(
          s"Could not find either `role` or `nickname` claim in the exalate internal JWT object: $jwtObj"
        )
        false
    }
  }

  /** Validation of UserAccessRights. It checks if expected rights is the same as actual.
    *
    * @param expectedAccessRights
    * @param actualAccessRights
    * @return
    *   Option[true] or None
    */
  def validateUserAccessRights(expectedRole: Role, actualRole: Role): Boolean =
    (expectedRole, actualRole) match {
      case (_, BasicRole(ADMIN)) => true
      case (BasicRole(USER), _)  => true
      case (
            ProjectAdminRole(_, expectedProjectIds),
            ProjectAdminRole(PROJECT_ADMIN_WITH_ACCESS, actualProjectIds)
          ) if expectedProjectIds.subsetOf(actualProjectIds) =>
        true
      case (ProjectAdminRole(_, _), ProjectAdminRole(PROJECT_ADMIN_WITH_ACCESS, projectIds))
          if projectIds.isEmpty =>
        true
      case (
            ProjectAdminRole(PROJECT_ADMIN_WITHOUT_ACCESS, expectedProjectIds),
            ProjectAdminRole(PROJECT_ADMIN_WITHOUT_ACCESS, actualProjectIds)
          ) if expectedProjectIds.subsetOf(actualProjectIds) =>
        true
      case (
            ProjectAdminRole(PROJECT_ADMIN_WITHOUT_ACCESS, _),
            ProjectAdminRole(PROJECT_ADMIN_WITHOUT_ACCESS, projectIds)
          ) if projectIds.isEmpty =>
        true
      case _                     => false
    }

  def returnUnauthorizedResponse[A](request: Request[A], msg: Option[String] = None): Future[Result] = {
    val unauthorizedResponse = Result(
      ResponseHeader(
        403,
        reasonPhrase = Some("Unauthorized to access this resource, please authenticate.")
      ),
      HttpEntity.Strict(
        ByteString(msg.getOrElse("You are not permitted to access this resource.")),
        Some("text/plain")
      )
    )
    Future.successful(unauthorizedResponse)
  }

}
