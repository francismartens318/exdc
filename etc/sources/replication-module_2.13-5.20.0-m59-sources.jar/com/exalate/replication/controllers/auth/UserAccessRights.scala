package com.exalate.replication.controllers.auth

object UserAccessRights extends Enumeration {
  type UserAccessRights = Value
  val USER = Value("user")
  val ADMIN = Value("admin")
  val PROJECT_ADMIN_WITHOUT_ACCESS = Value("project admin without access")
  val PROJECT_ADMIN_WITH_ACCESS = Value("project admin with access")

  def withNameOpt(name: String): Option[Value] =
    UserAccessRights.values.find(_.toString.equals(name))

}
