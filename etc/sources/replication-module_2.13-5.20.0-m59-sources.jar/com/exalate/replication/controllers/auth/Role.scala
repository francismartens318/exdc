package com.exalate.replication.controllers.auth

import com.exalate.replication.controllers.auth.UserAccessRights.{
  ADMIN,
  PROJECT_ADMIN_WITHOUT_ACCESS,
  PROJECT_ADMIN_WITH_ACCESS,
  USER,
  UserAccessRights
}
import play.api.libs.json.{
  Format,
  JsArray,
  JsError,
  JsObject,
  JsResult,
  JsString,
  JsSuccess,
  JsValue
}

sealed trait Role {
  def accessRights: UserAccessRights
}

case class BasicRole(override val accessRights: UserAccessRights) extends Role

case class ProjectAdminRole(override val accessRights: UserAccessRights, projectIds: Set[String])
    extends Role

object Role {

  def apply(accessRights: UserAccessRights, projectIds: Set[String] = Set.empty): Role =
    accessRights match {
      case PROJECT_ADMIN_WITH_ACCESS | PROJECT_ADMIN_WITHOUT_ACCESS =>
        ProjectAdminRole(accessRights, projectIds)
      case _                                                        => BasicRole(accessRights)
    }

  def Admin: Role = Role(ADMIN)

  def User: Role = Role(USER)

  def ProjectAdminWithAccess(projectIdOpt: Set[String]): Role =
    Role(PROJECT_ADMIN_WITH_ACCESS, projectIdOpt)

  def ProjectAdminWithoutAccess(projectIdOpt: Set[String]): Role =
    Role(PROJECT_ADMIN_WITHOUT_ACCESS, projectIdOpt)

  implicit val roleFormat: Format[Role] = new Format[Role] {

    override def reads(json: JsValue): JsResult[Role] =
      ((json \ "accessRights").validate[String], (json \ "projectIds").asOpt[Set[String]]) match {
        case (JsSuccess(accessRights, _), projectIdOpt) =>
          UserAccessRights.withNameOpt(accessRights) match {
            case Some(userAccessRights) =>
              JsSuccess(Role(userAccessRights, projectIdOpt.toSet.flatten))
            case _                      => JsError("Name from `role` json is not valid")
          }
        case (error @ JsError(_), _)                    => error

      }

    override def writes(role: Role): JsValue =
      role match {
        case BasicRole(accessRights)                    =>
          JsObject(Seq("role" -> JsObject(Seq("accessRights" -> JsString(accessRights.toString)))))
        case ProjectAdminRole(accessRights, projectIds) =>
          JsObject(
            Seq(
              "role" -> JsObject(
                Seq(
                  "accessRights" -> JsString(accessRights.toString),
                  "projectIds" -> JsArray(projectIds.map(JsString).toSeq)
                )
              )
            )
          )
      }

  }

}
