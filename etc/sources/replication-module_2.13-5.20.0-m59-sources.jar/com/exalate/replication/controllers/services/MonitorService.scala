package com.exalate.replication.controllers.services

import com.exalate.api.persistence.IHealthCheckRepository
import com.exalate.api.persistence.error.IErrorRepository
import com.exalate.api.persistence.metrics.IMetricsRepository
import com.exalate.api.persistence.relation.IRelationRepository
import com.exalate.api.persistence.replication.event.IEventReplicationRepository
import com.exalate.api.persistence.replication.request.IRequestReplicationRepository
import com.exalate.api.persistence.trigger.ITriggerRepository
import com.exalate.api.persistence.twintrace.ITwinTraceRepository
import com.exalate.domain.exception.issuetracker.UnauthorizedTrackerRestException
import com.exalate.domain.values.{NodeStatus, TrackerInfo}
import com.exalate.replication.services.api.config.{IConnectionService, IGeneralSettingsService}
import com.exalate.replication.services.api.issuetracker.{
  IMonitorLicenseService,
  ITrackerLicenseService
}
import com.exalate.replication.services.api.license.ILicenseService
import com.exalate.replication.services.api.node.lifecycle.ILifecycleInfoService
import com.exalate.services.utils.IBuildInfoService
import com.google.inject.Inject
import play.api.Logger
import play.api.i18n.{Langs, Messages, MessagesApi, MessagesImpl}
import play.api.libs.json.{Json, OFormat}

import java.text.SimpleDateFormat
import scala.concurrent.{ExecutionContext, Future}

class MonitorService @Inject() (
    langs: Langs,
    messagesApi: MessagesApi,
    connectionRepo: IRelationRepository,
    triggerRepository: ITriggerRepository,
    twinTraceRepository: ITwinTraceRepository,
    errorRepository: IErrorRepository,
    eventReplicationRepository: IEventReplicationRepository,
    requestReplicationRepository: IRequestReplicationRepository,
    generalSettingsService: IGeneralSettingsService,
    lifecycleInfoService: ILifecycleInfoService,
    monitorLicenseService: IMonitorLicenseService,
    trackerLicenseService: ITrackerLicenseService,
    licenseService: ILicenseService,
    connectionService: IConnectionService,
    metricPersis: IMetricsRepository,
    buildInfoService: IBuildInfoService,
    healthCheckRepository: IHealthCheckRepository
)(implicit val ec: ExecutionContext) {
  val LOG: Logger = Logger(classOf[MonitorService])

  implicit val messages: Messages =
    MessagesImpl(langs.availables.find(_.code == "en").get, messagesApi)

  def authMonitor(isRequestBy: Boolean): Future[AmountOfErrors] =
    if (isRequestBy) {
      errorRepository
        .countAllErrors()
        .map(errorCount => AmountOfErrors(errorCount))
    } else {
      Future.failed(new UnauthorizedTrackerRestException("Requested by Unauthorized user"))
    }

  def getSimpleNodeStatus: Future[SimpleNodeStatus] = {
    LOG.debug("Getting simple Node Status")
    twinTraceRepository.getLastSyncDate().map { dateOpt =>
      SimpleNodeStatus(
        dateOpt
          .map(ld => new SimpleDateFormat("dd/MMM/yyyy HH:mm:ss").format(ld))
          .getOrElse("No sync yet"),
        buildInfoService.getNodeVersion
      )
    }
  }

  def getNodeStatus: Future[NodeStatus] = {
    LOG.debug("Getting full Node Status")
    for {
      numberOfConnections <- connectionRepo.countConnectionsFuture
      numberOfEditorConnections <- connectionRepo.countConnectionsEditorFuture
      numberOfBasicConnections <- connectionRepo.countBasicConnectionsFuture
      numberOfAcceptedConnections <- connectionRepo.countAcceptedConnectionsFuture
      numberOfTriggers <- triggerRepository.countTriggers()
      numberOfTriggersForBasicConnection <- triggerRepository.countTriggersForBasicConnection()
      numberOfIssuesUnderSync <- twinTraceRepository.getSynchronizedCount()
      numberOfEditorIssuesUnderSync <- twinTraceRepository.getEditorSynchronizedCount()
      numberOfNodeLevelErrors <- errorRepository.countNodeLevelErrors()
      numberOfConnectionLevelErrors <- errorRepository.countConnectionLevelErrors()
      numberOfTriggerLevelErrors <- errorRepository.countTriggerLevelErrors()
      numberOfIssueLevelErrors <- errorRepository.countIssueLevelErrors()
      numberOfWarningLevelErrors <- errorRepository.countWarningLevelErrors()
      numberOfEntitiesInSyncEventQueue <- eventReplicationRepository.getNumberOfEntities()
      numberOfEntitiesInSyncRequestQueue <- requestReplicationRepository.getNumberOfEntities()
      gs <- generalSettingsService.get
      issueTrackerUrl = gs.map(_.getIssueTrackerUrl)
      lifecycleValue = lifecycleInfoService.get
      instanceUid <- lifecycleValue.map(_.instanceUid)
      isEulaAccepted <- lifecycleValue.map(_.isEulaAccepted)
      isVerified <- lifecycleValue.map(_.verified)
      lastSuccessfulSyncDate <- twinTraceRepository.getLastSuccessfulSyncDate()
      lastSuccessfulSyncDateStr = lastSuccessfulSyncDate.map(ld =>
        new SimpleDateFormat("dd/MMM/yyyy HH:mm:ss").format(ld)
      )
      lastSyncDate <- twinTraceRepository.getLastSyncDate()
      lastSyncDateStr = lastSyncDate.map(ld =>
        new SimpleDateFormat("dd/MMM/yyyy HH:mm:ss").format(ld)
      )
      lastEditorSyncDate <- twinTraceRepository.getLastEditorSyncDate()
      lastEditorSyncDateStr = lastEditorSyncDate.map(ld =>
        new SimpleDateFormat("dd/MMM/yyyy HH:mm:ss").format(ld)
      )
      monitorLicense <- monitorLicenseService.getMonitorLicenseInfo
      numberOfUsers <- monitorLicenseService.getNumberOfUsers
      hasTrackerLicense <- trackerLicenseService.hasTrackerLicense
      exalateLicenseValue <- licenseService
        .getLicenses(hasTrackerLicense, false)
        .map(_.currentLicense)
      remoteExalateUrls <- connectionRepo.getRemoteUrls
      connectionsInfo <- connectionService.getConnectionInfo()
      numberOfNotFinishedConnections <- metricPersis.getAmountOfNonFinishedConnections()
    } yield NodeStatus(
      exalateLicenseValue.orElse(monitorLicense.licenseInfo),
      lastSyncDateStr,
      lastSuccessfulSyncDateStr,
      lastEditorSyncDateStr,
      numberOfConnections,
      numberOfEditorConnections,
      numberOfBasicConnections,
      numberOfNotFinishedConnections,
      numberOfAcceptedConnections,
      numberOfTriggers,
      numberOfTriggersForBasicConnection,
      numberOfIssuesUnderSync,
      numberOfEditorIssuesUnderSync,
      numberOfNodeLevelErrors,
      numberOfConnectionLevelErrors,
      numberOfTriggerLevelErrors,
      numberOfIssueLevelErrors,
      numberOfWarningLevelErrors,
      numberOfEntitiesInSyncEventQueue,
      numberOfEntitiesInSyncRequestQueue,
      issueTrackerUrl,
      instanceUid,
      isEulaAccepted,
      isVerified,
      buildInfoService.getExaCompVersion,
      buildInfoService.getRawNodeVersion,
      remoteExalateUrls,
      TrackerInfo(
        monitorLicense.isPluginInstalled,
        monitorLicense.state,
        monitorLicense.errorMessage
      ),
      connectionsInfo,
      numberOfUsers
    )
  }

  def getNodeStatusWithAuth(isRequestBy: Boolean): Future[NodeStatus] =
    if (isRequestBy) {
      getNodeStatus
    } else {
      Future.failed(new UnauthorizedTrackerRestException("Requested by Unauthorized user"))
    }

}

case class SimpleNodeStatus(lastSyncDate: String, exaNodeVersion: String)

object SimpleNodeStatus {
  implicit val fmt: OFormat[SimpleNodeStatus] = Json.format[SimpleNodeStatus]
}

case class AmountOfErrors(numErrors: Int)

object AmountOfErrors {
  implicit val fmt: OFormat[AmountOfErrors] = Json.format[AmountOfErrors]
}
