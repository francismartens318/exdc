package com.exalate.replication.controllers.services

import com.exalate.api.exception.bug.NoGeneralSettingsBugException
import com.exalate.domain.exception.issuetracker.{
  BadRequestTrackerRestException,
  NotFoundTrackerRestException
}
import com.exalate.domain.values.NodeInfoValue
import com.exalate.domain.values.v4.FeatureFlagsValue
import com.exalate.replication.services.transport.v1.rest.NodeInfoProvider
import com.google.inject.Inject
import play.api.{Configuration, Logger}
import play.api.i18n.{Langs, Messages, MessagesApi, MessagesImpl}

import scala.concurrent.{ExecutionContext, Future}

class NodeInfoControllerService @Inject() (
    nodeInfoJsonProvider: NodeInfoProvider,
    langs: Langs,
    messagesApi: MessagesApi,
    configuration: Configuration
)(implicit val ec: ExecutionContext) {
  val LOG: Logger = Logger(classOf[NodeInfoControllerService])

  implicit val messages: Messages =
    MessagesImpl(langs.availables.find(_.code == "en").get, messagesApi)

  def getSelfNodeInfo: Future[NodeInfoValue] =
    nodeInfoJsonProvider.get
      .recoverWith {
        case e: NoGeneralSettingsBugException =>
          Future.failed(new BadRequestTrackerRestException(e.getMessage))
        case e: Exception                     =>
          LOG.error(e.getMessage, e)
          val message = messages
            .translate("not.found.self.node.info", Nil)
            .getOrElse("Exception while getting local node info")
          Future.failed(new NotFoundTrackerRestException(message))
      }

  lazy val getFeatureFlags: Future[FeatureFlagsValue] = Future.successful {
    FeatureFlagsValue(
      licensingService = configuration.get[Boolean]("com.exalate.service.licensing.enabled"),
      groovyLsp = configuration.get[Boolean]("com.exalate.feature.groovy-lsp.enabled"),
      chargeBee = configuration.get[Boolean]("com.exalate.feature.chargebee.enabled"),
      newGettingStartedUi =
        configuration.get[Boolean]("com.exalate.feature.new-getting-started-ui.enabled"),
      aiAssist = configuration.get[Boolean]("com.exalate.feature.ai-assist.enabled")
    )
  }

}
