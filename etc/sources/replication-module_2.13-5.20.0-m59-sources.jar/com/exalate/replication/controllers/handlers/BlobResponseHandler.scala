package com.exalate.replication.controllers.handlers

import com.exalate.api.domain.blob.event.{BlobEventStatus, IBlobEvent}
import com.exalate.api.domain.connection.ReceiveProtocol
import com.exalate.api.domain.event.ISyncEvent
import com.exalate.api.persistence.replication.blobevent.IBlobEventReplicationRepository
import com.exalate.api.persistence.replication.event.IEventReplicationRepository
import com.exalate.replication.services.api.replication.worker.IWorkerNotificationService
import com.exalate.replication.services.transport.value.BlobResponseValue
import play.api.Logger

import javax.inject.{Inject, Singleton}
import scala.concurrent.{ExecutionContext, Future}

@Singleton
class BlobResponseHandler @Inject() (
    persistence: IEventReplicationRepository,
    blobEventReplicationRepository: IBlobEventReplicationRepository,
    workerNotificationService: IWorkerNotificationService
)(implicit ec: ExecutionContext) {

  private val LOG = Logger("application.controllers.handlers.BlobResponseHandler")

  /** Handles blob response: Defines the next status by calling {@link getNextStatus()} and updates
    * Blob Event On Blob Response
    * @param blobResponseValue
    * @return
    *   None
    */
  def handleBlobResponse(blobResponseValue: BlobResponseValue): Future[Option[IBlobEvent]] = {
    val syncEventId: Int = blobResponseValue.syncEventId
    val blobId = blobResponseValue.blobMetadata.getBlobId
    val relationKey = blobResponseValue.relationKey
    LOG.info(
      s"Received a blob response for sync event id `$syncEventId` and unique blob id `$blobId`"
    )

    val blobEventIdOpt = blobResponseValue.blobEventId
    val blobEventOptFuture = blobEventIdOpt match {
      case Some(blobEventId) =>
        blobEventReplicationRepository.getBlobEventById(blobEventId).flatMap {
          case Some(blobEvent) =>
            val nextStatus = getNextStatus(blobEvent.getSyncEvent)
            blobEventReplicationRepository.updateBlobEventOnBlobResponse(blobEvent, nextStatus)
          case None            => Future.successful(None)
        }
      case None              =>
        persistence.getSyncEvent(syncEventId).flatMap {
          case Some(syncEvent) =>
            val nextStatus = getNextStatus(syncEvent)
            blobEventReplicationRepository
              .findBlobEventWaitingForBlobResponseBySyncEventAndUpdateStatus(
                syncEventId,
                blobId,
                relationKey,
                nextStatus
              )
          case None            => Future.successful(None)
        }
    }

    blobEventOptFuture.foreach {
      case Some(_) =>
        workerNotificationService.sendProcessBlobEventsNotification()

      case None =>
        val message = blobEventIdOpt
          .map(blobEventId =>
            s"Received an blobResponse from an instance, but could not find the referenced blob event by id `$blobEventId`"
          )
          .getOrElse(
            s"Received an blobResponse from an instance, but could not find the referenced blob event by sync event `$syncEventId` and blob id $blobId. The connection `$relationKey`"
          )
        LOG.warn(message)
    }
    blobEventOptFuture
  }

  /** Based on the ReceiveProtocol defines next blob Event status `NOTIFY_BLOB_RESPONSE_RECEIVED` or
    * `BLOB_PROCESSED`
    * @param syncEvent
    * @return
    */
  private def getNextStatus(syncEvent: ISyncEvent) = {
    val connection = syncEvent.getConnection
    val receiveProtocol = connection.getReceiveProtocol
    if (receiveProtocol == ReceiveProtocol.POLL) BlobEventStatus.NOTIFY_BLOB_RESPONSE_RECEIVED
    else BlobEventStatus.BLOB_PROCESSED
  }

}
