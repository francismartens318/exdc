package com.exalate.replication.controllers.handlers

import com.exalate.replication.services.transport.value.ErrorValue
import javax.inject._
import play.api._
import play.api.http.DefaultHttpErrorHandler
import play.api.libs.json.Json
import play.api.mvc.Results._
import play.api.mvc._
import play.api.routing.Router

import scala.concurrent._

class ErrorHandler @Inject() (
    env: Environment,
    config: Configuration,
    sourceMapper: OptionalSourceMapper,
    router: Provider[Router]
) extends DefaultHttpErrorHandler(env, config, sourceMapper, router) {

  private val LOG = Logger("application.controllers.transport.rest")

  /** For generating InternalServerError with ErrorValue based on the {@code request}
    * @param request
    * @param e
    * @return
    */
  override def onServerError(request: RequestHeader, e: Throwable): Future[Result] = {
    import com.exalate.replication.services.transport.v1.rest.SyncRestUtils.Implicits._

    LOG.error(s"On server error raised when interacting with ${request.uri}", e)

    val errorValue: ErrorValue =
      ErrorValue(e.getClass.getName, s"${e.getMessage} Stacktrace:${e.getStackTrace.toString}")
    Future.successful(
      InternalServerError(Json.toJson(errorValue))
    )
  }

}
