package com.exalate.replication.controllers.handlers

import com.exalate.api.domain.ErrorReason
import com.exalate.api.domain.connection.ReceiveProtocol
import com.exalate.api.domain.event.{EventStatus, ISyncEvent}
import com.exalate.api.persistence.replication.event.IEventReplicationRepository
import com.exalate.replication.services.api.replication.worker.IWorkerNotificationService
import com.exalate.replication.services.transport.value.{ErrorResponseValue, ErrorValue}

import javax.inject.{Inject, Singleton}
import play.api.Logger

import scala.concurrent.ExecutionContext
import scala.concurrent.Future
import scala.util.Try

@Singleton
class ErrorResponseHandler @Inject() (
    persistence: IEventReplicationRepository,
    workerNotificationService: IWorkerNotificationService
)(implicit ec: ExecutionContext) {

  private val LOG = Logger("application.controllers.handlers.ErrorResponseHandler")

  def handleErrorResponse(
      errorResponseValue: ErrorResponseValue
  ): Future[Either[ErrorValue, Option[ISyncEvent]]] = {
    val syncEventId: Int = errorResponseValue.syncEventId
    LOG.info(s"Received an error response for sync event id `$syncEventId`")
    persistence
      .getSyncEvent(syncEventId)
      .flatMap(processErrorResponseAndGetErrorValue(errorResponseValue))
  }

  /** Processes error response, based on the sync event status form message and return ErrorValues
    * @param errorResponseValue
    * @param syncEventOpt
    * @return
    */
  private def processErrorResponseAndGetErrorValue(
      errorResponseValue: ErrorResponseValue
  )(syncEventOpt: Option[ISyncEvent]): Future[Either[ErrorValue, Option[ISyncEvent]]] =
    syncEventOpt match {
      case Some(syncEvent) =>
        var message: String = ""
        if (syncEvent.getStatus != EventStatus.WAITING_FOR_RESPONSE) {
          message =
            s"Received an errorResponse from a connection `${errorResponseValue.relationKey}`: ${errorResponseValue.message}. " +
              s"But the referenced event `${errorResponseValue.syncEventId}`. " +
              "is not in the expected status (WAITING_FOR_RESPONSE)"
          Future.successful(Left(ErrorValue(classOf[RuntimeException].getName, message)))
        } else if (
          EventStatus.NOTIFY_RESPONSE_RECEIVED == syncEvent.getStatus || syncEvent.getRemoteReplica != null
        ) {
          message =
            s"Received an errorResponse from a connection `${errorResponseValue.relationKey}`: ${errorResponseValue.message}. " +
              s"But the referenced event `${errorResponseValue.syncEventId}` " +
              "is already in 'NOTIFY_RESPONSE_RECEIVED' state, so it already got a sync response or the remote replica has been already set. "
          Future.successful(Left(ErrorValue(classOf[RuntimeException].getName, message)))
        } else {
          handleValidErrorResponse(syncEvent, errorResponseValue)
        }
      case None            =>
        val message =
          s"Received an errorResponse from a connection `${errorResponseValue.relationKey}`: ${errorResponseValue.message}. " +
            s"But could not find the referenced event `${errorResponseValue.syncEventId}`. " +
            s"The relation `${errorResponseValue.relationKey}`, the issue key `${errorResponseValue.sourceIssueKey.urn}`"
        Future.successful(Left(ErrorValue(classOf[RuntimeException].getName, message)))
    }

  private def handleValidErrorResponse(
      syncEvent: ISyncEvent,
      errorResponseValue: ErrorResponseValue
  ): Future[Either[ErrorValue, Option[ISyncEvent]]] = {
    val connection = syncEvent.getConnection
    val receiveProtocol = connection.getReceiveProtocol
    val nextEventStatus =
      if (Option(receiveProtocol).contains(ReceiveProtocol.POLL))
        EventStatus.NOTIFY_RESPONSE_RECEIVED
      else EventStatus.ERROR_RESPONSE_READY

    syncEvent.setErrorReason(getErrorReason(errorResponseValue.errorReason))
    syncEvent.setErrorResponseMessage(errorResponseValue.message)

    persistence
      .updateSyncEventStatusAndErrorReasonAndErrorMessage(
        syncEvent,
        nextEventStatus,
        syncEvent.getSyncType
      )
      .map { seOpt =>
        workerNotificationService.sendProcessEventsNotification()
        Right(seOpt)
      }
  }

  /** Gets error reason based on the string values
    * @param errorReasonStr
    * @return
    */
  private def getErrorReason(errorReasonStr: String): ErrorReason =
    Try(ErrorReason.valueOf(errorReasonStr)).map(r => r).getOrElse {
      LOG.warn(
        "Received error reason " + errorReasonStr + " is not supported by this node and it will be handled as a general error response"
      )
      ErrorReason.NOT_SUPPORTED
    }

  private def getErrorValue(
      syncEvent: ISyncEvent,
      errorResponseValue: ErrorResponseValue
  ): Option[ErrorValue] = {
    val message = s"Connection `${syncEvent.getConnection.getName}`: ${errorResponseValue.message}"
    Some(ErrorValue(classOf[RuntimeException].getName, message))
  }

}
