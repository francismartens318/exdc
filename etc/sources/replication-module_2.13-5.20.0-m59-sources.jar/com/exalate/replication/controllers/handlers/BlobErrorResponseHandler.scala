package com.exalate.replication.controllers.handlers

import com.exalate.api.domain.blob.BlobErrorReason
import com.exalate.api.domain.blob.event.{BlobEventStatus, IBlobEvent}
import com.exalate.api.domain.connection.ReceiveProtocol
import com.exalate.api.domain.event.ISyncEvent
import com.exalate.api.persistence.replication.blobevent.IBlobEventReplicationRepository
import com.exalate.api.persistence.replication.event.IEventReplicationRepository
import com.exalate.replication.services.api.replication.worker.IWorkerNotificationService
import com.exalate.replication.services.transport.value.BlobErrorResponseValue

import javax.inject.{Inject, Singleton}
import play.api.Logger

import scala.concurrent.ExecutionContext
import scala.concurrent.Future

@Singleton
class BlobErrorResponseHandler @Inject() (
    persistence: IEventReplicationRepository,
    blobEventReplicationRepository: IBlobEventReplicationRepository,
    workerNotificationService: IWorkerNotificationService
)(implicit ec: ExecutionContext) {

  val LOG = Logger("application.controllers.handlers.BlobErrorResponseHandler")

  /** Handles blob error response.
    *   1. Gets blob event from DB 2. Defines next status, based on the sync event:
    *      BlobEventStatus.NOTIFY_BLOB_RESPONSE_RECEIVED or
    *      BlobEventStatus.BLOB_ERROR_RESPONSE_READY 3. sets error info to the blob event 4. updates
    *      blob event status and Error info in DB 5. then calls
    *      {@link IWorkerNotificationService.sendProcessBlobEventsNotification}
    * @param blobErrorResponseValue
    * @return
    *   None
    */
  def handleBlobErrorResponse(blobErrorResponseValue: BlobErrorResponseValue): Future[None.type] = {
    val syncEventId: Int = blobErrorResponseValue.syncEventId
    val blobId = blobErrorResponseValue.getBlobId
    val blobEventIdOpt = blobErrorResponseValue.blobEventId
    val relationKey = blobErrorResponseValue.relationKey
    val blobErrorReason = blobErrorResponseValue.blobErrorReason
    val errorResponseMessage = blobErrorResponseValue.errorMessage
    LOG.info(s"Received a blob error response for sync event id `$syncEventId`")

    val blobEventOptFuture = blobEventIdOpt match {
      case Some(blobEventId) =>
        blobEventReplicationRepository
          .getBlobEventById(blobEventId)
          .flatMap(handleErrorResponse(blobErrorReason, errorResponseMessage))
      case None              =>
        persistence.getSyncEvent(syncEventId).flatMap {
          case Some(se) =>
            blobEventReplicationRepository
              .findBlobEventWaitingForBlobResponseBySyncEvent(se.getId, blobId, relationKey)
              .flatMap(handleErrorResponse(blobErrorReason, errorResponseMessage))
          case None     => Future.successful(None)
        }
    }

    blobEventOptFuture.flatMap {
      case Some(_) => Future.successful(None)
      case None    =>
        val logMessage = blobEventIdOpt
          .map(blobEventId =>
            s"Received a blobErrorResponse from a remote connection: ${blobErrorResponseValue.errorMessage}. But could not find the referenced blob event by id `$blobEventId`. " +
              s"The remote connection `$relationKey`, the source issue key `${blobErrorResponseValue.sourceIssueKey}`"
          )
          .getOrElse(
            s"Received a blobErrorResponse from a remote connection: ${blobErrorResponseValue.errorMessage}. But could not find the referenced blob event by sync event `$syncEventId` and blob id $blobId. " +
              s"The remote connection `$relationKey`, the source issue key `${blobErrorResponseValue.sourceIssueKey}`"
          )
        LOG.debug(logMessage)
        Future.successful(None)
    }
  }

  /** Based on the ReceiveProtocol defines next Event status `NOTIFY_BLOB_RESPONSE_RECEIVED` or
    * `BLOB_ERROR_RESPONSE_READY`
    * @param syncEvent
    * @return
    */
  private def getNextStatus(syncEvent: ISyncEvent) = {
    val connection = syncEvent.getConnection
    val receiveProtocol = connection.getReceiveProtocol
    if (receiveProtocol == ReceiveProtocol.POLL) BlobEventStatus.NOTIFY_BLOB_RESPONSE_RECEIVED
    else BlobEventStatus.BLOB_ERROR_RESPONSE_READY
  }

  /** Handles error response:
    *   1. Defines next status, based on the sync event:
    *      BlobEventStatus.NOTIFY_BLOB_RESPONSE_RECEIVED or
    *      BlobEventStatus.BLOB_ERROR_RESPONSE_READY 2. sets error info to the blob event 3. updates
    *      blob event status and Error info in DB 4. then calls
    *      {@link IWorkerNotificationService.sendProcessBlobEventsNotification}
    *
    * @param blobErrorReason
    * @param errorResponseMessage
    * @param blobEventOpt
    * @return
    */
  private def handleErrorResponse(blobErrorReason: BlobErrorReason, errorResponseMessage: String)(
      blobEventOpt: Option[IBlobEvent]
  ): Future[Option[IBlobEvent]] = blobEventOpt match {
    case Some(blobEvent) =>
      val nextStatus = getNextStatus(blobEvent.getSyncEvent)
      blobEvent.setBlobErrorReason(blobErrorReason)
      blobEvent.setErrorResponseMessage(errorResponseMessage)

      blobEventReplicationRepository
        .updateBlobEventStatusAndErrorReasonAndErrorResponseMessage(blobEvent, nextStatus)
        .map { beOpt =>
          workerNotificationService.sendProcessBlobEventsNotification()
          beOpt
        }

    case None => Future.successful(None)
  }

}
