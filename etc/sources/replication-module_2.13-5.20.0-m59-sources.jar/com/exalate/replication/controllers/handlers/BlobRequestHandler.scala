package com.exalate.replication.controllers.handlers

import akka.stream.scaladsl.Source
import akka.util.ByteString
import com.exalate.api.domain.ExalateErrorReason
import com.exalate.api.domain.blob.request.{BlobRequestStatus, IBlobRequest}
import com.exalate.api.domain.connection.{IConnection, ReceiveProtocol, SendProtocol}
import com.exalate.api.persistence.relation.IRelationRepository
import com.exalate.api.persistence.replication.request.{
  ICreateBlobSyncRequestStateRepository,
  IRequestReplicationRepository,
  IUpdateBlobSyncRequestRepository
}
import com.exalate.domain.node.storeblob.StoredBlob
import com.exalate.error.services.api.IBugExceptionCategoryService
import com.exalate.replication.services.api.node.storeblob.IStoreBlobService
import com.exalate.replication.services.api.replication.worker.IWorkerNotificationService
import com.exalate.replication.services.transport.value.{
  BlobMetadataValue,
  BlobRequestValue,
  ErrorValue
}
import play.api.Logger

import javax.inject.{Inject, Singleton}
import scala.collection.JavaConverters
import scala.concurrent.{ExecutionContext, Future}

@Singleton
class BlobRequestHandler @Inject() (
    persistence: IRequestReplicationRepository,
    createBlobRepository: ICreateBlobSyncRequestStateRepository,
    updateBlobRepository: IUpdateBlobSyncRequestRepository,
    workerNotificationService: IWorkerNotificationService,
    relationRepository: IRelationRepository,
    storeBlobService: IStoreBlobService,
    bugExceptionCategoryService: IBugExceptionCategoryService
)(implicit ec: ExecutionContext) {

  val LOG: Logger = Logger("application.controllers.handlers.BlobRequestHandler")

  /** Handles blob request: If connection from blob request exists in DB, then register blob request
    * in DB and calls {@link IWorkerNotificationService.sendProcessBlobRequestsNotification}
    * otherwise return CONNECTION_NOT_FOUND
    * @param blobRequestValue
    * @return
    *   Either ErrorValue or None
    */
  def handleBlobRequest(
      blobRequestValue: BlobRequestValue
  ): Future[Either[ErrorValue, Option[IBlobRequest]]] = {
    val relationKey: String = blobRequestValue.relationKey
    val syncEventId: Int = blobRequestValue.syncEventId
    val blobRequestMetadata: BlobMetadataValue = blobRequestValue.blobMetadata

    relationRepository
      .getConnectionFuture(relationKey)
      .flatMap {
        case Some(connection) =>
          persistence
            .getSyncRequestByRemoteEventId(connection, syncEventId)
            .flatMap {
              // TODO: make it a for-comprehension
              _.map { syncRequest =>
                val blobMetadataSeq =
                  JavaConverters.asScalaBufferConverter(syncRequest.getBlobMetadataList).asScala
                (
                  blobMetadataSeq.find(_.getBlobId == blobRequestMetadata.getBlobId),
                  syncRequest
                )
              }
                .map {
                  case (Some(metadata), syncRequest) =>
                    val initialState = getNextStatus(connection)
                    val nonPersistentBlobRequestMetadata =
                      BlobMetadataValue.toNonPersistentBlobMetadata(blobRequestMetadata)
                    val blobRequestOptFuture: Future[Option[IBlobRequest]] =
                      createBlobRepository.createBlobRequest(
                        initialState,
                        nonPersistentBlobRequestMetadata,
                        metadata,
                        syncRequest,
                        blobRequestValue.blobEventId
                      )
                    blobRequestOptFuture
                      .foreach(_ => workerNotificationService.sendProcessBlobRequestsNotification())
                    blobRequestOptFuture
                  case (None, _)                     => Future.successful(None)
                }
                .getOrElse(Future.successful(None))
            }
            .map(brOpt => Right(brOpt))
        case None             =>
          Future.successful(
            Left(
              ErrorValue(
                ExalateErrorReason.CONNECTION_NOT_FOUND.name(),
                s"Connection `$relationKey` not found. Seems like it was removed on the Destination side."
              )
            )
          )
      }
  }

  /** Based on the ReceiveProtocol defines next Event status `NOTIFY_BLOB_REQUEST_RECEIVED` or
    * `WAITING_FOR_BLOB` or `READY`
    * @param connection
    * @return
    */
  private def getNextStatus(connection: IConnection): BlobRequestStatus = {
    val receiveProtocol = connection.getReceiveProtocol
    val sendProtocol = connection.getSendProtocol
    if (receiveProtocol == ReceiveProtocol.POLL) BlobRequestStatus.NOTIFY_BLOB_REQUEST_RECEIVED
    else if (
      connection.getRemoteInstance.getNodeInfo.isPollOnly || sendProtocol == SendProtocol.WAIT_FOR_POLL
    ) BlobRequestStatus.WAITING_FOR_BLOB
    else BlobRequestStatus.READY
  }

  /** Handles Receive Blob method, which is called when we publish blob. Storing file and updating
    * DB Blob Request Status And File Path BlobMetadata
    * @param blob
    * @param decodedRelationKey
    * @param remoteBlobEventId
    * @return
    *   None
    */
  def handleReceiveBlob(
      blob: Source[ByteString, _],
      decodedRelationKey: String,
      remoteBlobEventId: Int
  ): Future[None.type] =
    relationRepository
      .getConnectionFuture(decodedRelationKey)
      .flatMap {
        case Some(relation) =>
          persistence.getBlobRequestByRemoteBlobEventId(relation, remoteBlobEventId)
        case None           =>
          LOG.warn(
            s"Blob requests controller has received a message for receiving a blob " +
              s"which references a relation `$decodedRelationKey` and blob event id `$remoteBlobEventId`" +
              s" but the relation could not be found."
          )
          Future.successful(None)
      }
      .flatMap {
        case Some(blobRequest) =>
          storeBlobService
            .storeBlob(
              StoredBlob.generateIncomingBlobName(
                blobRequest.getSyncRequest.getConnection.getID,
                remoteBlobEventId
              ),
              blob
            )
            .flatMap(storedBlobMetaData => Future.successful(Some((blobRequest, storedBlobMetaData))))
            .recoverWith {
              case e =>
                LOG.error(
                  s"An error occurred while receiving a blob for remote blob event id `$remoteBlobEventId` and blob request id `${blobRequest.getId}`.",
                  e
                )
                Future.failed(e)
            }
        case None              =>
          LOG.warn(
            s"Blob requests controller has received a message for receiving a blob " +
              s"which references a relation `$decodedRelationKey` and blob event id `$remoteBlobEventId`" +
              s" but a related blob request could not be found."
          )
          Future.successful(None)
      }
      .flatMap {
        case Some((blobRequest, filePath)) =>
          val resultFuture = updateBlobRepository
            .updateBlobRequestStatusAndFilePathBlobMetadata(
              blobRequest,
              BlobRequestStatus.READY,
              filePath.filePath
            )
            .map(_ => None)
          resultFuture.foreach(_ => workerNotificationService.sendProcessBlobRequestsNotification())
          resultFuture
        case None                          =>
          val msg = s"Blob requests controller has received a message for receiving a blob " +
            s"which references a connection `$decodedRelationKey` and blob event id `$remoteBlobEventId`" +
            s" but a related blob request could not be found."
          val noBlobRequestBugException = bugExceptionCategoryService
            .generateNoBlobRequestBugException(decodedRelationKey, remoteBlobEventId)
          LOG.error(msg, noBlobRequestBugException)
          Future.failed(noBlobRequestBugException)
      }

}
