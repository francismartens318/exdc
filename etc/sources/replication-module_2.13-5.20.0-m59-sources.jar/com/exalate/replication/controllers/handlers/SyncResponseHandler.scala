package com.exalate.replication.controllers.handlers

import com.exalate.api.domain.SyncRequestEventType
import com.exalate.api.domain.connection.ReceiveProtocol
import com.exalate.api.domain.event.{EventStatus, ISyncEvent}
import com.exalate.api.domain.twintrace.INonPersistentTrace
import com.exalate.api.persistence.replication.event.{
  IEventReplicationRepository,
  IEventWaitingForResponseRepository
}
import com.exalate.basic.domain.BasicNonPersistentTrace
import com.exalate.replication.services.api.replication.worker.IWorkerNotificationService
import com.exalate.replication.services.api.transport.IReplicaValueHelper
import com.exalate.replication.services.transport.value.{SyncResponseValue, TraceValue}
import play.api.Logger

import javax.inject.{Inject, Singleton}
import scala.concurrent.{ExecutionContext, Future}
import scala.util.Failure

@Singleton
class SyncResponseHandler @Inject() (
    persistence: IEventReplicationRepository,
    waitingForResponseRepository: IEventWaitingForResponseRepository,
    replicaValueHelper: IReplicaValueHelper,
    workerNotificationService: IWorkerNotificationService
)(implicit ec: ExecutionContext) {

  private val LOG = Logger("application.controllers.handlers.SyncResponseHandler")

  def handleSyncResponse(responseValue: SyncResponseValue): Future[Option[ISyncEvent]] = {
    LOG.info(s"Received a sync response for sync event id `${responseValue.syncEventId}`")

    persistence
      .getSyncEvent(responseValue.syncEventId)
      .flatMap { syncEventOpt =>
        processSyncResponse(
          responseValue,
          syncEventOpt,
          TraceValue.toNonPersistentTraces(responseValue.traces)
        )
      }
  }

  /** Process Sync Response by calling {@link}
    * @param syncResponseValue
    * @param syncEventOpt
    * @param traces
    * @return
    */
  private def processSyncResponse(
      syncResponseValue: SyncResponseValue,
      syncEventOpt: Option[ISyncEvent],
      traces: Seq[INonPersistentTrace]
  ): Future[Option[ISyncEvent]] =
    syncEventOpt match {
      case None            =>
        LOG.warn(
          s"The sync event response resource has received a message, which references an event `${syncResponseValue.syncEventId}`. " +
            s"But the event is not found. Connection key - `${syncResponseValue.relationKey}`, source issue key - `${syncResponseValue.sourceIssueKey}`."
        )
        Future.successful(None)
      case Some(syncEvent) =>
        processResponseWhenEventFound(syncResponseValue, syncEvent, traces)
    }

  /** Process sync response if sync event was found, by calling {@link processSyncResponse}
    * @param syncResponseValue
    * @param syncEvent
    * @param traces
    * @return
    */
  private def processResponseWhenEventFound(
      syncResponseValue: SyncResponseValue,
      syncEvent: ISyncEvent,
      traces: Seq[INonPersistentTrace]
  ): Future[Option[ISyncEvent]] =
    // FIXME: it looks like in exalate components we are not checking this, check jiranode 9f381d68c512c84aff57e8459eac88b42424b3a7
    if (
      EventStatus.WAITING_FOR_RESPONSE != syncEvent.getStatus && EventStatus.SEND_REQUEST != syncEvent.getStatus
    ) {
      LOG.warn(
        s"The sync event response resource has received a message, which references an event `${syncResponseValue.syncEventId}`. " +
          s"But the event is not in the expected 'WAITING_FOR_RESPONSE' state. Connection key - `${syncResponseValue.relationKey}`, source issue key - `${syncResponseValue.sourceIssueKey}`."
      )
      Future.successful(Option(syncEvent))
    } else if (
      EventStatus.NOTIFY_RESPONSE_RECEIVED == syncEvent.getStatus || syncEvent.getRemoteReplica != null
    ) {
      LOG.warn(
        s"The sync event response resource has received a message, which references an event `${syncResponseValue.syncEventId}`. " +
          s"This event is already in 'NOTIFY_RESPONSE_RECEIVED' state, so it already got a sync response or the remote replica has been already set. " +
          s"Connection key - `${syncResponseValue.relationKey}`, source issue key - `${syncResponseValue.sourceIssueKey}`."
      )
      Future.successful(Option(syncEvent))
    } else {
      processSyncResponse(syncResponseValue, syncEvent, traces)
    }

  /** If replica from syncResponseValue exists, attach the received remote replica and traces to the
    * sync event and update the event's event state
    *
    * @param syncResponseValue
    * @param syncEvent
    * @param traces
    * @return
    */
  private def processSyncResponse(
      syncResponseValue: SyncResponseValue,
      syncEvent: ISyncEvent,
      traces: Seq[INonPersistentTrace]
  ): Future[Option[ISyncEvent]] = {
    val connection = syncEvent.getConnection
    val receiveProtocol = connection.getReceiveProtocol
    val nextEventStatus =
      if (Option(receiveProtocol).contains(ReceiveProtocol.POLL))
        EventStatus.NOTIFY_RESPONSE_RECEIVED
      else EventStatus.RESPONSE_READY
    val preparedTraces = prepareRemoteTraces(traces, syncEvent)
    val replicaTryOpt = syncResponseValue.replica.map(replicaValueHelper.toReplica(_, connection))
    val responseSyncType =
      syncResponseValue.syncType.map(SyncRequestEventType.getValue).getOrElse(syncEvent.getSyncType)

    replicaTryOpt match {
      case Some(Failure(e)) =>
        LOG.error(
          s"An error on constructing INonPersistentReplica from ReplicaValue ${syncResponseValue.replica
              .map(r => s"$r")
              .getOrElse("")}",
          e
        )
        Future.failed(e)
      case replicaOpt       =>
        waitingForResponseRepository
          .persistOnReceivingSyncResponse(
            syncEvent,
            nextEventStatus,
            replicaOpt.map(_.get),
            preparedTraces,
            syncResponseValue.twinTraceId,
            responseSyncType
          )
          .map { _ => workerNotificationService.sendProcessEventsNotification(); None }
    }
  }

  // Remote traces local id represents the remote id from the local perspective so we need to invert the ids
  private def prepareRemoteTraces(traces: Seq[INonPersistentTrace], syncEvent: ISyncEvent) =
    traces.map { t =>
      new BasicNonPersistentTrace()
        .from(t)
        .setLocalId(t.getRemoteId)
        .setRemoteId(t.getLocalId)
        .setEventId(syncEvent.getId);
    }

}
