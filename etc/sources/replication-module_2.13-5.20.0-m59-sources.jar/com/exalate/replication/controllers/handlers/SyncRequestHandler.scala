package com.exalate.replication.controllers.handlers

import com.exalate.api.domain.request.ISyncRequest
import com.exalate.api.domain.{ExalateErrorReason, SyncRequestEventType}
import com.exalate.api.persistence.relation.IRelationRepository
import com.exalate.basic.domain.license.SubscriptionContext
import com.exalate.basic.domain.{BasicIssueKey, NonPersistentConnectContext}
import com.exalate.replication.services.api.replication.in.IRequestSchedulerService
import com.exalate.replication.services.api.replication.worker.IWorkerNotificationService
import com.exalate.replication.services.api.transport.IReplicaValueHelper
import com.exalate.replication.services.transport.value.{
  BlobMetadataValue,
  ErrorValue,
  RequestValue,
  TraceValue
}
import org.slf4j.LoggerFactory

import javax.inject.{Inject, Singleton}
import scala.concurrent.{ExecutionContext, Future}

@Singleton
class SyncRequestHandler @Inject() (
    replicaValueHelper: IReplicaValueHelper,
    workerNotificationService: IWorkerNotificationService,
    requestSchedulerService: IRequestSchedulerService,
    relationRepository: IRelationRepository
)(implicit ec: ExecutionContext) {

  private val LOG = LoggerFactory.getLogger("application.controllers.handlers.SyncRequestHandler")

  /** Handles sync request value, by scheduling Sync Request and sending Process Requests
    * Notification
    * @param requestValue
    * @return
    */
  def handleSyncRequest(
      requestValue: RequestValue
  ): Future[Either[ErrorValue, Option[ISyncRequest]]] = {
    val requestsBlobMetadata =
      BlobMetadataValue.toNonPersistentBlobMetadataList(requestValue.blobMetadataList)
    val relationKey = requestValue.relationKey

    relationRepository.getConnectionFuture(relationKey).flatMap {
      case Some(connection) =>
        val remoteReplicaTry = replicaValueHelper.toReplica(requestValue.replica, connection)
        val syncedToIssueKey: Option[BasicIssueKey] = requestValue.syncedTo
          .map(s => new BasicIssueKey(s.getId, s.urn, s.entityType.getOrElse("issue")))
        val syncEventId = requestValue.syncEventId
        val syncEventNumber = requestValue.syncEventNumber
        LOG.info(
          s"Received a sync request for sync event id `$syncEventId` with number `$syncEventNumber`"
        )

        val subscriptionContext = requestValue.subscriptionContext
          .map(s => new SubscriptionContext(s.withNodeSubscription, s.withExalateSubscription))
          .getOrElse(new SubscriptionContext(false, false))
        val resultingRequestFuture = requestSchedulerService.scheduleSyncRequest(
          connection,
          remoteReplicaTry.get,
          syncedToIssueKey,
          requestsBlobMetadata,
          TraceValue.toNonPersistentTraces(requestValue.traces),
          syncEventId,
          syncEventNumber,
          requestValue.connectIssueUrn,
          requestValue.unexalateRemoteIssueUrn,
          requestValue.connectContext.map(c =>
            new NonPersistentConnectContext(
              c.synchronizeComments,
              c.synchronizeAttachments,
              c.synchronizeWorklogs,
              c.triggerSyncEvent,
              c.triggerUpdate.getOrElse(false),
              c.triggerUnexalate.getOrElse(false)
            )
          ),
          requestValue.deletedRemoteIssueUrn,
          requestValue.twinTraceId,
          requestValue.payed,
          subscriptionContext,
          requestValue.syncType.getOrElse(inferSyncRequestType(requestValue).name())
        )
        resultingRequestFuture.foreach {
          case None    =>
          case Some(_) => workerNotificationService.sendProcessRequestsNotification()
        }
        resultingRequestFuture.map(sr => Right(sr))
      case None             =>
        Future.successful(
          Left(
            ErrorValue(
              ExalateErrorReason.CONNECTION_NOT_FOUND.name(),
              s"Connection `$relationKey` not found. Seems like it was removed on the Destination side."
            )
          )
        )
    }
  }

  private def inferSyncRequestType(requestValue: RequestValue): SyncRequestEventType =
    if (requestValue.connectIssueUrn.isDefined) {
      SyncRequestEventType.CONNECT
    } else if (requestValue.deletedRemoteIssueUrn.isDefined) {
      SyncRequestEventType.DELETE
    } else if (requestValue.syncEventNumber == 1 && requestValue.syncedTo.isEmpty) {
      SyncRequestEventType.EXALATE
    } else if (requestValue.unexalateRemoteIssueUrn.isDefined) {
      SyncRequestEventType.UNEXALATE
    } else {
      SyncRequestEventType.UPDATE
    }

}
