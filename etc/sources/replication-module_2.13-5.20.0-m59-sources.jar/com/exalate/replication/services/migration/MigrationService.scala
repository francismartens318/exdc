package com.exalate.replication.services.migration

import cats.data.OptionT
import com.exalate.api.domain.license.{IPersistentLicense, PaymentModel}
import com.exalate.api.persistence.instance.IInstanceRepository
import com.exalate.api.persistence.license.ILicenseRepository
import com.exalate.clients.GrpcClient
import com.exalate.proto.licensing._
import com.exalate.persistence.domain.v1.license.AssignedLicenseAllFields
import com.exalate.replication.services.api.config.IGeneralSettingsService
import com.google.inject.Inject
import play.api.Logger

import scala.concurrent.{ExecutionContext, Future}

class MigrationService @Inject() (
    val generalSettingsService: IGeneralSettingsService,
    licenseRepository: ILicenseRepository,
    instanceRepository: IInstanceRepository,
    grpcClient: GrpcClient
)(implicit val ec: ExecutionContext) {

  private val LOG = Logger(classOf[MigrationService])

  /** Migrate specified service to microservice
    * @return
    *   \- licenseId
    */
  def migrate(service: String): Future[Option[String]] =
    service match {
      case Service.License.value => migrateLicenseToService
      case _ => throw new IllegalArgumentException(s"Unknown service for migration: $service")
    }

  /** Migrate specified service from microservice to monolith
    *
    * @return
    *   \- licenseId
    */
  def migrateRollback(service: String): Future[Option[String]] =
    service match {
      case Service.License.value => rollbackFromService
      case _                     =>
        throw new IllegalArgumentException(s"Unknown service for rollback migration: $service")
    }

  private def migrateLicenseToService: Future[Option[String]] =
    for {
      trackerUrlOpt <- generalSettingsService.get.map(_.map(_.getIssueTrackerUrl))
      licenseOpt <- licenseRepository.getLicense()
      assignedLicenses <- licenseRepository
        .getAllUsages()
        .map(
          _.map(AssignedLicenseAllFields.tupled(_))
        )
      result <- (trackerUrlOpt, licenseOpt) match {
        case (Some(trackerUrl), Some(license)) =>
          invokeLicenseMigrationToService(assignedLicenses, trackerUrl, license)
        case (Some(_), None)                   =>
          LOG.debug("No license found for migration")
          Future.successful(None)
        case (_, _) => Future.failed(new Exception("Not enough data to migrate"))
      }
    } yield result

  private def invokeLicenseMigrationToService(
      assignedLicenses: Seq[AssignedLicenseAllFields],
      trackerUrl: String,
      license: IPersistentLicense
  ): Future[Option[String]] =
    for {
      assignedLicensesWithInstanceUId <- Future.sequence(
        assignedLicenses
          .map { l =>
            getRemoteInstanceUId(l.instanceId).map(remoteInstanceUid =>
              AssignedLicenseMessage(
                remoteInstanceUid,
                PaymentModelMessage.fromValue(PaymentModel.valueOf(l.paymentModel).getNumber)
              )
            )
          }
      )
      response <- grpcClient.licenseService
        .migrate(
          LicenseMigrateRequest(
            Option(
              SaveLicenseRequest(
                None,
                license.getPayload,
                trackerUrl
              )
            ),
            assignedLicensesWithInstanceUId
          )
        )
    } yield Option(response.licenseId)

  private def rollbackFromService: Future[Option[String]] =
    (for {
      licenseProto <- invokeLicenseMigrationRollbackFromService()
      saved <- OptionT.liftF(licenseRepository.saveLicense(licenseProto.payload))
      assignedUsages <- OptionT.liftF(convertAssignedLicenses(licenseProto))
      _ <- OptionT.liftF(licenseRepository.updateAllUsages(assignedUsages))
    } yield saved.getId.toString).value

  /** convert proto assigned licenses to tuple of remote instanceId and payment model
    * @param licenseProto
    *   proto license
    * @return
    *   Future seq of tuples
    */
  private def convertAssignedLicenses(
      licenseProto: ExalateLicenseMessage
  ): Future[Seq[(String, PaymentModel)]] =
    Future.sequence(
      licenseProto.assignedLicenses
        .map { l =>
          for {
            remoteInstanceId <- getRemoteInstanceId(l.remoteInstanceUId)
            paymentModel = PaymentModel.valueOf(l.paymentModel.name)
          } yield (remoteInstanceId.toString, paymentModel)
        }
    )

  private def invokeLicenseMigrationRollbackFromService(): OptionT[Future, ExalateLicenseMessage] =
    OptionT(
      grpcClient.licenseService
        .migrationRollback(EmptyRequest())
        .map(_.exalateLicense)
    )

  private def getRemoteInstanceUId(instanceId: Int): Future[String] =
    instanceRepository
      .getRemoteInstanceUId(instanceId)
      .map(_.getOrElse(throw new Exception(s"Instance with id $instanceId not found")))

  private def getRemoteInstanceId(remoteInstanceUId: String): Future[Int] =
    instanceRepository
      .getRemoteInstanceId(remoteInstanceUId)
      .map(_.getOrElse(throw new Exception(s"Instance with uid $remoteInstanceUId not found")))

}

sealed abstract class Service(val value: String)

object Service {
  final case object License extends Service(value = "license")
}
