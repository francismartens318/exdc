package com.exalate.replication.services.hubobject

import com.exalate.api.domain.{IBlobMetadata, INonPersistentReplica}
import com.exalate.api.domain.hubobject.v1_3.IHubIssue
import com.exalate.api.domain.twintrace.{ITrace, TraceType}
import com.exalate.replication.services.api.hubobject.IBlobMetadataService

import scala.jdk.CollectionConverters._

class BlobMetadataService extends IBlobMetadataService {

  /** Gets ids of new added blobs
    * @param replica
    *   INonPersistentReplica
    * @param traces
    *   seq of traces
    * @param existingMetadata
    *   seq of blob meta data
    * @return
    *   seq of blob ids as string
    */
  def getAddedBlobIds(
      replica: INonPersistentReplica,
      traces: Seq[ITrace],
      existingMetadata: Seq[IBlobMetadata]
  ): Seq[String] = {
    val hubIssue = replica.getPayload.getHubIssue.asInstanceOf[IHubIssue]
    val newAttachments = hubIssue.getAttachments.asScala.toList.filter { a =>
      !traces.exists { t =>
        t.getType == TraceType.ATTACHMENT && t.getLocalId != null && t.getLocalId == a.getIdStr
      } &&
      !existingMetadata.exists { bmd =>
        bmd.getBlobId != null && bmd.getBlobId == a.getIdStr
      }
    }
    newAttachments.map(a => a.getIdStr)
  }

}
