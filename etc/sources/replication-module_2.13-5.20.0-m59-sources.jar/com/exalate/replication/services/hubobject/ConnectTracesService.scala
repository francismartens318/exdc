package com.exalate.replication.services.hubobject

import com.exalate.api.domain.INonPersistentConnectContext
import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.hubobject.IHubIssueReplica
import com.exalate.api.domain.twintrace.{INonPersistentTrace, TraceAction, TraceType}
import com.exalate.basic.domain
import com.exalate.replication.services.api.hubobject.IConnectTracesService

import javax.annotation.Nonnull
import scala.jdk.CollectionConverters._

class ConnectTracesService extends IConnectTracesService {

  /** Gets connected traces, namely comment, attachment & worlog traces
    * @param localReplica
    *   local HubIssueReplica
    * @param connectContextOpt
    * @param relation
    *   connection
    * @return
    *   Seq[INonPersistentTrace]
    */
  override def getConnectTraces(
      @Nonnull localReplica: IHubIssueReplica,
      @Nonnull connectContextOpt: Option[INonPersistentConnectContext],
      @Nonnull relation: IConnection
  ): Seq[INonPersistentTrace] = {
    val commentTraces =
      if (connectContextOpt.exists(!_.isSynchronizeComments)) getConnectCommentTraces(localReplica)
      else Nil
    val attachmentTraces =
      if (connectContextOpt.exists(!_.isSynchronizeAttachments))
        getConnectAttachmentTraces(localReplica)
      else Nil
    val worklogTraces =
      if (connectContextOpt.exists(!_.isSynchronizeWorklogs)) getConnectWorklogTraces(localReplica)
      else Nil
    commentTraces ++ attachmentTraces ++ worklogTraces
  }

  /** Gets Connected Comment Traces
    * @param localReplica
    *   local hub issue
    * @return
    *   Seq[INonPersistentTrace]
    */
  private def getConnectCommentTraces(localReplica: IHubIssueReplica): Seq[INonPersistentTrace] =
    localReplica.getComments.asScala.map { c =>
      new domain.BasicNonPersistentTrace()
        .setType(TraceType.COMMENT)
        .setLocalId(c.getIdStr)
        .setAction(TraceAction.NONE)
        .setToSynchronize(false)
    }.toSeq

  /** Gets Connected worklog Traces
    * @param localReplica
    *   local hub issue
    * @return
    *   Seq[INonPersistentTrace]
    */
  private def getConnectWorklogTraces(localReplica: IHubIssueReplica): Seq[INonPersistentTrace] =
    localReplica.getWorkLogs.asScala.map { c =>
      new domain.BasicNonPersistentTrace()
        .setType(TraceType.WORKLOG)
        .setLocalId(c.getIdStr)
        .setAction(TraceAction.NONE)
        .setToSynchronize(false)
    }.toSeq

  /** Gets Connected attachment Traces
    * @param localReplica
    *   local hub issue
    * @return
    *   Seq[INonPersistentTrace]
    */
  private def getConnectAttachmentTraces(localReplica: IHubIssueReplica): Seq[INonPersistentTrace] =
    localReplica.getAttachments.asScala.map { a =>
      new domain.BasicNonPersistentTrace()
        .setType(TraceType.ATTACHMENT)
        .setLocalId(a.getIdStr)
        .setAction(TraceAction.NONE)
        .setToSynchronize(false)
    }.toSeq

}
