package com.exalate.replication.services.hubobject

import com.exalate.api.domain.hubobject.v1_14.IHubIssue
import com.exalate.api.domain.hubobject.{IHubIssuePayload, IHubPayload, ISemanticVersion}
import com.exalate.api.domain.{IIssueKey, INonPersistentReplica, IPersistentReplica}
import com.exalate.api.exception.IssueTrackerException
import com.exalate.api.hubobject.v1.IHubObjectConversionService
import com.exalate.basic.domain.{
  BasicHubIssuePayload,
  BasicHubPayload,
  BasicSemanticVersion,
  NonPersistentReplica
}
import com.exalate.replication.services.api.hubobject.IReplicaHelper
import com.google.inject.Inject
import org.slf4j.LoggerFactory
import play.api.Logger
import play.api.data.validation.ValidationError
import play.api.libs.json._

import scala.util.{Failure, Success, Try}

class ReplicaHelper @Inject() (converter: IHubObjectConversionService) extends IReplicaHelper {

  val LOG = LoggerFactory.getLogger("application.services.hubobject.ReplicaHelper")

  /** Helps to create non persistent replica with provided data
    * @param issueKey
    * @param summary
    * @param payload
    * @return
    *   INonPersistentReplica
    */
  def createNonPersistentReplica(
      issueKey: IIssueKey,
      summary: Option[String],
      payload: IHubPayload
  ): INonPersistentReplica =
    new NonPersistentReplica(issueKey, summary.orNull, payload, computePayloadString(payload))

  /** Converts payload to string
    * @param payload
    * @return
    */
  private def computePayloadString(payload: IHubPayload): String = {
    import Implicits.Writes._

    Json.stringify(Json.toJson(payload))
  }

  /** Checks 2 replicas, new & old one, whether there were some changes
    * @param prevReplica
    * @param newReplica
    * @return
    *   true or false
    */
  override def hasChanges(
      prevReplica: IPersistentReplica,
      newReplica: INonPersistentReplica
  ): Boolean = {
    val oldJson = Json.parse(prevReplica.getPayload)
    val newJson = Json.parse(newReplica.getPayloadAsString)
    val different = !oldJson.equals(newJson)
    LOG.debug(
      s"#hasChanges oldJson=`${oldJson.toString()}` prevReplica=`${newJson.toString()}` different=$different"
    )
    different
  }

  /** Converts persistent replica to Non persistent replica
    * @param replica
    *   persistent replica
    * @return
    *   Non persistent replica
    */
  override def toNonPersistentReplica(replica: IPersistentReplica): INonPersistentReplica = {
    val payloadStr = replica.getPayload
    val hubPayLoad: IHubPayload = toHubPayload(payloadStr)
      // TODO: Deal with the error parsing case
      .get

    new NonPersistentReplica(
      replica.getIssueKey,
      Option(replica.getSummary).map(_.toExternalForm).orNull,
      hubPayLoad,
      payloadStr
    )
  }

  /** Parses payload string to hub payload
    * @param payloadStr
    *   payload as string
    * @return
    *   Try[IHubPayload]
    */
  override def toHubPayload(payloadStr: String): Try[IHubPayload] = {
    import Implicits.Reads._
    val payloadJson = Json.parse(payloadStr)

    payloadJson.validate[IHubPayload](IHubPayloadRead) match {
      case JsError(errors)          =>
        LOG.error(s"Error converting json str to hub payload: $errors")
        Failure(new IssueTrackerException(errors.mkString(",")))
      case JsSuccess(hubPayload, _) =>
        Success(hubPayload)
    }
  }

  override def toHubIssuePayload(payloadStr: String): Try[IHubIssuePayload] = {
    import Implicits.Reads._
    val payloadJson = Json.parse(payloadStr)

    payloadJson.validate[IHubIssuePayload](IHubIssuePayloadRead) match {
      case JsError(errors)          =>
        LOG.error(s"Error converting json str to hub payload: $errors")
        Failure(new IssueTrackerException(errors.mkString(",")))
      case JsSuccess(hubPayload, _) =>
        Success(hubPayload)
    }
  }

  object Implicits {

    object Writes {

      implicit lazy val hubIssueWrites: Writes[IHubIssue] = (o: IHubIssue) =>
        Json.parse(converter.toVersion1JsonString(o))

      implicit lazy val semanticVersionWrites: Writes[ISemanticVersion] = (o: ISemanticVersion) =>
        Json.obj(
          "major" -> o.getMajor,
          "minor" -> o.getMinor,
          "patch" -> o.getPatch
        )

      implicit lazy val payloadWrites: Writes[IHubPayload] = (o: IHubPayload) =>
        Option(o.getIssueUrl) match {
          case Some(issueUrl) =>
            Json.obj(
              "version" -> o.getVersion,
              "hubIssue" -> o.getHubIssue.asInstanceOf[IHubIssue],
              "issueUrl" -> issueUrl
            )
          case None           =>
            Json.obj(
              "version" -> o.getVersion,
              "hubIssue" -> o.getHubIssue.asInstanceOf[IHubIssue]
            )
        }

    }

    object Reads {

      implicit object IHubIssueV1Read extends Reads[V1HubIssue] {

        def reads(json: JsValue): JsResult[V1HubIssue] =
          JsSuccess(V1HubIssue(converter.toHubIssueFromVersion1Json(json.toString())))

      }

      implicit object ISemanticVersionRead extends Reads[ISemanticVersion] {

        def reads(json: JsValue): JsResult[ISemanticVersion] = JsSuccess(
          new BasicSemanticVersion(
            (json \ "major").as[Long],
            (json \ "minor").as[Long],
            (json \ "patch").as[Long]
          )
        )

      }

      implicit object IHubPayloadRead extends Reads[IHubPayload] {

        def reads(json: JsValue): JsResult[IHubPayload] = {
          val hubObjVersionResult: JsResult[ISemanticVersion] =
            (json \ "version").validate[ISemanticVersion]
          hubObjVersionResult match {
            case JsSuccess(v1, _) if v1.getMajor == 1 =>
              JsSuccess((json \ "issueUrl").asOpt[String] match {
                case Some(issueUrl) =>
                  new BasicHubPayload(
                    v1,
                    (json \ "hubIssue").as[V1HubIssue].issue,
                    issueUrl
                  )
                case None => new BasicHubPayload(v1, (json \ "hubIssue").as[V1HubIssue].issue)
              })
            case JsSuccess(unsupportedVersion, path)  =>
              val message: String =
                s"Unsupported Hub Objects version `$unsupportedVersion` of the payload `$json` - can not read it"
              JsError(path, message)
            case e: JsError                           =>
              e
          }
        }

      }

      implicit object IHubIssuePayloadRead extends Reads[IHubIssuePayload] {

        def reads(json: JsValue): JsResult[IHubIssuePayload] =
          (json \ "hubIssue").validate[V1HubIssue] match {
            case JsSuccess(v1HubIssue, _) =>
              JsSuccess(
                new BasicHubIssuePayload(
                  v1HubIssue.issue
                )
              )
            case e: JsError               =>
              e
          }

      }

    }

  }

  case class V1HubIssue(issue: IHubIssue)

  case class JsonErrors(errors: Seq[(JsPath, Seq[JsonValidationError])]) extends Exception

}
