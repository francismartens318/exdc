package com.exalate.replication.services.editor

import com.exalate.api.ILoggingService
import com.exalate.api.domain.connection.IConnection
import com.exalate.api.exception.bug.BugException
import com.exalate.api.persistence.issuetracker.IIssueTrackerOptionRepository
import com.exalate.domain.editor.FieldDataType
import com.exalate.domain.transport.trackeroptions.IssueTrackerOptionContextOps.filterOptions
import com.exalate.domain.transport.trackeroptions._
import com.exalate.domain.values.{EditorFieldValue, NodeInfoValue, PageRequest}
import com.exalate.replication.services.api.editor.{IEditorCustomFieldService, IOptionsService}
import com.exalate.replication.services.api.issuetracker.ITrackerOptionService
import com.exalate.replication.services.issuetracker.InstanceEditorFieldService
import com.exalate.replication.services.transport.v1.rest.NodeInfoProvider
import com.exalate.replication.services.transport.value.helpers.{
  EditorFieldValueHelper,
  NodeInfoValueHelper
}
import com.exalate.services.utils.pagination.{Page, PaginationUtil}
import com.google.inject.Inject

import scala.concurrent.{ExecutionContext, Future}

/** The service, which extract remote and local option for the provided field, and helps with
  * autocomplete on UI
  */
class OptionsService @Inject() (
    trackerOptionService: ITrackerOptionService,
    instanceEditorFieldService: InstanceEditorFieldService,
    loggingService: ILoggingService,
    issueTrackerOptionRepository: IIssueTrackerOptionRepository,
    nodeInfoProvider: NodeInfoProvider,
    editorCustomFieldService: IEditorCustomFieldService,
    implicit val executionContext: ExecutionContext
) extends IOptionsService {

  val PROJECT_FIELD: String = EditorFields.PROJECT.toString
  val ISSUE_TYPE_FIELD: String = EditorFields.ISSUE_TYPE.toString
  val PRIORITY_FIELD: String = EditorFields.PRIORITY.toString
  val STATUS_FIELD: String = EditorFields.STATUS.toString

  /** Firstly extracts context for provided queryParams from node info and then calls
    * {@link getLocalOptionsForAutocompleteWithContext()}
    * @param key
    * @param query
    * @param limit
    * @param offset
    * @param queryParams
    * @return
    */
  def getLocalOptionsForAutocomplete(
      key: String,
      query: Option[String],
      limit: Option[Int],
      offset: Option[Int],
      queryParams: Map[String, Seq[String]],
      userKey: Option[String]
  ): Future[IssueTrackerOptionsForAutocomplete] =
    nodeInfoProvider.get.flatMap { ni =>
      val issueTrackerOptionContext = getIssueTrackerOptionContext(queryParams, ni, Nil)
      getLocalOptionsForAutocompleteWithContext(
        key,
        query,
        limit,
        offset,
        issueTrackerOptionContext,
        userKey
      )
    }

  /** Searches for options on the local instance for the requested field (key) by calling
    * {@link com.exalate.replication.services.api.issuetracker.ITrackerOptionService} }. The field
    * could be one of the following: PROJECT, ISSUE_TYPE, PRIORITY, STATUS and CF
    * @param key
    *   \- key of the target field. String of EditorFields value
    * @param query
    *   \- query obtained from the request
    * @param limit
    *   \- number of values that should be returned
    * @param offset
    * @param context
    *   \- context which consists of Project keys, Issue types etc. where target field may belong
    * @return
    *   IssueTrackerOptionsForAutocomplete(query: Option[String], total: Int, offset: Option[Int],
    *   limit: Option[Int], results: Seq[IssueTrackerOptionValue])
    */
  def getLocalOptionsForAutocompleteWithContext(
      key: String,
      query: Option[String],
      limit: Option[Int],
      offset: Option[Int],
      context: Option[Seq[IssueTrackerOptionDependency]],
      userKey: Option[String]
  ): Future[IssueTrackerOptionsForAutocomplete] = {
    val pageRequest = com.exalate.services.utils.pagination
      .PageRequest(offset.map(_.toLong).getOrElse(0), limit.getOrElse(10))

    def _find(
        stream: Stream[Future[Page[IssueTrackerOption]]]
    ): Future[IssueTrackerOptionsForAutocomplete] =
      PaginationUtil
        .filterInfStreamIntoPage[IssueTrackerOption, Page[IssueTrackerOption]](stream)(
          pageRequest,
          opt => filterOptions(Seq(opt), query, context).nonEmpty
        )
        .map(p =>
          IssueTrackerOptionsForAutocomplete(
            query,
            p.total.toInt,
            Some(pageRequest.offset.toInt),
            Some(pageRequest.limit),
            p.results.map(EditorOptionsValueHelper.toIssueTrackerOptionValue)
          )
        )

    key match {
      case PROJECT_FIELD    =>
        _find(trackerOptionService.fetchProjectOptionsStream(userKey = userKey))
      case ISSUE_TYPE_FIELD =>
        _find(trackerOptionService.fetchIssuetypeOptions(context))

      case PRIORITY_FIELD =>
        _find(trackerOptionService.fetchPriorityOptions(context))
      case STATUS_FIELD   =>
        _find(trackerOptionService.fetchStatusOptions(context))
      // TODO: there is not a value for implementation for resolution
      case _              =>
        instanceEditorFieldService
          .getLocalEditorFieldValues()
          .flatMap(fs =>
            fs.find(_.key == key) match {
              case Some(f) if f.`type`.key == FieldDataType.OPTION.toString =>
                _find(trackerOptionService.fetchCustomFieldOptions(f, context))
              case _                                                        =>
                loggingService.warn(
                  s"#getLocalOptionsForAutocompleteWithContext attempted to find options for non-OPTION custom field $key"
                )
                Future.successful(
                  IssueTrackerOptionsForAutocomplete(
                    query,
                    0,
                    Some(pageRequest.offset.toInt),
                    Some(pageRequest.limit),
                    Nil
                  )
                )
            }
          )
    }

  }

  /** Depending on the connection type (local or not) extracts context for provided queryParams from
    * node info and then calls {@link getLocalOptionsForAutocompleteWithContext()} or
    * {@link getRemoteOptionsForAutocompleteWithContext()}
    * @param key
    * @param connection
    * @param query
    * @param limit
    * @param offset
    * @param queryParams
    * @return
    */
  def getRemoteOptionsForAutocomplete(
      key: String,
      connection: IConnection,
      query: Option[String],
      limit: Option[Int],
      offset: Option[Int],
      queryParams: Map[String, Seq[String]]
  ): Future[IssueTrackerOptionsForAutocomplete] =
    if (connection.isLocal) {
      for {
        ni <- nodeInfoProvider.get
        customFields <- editorCustomFieldService.getCustomFieldValues()
        issueTrackerOptionContext = getIssueTrackerOptionContext(queryParams, ni, customFields)
        r <- getLocalOptionsForAutocompleteWithContext(
          key,
          query,
          limit,
          offset,
          issueTrackerOptionContext,
          None
        )
      } yield r
    } else {
      for {
        ni <- Future.successful(connection.getRemoteInstance.getNodeInfo)
        niv = NodeInfoValueHelper.toNodeInfoValue(ni)
        customFields =
          if (connection.getRemoteInstance.getCustomFieldValues != null) {
            EditorFieldValueHelper.toEditorFieldValueSeq(
              connection.getRemoteInstance.getCustomFieldValues
            )
          } else {
            Seq.empty
          }
        issueTrackerOptionContext = getIssueTrackerOptionContext(queryParams, niv, customFields)
        r <- getRemoteOptionsForAutocompleteWithContext(
          key,
          connection,
          query,
          limit,
          offset,
          issueTrackerOptionContext
        )
      } yield r
    }

  /** Based on key of target field, instanceUid extracted from connection and provided query
    * searches for options in DB namely IssueTrackerOptionTable
    *
    * @param key
    * @param connection
    * @param query
    * @param limit
    * @param offset
    * @param context
    * @return
    */
  def getRemoteOptionsForAutocompleteWithContext(
      key: String,
      connection: IConnection,
      query: Option[String],
      limit: Option[Int],
      offset: Option[Int],
      context: Option[Seq[IssueTrackerOptionDependency]]
  ): Future[IssueTrackerOptionsForAutocomplete] = {
    val connectionId = connection.getID
    Option(connection.getRemoteInstance)
      .flatMap(i => Option(i.getNodeInfo))
      .flatMap(ni => Option(ni.getInstanceUid)) match {
      case None              =>
        loggingService.error(
          s"Got a request to get remote options for field `$key` for connection id `$connectionId`, but connection does not have node info with an instance UID."
        )
        Future.failed(
          new BugException(
            s"Connection `${connection.getName}` ($connectionId) can not be identified. Please contact Exalate Support!"
          )
        )
      case Some(instanceUid) =>
        issueTrackerOptionRepository.find(instanceUid, key, query, PageRequest.ALL).map { result =>
          val results = filterOptions(result.results, None, context)
          val resultsPaged = PaginationUtil
            .applyPagination(results, offset, limit)
            .map(EditorOptionsValueHelper.toIssueTrackerOptionValue)

          IssueTrackerOptionsForAutocomplete(query, results.length, offset, limit, resultsPaged)
        }
    }
  }

  /** Based on provided queryParams and editor Fields extracted from NodeInfoValue, forms seq of
    * IssueTrackerOptionDependency
    * @param queryParams
    * @param nodeInfo
    * @param customFields
    * @return
    */
  def getIssueTrackerOptionContext(
      queryParams: Map[String, Seq[String]],
      nodeInfo: NodeInfoValue,
      customFields: Seq[EditorFieldValue]
  ): Option[Seq[IssueTrackerOptionDependency]] =
    for {
      e <- nodeInfo.editor
      itFields = e.editorFields ++ customFields
      r <- queryParams.foldLeft(Option.empty[Seq[IssueTrackerOptionDependency]]) {
        case (res, (queryParamKey, queryParamValues)) =>
          val deps = itFields
            .find(f => f.key.equals(queryParamKey.toUpperCase))
            .toSeq
            .flatMap(itf =>
              queryParamValues.map(qpv => IssueTrackerOptionDependency(itf.key, Some(qpv)))
            )
          res match {
            case None               => Some(deps)
            case Some(dependencies) => Some(dependencies ++ deps)
          }
      }
    } yield r

}
