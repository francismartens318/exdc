package com.exalate.replication.services.editor

import com.exalate.api.ILoggingService
import com.exalate.api.domain.connection.fieldvalues.ConnectionMode
import com.exalate.api.domain.connection.{IConnection, InvitationStatus}
import com.exalate.api.domain.editor.mappings.RecoveryType
import com.exalate.api.exception.bug.BugException
import com.exalate.api.persistence.issuetracker.IIssueTrackerOptionRepository
import com.exalate.domain.editor.FieldDataType
import com.exalate.domain.editor.mappings._
import com.exalate.domain.editor.scopes.ScopeValue
import com.exalate.domain.transport.trackeroptions.EditorFields._
import com.exalate.domain.transport.trackeroptions.{
  EditorFields,
  IssueTrackerOption,
  IssueTrackerOptionContextOps,
  IssueTrackerOptionDependency,
  IssueTrackerOptionDependencyCombo
}
import com.exalate.domain.ObjectJsonFormatters._
import com.exalate.domain.values._
import com.exalate.replication.services.api.editor.{
  IEditorCustomFieldService,
  IEditorParamsService,
  IOptionsService
}
import com.exalate.replication.services.api.issuetracker.{
  IIssueTrackerBasicNonEditorValueService,
  ITrackerOptionService
}
import com.exalate.replication.services.transport.v1.rest.{INodeInfoClient, NodeInfoProvider}
import com.exalate.replication.services.transport.value.helpers.{
  EditorFieldValueHelper,
  NodeInfoValueHelper
}
import com.exalate.services.utils.pagination.{Page, PaginationUtil}
import com.exalate.services.utils.{pagination, FutureUtils}
import com.google.inject.Inject
import play.api.libs.json._

import scala.concurrent.{ExecutionContext, Future}

class EditorParamsService @Inject() (
    loggingService: ILoggingService,
    nodeInfoProvider: NodeInfoProvider,
    nodeInfoClient: INodeInfoClient,
    editorCustomFieldService: IEditorCustomFieldService,
    trackerOptionService: ITrackerOptionService,
    issueTrackerOptionRepository: IIssueTrackerOptionRepository,
    optionsService: IOptionsService,
    issueTrackerBasicNonEditorValueService: IIssueTrackerBasicNonEditorValueService
)(implicit val executionContext: ExecutionContext)
    extends IEditorParamsService {

  case class SuggestionContext(
      connection: IConnection,
      localNodeInfo: NodeInfoValue,
      remoteNodeInfo: NodeInfoValue,
      localContext: Seq[
        com.exalate.domain.transport.trackeroptions.IssueTrackerOptionDependencyCombo
      ],
      remoteContext: Seq[
        com.exalate.domain.transport.trackeroptions.IssueTrackerOptionDependencyCombo
      ]
  )

  type InstanceUid = String

  /** Build supported scope params for visual editor
    * @param connection
    * @return
    *   JsValue which looks like: { JsValue obtained from {@link buildLocalScopeParams()} , //
    *   "local": {....} JsValue obtained from {@link buildRemoteScopeParams()} , // "remote": {....}
    *   }
    */
  override def getScopeParamsValue(connection: IConnection): Future[Option[ScopeParamsValue]] = {
    val localRemoteScopeParams = for {
      localScopeParamsJson <- buildLocalScopeParams()
      remoteScopeParamsJson <-
        if (connection.isBasic) Future.successful(None) else buildRemoteScopeParams(connection)
    } yield (localScopeParamsJson, remoteScopeParamsJson)

    localRemoteScopeParams.map {
      case (Some(localParams), rpOpt @ _) => Some(ScopeParamsValue(localParams, rpOpt))
      case _                              => None
    }
  }

  /** Build supported mapping params for visual editor
    *
    * @param connection
    * @return
    *   JsValue which looks like: { JsValue obtained from {@link buildLocalMappingParams( )} , //
    *   "local": {....} JsValue obtained from {@link buildRemoteMappingParams( )} , // "remote":
    *   {....} }
    */
  override def getMappingsParamsValue(
      connection: IConnection
  ): Future[Option[MappingsParamsValue]] = {
    val localRemoteMappingParams = for {
      localMappingParamsJson <- buildLocalMappingParams()
      remoteMappingParamsJson <-
        if (connection.isBasic) Future.successful(None) else buildRemoteMappingParams(connection)
    } yield (localMappingParamsJson, remoteMappingParamsJson)

    localRemoteMappingParams.map {
      case (Some(localParams), rpOpt @ _) => Some(MappingsParamsValue(localParams, rpOpt))
      case _                              => None
    }
  }

  /** Builds suggestion for mapping rules which user can seen just after Scopes are selected and
    * navigated to the rules tab. Suggestion is build based on the list of fields obtained from
    * nodeInfoValue.editor and options for each of the fields is choosed based on scope
    *
    * @param connection
    * @param scopeValueOptSeq
    *   \- seq of scopes that were selected on UI by user
    * @return
    *   JsValue which looks like: { "mappings":[ { "local" : { }, "arrow":"LR", "remote": { },
    *   "type":"MAPPING" },// {@link com.exalate.domain.editor.mappings.MappingValue} {
    *   {@link com.exalate.domain.editor.mappings.MappingValue} }, {
    *   {@link com.exalate.domain.editor.mappings.MappingValue} } ] }
    */
  override def getMappingsSuggestions(
      connection: IConnection,
      scopeValueOptSeq: Seq[ScopeValue],
      previousConnectionMode: Option[String]
  ): Future[Option[MappingsSuggestionValue]] =
    getMappingsValueForSuggestions(connection, scopeValueOptSeq, previousConnectionMode).map(
      _.map(msv => MappingsSuggestionValue(msv))
    )

  def getMappingsValueForSuggestions(
      connection: IConnection,
      scopeValueOptSeq: Seq[ScopeValue],
      previousConnectionMode: Option[String]
  ): Future[Option[Seq[MappingValue]]] = {
    val localContext = scopeValueOptSeq.map { sV =>
      val itod = sV.local.mainFields
        .map(mF =>
          IssueTrackerOptionDependency(
            mF.key,
            mF.value.flatMap { o =>
              Json
                .toJson(o)
                .asOpt[Map[String, Object]]
                .flatMap(_.get("value"))
                .map(_.asInstanceOf[String])
            }
          )
        )
        .toSet

      IssueTrackerOptionDependencyCombo(itod)
    }

    val remoteContext = scopeValueOptSeq.map { sV =>
      val itod = sV.remote.mainFields
        .map(mF =>
          IssueTrackerOptionDependency(
            mF.key,
            mF.value.flatMap { o =>
              Json
                .toJson(o)
                .asOpt[Map[String, Object]]
                .flatMap(_.get("value"))
                .map(_.asInstanceOf[String])
            }
          )
        )
        .toSet

      IssueTrackerOptionDependencyCombo(itod)
    }

    Option(connection.getRemoteInstance)
      .flatMap(i => Option(i.getNodeInfo))
      .flatMap(ni => Option(ni.getInstanceUid)) match {
      case None =>
        loggingService.error(
          s"Got a request to get mapping suggestions for connection id `${connection.getID}`, but connection does not have node info with an instance UID."
        )
        Future.failed(
          new BugException(
            s"Got a request to get mapping suggestions for connection id `${connection.getID}`, but connection does not have node info with an instance UID."
          )
        )

      case Some(instanceUid) =>
        val remoteNodeInfo =
          NodeInfoValueHelper.toNodeInfoValue(connection.getRemoteInstance.getNodeInfo)
        nodeInfoProvider.get.flatMap { nodeInfoValue =>
          nodeInfoValue.editor match {
            case None =>
              loggingService.info(
                "#getMappingsValueForSuggestions: Editor is not supported. Getting Basic Non Editor Value"
              )
              issueTrackerBasicNonEditorValueService.get().map {
                case Some(editorValue) =>
                  val suggestionContext = SuggestionContext(
                    connection,
                    nodeInfoValue,
                    remoteNodeInfo,
                    localContext,
                    remoteContext
                  )
                  buildMappingsValueForSuggestions(
                    editorValue,
                    previousConnectionMode,
                    suggestionContext,
                    instanceUid
                  )
                case None              =>
                  loggingService.error(
                    s"Got a request for suggestions of mappings params but local side doesn't have supported Editor fields."
                  )
                  None
              }

            case Some(editorValue) =>
              val suggestionContext = SuggestionContext(
                connection,
                nodeInfoValue,
                remoteNodeInfo,
                localContext,
                remoteContext
              )
              Future.successful(
                buildMappingsValueForSuggestions(
                  editorValue,
                  previousConnectionMode,
                  suggestionContext,
                  instanceUid
                )
              )
          }
        }
    }
  }

  private def buildMappingsValueForSuggestions(
      editorValue: VisualFieldValue,
      previousConnectionMode: Option[String],
      suggestionContext: SuggestionContext,
      instanceUid: String
  ): Option[Seq[MappingValue]] = {
    val connection = suggestionContext.connection
    val fields = editorValue.editorFields
    // TODO use "sortRules" function, when field dependencies are implemented
    val nonMainFields = if (previousConnectionMode.contains(ConnectionMode.BASIC.toString)) {
      fields.filter(f =>
        f.key.equals(EditorFields.ISSUE_TYPE.toString)
          || f.key.equals(EditorFields.SUMMARY.toString)
          || f.key.equals(EditorFields.DESCRIPTION.toString)
          || f.key.equals(EditorFields.COMMENTS.toString)
          || f.key.equals(EditorFields.ATTACHMENTS.toString)
      )
    } else {
      fields
        .filterNot(f => f.main.contains(true))
    }

    val mappingEditorField = nonMainFields
      .foldLeft(Seq.empty[MappingValue]) {
        case (accum, next) =>
          val hasSameFieldOnRemote = suggestionContext.remoteNodeInfo.editor.toSeq
            .flatMap(_.editorFields)
            .exists(_.key == next.key)
          if (hasSameFieldOnRemote) {
            val key = next.key
            val `type` = next.`type`.toFieldTypeValue
            val (recoveryLocal, recoveryRemote) =
              createRecoveryParamsForSuggestion(key, suggestionContext)
            val (filterLocal, filterRemote) = createFilterParamsForSuggestion(key)
            val fieldValue = FieldValue(key, "???") // TODO: icon url unknown
            val local = MappingFieldTypeValue(fieldValue, recoveryLocal, filterLocal, None)
            val remote = MappingFieldTypeValue(fieldValue, recoveryRemote, filterRemote, None)
            if (`type`.key.equals(FieldDataType.OPTION.toString)) {
              val maps =
                Some(generateLocalToRemoteMaps(key, instanceUid, connection, suggestionContext))
              val mappingValue =
                MappingValue(None, Some(local), Some(Arrow.LR.toString), maps, Some(remote), None)
              accum :+ mappingValue
            } else {
              val mappingValue =
                MappingValue(None, Some(local), Some(Arrow.LR.toString), None, Some(remote), None)
              accum :+ mappingValue
            }
          } else accum
      }
    Some(mappingEditorField)
  }

  /** Checks whether the visual rules for provided connection is ready. Checking is performed by
    * Invitation Status of the connection (should be ACCEPTED) and by monitor whether Main Field
    * Options have been saved to IssueTrackerOptionTable (table where we hold all system fields and
    * their options from the remote side)
    * @param connection
    * @return
    */
  override def isVisualReady(connection: IConnection): Future[Option[JsBoolean]] = {
    val nodeInfoOpt = Option(connection.getRemoteInstance)
      .flatMap(i => Option(i.getNodeInfo))
    nodeInfoOpt
      .flatMap(ni => Option(ni.getInstanceUid)) match {
      case None =>
        loggingService.error(
          s"Got a request checking whether visual mode is ready for connection id `${connection.getID}`, but connection does not have node info with an instance UID."
        )
        Future.successful(None)

      case Some(instanceUid) =>
        val remoteNodeInfo = nodeInfoOpt.get
        val connectionIsActive = connection.getInvitationStatus == InvitationStatus.ACCEPTED
        val mainFields: Seq[EditorFieldValue] = NodeInfoValueHelper
          .toNodeInfoValue(remoteNodeInfo)
          .editor
          .toSeq
          .flatMap(_.editorFields.filter(_.main.contains(true)))
        if (!connectionIsActive) Future.successful(Some(JsBoolean(false)))
        else
          for {
            allMainFieldsHaveLoaded <- mainFields.foldLeft(Future.successful(true)) {
              case (loadedFuture, mainField) =>
                loadedFuture.flatMap { loaded =>
                  if (!loaded) Future.successful(false)
                  else {
                    Option(mainField.`type`.key) match {
                      case Some(k) if k == FieldDataType.OPTION.toString =>
                        hasOptionMainFieldLoaded(mainField, instanceUid, connection)
                      case _                                             =>
                        Future.successful(true)
                    }
                  }
                }
            }
            allMainFieldsHaveLoadedJson = JsBoolean(allMainFieldsHaveLoaded)
          } yield Some(allMainFieldsHaveLoadedJson)
    }
  }

  private def buildLocalScopeParams(): Future[Option[SingleSideScopeParamsValue]] =
    nodeInfoProvider.get.flatMap { nodeInfoValue =>
      loggingService.trace(s"Local NodeInfo value for scope params: $nodeInfoValue")
      buildScopeParams(nodeInfoValue.editor)
    }

  private def buildRemoteScopeParams(
      connection: IConnection
  ): Future[Option[SingleSideScopeParamsValue]] =
    if (connection.isLocal) buildLocalScopeParams()
    else
      nodeInfoClient.getNodeInfo(connection.getRemoteInstance).flatMap { nodeInfoValue =>
        loggingService.trace(s"Remote NodeInfo value for scope params: $nodeInfoValue")
        buildScopeParams(nodeInfoValue.editor)
      }

  /** Building scope params, by accumulating all "main" and "queryable" fields from EditorValue
    * (provided by
    * {@link com.exalate.replication.services.api.issuetracker.IIssueTrackerEditorValueService} ).
    *
    * @param editor
    *   \- obtained from nodeInfoValue.editor
    *
    * @return
    *   a JsValue which looks like { localOrRemote : { "mainFields" : [{@link
    *   com.exalate.domain.values.SupportedEditorField}], "fields": { "query": [{@link
    *   com.exalate.domain.values.SupportedEditorField}] }
    *
    * } }
    */
  private def buildScopeParams(
      editor: Option[VisualFieldValue]
  ): Future[Option[SingleSideScopeParamsValue]] =
    editor match {
      case Some(editorValue) =>
        Future.successful(buildScopeParams(editorValue))
      case None              =>
        loggingService.info(
          "#buildScopeParams: Editor is not supported. Getting Basic Non Editor Value"
        )
        issueTrackerBasicNonEditorValueService.get().map {
          case Some(editorValue) =>
            buildScopeParams(editorValue)
          case None              =>
            loggingService.error(
              s"Got a request for scope params but either local or remote side doesn't have supported Editor fields."
            )
            None
        }

    }

  private def buildScopeParams(
      editorValue: VisualFieldValue
  ): Option[SingleSideScopeParamsValue] = {
    val fields = editorValue.editorFields
    val (mainFields, queryFields) = fields
      .foldLeft(
        (Seq.empty[SupportedEditorField], Seq.empty[SupportedEditorField])
      ) {
        case (accum, next) =>
          val main = next.main.contains(true)
          val queryable = !next.queryable.contains(false)
          val key = next.key
          val `type` =
            FieldTypeValue(next.`type`.key, next.`type`.of.map(_.map(of => OfValue(of.key))))
          val labelOpt = Some(next.label)
          val operators = next.operators
            .map(_.map(op => FieldTypeValue(op.key, None)))
            .getOrElse(Seq.empty[FieldTypeValue])

          val editorField = SupportedEditorField(
            key,
            labelOpt.getOrElse(EditorFields.getReadableLabelByKey(key)),
            `type`,
            operators,
            next.placeholder
          )
          // where main == true & queryable != false add to both 'mainFields' and query fields
          if (main && queryable) {
            (accum._1 :+ editorField, accum._2 :+ editorField)
            // where main == true & queryable == false add only to 'mainFields'
          } else if (main && !queryable) {
            (accum._1 :+ editorField, accum._2)
            // where main != true & queryable != false add only to query fields
          } else if (!main && queryable) {
            (accum._1, accum._2 :+ editorField)
          } else (accum._1, accum._2)
      }

    val fieldsScope = FieldsScopeParamsValue(queryFields)
    val scopeParamsValue = SingleSideScopeParamsValue(mainFields, fieldsScope)

    Some(scopeParamsValue)
  }

  private def buildLocalMappingParams(): Future[Option[SingleSideMappingsParamsValue]] =
    nodeInfoProvider.get.flatMap { nodeInfoValue =>
      loggingService.trace(s"Local NodeInfo value for mapping params: $nodeInfoValue")
      editorCustomFieldService
        .getCustomFieldValues()
        .flatMap { customFieldValues =>
          buildMappingParams(nodeInfoValue.editor, customFieldValues)
        }
    }

  private def buildRemoteMappingParams(
      connection: IConnection
  ): Future[Option[SingleSideMappingsParamsValue]] =
    if (connection.isLocal) buildLocalMappingParams()
    else {
      val nodeInfoValueOpt = Option(connection.getRemoteInstance)
        .flatMap(instance => Option(instance.getNodeInfo))
        .map(ni => NodeInfoValueHelper.toNodeInfoValue(ni))
      val customFieldValuesOpt = Option(connection.getRemoteInstance)
        .map(instance =>
          if (instance.getCustomFieldValues != null) {
            EditorFieldValueHelper.toEditorFieldValueSeq(instance.getCustomFieldValues)
          } else {
            Nil
          }
        )
      (nodeInfoValueOpt, customFieldValuesOpt) match {
        case (Some(nodeInfoValue), Some(customFieldValues)) =>
          loggingService.trace(s"Remote NodeInfo value for mapping params: $nodeInfoValue")
          buildMappingParams(nodeInfoValue.editor, customFieldValues)
        case (Some(nodeInfoValue), _)                       =>
          loggingService.trace(s"Remote NodeInfo value for mapping params: $nodeInfoValue")
          buildMappingParams(nodeInfoValue.editor, Seq())
        case (_, _)                                         =>
          loggingService.error("#buildRemoteMappingParams: Exalate can't find nodeInfoValue")
          Future.failed(new BugException("Exalate can't find node Info Value"))
      }
    }

  /** Building mapping params, by accumulating all system fields from EditorValue and CF (provided
    * as input param)
    * @param editorValue
    * @param customFieldValues
    * @return
    *   JsValu which looks like: { localOrRemote : { "fields":
    *   {@link com.exalate.domain.values.MappingEditorField} } }
    */
  private def buildMappingParams(
      editorValue: Option[VisualFieldValue],
      customFieldValues: Seq[EditorFieldValue]
  ): Future[Option[SingleSideMappingsParamsValue]] =
    editorValue match {
      case Some(editorValue) =>
        Future.successful(buildMappingParams(editorValue, customFieldValues))
      case None              =>
        loggingService.info(
          "#buildMappingParams: Editor is not supported. Getting Basic Non Editor Value"
        )
        issueTrackerBasicNonEditorValueService.get().map {
          case Some(editorValue) =>
            buildMappingParams(editorValue, customFieldValues)
          case None              =>
            loggingService.error(
              s"Got a request for mappings params but either local or remote side doesn't have supported Editor fields."
            )
            None
        }

    }

  private def buildMappingParams(
      editorValue: VisualFieldValue,
      customFieldValues: Seq[EditorFieldValue]
  ): Option[SingleSideMappingsParamsValue] = {
    val fields = editorValue.editorFields ++ customFieldValues
    val mappingEditorField = fields.foldLeft(Seq[MappingEditorField]()) {
      case (accum, next) =>
        val key = next.key
        val `type` = next.`type`
        val main = next.main
        val labelOpt = Some(next.label)
        if (main.contains(true)) accum
        // START: remove when Labels for visual mappings is implemented
        // else if (`type`.key == FieldDataType.MULTI.toString && `type`.of.exists(_.exists(_.key == FieldDataType.TEXT))) accum
        // END: remove when Labels for visual mappings is implemented
        else {
          val editorField = MappingEditorField(
            key,
            labelOpt.getOrElse(EditorFields.getReadableLabelByKey(key)),
            `type`.toFieldTypeValue,
            next.placeholder
          )
          editorField +: accum
        }
    }
    val singleSideMappingsParams = SingleSideMappingsParamsValue(mappingEditorField)

    Some(singleSideMappingsParams)
  }

  /** Creates recovery value for requested system field (key) for suggested mapping rules.
    * @param key
    *   \- key of the target field (String of
    *   {@link com.exalate.domain.transport.trackeroptions.EditorFields} )
    * @param ctx
    * @return
    */
  private def createRecoveryParamsForSuggestion(
      key: String,
      ctx: SuggestionContext
  ): (Option[Recovery], Option[Recovery]) =
    EditorFields.withNameOpt(key) match {
      case Some(ISSUE_TYPE)                               =>
        val localOpt = FutureUtils
          .toTry(
            optionsService.getLocalOptionsForAutocompleteWithContext(
              ISSUE_TYPE.toString,
              query = None,
              limit = None,
              offset = None,
              Some(ctx.localContext.flatMap(_.combination))
            )
          )
          .toOption
          .map(_.results)
          .flatMap(findBestRecoveryIssueType)

        val remoteOpt =
          if (ctx.connection.isLocal)
            FutureUtils
              .toTry(
                optionsService.getLocalOptionsForAutocompleteWithContext(
                  ISSUE_TYPE.toString,
                  query = None,
                  limit = None,
                  offset = None,
                  Some(ctx.remoteContext.flatMap(_.combination))
                )
              )
              .toOption
              .map(_.results)
              .flatMap(findBestRecoveryIssueType)
          else
            FutureUtils
              .toTry(
                optionsService.getRemoteOptionsForAutocompleteWithContext(
                  ISSUE_TYPE.toString,
                  ctx.connection,
                  None,
                  None,
                  None,
                  Some(ctx.remoteContext.flatMap(_.combination))
                )
              )
              .toOption
              .map(_.results)
              .flatMap(findBestRecoveryIssueType)

        (
          Some(Recovery(RecoveryType.DEFAULT.toString, localOpt)),
          Some(Recovery(RecoveryType.DEFAULT.toString, remoteOpt))
        )
      case Some(SUMMARY)                                  =>
        (
          Some(Recovery(RecoveryType.DEFAULT.toString, Some(JsString("Test, please ignore")))),
          Some(Recovery(RecoveryType.DEFAULT.toString, Some(JsString("Test, please ignore"))))
        )
      case Some(PRIORITY)                                 =>
        (
          Some(Recovery(RecoveryType.NONE.toString, None)),
          Some(Recovery(RecoveryType.NONE.toString, None))
        )
      case Some(STATUS)                                   =>
        (
          Some(Recovery(RecoveryType.NONE.toString, None)),
          Some(Recovery(RecoveryType.NONE.toString, None))
        )
      case Some(DESCRIPTION)                              =>
        (
          Some(Recovery(RecoveryType.DEFAULT.toString, Some(JsString("No description provided")))),
          Some(Recovery(RecoveryType.DEFAULT.toString, Some(JsString("No description provided"))))
        )
      case Some(COMMENTS)                                 => (None, None)
      case Some(ATTACHMENTS)                              => (None, None)
      case Some(LABELS) | Some(ASSIGNEE) | Some(REPORTER) =>
        (
          Some(Recovery(RecoveryType.NONE.toString, None)),
          Some(Recovery(RecoveryType.NONE.toString, None))
        )
      case _                                              => (None, None)
    }

  /** Creates filter Params for requested system field (key) for suggested mapping rules. For
    * comments: {@link com.exalate.domain.editor.mappings.CommentFilters} For attachments:
    * {@link com.exalate.domain.editor.mappings.AttachmentFilters}
    * @param key
    *   \- requested system field , could be COMMENTS or ATTACHMENTS
    * @return
    */
  private def createFilterParamsForSuggestion(
      key: String
  ): (Option[Seq[FilterKey]], Option[Seq[FilterKey]]) =
    EditorFields.withNameOpt(key) match {
      case Some(COMMENTS)    =>
        (Some(Seq(FilterKey(CommentFilters.SKIP_NONE.toString, None, None))), None)
      case Some(ATTACHMENTS) =>
        (
          Some(
            Seq(
              FilterKey(
                AttachmentFilters.SKIP_FILESIZE_GREATER_THAN.toString,
                Some(FilterKeyValue("MB", 100)),
                Some(false)
              )
            )
          ),
          Some(
            Seq(
              FilterKey(
                AttachmentFilters.SKIP_FILESIZE_GREATER_THAN.toString,
                Some(FilterKeyValue("MB", 100)),
                Some(false)
              )
            )
          )
        )
      case default           => (None, None)
    }

  /** Generates suggested mapping maps for target system fields with Field Data Type "OPTION". The
    * mapping maps (List[{@link com.exalate.domain.editor.mappings.MapValue}]) is formed based on
    * issue tracker options obtained from local and remote sides for the target field.
    * @param key
    *   \- key of the target field
    * @param instanceUid
    * @param connection
    * @param ctx
    * @return
    */
  private def generateLocalToRemoteMaps(
      key: String,
      instanceUid: InstanceUid,
      connection: IConnection,
      ctx: SuggestionContext
  ): List[MapValue] = {
    val streamOfLocalOptions =
      getListOfLocalOptionsForKey(key, Some(ctx.localContext.flatMap(_.combination)))

    FutureUtils.resultInf(
      streamOfLocalOptions.map(localOptsStream =>
        localOptsStream.foldLeft(List[MapValue]()) {
          case (accum, localOpts) =>
            val localOptions = ctx.localContext.flatMap(combination =>
              IssueTrackerOptionContextOps.filterOptions(
                localOpts,
                None,
                Some(combination.combination)
              )
            )
            val maps = localOptions.foldLeft(List[MapValue]()) { (result, localOpt) =>
              // de-duplication for suggestions
              if (result.exists(m => m.local == localOpt.label)) result
              else {
                val remoteOptsFuture = ctx.remoteContext
                  .flatMap { combo =>
                    val remoteOpts =
                      if (!connection.isLocal)
                        FutureUtils.resultInf(
                          findRemoteOpts(instanceUid, key, localOpt, connection, ctx)
                        )
                      else FutureUtils.resultInf(streamOfLocalOptions).flatten
                    IssueTrackerOptionContextOps
                      .filterOptions(remoteOpts, None, Some(combo.combination))
                  }
                  .find(_.label == localOpt.label)
                val matchingRemoteOpt = remoteOptsFuture

                result ++ matchingRemoteOpt.map(remoteOpt =>
                  MapValue(localOpt.label, Arrow.LR.toString, remoteOpt.label)
                )
              }
            }
            accum ++ maps
        }
      )
    )
  }

  /** The method extracts a seq of Issue Tracker Option for the target field by calling
    * corresponding method from
    * {@link com.exalate.replication.services.api.issuetracker.ITrackerOptionService}
    * @param key
    *   \- target field (string of {@link com.exalate.domain.transport.trackeroptions.EditorFields}
    *   )
    * @param context
    * @return
    *   Future[Stream[Seq[IssueTrackerOption]]]
    */
  private def getListOfLocalOptionsForKey(
      key: String,
      context: Option[Seq[IssueTrackerOptionDependency]]
  ): Future[Stream[Seq[IssueTrackerOption]]] =
    EditorFields.withNameOpt(key) match {
      case Some(PROJECT)    =>
        PaginationUtil
          .collect[IssueTrackerOption, Page[IssueTrackerOption]](
            trackerOptionService.fetchProjectOptionsStream(context)
          ) // FIXME EXACOMP-546 stop collecting into memory
          .map(results => Stream(results))
      case Some(ISSUE_TYPE) =>
        PaginationUtil
          .collect[IssueTrackerOption, Page[IssueTrackerOption]](
            trackerOptionService.fetchIssuetypeOptions(context)
          ) // FIXME EXACOMP-546 stop collecting into memory
          .map(results => Stream(results))
      case Some(PRIORITY)   =>
        PaginationUtil
          .collect[IssueTrackerOption, Page[IssueTrackerOption]](
            trackerOptionService.fetchPriorityOptions(context)
          ) // FIXME EXACOMP-546 stop collecting into memory
          .map(results => Stream(results))
      case Some(STATUS)     =>
        PaginationUtil
          .collect[IssueTrackerOption, Page[IssueTrackerOption]](
            trackerOptionService.fetchStatusOptions(context)
          ) // FIXME EXACOMP-546 stop collecting into memory
          .map(results => Stream(results))
      // not loading custom field options
      case _                =>
        Future.successful(Stream.empty)
      // TODO make suggestions using custom fields
      //        PaginationUtil
      //          .collect(trackerOptionService.fetchCustomFieldOptions(key)) //FIXME EXACOMP-546 stop collecting into memory
      //          .map(results => Stream(results))
    }

  /** Based on the provided params, the method calls
    * {@link com.exalate.api.persistence.issuetracker.IIssueTrackerOptionRepository} to find a list
    * of options for target field
    *
    * @param instanceUid
    *   \- instanceUid of the remote side
    * @param key
    *   \- key of the target system field
    * @param localOpt
    * @param connection
    * @param ctx
    * @return
    */
  private def findRemoteOpts(
      instanceUid: InstanceUid,
      key: String,
      localOpt: IssueTrackerOption,
      connection: IConnection,
      ctx: SuggestionContext
  ): Future[Seq[IssueTrackerOption]] =
    PaginationUtil.collect { (r: pagination.PageRequest) =>
      issueTrackerOptionRepository
        .find(
          instanceUid,
          key,
          Option(localOpt.label),
          PageRequest(Option(r.limit), Option(r.offset.toInt))
        )
        .map(p => Page(r, p.results, p.total.toLong, r.offset + r.limit >= p.total))
    }

  /** Make a request to DB, namely to IssueTrackerOptionTable, in order to check if issue tracker
    * options have been saved
    * @param mainField
    *   \- field which should be checked
    * @param instanceUid
    *   \- instanceUid of the remote instance
    * @param connection
    * @return
    */
  private def hasOptionMainFieldLoaded(
      mainField: EditorFieldValue,
      instanceUid: String,
      connection: IConnection
  ) =
    if (connection.isLocal) Future.successful(true)
    else
      issueTrackerOptionRepository
        .find(instanceUid, mainField.key, None, PageRequest(Some(1), Some(0)))
        .map(_.total > 0)

  private def findBestRecoveryIssueType(
      os: Seq[com.exalate.domain.transport.trackeroptions.IssueTrackerOptionValue]
  ): Option[com.exalate.domain.transport.trackeroptions.IssueTrackerOptionValue] =
    os.find(isNotEpicOrSubTask)
      .orElse(os.headOption)

  private def isNotEpicOrSubTask(
      o: com.exalate.domain.transport.trackeroptions.IssueTrackerOptionValue
  ): Boolean =
    !o.label.equalsIgnoreCase("Epic") &&
      !o.label.equalsIgnoreCase("Sub-task") &&
      !o.label.equalsIgnoreCase("Subtask")

}
