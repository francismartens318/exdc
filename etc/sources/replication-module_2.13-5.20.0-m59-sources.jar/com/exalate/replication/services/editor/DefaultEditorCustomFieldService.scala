package com.exalate.replication.services.editor

import com.exalate.replication.services.api.editor.IEditorCustomFieldService

class DefaultEditorCustomFieldService extends IEditorCustomFieldService {}
