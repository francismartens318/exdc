package com.exalate.replication.services.error.retry

import akka.actor._
import com.exalate.replication.services.replication.worker.messages.RequestWorkerMessages
import com.google.inject.Inject
import play.api.Logger

object RateLimitedTaskProcessorActor {
  object Process
}

/** @see
  *   http://doc.akka.io/docs/akka/snapshot/scala/actors.html
  */
class RateLimitedTaskProcessorActor @Inject() (
    rateLimitedTaskProcessorService: IRateLimitedTaskProcessorService
) extends Actor {
  import RateLimitedTaskProcessorActor.Process

  val LOG: Logger = Logger(
    "application.com.exalate.replication.services.error.retry.RateLimitedTaskProcessorActor"
  )

  import RequestWorkerMessages._

  def receive: Receive = waiting

  private val waiting: Receive = {
    case Process =>
      LOG.trace("RateLimitedTaskProcessorActor:waiting:_")
      self ! AfterTheLastMessage
      context.become(waitingForAfterTheLastMessage)
  }

  private def waitingForAfterTheLastMessage: Receive = {
    case AfterTheLastMessage =>
      LOG.trace(
        "RateLimitedTaskProcessorActor:waitingForAfterTheLastMessage AfterTheLastMessage - processTaskQueue"
      )
      rateLimitedTaskProcessorService.processTaskQueue()
      context.become(waiting)
    case Process             =>
      // We avoid processing unnecessary messages, relaying that if we are in this actor state, there is a AfterTheLastMessage on the queue
      LOG.trace("RateLimitedTaskProcessorActor:waitingForAfterTheLastMessage:_")
  }

}
