package com.exalate.replication.services.error

import com.exalate.api.domain.event.ISyncEvent
import com.exalate.api.domain.request.ISyncRequest
import com.exalate.api.domain.{ErrorActType, ErrorEntityType, ErrorKeys}
import com.exalate.api.exception.bug.PersistenceBugException
import com.exalate.api.exception.network.AvailabilityNetworkException
import com.exalate.api.exception.script.ScriptException
import com.exalate.api.exception.{CategorizedException, RetriableException}
import com.exalate.api.persistence.relation.IRelationRepository
import com.exalate.api.persistence.replication.event.IEventReplicationRepository
import com.exalate.basic.domain.error.NonPersistentError
import com.exalate.domain.exception.config.ConnectionOnRemoteSideNotFoundExalateConfigException
import com.exalate.domain.exception.issuetracker.{
  ForbiddenTrackerRestException,
  UnauthorizedTrackerRestException
}
import com.exalate.domain.exception.trigger.ExalateTriggerException
import com.exalate.domain.replication.BasicSyncRequest
import com.exalate.error.services.api.IAvailabilityNetworkExceptionCategoryService
import com.exalate.persistence.RepositoryUtils
import com.exalate.replication.services.api.error._
import com.exalate.replication.services.api.error.retry.IRetryContextService
import com.exalate.replication.services.transport.value.IssueKeyValue
import com.google.inject.Provider
import org.apache.commons.lang3.exception.ExceptionUtils
import play.api.Logger
import play.api.libs.json.Json

import java.net.UnknownHostException
import javax.inject.Inject
import scala.concurrent.{ExecutionContext, Future}

class ErrorHandler @Inject() (
    errorService: IErrorService,
    trackerErrorHandler: ITrackerErrorHandler,
    failedToTriggerIssuesService: FailedToTriggerExalateIssuesService,
    retryContextServiceProvider: Provider[IRetryContextService],
    replicationRepository: IEventReplicationRepository,
    availabilityNetworkExceptionCategoryService: IAvailabilityNetworkExceptionCategoryService,
    connectionRepository: IRelationRepository
)(implicit executionContext: ExecutionContext)
    extends IErrorHandler {

  val LOG = Logger("application.services.error.ErrorHandler")

  /** Error handling process It handles UnknownHostException, RetriableException and Non Retriable
    * Error
    * @param ex
    *   exception
    * @param context
    * @return
    *   None
    */
  override def handleError(ex: Exception, context: SyncContext): Future[None.type] = {
    LOG.error("Handling general exception", ex)
    Future
      .failed(ex)
      .recoverWith {
        case e: UnknownHostException             =>
          val exception = availabilityNetworkExceptionCategoryService
            .generateRetriableConnectTransportNetworkException(e, Option(e.getMessage))
          Future.failed(exception)
        case e: UnauthorizedTrackerRestException =>
          errorService
            .createError(
              ErrorEntityType.NODE,
              e,
              SyncContext(),
              Some(ErrorKeys.getUnauthorizedErrorKey)
            )
            .map(_ => None)
      }
      .recoverWith {
        case e: Exception => trackerErrorHandler.handleError(e, context)
      }
      .recoverWith {
        case e: RetriableException =>
          retryContextServiceProvider.get().handle(e, context)
      }
      .recoverWith {
        case e: Exception => handleNonRetriableError(e, context)
      }
  }

  /** Handles Non Retriable Error, namely it handles PersistenceBugException,
    * AvailabilityNetworkException, ScriptException,
    * ConnectionOnRemoteSideNotFoundExalateConfigException, CategorizedException and default
    * Exception
    * @param e
    *   exception
    * @param context
    *   sync contextx
    * @return
    */
  def handleNonRetriableError(e: Exception, context: SyncContext): Future[None.type] =
    e match {

      case e: PersistenceBugException =>
        LOG.error("There was an error while attempting to perform a persistence operation", e)
        Future.successful(None)

      case e: AvailabilityNetworkException =>
        shouldCreateError(context).flatMap { should =>
          if (should) errorService.createTransportError(e, context).map(_ => None)
          else Future.successful(None)
        }

      case e: ScriptException =>
        shouldCreateError(context)
          .flatMap { should =>
            if (should) {
              val errorKey: Option[String] =
                if (
                  Option(
                    e.getLineNumber
                  ).isDefined || ErrorEntityType.WARNING == e.getErrorEntityType
                ) {
                  val eventRequestFromContextOpt = getSyncEventRequestFromContext(context)
                  eventRequestFromContextOpt.map(eventRequestFromContext =>
                    ErrorKeys.getScriptError(
                      context.connection.get.getID,
                      eventRequestFromContext,
                      e.getLineNumber,
                      e.getScriptProcessor
                    )
                  )
                } else None
              errorService
                .createError(e, context, errorKey)
                .map(_ => None)
            } else Future.successful(None)
          }

      case e: ConnectionOnRemoteSideNotFoundExalateConfigException =>
        shouldCreateError(context).flatMap { should =>
          if (should) {
            context.syncEventOpt
              .map(_.getConnection.getID)
              .foreach(connectionRepository.deActivateConnection)
            errorService.createError(e, context, None).map(_ => None)
          } else Future.successful(None)
        }

      case e: CategorizedException =>
        shouldCreateError(context).flatMap { should =>
          if (should) errorService.createError(e, context, None).map(_ => None)
          else Future.successful(None)
        }

      case e: Exception =>
        shouldCreateError(context).flatMap { should =>
          if (should)
            errorService.createError(ErrorEntityType.RELATION, e, context, None).map(_ => None)
          else Future.successful(None)
        }
    }

  /** Checks whether error should be created
    * @param context
    * @return
    *   Future of true or false
    */
  private def shouldCreateError(context: SyncContext): Future[Boolean] = context match {
    case SyncContext(_, _, _, _, _, _, _, Some(syncEvent: ISyncEvent), _, _, _, _)              =>
      errorService.hasErrorReferencingSyncEvent(syncEvent.getId).map(exists => !exists)
    case SyncContext(_, _, _, _, _, _, _, _, Some(syncRequest: ISyncRequest), _, _, _)          =>
      errorService.hasErrorReferencingSyncRequest(syncRequest.getId).map(exists => !exists)
    case SyncContext(_, _, _, _, _, _, _, _, _, Some(basicSyncRequest: BasicSyncRequest), _, _) =>
      errorService.hasErrorReferencingSyncRequest(basicSyncRequest.id).map(exists => !exists)
    case SyncContext(Some(syncEventId), _, _, _, _, _, _, _, _, _, _, _)                        =>
      replicationRepository.getSyncEvent(syncEventId).flatMap {
        case Some(syncEvent) =>
          errorService.hasErrorReferencingSyncEvent(syncEvent.getId).map(exists => !exists)
        case None            => Future.successful(true)
      }
    case _ => Future.successful(true)
  }

  // FIXME: logic for handling trigger errors is affected as now there is no way to know which is the entity that failed
  /** Handles Scheduled Error, by pre-processing obtained exception and saving it to DB
    * @param ex
    * @param ec
    * @param actTypeOpt
    * @return
    */
  override def handleScheduleError(
      ex: Exception,
      ec: SyncContext,
      actTypeOpt: Option[ErrorActType]
  ): Future[None.type] = {
    LOG.error("Handling schedule exception", ex)
    Future
      .failed(ex)
      .recoverWith {
        case e: Exception => trackerErrorHandler.handleScheduleError(e, ec, actTypeOpt)
      }
      .recoverWith {
        case e: ScriptException               =>
          val errorKey = Some(
            ErrorKeys.getScriptSchedulingError(
              ec.connection.get.getID,
              e.getLineNumber,
              e.getScriptProcessor
            )
          )
          errorService
            .createError(
              ErrorEntityType.WARNING,
              e,
              ec.connection.get,
              ec.localIssueKeyOpt,
              ec.remoteIssueKeyOpt,
              actTypeOpt,
              errorKey
            )
            .map(_ => None)
        case e: ExalateTriggerException       =>
          // Trigger errors happens when attempting to trigger sync for a local issue, so we can be sure that the error will reference that local issue.
          val localIssueKey = ec.localIssueKeyOpt.get
          val trigger = e.trigger
          errorService.getErrorForTrigger(trigger).flatMap {
            case Some(triggerError) =>
              LOG.debug(
                s"Handling trigger exception: there is already an error for trigger, error will be updated to include issue ${localIssueKey.getURN}"
              )
              val failedIssuesUpdated = (failedToTriggerIssuesService.getFailedToTriggerIssues(
                triggerError
              ) :+ IssueKeyValue.convert(localIssueKey)).distinct
              val updatedError = new NonPersistentError(triggerError)
              updatedError.setStackTrace(ExceptionUtils.getStackTrace(e))
              updatedError.setRootCauseErrorTypeName("Trigger configuration error")
              val failedUrnsUpdate = failedIssuesUpdated.map(_.urn).mkString(", ")
              updatedError.setRootCauseDetails(
                s"Cannot run the query for issue(s) `$failedUrnsUpdate`. Please validate the search query and retry: ${trigger.getJqlFilter}."
              )
              errorService.updateError(triggerError.getId, updatedError)

            case None =>
              LOG.debug(
                s"Handling trigger exception: there is no error for trigger yet, error will be created for issue ${localIssueKey.getURN}"
              )
              val failedIssueValueJsonStr =
                Json.stringify(Json.toJson(Seq(IssueKeyValue.convert(localIssueKey))))
              val entityType = ec.syncEventOpt.flatMap(RepositoryUtils.getEntityTypeFromSyncEvent)
              errorService
                .createTriggerError(
                  entityType,
                  e,
                  ec.connection.get,
                  ec.localIssueKeyOpt,
                  failedIssueValueJsonStr
                )
                .map(_ => None)
          }
        case e: PersistenceBugException       =>
          LOG.error("There was an error while attempting to perform a persistence operation", e)
          Future.successful(None)
        case e: AvailabilityNetworkException  =>
          val errorKey =
            actTypeOpt.map(_ => ErrorKeys.getReplicationTransportErrorKey(ec.connection.get.getID))
          errorService
            .createError(
              ErrorEntityType.WARNING,
              e,
              ec.connection.get,
              ec.localIssueKeyOpt,
              ec.remoteIssueKeyOpt,
              actTypeOpt,
              errorKey
            )
            .map(_ => None)
        case e: ForbiddenTrackerRestException =>
          val errorKey = actTypeOpt.map(_ => ErrorKeys.getUnauthorizedErrorKey)
          errorService.createError(e, SyncContext(), errorKey).map(_ => None)
        case e: Exception                     =>
          val errorKey = actTypeOpt
            .map(_ => ErrorKeys.getSchedulingErrorKey(ec.connection.get.getID, ec.localIssueKeyOpt))
          errorService
            .createError(
              ErrorEntityType.WARNING,
              e,
              ec.connection.get,
              ec.localIssueKeyOpt,
              ec.remoteIssueKeyOpt,
              actTypeOpt,
              errorKey
            )
            .map(_ => None)
      }
  }

  def getSyncEventRequestFromContext(context: SyncContext): Option[Int] =
    (context.syncEventOpt, context.syncRequestOpt, context.basicSyncRequestOpt) match {
      case (Some(syncEvent), None, None)        => Some(syncEvent.getId)
      case (None, Some(syncRequest), None)      => Some(syncRequest.getId)
      case (None, None, Some(basicSyncRequest)) => Some(basicSyncRequest.id)
      case _                                    => None
    }

}
