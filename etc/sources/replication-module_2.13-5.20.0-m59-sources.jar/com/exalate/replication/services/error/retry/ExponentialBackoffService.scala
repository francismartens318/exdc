package com.exalate.replication.services.error.retry

import com.exalate.replication.services.api.error.retry.IExponentialBackoffService

import scala.concurrent.duration.Duration
import scala.util.Random

class ExponentialBackoffService extends IExponentialBackoffService {

  def next(prev: Duration): Duration = Duration(
    {
      val linearBackoff = Math.ceil(prev.length * 1.5).toLong
      val jitter = Random.nextInt(10)
      linearBackoff + jitter
    },
    prev.unit
  )

}
