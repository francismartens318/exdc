package com.exalate.replication.services.error

import com.exalate.api.domain.SyncRequestEventType
import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.editor.error.{EditorErrorSide, ErrorLocationType}
import com.exalate.api.domain.editor.scopes.SyncCriteria
import com.exalate.api.domain.request.ISyncRequest
import com.exalate.api.exception.{CategorizedException, IssueTrackerException}
import com.exalate.api.persistence.mappings.IMappingsRepository
import com.exalate.api.persistence.scopes.IScopesRepository
import com.exalate.api.persistence.twintrace.ITwinTraceRepository
import com.exalate.basic.domain.hubobject.v1.BasicHubIssue
import com.exalate.domain.editor.FieldDataType
import com.exalate.domain.editor.FieldDataType.FieldDataType
import com.exalate.domain.editor.mappings.{Arrow, Mappings, Recovery}
import com.exalate.domain.editor.scopes.Scope
import com.exalate.domain.exception.editor._
import com.exalate.domain.transport.trackeroptions.{EditorFields, RecoveryKey}
import com.exalate.domain.values.{EditorFieldErrorValue, EditorFieldValue}
import com.exalate.replication.services.api.error.{
  IEditorErrorCategoryService,
  VisualNotEnoughDataToCreateIssueProcessorException
}
import com.exalate.replication.services.api.issuetracker.IInstanceEditorFieldService
import com.exalate.util.json.gson.GsonCaseClassValueJsonService

import javax.inject.Inject
import scala.jdk.CollectionConverters._
import scala.concurrent.{ExecutionContext, Future}

class EditorErrorCategoryService @Inject() (
    twinTraceRepository: ITwinTraceRepository,
    instanceEditorFieldService: IInstanceEditorFieldService,
    scopesRepository: IScopesRepository,
    mappingsRepository: IMappingsRepository
)(implicit ec: ExecutionContext)
    extends IEditorErrorCategoryService {

  /** The function which take a seq of errors, obtained after create issue or update issue, and
    * transform it to the corresponding visual error in order to visualize it on UI
    *
    * @param editorFieldErrorValue
    *   : Seq[EditorFieldErrorValue] where EditorFieldErrorValue consist of editorField obtained as
    *   following: { localFields <- instanceEditorFieldService.getLocalEditorFieldValues() fOpt =
    *   editorFieldService.toEditorFieldOpt(field, EntityTypes.Issue, localFields) } errorMessage:
    *   taken from Exception; value: obtained as following { value =
    *   editorFieldService.getValue(hubIssue, EntityTypes.Issue, fOpt.get) }
    * @param syncRequest
    * @param hubIssue:
    *   is the issue after visual rules have been run
    * @return
    *   Future[CategorizedException], CategorizedException namely :
    *   VisualNotEnoughDataToCreateIssueProcessorException; MissingMappingEditorException;
    *   NoProjectEditorCategorizedException; ScriptEditorException; OverallMappingEditorException;
    *   RecoveryMappingEditorException; MappingMapsEditorException
    */

  // TODO EXAEDIT-981 !IMPORTANT! Iteration 2: switch all backtracking to MappingService producing an audit log AuditLog(editorField: EditorFieldValue, mappingOpt, mapOpt, recoveryOpt) { def isRecovery = recoveryOpt.isDefined; def isScript = mappingOpt.exists(m.script.isDefined); ... }, which can be used for direct causing
  def toEditorError(
      editorFieldErrorValue: Seq[EditorFieldErrorValue],
      syncRequest: ISyncRequest,
      hubIssue: BasicHubIssue /*,  auditLog: Seq[AuditLog] */
  ): Future[CategorizedException] = {
    val connection = syncRequest.getConnection
    val fieldError = editorFieldErrorValue.head // TODO EXE-683 handle multiple field errors
    val value = fieldError.value // TODO EXAEDIT-981 we should have Option[String]
    val trackerError = fieldError.errorMessage
    val field = fieldError.editorField
    if (!field.isMain) {
      backtrackRuleError(syncRequest, hubIssue, connection, field, trackerError, value)
    } else if (field.key == EditorFields.PROJECT.toString) {
      shouldSwapSides(syncRequest).flatMap { swapSides =>
        scopesRepository
          .getByConnectionId(connection.getID)
          .map { scopes =>
            if (value.isEmpty && syncRequest.getSyncType == SyncRequestEventType.EXALATE) {
              new VisualNotEnoughDataToCreateIssueProcessorException(
                syncRequest.getReplica.getIssueKey.getURN,
                scopes
                  .map { s =>
                    val rightArrow =
                      if (s.local.syncCriteria == SyncCriteria.NONE) "-"
                      else ">"
                    val leftArrow =
                      if (s.remote.syncCriteria == SyncCriteria.NONE) "-"
                      else "<"
                    val left = "(" + s.local.mainFields
                      .map(f => s"${f.key}=${f.value.map(_.toString).getOrElse("None")}")
                      .mkString(", ") + ")"
                    val right = s.remote.mainFields
                    s"$left $leftArrow$rightArrow $right"
                  }
                  .mkString("; ")
              ).asInstanceOf[EditorCategorizedException]
            } else {
              backtrackScope(swapSides, scopes, value) match {
                case None        => new IssueTrackerException(trackerError)
                case Some(scope) =>
                  val sideScope =
                    if (swapSides) scope.remote
                    else scope.local
                  val field = sideScope.mainFields.find(_.key == EditorFields.PROJECT.toString)
                  val projectName = field.flatMap(toLabelStr).getOrElse("None")
                  val projectKey = value.map(_.toString).getOrElse("None")
                  val side = if (swapSides) EditorErrorSide.REMOTE else EditorErrorSide.LOCAL
                  NoProjectEditorCategorizedException(
                    scope.local.scopeUid,
                    projectName,
                    projectKey,
                    ErrorLocationType.SCOPE_MAIN_FIELD,
                    side
                  )
              }
            }
          }
      }
    } else {
      // TODO EXE-683 handle non-field Errors
      Future.successful(new IssueTrackerException(trackerError))
    }

  }

  // TODO EXE-683 remove when audit log is available
  /** checks whether the scopes caused an error, by searching in the scopes a value which was
    * extracted from EditorFieldErrorValue
    * @param swapSides
    * @param scopes
    *   \- a seq of scopes
    * @param value
    *   \- value/field extracted from EditorFieldErrorValue
    * @return
    */
  private def backtrackScope(swapSides: Boolean, scopes: Seq[Scope], value: Option[Object]) =
    scopes
      .find { s =>
        val sideScope =
          if (swapSides) s.remote
          else s.local
        sideScope.mainFields
          .find(_.key == EditorFields.PROJECT.toString)
          .flatMap(_.value)
          .flatMap(toValueStr)
          .contains(value.map(_.toString).orNull)
      }

  /** checks whether the one of the mapping rules caused an error
    * @param syncRequest
    * @param hubIssue
    * @param connection
    * @param f
    *   \- EditorFieldValue
    * @param errorMessage
    * @param value
    *   value/field extracted from EditorFieldErrorValue
    * @return
    */
  private def backtrackRuleError(
      syncRequest: ISyncRequest,
      hubIssue: BasicHubIssue,
      connection: IConnection,
      f: EditorFieldValue,
      errorMessage: String,
      value: Option[Object]
  ) =
    for {
      swapSides <- shouldSwapSides(syncRequest)
      receivingSide =
        if (swapSides) EditorErrorSide.REMOTE
        else EditorErrorSide.LOCAL
      remoteFields <-
        if (connection.isLocal) instanceEditorFieldService.getLocalEditorFieldValues()
        else
          Future.successful(
            instanceEditorFieldService.getRemoteEditorFieldValues(connection.getRemoteInstance)
          )
      correctDirections = (if (swapSides) Seq(Arrow.LR, Arrow.R)
                           else Seq(Arrow.L, Arrow.LR))
        .map(_.toString)
      e <- mappingsRepository
        .getByConnectionId(connection.getID)
        .map { mappings: Seq[Mappings] =>
          val mappingInRightDirectionForField =
            getMappingsToCorrectFieldAndDirection(mappings, correctDirections, swapSides, f)
          val recoveryBlamed =
            // Field 'priority' cannot be set. It is not on the appropriate screen, or unknown.
            if (errorMessage.contains("not on the appropriate screen, or unknown"))
              Option.empty[EditorCategorizedException]
            else
              blameMapsOrRecovery(
                value,
                hubIssue,
                f,
                mappingInRightDirectionForField,
                correctDirections,
                remoteFields,
                swapSides
              )
          recoveryBlamed
            // if there was no recovery or map found, blame the last field mapping
            .orElse(
              blameOverallMapping(errorMessage, f, receivingSide, mappingInRightDirectionForField)
            )
            // if there was no mapping found, blame the last script
            .orElse(blameScript(mappings, f))
            .getOrElse {
              if (value.isDefined) new IssueTrackerException(errorMessage)
              // Iteration 1:
              // valueOpt.isEmpty => RequiredFieldException (show error next to "add mapping" button)
              // Iteration 2:
              // val ruleOpt = auditLog.reverse.find(al => al.f.key == f.key); ruleOpt match {
              //  case Some(rule) if rule.isRecovery =>
              //     RecoveryException() // (show error next to recovery)
              //  case Some(rule) if rule.isScript =>
              //     ScriptException() // (show error next to that script)
              //  case None =>
              //     RequiredFieldException (show error next to "add mapping" button)
              //  case _ =>
              //     ContactSupport() // (no visual error)
              // }
              else MissingMappingEditorException(f)
            }
        }
    } yield e

  /** checks whether the script rules caused an error
    * @param mappings
    * @param f
    * @return
    */
  private def blameScript(mappings: Seq[Mappings], f: EditorFieldValue) =
    mappings
      .filter(m => m.local.isEmpty && m.remote.isEmpty && m.inScript.isDefined)
      .lastOption
      // TODO EXE-683 extract into subclass of ScriptEditorException
      .map(m => ScriptEditorException(s"This script rule might be removing the ${f.label} value!", m))

  /** checks whether the field is missing
    * @param jiraError
    * @param f
    * @param receivingSide
    * @param mappingInRightDirectionForField
    * @return
    */
  private def blameOverallMapping(
      jiraError: String,
      f: EditorFieldValue,
      receivingSide: EditorErrorSide,
      mappingInRightDirectionForField: Seq[Mappings]
  ) =
    mappingInRightDirectionForField.reverse.lastOption
      .map(m => OverallMappingEditorException(jiraError, m, receivingSide, f))

  // TODO EXE-683 move to MappingService
  private def shouldSwapSides(syncRequest: ISyncRequest) =
    if (syncRequest.getConnection.isLocal)
      twinTraceRepository
        .getTwinTraceById(syncRequest.getRemoteTwinTraceId)
        .map(_.exists(!_.isUseRemoteScope))
    else Future.successful(false)

  /** checks whether the mapping maps or recovery values are missing, or caused an error in case it
    * was wrong provided
    * @param value
    * @param hubIssue
    * @param f
    * @param mappings
    * @param correctDirections
    * @param remoteFields
    * @param swapSides
    * @return
    */
  private def blameMapsOrRecovery(
      value: Option[Object],
      hubIssue: BasicHubIssue,
      f: EditorFieldValue,
      mappings: Seq[Mappings],
      correctDirections: Seq[String],
      remoteFields: Seq[EditorFieldValue],
      swapSides: Boolean
  ) = {
    lazy val receivingSide =
      if (swapSides) EditorErrorSide.REMOTE
      else EditorErrorSide.LOCAL
    val receivedValue = value
    mappings
      // find the first mapping from the bottom
      // that either has a map for the appropriate value or has
      .reverse.foldLeft(Option.empty[CategorizedException]) {
        case (r: Some[CategorizedException], _) => r
        case (None, m)                          =>
          //        val sendingField =
          //          if (swapSides) m.local
          //          else m.remote
          //        lazy val sendingFieldOpt = sendingField
          //          .flatMap(sf => remoteFields.find(_.key == sf.field.key))
          val receivingField =
            if (swapSides) m.remote
            else m.local
          val mapOpt = m.maps.toSeq.flatten
            .find { map =>
              lazy val correctSideValue =
                if (swapSides) map.remote
                else map.local
              correctDirections.contains(map.arrow) && receivedValue.contains(correctSideValue)
            }
          lazy val recoveryOpt = receivingField
            .flatMap(_.recovery)
            .find(recovery =>
              recovery.key == RecoveryKey.DEFAULT.toString && recovery.value.exists {
                case Some(_)
                    if Seq(FieldDataType.OPTION, FieldDataType.TEXT)
                      .map(_.toString)
                      .contains(f.`type`.key) =>
                  getRecoveryValue(recovery, FieldDataType.withNameOpt(f.`type`.key))
                    .exists(recoveryValue => receivedValue.contains(recoveryValue))
                case _ => false
              }
            )
          // FIXME EXE-683 can only be fixed by audit log
          lazy val sentValue = Some(
            "unknown"
          ) // sendingFieldOpt.flatMap(sf => editorFieldService.getValue(replica, Issue, sf))
          mapOpt
            .map { map =>
              val sending = if (swapSides) map.local else map.remote
              val receiving = if (swapSides) map.remote else map.local
              MappingMapsEditorException(m, receiving, sending, receivingSide, f)
            }
            .orElse(
              recoveryOpt
                .map(_ =>
                  RecoveryMappingEditorException(
                    m,
                    receivingSide,
                    sentValue.map(_.toString).getOrElse("None")
                  )
                )
            )
      }
  }

  private def getRecoveryValue(recovery: Recovery, fieldDataType: Option[FieldDataType]) = {
    lazy val key =
      if (fieldDataType.contains(FieldDataType.OPTION)) "label"
      else "value"
    recovery.value
      .flatMap { o =>
        GsonCaseClassValueJsonService
          .write(o)
          .flatMap(j =>
            GsonCaseClassValueJsonService.read[Map[String, Object]](j, classOf[Map[String, Object]])
          )
          .toOption
          .flatMap(_.get(key))
          .map(_.asInstanceOf[String])
      }
  }

  private def getMappingsToCorrectFieldAndDirection(
      mappings: Seq[Mappings],
      correctDirections: Seq[String],
      swapSides: Boolean,
      f: EditorFieldValue
  ) =
    mappings
      // consider only mappings in the correct direction and for the correct field
      .filter { m: Mappings =>
        val correctDirection =
          correctDirections
            .exists(m.arrow.contains)
        lazy val toCorrectField =
          (if (!swapSides) m.local
           else m.remote)
            .exists(_.field.key == f.key)
        correctDirection && toCorrectField
      }

  // TODO reuse implementation across ScopeQueryService,  JcloudEditorFieldService and MappingService
  private def toValueStr(v: Object) =
    toStr("value")(v)

  private def toLabelStr(v: Object) =
    toStr("label")(v)

  private def toStr(key: String)(v: Object) = {
    def mapToStr(in: Map[String, Object]): Option[String] =
      in.get(key)
        .map(_.toString)

    v match {
      case _: java.util.Map[String, Object] =>
        mapToStr(
          v.asInstanceOf[java.util.Map[String, Object]].asScala.toMap
        )
      case _: Map[String, Object]           =>
        mapToStr(
          v
            .asInstanceOf[Map[String, Object]]
        )
      case _: String                        => Option(v.asInstanceOf[String])
      case _                                => Option.empty[String]
    }
  }

}
