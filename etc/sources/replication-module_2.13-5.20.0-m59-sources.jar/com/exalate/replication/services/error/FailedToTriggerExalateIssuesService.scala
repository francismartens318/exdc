package com.exalate.replication.services.error

import com.exalate.api.domain.IError
import com.exalate.replication.services.transport.value.IssueKeyValue

//todo ihor remove
class FailedToTriggerExalateIssuesService {

  def getFailedToTriggerIssues(triggerError: IError): Seq[IssueKeyValue] =
    Nil

}
