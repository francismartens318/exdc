package com.exalate.replication.services.error.retry

import scala.concurrent.Future

/** Should be used exclusively by the Rate Limited Task Processor Worker
  */
trait IRateLimitedTaskProcessorService {
  def processTaskQueue(): Future[None.type]
}
