package com.exalate.replication.services.error.retry

import java.text.SimpleDateFormat
import java.util.Date
import com.exalate.domain.error.retry.RateLimitedTask
import com.exalate.domain.exception.network.{RateLimitException, SecondaryRateLimitException}
import com.exalate.replication.services.api.error.retry.{
  IExponentialBackoffService,
  IRateLimitedTaskService
}
import com.google.inject.Singleton

import javax.inject.Inject
import play.api.{Configuration, Logger}

import scala.jdk.CollectionConverters._
import scala.concurrent.{blocking, ExecutionContext, Future, Promise}
import scala.concurrent.duration.{Duration, _}

object RateLimitedTaskService {
  private val LOG = Logger("com.exalate.replication.services.error.retry.RateLimitedTaskService")

  private[retry] val taskQueue: java.util.concurrent.ConcurrentLinkedQueue[RateLimitedTask[_]] =
    new java.util.concurrent.ConcurrentLinkedQueue[RateLimitedTask[_]]()

  private[retry] val secondaryTaskQueue: java.util.concurrent.ConcurrentLinkedQueue[RateLimitedTask[_]] =
    new java.util.concurrent.ConcurrentLinkedQueue[RateLimitedTask[_]]()

  private val INITIAL_DEFAULT_BACKOFF = 10.seconds
}

/** How is it supposed to be injected:
  * ```
  * val i:Binder = ...
  * i.bind(classOf[RateLimitedTaskService]).in(Scopes.SINGLETON)
  * i.bind(classOf[IRateLimitedTaskService]).to(classOf[RateLimitedTaskService])
  * i.bind(classOf[IRateLimitedTaskProcessorService]).to(classOf[RateLimitedTaskService])
  * ```
  * @inheritdoc
  * IRateLimitedTaskService
  * @inheritdoc
  * IRateLimitedTaskProcessorService
  */
@Singleton
class RateLimitedTaskService @Inject() (
    exponentialBackoffService: IExponentialBackoffService,
    config: Configuration
)(implicit ec: ExecutionContext)
    extends IRateLimitedTaskService
      with IRateLimitedTaskProcessorService {

  import RateLimitedTaskService._

  override def doRateLimitedTask[R](task: () => Future[R]): Future[R] = blocking(synchronized {
    LOG.debug(s"#doRateLimitedTask: going to execute a task `$task`")
    val promise = Promise[R]()
    val rateLimitedTask = RateLimitedTask(now, INITIAL_DEFAULT_BACKOFF, task, promise)
    if (taskQueue.size() > 0) {
      // if we already have rate limit task, we add task to queue with nextRetry of the very first task
      val firstRateLimitTask = taskQueue.peek()
      val newRateLimitTask = RateLimitedTask(
        firstRateLimitTask.nextRetry,
        firstRateLimitTask.prevBackoff,
        task,
        promise
      )
      taskQueue.add(newRateLimitTask)
    } else if (secondaryTaskQueue.size() > 0) {
      val firstRateLimitTask = secondaryTaskQueue.peek()
      val newRateLimitTask = RateLimitedTask(
        firstRateLimitTask.nextRetry,
        firstRateLimitTask.prevBackoff,
        task,
        promise,
        isSecondary = true
      )
      secondaryTaskQueue.add(newRateLimitTask)
    } else {
      executeTask(Some(rateLimitedTask))
        .map {
          case None    =>
          case Some(t) =>
            if (t.isSecondary)
              secondaryTaskQueue.add(t)
            else
              taskQueue.add(t)
        }
    }
    promise.future
  })

  def calculateNextRetry(
      nextRetryInFromIssueTracker: Option[Duration],
      previousBackoff: Duration
  ): Duration =
    nextRetryInFromIssueTracker.getOrElse(
      exponentialBackoffService.next(previousBackoff)
    )

  def calculateNextRetryDate(nextRetryIn: Duration): Date = {
    val nextRetryTime = now.getTime + nextRetryIn.toMillis
    new Date(nextRetryTime)
  }

  override def processTaskQueue(): Future[None.type] = {
    LOG.trace("Processing tasks queue")
    def nextTask(): Option[RateLimitedTask[_]] = Option(taskQueue.poll())
    def nextSecondaryTask(): Option[RateLimitedTask[_]] = Option(secondaryTaskQueue.poll())
    val allProcessedFuture = processQueue(nextTask)
    val allSecondaryProcessedFuture = processQueue(nextSecondaryTask)
    allProcessedFuture.foreach { tasksToAdd =>
      taskQueue.addAll(tasksToAdd.asJavaCollection)
    }
    allSecondaryProcessedFuture.foreach { tasksToAdd =>
      secondaryTaskQueue.addAll(tasksToAdd.asJavaCollection)
    }
    allProcessedFuture.map(_ => None)
    allSecondaryProcessedFuture.map(_ => None)
  }

  private def processQueue(
      nextTask: () => Option[RateLimitedTask[_]]
  ): Future[Seq[RateLimitedTask[_]]] =
    Stream
      .iterate(nextTask())(_ => nextTask())
      .takeWhile(_.isDefined)
      .foldLeft(Future.successful(Seq.empty[RateLimitedTask[_]])) {
        case (result, taskOpt) =>
          for {
            tasksToAdd <- result
            newTaskOpt <- executeTask(taskOpt)
            tasks = tasksToAdd ++ newTaskOpt
          } yield tasks
      }

  private def executeTask(taskOpt: Option[RateLimitedTask[_]]): Future[Option[RateLimitedTask[_]]] =
    taskOpt match {
      case None                                                            =>
        LOG.trace(s"#executeTask: no tasks in the queue")
        // if there are no tasks in the queue - we're done
        Future.successful(None)
      case Some(RateLimitedTask(nextRetry, prevBackoff, task, promise, _)) =>
        val curTimeNow = now
        if (curTimeNow.before(nextRetry)) {
          LOG.trace(
            s"#executeTask: `$task` is still to be executed in the future `${new SimpleDateFormat()
                .format(nextRetry)}` (now it is `${new SimpleDateFormat().format(now)}`)"
          )
          // if it's not the time yet, we re-submit the task
          Future.successful(taskOpt)
        } else {
          LOG.trace(
            s"#executeTask: executing `$task` (now it is `${new SimpleDateFormat().format(now)}`)"
          )
          try {
            val resultFuture = task()
            resultFuture
              .map { result =>
                LOG.debug(
                  s"#executeTask: executed `$task` " +
                    s"and it succeeded with a result `$result`"
                )
                promise.success(result)
                None
              }
              .recover {
                case RateLimitException(
                      _,
                      _,
                      nextRetryInFromIssueTracker,
                      rateLimit,
                      rateLimitRemaining
                    ) =>
                  LOG.error(
                    s"#executeTask: executed `$task` " +
                      s"and it failed due to rate limit: " +
                      s"nextRetryInFromIssueTracker=`$nextRetryInFromIssueTracker` " +
                      s"rateLimit=`$rateLimit` " +
                      s"rateLimitRemaining=`$rateLimitRemaining`"
                  )
                  getNextRateLimitedTask(
                    task,
                    nextRetryInFromIssueTracker,
                    prevBackoff,
                    promise,
                    isSecondary = false
                  )
                case SecondaryRateLimitException(_, _, nextRetryInFromIssueTracker) =>
                  LOG.error(
                    s"#executeTask: executed `$task` " +
                      s"and it failed due to the secondary rate limit: " +
                      s"nextRetryIn=`$nextRetryInFromIssueTracker`"
                  )
                  getNextRateLimitedTask(
                    task,
                    nextRetryInFromIssueTracker,
                    prevBackoff,
                    promise,
                    isSecondary = true
                  )
                case otherError                                                     =>
                  LOG.error(
                    s"#executeTask: executed `$task` " +
                      s"and it failed due to some other problem",
                    otherError
                  )
                  promise.failure(otherError)
                  None
              }
          } catch {
            case e: Exception =>
              LOG.debug(
                s"#executeTask: task `$task` " +
                  s"execution failed due to some coding problem",
                e
              )
              promise.failure(e)
              Future.successful(None)
          }
        }

    }

  private def getNextRateLimitedTask[R](
      task: () => Future[R],
      nextRetryInFromIssueTracker: Option[Duration],
      prevBackoff: Duration,
      promise: Promise[R],
      isSecondary: Boolean
  ): Option[RateLimitedTask[R]] = {
    // if we've failed again with the rate limit, we re-submit the task:
    val nextRetryIn = calculateNextRetry(nextRetryInFromIssueTracker, prevBackoff)
    val nextRetry = calculateNextRetryDate(nextRetryIn)

    val rateLimitedTask = RateLimitedTask(
      nextRetry,
      nextRetryIn,
      task,
      promise,
      isSecondary
    )
    Some(rateLimitedTask)
  }

  private def now = new Date()
}
