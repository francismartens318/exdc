package com.exalate.replication.services.error.retry

import com.exalate.api.domain.IIssueKey
import com.exalate.api.domain.blob.event.IBlobEvent
import com.exalate.api.domain.blob.request.IBlobRequest
import com.exalate.api.domain.error.IRetryContext
import com.exalate.api.domain.event.ISyncEvent
import com.exalate.api.domain.request.ISyncRequest
import com.exalate.api.exception.RetriableException
import com.exalate.api.persistence.replication.event.IEventReplicationRepository
import com.exalate.api.persistence.retrycontext.IRetryContextRepository
import com.exalate.domain.replication.{BasicSyncEvent, BasicSyncRequest}
import com.exalate.error.services.api.IBugExceptionCategoryService
import com.exalate.replication.services.api.error.retry.IRetryContextService
import com.exalate.replication.services.api.error.{IErrorService, SyncContext}
import com.exalate.replication.services.api.replication.worker.IWorkerNotificationService
import com.exalate.replication.services.error.ErrorHandler
import com.exalate.services.utils.FutureUtils
import play.api.Logger

import java.time.Instant
import javax.inject.Inject
import scala.concurrent.{ExecutionContext, Future}

class RetryContextService @Inject() (
    retryContextRepository: IRetryContextRepository,
    errorHandler: ErrorHandler,
    errorService: IErrorService,
    replicationRepository: IEventReplicationRepository,
    workerNotificationService: IWorkerNotificationService,
    bugExceptionCategoryService: IBugExceptionCategoryService
)(implicit ec: ExecutionContext)
    extends IRetryContextService {

  private val LOG = Logger("application.services.retry.RetryContextService")

  override def shouldRetry(syncRequestId: Int): Future[Boolean] =
    retryContextRepository.findBySyncRequest(syncRequestId) map {
      case Some(retryContext) => retryContext.getNextRetry.toInstant.isBefore(Instant.now)
      case _                  => true
    }

  override def shouldRetry(syncEvent: ISyncEvent): Future[Boolean] =
    retryContextRepository.findBySyncEvent(syncEvent) map {
      case Some(retryContext) => retryContext.getNextRetry.toInstant.isBefore(Instant.now)
      case _                  => true
    }

  override def shouldRetry(blobEvent: IBlobEvent): Future[Boolean] =
    retryContextRepository.findByBlobEvent(blobEvent) map {
      case Some(retryContext) => retryContext.getNextRetry.toInstant.isBefore(Instant.now)
      case _                  => true
    }

  override def shouldRetry(blobRequest: IBlobRequest): Future[Boolean] =
    retryContextRepository.findByBlobRequest(blobRequest) map {
      case Some(retryContext) => retryContext.getNextRetry.toInstant.isBefore(Instant.now)
      case _                  => true
    }

  override def handle(exception: RetriableException, context: SyncContext): Future[None.type] =
    shouldCreateError(exception, context)
      .flatMap { shouldCreateError =>
        if (shouldCreateError) {
          resetAttemptsRetryContext(exception, context)
          LOG.info(
            getLoggingMessageFromContext(exception, context, shouldCreateError, None),
            exception
          )
          errorHandler.handleNonRetriableError(exception, context)
        } else {
          upsertRetryContext(exception, context).map { retryContext =>
            LOG.info(
              getLoggingMessageFromContext(exception, context, shouldCreateError, Some(retryContext))
            )
          }
        }
      }
      .map(_ => None)

  private def getLoggingMessageFromContext(
      exception: RetriableException,
      context: SyncContext,
      shouldCreateError: Boolean,
      retryContextOpt: Option[IRetryContext]
  ): String = context match {
    case SyncContext(_, _, _, _, _, _, _, Some(syncEvent: ISyncEvent), _, _, _, _) =>
      getLoggingMessageBySyncEvent(shouldCreateError, retryContextOpt, syncEvent)

    case SyncContext(_, _, _, _, _, _, _, _, Some(syncRequest: ISyncRequest), _, _, _) =>
      getLoggingMessageBySyncRequest(shouldCreateError, retryContextOpt, syncRequest)

    case SyncContext(_, _, _, _, _, _, _, _, _, Some(basicSyncRequest: BasicSyncRequest), _, _) =>
      getLoggingMessageByBasicSyncRequest(shouldCreateError, retryContextOpt, basicSyncRequest)

    case SyncContext(_, _, _, _, _, _, _, _, _, _, Some(blobEvent: IBlobEvent), _) =>
      getLoggingMessageByBlobEvent(shouldCreateError, retryContextOpt, blobEvent)

    case SyncContext(_, _, _, _, _, _, _, _, _, _, _, Some(blobRequest: IBlobRequest)) =>
      getLoggingMessageByBlobRequest(shouldCreateError, retryContextOpt, blobRequest)

    case SyncContext(Some(syncEventId), _, _, _, _, localIssueKeyOpt, _, _, _, _, _, _) =>
      val syncEventOpt = FutureUtils.resultInf(replicationRepository.getSyncEvent(syncEventId))
      syncEventOpt match {
        case Some(syncEvent) =>
          getLoggingMessageBySyncEvent(shouldCreateError, retryContextOpt, syncEvent)
        case None            =>
          getLoggingMessageBySyncEventId(
            shouldCreateError,
            retryContextOpt,
            syncEventId,
            localIssueKeyOpt
          )
      }
  }

  private def getLoggingMessageBySyncEventId(
      shouldCreateError: Boolean,
      retryContextOpt: Option[IRetryContext],
      syncEventId: Int,
      localIssueKeyOpt: Option[IIssueKey]
  ) = {
    val localIssueMsg = localIssueKeyOpt
      .map(localIssueKey => s" for local issue `${localIssueKey.getURN}`")
      .getOrElse("")
    if (shouldCreateError)
      s"#transitioning event `$syncEventId`$localIssueMsg: retry context has reached its limit, an error will be created"
    else
      s"#transitioning event `$syncEventId`$localIssueMsg: retry context `${retryContextOpt.get.getId}` has been upserted"
  }

  private def getLoggingMessageByBlobRequest(
      shouldCreateError: Boolean,
      retryContextOpt: Option[IRetryContext],
      blobRequest: IBlobRequest
  ) = {
    val blobRequestId = blobRequest.getId
    val syncRequestId = blobRequest.getSyncRequest.getId
    val remoteIssueUrn = blobRequest.getSyncRequest.getReplica.getIssueKey.getURN
    if (shouldCreateError)
      s"#transitioning blob request `$blobRequestId` for sync request `$syncRequestId` for remote issue `$remoteIssueUrn`: retry context has reached its limit, an error will be created"
    else
      s"#transitioning blob request `$blobRequestId` for sync request `$syncRequestId` for remote issue `$remoteIssueUrn`: retry context `${retryContextOpt.get.getId}` has been upserted"
  }

  private def getLoggingMessageByBlobEvent(
      shouldCreateError: Boolean,
      retryContextOpt: Option[IRetryContext],
      blobEvent: IBlobEvent
  ) = {
    val blobEventId = blobEvent.getId
    val syncEventId = blobEvent.getSyncEvent.getId
    val localIssueUrn = blobEvent.getSyncEvent.getLocalReplica.getIssueKey.getURN
    if (shouldCreateError)
      s"#transitioning blob event `$blobEventId` for sync event `$syncEventId` for local issue `$localIssueUrn`: retry context has reached its limit, an error will be created"
    else
      s"#transitioning blob event `$blobEventId` for sync event `$syncEventId` for local issue `$localIssueUrn`: retry context `${retryContextOpt.get.getId}` has been upserted"
  }

  private def getLoggingMessageBySyncRequest(
      shouldCreateError: Boolean,
      retryContextOpt: Option[IRetryContext],
      syncRequest: ISyncRequest
  ) = {
    val syncRequestId = syncRequest.getId
    val remoteIssueUrn = syncRequest.getReplica.getIssueKey.getURN
    if (shouldCreateError)
      s"#transitioning request `$syncRequestId` for remote issue `$remoteIssueUrn`: retry context has reached its limit, an error will be created"
    else
      s"#transitioning request `$syncRequestId` for remote issue `$remoteIssueUrn`: retry context `${retryContextOpt.get.getId}` has been upserted"
  }

  private def getLoggingMessageByBasicSyncRequest(
      shouldCreateError: Boolean,
      retryContextOpt: Option[IRetryContext],
      basicSyncRequest: BasicSyncRequest
  ) = {
    val syncRequestId = basicSyncRequest.id
    val remoteIssueUrn = basicSyncRequest.replica.getIssueKey.getURN
    if (shouldCreateError)
      s"#transitioning request `$syncRequestId` for remote issue `$remoteIssueUrn`: retry context has reached its limit, an error will be created"
    else
      s"#transitioning request `$syncRequestId` for remote issue `$remoteIssueUrn`: retry context `${retryContextOpt.get.getId}` has been upserted"
  }

  private def getLoggingMessageBySyncEvent(
      shouldCreateError: Boolean,
      retryContextOpt: Option[IRetryContext],
      syncEvent: ISyncEvent
  ) = {
    val syncEventId = syncEvent.getId
    val localIssueUrn = syncEvent.getLocalReplica.getIssueKey.getURN
    if (shouldCreateError)
      s"#transitioning event `$syncEventId` for local issue `$localIssueUrn`: retry context has reached its limit, an error will be created"
    else
      s"#transitioning event `$syncEventId` for local issue `$localIssueUrn`: retry context `${retryContextOpt.get.getId}` has been upserted"
  }

  private def shouldCreateError(error: RetriableException, context: SyncContext): Future[Boolean] =
    context match {
      case SyncContext(_, _, _, _, _, _, _, Some(syncEvent: ISyncEvent), _, _, _, _)              =>
        shouldCreateErrorForSyncEvent(error, syncEvent)
      case SyncContext(_, _, _, _, _, _, _, _, Some(syncRequest: ISyncRequest), _, _, _)          =>
        shouldCreateErrorForSyncRequest(error, syncRequest)
      case SyncContext(_, _, _, _, _, _, _, _, _, Some(basicSyncRequest: BasicSyncRequest), _, _) =>
        shouldCreateErrorForBasicSyncRequest(error, basicSyncRequest)
      case SyncContext(_, _, _, _, _, _, _, _, _, _, Some(blobEvent: IBlobEvent), _)              =>
        retryContextRepository
          .findByBlobEvent(blobEvent)
          .map(isRetryLimitReached(_, error))
      case SyncContext(_, _, _, _, _, _, _, _, _, _, _, Some(blobRequest: IBlobRequest))          =>
        retryContextRepository
          .findByBlobRequest(blobRequest)
          .map(isRetryLimitReached(_, error))
      case SyncContext(Some(syncEventId), _, _, _, _, _, _, _, _, _, _, _)                        =>
        replicationRepository.getSyncEvent(syncEventId).flatMap {
          case Some(syncEvent) => shouldCreateErrorForSyncEvent(error, syncEvent)
          case None            =>
            val exception = bugExceptionCategoryService.generateSyncContextHasNoEntityBugException(
              context.connection.get.getName,
              context.localIssueKeyOpt.map(_.getURN),
              context.remoteIssueKeyOpt.map(_.getURN),
              error
            )
            LOG.error("Synchronizations failed with unexpected error.", exception)
            Future.failed(exception)
        }
      case _                                                                                      =>
        val exception = bugExceptionCategoryService.generateSyncContextHasNoEntityBugException(
          context.connection.get.getName,
          context.localIssueKeyOpt.map(_.getURN),
          context.remoteIssueKeyOpt.map(_.getURN),
          error
        )
        LOG.error("Synchronizations failed with unexpected error.", exception)
        Future.failed(exception)
    }

  private def shouldCreateErrorForSyncRequest(
      error: RetriableException,
      syncRequest: ISyncRequest
  ): Future[Boolean] =
    retryContextRepository
      .findBySyncRequest(syncRequest.getId)
      .map(isRetryLimitReached(_, error))
      .flatMap { retryLimitReached =>
        if (retryLimitReached && BasicSyncRequest.isCleanupRequest(syncRequest)) {
          errorService.hasErrorReferencingSyncRequest(syncRequest.getId).map(exists => !exists)
        } else Future.successful(retryLimitReached)
      }

  private def shouldCreateErrorForBasicSyncRequest(
      error: RetriableException,
      basicSyncRequest: BasicSyncRequest
  ): Future[Boolean] =
    retryContextRepository
      .findBySyncRequest(basicSyncRequest.id)
      .map(isRetryLimitReached(_, error))
      .flatMap { retryLimitReached =>
        if (retryLimitReached && BasicSyncRequest.isCleanupRequest(basicSyncRequest)) {
          errorService.hasErrorReferencingSyncRequest(basicSyncRequest.id).map(exists => !exists)
        } else Future.successful(retryLimitReached)
      }

  private def shouldCreateErrorForSyncEvent(error: RetriableException, syncEvent: ISyncEvent) =
    retryContextRepository.findBySyncEvent(syncEvent).map(isRetryLimitReached(_, error)).flatMap {
      retryLimitReached =>
        if (retryLimitReached && BasicSyncEvent.isCleanupEvent(syncEvent)) {
          errorService.hasErrorReferencingSyncEvent(syncEvent.getId).map(exists => !exists)
        } else Future.successful(retryLimitReached)
    }

  private def getErrorMessage(error: RetriableException, context: SyncContext): String = {
    val relationMsg = s"for connection `${context.connection.get.getName}`"
    val localIssueMsg =
      context.localIssueKeyOpt.map(issueKey => s"for local issue ${issueKey.getURN}").getOrElse("")
    val remoteIssueMsg =
      context.remoteIssueKeyOpt.map(issueKey => s"for remote issue ${issueKey.getURN}").getOrElse("")
    s"$relationMsg $localIssueMsg $remoteIssueMsg"
  }

  private def isRetryLimitReached(retryContextOpt: Option[IRetryContext], e: Throwable): Boolean =
    retryContextOpt match {
      case Some(retryContext) =>
        retryContext.getAttemptedRetries >= getRetryLimit(e)
      case None               => false
    }

  private def upsertRetryContext(
      error: RetriableException,
      context: SyncContext
  ): Future[IRetryContext] = {
    val secondsToNextRetry = getSecondsToNextRetry(error)
    context match {
      case SyncContext(_, _, _, _, _, _, _, Some(syncEvent: ISyncEvent), _, _, _, _)     =>
        val retryContextFuture =
          retryContextRepository.upsertRetryContext(syncEvent, Instant.now(), secondsToNextRetry)
        retryContextFuture.foreach { _ =>
          workerNotificationService.sendProcessEventsNotification(secondsToNextRetry)
        }
        retryContextFuture
      case SyncContext(_, _, _, _, _, _, _, _, Some(syncRequest: ISyncRequest), _, _, _) =>
        val retryContextFuture = retryContextRepository.upsertRetryContext(
          syncRequest.getId,
          Instant.now(),
          secondsToNextRetry
        )
        retryContextFuture.foreach { _ =>
          workerNotificationService.sendProcessRequestsNotification(secondsToNextRetry)
        }
        retryContextFuture

      case SyncContext(_, _, _, _, _, _, _, _, _, Some(basicSyncRequest: BasicSyncRequest), _, _) =>
        val retryContextFuture = retryContextRepository.upsertRetryContext(
          basicSyncRequest.id,
          Instant.now(),
          secondsToNextRetry
        )
        retryContextFuture.foreach { _ =>
          workerNotificationService.sendProcessRequestsNotification(secondsToNextRetry)
        }
        retryContextFuture

      case SyncContext(_, _, _, _, _, _, _, _, _, _, Some(blobEvent: IBlobEvent), _) =>
        val retryContextFuture =
          retryContextRepository.upsertRetryContext(blobEvent, Instant.now(), secondsToNextRetry)
        retryContextFuture.foreach { _ =>
          workerNotificationService.sendProcessBlobEventsNotification(secondsToNextRetry)
        }
        retryContextFuture

      case SyncContext(_, _, _, _, _, _, _, _, _, _, _, Some(blobRequest: IBlobRequest)) =>
        val retryContextFuture =
          retryContextRepository.upsertRetryContext(blobRequest, Instant.now(), secondsToNextRetry)
        retryContextFuture.foreach { _ =>
          workerNotificationService.sendProcessBlobRequestsNotification(secondsToNextRetry)
        }
        retryContextFuture

      case SyncContext(Some(syncEventId), _, _, _, _, _, _, _, _, _, _, _) =>
        val syncEventOpt = FutureUtils.resultInf(replicationRepository.getSyncEvent(syncEventId))
        syncEventOpt match {
          case Some(syncEvent) =>
            val retryContextFuture =
              retryContextRepository.upsertRetryContext(syncEvent, Instant.now(), secondsToNextRetry)
            retryContextFuture.foreach { _ =>
              workerNotificationService.sendProcessEventsNotification(secondsToNextRetry)
            }
            retryContextFuture
          case None            =>
            val exception = bugExceptionCategoryService.generateSyncContextHasNoEntityBugException(
              context.connection.get.getName,
              context.localIssueKeyOpt.map(_.getURN),
              context.remoteIssueKeyOpt.map(_.getURN),
              error
            )
            LOG.error("Synchronizations failed with unexpected error.", exception)
            Future.failed(exception)
        }
    }
  }

  private def resetAttemptsRetryContext(
      error: RetriableException,
      context: SyncContext
  ): Future[IRetryContext] = {
    val secondsToNextRetry = getSecondsToNextRetry(error)
    context match {
      case SyncContext(_, _, _, _, _, _, _, Some(syncEvent: ISyncEvent), _, _, _, _) =>
        retryContextRepository.resetAttemptsRetryContext(
          syncEvent,
          Instant.now(),
          secondsToNextRetry
        )

      case SyncContext(_, _, _, _, _, _, _, _, Some(syncRequest: ISyncRequest), _, _, _) =>
        retryContextRepository.resetAttemptsRetryContext(
          syncRequest.getId,
          Instant.now(),
          secondsToNextRetry
        )

      case SyncContext(_, _, _, _, _, _, _, _, _, Some(basicSyncRequest: BasicSyncRequest), _, _) =>
        retryContextRepository.resetAttemptsRetryContext(
          basicSyncRequest.id,
          Instant.now(),
          secondsToNextRetry
        )

      case SyncContext(_, _, _, _, _, _, _, _, _, _, Some(blobEvent: IBlobEvent), _) =>
        retryContextRepository.resetAttemptsRetryContext(
          blobEvent,
          Instant.now(),
          secondsToNextRetry
        )

      case SyncContext(_, _, _, _, _, _, _, _, _, _, _, Some(blobRequest: IBlobRequest)) =>
        retryContextRepository.resetAttemptsRetryContext(
          blobRequest,
          Instant.now(),
          secondsToNextRetry
        )

      case SyncContext(Some(syncEventId), _, _, _, _, _, _, _, _, _, _, _) =>
        val syncEventOpt = FutureUtils.resultInf(replicationRepository.getSyncEvent(syncEventId))
        syncEventOpt match {
          case Some(syncEvent) =>
            retryContextRepository.resetAttemptsRetryContext(
              syncEvent,
              Instant.now(),
              secondsToNextRetry
            )
          case None            =>
            val exception = bugExceptionCategoryService.generateSyncContextHasNoEntityBugException(
              context.connection.get.getName,
              context.localIssueKeyOpt.map(_.getURN),
              context.remoteIssueKeyOpt.map(_.getURN),
              error
            )
            LOG.error("Synchronizations failed with unexpected error.", exception)
            Future.failed(exception)
        }
    }
  }

  private def getSecondsToNextRetry(e: Throwable): Int =
    30

  private def getRetryLimit(e: Throwable): Int =
    8

}
