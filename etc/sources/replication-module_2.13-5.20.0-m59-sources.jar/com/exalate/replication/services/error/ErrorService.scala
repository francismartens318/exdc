package com.exalate.replication.services.error

import com.exalate.api.domain._
import com.exalate.api.domain.blob.event.IBlobEvent
import com.exalate.api.domain.blob.request.IBlobRequest
import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.event.ISyncEvent
import com.exalate.api.domain.request.ISyncRequest
import com.exalate.api.domain.trigger.ITrigger
import com.exalate.api.exception.CategorizedException
import com.exalate.api.persistence.error.IErrorRepository
import com.exalate.api.persistence.replication.request.IRequestReplicationRepository
import com.exalate.api.persistence.twintrace.ITwinTraceRepository
import com.exalate.basic.domain.BasicIssueKey
import com.exalate.basic.domain.error.NonPersistentError
import com.exalate.domain.editor.error.EditorError
import com.exalate.domain.editor.error.EditorErrorFormatters._
import com.exalate.domain.exception.editor.EditorCategorizedException
import com.exalate.domain.exception.trigger.ExalateTriggerException
import com.exalate.domain.replication.{BasicSyncEvent, BasicSyncRequest}
import com.exalate.error.services.api.IBugExceptionCategoryService
import com.exalate.persistence.error.ErrorRepository.PLUGIN_EXPIRED_ROOT_CAUSE_ERROR_TYPE_NAME
import com.exalate.replication.services.api.error.retry.IRetryContextService
import com.exalate.replication.services.api.error.{IErrorService, SyncContext}
import com.exalate.replication.services.api.replication.IEventSchedulerNotificationService
import com.exalate.replication.services.api.replication.worker.IWorkerNotificationService
import com.exalate.replication.services.api.transport.smtp.IMailService
import com.exalate.replication.services.api.trigger.ITriggerService
import com.exalate.replication.services.config.ExalateErrorMessageService
import com.google.inject.Provider
import org.apache.commons.lang3.exception.ExceptionUtils
import play.api.Logger
import play.api.libs.json.Json

import java.sql.Date
import java.util
import javax.inject.Inject
import scala.concurrent.{ExecutionContext, Future}

class ErrorService @Inject() (
    errorRepository: IErrorRepository,
    exalateErrorMessageService: ExalateErrorMessageService,
    workerNotificationService: IWorkerNotificationService,
    mailService: IMailService,
    failedToTriggerIssuesService: FailedToTriggerExalateIssuesService,
    triggerServiceProvider: Provider[ITriggerService],
    eventSchedulerServiceProvider: Provider[IEventSchedulerNotificationService],
    retryContextServiceProvider: Provider[IRetryContextService],
    bugExceptionCategoryService: IBugExceptionCategoryService,
    twinTraceRepository: ITwinTraceRepository,
    requestReplicationRepository: IRequestReplicationRepository
)(implicit ec: ExecutionContext)
    extends IErrorService {

  val LOG = Logger("application.services.error.ErrorService")

  /** Calls {@link createErrorInternal} in order to create error
    * @param errorEntityType
    *   level of the error: NODE,INSTANCE,RELATION,TRIGGER,ISSUE,WARNING
    * @param t
    *   Throwable/Exception
    * @param connection
    * @param localIssueKey
    * @param remoteIssueKey
    * @param errorActTypeOpt
    * @param errorKey
    *   key of the error
    * @return
    *   id of the saved error
    */
  override def createError(
      errorEntityType: ErrorEntityType,
      t: Throwable,
      connection: IConnection,
      localIssueKey: Option[IIssueKey],
      remoteIssueKey: Option[IIssueKey],
      errorActTypeOpt: Option[ErrorActType],
      errorKey: Option[String]
  ): Future[Option[Int]] =
    createErrorInternal(
      errorEntityType,
      t,
      Option(connection),
      localIssueKey,
      remoteIssueKey,
      None,
      None,
      None,
      errorActTypeOpt,
      errorKey
    )

  /** Creates transport error i.e error with key `REPLICATION_TRANSPORT`
    * @param e
    *   categorized exception
    * @param context
    * @return
    *   id of the saved error
    */
  def createTransportError(e: CategorizedException, context: SyncContext): Future[Option[Int]] = {
    val errorKey: String = ErrorKeys.getReplicationTransportErrorKey(context.connection.get.getID)
    createErrorInternal(
      e.getErrorEntityType,
      e,
      context.connection,
      context.localIssueKeyOpt,
      context.remoteIssueKeyOpt,
      context.syncEventOpt,
      context.syncRequestOpt,
      context.basicSyncRequestOpt,
      None,
      Some(errorKey)
    )
  }

  /** Creates polling transport error i.e error with key `POLLING_TRANSPORT`
    * @param exception
    * @param connection
    * @return
    *   id of the saved error
    */
  def createPollingTransportError(exception: Exception, connection: IConnection): Future[Option[Int]] = {
    val errorKey = ErrorKeys.getPollingErrorKey(connection.getID)
    val stackTrace = ExceptionUtils.getStackTrace(exception)
    val rootCauseInfo = exception.getClass.getSimpleName

    val npError = new NonPersistentError(
      new Date(System.currentTimeMillis()),
      stackTrace,
      rootCauseInfo + " for connection " + connection.getName,
      "A warning error is not blocking exalate synchronization.",
      ErrorEntityType.WARNING,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      errorKey
    )
    errorRepository.create(npError).map(_.map(_.getId))
  }

  /** Creates error
    * @param ce
    *   Categorized Exception
    * @param connection
    * @param localIssueKey
    * @param remoteIssueKey
    * @param errorActTypeOpt
    * @return
    *   id of the saved error
    */
  override def createError(
      ce: CategorizedException,
      connection: IConnection,
      localIssueKey: Option[IIssueKey],
      remoteIssueKey: Option[IIssueKey],
      errorActTypeOpt: Option[ErrorActType]
  ): Future[Option[Int]] = createError(
    ce.getErrorEntityType,
    ce,
    connection,
    localIssueKey,
    remoteIssueKey,
    errorActTypeOpt
  )

  /** Creates error
    * @param e
    *   Categorized Exception
    * @param context
    * @param errorKey
    * @return
    *   id of the saved error
    */
  override def createError(
      e: CategorizedException,
      context: SyncContext,
      errorKey: Option[String]
  ): Future[Option[Int]] = createError(e.getErrorEntityType, e, context, errorKey)

  /** Creates error and save it to DB
    *
    * @param errorEntityType
    *   \- level of the error: NODE,INSTANCE,RELATION,TRIGGER,ISSUE,WARNING
    * @param t
    *   throwable/exception
    * @param connection
    * @param localIssueKey
    * @param remoteIssueKey
    * @param syncEvent
    * @param syncRequest
    * @param basicSyncRequest
    * @param errorActTypeOpt
    * @param key
    *   key of the error
    * @return
    *   id of the saved error
    */
  private def createErrorInternal(
      errorEntityType: ErrorEntityType,
      t: Throwable,
      connection: Option[IConnection],
      localIssueKey: Option[IIssueKey],
      remoteIssueKey: Option[IIssueKey],
      syncEvent: Option[ISyncEvent],
      syncRequest: Option[ISyncRequest],
      basicSyncRequest: Option[BasicSyncRequest],
      errorActTypeOpt: Option[ErrorActType],
      key: Option[String]
  ): Future[Option[Int]] =
    key.map(errorRepository.errorWithKeyExists).getOrElse(Future.successful(false)).flatMap {
      case true  => Future.successful(None)
      case false =>
        val requestOptFut = syncRequest match {
          case Some(sr) => Future.successful(Some(sr))
          case _        =>
            // NonPersistentError doesn't have a direct reference to BasicSyncRequest so we need to obtain an ISyncRequest
            basicSyncRequest
              .map { basicReq =>
                requestReplicationRepository.getSyncRequestById(basicReq.id)
              }
              .getOrElse(Future.successful(None))
        }

        val npErrorFut = requestOptFut.map { requestOpt =>
          val npError = new NonPersistentError(
            new Date(System.currentTimeMillis()),
            ExceptionUtils.getStackTrace(t),
            exalateErrorMessageService.generateRootCauseErrorTypeNameIfPresent(t),
            // FIXME get locale from outside
            exalateErrorMessageService.generateMessageWithDocLinkIfPresent(t)(None).getOrElse(""),
            errorEntityType,
            errorActTypeOpt.orNull,
            null,
            null,
            connection.orNull,
            connection.map(_.getRemoteInstance).orNull,
            localIssueKey.orNull,
            remoteIssueKey.orNull,
            syncEvent.orNull,
            requestOpt.orNull,
            null,
            null,
            null,
            localIssueKey.map(_.getFieldValues).getOrElse(new util.HashMap[String, String]()),
            null,
            key.orNull
          )
          t match {
            case e: EditorCategorizedException =>
              val editorErrorValueStr = Json.stringify(Json.toJson(e.editorError))
              npError.getFieldValues.put("editor", editorErrorValueStr)
            case _                             =>
          }

          npError
        }

        val createFuture: Future[Option[IError]] = npErrorFut.flatMap(errorRepository.create)

        createFuture.map(_.map(mailService.sendErrorMail))

        createFuture.map {
          case Some(error) =>
            val cleanupError =
              (Option(error.getSyncEvent), Option(error.getSyncRequest)) match {
                case (Some(se), Some(sr)) =>
                  BasicSyncEvent.isCleanupEvent(se) || BasicSyncRequest.isCleanupRequest(sr)
                case (Some(se), None)     => BasicSyncEvent.isCleanupEvent(se)
                case (None, Some(sr))     => BasicSyncRequest.isCleanupRequest(sr)
                case _                    => false
              }
            if (cleanupError) workerNotificationService.fireAllWorkerNotifications()

            Some(error.getId)
          case _           => None
        }
    }

  /** Creates error
    * @param errorEntityType
    * @param t
    *   throwable/exception
    * @param context
    * @param errorKey
    * @return
    *   id of the saved error
    */
  override def createError(
      errorEntityType: ErrorEntityType,
      t: Throwable,
      context: SyncContext,
      errorKey: Option[String]
  ): Future[Option[Int]] =
    createErrorInternal(
      errorEntityType,
      t,
      context.connection,
      context.localIssueKeyOpt,
      context.remoteIssueKeyOpt,
      context.syncEventOpt,
      context.syncRequestOpt,
      context.basicSyncRequestOpt,
      None,
      errorKey
    )

  /** Calls {@link IErrorRepository.hasErrorReferencingSyncEvent} to check whether ErrorTable has
    * errors that corresponds provide sync event id
    * @param syncEventId
    *   id of a sync event
    * @return
    *   true or false
    */
  override def hasErrorReferencingSyncEvent(syncEventId: Int): Future[Boolean] =
    errorRepository.hasErrorReferencingSyncEvent(syncEventId)

  /** Calls {@link IErrorRepository.hasErrorReferencingSyncRequest} to check check whether
    * ErrorTable has errors that corresponds provide sync request id
    * @param syncRequestId
    *   id of a sync request
    * @return
    *   true or false
    */
  override def hasErrorReferencingSyncRequest(syncRequestId: Int): Future[Boolean] =
    errorRepository.hasErrorReferencingSyncRequest(syncRequestId)

  /** Checks whether there exist blockers for provide trigger, connection, instance or issue (local
    * or remote) obtained from syncEvent, and try to resolve it
    * @param syncEvent
    * @return
    *   true if there is no errors or they were resolved
    */
  override def isOk(syncEvent: ISyncEvent): Future[Boolean] =
    for {
      hasErrors <- errorRepository.hasBlockers(
        None,
        Option(syncEvent.getConnection),
        Option(syncEvent.getConnection.getRemoteInstance),
        Option(syncEvent.getLocalReplica.getIssueKey),
        Option(syncEvent.getRemoteReplica).map(_.getIssueKey)
      )
      hasNoErrors = !hasErrors
      ok <-
        if (hasNoErrors) retryContextServiceProvider.get().shouldRetry(syncEvent)
        else Future.successful(false)
    } yield ok

  /** Checks whether there exist errors for provided connection
    * @param connection
    * @return
    *   true or false
    */
  override def isOk(connection: IConnection): Future[Boolean] =
    errorRepository
      .hasBlockers(
        None,
        Option(connection),
        Option(connection.getRemoteInstance),
        None,
        None
      )
      .map(hasErrors => !hasErrors)

  /** Checks whether there exist errors
    * @return
    *   true or false
    */
  override def isOk(): Future[Boolean] =
    errorRepository
      .hasBlockers(
        None,
        None,
        None,
        None,
        None
      )
      .map(hasErrors => !hasErrors)

  /** Checks whether there exist errors for provided trigger
    * @param trigger
    * @return
    *   true or false
    */
  override def isOkForTriggerPoll(trigger: ITrigger): Future[Boolean] =
    errorRepository
      .hasBlockers(
        Some(trigger),
        Some(trigger.getConnection),
        Some(trigger.getConnection.getRemoteInstance),
        None,
        None
      )
      .map(hasErrors => !hasErrors)

  /** Resolves error and reschedules synchronization
    * @param errorId
    *   if of the error that should be resolved
    * @return
    *   None
    */
  override def resolveErrorAndRescheduleSync(errorId: Int): Future[None.type] =
    errorRepository.get(errorId).flatMap {
      case Some(error) =>
        val e = errorRepository.delete(errorId).flatMap { _ =>
          val connection = error.getConnection
          (Option(error.getActType), Option(error.getIssueKey)) match {
            case (Some(ErrorActType.SYNC), Some(issueKey))    =>
              LOG.debug(s"Resolving error with id $errorId and error act type SYNC")
              eventSchedulerServiceProvider.get.scheduleExalateOrUpdateEvent(connection, issueKey)
              Future.successful(None)
            case (Some(ErrorActType.PAIR), Some(issueKey))    =>
              LOG.debug(s"Resolving error with id $errorId and error act type PAIR")
              eventSchedulerServiceProvider.get.scheduleExalateOrUpdateEvent(connection, issueKey)
              Future.successful(None)
            case (Some(ErrorActType.CONNECT), Some(issueKey)) =>
              LOG.debug(s"Resolving error with id $errorId and error act type CONNECT")
              eventSchedulerServiceProvider.get
                .scheduleConnectEvent(connection, issueKey, error.getConnectRemoteIssueUrn, None)
              Future.successful(None)
            case (Some(ErrorActType.DELETE), Some(issueKey))  =>
              LOG.debug(s"Resolving error with id $errorId and error act type DELETE")
              eventSchedulerServiceProvider.get.scheduleDeleteEvent(connection, issueKey)
              Future.successful(None)
            case (Some(ErrorActType.TRIGGER), _)              =>
              LOG.debug(s"Resolving error with id $errorId and error act type TRIGGER")
              val issueKeys = failedToTriggerIssuesService
                .getFailedToTriggerIssues(error)
                .map(i => new BasicIssueKey(i.getId, i.urn, i.entityType.getOrElse("issue")))
              val triggerService = triggerServiceProvider.get
              val trigger = error.getTrigger

              triggerService
                .getIssueKeysUnderTrigger(trigger)
                .map(_.intersect(issueKeys))
                .map(iks => triggerService.executeTriggerForIssueKeys(trigger, iks))
                .map(_ => None)

            case _ =>
              LOG.debug(s"Resolving error with id $errorId")
              Future.successful(None)
          }
        }
        e.foreach(_ => workerNotificationService.fireAllWorkerNotifications())
        e
      case None        => Future.successful(None)
    }

  /** Checks whether there exist errors for provided blob event
    * @param toProcess
    *   blob event
    * @return
    *   true or false
    */
  override def isOk(toProcess: IBlobEvent): Future[Boolean] =
    for {
      hasErrors <- errorRepository.hasBlockers(
        None,
        Option(toProcess.getSyncEvent.getConnection),
        Option(toProcess.getSyncEvent.getConnection.getRemoteInstance),
        Option(toProcess.getSyncEvent.getLocalReplica.getIssueKey),
        Option(toProcess.getSyncEvent.getRemoteReplica).map(_.getIssueKey)
      )
      hasNoErrors = !hasErrors
      ok <-
        if (hasNoErrors) retryContextServiceProvider.get().shouldRetry(toProcess)
        else Future.successful(false)
    } yield ok

  /** Checks whether there exist errors for provided blob request
    * @param toProcess
    *   blob request
    * @return
    *   true or false
    */
  override def isOk(toProcess: IBlobRequest): Future[Boolean] =
    for {
      localKey <- getLocalIssueKey(toProcess.getSyncRequest)
      hasErrors <- errorRepository.hasBlockers(
        None,
        Option(toProcess.getSyncRequest.getConnection),
        Option(toProcess.getSyncRequest.getConnection.getRemoteInstance),
        localKey,
        Option(toProcess.getSyncRequest.getReplica).map(_.getIssueKey)
      )
      hasNoErrors = !hasErrors
      ok <-
        if (hasNoErrors) retryContextServiceProvider.get().shouldRetry(toProcess)
        else Future.successful(false)
    } yield ok

  /** Checks whether there exist errors for provided sync request
    * @param syncRequest
    * @return
    *   true or false
    */
  override def isOk(syncRequest: ISyncRequest): Future[Boolean] =
    // TODO: reuse here the method created on event scheduler service for getting local issue key from sync request. The method could be placed into some sort of SyncRequestService / Utils
    for {
      localKey <- getLocalIssueKey(syncRequest)
      hasErrors <- errorRepository.hasBlockers(
        None,
        Option(syncRequest.getConnection),
        Option(syncRequest.getConnection.getRemoteInstance),
        localKey,
        Option(syncRequest.getReplica).map(_.getIssueKey)
      )
      hasNoErrors = !hasErrors
      ok <-
        if (hasNoErrors) retryContextServiceProvider.get().shouldRetry(syncRequest.getId)
        else Future.successful(false)
    } yield ok

  override def isOk(syncRequest: BasicSyncRequest, connection: IConnection): Future[Boolean] =
    for {
      localKey <- getLocalIssueKey(syncRequest, connection)
      hasErrors <- errorRepository.hasBlockers(
        None,
        Some(connection),
        Option(connection.getRemoteInstance),
        localKey,
        Some(syncRequest.replica.getIssueKey)
      )
      hasNoErrors = !hasErrors
      ok <-
        if (hasNoErrors) retryContextServiceProvider.get().shouldRetry(syncRequest.id)
        else Future.successful(false)
    } yield ok

  /** Extracts local issue key from provided sync request
    *
    * @param syncRequest
    * @return
    *   issue key
    */
  private def getLocalIssueKey(syncRequest: ISyncRequest): Future[Option[IIssueKey]] =
    twinTraceRepository
      .getLocalIssueKeyByRemoteTwinTraceId(
        syncRequest.getConnection,
        syncRequest.getRemoteTwinTraceId
      )
      .map(
        _.orElse(Option(syncRequest.getCreatedIssueKey))
          .orElse(Option(syncRequest.getUpdatedReplica).map(_.getIssueKey))
      )

  private def getLocalIssueKey(
      syncRequest: BasicSyncRequest,
      connection: IConnection
  ): Future[Option[IIssueKey]] =
    syncRequest.remoteTwinTraceId match {
      case Some(remoteTwinTraceId) =>
        twinTraceRepository
          .getLocalIssueKeyByRemoteTwinTraceId(connection, remoteTwinTraceId)
          .map(
            _.orElse(syncRequest.createdIssueKey)
              .orElse(syncRequest.updatedReplica.map(_.getIssueKey))
          )
      case _                       => Future.successful(None)
    }

  /** Gets a full list of errors from DB
    * @return
    *   seq of errors
    */
  override def findAll: Future[Seq[IError]] = errorRepository.findAll

  /** Gets error for trigger
    * @param trigger
    * @return
    *   error
    */
  override def getErrorForTrigger(trigger: ITrigger): Future[Option[IError]] =
    errorRepository.getTriggerErrorFuture(trigger)

  /** Update error info in DB
    * @param id
    *   of the error that should be updated
    * @param params
    *   new info about error
    * @return
    *   None
    */
  override def updateError(id: Int, params: NonPersistentError): Future[None.type] =
    errorRepository.update(id, params)

  /** Resolves all errors: tries to resolve, deletes them from DB and fires All Worker Notifications
    * @return
    *   None
    */
  override def resolveAllErrors: Future[None.type] = {
    val result = Future.sequence(
      Seq(
        errorRepository.findIdsScheduleErrors.flatMap(errors =>
          Future.sequence(errors.map(resolveErrorAndRescheduleSync))
        ),
        errorRepository.deleteNonScheduleErrors
      )
    )
    result.foreach(_ => workerNotificationService.fireAllWorkerNotifications())
    result.map(_ => None)

  }

  /** Resolves errors for provided connection ID
    * @param connectionId
    * @return
    *   None
    */
  override def resolveForConnection(connectionId: Int): Future[None.type] = {
    val result = Future.sequence(
      Seq(
        errorRepository
          .findIdsScheduleErrorsForConnection(connectionId)
          .flatMap(errors => Future.sequence(errors.map(resolveErrorAndRescheduleSync))),
        errorRepository.deleteNonScheduleErrorsForConnection(connectionId)
      )
    )
    result.foreach(_ => workerNotificationService.fireAllWorkerNotifications())
    result.map(_ => None)
  }

  /** Creates and saves error with ErrorEntityType & ErrorActType - `TRIGGER`
    * @param entityType
    *   supported entity type
    * @param te
    *   Trigger Exception
    * @param connection
    * @param localIssueKey
    * @param failedExalateIssue
    * @param errorKey
    * @return
    *   id of the saved error
    */
  override def createTriggerError(
      entityType: Option[String],
      te: ExalateTriggerException,
      connection: IConnection,
      localIssueKey: Option[IIssueKey],
      failedExalateIssue: String,
      errorKey: Option[String] = None
  ): Future[Option[Int]] = {
    val npError = new NonPersistentError(
      new Date(System.currentTimeMillis()),
      ExceptionUtils.getStackTrace(te),
      exalateErrorMessageService.generateRootCauseErrorTypeNameIfPresent(te),
      // FIXME get locale from outside
      exalateErrorMessageService.generateMessageWithDocLinkIfPresent(te)(None).getOrElse(""),
      ErrorEntityType.TRIGGER,
      ErrorActType.TRIGGER,
      null,
      null,
      connection,
      connection.getRemoteInstance,
      localIssueKey.orNull,
      null,
      null,
      null,
      null,
      null,
      te.trigger,
      null,
      null,
      null
    )
    val createFuture: Future[Option[IError]] = errorRepository.create(npError)
    createFuture.map(_.map(mailService.sendErrorMail))

    createFuture.map(_.map(_.getId))
  }

  /** Ensures the "Plugin Expired" error does exist
    * @return
    */
  def ensureExpiredError(): Future[None.type] =
    for {
      expiredErrorExists <- errorRepository.expiredErrorExists
      _ <- {
        if (expiredErrorExists) Future.successful(None)
        else persistPluginExpiredErrorAndSendEmail()
      }
    } yield None

  private def persistPluginExpiredErrorAndSendEmail(): Future[None.type] = {
    val npError = new NonPersistentError(
      new Date(System.currentTimeMillis()),
      null,
      PLUGIN_EXPIRED_ROOT_CAUSE_ERROR_TYPE_NAME,
      "Two years have passed since the last jiranode upgrade.",
      ErrorEntityType.NODE,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null
    )
    val createFuture = errorRepository.create(npError)
    createFuture.map(_.map(mailService.sendErrorMail))
    createFuture.map(_ => None)
  }

  /** Changes entity type of the error to `ISSUE`
    * @param errorId
    *   id of the error that entity type should be changed
    */
  override def changeEntityTypeToIssue(errorId: Int): Future[Unit] =
    errorRepository
      .get(errorId)
      .flatMap {
        case Some(error) =>
          val nonPersistentError: NonPersistentError = new NonPersistentError(
            error.getCreationTime,
            error.getStackTrace,
            error.getRootCauseErrorTypeName,
            error.getRootCauseDetails,
            ErrorEntityType.ISSUE,
            error.getActType,
            error.getConnectRemoteIssueUrn,
            error.getConnectContext,
            error.getConnection,
            error.getInstance(),
            error.getIssueKey,
            error.getRemoteIssueKey,
            error.getSyncEvent,
            error.getSyncRequest,
            error.getBlobEvent,
            error.getBlobRequest,
            error.getTrigger,
            error.getFieldValues,
            error.getUsersDismissed,
            error.getKey
          )
          errorRepository.update(errorId, nonPersistentError)
        case _           =>
          val exception = bugExceptionCategoryService.generateNoErrorBugException(errorId)
          LOG.error(s"Error with id `$errorId` was not found.", exception)
          Future.failed(exception)
      }
      .map(_ => workerNotificationService.fireAllWorkerNotifications())

  /** Deletes Transport Errors For provided Sync Event
    * @param syncEvent
    * @return
    *   id of deleted error
    */
  def deleteTransportErrorsForSyncEvent(syncEvent: ISyncEvent): Future[Int] =
    errorRepository.deleteTransportErrorsForSyncEvent(syncEvent)

  /** Deletes Transport Errors For provided Sync Request
    * @param syncRequest
    * @return
    *   id of deleted error
    */
  def deleteTransportErrorsForSyncRequest(syncRequest: ISyncRequest): Future[Int] =
    errorRepository.deleteTransportErrorsForSyncRequest(syncRequest.getId)

  override def deleteTransportErrorsForSyncRequest(
      basicSyncRequest: BasicSyncRequest
  ): Future[Int] =
    errorRepository.deleteTransportErrorsForSyncRequest(basicSyncRequest.id)

  /** Deletes Polling Transport Errors
    *
    * @param connection
    * @return
    *   id of deleted error
    */
  def deletePollingTransportErrors(connection: IConnection): Future[Int] = {
    val errorKey = ErrorKeys.getPollingErrorKey(connection.getID)
    errorRepository.deleteErrorsWithKey(errorKey)
  }

  /** Deletes Scheduling Error
    * @param connection
    * @param localIssueKeyOpt
    * @return
    *   id of deleted error
    */
  def deleteSchedulingErrors(
      connection: IConnection,
      localIssueKeyOpt: Option[IIssueKey]
  ): Future[Int] = {
    val errorKey = ErrorKeys.getSchedulingErrorKey(connection.getID, localIssueKeyOpt)
    errorRepository.deleteErrorsWithKey(errorKey)
  }

  /** Finds Editor Errors For provided Connection
    * @param connectionId
    * @return
    *   seq of EditorError
    */
  override def findEditorErrorsForConnection(connectionId: Int): Future[Seq[EditorError]] =
    errorRepository
      .findEditorErrors(connectionId)

}
