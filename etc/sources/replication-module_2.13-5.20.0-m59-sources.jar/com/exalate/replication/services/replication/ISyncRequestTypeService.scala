package com.exalate.replication.services.replication

import com.exalate.api.domain.request.ISyncRequest
import com.exalate.domain.replication.BasicSyncRequest
import com.google.inject.ImplementedBy

import scala.concurrent.Future

@ImplementedBy(classOf[SyncRequestTypeService])
trait ISyncRequestTypeService {

  def isPairOrConnectRequest(
      basicSyncRequest: BasicSyncRequest,
      remoteTwinTraceId: Int
  ): Future[Boolean]

  def isOutOfBandRequest(basicSyncRequest: BasicSyncRequest, remoteTwinTraceId: Int): Boolean
}
