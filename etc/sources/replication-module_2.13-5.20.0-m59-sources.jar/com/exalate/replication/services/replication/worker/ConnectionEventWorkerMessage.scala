package com.exalate.replication.services.replication.worker

import com.exalate.domain.values.connection.ConnectionDraftRequestValue

sealed trait ConnectionEventWorkerMessage
case object ReviewInvitationStatus extends ConnectionEventWorkerMessage

case class ConnectionInitiated(
    connectionId: Int,
    connectionName: String,
    adminUserKeyOpt: Option[String]
) extends ConnectionEventWorkerMessage

case class ConnectionAccepted(
    connectionId: Int,
    connectionName: String,
    adminUserKeyOpt: Option[String]
) extends ConnectionEventWorkerMessage

case class ConnectionUpdated(
    connectionId: Int,
    connectionName: String,
    connectionDraftValue: Option[ConnectionDraftRequestValue]
) extends ConnectionEventWorkerMessage
