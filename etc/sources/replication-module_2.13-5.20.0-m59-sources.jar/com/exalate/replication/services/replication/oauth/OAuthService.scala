package com.exalate.replication.services.replication.oauth

import com.exalate.api.ILoggingService
import com.exalate.api.domain.oauth.{AccessTokenStatus, INonPersistentOAuthData, IOAuthData}
import com.exalate.api.exception.bug.BugException
import com.exalate.api.persistence.oauth.{IOAuthClientRepository, IOAuthDataRepository}
import com.exalate.api.persistence.relation.IRelationRepository
import com.exalate.basic.domain.oauth.NonPersistentOAuthData
import com.exalate.domain.TokenType
import com.exalate.domain.TokenType.TokenType
import com.exalate.domain.exception.issuetracker.{
  BadRequestTrackerRestException,
  ForbiddenTrackerRestException,
  InternalServerErrorTrackerRestException
}
import com.exalate.domain.oauth.OAuthClient
import com.exalate.replication.services.api.config.{IGeneralSettingsService, IUrlInferringService}
import com.exalate.replication.services.api.node.lifecycle.ILifecycleInfoService
import com.exalate.replication.services.api.replication.oauth.{
  IJwtOauthService,
  IOAuthService,
  IOAuthUriService
}
import com.exalate.replication.services.api.transport.v3_6.IExternalOAuthResourceClient
import com.exalate.replication.services.transport.v1.rest.INodeInfoClient
import com.exalate.replication.services.transport.value.oauth._
import com.google.inject.Inject
import play.api.libs.json.Json

import java.security.SecureRandom
import java.sql.Timestamp
import java.time.Clock
import java.util.{Date, UUID}
import scala.concurrent.impl.Promise
import scala.concurrent.{ExecutionContext, Future}
import scala.util.Random

class OAuthService @Inject() (
    val oauthDataRepository: IOAuthDataRepository,
    oauthClientRepository: IOAuthClientRepository,
    generalSettingsService: IGeneralSettingsService,
    externalOAuthResourceClient: IExternalOAuthResourceClient,
    oauthUriService: IOAuthUriService,
    lifecycleInfoService: ILifecycleInfoService,
    loggingService: ILoggingService,
    connectionRepository: IRelationRepository,
    nodeInfoClient: INodeInfoClient,
    jwtService: IJwtOauthService,
    urlInferringService: IUrlInferringService,
    implicit val executionContext: ExecutionContext
) extends IOAuthService {

  implicit val clock: Clock = Clock.systemUTC()

  // TODO EXAEDIT-956 review expiration time
  val ACCESS_TOKEN_EXPIRES_IN = 3600 * 24 * 365
  val REFRESH_TOKEN_EXPIRES_IN = 3600 * 24 * 365

  val RESPONSE_TYPE = "code"
  val GRANT_TYPE_AUTHORIZATION_CODE = "authorization_code"
  val GRANT_TYPE_REFRESH_TOKEN = "refresh_token"
  val SCOPE = "user:admin_exalate"

  /** Gets token from db with type `ACCESS_TOKEN` for provided instanceUID
    * @param instanceUid
    * @return
    *   \- token from provided instanceUid
    */
  override def getAccessToken(instanceUid: String): Future[Option[String]] =
    findFirstOAuthDataWithAccessToken(instanceUid).map(_.map(_.getAccessToken))

  def findFirstOAuthDataWithAccessToken(instanceUid: String): Future[Option[IOAuthData]] =
    oauthDataRepository
      .findOAuthData(TokenType.ACCESS_TOKEN, instanceUid)
      .map(_.headOption)

  override def findFirstValidOAuthDataWithAccessTokenAndRemoveIfRevoked(
      instanceUid: String
  ): Future[Option[IOAuthData]] =
    oauthDataRepository
      .findOAuthData(TokenType.ACCESS_TOKEN, instanceUid)
      .flatMap { oauthDataSeq =>
        oauthDataSeq.foldLeft(Future.successful(None): Future[Option[IOAuthData]]) {
          (resultFuture, od) =>
            resultFuture.flatMap {
              case None      =>
                hasValidRemoteAccessToken(ValidateAccessTokenReqValue(od.getAccessToken))
                  .map(_ => Some(od))
                  .recoverWith { case _ => oauthDataRepository.deleteTokens(Seq(od)) }
              case resultOpt => Future.successful(resultOpt)
            }
        }
      }

  /** Gets oauth data from DB for required instanceUID and user
    * @param instanceUid
    *   \- the instance uid
    * @param exaUser
    *   \- user key
    * @return
    *   \- Future[Option[IOAuthData]]
    */
  override def findFirstOAuthDataWithAccessToken(
      instanceUid: String,
      exaUser: String
  ): Future[Option[IOAuthData]] =
    oauthDataRepository.getOAuthDataForIssuerAndUser(instanceUid, exaUser, TokenType.ACCESS_TOKEN)

  /** Token validation
    * @param token
    * @return
    *   Future.failed in case token is not valid.
    */
  override def validateToken(token: String): Future[None.type] =
    oauthDataRepository
      .getOAuthDataWithToken(token)
      .flatMap {
        case Some(oauthData) =>
          Future.fromTry(jwtService.validateToken(token, oauthData)).map(_ => None)
        case None            =>
          Future.failed(new IllegalArgumentException(s"#validateToken token=`$token` is invalid!"))
      }

  /** In order to start OAuth flow we check if we already have corresponding token. In the request
    * we have remote url (req.authServerUri). Using nodeInfoClient we get remote instance uid. Based
    * on the remote instance uid we check in our and remote DBs if we have corresponding token.
    *
    * @param req
    *   { "clientUri": "http://nodeA", "authServerUri": "http://nodeB", }
    *
    * @return
    *   ValidateAccessTokenResValue(status: "PROVEN") or ValidateAccessTokenResValue(status:
    *   "NOT_PROVEN")
    */
  def checkExistingOAuthData(
      req: OAuthStartReqValue,
      userKey: String
  ): Future[ValidateAccessTokenResValue] = {
    val authServerUri = req.authServerUri

    nodeInfoClient
      .getNodeInfo(authServerUri, None, None)
      .flatMap { nodeInfoValue =>
        nodeInfoValue.instanceUid match {
          case Some(uid) =>
            findFirstOAuthDataWithAccessToken(uid, userKey)
              .flatMap {
                case Some(od) =>
                  hasValidRemoteAccessToken(ValidateAccessTokenReqValue(od.getAccessToken))
                    .recoverWith {
                      case _ =>
                        Future.successful(
                          ValidateAccessTokenResValue(AccessTokenStatus.NOT_PROVEN.toString)
                        )
                    }
                case None     =>
                  Future.successful(
                    ValidateAccessTokenResValue(AccessTokenStatus.NOT_PROVEN.toString)
                  )
              }
          case None      =>
            Future.successful(ValidateAccessTokenResValue(AccessTokenStatus.NOT_PROVEN.toString))
        }
      }
      .recover {
        case e: Exception => ValidateAccessTokenResValue(AccessTokenStatus.NOT_PROVEN.toString)
      }
  }

  /** The method which starts OAuth flow. Registers client data on the remote side. Obtain response.
    * Registers data on the local side. Generates `state` and ask remote side to generate url by
    * calling {@link IExternalOAuthResourceClient.generateUrl()}
    * @param req
    *   \- OAuthStartReqValue
    * @param userKey
    * @return
    */
  override def start(
      req: OAuthStartReqValue,
      userKey: String
  ): Future[Option[OAuthClientRegResponseValue]] =
    lifecycleInfoService.getInstanceUid.flatMap { instanceUid =>
      generalSettingsService.get.flatMap {
        case Some(gs) if gs.getExalateUrl.isDefined && instanceUid.isDefined =>
          (for {
            clientUri <- oauthUriService.getClientUri()
            redirectUris <- oauthUriService.getRedirectUris()
            clientName = req.connection.localInstanceName.getOrElse(instanceUid.get)
            authServerUri = req.authServerUri
            grantTypes = Seq(GRANT_TYPE_AUTHORIZATION_CODE, GRANT_TYPE_REFRESH_TOKEN)
            res <- externalOAuthResourceClient.register(
              authServerUri,
              RegisterOAuthClientReqValue(
                clientName,
                redirectUris,
                clientUri,
                grantTypes,
                SCOPE
              )
            )
            clientId = res.clientId
            clientSecret = res.clientSecret
            responseTypes = res.responseTypes
            authServerUid = res.authServerUid

            oauthClient = OAuthClient(
              None,
              res.clientId,
              res.clientSecret,
              new Timestamp(new Date().getTime),
              None,
              None,
              res.clientName,
              res.redirectUris,
              res.clientUri,
              res.grantTypes,
              res.responseTypes,
              res.scope,
              authServerUid,
              isLocal = true
            )
            _ <- oauthClientRepository.register(oauthClient)
            connectionJsValue = Json.toJson(req.connection)
            state = jwtService.generateState(
              clientId,
              redirectUris.head,
              userKey, // "JCLOUDNODE:FOOEY"
              UUID.randomUUID(),
              instanceUid.get,
              connectionJsValue,
              SCOPE
            )
            urlRes <- externalOAuthResourceClient
              .generateUrl(
                authServerUri,
                OAuthGenerateUrlReqValue(
                  "authorization",
                  clientId,
                  redirectUris.head,
                  clientUri,
                  responseTypes.headOption.getOrElse(RESPONSE_TYPE),
                  SCOPE,
                  state,
                  None
                ),
                jwtService.generateClientJwt(clientId, clientSecret, redirectUris.head)
              )
            value = OAuthClientRegResponseValue(
              clientId,
              clientName,
              redirectUris,
              clientUri,
              grantTypes,
              responseTypes,
              SCOPE,
              urlRes.url,
              state
            )

          } yield Some(value))
            .recover {
              case exception: Exception =>
                loggingService.error("Cannot get client uri", exception)
                None
            }
        case _ => Future.successful(None)
      }
    }

  /** The methods which generate `redirectUri`.
    * @param req
    * @return
    */
  override def generate(
      req: OAuthGenerateAuthorizationCodeReqValue
  ): Future[Option[OAuthGenerateAuthorizationCodeResValue]] = {
    val clientId = req.client_id
    val redirectUri = req.redirect_uri
    oauthClientRepository
      .findFirst(clientId, redirectUri)
      .flatMap {
        case Some(oauthClient) =>
          val registeredScope = oauthClient.scope
          val unregisteredScopes = req.scope
            .trim()
            .split(",")
            .filterNot(subScope => registeredScope.trim().split(",").contains(subScope))
          if (unregisteredScopes.length > 0) {
            Future.failed(new BadRequestTrackerRestException(s""))
          } else {
            if (req.response_type == RESPONSE_TYPE) {
              lifecycleInfoService.getInstanceUid map {
                case Some(instanceUid) =>
                  val code = jwtService.generateAuthorizationCode(
                    req.client_id,
                    req.redirect_uri,
                    req.exalateUserId,
                    UUID.randomUUID(),
                    instanceUid,
                    req.scope
                  )

                  Some(
                    OAuthGenerateAuthorizationCodeResValue(redirectUri =
                      s"${req.redirect_uri}?state=${req.state}&code=$code"
                    )
                  )

                case _ =>
                  None
              }
            } else {
              Future.failed(
                new ForbiddenTrackerRestException(s"Wrong response type ${req.response_type}")
              )
            }

          }
        case _                 =>
          Future.failed(
            new BugException(s"There's no client with id `$clientId` and redirect uri `$redirectUri`")
          )
      }
  }

  /** The methods which performs continue flow, after we press "Accept" on the oauth modal and we
    * redirected to the client side. This method validates state (obtained from remote side),
    * looking for the record in db (OAuthClientTable) which match info decoded from state. Then ask
    * target side to generate Access Token (by calling
    * {@link IExternalOAuthResourceClient.generateAccessToken()} ) and save returned data to DB
    * (OAuthDataTable)
    * @param req
    * @return
    */
  override def oauthContinue(req: OAuthContinueValue): Future[None.type] = {
    val isLocal = true
    jwtService
      .validateStateJwt(req.state, isLocal)
      .flatMap { _ =>
        (
          jwtService.getClientIdFromToken(req.state),
          jwtService.getRedirectUriFromToken(req.state)
        ) match {
          case (Some(clientId), Some(redirectUri)) =>
            val grantType = Some("authorization_code")
            oauthClientRepository.findFirst(clientId, redirectUri, isLocal).flatMap {
              case Some(oauthClient) =>
                jwtService.getConnectionValueFromToken(req.state) match {
                  case Some(connection) if connection.communication.remoteUrl.isDefined =>
                    urlInferringService
                      .getNodeInfoViaDifferentUrls(
                        connection.communication.remoteUrl.get,
                        None,
                        None
                      )
                      .flatMap { ni =>
                        ni.baseUrl match {
                          case Some(authServerUri) =>
                            externalOAuthResourceClient
                              .generateAccessToken(
                                authServerUri,
                                OAuthGenerateAccessTokenValue(
                                  clientId,
                                  redirectUri,
                                  grantType,
                                  authServerUri = None,
                                  req.state,
                                  req.code,
                                  req.clientExaUserId,
                                  oauthClient.scope
                                ),
                                jwtService
                                  .generateClientJwt(clientId, oauthClient.clientSecret, redirectUri)
                              )
                              .flatMap {
                                case res @ OAuthAccessTokenValue(
                                      _,
                                      accessToken,
                                      refreshToken,
                                      expiresIn,
                                      issuer
                                    ) =>
                                  for {
                                    accessTokenResult <- oauthDataRepository.upsert(
                                      toNonPersistentOAuthData(
                                        req.clientExaUserId,
                                        accessToken,
                                        Option(expiresIn),
                                        null,
                                        issuer,
                                        req.code,
                                        TokenType.ACCESS_TOKEN
                                      )
                                    )
                                    refreshTokenResult <- oauthDataRepository.upsert(
                                      toNonPersistentOAuthData(
                                        req.clientExaUserId,
                                        refreshToken,
                                        None,
                                        null,
                                        issuer,
                                        req.code,
                                        TokenType.REFRESH_TOKEN
                                      )
                                    )
                                  } yield None
                              }
                          case _                   =>
                            val details =
                              s"Node not installed yet on OAuth server instance ${connection.communication.remoteUrl}"
                            loggingService.error(details)
                            Future.failed(new BadRequestTrackerRestException(details))
                        }
                      }
                  case None                                                             =>
                    loggingService
                      .error(s"Error while getting connection value from state JWT: ${req.state}")
                    Future.failed(
                      new BadRequestTrackerRestException(
                        s"Error while decoding connection value from state JWT: ${req.state}"
                      )
                    )
                }
              case _                 =>
                Future.failed(
                  new BugException(
                    s"There's no client oauth with id `$clientId` and redirect uri `$redirectUri` in order to generate ClientJwt"
                  )
                )
            }
          case (c, r)                              =>
            Future.failed(
              new BugException(
                s"There's no client with id `$c` and redirect uri `$r` in order to generate ClientJwt"
              )
            )
        }
      }
  }

  /** Registers data to DB of the remote side for oauth flow communication.
    * @param clientName
    * @param clientUri
    * @param redirectUris
    * @param grantTypes
    * @param scope
    * @return
    */
  override def register(
      clientName: String,
      clientUri: String,
      redirectUris: Seq[String],
      grantTypes: Seq[String],
      scope: String
  ): Future[RegisterOAuthClientResValue] =
    lifecycleInfoService.getInstanceUid.flatMap { instanceUid =>
      generalSettingsService.get.flatMap {
        case Some(gs) if gs.getExalateUrl.isDefined && instanceUid.isDefined =>
          ({
            val invalidGrantTypes = grantTypes.filterNot(grant =>
              Seq("authorization_code", "refresh_token").contains(grant)
            )

            if (invalidGrantTypes.nonEmpty) {
              Future.failed(
                new BadRequestTrackerRestException(
                  s"Invalid grant types. Can't register client $clientName, that requires grant types other than $GRANT_TYPE_AUTHORIZATION_CODE and $GRANT_TYPE_REFRESH_TOKEN "
                )
              )
            } else {
              Future.successful(None)
            }
          })
            .flatMap { _ =>
              val invalidScopes = scope
                .trim()
                .split(",")
                .filterNot(subScope => Seq("user:admin_exalate").contains(subScope))
              if (invalidScopes.length > 0) {
                Future.failed(
                  new BadRequestTrackerRestException(
                    s"Invalid Scope. Can't register client $clientName, that needs any other scope than $SCOPE "
                  )
                )
              } else {
                Future.successful(None)
              }
            }
            .flatMap { _ =>
              val responseType = RESPONSE_TYPE
              val clientIdStr = Random.alphanumeric.take(32).mkString
              // TODO review cryptography behind SecureRandom being used
              // FIXME EXAEDIT-956: support multiple redirectUris
              val clientSecretStr = generateClientSecret()
              val localInstanceUid = instanceUid.get

              val newOAuthClient = OAuthClient(
                None,
                clientIdStr,
                clientSecretStr,
                new Timestamp(new Date().getTime),
                None,
                None,
                clientName,
                redirectUris,
                clientUri,
                grantTypes,
                Seq(responseType),
                scope,
                localInstanceUid
              )
              oauthClientRepository
                .register(newOAuthClient)
                .map(_ =>
                  RegisterOAuthClientResValue(
                    clientIdStr,
                    clientSecretStr,
                    clientName,
                    redirectUris,
                    clientUri,
                    grantTypes,
                    Seq(responseType),
                    scope,
                    localInstanceUid
                  )
                )
            }
        case _                                                               =>
          Future.failed(new InternalServerErrorTrackerRestException("Node not installed yet"))
      }
    }

  override def generateUrl(
      `type`: String,
      clientId: String,
      redirectUri: String,
      responseType: String,
      scope: String,
      state: String,
      code: Option[String],
      clientJwtOpt: Option[String]
  ): Future[OAuthUrlResValue] =
    // TODO EXAEDIT-956: generate a JWT of side A that would be used to prove that originally you're allowed to pass this code
    // TODO: maybe use secure random
    // TODO client Secret Generation should be done on node B
    // TODO review cryptography behind SecureRandom being used
    lifecycleInfoService.getInstanceUid.flatMap { instanceUid =>
      jwtService
        .validateClientJwt(clientJwtOpt, "redirect" == `type`)
        .flatMap { _ =>
          generalSettingsService.get.flatMap {
            case Some(gs) if gs.getExalateUrl.isDefined && instanceUid.isDefined =>
              `type` match {
                case "authorization" =>
                  oauthUriService
                    .getAuthorizationUri(
                      clientId,
                      responseType,
                      scope,
                      state,
                      redirectUri
                    )
                    .map(authServerAuthorizeUri => OAuthUrlResValue(authServerAuthorizeUri))
                    .recoverWith {
                      case exception: Exception =>
                        Future.failed(
                          new BadRequestTrackerRestException(
                            s"Cannot obtain authorization uri. Error: ${exception.getMessage}"
                          )
                        )
                    }
                case "redirect"      =>
                  // validating the clientId + redirectUri from the body according to the local client stored
                  oauthClientRepository
                    .findFirst(clientId, redirectUri, isLocal = true)
                    .flatMap {
                      case None    =>
                        Future.failed(
                          new BadRequestTrackerRestException(
                            s"Could not find the local client with given client id=$clientId and redirect Uri=`$redirectUri`."
                          )
                        )
                      case Some(_) =>
                        code match {
                          case Some(code) =>
                            Future.successful(
                              OAuthUrlResValue(
                                redirectUri + s"?state=$state&code=$code"
                              )
                            )
                          case None       =>
                            Future.failed(
                              new BadRequestTrackerRestException(
                                "Authorization Code is not provided"
                              )
                            )
                        }
                    }

                case _ =>
                  Future.failed(new BadRequestTrackerRestException(s"Unknown request type: ${`type`}"))
              }
            case _                                                               =>
              Future.failed(new InternalServerErrorTrackerRestException("Node not installed yet"))
          }
        }
    }

  /** Generates access token for further authentication.
    * @param oauthGenerateAccessTokenValue
    * @param clientJwtOpt
    * @return
    */
  override def generateAccessToken(
      oauthGenerateAccessTokenValue: OAuthGenerateAccessTokenValue,
      clientJwtOpt: Option[String]
  ): Future[OAuthAccessTokenValue] =
    lifecycleInfoService.getInstanceUid.flatMap { instanceUid =>
      jwtService
        .validateClientJwt(clientJwtOpt)
        .flatMap { oAuthClient =>
          generalSettingsService.get.flatMap {
            case Some(gs) if gs.getExalateUrl.isDefined && instanceUid.isDefined =>
              val localInstanceUid = instanceUid.get

              val clientExaUserId = oauthGenerateAccessTokenValue.clientExaUserId
              val localUrl = gs.getExalateUrl.get

              val (authServerExaUserIdOpt, scopeOpt) = (
                jwtService.getAuthServerExaUserIdFromToken(oauthGenerateAccessTokenValue.code),
                jwtService.getScopeFromToken(oauthGenerateAccessTokenValue.code)
              )

              (authServerExaUserIdOpt, scopeOpt) match {
                case (Some(authServerExaUserId), Some(scope)) =>
                  val accessTokenSecret = generateClientSecret()
                  val refreshTokenSecret = generateClientSecret()
                  val accessToken = jwtService.generateToken(
                    localInstanceUid,
                    clientExaUserId,
                    authServerExaUserId,
                    accessTokenSecret,
                    scope,
                    ACCESS_TOKEN_EXPIRES_IN,
                    localUrl,
                    oAuthClient.clientId
                  )
                  val refreshToken = jwtService.generateToken(
                    localInstanceUid,
                    clientExaUserId,
                    authServerExaUserId,
                    refreshTokenSecret,
                    scope,
                    REFRESH_TOKEN_EXPIRES_IN,
                    localUrl,
                    oAuthClient.clientId
                  )

                  for {
                    accessTokenResult <- oauthDataRepository.upsert(
                      toNonPersistentOAuthData(
                        clientExaUserId,
                        accessToken,
                        Some(ACCESS_TOKEN_EXPIRES_IN),
                        accessTokenSecret,
                        localInstanceUid,
                        oauthGenerateAccessTokenValue.code,
                        TokenType.ACCESS_TOKEN
                      )
                    )
                    refreshTokenResult <- oauthDataRepository.upsert(
                      toNonPersistentOAuthData(
                        clientExaUserId,
                        refreshToken,
                        Some(REFRESH_TOKEN_EXPIRES_IN),
                        refreshTokenSecret,
                        localInstanceUid,
                        oauthGenerateAccessTokenValue.code,
                        TokenType.REFRESH_TOKEN
                      )
                    )
                  } yield None

                  Future.successful(
                    OAuthAccessTokenValue(
                      "bearer",
                      accessToken,
                      refreshToken,
                      ACCESS_TOKEN_EXPIRES_IN,
                      localInstanceUid
                    )
                  )

                case (_, _) =>
                  Future.failed(
                    new BugException(
                      s"Cannot parse either subject of scope from code: ${oauthGenerateAccessTokenValue.code}"
                    )
                  )
              }

            case _ =>
              Future.failed(new InternalServerErrorTrackerRestException("Node not installed yet"))
          }
        }
    }

  override def deleteTokens(connectionId: Int): Future[None.type] =
    getTokens(connectionId).flatMap { tokens =>
      if (tokens.nonEmpty)
        oauthDataRepository.deleteTokens(tokens)
      else
        Future.successful(None)
    }

  override def getTokens(connectionId: Int): Future[Seq[IOAuthData]] =
    connectionRepository.getConnectionFuture(connectionId).flatMap {
      case Some(connection) =>
        Option(connection.getRemoteInstance.getNodeInfo) match {
          case Some(nodeInfo) =>
            lifecycleInfoService.getInstanceUid.flatMap { instanceUid =>
              generalSettingsService.get.flatMap {
                case Some(gs) if instanceUid.isDefined =>
                  val remoteExalateUrl = nodeInfo.getExalateUrl
                  val localInstanceUid = instanceUid.get

                  for {
                    clientIdsForConnection <- oauthClientRepository
                      .findByClientUrl(remoteExalateUrl)
                      .map(_.map(_.clientId))
                    oAuthDataGeneratedByLocalInstance <- oauthDataRepository
                      .getOAuthDataForIssuer(localInstanceUid)
                  } yield Some(oAuthDataGeneratedByLocalInstance.filter { oauthData =>
                    jwtService.getClientIdFromToken(oauthData.getAccessToken) match {
                      case Some(clientId) => clientIdsForConnection.contains(clientId)
                      case _              => false
                    }
                  })
                    .getOrElse(Nil)

                case _ => Future.successful(Nil)
              }
            }
          case _              => Future.successful(Nil)
        }
      case _                => Future.successful(Nil)
    }

  /** generates secret with required length.
    * @param lengthOfSecret
    * @return
    */
  def generateClientSecret(lengthOfSecret: Int = 32): String = {

    val secureRandom = new SecureRandom()
    val random32Bytes = Array.fill(lengthOfSecret)(0.toByte)
    secureRandom.nextBytes(random32Bytes)
    val sb = new StringBuilder
    for (b <- random32Bytes)
      sb.append(f"$b%02X")
    sb.toString

  }

  private def toNonPersistentOAuthData(
      userKey: String,
      token: String,
      expiresInOpt: Option[Long],
      secret: String,
      instanceUid: String,
      code: String,
      tokenType: TokenType
  ): INonPersistentOAuthData =
    // TODO EXAEDIT-956 Encrypt secret
    new NonPersistentOAuthData(
      userKey,
      token,
      expiresInOpt.asInstanceOf[Option[java.lang.Long]].orNull,
      secret,
      instanceUid, // issuer
      code,
      tokenType.toString
    )

  /** Checks whether the token is proven or not.
    * @param state
    * @return
    *   \- AccessTokenStatus
    */
  override def getAccessTokenStatus(state: String): Future[AccessTokenStatusValue] =
    jwtService.getConnectionValueFromToken(state) match {
      case Some(connectionValue) =>
        connectionValue.communication.remoteUrl match {
          case Some(remoteUrl) =>
            urlInferringService.getNodeInfoViaDifferentUrls(remoteUrl, None, None).flatMap {
              nodeInfoValue =>
                nodeInfoValue.instanceUid match {
                  case Some(remoteInstanceUid) =>
                    jwtService.getUserIdFromToken(state) match {
                      case Some(userId) =>
                        oauthDataRepository
                          .getOAuthDataForIssuerAndUser(
                            remoteInstanceUid,
                            userId,
                            TokenType.ACCESS_TOKEN
                          )
                          .flatMap {
                            case Some(od) =>
                              hasValidRemoteAccessToken(
                                ValidateAccessTokenReqValue(od.getAccessToken)
                              ).map { res =>
                                AccessTokenStatusValue(res.status)
                              }
                            case None     =>
                              Future.successful(
                                AccessTokenStatusValue(AccessTokenStatus.NOT_PROVEN.toString)
                              )
                          }
                      case _            =>
                        Future.failed(
                          new BadRequestTrackerRestException(
                            s"Error while getting user Id from state $state"
                          )
                        )
                    }

                  case _ =>
                    Future.failed(
                      new BadRequestTrackerRestException(
                        s"Error while getting remote instance uid value from connection ${connectionValue.name}"
                      )
                    )
                }
            }
          case _               =>
            Future.failed(
              new BadRequestTrackerRestException(
                s"Cannot find remote url for connection ${connectionValue.name}"
              )
            )
        }
      case _                     =>
        Future.failed(
          new BadRequestTrackerRestException(
            s"Wrong State jwt token format. Cannot map the json to ConnectionValue: $state."
          )
        )

    }

  /** Sends a request to the remote side to check where the access token is valid
    * @param validateAccessTokenReqValue
    * @return
    */
  override def hasValidRemoteAccessToken(
      validateAccessTokenReqValue: ValidateAccessTokenReqValue
  ): Future[ValidateAccessTokenResValue] = {
    val token = validateAccessTokenReqValue.accessToken
    jwtService.getAuthServerUriFromToken(token) match {
      case Some(url) =>
        externalOAuthResourceClient.hasValidAccessToken(url, validateAccessTokenReqValue)
      case None      =>
        loggingService.error(s"#hasValidRemoteAccessToken: Wrong jwt token format $token ")
        Future.failed(new BadRequestTrackerRestException("Wrong jwt token format"))
    }

  }

  override def getClient(clientId: String): Future[Option[OAuthClient]] =
    oauthClientRepository.findByClientId(clientId).map(_.headOption)

}
