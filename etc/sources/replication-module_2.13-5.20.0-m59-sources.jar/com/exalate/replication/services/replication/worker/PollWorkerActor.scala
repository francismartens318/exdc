package com.exalate.replication.services.replication.worker

import akka.actor.Actor
import com.exalate.api.domain.connection.IConnection
import com.exalate.api.persistence.relation.IRelationRepository
import com.exalate.replication.services.api.config.IConnectionService
import com.exalate.replication.services.api.replication.in.IPollerService
import com.exalate.replication.services.replication.worker.PollWorkerActor.{Poll, PollAll}
import com.exalate.replication.services.utils.LoggingUtils.tryWithLoggedBugs
import com.google.inject.Inject
import play.api.Logger

import scala.concurrent.Future
import scala.concurrent.duration.{FiniteDuration, _}

object PollWorkerActor {

  case class Poll(connection: IConnection)
  case class PollAll()

}

class PollWorkerActor @Inject() (
    pollerService: IPollerService,
    connectionPersistence: IRelationRepository
) extends Actor {

  val LOG: Logger = Logger("application.services.replication.worker.PollWorkerActor")
  private val intervalDuration: FiniteDuration = 60.seconds
  implicit private val ec = context.dispatcher

  // worker starts in waiting state
  def receive: Receive = {
    case m @ Poll(connection) =>
      tryWithLoggedBugs {
        LOG.trace(s"PollWorkerActor:polling remote messages for connection id = `${connection.getID}`")
        pollerService
          .pollAllMessages(connection)
          .onComplete(_ => context.system.scheduler.scheduleOnce(intervalDuration, self, m))
      }
    case p @ PollAll()        =>
      tryWithLoggedBugs {
        LOG.trace(s"PollWorkerActor:polling remote messages for all connections")
        (for {
          shouldPoll <- connectionPersistence.findShouldPoll
          toPollRemoteSideAware <- pollerService.shouldPollRemoteSideAware(shouldPoll)
          _ <- Future.sequence(toPollRemoteSideAware.map(pollerService.pollAllMessages))
        } yield ())
          .onComplete(_ => context.system.scheduler.scheduleOnce(intervalDuration, self, p))
      }

    case _ =>
      tryWithLoggedBugs {
        LOG.trace("PollWorkerActor:waiting:_")
      }
  }

}
