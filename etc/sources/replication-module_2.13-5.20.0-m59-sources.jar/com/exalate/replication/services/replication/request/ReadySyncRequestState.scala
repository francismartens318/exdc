package com.exalate.replication.services.replication.request

import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.request.RequestStatus
import com.exalate.api.domain.twintrace.{INonPersistentTrace, ITrace, TwinTraceStatus}
import com.exalate.api.domain.{ErrorReason, IIssueKey, IPersistentReplica, SyncRequestEventType}
import com.exalate.api.persistence.replication.request.{
  ICreateIssueSyncRequestStateRepository,
  ICreateOrUpdateTwinTraceSyncRequestStateRepository,
  IRequestReplicationRepository
}
import com.exalate.api.persistence.twintrace.ITwinTraceRepository
import com.exalate.basic.domain.BasicNonPersistentTrace
import com.exalate.domain.replication.BasicSyncRequest
import com.exalate.error.services.api.IBugExceptionCategoryService
import com.exalate.generic.services.api.ITrackerHubObjectService
import com.exalate.replication.services.api.license.ILicenseService
import com.exalate.replication.services.replication.ISyncRequestTypeService
import com.exalate.replication.services.replication.state.IState
import play.api.Logger

import java.net.URLEncoder
import javax.inject.Inject
import scala.concurrent.{ExecutionContext, Future}

class ReadySyncRequestState @Inject() (
    persistence: IRequestReplicationRepository,
    twinTraceRepository: ITwinTraceRepository,
    hubObjectService: ITrackerHubObjectService,
    syncRequestTypeService: ISyncRequestTypeService,
    licenseService: ILicenseService,
    createIssueSyncRequestStateRepository: ICreateIssueSyncRequestStateRepository,
    createOrUpdateTwinTraceRepository: ICreateOrUpdateTwinTraceSyncRequestStateRepository,
    bugExceptionCategoryService: IBugExceptionCategoryService
)(implicit ec: ExecutionContext)
    extends IState[BasicSyncRequestContext] {

  private val LOG = Logger("application.services.replication.request.ReadySyncRequestState")

  /** Performs transition of one of the states of SyncRequestStateMachine: status `READY`
    *
    * @param context
    * @return
    *   BasicSyncRequestContext
    */
  override def transition(
      context: BasicSyncRequestContext
  ): Future[Option[BasicSyncRequestContext]] = {
    val BasicSyncRequestContext(basicSyncRequest, connection) = context
    basicSyncRequest.remoteTwinTraceId match {
      case Some(remoteTwinTraceId) =>
        for {
          mergedTracesOpt <- getMergedTwinTraceTracesIntoSyncRequestOpt(
            basicSyncRequest,
            remoteTwinTraceId
          )
          isPairOrConnectRequest <- syncRequestTypeService.isPairOrConnectRequest(
            basicSyncRequest,
            remoteTwinTraceId
          )
          licenseErrorMessages <- licenseService.validatePayed(basicSyncRequest, connection)
          transitionedSyncRequestFuture <-
            if (licenseErrorMessages.nonEmpty) {
              // transition to send error response
              persistence
                .updateRequestWhenError(
                  basicSyncRequest.id,
                  RequestStatus.SEND_ERROR_RESPONSE,
                  licenseErrorMessages.mkString("\n"),
                  ErrorReason.SYNC_NOT_PAID
                )
                .map(toUpdatedContext(_, context))
            } else {
              twinTraceRepository
                .getRequestTwinTraceDataByRemoteTwinTraceId(
                  basicSyncRequest.connectionId,
                  remoteTwinTraceId
                )
                .flatMap { localTwinTraceData =>
                  basicSyncRequest match {
                    case _
                        if localTwinTraceData.exists(_.twinStatus == TwinTraceStatus.CLEANED) ||
                          localTwinTraceData.exists(
                            _.twinStatus == TwinTraceStatus.REMOTE_ISSUE_DELETED
                          ) ||
                          syncRequestTypeService.isOutOfBandRequest(
                            basicSyncRequest,
                            remoteTwinTraceId
                          ) =>
                      val errorMessage =
                        s"The received request `${basicSyncRequest.id}` for remote sync event `${basicSyncRequest.remoteSyncEventId}` refers to a twin trace that is not available anymore"
                      persistence
                        .updateRequestWhenError(
                          basicSyncRequest.id,
                          RequestStatus.SEND_ERROR_RESPONSE,
                          errorMessage,
                          ErrorReason.OUT_OF_BAND_REQUEST
                        )
                        .map(toUpdatedContext(_, context))

                    case unsupportedTypeRequest
                        if unsupportedTypeRequest.syncType == SyncRequestEventType.UNSUPPORTED =>
                      val errorMessage =
                        s"The received request `${basicSyncRequest.id}` for remote sync event `${basicSyncRequest.remoteSyncEventId}` has an unsupported request type. " +
                          s"Please update or downgrade your Exalate app. The type of sync is not supported by destination Instance for connection ${connection.getName}"
                      LOG.error(errorMessage)
                      persistence
                        .updateRequestWhenError(
                          basicSyncRequest.id,
                          RequestStatus.SEND_ERROR_RESPONSE,
                          errorMessage,
                          ErrorReason.NOT_SUPPORTED_SYNC_TYPE
                        )
                        .map(toUpdatedContext(_, context))

                    case connectRequest if BasicSyncRequest.isConnectRequest(connectRequest) =>
                      lazy val remoteIssueUrn = basicSyncRequest.replica.getIssueKey.getURN
                      LOG.info(
                        s"#transitioning request `${basicSyncRequest.id}` for remote issue `$remoteIssueUrn`: starting a connect transition for remote urn `${basicSyncRequest.connectIssueUrn.get}`"
                      )
                      doConnectTransition(
                        basicSyncRequest,
                        remoteTwinTraceId,
                        mergedTracesOpt,
                        connection
                      )
                        .map(toUpdatedContext(_, context))

                    case _
                        if BasicSyncRequest.isCleanupOrUnexalateOrDeleteRequest(
                          basicSyncRequest
                        ) =>
                      localTwinTraceData match {
                        case Some(existingTwintraceData) =>
                          createOrUpdateTwinTraceRepository
                            .updateTwinTraceStatusAndRequestStatus(
                              existingTwintraceData.twinId,
                              Some(TwinTraceStatus.UNEXALATED),
                              basicSyncRequest.id,
                              RequestStatus.SEND_RESPONSE
                            )
                            .map(toUpdatedContext(_, context))
                        case None                        =>
                          // If we did not get a pair response yet, we wouldn't find twin trace by remote twin trace id and we would rely on the synced issue field
                          createIssueSyncRequestStateRepository
                            .persistCreateStateIfNotEnoughData(
                              basicSyncRequest,
                              RequestStatus.SEND_RESPONSE
                            )
                            .map(toUpdatedContext(_, context))

                      }

                    case _ =>
                      if (isPairOrConnectRequest) {
                        // is pair request, as we have already handled the connect case
                        persistence
                          .updateTracesCreatedIssueKeyUpdatedReplicaAndStatus(
                            basicSyncRequest,
                            RequestStatus.CREATE_ISSUE,
                            mergedTracesOpt,
                            None,
                            None
                          )
                          .map(toUpdatedContext(_, context))
                      } else {
                        // is sync request, as we have already handled all the other types of requests
                        persistence
                          .updateTracesCreatedIssueKeyUpdatedReplicaAndStatus(
                            basicSyncRequest,
                            RequestStatus.UPDATE_ISSUE,
                            mergedTracesOpt,
                            None,
                            None
                          )
                          .map(toUpdatedContext(_, context))
                      }
                  }
                }
            }
        } yield transitionedSyncRequestFuture

      case _ =>
        val errMsg =
          s"A remote twin trace ID is missed in the sync request with id=${basicSyncRequest.id} though it is expected to be present."
        val ex = bugExceptionCategoryService.generateBugException(None, Some(errMsg))
        Future.failed(ex)
    }

  }

  private def toUpdatedContext(
      updatedRequestOpt: Option[BasicSyncRequest],
      context: BasicSyncRequestContext
  ): Option[BasicSyncRequestContext] =
    updatedRequestOpt.map(r => context.copy(request = r))

  private def doConnectTransition(
      basicSyncRequest: BasicSyncRequest,
      remoteTwinTraceId: Int,
      mergedTracesOpt: Option[Seq[INonPersistentTrace]],
      connection: IConnection
  ): Future[Option[BasicSyncRequest]] = {
    val issueKeyAndFieldValues =
      hubObjectService.getIssueKeyAndFieldValuesForConnect(basicSyncRequest.connectIssueUrn.get)
    hubObjectService
      .getLocalKey(
        URLEncoder.encode(issueKeyAndFieldValues._1, "UTF-8"),
        connection,
        hubObjectService.getMainEntityType,
        issueKeyAndFieldValues._2
      )
      .flatMap {
        case Some(issueKey) =>
          doConnectTransitionWhenLocalIssueIsPresent(
            basicSyncRequest,
            remoteTwinTraceId,
            mergedTracesOpt,
            issueKey,
            connection
          )
        case None           => doConnectTransitionIfNoLocalIssueFound(basicSyncRequest)
      }
  }

  private def doConnectTransitionWhenLocalIssueIsPresent(
      basicSyncRequest: BasicSyncRequest,
      remoteTwinTraceId: Int,
      mergedTracesOpt: Option[Seq[INonPersistentTrace]],
      localIssueKey: IIssueKey,
      connection: IConnection
  ): Future[Option[BasicSyncRequest]] =
    twinTraceRepository
      .getTwinTraceLocalReplicaByRemoteTwinTraceId(basicSyncRequest.connectionId, remoteTwinTraceId)
      .flatMap {
        case None               =>
          doConnectTransitionIfNoTwinTraceByRemoteKey(
            basicSyncRequest,
            mergedTracesOpt,
            localIssueKey,
            connection
          )
        case Some(localReplica) =>
          persistence.updateTracesCreatedIssueKeyUpdatedReplicaAndStatus(
            basicSyncRequest,
            RequestStatus.SEND_RESPONSE,
            mergedTracesOpt,
            None,
            Some(localReplica)
          )

      }

  private def doConnectTransitionIfNoTwinTraceByRemoteKey(
      basicSyncRequest: BasicSyncRequest,
      mergedTracesOpt: Option[Seq[INonPersistentTrace]],
      localIssueKey: IIssueKey,
      connection: IConnection
  ): Future[Option[BasicSyncRequest]] = {
    val isTriggerUpdate = basicSyncRequest.connectContext.exists(_.isTriggerUpdate)
    val nextStatus = if (isTriggerUpdate) RequestStatus.UPDATE_ISSUE else RequestStatus.ADD_LINK
    (if (isTriggerUpdate) {
       createIssueSyncRequestStateRepository.createTwinTraceAndSetRequestStatus(
         basicSyncRequest,
         localIssueKey,
         RequestStatus.UPDATE_ISSUE,
         mergedTracesOpt.getOrElse(Nil),
         connection
       )
     } else {
       Future.successful(Option(basicSyncRequest))
     }).flatMap { _ =>
      persistence.updateTracesCreatedIssueKeyUpdatedReplicaAndStatus(
        basicSyncRequest,
        nextStatus,
        mergedTracesOpt,
        Option(localIssueKey),
        None
      )
    }
  }

  private def doConnectTransitionIfNoLocalIssueFound(
      basicSyncRequest: BasicSyncRequest
  ): Future[Option[BasicSyncRequest]] = {
    val remoteReplica: IPersistentReplica = basicSyncRequest.replica
    val remoteIssueKey: IIssueKey = remoteReplica.getIssueKey
    val remoteIssueUrn: String = remoteIssueKey.getURN
    val connectIssueUrn: String =
      basicSyncRequest.connectIssueUrn.get // connectIssueUrn should be present here
    var errorResponseMessage: String = ""
    errorResponseMessage =
      s"Could not connect `$remoteIssueUrn` to `$connectIssueUrn`: issue by key `$connectIssueUrn` not found"

    persistence.updateRequestWhenConnectError(
      basicSyncRequest,
      RequestStatus.SEND_ERROR_RESPONSE,
      errorResponseMessage,
      ErrorReason.NO_ISSUE_TO_CONNECT_TO
    )
  }

  private def getMergedTwinTraceTracesIntoSyncRequestOpt(
      syncRequest: BasicSyncRequest,
      remoteTwinTraceId: Int
  ): Future[Option[Seq[INonPersistentTrace]]] = {
    val syncRequestId = syncRequest.id
    persistence
      .findRequestTraces(syncRequestId)
      .flatMap { requestTraces =>
        twinTraceRepository
          .findTwinTraceTracesByRemoteTwinTraceId(syncRequest.connectionId, remoteTwinTraceId)
          .map(_.map { twinTraceTraces =>
            val twinTraceTracesNotInRequest = twinTraceTraces.filter { twinTraceTrace =>
              !requestTraces.exists(requestTrace => isSameTrace(requestTrace, twinTraceTrace))
            }

            val mergedPersistentTraces = requestTraces ++ twinTraceTracesNotInRequest
            mergedPersistentTraces.map { t =>
              new BasicNonPersistentTrace()
                .from(t)
                .setRequestId(syncRequestId)
            }
          })
      }
      .map(_.flatMap {
        case merged if merged.nonEmpty => Some(merged)
        case _                         => None
      })
  }

  private def isSameTrace(requestTrace: ITrace, twinTraceTrace: ITrace): Boolean =
    Option(requestTrace.getLocalId).fold {
      twinTraceTrace.getRemoteId == requestTrace.getRemoteId && twinTraceTrace.getType == requestTrace.getType
    } { localId =>
      twinTraceTrace.getLocalId == localId && twinTraceTrace.getType == requestTrace.getType
    }

}
