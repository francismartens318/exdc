package com.exalate.replication.services.replication

import cats.data.EitherT
import cats.data.EitherT.{cond, liftF, rightT}
import cats.implicits._
import com.exalate.api.domain._
import com.exalate.api.domain.connection.fieldvalues.{ConnectionWasPublished, FieldValues}
import com.exalate.api.domain.connection.{ConnectionStatus, IConnection, InvitationStatus}
import com.exalate.api.domain.event.{EventStatus, ISyncEvent}
import com.exalate.api.domain.twintrace.{ITwinTrace, TwinTraceStatus, TwinType}
import com.exalate.api.exception.CategorizedException
import com.exalate.api.persistence.replication.event.IEventReplicationRepository
import com.exalate.api.persistence.twintrace.ITwinTraceRepository
import com.exalate.domain.replication.BasicSyncEvent
import com.exalate.error.services.api.IBugExceptionCategoryService
import com.exalate.replication.services.api.error._
import com.exalate.replication.services.api.node.lifecycle.ILifecycleInfoService
import com.exalate.replication.services.api.replication.worker.IWorkerNotificationService
import com.exalate.replication.services.api.replication.{
  ICleanUpService,
  IEventProcessorService,
  ISyncEventService
}
import com.exalate.replication.services.replication.event.SyncEventStateMachine
import play.api.Logger

import javax.inject.Inject
import scala.concurrent.{ExecutionContext, Future}
import scala.util.Random

class EventProcessorService @Inject() (
    syncEventStateMachine: SyncEventStateMachine,
    workerNotificationService: IWorkerNotificationService,
    persistence: IEventReplicationRepository,
    twinTraceRepository: ITwinTraceRepository,
    errorService: IErrorService,
    errorHandler: IErrorHandler,
    syncEventService: ISyncEventService,
    lifecycleInfoService: ILifecycleInfoService,
    cleanupService: ICleanUpService,
    bugExceptionCategoryService: IBugExceptionCategoryService
)(implicit ec: ExecutionContext)
    extends IEventProcessorService {

  private val LOG = Logger("application.services.replication.event.EventProcessorService")

  /** Process Sync Events: find Pending Sync Events For Issue and process
    */
  override def processSyncEvents(): Future[Unit] =
    for {
      _ <-
        if (lifecycleInfoService.isExpired) errorService.ensureExpiredError().recover {
          case e: Throwable =>
            LOG.error(
              s"#processSyncEvents failed to create expiration error within 10 seconds. Skipping this beat",
              e
            )
            workerNotificationService.sendProcessEventsNotification(5 + Random.nextInt(5))
        }
        else Future.successful(None)
      issueIds <- persistence.findSynchronizingIssueIds().recover {
        case e: Throwable =>
          LOG.error(
            s"#processSyncEvents failed to find issues to process within 1 minute. Skipping this beat",
            e
          )
          workerNotificationService.sendProcessEventsNotification(5 + Random.nextInt(5))
          Seq.empty
      }
      _ = LOG.trace(s"Processing outgoing sync for ${issueIds.size} entities")
      _ <- issueIds.toList.traverse { issueId =>
        for {
          syncEvents <- persistence.findPendingSyncEventsForIssue(issueId).recover {
            case e: Throwable =>
              LOG.error(
                s"#processSyncEvents failed to get sync events within 1 minute. Skipping this beat",
                e
              )
              workerNotificationService.sendProcessEventsNotification(5 + Random.nextInt(5))
              Seq.empty
          }
          _ <- syncEvents
            .groupBy(_.getConnection)
            .toList
            .traverse_ {
              case (_, syncEventsPerConnection) =>
                syncEventsPerConnection.find(BasicSyncEvent.isCleanupEvent) match {
                  case Some(cleanUpEvent) =>
                    val syncContextStr = getSyncContextMessage(Seq(cleanUpEvent))
                    LOG.trace(s"Process pending events: Found cleanup up event $syncContextStr")
                    processSyncEvents(List(cleanUpEvent))
                  case None               =>
                    val syncContextStr = getSyncContextMessage(syncEventsPerConnection)
                    LOG.trace(
                      s"Process pending events: Found ${syncEventsPerConnection.size} sync events $syncContextStr"
                    )
                    processSyncEvents(syncEventsPerConnection.toList)
                }
            }
        } yield ()

      }

    } yield ()

  /** Generates sync context message
    * @param syncEvents
    * @return
    */
  private def getSyncContextMessage(syncEvents: Seq[ISyncEvent]): String =
    syncEvents.headOption
      .map { se =>
        val relationStr = se.getConnection
        val issueStr = se.getLocalReplica.getIssueKey.getURN
        s" for issue `$issueStr` for connection `$relationStr`"
      }
      .getOrElse("")

  /** Checks whether sync event can be processed
    * @param syncEvent
    * @return
    *   true or false
    */
  private[replication] def canBeProcessed(syncEvent: ISyncEvent, tt: Option[ITwinTrace]): Boolean =
    if (BasicSyncEvent.isCleanupEvent(syncEvent)) {
      true
    } else {
      tt match {
        case Some(twinTrace) =>
          val isParent: Boolean = twinTrace.getType == TwinType.PARENT
          val isInitial: Boolean = twinTrace.getStatus == TwinTraceStatus.INITIAL
          val isParentOrNotInitial = isParent || !isInitial
          val issueKeyOpt: Option[IIssueKey] = Option(syncEvent.getLocalReplica)
            .flatMap(lr => Option(lr.getIssueKey))
          val issueKeyStr =
            issueKeyOpt.map(k => s" for ${k.getEntityType} `${k.getURN}` (${k.getIdStr})")
          if (!isParentOrNotInitial) {
            LOG.info(
              s"sync event `${syncEvent.getId}` with number `${syncEvent.getEventNumber}`$issueKeyStr cannot be processed because twin trace is 'CHILD' and status is 'INITIAL'"
            )
          }
          val wasPublishedAtLeastOnce = !Option(syncEvent.getConnection.getFieldValues)
            .flatMap(fv => Option(fv.get(FieldValues.WAS_PUBLISHED.toString)))
            .contains(ConnectionWasPublished.FALSE.toString)
          if (!wasPublishedAtLeastOnce) {
            LOG.info(
              s"sync event `${syncEvent.getId}` with number `${syncEvent.getEventNumber}`$issueKeyStr cannot be processed because the first draft was never published for it yet"
            )
          }
          isParentOrNotInitial && wasPublishedAtLeastOnce
        case None            => true
      }
    }

  /** Process Sync Event
    * @param syncEvent
    */
  private def processSyncEvent(syncEvent: ISyncEvent): Future[ShouldProcess] = {
    val connection = syncEvent.getConnection
    val localIssueKey = syncEvent.getLocalReplica.getIssueKey

    val syncEventProcessResult = for {
      twinTraceData <- liftF(twinTraceRepository.getTwinTraceById(syncEvent.getTwinTraceId))
      isReadyForProcessing = canBeProcessed(syncEvent, twinTraceData)
      _ <- cond[Future](isReadyForProcessing, (), StopProcess)

      se <- liftF(persistence.getSyncEvent(syncEvent.getId))
      _ <- cond[Future](se.isDefined, (), StopProcess)

      _ = LOG.info(
        s"Starting to process sync event `${syncEvent.getId}` of type `${syncEvent.getSyncType}`, number `${syncEvent.getEventNumber}` on state '${syncEvent.getStatus}'  for local issue `${localIssueKey.getURN}` for local twin trace `${syncEvent.getTwinTraceId}` and connection `${connection.getName}`"
      )
      v <- liftF(shouldProcess(syncEvent))

      processedEvent <- if (v._2) processEvent(v._1) else liftF(Future.successful(v._1))
      _ <-
        if (processedEvent.getStatus == EventStatus.PROCESSED) {
          cleanupService
            .handleProcessedEvent(processedEvent)
            .attemptT
            .map(_ => ())
            .leftMap { e =>
              LOG.error(s"Error while handling processed event ${processedEvent.getId}", e)
              StopProcess
            }
        } else {
          rightT[Future, StopProcess.type](())
        }

    } yield KeepProcess

    syncEventProcessResult.value
      .map {
        case Left(_)  => StopProcess
        case Right(_) => KeepProcess
      }
      .recoverWith {
        case CategorizedExceptionWithContext(context, e) =>
          for {
            remoteIssueKeyOpt <- syncEventService.getRemoteIssueKey(syncEvent)
            _ = logErrorContext(syncEvent, remoteIssueKeyOpt, e)
            _ <- errorHandler.handleError(e, context)
          } yield StopProcess
        case e: CategorizedException                     =>
          for {
            remoteIssueKeyOpt <- syncEventService.getRemoteIssueKey(syncEvent)
            _ = logErrorContext(syncEvent, remoteIssueKeyOpt, e)
            context = SyncContext(
              connection = Some(connection),
              localIssueKeyOpt = Some(localIssueKey),
              remoteIssueKeyOpt = remoteIssueKeyOpt
            )
            _ <- errorHandler.handleError(e, context)
          } yield StopProcess

        case e: Exception =>
          for {
            remoteIssueKeyOpt <- syncEventService.getRemoteIssueKey(syncEvent)
            _ = logErrorContext(syncEvent, remoteIssueKeyOpt, e)
            bugException = bugExceptionCategoryService.generateBugException(Some(e), None)
            context = SyncContext(
              connection = Some(connection),
              localIssueKeyOpt = Some(localIssueKey),
              remoteIssueKeyOpt = remoteIssueKeyOpt
            )
            _ <- errorHandler.handleError(bugException, context)
          } yield StopProcess

      }
  }

  private def shouldProcess(syncEvent: ISyncEvent): Future[(ISyncEvent, Boolean)] = {
    val toProcess = syncEvent
    val connection = toProcess.getConnection
    val localIssueURN = toProcess.getLocalReplica.getIssueKey.getURN
    val invitationStatus = connection.getInvitationStatus

    if (
      BasicSyncEvent.isCleanupOrUnexalateOrDeleteEvent(toProcess) &&
      (invitationStatus == InvitationStatus.PENDING || invitationStatus == InvitationStatus.SEND_ACCEPTED)
    ) {
      persistence
        .updateSyncEventStatus(toProcess, EventStatus.PROCESSED)
        .map {
          case Some(value) => value
          case None        =>
            LOG.warn(
              s"Could not update sync event`${toProcess.getId}` of type `${syncEvent.getSyncType}`, number `${syncEvent.getEventNumber}` for local issue `$localIssueURN` for local twin trace `${syncEvent.getTwinTraceId}` and connection `${connection.getName}`."
            )
            syncEvent
        }
        .map(value => (value, false))
    } else {
      Future.successful(toProcess, true)
    }
  }

  private def processEvent(toProcess: ISyncEvent): EitherT[Future, StopProcess.type, ISyncEvent] = {
    val localIssueURN = toProcess.getLocalReplica.getIssueKey.getURN
    val connectionName = toProcess.getConnection.getName

    def loop(toProcess: ISyncEvent): EitherT[Future, StopProcess.type, ISyncEvent] =
      canProcessingContinue(toProcess).flatMap {
        case StopProcess => rightT(toProcess)
        case KeepProcess =>
          LOG.info(
            s"Processing sync event `${toProcess.getId}` with event number `${toProcess.getEventNumber}` of type `${toProcess.getSyncType}`, on state '${toProcess.getStatus}'  for local issue `$localIssueURN` for local twin trace `${toProcess.getTwinTraceId}` and connection `$connectionName`"
          )
          liftF(
            syncEventStateMachine
              .getState(toProcess)
              .transition(toProcess)
              .flatMap(e => errorService.deleteTransportErrorsForSyncEvent(toProcess).map(_ => e))
              .recoverWith {
                case e: CategorizedException =>
                  val context = SyncContext.createWithSyncEvent(toProcess)
                  val categorizedWithContext = CategorizedExceptionWithContext(context, e)
                  Future.failed(categorizedWithContext)
                case e: Exception            =>
                  val context = SyncContext.createWithSyncEvent(toProcess)
                  val bugException = bugExceptionCategoryService.generateBugException(Some(e), None)
                  val categorizedWithContext = CategorizedExceptionWithContext(context, bugException)
                  Future.failed(categorizedWithContext)
              }
          ).flatMap {
            case Some(se) => loop(se)
            case None     => rightT(toProcess)
          }

      }

    loop(toProcess)

  }

  private[replication] def processSyncEvents(syncEvents: List[ISyncEvent]): Future[Unit] = {

    def loop(
        syncEvents: List[ISyncEvent],
        shouldProcess: ShouldProcess
    ): Future[ShouldProcess] =
      syncEvents match {
        case Nil          => Future.successful(shouldProcess)
        case head :: tail =>
          if (shouldProcess == KeepProcess) {
            processSyncEvent(head).flatMap { updatedAcc =>
              loop(tail, updatedAcc)
            }
          } else {
            Future.successful(shouldProcess)
          }

      }

    loop(syncEvents, KeepProcess).map(_ => ())
  }

  private def logErrorContext(
      syncEvent: ISyncEvent,
      remoteIssueKeyOpt: Option[IIssueKey],
      e: Exception
  ): Unit = {
    val localIssueKey = syncEvent.getLocalReplica.getIssueKey
    val connectionName = syncEvent.getConnection.getName
    LOG.error(
      s"Exception occurred while processing sync event ID `${syncEvent.getId}`, local issue `$localIssueKey`, connection `$connectionName`${remoteIssueKeyOpt
          .map(rKey => s", remote issue `$rKey`.")
          .getOrElse(".")}",
      e
    )
  }

  /** Checks whether sync event process can be continued
    * @param toProcess
    * @return
    */
  private def canProcessingContinue(
      toProcess: ISyncEvent
  ): EitherT[Future, StopProcess.type, ShouldProcess] =
    if (BasicSyncEvent.isCleanupEvent(toProcess) && toProcess.canBeProcessed) {
      rightT(KeepProcess)
    } else {
      val connection: IConnection = toProcess.getConnection
      val isInvitationAccepted = InvitationStatus.ACCEPTED == connection.getInvitationStatus

      val isInvitationActive = ConnectionStatus.ACTIVE == connection.getStatus

      if (!isInvitationAccepted) {
        LOG.warn(
          s"sync event `${toProcess.getId}` for issue ${toProcess.getLocalReplica.getIssueKey.getURN} will not be processed because invitation for connection ${connection.getName} is not accepted"
        )
      }

      if (!isInvitationActive) {
        LOG.warn(
          s"sync event `${toProcess.getId}` for issue ${toProcess.getLocalReplica.getIssueKey.getURN} will not be processed because connection ${connection.getName} is not active"
        )
      }
      liftF(errorService.isOk(toProcess)).map { noErrors =>
        val canContinue = noErrors &&
          toProcess.canBeProcessed &&
          isInvitationActive &&
          isInvitationAccepted

        if (canContinue) KeepProcess else StopProcess
      }
    }

}
