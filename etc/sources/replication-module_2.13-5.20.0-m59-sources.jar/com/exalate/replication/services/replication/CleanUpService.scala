package com.exalate.replication.services.replication

import cats.data.OptionT
import cats.implicits._
import com.exalate.api.CleanUpResult
import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.event.ISyncEvent
import com.exalate.api.domain.request.ISyncRequest
import com.exalate.api.exception.bug.PersistenceBugException
import com.exalate.api.persistence.ICleanUpRepository
import com.exalate.api.persistence.relation.IRelationRepository
import com.exalate.api.persistence.replication.cleanup.ICleanUpReplicationRepository
import com.exalate.api.persistence.replication.event.IEventCleanUpRepository
import com.exalate.api.persistence.replication.request.{
  IRequestCleanUpRepository,
  IRequestReplicationRepository
}
import com.exalate.api.persistence.twintrace.ITwinTraceRepository
import com.exalate.domain.exception.issuetracker.{
  BadRequestTrackerRestException,
  NotFoundTrackerRestException
}
import com.exalate.domain.node.storeblob.StoredBlobMetaData
import com.exalate.domain.replication.{BasicSyncEvent, BasicSyncRequest}
import com.exalate.domain.values.{CleanUpResponse, IssuePairs, RemoteSupportsCleanUpResult}
import com.exalate.error.services.BugExceptionCategoryService
import com.exalate.replication.services.api.node.storeblob.IStoreBlobService
import com.exalate.replication.services.api.replication.worker.IWorkerNotificationService
import com.exalate.replication.services.api.replication.{
  ICleanUpService,
  IEventSchedulerNotificationService
}
import com.exalate.replication.services.config.CleanUpHelper
import com.exalate.services.utils.{FutureUtils, JsonStringToMapHelper}
import com.google.common.collect.Maps
import com.google.inject.Inject
import play.api.Logger

import java.util
import scala.collection.JavaConverters.mapAsJavaMapConverter
import scala.collection.{mutable, JavaConverters}
import scala.concurrent.{ExecutionContext, Future}

class CleanUpService @Inject() (
    storeBlobService: IStoreBlobService,
    syncCleanupRepository: ICleanUpRepository,
    eventCleanupRepository: IEventCleanUpRepository,
    cleanUpReplicationRepository: ICleanUpReplicationRepository,
    requestCleanupRepository: IRequestCleanUpRepository,
    workerNotificationService: IWorkerNotificationService,
    connectionRepository: IRelationRepository,
    requestReplicationRepository: IRequestReplicationRepository,
    cleanUpHelper: CleanUpHelper,
    eventSchedulerService: IEventSchedulerNotificationService,
    twinTraceRepository: ITwinTraceRepository,
    bugExceptionCategoryService: BugExceptionCategoryService
)(implicit ec: ExecutionContext)
    extends ICleanUpService {

  val LOG = Logger("application.services.replication.CleanUpService")

  /** Handles Processed Event, namely cleans Up Sync Event And Context
    *
    * @param syncEvent
    * @return
    *   None
    */
  override def handleProcessedEvent(syncEvent: ISyncEvent): Future[None.type] =
    if (BasicSyncEvent.isCleanupOrUnexalateOrDeleteEvent(syncEvent)) {
      LOG.debug(s"Handling processing of clean up, exalate or delete event")
      cleanUpReplicationRepository
        .cleanUpSyncEventAndContext(syncEvent)
        .flatMap(deleteRelatedBlobs)
    } else deleteAndCleanUpProcessed(syncEvent)

  /** Deletes Blobs related to CleanUpResult
    *
    * @param cleanUpResult
    * @return
    *   None
    */
  private def deleteRelatedBlobs(cleanUpResult: CleanUpResult): Future[None.type] =
    deleteRelatedBlobs(cleanUpResult.blobPathsToDelete)

  def deleteRelatedBlobs(paths: Seq[String]): Future[None.type] =
    Future
      .sequence(
        paths
          .flatMap(StoredBlobMetaData.get(_))
          .map(storeBlobService.deleteBlob)
      )
      .flatMap(_ => Future.successful(None))

  /** Deletes info of the processed sync event
    *
    * @param syncEvent
    * @return
    *   None
    */
  private def deleteAndCleanUpProcessed(syncEvent: ISyncEvent): Future[None.type] = {
    val syncEventId = syncEvent.getId
    val blobMetadataSeq =
      JavaConverters.asScalaBufferConverter(syncEvent.getBlobMetadataList).asScala
    val (withFilePath, withoutFilePath) =
      blobMetadataSeq.partition(b => Option(b.getBlobFilePath).isDefined)
    LOG.info(
      s"#transition: cleaning up and deleting the syncEvent with id $syncEventId for the connection `${syncEvent.getConnection.getName}'"
    )

    Future
      .sequence(
        withFilePath
          .flatMap(StoredBlobMetaData.get(_))
          .map(storeBlobService.deleteBlob)
      )
      .flatMap(_ => eventCleanupRepository.deleteAndCleanUpEvent(syncEvent))
  }

  /** Handles Processed Request: namely cleans Up Sync Request And Context
    *
    * @param syncRequest
    * @return
    *   None
    */
  override def handleProcessedRequest(syncRequest: ISyncRequest): Future[None.type] =
    if (BasicSyncRequest.isCleanupOrUnexalateRequest(syncRequest)) {
      LOG.debug(
        s"Handling processing of clean up, exalate or delete request with id '${syncRequest.getId}' for remote issue ${Option(syncRequest.getReplica)
            .map(_.getIssueKey.getURN)}"
      )
      cleanUpReplicationRepository
        .cleanUpSyncRequestAndContext(syncRequest)
        .flatMap(deleteRelatedBlobs)
    } else if (BasicSyncRequest.isDeleteRequest(syncRequest))
      cleanUpReplicationRepository
        .cleanUpDeleteSyncRequest(syncRequest)
        .flatMap(deleteRelatedBlobs)
    else deleteAndCleanUpProcessed(syncRequest)

  override def handleProcessedRequest(basicSyncRequest: BasicSyncRequest): Future[None.type] =
    if (BasicSyncRequest.isCleanupOrUnexalateRequest(basicSyncRequest)) {
      LOG.debug(
        s"Handling processing of clean up, exalate or delete request with id '${basicSyncRequest.id}' for remote issue ${Option(basicSyncRequest.replica)
            .map(_.getIssueKey.getURN)}"
      )
      cleanUpReplicationRepository
        .cleanUpSyncRequestAndContext(basicSyncRequest)
        .flatMap(deleteRelatedBlobs)
    } else if (BasicSyncRequest.isDeleteRequest(basicSyncRequest))
      cleanUpReplicationRepository
        .cleanUpDeleteSyncRequest(basicSyncRequest)
        .flatMap(deleteRelatedBlobs)
    else deleteAndCleanUpProcessed(basicSyncRequest)

  /** Deletes info of the processed sync request
    *
    * @param syncRequest
    * @return
    *   None
    */
  @deprecated(
    "Will be removed in favor of `deleteAndCleanUpProcessed(basicSyncRequest: BasicSyncRequest)`",
    "EXACOMP-1884"
  )
  private def deleteAndCleanUpProcessed(syncRequest: ISyncRequest): Future[None.type] = {
    val connection = syncRequest.getConnection
    val connectionName = connection.getName
    val syncEventId = syncRequest.getRemoteSyncEventId
    LOG.info(
      s"#transition: cleaning up and deleting the syncRequest with id ${syncRequest.getId} for the remote event `$syncEventId` " +
        s"and connection `$connectionName'"
    )

    FutureUtils
      .foldLeft(
        JavaConverters
          .asScalaBufferConverter(syncRequest.getBlobMetadataList)
          .asScala
          .toList
          .flatMap(StoredBlobMetaData.get(_))
      )(storeBlobService.deleteBlob)
      .flatMap { _ =>
        LOG.debug(
          s"#deleteAndCleanUpProcessed: deleted related files, now cleaning up and deleting the syncRequest with id ${syncRequest.getId} for the remote event `$syncEventId` " +
            s"and connection `$connectionName'"
        )
        requestCleanupRepository
          .deleteAndCleanUpRequest(BasicSyncRequest(syncRequest))
          .recover {
            case e: PersistenceBugException =>
              LOG.error(
                s"There was a persistence error while attempting to clean up the request ${syncRequest.getId}",
                e
              )
              None
          }
      }
  }

  /** Cleanup the processed sync request.
    * @param basicSyncRequest
    *   BasicSyncRequest to be cleaned up.
    * @return
    */
  private def deleteAndCleanUpProcessed(basicSyncRequest: BasicSyncRequest): Future[None.type] = {
    val remoteSyncEventId = basicSyncRequest.remoteSyncEventId
    val connectionId = basicSyncRequest.connectionId
    LOG.info(
      s"#transition: cleaning up and deleting the syncRequest with id ${basicSyncRequest.id} for the remote event `$remoteSyncEventId` " +
        s"and connection `$connectionId'"
    )

    for {
      blobMetadataSeq <- requestReplicationRepository.findBlobMetadata(basicSyncRequest.id)
      _ <- blobMetadataSeq.toList.traverse(blobMetadata =>
        (for {
          storedBlobMetadata <- OptionT.fromOption[Future](StoredBlobMetaData.get(blobMetadata))
          _ <- OptionT.liftF(storeBlobService.deleteBlob(storedBlobMetadata))
        } yield ()).value
      )
      _ <- {
        LOG.debug(
          s"#deleteAndCleanUpProcessed: deleted related files, now cleaning up and deleting the syncRequest with id ${basicSyncRequest.id} for the remote event `$remoteSyncEventId` " +
            s"and connection `$connectionId'"
        )
        requestCleanupRepository
          .deleteAndCleanUpRequest(basicSyncRequest)
          .recover {
            case e: PersistenceBugException =>
              LOG.error(
                s"There was a persistence error while attempting to clean up the request ${basicSyncRequest.id}",
                e
              )
          }
      }
    } yield None
  }

  /** Gets amount of active twintraces for provided issue
    *
    * @param connection
    * @param issueUrn
    * @param entityType
    * @return
    *   the amount of active twintraces
    */
  override def getActiveTwinTraceCountForIssue(
      connection: IConnection,
      issueUrn: String,
      entityType: String,
      fieldValuesStr: Option[String]
  ): Future[Int] = syncCleanupRepository.getActiveTwinTraceCountForIssue(
    connection,
    issueUrn,
    entityType,
    fieldValuesStr
  )

  /** Gets amount of active twintraces for provided remote issue
    *
    * @param connection
    * @param remoteIssueUrn
    * @param entityType
    * @return
    *   amount of active twintraces
    */
  override def getActiveTwinTraceCountForRemoteIssue(
      connection: IConnection,
      remoteIssueUrn: String,
      entityType: String
  ): Future[Int] = syncCleanupRepository.getActiveTwinTraceCountForRemoteIssue(
    connection,
    remoteIssueUrn,
    entityType
  )

  /** Gets amount of active twintraces for provided connection
    *
    * @param connection
    * @param entityType
    * @return
    *   amount of active twintraces
    */
  override def getActiveTwinTraceCountForConnection(
      connection: IConnection,
      entityType: String
  ): Future[Int] = syncCleanupRepository.getActiveTwinTraceCountForConnection(connection, entityType)

  /** Gets amount of active twintraces
    *
    * @return
    *   amount of active twintraces
    */
  override def getActiveTwinTraceCount: Future[Int] = syncCleanupRepository.getActiveTwinTraceCount

  /** Gets amount of Sync Events for provided connections
    *
    * @param connection
    * @param entityType
    * @return
    *   amount of Sync Events
    */
  override def getSyncEventsCountForConnection(
      connection: IConnection,
      entityType: String
  ): Future[Int] = syncCleanupRepository.getSyncEventsCountForConnection(connection, entityType)

  /** Gets amount of Sync requests for provided connections
    *
    * @param connection
    * @param entityType
    * @return
    *   amount of Sync requests
    */
  override def getSyncRequestsCountForConnection(
      connection: IConnection,
      entityType: String
  ): Future[Int] = syncCleanupRepository.getSyncRequestsCountForConnection(connection, entityType)

  /** Clean up all sync info
    *
    * @return
    *   CleanUpResult
    */
  override def cleanUpAllSyncInfo(): Future[Option[CleanUpResult]] = {
    val cleanUpResultOptFut = syncCleanupRepository.cleanUpAllSyncInfo().map(Some.apply)
    deleteBlobsFireNotificationsAndReturnResult(cleanUpResultOptFut)
  }

  /** Clean up all sync info related to provided connection
    *
    * @param connection
    * @param entityType
    * @return
    *   CleanUpResult
    */
  override def cleanUpSyncInfoForConnection(
      connection: IConnection,
      entityType: String
  ): Future[Option[CleanUpResult]] = {
    val cleanUpResultOptFut =
      syncCleanupRepository.cleanUpSyncInfoForConnection(connection, entityType).map(Some.apply)
    deleteBlobsFireNotificationsAndReturnResult(cleanUpResultOptFut)
  }

  /** Clean Up Sync Info For provided Issue and keep Twin Trace
    *
    * @param issueUrn
    * @param entityType
    * @return
    *   CleanUpResult
    */
  def cleanUpSyncInfoForIssueKeepTwinTrace(
      issueUrn: String,
      entityType: String,
      fieldValues: util.Map[String, String]
  ): Future[Seq[CleanUpResult]] =
    connectionRepository.findConnectionIdsFuture.flatMap { ids =>
      ids
        .foldLeft(Future.successful(Seq[Option[CleanUpResult]]())) { (r, connectionId) =>
          r.flatMap { r =>
            cleanUpSyncInfoForIssueKeepTwinTrace(connectionId, issueUrn, entityType, fieldValues)
              .map(_ +: r)
          }
        }
        .map(_.flatten)
    }

  /** Clean up all sync info related to provided issue
    *
    * @param connectionId
    * @param issueUrn
    * @param entityType
    * @return
    *   CleanUpResult
    */
  override def cleanUpSyncInfoForIssue(
      connectionId: Int,
      issueUrn: String,
      entityType: String,
      fieldValues: Map[String, String]
  ): Future[Option[CleanUpResult]] = {
    val fieldValuesStr = JsonStringToMapHelper.javaMapToStringJson(fieldValues.asJava)
    val cleanUpResultOptFut = syncCleanupRepository
      .cleanUpSyncInfoForIssue(connectionId, issueUrn, entityType, fieldValuesStr)
      .map(Some.apply)
    deleteBlobsFireNotificationsAndReturnResult(cleanUpResultOptFut)
  }

  /** Clean up all sync info related to provided remote issue urn
    *
    * @param connection
    * @param remoteIssueUrn
    * @param entityType
    * @return
    */
  override def cleanUpForRemoteIssue(
      connection: IConnection,
      remoteIssueUrn: String,
      entityType: String
  ): Future[Option[CleanUpResult]] = {
    val cleanUpResultOptFut = syncCleanupRepository
      .cleanUpForRemoteIssue(connection, remoteIssueUrn, entityType)
      .map(Some.apply)
    deleteBlobsFireNotificationsAndReturnResult(cleanUpResultOptFut)
  }

  /** Clean Up Sync Info For provided Issue and connection and keep Twin Trace
    *
    * @param connectionId
    * @param issueUrn
    * @param entityType
    * @return
    *   CleanUpResult
    */
  override def cleanUpSyncInfoForIssueKeepTwinTrace(
      connectionId: Int,
      issueUrn: String,
      entityType: String,
      fieldValues: util.Map[String, String]
  ): Future[Option[CleanUpResult]] = {
    val fieldValuesStr = JsonStringToMapHelper.javaMapToStringJson(fieldValues)
    val cleanUpResultOptFut = syncCleanupRepository
      .cleanUpSyncInfoForIssueKeepTwinTrace(connectionId, issueUrn, entityType, fieldValuesStr)
      .map(Some.apply)
    deleteBlobsFireNotificationsAndReturnResult(cleanUpResultOptFut)
  }

  /** deletes Blobs and fire Notifications
    *
    * @param cleanUpResultOptFut
    * @return
    *   CleanUpResult
    */
  private def deleteBlobsFireNotificationsAndReturnResult(
      cleanUpResultOptFut: Future[Option[CleanUpResult]]
  ) =
    cleanUpResultOptFut
      .flatMap(cleanUpResOpt =>
        cleanUpResOpt.map(res => deleteRelatedBlobs(res)).getOrElse(Future.successful(None))
      )
      .flatMap { _ =>
        workerNotificationService.fireAllWorkerNotifications()
        cleanUpResultOptFut
      }

  /** Clean Up For provided remote Issue and connection and keep Twin Trace
    *
    * @param connection
    * @param remoteIssueUrn
    * @param entityType
    * @return
    *   CleanUpResult
    */
  override def cleanUpForRemoteIssueKeepTwinTrace(
      connection: IConnection,
      remoteIssueUrn: String,
      entityType: String
  ): Future[Option[CleanUpResult]] = {
    val cleanUpResultOptFut = syncCleanupRepository
      .cleanUpForRemoteIssueKeepTwinTrace(connection, remoteIssueUrn, entityType)
      .map(Some.apply)
    deleteBlobsFireNotificationsAndReturnResult(cleanUpResultOptFut)
  }

  /** Clean Up Sync Info For provided connection and keep Twin Trace
    *
    * @param connection
    * @param entityType
    * @return
    *   CleanUpResult
    */
  override def cleanUpSyncInfoForConnectionKeepTwinTrace(
      connection: IConnection,
      entityType: String
  ): Future[Option[CleanUpResult]] = {
    LOG.debug(s"Starting cleaning up sync info for connection ${connection.getName}")
    val cleanUpResultOptFut = syncCleanupRepository
      .cleanUpSyncInfoForConnectionKeepTwinTraces(connection, entityType)
      .map(Some.apply)
    deleteBlobsFireNotificationsAndReturnResult(cleanUpResultOptFut)
  }

  /** clean Up Scheduled Errors for provided Connection
    *
    * @param connection
    * @param entityType
    * @return
    *   None
    */
  override def cleanUpScheduleErrorForConnection(
      connection: IConnection,
      entityType: String
  ): Future[None.type] =
    syncCleanupRepository.cleanUpScheduleErrorForConnection(connection.getID, entityType)

  def cleanUpConnection(
      connectionId: Int,
      entityTypeOpt: Option[String]
  ): Future[List[CleanUpResponse]] =
    entityTypeOpt match {
      case Some(entityType) =>
        connectionRepository.getConnectionFuture(connectionId).flatMap {
          case Some(connection) =>
            if (cleanUpHelper.remoteSupportsCleanup(connection)) {
              eventSchedulerService.scheduleCleanupEventForConnection(connectionId, entityType)
              Future.successful(List.empty[CleanUpResponse]) // NoContent
            } else {
              LOG.warn("Remote site does not support Clean up")
              cleanUpSyncInfoForConnectionKeepTwinTrace(connection, entityType).flatMap(toResult)
            }
          case _                =>
            val message =
              s"Trying cleaning-up by connection $connectionId for $entityType on both sides but connection was not found."
            LOG.debug(message)
            Future.failed(
              bugExceptionCategoryService.generateNoConnectionBugException(connectionId.toString)
            )
        }
      case None => Future.failed(new IllegalArgumentException("`entityType` is missing"))
    }

  override def cleanUpIssue(
      connectionId: Int,
      issueUrn: String,
      entityTypeOpt: Option[String],
      fieldValuesFromQuery: mutable.Map[String, String]
  ): Future[List[CleanUpResponse]] =
    entityTypeOpt match {
      case Some(entityType) =>
        connectionRepository.getConnectionFuture(connectionId).flatMap {
          case Some(connection) =>
            fieldValuesFromQuery.remove("entityType")
            val fieldValues = fieldValuesFromQuery.asJava
            if (cleanUpHelper.remoteSupportsCleanup(connection)) {
              LOG.debug(
                s"Starting cleaning-up $entityType $issueUrn for connection $connectionId on both sides."
              )
              cleanIssueOnBoth(connection, issueUrn, entityType, fieldValues).flatMap(toResult)
            } else {
              LOG.debug(
                s"Starting cleaning-up $entityType $issueUrn for connection $connectionId on local side."
              )
              cleanUpSyncInfoForIssueKeepTwinTrace(
                connection.getID,
                issueUrn,
                entityType,
                fieldValues
              )
                .flatMap(toResult)
            }

          case _ =>
            val message =
              s"Trying cleaning-up ${entityTypeOpt.getOrElse("issue")} $issueUrn for connection $connectionId on both sides but connection was not found."
            LOG.debug(message)
            Future.failed(new NotFoundTrackerRestException(message))
        }
      case None             =>
        Future.failed(new BadRequestTrackerRestException("Query parameter `entityType` is missing"))
    }

  override def cleanUpByRemoteIssue(
      connectionId: Int,
      remoteIssueUrn: String,
      entityTypeOpt: Option[String]
  ): Future[List[CleanUpResponse]] =
    entityTypeOpt match {
      case Some(entityType) =>
        connectionRepository.getConnectionFuture(connectionId).flatMap {
          case Some(connection) =>
            if (cleanUpHelper.remoteSupportsCleanup(connection)) {
              twinTraceRepository
                .getTwinTraceByRelationAndRemoteIssueUrnFuture(
                  connection,
                  remoteIssueUrn,
                  entityType,
                  Maps.newHashMap()
                )
                .map(_.map(_.getLocalReplica.getIssueKey))
                .map {
                  case Some(issueKey) =>
                    eventSchedulerService.scheduleCleanupEvent(connection, issueKey)
                    List.empty[CleanUpResponse] // NoContent
                  case None           =>
                    eventSchedulerService
                      .scheduleCleanupEventForRemoteIssue(connection, remoteIssueUrn, entityType)
                    List.empty[CleanUpResponse] // NoContent
                }
            } else {
              cleanUpForRemoteIssueKeepTwinTrace(connection, remoteIssueUrn, entityType)
                .flatMap(toResult)
            }
          case _                =>
            val message =
              s"Trying cleaning-up by remote ${entityTypeOpt.getOrElse("issue")} $remoteIssueUrn for connection $connectionId on both sides but connection was not found."
            LOG.debug(message)
            Future.failed(new NotFoundTrackerRestException(message))
        }
      case None             =>
        Future.failed(new BadRequestTrackerRestException("Query parameter `entityType` is missing"))
    }

  def doesRemoteSupportCleanup(connectionId: Int): Future[RemoteSupportsCleanUpResult] =
    connectionRepository.getConnectionFuture(connectionId).flatMap {
      case Some(connection) =>
        Future.successful(RemoteSupportsCleanUpResult(cleanUpHelper.remoteSupportsCleanup(connection)))
      case _                =>
        val message =
          s"Trying to check if remote supports cleanup for connection $connectionId but connection was not found."
        LOG.debug(message)
        Future.failed(new NotFoundTrackerRestException(message))
    }

  private def cleanIssueOnBoth(
      connection: IConnection,
      issueUrn: String,
      entityType: String,
      fieldValues: util.Map[String, String]
  ): Future[Option[CleanUpResult]] =
    twinTraceRepository
      .getTwinTraceByRelationAndLocalIssueUrnFuture(
        connection.getID,
        issueUrn,
        entityType,
        fieldValues
      )
      .flatMap {
        case Some(twinTrace) if twinTrace.getLocalReplica != null =>
          eventSchedulerService.scheduleCleanupEvent(
            connection,
            twinTrace.getLocalReplica.getIssueKey
          )
          Future.successful(None)
        case _                                                    =>
          LOG.debug(
            s"Trying cleaning-up issue $issueUrn for connection ${connection.getID} on both sides but twintrace was not found."
          )
          cleanUpSyncInfoForIssueKeepTwinTrace(connection.getID, issueUrn, entityType, fieldValues)
      }

  lazy val toResult: PartialFunction[Option[CleanUpResult], Future[List[CleanUpResponse]]] = {
    case Some(cleanUpResult) =>
      val cleanUpResponsesF = cleanUpResult.issuePairs.map {
        case (connectionId, issuePairsForRelation) =>
          val issuePairs = issuePairsForRelation.map(p => IssuePairs(p._1, p._2))
          val connectionNameFuture = connectionRepository
            .getConnectionFuture(connectionId)
            .map(_.map(_.getName).getOrElse("unknown"))
          val fileFuture = Future.fromTry(
            cleanUpHelper.getCsvFile(issuePairsForRelation, "CONNECTION", Some(connectionId.toString))
          )
          for {
            connectionName <- connectionNameFuture
            file <- fileFuture
          } yield CleanUpResponse(connectionName, issuePairs, file)
      }
      cleanUpResponsesF.toList.traverse(c => c)
    case None                => Future.successful(List.empty[CleanUpResponse])
  }

}
