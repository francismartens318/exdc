package com.exalate.replication.services.replication.in

import java.util.concurrent.{ConcurrentHashMap, ConcurrentMap}

import akka.actor.{ActorRef, ActorSystem, Cancellable}
import com.exalate.api.domain.connection.{
  ConnectionStatus,
  IConnection,
  InvitationStatus,
  ReceiveProtocol
}
import com.exalate.replication.services.api.replication.in.IPollSchedulerService
import com.exalate.replication.services.replication.worker.PollWorkerActor
import com.google.inject.name.Named
import com.google.inject.{Inject, Singleton}
import play.api.Logger

import scala.jdk.CollectionConverters._
import scala.concurrent.ExecutionContext
import scala.concurrent.duration._

@Singleton
class PollSchedulerService @Inject() (
    @Named("poll-worker-actor") pollWorkerActor: ActorRef,
    system: ActorSystem
)(implicit ec: ExecutionContext)
    extends IPollSchedulerService {

  private val LOG = Logger("application.services.replication.PollSchedulerService")

  private val pollSchedules: ConcurrentMap[Int, Cancellable] =
    new ConcurrentHashMap[Int, Cancellable]()

  override def handlePollScheduleOnUpdate(connection: IConnection): Unit =
    if (shouldPoll(connection)) ensurePollSchedule(connection)
    else removePollScheduleIfExists(connection.getID)

  private def ensurePollSchedule(connection: IConnection): Unit = {
    val scheduleExists = isScheduleExists(connection.getID)
    if (!scheduleExists) addSchedule(connection)
  }

  override def removePollScheduleIfExists(connectionId: Int): Unit = {
    val scheduleExists = isScheduleExists(connectionId)
    if (scheduleExists) removeSchedule(connectionId)
  }

  override def shouldPoll(connection: IConnection): Boolean = {
    val receiveProtocol = connection.getReceiveProtocol
    val connectionStatus = connection.getStatus
    val invitationStatus = connection.getInvitationStatus
    ReceiveProtocol.POLL == receiveProtocol && ConnectionStatus.ACTIVE == connectionStatus && InvitationStatus.ACCEPTED == invitationStatus
  }

  override def isScheduleExists(connectionId: Int): Boolean = {
    LOG.info(
      s"PollSchedulerService is checking whether a schedule exists for the connection with id `$connectionId`"
    )
    val schedule = pollSchedules.get(connectionId)
    schedule != null
  }

  override def addSchedule(connection: IConnection): Unit = {
    LOG.info(
      s"PollSchedulerService is going to add a schedule for the connection with id `${connection.getID}`"
    )
    val pollSchedule =
      system.scheduler.scheduleOnce(
        5.seconds,
        pollWorkerActor,
        PollWorkerActor.Poll(connection)
      )
    pollSchedules.put(connection.getID, pollSchedule)
  }

  override def removeSchedule(connectionId: Int): Unit = {
    LOG.info(
      s"PollSchedulerService is going to remove a schedule for the connection with id `$connectionId`"
    )
    Option(pollSchedules.remove(connectionId)).map(_.cancel()).map(_ => None)
  }

  override def removeAllSchedules(): Unit = {
    LOG.info(s"PollSchedulerService is going to remove all schedules")
    val schedules = pollSchedules.values()
    val scalaSchedules = schedules.asScala.toList
    pollSchedules.clear()
    scalaSchedules.map(_.cancel())
  }

}
