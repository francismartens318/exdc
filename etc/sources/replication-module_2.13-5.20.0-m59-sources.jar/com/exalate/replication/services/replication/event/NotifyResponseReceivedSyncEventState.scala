package com.exalate.replication.services.replication.event

import com.exalate.api.domain.event.{EventStatus, ISyncEvent}
import com.exalate.api.persistence.replication.event.IEventReplicationRepository
import com.exalate.replication.services.api.replication.worker.IWorkerNotificationService
import com.exalate.replication.services.api.transport.ITransportServiceFactory
import com.exalate.replication.services.replication.state.IState
import com.exalate.replication.services.transport.utils.ExalateVersionCheckerUtils
import com.google.inject.Inject

import scala.concurrent.ExecutionContext
import scala.concurrent.Future

class NotifyResponseReceivedSyncEventState @Inject() (
    transportServiceFactory: ITransportServiceFactory,
    persistence: IEventReplicationRepository,
    workerNotificationService: IWorkerNotificationService
)(implicit ec: ExecutionContext)
    extends IState[ISyncEvent] {

  /** Performs transition of one of the states of SyncEventStateMachine: status
    * `NOTIFY_RESPONSE_RECEIVED` the next state will be `ERROR_RESPONSE_READY` or `RESPONSE_READY`
    *
    * @param syncEvent
    * @return
    *   ISyncEvent
    */
  override def transition(syncEvent: ISyncEvent): Future[Option[ISyncEvent]] = {
    val future =
      if (ExalateVersionCheckerUtils.remoteSupportsNoExtraConfirmation(syncEvent.getConnection))
        Future.successful(None)
      else
        Future
          .fromTry(transportServiceFactory.get(syncEvent.getConnection))
          .flatMap(_.postResponseReceived(syncEvent))

    future
      .flatMap { _ =>
        Option(syncEvent.getErrorReason) match {
          case Some(_) =>
            persistence.updateSyncEventStatus(syncEvent, EventStatus.ERROR_RESPONSE_READY).map {
              se =>
                workerNotificationService.sendProcessEventsNotification()
                se
            }

          case None =>
            persistence.updateSyncEventStatus(syncEvent, EventStatus.RESPONSE_READY).map { se =>
              workerNotificationService.sendProcessEventsNotification()
              se
            }
        }
      }
  }

}
