package com.exalate.replication.services.replication.request

import com.exalate.api.domain.request.RequestStatus.SEND_RESPONSE
import com.exalate.api.domain.twintrace.TwinTraceStatus.UNEXALATED
import com.exalate.api.persistence.replication.request.ICreateOrUpdateTwinTraceSyncRequestStateRepository
import com.exalate.api.persistence.twintrace.ITwinTraceRepository
import com.exalate.error.services.api.IBugExceptionCategoryService
import com.exalate.replication.services.replication.state.IState
import com.google.inject.Inject
import org.slf4j.{Logger, LoggerFactory}

import scala.concurrent.{ExecutionContext, Future}

class MarkTwinTraceForCleanUpSyncRequestState @Inject() (
    createOrUpdateTwinTraceRepository: ICreateOrUpdateTwinTraceSyncRequestStateRepository,
    twinTraceRepository: ITwinTraceRepository,
    bugExceptionCategoryService: IBugExceptionCategoryService
)(implicit ec: ExecutionContext)
    extends IState[BasicSyncRequestContext] {

  private val LOG: Logger = LoggerFactory.getLogger(classOf[MarkTwinTraceForCleanUpSyncRequestState])

  /** Performs transition of one of the states of SyncRequestStateMachine: status
    * `DELETE_TWIN_TRACE`
    *
    * @param context
    * @return
    *   BasicSyncRequestContext
    */
  def transition(context: BasicSyncRequestContext): Future[Option[BasicSyncRequestContext]] = {
    val BasicSyncRequestContext(basicSyncRequest, connection) = context
    basicSyncRequest.remoteTwinTraceId match {
      case Some(remoteTwinTraceId) =>
        twinTraceRepository
          .getRequestTwinTraceDataByRemoteTwinTraceId(connection.getID, remoteTwinTraceId)
          .flatMap {
            // If the request came as far as to the MarkTwinTraceForCleanUpSyncRequestState state, then there's no way for
            // the twin trace not to be there anymore - we delete the twin trace only if there are no requests in the queue.
            // We may have the twin trace removed if the request was just scheduled (and it is in the RECEIVING_BLOBS / READY state)
            // and there were no requests / events in the queue when the clean up was happening.
            case Some(twinTraceData) =>
              createOrUpdateTwinTraceRepository
                .updateTwinTraceStatusAndRequestStatus(
                  twinTraceData.twinId,
                  Some(UNEXALATED),
                  basicSyncRequest.id,
                  SEND_RESPONSE
                )
                .map(_.map(r => context.copy(request = r)))
          }

      case _ =>
        val errMsg =
          s"A remote twin trace ID is missed in the sync request with id=${basicSyncRequest.id} though it is expected to be present."
        val ex = bugExceptionCategoryService.generateBugException(None, Some(errMsg))
        Future.failed(ex)
    }

  }

}
