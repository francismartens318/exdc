package com.exalate.replication.services.replication.event

import com.exalate.api.domain.event.{EventStatus, ISyncEvent}
import com.exalate.api.persistence.replication.event.IEventReplicationRepository
import com.exalate.replication.services.replication.state.IState
import javax.inject.Inject
import play.api.Logger

import scala.concurrent.ExecutionContext
import scala.concurrent.Future

class RemoveLinkSyncEventState @Inject() (persistence: IEventReplicationRepository)(implicit
    ec: ExecutionContext
) extends IState[ISyncEvent] {

  private val LOG: Logger = Logger(
    "com.exalate.replication.services.replication.event.RemoveLinkSyncEventState"
  )

  /** Performs transition of one of the states of SyncEventStateMachine: status `REMOVE_LINK` the
    * next state will be `PROCESSED`
    *
    * @param event
    * @return
    *   ISyncEvent
    */
  override def transition(event: ISyncEvent): Future[Option[ISyncEvent]] = {
    lazy val localIssueKey = event.getLocalReplica.getIssueKey
    lazy val relationName = event.getConnection.getName
    LOG.info(
      s"#transition: removing the link of the local issue for the issue `$localIssueKey` and relation `$relationName`"
    )

    // TODO: handle link removal
    /*hpqcHubObjectService.updateIssueLinkField(relation, localIssueKey, ???).flatMap(_ =>
      persistence.updateSyncEventStatus(event, EventStatus.UPDATE_TWINTRACE)
    )*/

    persistence.updateSyncEventStatus(event, EventStatus.PROCESSED)
  }

}
