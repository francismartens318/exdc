package com.exalate.replication.services.replication.request

import com.exalate.api.domain.IIssueKey
import com.exalate.api.domain.request.RequestStatus
import com.exalate.api.persistence.replication.request.IRequestReplicationRepository
import com.exalate.generic.services.api.ITrackerHubObjectService
import com.exalate.replication.services.replication.state.IState
import play.api.Logger

import javax.inject.Inject
import scala.concurrent.{ExecutionContext, Future}

class AddLinkSyncRequestState @Inject() (
    persistence: IRequestReplicationRepository,
    hubObjectService: ITrackerHubObjectService
)(implicit ec: ExecutionContext)
    extends IState[BasicSyncRequestContext] {

  val LOG = Logger("application.services.replication.request.AddLinkSyncRequestState")

  /** Performs transition of one of the states of SyncRequestStateMachine: status `ADD_LINK`
    *
    * @param context
    * @return
    *   BasicSyncRequestContext
    */
  override def transition(
      context: BasicSyncRequestContext
  ): Future[Option[BasicSyncRequestContext]] = {
    val BasicSyncRequestContext(basicSyncRequest, connection) = context
    val requestId = basicSyncRequest.id
    val createdIssueKey: IIssueKey = basicSyncRequest.createdIssueKey.get
    val remoteReplica = basicSyncRequest.replica
    val remoteIssueKey = remoteReplica.getIssueKey
    val remoteIssueUrn = remoteIssueKey.getURN
    LOG.info(
      s"#transitioning request `$requestId` for remote issue `$remoteIssueUrn`: adding the link from the issue $remoteIssueUrn` to `$createdIssueKey`"
    )
    // FIXME: If we want to reuse this code, we need a way to extract error handling to issue trackers
    val issueLinkFieldNameOpt =
      Option(connection.getTrackerSettings.getIssueLinkFieldName).filter(_.nonEmpty)
    val updateLinkFutureOpt = issueLinkFieldNameOpt.map(
      hubObjectService.updateEntityLinkField(connection, _, createdIssueKey, remoteIssueKey)
    )
    updateLinkFutureOpt
      .getOrElse(Future.successful(None))
      .flatMap(_ =>
        persistence.updateSyncRequestStatus(basicSyncRequest.id, RequestStatus.CREATE_REPLICA)
      )
      .map(_.map(r => context.copy(request = r)))
  }

}
