package com.exalate.replication.services.replication.scope

import com.exalate.api.domain.editor.error.{EditorErrorSide, ErrorLocationType}
import com.exalate.api.domain.hubobject.v1_2.IHubProject
import com.exalate.api.exception.CategorizedException
import com.exalate.api.exception.bug.BugException
import com.exalate.basic.domain.hubobject.v1.BasicHubIssue
import com.exalate.domain.editor.scopes.{FieldValue, OperatorValue, QueryValue, SingleSideScope}
import com.exalate.domain.exception.editor.{
  EditorCategorizedException,
  NoProjectEditorCategorizedException,
  StaleQueryValueEditorCategorizedException
}
import com.exalate.domain.transport.trackeroptions.ScopeQueryOperators._
import com.exalate.domain.transport.trackeroptions.{EditorFields, ScopeQueryOperators}
import com.exalate.replication.services.api.replication.scope.{
  IScopeQueryService,
  ITrackerScopeAndMappingHelper
}
import com.exalate.util.json.gson.GsonCaseClassValueJsonService
import com.google.inject.Inject

import scala.collection.JavaConverters
import scala.concurrent.{ExecutionContext, Future}
import scala.jdk.CollectionConverters._
import scala.util.{Failure, Success, Try}

class ScopeQueryService @Inject() (
    trackerScopeHelper: ITrackerScopeAndMappingHelper
)(implicit ec: ExecutionContext)
    extends IScopeQueryService {

  /** Checks whether the particular field of an issue that should be created/changed matches a query
    * value from scopes. The type of the actual value (fieldValue) depends on the field.
    *
    * The main matches algorithm is under [[fieldMatches]]
    *
    * @param hubIssue
    *   issue that should be created/changed
    * @param singleSideScope
    *   scope params of the single side. Has sequence of queryField (field: FieldValue, operator:
    *   OperatorValue, value: Object)
    * @return
    */
  override def matches(hubIssue: BasicHubIssue, singleSideScope: SingleSideScope): Boolean =
    singleSideScope.mainFields.foldLeft(true) {
      case (result, field) =>
        field.key match {
          case k if k == EditorFields.PROJECT.toString =>
            result && projectMatches(Option(hubIssue.getProject), field)
          case _                                       => result
        }
    } && (singleSideScope.query match {
      case None              => true
      case Some(queryFields) =>
        queryFields.foldLeft(true) {
          case (result, queryField) =>
            queryField match {
              case k if k.field.key == EditorFields.ISSUE_TYPE.toString  =>
                Option(hubIssue.getType).flatMap(o => Option(o.getId)) match {
                  case Some(id) => result && fieldMatches(Some(id), k.value, k.operator)
                  case None     =>
                    result && fieldMatches(
                      Option(hubIssue.getType).map(_.getName),
                      k.value,
                      k.operator
                    )
                }
              case k if k.field.key == EditorFields.SUMMARY.toString     =>
                result && fieldMatches(Option(hubIssue.getSummary), k.value, k.operator)
              case k if k.field.key == EditorFields.PRIORITY.toString    =>
                Option(hubIssue.getPriority).flatMap(o => Option(o.getId)) match {
                  case Some(id) => result && fieldMatches(Some(id), k.value, k.operator)
                  case None     =>
                    result && fieldMatches(
                      Option(hubIssue.getPriority).map(_.getName),
                      k.value,
                      k.operator
                    )
                }
              case k if k.field.key == EditorFields.STATUS.toString      =>
                Option(hubIssue.getStatus).flatMap(o => Option(o.getId)) match {
                  case Some(id) => result && fieldMatches(Some(id), k.value, k.operator)
                  case None     =>
                    result && fieldMatches(
                      Option(hubIssue.getStatus).map(_.getName),
                      k.value,
                      k.operator
                    )
                }
              case k if k.field.key == EditorFields.DESCRIPTION.toString =>
                result && fieldMatches(Option(hubIssue.getDescription), k.value, k.operator)

              case k if k.field.key == EditorFields.LABELS.toString   =>
                result && Option(hubIssue.getLabels).toSeq
                  .map(JavaConverters.asScalaSet)
                  .flatMap(_.toSeq)
                  .map(_.getLabel)
                  .exists(actualValue => fieldMatches(Option(actualValue), k.value, k.operator))
              case k if k.field.key == EditorFields.ASSIGNEE.toString =>
                Option(hubIssue.getAssignee) match {
                  case Some(assignee) =>
                    result && (fieldMatches(
                      Option(assignee.getKey),
                      k.value,
                      k.operator
                    ) || (fieldMatches(Option(assignee.getEmail), k.value, k.operator)))
                  case None           => result
                }
              case k if k.field.key == EditorFields.REPORTER.toString =>
                Option(hubIssue.getReporter) match {
                  case Some(reporter) =>
                    result && (fieldMatches(
                      Option(reporter.getKey),
                      k.value,
                      k.operator
                    ) || (fieldMatches(Option(reporter.getEmail), k.value, k.operator)))
                  case None           => result
                }
              case _                                                  => result
            }
        }
    })

  /*
  Case classes for visual editor, depends on the exception obtained from scope rules
   */
  sealed abstract class MainFieldAndError[T](
      val fieldKey: String,
      val valueOrError: Either[T, CategorizedException]
  )

  final case class UnknownMainFieldError(override val fieldKey: String)
      extends MainFieldAndError[Object](fieldKey, Right(new BugException(s"Unknown field $fieldKey")))

  final case class ProjectFieldAndError(
      override val valueOrError: Either[IHubProject, CategorizedException]
  ) extends MainFieldAndError(EditorFields.PROJECT.toString, valueOrError)

  /** Validate main fields (currently PROJECT), if Exalate did not manage to extract project from
    * issue tracker returns Exception
    * @param singleSideScope
    *   scope rules from one side
    * @param side
    *   side identification LOCAL, REMOTE
    * @return
    *   seq of exception if validation failed
    */
  override def validate(
      singleSideScope: SingleSideScope,
      side: EditorErrorSide
  ): Future[Seq[EditorCategorizedException]] =
    (for {
      mainFieldsAndErrors <- getMainFieldsAndErrorsFuture(singleSideScope)

      mainFieldErrors = mainFieldsAndErrors
        .flatMap {
          case m: MainFieldAndError[_] if m.valueOrError.isRight =>
            Option(m.valueOrError.right.get)
          case _                                                 => None
        }

      queryErrors <- getQueryErrorsFuture(singleSideScope, side, mainFieldsAndErrors)
    } yield mainFieldErrors ++ queryErrors)
      .map(_.collect { case e: EditorCategorizedException => e })

  private def getQueryErrorsFuture(
      singleSideScope: SingleSideScope,
      side: EditorErrorSide,
      mainFieldsAndErrors: Seq[MainFieldAndError[_]]
  ): Future[Seq[CategorizedException]] =
    Future
      .sequence(
        singleSideScope.query.toSeq.flatten
          .map {
            case k if k.field.key == EditorFields.ISSUE_TYPE.toString  =>
              validateOptionQuery(singleSideScope, side, mainFieldsAndErrors, k) {
                (pId: Option[String], issueTypeName: String) =>
                  trackerScopeHelper.getIssueType(issueTypeName, pId)
              }
            case k if k.field.key == EditorFields.SUMMARY.toString     =>
              noValidation
            case k if k.field.key == EditorFields.PRIORITY.toString    =>
              validateOptionQuery(singleSideScope, side, mainFieldsAndErrors, k) {
                (pId: Option[String], priorityName: String) =>
                  trackerScopeHelper.getPriority(priorityName, pId)
              }
            case k if k.field.key == EditorFields.STATUS.toString      =>
              // TODO EXE-683, delay impl, for now:
              noValidation
            case k if k.field.key == EditorFields.DESCRIPTION.toString =>
              noValidation
            case k if k.field.key == EditorFields.LABELS.toString      =>
              noValidation
            case _                                                     =>
              noValidation
          }
      )
      .map(_.flatten)

  /** Gets main fields (currently PROJECT) values and
    * @param singleSideScope
    *   scope rules from one side
    * @return
    *   seq of project values (IHubProject)
    */
  private def getMainFieldsAndErrorsFuture(
      singleSideScope: SingleSideScope
  ): Future[Seq[MainFieldAndError[_]]] =
    Future.sequence(
      singleSideScope.mainFields
        .map {
          case k if k.key == EditorFields.PROJECT.toString =>
            k.value.flatMap(toValueStr) match {
              case None    =>
                Future.successful(
                  ProjectFieldAndError(
                    Right(
                      new BugException(s"main field ${k.key} in scope $singleSideScope has no value!")
                    )
                  )
                )
              case Some(v) =>
                getProject(v, singleSideScope, k)
                  .map(p => ProjectFieldAndError(Left(p)): MainFieldAndError[_])
                  .recover {
                    case e: CategorizedException =>
                      ProjectFieldAndError(Right(e)): MainFieldAndError[_]
                    case e                       =>
                      ProjectFieldAndError(
                        Right(
                          new BugException(
                            s"Failed to validate project $v for scope ${singleSideScope.scopeUid}",
                            e
                          )
                        )
                      ): MainFieldAndError[_]
                  }
            }
          case k => Future.successful(UnknownMainFieldError(k.key))
        }
    )

  private def noValidation: Future[Seq[CategorizedException]] =
    Future.successful(Seq.empty[CategorizedException])

  /** Validates scope option query
    * @param singleSideScope
    *   scope rules from one side
    * @param side
    *   LOCAL, REMOTE
    * @param mainFieldsAndErrors
    *   seq of main fields obtained from issue tracker
    * @param k
    *   QueryValue
    * @param getOptionFn
    * @return
    *   seq of exceptions if validation failed
    */
  private def validateOptionQuery(
      singleSideScope: SingleSideScope,
      side: EditorErrorSide,
      mainFieldsAndErrors: Seq[MainFieldAndError[_]],
      k: QueryValue
  )(getOptionFn: (Option[String], String) => Future[Option[_]]) = {
    val projectIdOpt = mainFieldsAndErrors
      .collectFirst {
        case m: ProjectFieldAndError if m.valueOrError.isLeft =>
          m.valueOrError.left.get
      }
      .flatMap(p => Option(p.getIdStr))
    val valueFromQuery = k.value
    ScopeQueryOperators.withNameOpt(k.operator.key) match {
      case Some(inOrNotIn) if inOrNotIn == IN || inOrNotIn == NOT_IN =>
        Future
          .sequence(
            toStrSeq(valueFromQuery)(toLabelStr).toOption.toSeq.flatten
              .map { label =>
                getOptionFn(projectIdOpt, label)
                  .map {
                    case None    =>
                      Seq(
                        StaleQueryValueEditorCategorizedException(
                          singleSideScope.scopeUid,
                          label,
                          k.field.key,
                          // TODO EXE-683 find field label through
                          EditorFields.getReadableLabelByKey(k.field.key),
                          side
                        )
                      )
                    case Some(_) =>
                      Seq.empty[CategorizedException]
                  }
              }
          )
          .map(_.flatten)
      case Some(_)                                                   =>
        noValidation
      case None                                                      =>
        Future.successful(
          Seq(new BugException(s"filter $k has unrecognized opertor ${k.operator.key}"))
        )
    }
  }

  def toStrSeq(v: Object)(toStrFn: Object => Option[String]): Try[Seq[String]] = v match {
    case vL if vL.isInstanceOf[java.util.List[Object]] =>
      Success(vL.asInstanceOf[java.util.List[Object]].asScala.toSeq.flatMap(v => toStrFn(v)))
    case vS if vS.isInstanceOf[Seq[Object]]            =>
      Success(vS.asInstanceOf[Seq[Object]].flatMap(v => toStrFn(v)))
    case _                                             =>
      Failure[Seq[String]](
        new ClassCastException(
          "Expecting to have Either Java List or a Scala Seq, but got: " + v + "of class: " + v.getClass
        )
      )
  }

  /** Overrides main fields (currently PROJECT) of provided hub issue with values from scope rules
    * @param hubIssue
    *   issue that is going to be updated
    * @param scope
    *   scope rules from one side
    * @return
    *   updated issue
    */
  override def overrideMainFields(
      hubIssue: BasicHubIssue,
      scope: SingleSideScope
  ): Future[BasicHubIssue] =
    scope.mainFields.foldLeft(Future.successful(hubIssue)) {
      case (updatedHubIssueFut, field) =>
        updatedHubIssueFut.flatMap { updated =>
          field.key match {
            case k if k == EditorFields.PROJECT.toString =>
              field.value.flatMap(toValueStr) match {
                case None         => Future.successful(updated)
                case Some(projId) =>
                  getProject(projId, scope, field)
                    .map {
                      case p if Option(p.getKey).isDefined =>
                        updated.setProject(p)
                        updated.setProjectKey(p.getKey)
                        updated

                      case _ => updated
                    }
              }
            case _                                       => Future.successful(updated)
          }
        }
    }

  /** Gets project by id from issue tracker
    * @param projId
    * @param scope
    * @param field
    * @return
    *   hub project or NoProjectEditorCategorizedException
    */
  private def getProject(
      projId: String,
      scope: SingleSideScope,
      field: FieldValue
  ): Future[IHubProject] =
    trackerScopeHelper
      .getProject(projId)
      .flatMap {
        case None =>
          val projectName = field.value.flatMap { o =>
            GsonCaseClassValueJsonService
              .write(o)
              .flatMap(j =>
                GsonCaseClassValueJsonService
                  .read[Map[String, Object]](j, classOf[Map[String, Object]])
              )
              .toOption
              .flatMap(_.get("label"))
              .map(_.asInstanceOf[String])
          }
          Future.failed(
            NoProjectEditorCategorizedException(
              scope.scopeUid,
              projectName.getOrElse("None"),
              projId,
              ErrorLocationType.SCOPE_MAIN_FIELD,
              EditorErrorSide.REMOTE
            )
          )

        case Some(p) => Future.successful(p)

      }

  /** Checks whether provided project and project from provided FieldValue does match
    * @param hubProjectOpt
    * @param projField
    * @return
    *   true or false
    */
  private def projectMatches(hubProjectOpt: Option[IHubProject], projField: FieldValue): Boolean = {
    val projectFieldValueOpt = projField.value.flatMap(toValueStr)
    projectFieldValueOpt match {
      case None                   => true
      case Some(prjFieldCriteria) => hubProjectOpt.map(_.getIdStr).contains(prjFieldCriteria)
    }
  }

  /** Gets `value` from object (field)
    * @param v
    * @return
    */
  private def toValueStr(v: Object) =
    toStr("value")(v)

  private def toStr(key: String)(v: Object) = {
    def mapToStr(in: Map[String, Object]): Option[String] =
      in.get(key)
        .map(_.toString)

    v match {
      case _: java.util.Map[String, Object] =>
        mapToStr(
          JavaConverters
            .mapAsScalaMap(v.asInstanceOf[java.util.Map[String, Object]])
            .toMap
        )
      case _: Map[String, Object]           =>
        mapToStr(
          v
            .asInstanceOf[Map[String, Object]]
        )
      case _: String                        => Option(v.asInstanceOf[String])
      case _                                => Option.empty[String]
    }
  }

  /** Gets `label` from object (field)
    * @param v
    * @return
    */
  private def toLabelStr(v: Object) =
    toStr("label")(v)

  /** The method that compares input value (taken from valueFromQuery) with actual value of an issue
    * (fieldValue). The way it's compared depends on the operator The type of the query value
    * (valueFromQuery) also depends on the operator.
    *
    * @param fieldValue
    *   actual value extracted from hubIssue
    * @param valueFromQuery
    *   values extracted from the query. The values may have different types, namely:
    *   TEXT,OPTION,MULTI,FILE,COMMENT
    * @param operator
    *   query operator defined here [[ScopeQueryOperators]]
    * @return
    */
  private def fieldMatches(
      fieldValue: Option[String],
      valueFromQuery: Object,
      operator: OperatorValue
  ): Boolean =
    ScopeQueryOperators.withNameOpt(operator.key) match {
      case Some(IS)       => toValueStr(valueFromQuery).exists(value => fieldValue.contains(value))
      case Some(IS_NOT)   => toValueStr(valueFromQuery).exists(value => !fieldValue.contains(value))
      case Some(CONTAINS) =>
        toValueStr(valueFromQuery).exists(value => fieldValue.forall(_.contains(value)))
      case Some(DOES_NOT_CONTAIN) =>
        toValueStr(valueFromQuery).exists(value => !fieldValue.forall(_.contains(value)))

      case Some(IN)     =>
        toStrSeq(valueFromQuery)(toValueStr).toOption
          .exists(_.exists(value => fieldValue.contains(value)))
      case Some(NOT_IN) =>
        toStrSeq(valueFromQuery)(toValueStr).toOption
          .exists(_.exists(value => !fieldValue.contains(value)))
      // TODO should we faile with a bug Exception?
      case None         => false
    }

}
