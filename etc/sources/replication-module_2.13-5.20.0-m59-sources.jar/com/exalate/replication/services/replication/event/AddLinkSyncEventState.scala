package com.exalate.replication.services.replication.event

import javax.inject.Inject
import com.exalate.api.domain.event.{EventStatus, ISyncEvent}
import com.exalate.api.persistence.replication.event.IEventReplicationRepository
import com.exalate.generic.services.api.ITrackerHubObjectService
import play.api.Logger
import com.exalate.replication.services.api.error.{IErrorService, SyncContext}
import com.exalate.replication.services.replication.state.IState

import scala.concurrent.ExecutionContext
import scala.concurrent.Future

class AddLinkSyncEventState @Inject() (
    persistence: IEventReplicationRepository,
    hubObjectService: ITrackerHubObjectService
)(implicit ec: ExecutionContext)
    extends IState[ISyncEvent] {

  private val LOG: Logger = Logger(
    "com.exalate.replication.services.replication.event.AddLinkSyncEventState"
  )

  /** Performs transition of one of the states of SyncEventStateMachine: status `ADD_LINK` the next
    * state will be `UPDATE_TWINTRACE`
    * @param event
    * @return
    */
  override def transition(event: ISyncEvent): Future[Option[ISyncEvent]] = {
    lazy val localIssueKey = event.getLocalReplica.getIssueKey
    lazy val connection = event.getConnection
    lazy val remoteIssueKey = event.getRemoteReplica.getIssueKey
    val trackerSettings = connection.getTrackerSettings
    val issueLinkFieldNameOpt = Option(trackerSettings.getIssueLinkFieldName).filter(_.nonEmpty)
    LOG.info(
      s"#transitioning event `${event.getId}` for local issue `${localIssueKey.getURN}`: Adding link to remote issue `${remoteIssueKey.getURN}`"
    )

    // FIXME for reusing this code we will need to extract error handling into tracker logic

    val updateLinkFutureOpt = issueLinkFieldNameOpt.map(
      hubObjectService.updateEntityLinkField(connection, _, localIssueKey, remoteIssueKey)
    )

    updateLinkFutureOpt
      .getOrElse(Future.successful(None))
      .flatMap(_ => persistence.updateSyncEventStatus(event, EventStatus.UPDATE_TWINTRACE))
  }

}
