package com.exalate.replication.services.replication.request

import com.exalate.api.domain.request.{ISyncRequest, RequestStatus}

import javax.inject.Inject

class WaitingResponseReceivedService @Inject() () {

  def getNextStatus(syncRequest: ISyncRequest): RequestStatus =
    RequestStatus.RESPONSE_SENT

}
