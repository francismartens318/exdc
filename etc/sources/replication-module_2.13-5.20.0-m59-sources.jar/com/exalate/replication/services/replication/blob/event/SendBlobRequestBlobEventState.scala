package com.exalate.replication.services.replication.blob.event

import javax.inject.Inject

import com.exalate.api.domain.blob.event.{BlobEventStatus, IBlobEvent}
import com.exalate.api.domain.connection.SendProtocol
import com.exalate.api.persistence.replication.blobevent.IBlobEventReplicationRepository
import com.exalate.replication.services.api.error.IErrorService
import com.exalate.replication.services.api.replication.ISyncEventService
import com.exalate.replication.services.api.transport.ITransportServiceFactory
import com.exalate.replication.services.replication.state.IState
import play.api.Logger

import scala.concurrent.ExecutionContext
import scala.concurrent.Future

class SendBlobRequestBlobEventState @Inject() (
    persistence: IBlobEventReplicationRepository,
    transportServiceFactory: ITransportServiceFactory
)(implicit ec: ExecutionContext)
    extends IState[IBlobEvent] {

  val LOG = Logger("application.services.replication.blob.event.SendBlobRequestBlobEventState")

  /** Performs transition of one of the states of BlobEventStateMachine: status `SEND_BLOB_REQUEST`
    * @param blobEvent
    * @return
    *   IBlobEvent
    */
  override def transition(blobEvent: IBlobEvent): Future[Option[IBlobEvent]] = {
    val syncEvent = blobEvent.getSyncEvent
    val connection = syncEvent.getConnection
    Future
      .fromTry(transportServiceFactory.get(connection))
      .flatMap(_.sendBlobRequest(blobEvent))
      .flatMap { _ =>
        val connection = blobEvent.getSyncEvent.getConnection
        val remoteNodeInfo = connection.getRemoteInstance.getNodeInfo
        val sendProtocol = connection.getSendProtocol
        val nextStatus =
          if (remoteNodeInfo.isPollOnly || Option(sendProtocol).contains(SendProtocol.WAIT_FOR_POLL)) {
            BlobEventStatus.WAITING_BLOB_REQUEST_RECEIVED
          } else {
            BlobEventStatus.PUBLISH_BLOB_IF_NEEDED
          }
        persistence.updateBlobEventStatus(blobEvent, nextStatus).map(Some(_))
      }
  }

}
