package com.exalate.replication.services.replication.event

import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.event.{EventStatus, ISyncEvent}
import com.exalate.api.domain.twintrace.TwinType
import com.exalate.api.domain.{ErrorEntityType, ErrorKeys, ErrorReason, SyncRequestEventType}
import com.exalate.api.exception.{CategorizedException, IssueTrackerException}
import com.exalate.api.persistence.replication.event.IEventReplicationRepository
import com.exalate.api.persistence.twintrace.ITwinTraceRepository
import com.exalate.error.services.api.ILicenseExceptionCategoryService
import com.exalate.replication.services.api.error.{IErrorService, SyncContext}
import com.exalate.replication.services.api.replication.ISyncEventService
import com.exalate.replication.services.api.replication.worker.IWorkerNotificationService
import com.exalate.replication.services.replication.event.ErrorResponseReadyEventState.errorMessageContext
import com.exalate.replication.services.replication.state.IState
import com.google.inject.Inject
import play.api.Logger

import scala.concurrent.ExecutionContext
import scala.concurrent.Future

class ErrorResponseReadyEventState @Inject() (
    persistence: IEventReplicationRepository,
    workerNotificationService: IWorkerNotificationService,
    errorService: IErrorService,
    syncEventService: ISyncEventService,
    twinTraceRepository: ITwinTraceRepository,
    exceptionCategoryService: ILicenseExceptionCategoryService
)(implicit ec: ExecutionContext)
    extends IState[ISyncEvent] {

  private val LOG: Logger = Logger(
    "com.exalate.replication.services.replication.event.ErrorResponseReadyEventState"
  )

  /** Performs transition of one of the states of SyncEventStateMachine: status
    * `ERROR_RESPONSE_READY` the next state will be `PROCESSED` or `READY`
    *
    * @param syncEvent
    * @return
    *   ISyncEvent
    */
  override def transition(syncEvent: ISyncEvent): Future[Option[ISyncEvent]] = {
    lazy val exception = {
      val messageOpt = Option(syncEvent.getErrorResponseMessage).map(errorMsg =>
        s"Error message from remote side using connection ${syncEvent.getConnection.getName}:\n '$errorMsg'"
      )
      new IssueTrackerException(messageOpt.orNull)
    }

    twinTraceRepository
      .getTwinTraceById(syncEvent.getTwinTraceId)
      .map { twinTraceOpt =>
        if (syncEvent.getEventNumber == 1 && twinTraceOpt.exists(tt => tt.getType == TwinType.PARENT)) {
          twinTraceRepository.updateTwinTracePayedDate(twinTraceOpt.get, None)
        }
      }
      .flatMap { _ =>
        Option(syncEvent.getErrorReason) match {
          case Some(errorReason) =>
            errorReason match {
              case reason
                  if ErrorReason.ISSUE_DELETED == reason || ErrorReason.UNEXALATED == reason || reason == ErrorReason.OUT_OF_BAND_REQUEST =>
                updateSyncEventStatusAndFireNotification(syncEvent, EventStatus.PROCESSED)

              case reason if ErrorReason.NOT_SUPPORTED_SYNC_TYPE == reason =>
                val errorMessage =
                  s"${errorMessageContext(syncEvent.getConnection, syncEvent)}. Sync event type '${syncEvent.getSyncType}' is not unsupported by destination instance. " +
                    s"Please update or downgrade your Exalate app."
                LOG.error(errorMessage)
                updateSyncEventStatusAndFireNotification(syncEvent, EventStatus.PROCESSED)

              case reason if reason == ErrorReason.NO_ISSUE_TO_CONNECT_TO =>
                createWarningError(syncEvent, exception)
                  .flatMap(_ =>
                    updateSyncEventStatusAndFireNotification(
                      syncEvent,
                      EventStatus.PROCESSED,
                      Option(SyncRequestEventType.CLEANUP)
                    )
                  )

              case reason if reason == ErrorReason.SYNC_NOT_PAID =>
                val syncNotPaidEx = exceptionCategoryService.generateSyncNotPaidException(
                  Option(syncEvent.getErrorResponseMessage)
                )
                val errorMessage =
                  s"${errorMessageContext(syncEvent.getConnection, syncEvent)}. " +
                    s"${syncNotPaidEx.getMessage}."
                LOG.error(errorMessage)
                createError(
                  syncEvent,
                  syncNotPaidEx,
                  Option(
                    ErrorKeys.getLicenseErrorKey(
                      syncEvent.getConnection.getID,
                      Option(syncEvent.getLocalReplica.getIssueKey)
                    )
                  )
                )
                  .flatMap(_ =>
                    updateSyncEventStatusAndFireNotification(syncEvent, EventStatus.READY)
                  )
              case _                                             =>
                createError(syncEvent, exception)
                  .flatMap(_ =>
                    updateSyncEventStatusAndFireNotification(syncEvent, EventStatus.PROCESSED)
                  )
            }

          case None =>
            createError(syncEvent, exception)
              .flatMap(_ =>
                updateSyncEventStatusAndFireNotification(syncEvent, EventStatus.PROCESSED)
              )
        }
      }

  }

  private def createError(
      syncEvent: ISyncEvent,
      exception: Exception,
      errorKey: Option[String] = None
  ): Future[None.type] =
    syncEventService.getRemoteIssueKey(syncEvent).flatMap { remoteIssueKeyOpt =>
      val reportErrorRes = exception match {
        case e: CategorizedException =>
          errorService.createError(
            e,
            SyncContext.createWithSyncEvent(syncEvent).copy(remoteIssueKeyOpt = remoteIssueKeyOpt),
            errorKey
          )
        case e                       =>
          errorService.createError(
            ErrorEntityType.ISSUE,
            e,
            SyncContext.createWithSyncEvent(syncEvent).copy(remoteIssueKeyOpt = remoteIssueKeyOpt),
            errorKey
          )
      }

      reportErrorRes.map(_ => None)
    }

  private def createWarningError(syncEvent: ISyncEvent, exception: Exception): Future[None.type] =
    syncEventService.getRemoteIssueKey(syncEvent).flatMap { remoteIssueKeyOpt =>
      val syncContext = SyncContext(
        connection = Option(syncEvent.getConnection),
        syncEventOpt = None,
        localIssueKeyOpt = Option(syncEvent.getLocalReplica).map(_.getIssueKey),
        remoteIssueKeyOpt = remoteIssueKeyOpt
      )

      (exception match {
        case e: CategorizedException =>
          errorService.createError(
            ErrorEntityType.WARNING,
            e,
            syncContext,
            None
          )
        case e                       =>
          errorService.createError(
            ErrorEntityType.WARNING,
            e,
            syncContext,
            None
          )
      }).map(_ => None)
    }

  private def updateSyncEventStatusAndFireNotification(
      syncEvent: ISyncEvent,
      nextStatus: EventStatus,
      syncTypeOpt: Option[SyncRequestEventType] = None
  ): Future[Option[ISyncEvent]] = {
    syncEvent.setErrorReason(null)
    syncEvent.setErrorResponseMessage(null)
    for {
      syncEventOpt <- persistence.updateSyncEventStatusAndErrorReasonAndErrorMessage(
        syncEvent,
        nextStatus,
        syncTypeOpt.getOrElse(syncEvent.getSyncType)
      )
      _ = workerNotificationService.sendProcessEventsNotification()
    } yield syncEventOpt
  }

}

object ErrorResponseReadyEventState {

  def errorMessageContext(connection: IConnection, syncEvent: ISyncEvent): String =
    s"The destination instance for connection ${connection.getName} responded with error to sync event with id `${syncEvent.getId}` for local entity ${syncEvent.getLocalReplica.getIssueKey.getURN} scheduled at ${syncEvent.getLocalReplica.getValidOn}."

}
