package com.exalate.replication.services.replication.event

import com.exalate.api.domain.event.{EventStatus, ISyncEvent}
import com.exalate.api.persistence.replication.event.IEventReplicationRepository
import com.exalate.replication.services.api.replication.worker.IWorkerNotificationService
import com.exalate.replication.services.replication.state.IState
import javax.inject.Inject

import scala.concurrent.{ExecutionContext, Future}

class SendBlobsEventState @Inject() (
    persistence: IEventReplicationRepository,
    workerNotificationService: IWorkerNotificationService
)(implicit ec: ExecutionContext)
    extends IState[ISyncEvent] {

  /** Performs transition of one of the states of SyncEventStateMachine: status `SEND_BLOBS` the
    * next state will be `WAITING_FOR_RESPONSE`
    *
    * @param event
    * @return
    *   ISyncEvent
    */
  override def transition(event: ISyncEvent): Future[Option[ISyncEvent]] =
    persistence
      .createBlobEventsAndUpdateEventStatus(event, EventStatus.WAITING_FOR_RESPONSE)
      .map { e =>
        workerNotificationService.sendProcessBlobEventsNotification()
        e
      }

}
