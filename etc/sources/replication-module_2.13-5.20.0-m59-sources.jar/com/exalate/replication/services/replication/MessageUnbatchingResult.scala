package com.exalate.replication.services.replication

import com.exalate.domain.transport.message.{ExalateMessage, ExalateMessageChunk}

/** @param messageToChunks
  *   \- messages to chunks which were used to compose the messages
  */
case class MessageUnbatchingResult(messageToChunks: Map[ExalateMessage, Seq[ExalateMessageChunk]])
