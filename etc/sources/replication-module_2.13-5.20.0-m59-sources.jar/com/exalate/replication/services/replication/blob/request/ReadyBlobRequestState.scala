package com.exalate.replication.services.replication.blob.request

import javax.inject.Inject

import com.exalate.api.domain.blob.request.{BlobRequestStatus, IBlobRequest}
import com.exalate.api.persistence.replication.request.IUpdateBlobSyncRequestRepository
import play.api.Logger
import com.exalate.replication.services.replication.state.IState

import scala.concurrent.ExecutionContext
import scala.concurrent.Future

class ReadyBlobRequestState @Inject() (updateBlobRepository: IUpdateBlobSyncRequestRepository)(
    implicit ec: ExecutionContext
) extends IState[IBlobRequest] {
  val LOG: Logger = Logger("services.replication.blob.request.ReadyBlobRequestState")

  /** Performs transition of one of the states of BlobRequestStateMachine: status `READY`
    * @param blobRequest
    * @return
    *   IBlobRequest
    */
  override def transition(blobRequest: IBlobRequest): Future[Option[IBlobRequest]] =
    updateBlobRepository
      .updateBlobRequestStatus(blobRequest, BlobRequestStatus.RECEIVE_BLOB)
      .map(Some(_))

}
