package com.exalate.replication.services.replication.worker

import akka.actor.{Actor, Props}
import com.exalate.replication.services.api.replication.IEventProcessorService
import com.exalate.replication.services.api.replication.blob.IBlobEventProcessorService
import com.exalate.replication.services.replication.worker.messages.EventWorkerMessages.{
  AfterTheLastMessage,
  ProcessEvents
}
import com.google.inject.Inject
import play.api.Logger

import scala.concurrent.ExecutionContextExecutor
import scala.util.{Failure, Success}

object EventWorkerActor {

  def props(
      eventProcessorService: IEventProcessorService,
      blobEventProcessorService: IBlobEventProcessorService
  ): Props = Props(new EventWorkerActor(eventProcessorService, blobEventProcessorService))

}

class EventWorkerActor @Inject() (
    eventProcessorService: IEventProcessorService,
    blobEventProcessorService: IBlobEventProcessorService
) extends Actor {

  val LOG: Logger = Logger("application.services.replication.worker.EventWorkerActor")
  implicit private val ec: ExecutionContextExecutor = context.dispatcher

  private val waiting: Receive = {
    case ProcessEvents =>
      LOG.trace("EventWorkerActor:waiting:_")
      self ! AfterTheLastMessage
      context.become(waitingForAfterTheLastMessage)
  }

  private def waitingForAfterTheLastMessage: Receive = {
    case AfterTheLastMessage =>
      LOG.trace(
        "EventWorkerActor:waitingForAfterTheLastMessage AfterTheLastMessage - ProcessBlobEvents"
      )
      blobEventProcessorService.processBlobEvents() onComplete {
        case Success(_)  =>
          LOG.trace(
            "EventWorkerActor:waitingForAfterTheLastMessage AfterTheLastMessage - processSyncEvents"
          )
          processEvents()
        case Failure(ex) =>
          LOG.error(
            s"#processBlobEvents failed to process processBlobEvents",
            ex
          )
          processEvents()
      }
    case ProcessEvents       =>
      // We avoid processing unnecessary messages, relaying that if we are in this actor state, there is a AfterTheLastMessage on the queue
      LOG.trace("EventWorkerActor:waitingForAfterTheLastMessage:_")
  }

  private def processEvents(): Unit =
    eventProcessorService
      .processSyncEvents()
      .onComplete {
        case Success(_)         =>
          LOG.trace(
            "EventWorkerActor:waitingForAfterTheLastMessage AfterTheLastMessage - processSyncEvents - Success"
          )
          context.become(waiting)
        case Failure(exception) =>
          LOG.error(
            "EventWorkerActor:waitingForAfterTheLastMessage AfterTheLastMessage - processSyncEvents - Failure",
            exception
          )
          context.become(waiting)
      }

  def receive: Receive = waiting
}
