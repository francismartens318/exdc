package com.exalate.replication.services.replication.oauth

import com.exalate.api.domain.connection.fieldvalues.FieldValues
import com.exalate.domain.{GeneralSettings, InferredGeneralSettings}
import com.exalate.generic.services.oauth.INodeOAuthHelper
import com.exalate.replication.services.api.config.IGeneralSettingsService
import com.google.inject.Inject

import scala.concurrent.{ExecutionContext, Future}

class OAuthHelper @Inject() (
    generalSettingsService: IGeneralSettingsService,
    nodeOAuthHelper: INodeOAuthHelper
)(implicit executionContext: ExecutionContext) {

  def hasToInitiateAuthenticationFlow(): Future[Boolean] =
    for {
      hasValidContext <- nodeOAuthHelper.hasOauthContext
      hasRT <- hasRefreshToken
    } yield !hasRT && hasValidContext

  def hasRefreshToken: Future[Boolean] =
    generalSettingsService.get
      .map(_.flatMap(gs => gs.fieldValues.get(FieldValues.REFRESH_TOKEN.toString)))
      .map(_.isDefined)

  def removeOAuthTokens(fieldValues: Map[String, String]): Map[String, String] =
    fieldValues.filter(fv =>
      fv._1 != FieldValues.REFRESH_TOKEN.toString && fv._1 != FieldValues.ACCESS_TOKEN.toString
    )

  def shouldRemoveOAuthTokens(oldGs: InferredGeneralSettings, newGs: GeneralSettings): Boolean =
    nodeOAuthHelper.shouldRemoveOauthTokens(oldGs, newGs)

}
