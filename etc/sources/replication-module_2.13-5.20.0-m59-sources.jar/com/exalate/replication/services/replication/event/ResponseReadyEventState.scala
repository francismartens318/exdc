package com.exalate.replication.services.replication.event

import javax.inject.Inject
import com.exalate.api.domain.{IIssueKey, SyncRequestEventType}
import com.exalate.api.domain.event.{EventStatus, ISyncEvent}
import com.exalate.api.persistence.replication.event.IEventReplicationRepository
import com.exalate.api.persistence.twintrace.ITwinTraceRepository
import com.exalate.domain.replication.BasicSyncEvent
import play.api.Logger
import com.exalate.replication.services.replication.state.IState

import scala.concurrent.ExecutionContext
import scala.concurrent.Future

class ResponseReadyEventState @Inject() (
    persistence: IEventReplicationRepository,
    twinTraceRepository: ITwinTraceRepository
)(implicit ec: ExecutionContext)
    extends IState[ISyncEvent] {

  private val LOG: Logger = Logger(
    "com.exalate.replication.services.replication.event.ResponseReadyEventState"
  )

  /** Performs transition of one of the states of SyncEventStateMachine: status `RESPONSE_READY` the
    * next state will be `REMOVE_LINK`, `PROCESSED` or `UPDATE_TWINTRACE`
    *
    * @param syncEvent
    * @return
    *   ISyncEvent
    */
  override def transition(syncEvent: ISyncEvent): Future[Option[ISyncEvent]] =
    getNextStatus(syncEvent)
      .flatMap {
        case (nextStatus, typeOpt) =>
          persistence.updateSyncEventType(syncEvent, nextStatus, typeOpt)
      }

  private def getNextStatus(
      syncEvent: ISyncEvent
  ): Future[(EventStatus, Option[SyncRequestEventType])] =
    twinTraceRepository
      .getTwinTraceById(syncEvent.getTwinTraceId)
      .flatMap {
        case Some(twinTrace) =>
          if (BasicSyncEvent.isCleanupOrUnexalateEvent(syncEvent)) {
            Future.successful(EventStatus.REMOVE_LINK, None)
          } else if (BasicSyncEvent.isDeleteEvent(syncEvent)) {
            Future.successful(EventStatus.PROCESSED, None)
          } else if (BasicSyncEvent.isPairResponse(syncEvent, twinTrace)) {
            getStateForPairOrConnectResponse(syncEvent, syncEvent.getLocalReplica.getIssueKey)
          } else {
            Future.successful(EventStatus.UPDATE_TWINTRACE, None)
          }
      }

  private def getStateForPairOrConnectResponse(
      syncEvent: ISyncEvent,
      localIssueKey: IIssueKey
  ): Future[(EventStatus, Option[SyncRequestEventType])] =
    if (syncEvent.getRemoteReplica == null) {
      LOG.info(
        s"#transitioning event `${syncEvent.getId}` for local issue `${localIssueKey.getURN}`: no remote replica set. Assuming, that the twin trace for it is not needed"
      )
      Future.successful(EventStatus.PROCESSED, Option(SyncRequestEventType.CLEANUP))
    } else {
      Future.successful(EventStatus.ADD_LINK, None)
    }

}
