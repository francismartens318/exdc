package com.exalate.replication.services.replication.worker

import akka.actor.Actor
import com.exalate.api.domain.ErrorKeys
import com.exalate.replication.services.api.error.IErrorService
import com.exalate.replication.services.api.replication.worker.IWorkerNotificationService
import com.exalate.replication.services.replication.worker.ErrorWorkerActor.ResolveErrors
import com.exalate.replication.services.utils.LoggingUtils.tryWithLoggedBugs
import com.google.inject.Inject
import play.api.Logger

import scala.concurrent.ExecutionContext

object ErrorWorkerActor {

  object ResolveErrors

}

class ErrorWorkerActor @Inject() (workerNotificationService: IWorkerNotificationService)
    extends Actor {

  val LOG: Logger = Logger("application.services.replication.worker.ErrorWorkerActor")

  implicit private val ec: ExecutionContext = context.dispatcher

  // worker starts in waiting state
  def receive: Receive = {
    case ResolveErrors =>
      tryWithLoggedBugs {
        LOG.trace(s"ErrorWorkerActor: resolving errors")
        workerNotificationService.fireAllWorkerNotifications()
      }
    case _             =>
      tryWithLoggedBugs {
        LOG.trace("ErrorWorkerActor:waiting:_")
      }
  }

}
