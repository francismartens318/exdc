package com.exalate.replication.services.replication.request

import com.exalate.api.domain.connection.SendProtocol
import com.exalate.api.domain.request.RequestStatus
import com.exalate.api.domain.twintrace.TwinTraceStatus
import com.exalate.api.persistence.replication.request.{
  ICreateOrUpdateTwinTraceSyncRequestStateRepository,
  IRequestReplicationRepository
}
import com.exalate.api.persistence.twintrace.ITwinTraceRepository
import com.exalate.domain.replication.BasicSyncRequest
import com.exalate.error.services.api.IBugExceptionCategoryService
import com.exalate.replication.services.api.replication.worker.IWorkerNotificationService
import com.exalate.replication.services.api.transport.ITransportServiceFactory
import com.exalate.replication.services.replication.state.IState
import play.api.Logger
import cats.data.OptionT
import cats.implicits._

import javax.inject.Inject
import scala.concurrent.{ExecutionContext, Future}

class SendResponseSyncRequestState @Inject() (
    requestReplicationRepository: IRequestReplicationRepository,
    createOrUpdateTwinTraceRepository: ICreateOrUpdateTwinTraceSyncRequestStateRepository,
    twinTraceRepository: ITwinTraceRepository,
    transportServiceFactory: ITransportServiceFactory,
    workerNotificationService: IWorkerNotificationService,
    bugExceptionCategoryService: IBugExceptionCategoryService
)(implicit ec: ExecutionContext)
    extends IState[BasicSyncRequestContext] {

  val LOG = Logger("application.services.replication.request.SendResponseSyncRequestState")

  /** Performs transition of one of the states of SyncRequestStateMachine: status `SEND_RESPONSE`
    *
    * @param context
    * @return
    *   BasicSyncRequestContext
    */
  override def transition(
      context: BasicSyncRequestContext
  ): Future[Option[BasicSyncRequestContext]] = {
    val BasicSyncRequestContext(basicSyncRequest, connection) = context
    basicSyncRequest.remoteTwinTraceId match {
      case Some(remoteTwinTraceId) =>
        val remoteNodeInfo = connection.getRemoteInstance.getNodeInfo
        val sendProtocol = connection.getSendProtocol
        val nextStatus =
          if (
            remoteNodeInfo.isPollOnly || Option(sendProtocol).contains(SendProtocol.WAIT_FOR_POLL)
          ) {
            RequestStatus.WAITING_RESPONSE_RECEIVED
          } else {
            RequestStatus.RESPONSE_SENT
          }

        (for {
          transportService <- Future.fromTry(transportServiceFactory.get(connection))
          maybeTwinTraceData <- twinTraceRepository
            .getRequestTwinTraceDataByRemoteTwinTraceId(connection.getID, remoteTwinTraceId)
          requestTraces <- maybeTwinTraceData
            .traverse(twinTraceData =>
              twinTraceRepository.findTracesByTwinTrace(twinTraceData.twinId)
            )
            .map(_.getOrElse(Nil))
          _ <- transportService.sendSyncResponse(
            basicSyncRequest,
            requestTraces,
            connection,
            maybeTwinTraceData.map(_.twinId)
          )
        } yield maybeTwinTraceData).flatMap {
          case Some(twinTraceData) =>
            val twinTraceStatusOpt =
              if (twinTraceData.twinStatus == TwinTraceStatus.INITIAL)
                Some(TwinTraceStatus.SYNCHRONIZED)
              else None
            val requestFuture =
              createOrUpdateTwinTraceRepository.updateTwinTraceStatusAndRequestStatus(
                twinTraceData.twinId,
                twinTraceStatusOpt,
                basicSyncRequest.id,
                nextStatus
              )
            requestFuture.foreach { _ =>
              workerNotificationService.fireAllWorkerNotifications()
            }
            requestFuture.map(toUpdatedContext(_, context))
          case _                   =>
            requestReplicationRepository
              .updateSyncRequestStatus(basicSyncRequest.id, nextStatus)
              .map(toUpdatedContext(_, context))
        }

      case _ =>
        val errMsg =
          s"A remote twin trace ID is missed in the sync request with id=${basicSyncRequest.id} though it is expected to be present."
        val ex = bugExceptionCategoryService.generateBugException(None, Some(errMsg))
        Future.failed(ex)
    }
  }

  private def toUpdatedContext(
      updatedRequestOpt: Option[BasicSyncRequest],
      context: BasicSyncRequestContext
  ): Option[BasicSyncRequestContext] =
    updatedRequestOpt.map(r => context.copy(request = r))

}
