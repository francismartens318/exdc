package com.exalate.replication.services.replication.event

import com.exalate.api.domain.SyncRequestEventType
import com.exalate.api.domain.connection.SendProtocol
import com.exalate.api.domain.event.{EventStatus, ISyncEvent}
import com.exalate.api.domain.twintrace.TwinType
import com.exalate.api.persistence.replication.event.IEventReplicationRepository
import com.exalate.api.persistence.twintrace.ITwinTraceRepository
import com.exalate.domain.replication.BasicSyncEvent
import com.exalate.replication.services.api.license.ILicenseService
import com.exalate.replication.services.api.transport.ITransportServiceFactory
import com.exalate.replication.services.replication.state.IState
import play.api.Logger

import java.sql.Timestamp
import java.util.Date
import javax.inject.Inject
import scala.concurrent.{ExecutionContext, Future}

class SendSyncRequestEventState @Inject() (
    transportServiceFactory: ITransportServiceFactory,
    persistence: IEventReplicationRepository,
    licenseService: ILicenseService,
    twinTraceRepository: ITwinTraceRepository
)(implicit ec: ExecutionContext)
    extends IState[ISyncEvent] {

  private val LOG: Logger = Logger(
    "com.exalate.replication.services.replication.event.SendSyncRequestEventState"
  )

  /** Performs transition of one of the states of SyncEventStateMachine: status `SEND_REQUEST`
    *
    * @param event
    * @return
    *   ISyncEvent
    */
  override def transition(event: ISyncEvent): Future[Option[ISyncEvent]] =
    for {
      subscriptionValidationResult <- licenseService.validateSubscription(event)
      _ = LOG.debug(
        s"#SendSyncRequestEventState checked subscriptionValidation = $subscriptionValidationResult;"
      )
      // we don't want to update payed_date for Cleanup here, as if sync was success - payed already there. If it was first sync and failed, we don't want to count cleanup as sync
      // If node is under Freemium License we will always set the payed date unless is a clean up event
      _ <-
        if (
          event.getSyncType != SyncRequestEventType.CLEANUP && subscriptionValidationResult.hasValidSubscription
        ) {
          // If it's new pair event/request, getPayedDate is empty, we update tt payedDate to today
          twinTraceRepository
            .getTwinTraceByLocalIssueKeyFuture(
              event.getConnection,
              event.getLocalReplica.getIssueKey
            )
            .flatMap(_.map { tt =>
              if (
                tt.getPayedDate == null && (!tt.getConnection.isLocal) || (tt.getConnection.isLocal && tt.getType == TwinType.CHILD)
              ) {
                LOG.debug(
                  s"Updating twin trace payed date for tt of entity ${tt.getLocalReplica.getIssueKey.getURN}"
                )
                twinTraceRepository
                  .updateTwinTracePayedDate(tt, Option(new Timestamp(new Date().getTime)))
              } else Future.successful(null)
            }.orNull)
        } else Future.successful(null)
      transportService <- Future.fromTry(transportServiceFactory.get(event.getConnection))
      _ <- transportService.sendSyncRequest(
        event,
        subscriptionValidationResult.toSubscriptionContext
      )
      syncEvent <- persistence.updateSyncEventStatus(event, getNextEventStatus(event))
    } yield syncEvent

  private def getNextEventStatus(syncEvent: ISyncEvent): EventStatus = {
    val connection = syncEvent.getConnection
    val remoteNodeInfo = connection.getRemoteInstance.getNodeInfo
    val sendProtocol = connection.getSendProtocol
    if (remoteNodeInfo.isPollOnly || Option(sendProtocol).contains(SendProtocol.WAIT_FOR_POLL)) {
      EventStatus.WAITING_REQUEST_RECEIVED
    } else if (
      (BasicSyncEvent.isConnectEvent(syncEvent) && !Option(syncEvent.getConnectContext).forall(
        _.isTriggerUpdate
      )) || BasicSyncEvent
        .isDeleteEvent(syncEvent) || BasicSyncEvent.isUnexalateEvent(syncEvent) || noBlobsOnEvent(
        syncEvent
      ) || BasicSyncEvent.isCleanupEvent(syncEvent)
    ) {
      EventStatus.WAITING_FOR_RESPONSE
    } else {
      EventStatus.SEND_BLOBS
    }
  }

  private def noBlobsOnEvent(syncEvent: ISyncEvent) = syncEvent.getBlobMetadataList.isEmpty

}
