package com.exalate.replication.services.replication.supportzip

import javax.inject.Inject

import akka.actor.ActorRef
import com.exalate.api.domain.progresstracker.TaskType
import com.exalate.api.persistence.progresstracker.IProgressTrackerRepository
import com.exalate.replication.services.api.supportzip.ISupportZipTaskExecutor
import com.exalate.replication.services.replication.worker.SupportZipWorkerActor.GenerateSupportZip
import com.google.inject.name.Named
import scala.concurrent.ExecutionContext

import scala.concurrent.Future

class SupportZipTaskExecutor @Inject() (
    progressTrackerRepository: IProgressTrackerRepository,
    @Named("support-zip-worker-actor") supportZipWorkerActor: ActorRef
)(implicit ec: ExecutionContext)
    extends ISupportZipTaskExecutor {

  /** Executes Support Zip Generation Task
    * @return
    *   id of the task
    */
  override def executeSupportZipGenerationTask(): Future[Int] = {
    val taskIdFuture =
      progressTrackerRepository.createProgressTracker(TaskType.SUPPORT_ZIP_GENERATION)
    taskIdFuture.foreach { taskId =>
      supportZipWorkerActor ! GenerateSupportZip(taskId)
    }
    taskIdFuture
  }

}
