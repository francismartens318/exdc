package com.exalate.replication.services.replication.event

import com.exalate.api.domain.event.{EventStatus, ISyncEvent}
import com.exalate.api.persistence.replication.event.IEventReadyRepository
import com.exalate.replication.services.api.license.ILicenseService
import com.exalate.replication.services.replication.state.IState

import javax.inject.Inject
import scala.concurrent.{ExecutionContext, Future}

class ReadySyncEventState @Inject() (
    persistence: IEventReadyRepository,
    licenseService: ILicenseService
)(implicit ec: ExecutionContext)
    extends IState[ISyncEvent] {

  /** Performs transition of one of the states of SyncEventStateMachine: status `READY`
    *
    * @param event
    * @return
    *   ISyncEvent
    */
  override def transition(event: ISyncEvent): Future[Option[ISyncEvent]] =
    for {
      isPaying <- licenseService.isSyncPayed(event)
      syncEvent <- persistence.persistOnReadySyncEvent(event, EventStatus.STORE_BLOB, isPaying)
    } yield syncEvent

}
