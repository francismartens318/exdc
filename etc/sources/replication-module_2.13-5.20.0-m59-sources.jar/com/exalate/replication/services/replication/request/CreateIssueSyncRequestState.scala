package com.exalate.replication.services.replication.request

import akka.actor.ActorRef
import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.request.{ISyncRequest, RequestStatus}
import com.exalate.api.persistence.replication.request.{
  ICreateIssueSyncRequestStateRepository,
  IRequestReplicationRepository
}
import com.exalate.domain.replication.BasicSyncRequest
import com.exalate.replication.services.api.error.NotEnoughDataToCreateIssueProcessorException
import com.exalate.replication.services.api.hubobject.IReplicaHelper
import com.exalate.replication.services.api.processor.ICreateIssueProcessor
import com.exalate.replication.services.replication.state.IState
import com.exalate.replication.services.replication.worker.EventSchedulerWorkerActor
import play.api.Logger

import javax.inject.{Inject, Named}
import scala.jdk.CollectionConverters._
import scala.concurrent.{ExecutionContext, Future}

class CreateIssueSyncRequestState @Inject() (
    createIssueRequestRepository: ICreateIssueSyncRequestStateRepository,
    @Named("event-scheduler-worker-actor") eventSchedulerActor: ActorRef,
    createIssueProcessor: ICreateIssueProcessor,
    replicaHelper: IReplicaHelper,
    persistence: IRequestReplicationRepository
)(implicit ec: ExecutionContext)
    extends IState[BasicSyncRequestContext] {

  private val LOG = Logger("application.services.replication.request.CreateIssueSyncRequestState")

  /** Performs transition of one of the states of SyncRequestStateMachine: status `CREATE_ISSUE`
    *
    * @param context
    * @return
    *   BasicSyncRequestContext
    */

  override def transition(
      context: BasicSyncRequestContext
  ): Future[Option[BasicSyncRequestContext]] = {
    val BasicSyncRequestContext(basicSyncRequest, connection) = context
    persistence.getSyncRequestById(basicSyncRequest.id).flatMap {
      case Some(syncRequest) =>
        transition(syncRequest, basicSyncRequest, connection)
          .map(_.map(r => context.copy(request = r)))
      case _                 =>
        LOG.error(
          s"#transitioning request `${basicSyncRequest.id}`. Could not find a sync request by ID=${basicSyncRequest.id}. Skip processing."
        )
        Future.successful(None)
    }
  }

  private def transition(
      syncRequest: ISyncRequest,
      basicSyncRequest: BasicSyncRequest,
      connection: IConnection
  ): Future[Option[BasicSyncRequest]] = {
    val remoteReplica = syncRequest.getReplica
    val remoteIssueKey = remoteReplica.getIssueKey
    val blobMetadataSeq = syncRequest.getBlobMetadataList.asScala.toSeq
    val replica = replicaHelper.toNonPersistentReplica(remoteReplica)
    eventSchedulerActor ! EventSchedulerWorkerActor.BlockScheduling
    val result = (for {
      (issueKey, traces) <- createIssueProcessor.createIssue(
        connection,
        syncRequest,
        replica,
        blobMetadataSeq
      )
      updatedSyncRequest <- createIssueRequestRepository.createTwinTraceAndSetRequestStatus(
        basicSyncRequest,
        issueKey,
        RequestStatus.ADD_LINK,
        traces,
        connection
      )
      // Unblock scheduling
    } yield updatedSyncRequest) recoverWith {
      case _: NotEnoughDataToCreateIssueProcessorException =>
        LOG.info(
          s"Issue $remoteIssueKey was NOT paired. The create processor of relation ${connection.getName} did not create an issue."
        )
        createIssueRequestRepository.persistCreateStateIfNotEnoughData(
          basicSyncRequest,
          RequestStatus.SEND_RESPONSE
        )
    }

    result
      .foreach(_ => eventSchedulerActor ! EventSchedulerWorkerActor.ResumeScheduling)

    result.recoverWith {
      case e: Exception =>
        eventSchedulerActor ! EventSchedulerWorkerActor.ResumeScheduling
        Future.failed(e)
    }

  }

}
