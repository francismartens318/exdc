package com.exalate.replication.services.replication.worker

import akka.actor._
import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.hubobject.IHubIssueReplica
import com.exalate.api.domain.twintrace.ITwinTrace
import com.exalate.api.domain.{IIssueKey, INonPersistentConnectContext}
import com.exalate.api.persistence.twintrace.ITwinTraceRepository
import com.exalate.basic.domain.hubobject.v1.UpdateBasicHubIssue
import com.exalate.replication.services.api.replication.IEventSchedulerFromTrackerService
import com.exalate.replication.services.replication.worker.EventSchedulerWorkerActor._
import com.exalate.replication.services.utils.ActorLoggingService
import com.exalate.services.utils.FutureUtils
import com.google.inject.Inject
import org.slf4j.LoggerFactory

import scala.jdk.CollectionConverters._
import scala.collection.mutable
import scala.concurrent.ExecutionContext
import scala.util.Try

object EventSchedulerWorkerActor {

  sealed trait EventSchedulerMessage

  case class ScheduleExalateOrUpdateEvent(
      connection: IConnection,
      issueKey: IIssueKey,
      updateHubIssueOption: Option[UpdateBasicHubIssue] = None,
      issueOption: Option[IHubIssueReplica] = None
  ) extends EventSchedulerMessage

  case class ScheduleExalateEvent(
      connection: IConnection,
      issueKey: IIssueKey,
      updateHubIssueOption: Option[UpdateBasicHubIssue] = None,
      issueOption: Option[IHubIssueReplica] = None
  ) extends EventSchedulerMessage

  case class ScheduleUpdateEvent(
      connection: IConnection,
      issueKey: IIssueKey,
      basicHubIssue: Option[UpdateBasicHubIssue] = None
  ) extends EventSchedulerMessage

  case class ScheduleUpdateEventForTwinTrace(
      twinTrace: ITwinTrace,
      issueKey: IIssueKey,
      basicHubIssue: Option[UpdateBasicHubIssue] = None
  ) extends EventSchedulerMessage

  case class ScheduleUpdateEvents(
      issueKey: IIssueKey,
      basicHubIssue: Option[UpdateBasicHubIssue] = None
  ) extends EventSchedulerMessage

  case class ScheduleSyncEventNoChangeCheck(connection: IConnection, issueKey: IIssueKey)
      extends EventSchedulerMessage

  case class ScheduleConnectEvent(
      connection: IConnection,
      issueKey: IIssueKey,
      connectRemoteIssue: String,
      connectContextOpt: Option[INonPersistentConnectContext],
      issue: Option[UpdateBasicHubIssue]
  ) extends EventSchedulerMessage

  case class ScheduleUnexalateEvent(connection: IConnection, issueKey: IIssueKey)
      extends EventSchedulerMessage

  case class ScheduleCleanupEvent(connection: IConnection, issueKey: IIssueKey)
      extends EventSchedulerMessage

  case class ScheduleCleanupEventForRemoteIssue(
      connection: IConnection,
      remoteIssueUrn: String,
      entityType: String
  ) extends EventSchedulerMessage

  case class ScheduleCleanupEventForConnection(connectionId: Int, entityType: String)
      extends EventSchedulerMessage

  case class ScheduleDeleteEvent(connection: IConnection, issueKey: IIssueKey)
      extends EventSchedulerMessage

  case object BlockScheduling
  case object ResumeScheduling

  private val LOG = LoggerFactory.getLogger(classOf[EventSchedulerWorkerActor])
}

class EventSchedulerWorkerActor @Inject() (
    eventSchedulerService: IEventSchedulerFromTrackerService,
    twinTraceRepository: ITwinTraceRepository,
    actorLoggingService: ActorLoggingService
) extends Actor {
  private val queue = new mutable.Queue[EventSchedulerMessage]()

  import EventSchedulerWorkerActor._

  private def tryWithLoggedBugs[R](block: => R): Try[R] =
    actorLoggingService.tryWithLoggedBugs(block)

  implicit private val ec: ExecutionContext = context.dispatcher

  def blockSchedule: Receive = {
    case e: EventSchedulerMessage =>
      LOG.debug(s"EventSchedulerWorkerActor:blockSchedule enqueueing message $e")
      queue += e
    case ResumeScheduling         =>
      LOG.debug(
        s"EventSchedulerWorkerActor:blockSchedule becoming readyToSchedule and dequeueing messages"
      )
      context.become(readyToSchedule)
      queue.dequeueFirst { e =>
        self ! e
        true
      }
    case _                        =>

  }

  def receive: Receive = readyToSchedule

  def readyToSchedule: Receive = {
    case BlockScheduling =>
      LOG.debug(s"EventSchedulerWorkerActor:Stopping scheduling")
      context.become(blockSchedule)

    case ResumeScheduling =>

    case ScheduleExalateOrUpdateEvent(r, i, updateHubIssue, issue) =>
      try {
        context.become(blockSchedule)
        LOG.trace(s"EventSchedulerWorkerActor:Scheduling sync event for issue ${i.getURN}")
        eventSchedulerService
          .scheduleExalateOrUpdateEvent(i, r, updateHubIssue, issue)
          .onComplete(_ => resume())
      } catch {
        case e: Throwable =>
          resume()
      }

    case ScheduleExalateEvent(r, i, updateHubIssue, issue) =>
      try {
        context.become(blockSchedule)
        LOG.trace(s"EventSchedulerWorkerActor:Scheduling exalate event for issue ${i.getURN}")
        eventSchedulerService
          .scheduleExalateEvent(i, r, updateHubIssue, issue)
          .onComplete(_ => resume())
      } catch {
        case e: Throwable =>
          resume()
      }

    case ScheduleUpdateEvent(r, i, issue) =>
      try {
        context.become(blockSchedule)
        LOG.trace(s"EventSchedulerWorkerActor:Scheduling sync event for issue ${i.getURN}")
        eventSchedulerService
          .scheduleUpdateEvent(i, r, issue)
          .onComplete(_ => resume())
      } catch {
        case e: Throwable =>
          resume()
      }

    case ScheduleUpdateEventForTwinTrace(twinTrace, i, issue) =>
      try {
        context.become(blockSchedule)
        LOG.trace(
          s"EventSchedulerWorkerActor:Scheduling sync event for twin trace - issue ${i.getURN}"
        )
        eventSchedulerService
          .scheduleUpdateEventForTwinTrace(i, twinTrace, issue)
          .onComplete(_ => resume())
      } catch {
        case e: Throwable =>
          resume()
      }

    case ScheduleUpdateEvents(issueKey, issue)                                 =>
      try {
        context.become(blockSchedule)
        LOG.trace(
          s"EventSchedulerWorkerActor:Scheduling sync event for issue issueKey.getIdStr=${issueKey.getIdStr} (issueKey.getURN=${issueKey.getURN}) issueKey.getEntityType=${issueKey.getEntityType} issueKey.getFieldValues=${issueKey.getFieldValues.asScala
              .mkString(",")}"
        )
        twinTraceRepository
          .findTwinTracesByIssueId(
            issueKey.getIdStr,
            issueKey.getEntityType,
            issueKey.getFieldValues
          )
          .flatMap { twinTraces =>
            LOG.trace(
              s"EventSchedulerWorkerActor:Found twin traces(${twinTraces.size}) issueKey.getIdStr=${issueKey.getIdStr} (issueKey.getURN=${issueKey.getURN}) issueKey.getEntityType=${issueKey.getEntityType} issueKey.getFieldValues=${issueKey.getFieldValues.asScala
                  .mkString(",")}"
            )
            FutureUtils.foldLeft(twinTraces) { twinTrace =>
              LOG.trace(
                s"EventSchedulerWorkerActor:Scheduling from twin trace (id=${twinTrace.getId} remote_twin_trace_id=${twinTrace.getRemoteTwinTraceId}) issueKey.getIdStr=${issueKey.getIdStr} (issueKey.getURN=${issueKey.getURN}) issueKey.getEntityType=${issueKey.getEntityType} issueKey.getFieldValues=${issueKey.getFieldValues.asScala
                    .mkString(",")}"
              )
              eventSchedulerService.scheduleUpdateEventForTwinTrace(issueKey, twinTrace, issue)
            }
          }
          .onComplete(_ => resume())
      } catch {
        case e: Throwable =>
          resume()
      }
    case ScheduleSyncEventNoChangeCheck(r, i)                                  =>
      try {
        context.become(blockSchedule)
        LOG.trace(
          s"EventSchedulerWorkerActor:Scheduling sync event not change check for issue ${i.getURN}"
        )
        eventSchedulerService
          .scheduleSyncEventNoChangeCheck(i, r)
          .onComplete(_ => resume())
      } catch {
        case e: Throwable =>
          resume()
      }
    case ScheduleConnectEvent(r, i, connectRemoteIssue, connectContext, issue) =>
      try {
        context.become(blockSchedule)
        LOG.trace(
          s"EventSchedulerWorkerActor:Scheduling connect event between local ${i.getURN} and remote $connectRemoteIssue"
        )
        eventSchedulerService
          .scheduleConnectEvent(i, r, connectRemoteIssue, connectContext, issue)
          .onComplete(_ => resume())
      } catch {
        case e: Throwable =>
          resume()
      }
    case ScheduleUnexalateEvent(r, i)                                          =>
      try {
        context.become(blockSchedule)
        LOG.trace(s"EventSchedulerWorkerActor:Scheduling unexalate event for ${i.getURN}")
        eventSchedulerService
          .scheduleUnexalateEvent(i, r)
          .onComplete(_ => resume())
      } catch {
        case e: Throwable =>
          resume()
      }

    case ScheduleCleanupEvent(c, i) =>
      try {
        context.become(blockSchedule)
        LOG.trace(s"EventSchedulerWorkerActor:Scheduling cleanup event for ${i.getURN}")
        eventSchedulerService
          .scheduleCleanupEvent(i, c)
          .onComplete(_ => resume())
      } catch {
        case e: Throwable =>
          resume()
      }

    case ScheduleCleanupEventForRemoteIssue(c, i, et) =>
      try {
        context.become(blockSchedule)
        LOG.trace(s"EventSchedulerWorkerActor:Scheduling clean up event for remote issue for $i")
        eventSchedulerService
          .scheduleCleanupEventForRemoteIssue(i, c, et)
          .onComplete(_ => resume())
      } catch {
        case e: Throwable =>
          resume()
      }

    case ScheduleCleanupEventForConnection(connectionId, et) =>
      try {
        context.become(blockSchedule)
        LOG.trace(s"EventSchedulerWorkerActor:Scheduling clean up event for connection $connectionId")
        eventSchedulerService
          .scheduleCleanupEventForConnection(connectionId, et)
          .onComplete(_ => resume())
      } catch {
        case e: Throwable =>
          resume()
      }

    case ScheduleDeleteEvent(r, i) =>
      try {
        context.become(blockSchedule)
        LOG.trace(s"EventSchedulerWorkerActor:Scheduling delete event for ${i.getURN}")
        eventSchedulerService
          .scheduleDeleteEvent(i, r)
          .onComplete(_ => resume())
      } catch {
        case e: Throwable =>
          resume()
      }

    case _ =>
      tryWithLoggedBugs {
        LOG.trace("EventSchedulerWorkerActor:waiting:_")
      }
  }

  private def resume(): Unit =
    self ! ResumeScheduling

}
