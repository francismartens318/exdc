package com.exalate.replication.services.replication.metric

import java.util.UUID

import com.exalate.api.ILoggingService
import com.exalate.api.exception.bug.BugException
import com.exalate.api.persistence.metrics.IMetricsRepository
import com.exalate.domain.metrics.{MetricEvents, MetricsValue}
import com.exalate.replication.services.api.replication.metric.IMetricService
import com.exalate.services.utils.FutureUtils
import com.google.inject.Inject

import scala.concurrent.{ExecutionContext, Future}
import scala.util.{Failure, Success, Try}

class MetricService @Inject() (metricPersis: IMetricsRepository, loggingService: ILoggingService)(
    implicit ec: ExecutionContext
) extends IMetricService {

  override def addEvent(metricsValues: Seq[MetricsValue]): Future[Option[String]] = {
    loggingService.info(s"Adding ${metricsValues.size} metric event/s")
    val uuid = UUID.randomUUID().toString
    val metricsKey = metricsValues.map { metricsValue =>
      validateMetricEvent(metricsValue.eventName) match {
        case Success(_)            =>
          loggingService.debug(s"Metric `${metricsValue.eventName}` is valid. Going to save to DB")
          val newMetricsValue = if (metricsValue.eventKey.isEmpty) {
            metricsValue.copy(eventKey = Some(uuid))
          } else {
            metricsValue
          }
          metricPersis.save(newMetricsValue)
          Future.successful(newMetricsValue.eventKey.get)
        case Failure(e: Exception) =>
          loggingService.debug(e.getMessage)
          Future.failed(e)
      }
    }
    FutureUtils.foldLeft(metricsKey)(m => m).map(_.headOption)

  }

  /** Check whether event name from front end exists in the list of events
    * @param event
    * @return
    */
  private def validateMetricEvent(event: String): Try[None.type] =
    if (MetricEvents.withNameOpt(event).isDefined) {
      Success(None)
    } else {
      Failure(new BugException(s"Metric event `$event` is not valid "))
    }

}
