package com.exalate.replication.services.replication.worker.syncstatus

import akka.actor.{Actor, Props, Terminated}
import akka.routing.{ActorRefRoutee, RoundRobinRoutingLogic, Router}
import com.exalate.api.domain.IIssueKey
import com.exalate.replication.services.api.config.ISyncStatusService
import com.exalate.replication.services.replication.worker.syncstatus.SyncStatusActor.Messages.SyncStatusMessage
import com.google.inject.Inject

class SyncStatusMasterActor @Inject() (syncStatusService: ISyncStatusService) extends Actor {

  var issueIdToKey: Map[Long, IIssueKey] = Map.empty

  var router = {
    val routees = Vector.fill(4) {
      val props = SyncStatusActor.props(syncStatusService)
      val r = context.actorOf(props)
      context.watch(r)
      ActorRefRoutee(r)
    }
    Router(RoundRobinRoutingLogic(), routees)
  }

  def receive = {
    case w: SyncStatusMessage =>
      router.route(w, sender())
    case Terminated(a)        =>
      router = router.removeRoutee(a)
      val r = context.actorOf(Props[SyncStatusActor])
      context.watch(r)
      router = router.addRoutee(r)
  }

}

object SyncStatusMasterActor {
  val name = "sync-status-core-actor"
}
