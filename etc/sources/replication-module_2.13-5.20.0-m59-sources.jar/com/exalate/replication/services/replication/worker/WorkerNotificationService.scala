package com.exalate.replication.services.replication.worker

import akka.actor.{ActorRef, ActorSystem}
import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.{ErrorActType, IIssueKey, INonPersistentConnectContext}
import com.exalate.domain.transport.message.ExalateMessage
import com.exalate.generic.services.FullAuditInfo
import com.exalate.replication.services.api.replication.worker.IWorkerNotificationService
import com.exalate.replication.services.message.worker.MessageBatcherActor.ProcessMessages
import com.exalate.replication.services.message.worker.MessageServiceActor.Send
import com.exalate.replication.services.replication.worker.messages.{
  EventWorkerMessages,
  RequestWorkerMessages
}
import com.google.inject.Inject
import com.google.inject.name.Named

import scala.concurrent.ExecutionContext
import scala.concurrent.duration._

class WorkerNotificationService @Inject() (
    actorSystem: ActorSystem,
    @Named("event-worker-actor") eventWorkerActor: ActorRef,
    @Named("request-worker-actor") requestWorkerActor: ActorRef
)(implicit ec: ExecutionContext)
    extends IWorkerNotificationService {

  override def sendProcessWebhookQueue(fullAudit: FullAuditInfo): Unit =
    eventWorkerActor ! EventWorkerMessages.ProcessWebhookQueue(fullAudit)

  override def sendPartialAuditLogRemoved(): Unit =
    eventWorkerActor ! EventWorkerMessages.ProcessAuditlogRemoved

  def sendProcessEventsNotification(): Unit =
    eventWorkerActor ! EventWorkerMessages.ProcessEvents

  def sendProcessEventsNotification(timeInSeconds: Int): Unit =
    actorSystem.scheduler.scheduleOnce(
      timeInSeconds.seconds,
      eventWorkerActor,
      EventWorkerMessages.ProcessEvents
    )

  override def sendProcessBlobEventsNotification(): Unit =
    eventWorkerActor ! EventWorkerMessages.ProcessEvents

  override def sendProcessBlobEventsNotification(timeInSeconds: Int): Unit =
    actorSystem.scheduler.scheduleOnce(
      timeInSeconds.seconds,
      eventWorkerActor,
      EventWorkerMessages.ProcessEvents
    )

  override def sendProcessRequestsNotification(): Unit =
    requestWorkerActor ! RequestWorkerMessages.ProcessRequests

  override def sendProcessRequestsNotification(timeInSeconds: Int): Unit =
    actorSystem.scheduler.scheduleOnce(
      timeInSeconds.seconds,
      requestWorkerActor,
      RequestWorkerMessages.ProcessRequests
    )

  override def sendProcessBlobRequestsNotification(): Unit =
    requestWorkerActor ! RequestWorkerMessages.ProcessRequests

  override def sendProcessBlobRequestsNotification(timeInSeconds: Int): Unit =
    actorSystem.scheduler.scheduleOnce(
      timeInSeconds.seconds,
      requestWorkerActor,
      RequestWorkerMessages.ProcessRequests
    )

  override def fireAllWorkerNotifications(): Unit = {
    sendProcessBlobEventsNotification()
    sendProcessEventsNotification()
    sendProcessBlobRequestsNotification()
    sendProcessRequestsNotification()
  }

  override def fireRescheduleEvent(
      issueKey: IIssueKey,
      actType: ErrorActType,
      relation: IConnection,
      connectRemoteIssueUrn: String,
      connectContext: INonPersistentConnectContext
  ): Unit = ???

  override def fireTriggerExalateEvent(issueKey: IIssueKey): Unit = ???

  override def fireConnectionInitiatedEvent(connectionCreated: ConnectionInitiated): Unit =
    actorSystem.actorSelection("/user/*") ! connectionCreated

  override def fireConnectionAcceptedEvent(connectionAccepted: ConnectionAccepted): Unit =
    actorSystem.actorSelection("/user/*") ! connectionAccepted

  override def fireConnectionUpdatedEvent(connectionUpdated: ConnectionUpdated): Unit =
    actorSystem.actorSelection("/user/*") ! connectionUpdated

  override def fireStartMessageBatching(): Unit =
    actorSystem.actorSelection(s"/user/*") ! ProcessMessages

  override def fireSendMessage(m: ExalateMessage): Unit =
    actorSystem.actorSelection(s"/user/*") ! Send(m)

}
