package com.exalate.replication.services.replication.in

import com.exalate.api.domain._
import com.exalate.api.domain.connection.{IConnection, ReceiveProtocol}
import com.exalate.api.domain.license.ISubscriptionContext
import com.exalate.api.domain.request.{ISyncRequest, RequestStatus}
import com.exalate.api.domain.twintrace.{INonPersistentTrace, ITwinTrace}
import com.exalate.api.exception.bug.PersistenceBugException
import com.exalate.api.persistence.replication.request.IRequestReplicationRepository
import com.exalate.api.persistence.twintrace.ITwinTraceRepository
import com.exalate.replication.services.api.replication.in.IRequestSchedulerService
import play.api.Logger

import javax.inject.Inject
import scala.concurrent.{ExecutionContext, Future}

class RequestSchedulerService @Inject() (
    twinTraceRepository: ITwinTraceRepository,
    requestReplicationRepository: IRequestReplicationRepository
)(implicit ec: ExecutionContext)
    extends IRequestSchedulerService {

  private val LOG = Logger("application.services.replication.request.RequestSchedulerService")

  override def scheduleSyncRequest(
      connection: IConnection,
      nonPersistentRemoteReplica: INonPersistentReplica,
      syncedTo: Option[IIssueKey],
      blobMetadataList: Seq[INonPersistentBlobMetadata],
      remoteTraces: Seq[INonPersistentTrace],
      syncEventId: Int,
      syncEventNumber: Long,
      connectIssueUrnOpt: Option[String],
      unexalateRemoteIssueUrn: Option[String],
      connectContext: Option[INonPersistentConnectContext],
      deletedRemoteIssueUrnOpt: Option[String],
      twinTraceId: Option[Int],
      isPayed: Boolean,
      subscriptionContext: ISubscriptionContext,
      syncType: String
  ): Future[Option[ISyncRequest]] =
    requestReplicationRepository
      .getSyncRequestByRemoteEventId(connection, syncEventId)
      .flatMap {
        case None                      =>
          val twinTraceFuture: Future[Option[ITwinTrace]] =
            if (twinTraceId.isDefined)
              twinTraceRepository.getTwinTraceByRemoteTwinTraceId(connection, twinTraceId.get)
            else
              twinTraceRepository.getTwinTraceByRemoteIssueKeyFuture(
                connection,
                nonPersistentRemoteReplica.getIssueKey
              )

          twinTraceFuture
            .flatMap {
              case Some(twinTrace)
                  if twinTrace.getLastProcessedRemoteEventNumber >= syncEventNumber =>
                LOG.debug(
                  s"sync request for remote sync event id $syncEventId won't be scheduled as the sync  event number ($syncEventNumber) is less than the twin trace last processed remote event number(${twinTrace.getLastProcessedRemoteEventNumber})"
                )
                Future.successful(None)
              case _ =>
                scheduleSyncRequestInt(
                  connection,
                  nonPersistentRemoteReplica,
                  syncedTo,
                  blobMetadataList,
                  remoteTraces,
                  syncEventId,
                  syncEventNumber,
                  connectIssueUrnOpt,
                  unexalateRemoteIssueUrn,
                  connectContext,
                  deletedRemoteIssueUrnOpt,
                  twinTraceId,
                  isPayed,
                  subscriptionContext,
                  syncType
                )
            }
        case Some(existingSyncRequest) =>
          LOG.info(
            s"RequestScheduler already found the SyncRequest '${existingSyncRequest.getId}' by remote event id '$syncEventId' for connection '${connection.getName}' "
          )
          Future.successful(None)
      }
      .recover {
        case e: PersistenceBugException =>
          LOG.error(
            "There was an error while attempting to perform a persistence operation during the scheduling of sync events",
            e
          )
          None
      }

  private def scheduleSyncRequestInt(
      connection: IConnection,
      nonPersistentRemoteReplica: INonPersistentReplica,
      syncedTo: Option[IIssueKey],
      blobMetadataList: Seq[INonPersistentBlobMetadata],
      remoteTraces: Seq[INonPersistentTrace],
      syncEventId: Int,
      syncEventNumber: Long,
      connectIssueUrnOpt: Option[String],
      unexalateRemoteIssueUrn: Option[String],
      connectContext: Option[INonPersistentConnectContext],
      deletedRemoteIssueUrnOpt: Option[String],
      twinTraceId: Option[Int],
      isPayed: Boolean,
      subscriptionContext: ISubscriptionContext,
      syncType: String
  ): Future[Option[ISyncRequest]] = {
    LOG.info(
      s"Creating a sync request and context for remote event id $syncEventId and connection '${connection.getName}'"
    )
    val receiveProtocol = connection.getReceiveProtocol
    val status =
      if (Option(receiveProtocol).contains(ReceiveProtocol.POLL))
        RequestStatus.NOTIFY_REQUEST_RECEIVED
      else
        getNextSyncRequestStatusIfWeAreNotPrivate(
          blobMetadataList,
          deletedRemoteIssueUrnOpt,
          syncType,
          connectContext
        )

    requestReplicationRepository.createSyncRequestAndContext(
      status,
      syncEventId,
      syncEventNumber,
      connection,
      nonPersistentRemoteReplica,
      syncedTo,
      connectIssueUrnOpt,
      unexalateRemoteIssueUrn,
      connectContext,
      deletedRemoteIssueUrnOpt,
      blobMetadataList,
      remoteTraces,
      twinTraceId,
      isPayed,
      subscriptionContext.isRemoteWithNodeSubscription,
      subscriptionContext.isRemoteWithExalateSubscription,
      syncType
    )
  }

  private def getNextSyncRequestStatusIfWeAreNotPrivate(
      blobMetadataList: Seq[INonPersistentBlobMetadata],
      deletedRemoteIssueUrnOpt: Option[String],
      syncType: String,
      connectContext: Option[INonPersistentConnectContext]
  ): RequestStatus =
    if (
      blobMetadataList.isEmpty || isRemoteIssueDeletedRequest(
        deletedRemoteIssueUrnOpt
      ) || (syncType == SyncRequestEventType.CONNECT
        .name() && !connectContext.forall(_.isTriggerUpdate))
    ) {
      RequestStatus.READY
    } else {
      RequestStatus.RECEIVING_BLOBS
    }

  private def isRemoteIssueDeletedRequest(deletedRemoteIssueUrn: Option[String]): Boolean =
    deletedRemoteIssueUrn.exists(_ != "")

}
