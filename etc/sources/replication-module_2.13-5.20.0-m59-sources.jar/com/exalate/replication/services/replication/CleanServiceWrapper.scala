package com.exalate.replication.services.replication

import com.exalate.replication.services.api.replication.{ICleanServiceWrapper, ICleanUpService}
import com.google.inject.Inject

import scala.concurrent.Future

class CleanServiceWrapper @Inject() (cleanUpService: ICleanUpService) extends ICleanServiceWrapper {

  override def deleteRelatedBlobs(paths: Seq[String]): Future[None.type] =
    cleanUpService.deleteRelatedBlobs(paths)

}
