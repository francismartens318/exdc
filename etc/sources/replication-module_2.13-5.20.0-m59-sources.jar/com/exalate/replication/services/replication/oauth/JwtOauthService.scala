package com.exalate.replication.services.replication.oauth

import com.exalate.api.domain.oauth.IOAuthData
import com.exalate.api.persistence.oauth.IOAuthClientRepository
import com.exalate.domain.exception.issuetracker.{
  BadRequestTrackerRestException,
  ForbiddenTrackerRestException
}
import com.exalate.domain.oauth.OAuthClient
import com.exalate.domain.values.connection.ConnectionValue
import com.exalate.error.services.BugExceptionCategoryService
import com.exalate.replication.services.api.replication.oauth.IJwtOauthService
import com.exalate.replication.services.transport.value.ExaCompFormatters._
import com.google.inject.Inject
import pdi.jwt._
import pdi.jwt.algorithms.JwtHmacAlgorithm
import play.api.libs.json.{JsValue, Json}
import play.api.{Configuration, Logger}

import java.time.Clock
import java.util.UUID
import scala.collection.immutable.Seq
import scala.concurrent.{ExecutionContext, Future}
import scala.util.Try

/** The class which is in charge of jwt processing. Mainly used in OAuth flow. This class has
  * methods for the following jwt handling:
  *   1. decode provided jwt and returns instance uid obtained from the jwt {@link
  *      decodeAccessTokenAndReturnInstanceUid()} 2. validating jwt. In case it is not valid returns
  *      `Failure` {@link validateToken} 3. forms STATE jwt token based on the input params {@link
  *      generateState(clientId, redirectUri, exaUserId, stateUuid, clientSecret, instanceUid,
  *      connectionJsValue, scope)} 4. generates Authorization jwt Code based on the input params
  *      {@link generateAuthorizationCode(clientId, redirectUri, authServerExaUserId, authCodeUuid,
  *      instanceUid, scope)} 5. generates Access TOKEN for oauth flow {@link
  *      generateToken(instanceUid, clientExaUserId, serverExaUserId, secret, scope, expiresIn,
  *      localUrl, clientId)} 6. generates Client Jwt {@link generateClientJwt(clientId,
  *      clientSecret, redirectUri)} 7. handles validation of the above mentioned JWT tokens,
  *      namely: {@link validateStateJwt} , {@link validateClientJwt} 8. decodes jwt and extract
  *      needed info, namely * `Client Id` {@link getClientIdFromToken} * `Redirect Uri` {@link
  *      getRedirectUriFromToken} * `AuthServer Uri` {@link getAuthServerUriFromToken} * `User Id`
  *      {@link getUserIdFromToken} * `Connection Value` {@link getConnectionValueFromToken} *
  *      `Scope` {@link getScopeFromToken} * `Auth Server ExaUser Id` {@link
  *      getAuthServerExaUserIdFromToken}
  */
class JwtOauthService @Inject() (
    configuration: Configuration,
    oauthClientRepository: IOAuthClientRepository,
    bugExceptionCategoryService: BugExceptionCategoryService,
    implicit val executionContext: ExecutionContext
) extends IJwtOauthService {

  val LOG: Logger = Logger("replication.services.replication.oauth.JwtService")

  implicit val clock: Clock = Clock.systemUTC()
  private val SECRET_KEY = "play.http.secret.key"
  private lazy val internalSecretKey = configuration.get[String](SECRET_KEY)
  private val JwtAlgorithm_HS256: JwtAlgorithm.HS256.type = JwtAlgorithm.HS256

  private val DEFAULT_JWT_OPTIONS_FOR_VALIDATION: JwtOptions =
    JwtOptions(signature = true, expiration = false, notBefore = false, leeway = 0)

  val TOKEN_EXPIRES_IN = 600 // seconds

  override def decodeAccessTokenAndReturnInstanceUid(accessToken: String): Option[String] =
    JwtJson
      .decode(accessToken, JwtOptions.apply(signature = false, expiration = false, notBefore = false))
      .toOption
      .flatMap(_.issuer)

  override def validateToken(token: String, oauthData: IOAuthData): Try[Unit] =
    Try(JwtJson.validate(token, oauthData.getSecret, Seq(JwtAlgorithm_HS256)))

  override def generateState(
      clientId: String,
      redirectUri: String,
      exaUserId: String,
      stateUuid: UUID,
      instanceUid: String,
      connectionJsValue: JsValue,
      scope: String
  ): String = {
    val claim = JwtClaim()
      .by(instanceUid)
      .issuedNow
      .expiresIn(TOKEN_EXPIRES_IN)
      .withId(stateUuid.toString)
      .about(exaUserId)
      .+("scp", scope)
      .+("clt", clientId)
      .+("rur", redirectUri)
      .+("con", connectionJsValue.toString())

    val algo = JwtAlgorithm_HS256
    JwtJson.encode(claim, internalSecretKey, algo)
  }

  override def generateState(
      clientId: String,
      redirectUri: String,
      clientSecret: String,
      instanceUid: String,
      exalateUrl: String
  ): String = {
    val claim = JwtClaim()
      .by(instanceUid)
      .issuedNow
      .expiresIn(TOKEN_EXPIRES_IN)
      .withId(UUID.randomUUID().toString)
      .+("clt", clientId)
      .+("rur", redirectUri)
      .+("eur", exalateUrl)

    val algo = JwtAlgorithm_HS256
    JwtJson.encode(claim, clientSecret, algo)
  }

  /** client_id – The client ID (or other client identifier) that requested this code redirect_uri –
    * The redirect URL that was used. This needs to be stored since the access token request must
    * contain the same redirect URL for verification when issuing the access token. User info – Some
    * way to identify the user that this authorization code is for, such as a user ID. Expiration
    * Date – The code needs to include an expiration date so that it only lasts a short time. Unique
    * ID – The code needs its own unique ID of some sort in order to be able to check if the code
    * has been used before. A database ID or a random string is sufficient.
    */
  override def generateAuthorizationCode(
      clientId: String,
      redirectUri: String,
      authServerExaUserId: String,
      authCodeUuid: UUID,
      instanceUid: String,
      scope: String
  ): String = {
    val claim = JwtClaim()
      .by(instanceUid)
      .issuedNow
      .expiresIn(60 * 10)
      .withId(authCodeUuid.toString)
      .about(authServerExaUserId)
      .+("clt", clientId)
      .+("rur", redirectUri)
      .+("scp", scope)

    val algo = JwtAlgorithm_HS256
    JwtJson.encode(claim, internalSecretKey, algo)
  }

  override def generateToken(
      instanceUid: String,
      clientExaUserId: String,
      serverExaUserId: String,
      secret: String,
      scope: String,
      expiresIn: Long,
      localUrl: String,
      clientId: String
  ): String = {

    val claim = JwtClaim()
      .about(clientExaUserId)
      .by(instanceUid)
      .issuedNow
      .expiresIn(expiresIn)
      .+("serverExaUserId", serverExaUserId)
      .+("scp", scope)
      .+("url", localUrl)
      .+("clt", clientId)

    val algo = JwtAlgorithm_HS256
    val jwt = JwtJson.encode(claim, secret, algo)

    jwt
  }

  def generateClientJwt(clientId: String, clientSecret: String, redirectUri: String): String = {
    val claim = JwtClaim().issuedNow
      .expiresIn(TOKEN_EXPIRES_IN)
      .+("clt", clientId)
      .+("rur", redirectUri)

    val algo = JwtAlgorithm_HS256
    val jwt = JwtJson.encode(claim, clientSecret, algo)

    jwt
  }

  /** Validates state jwt using hmac algorithm and secret key from OAuth client
    * @param stateJwtStr
    * @param isLocal
    * @return
    *   Future.successful(None) if state is valid, else Future.failed(Exception)
    */
  override def validateStateJwt(
      stateJwtStr: String,
      isLocal: Boolean,
      withSignature: Boolean = false
  ): Future[None.type] = {

    val unvalidatedJwt: Future[(JwtHeader, JwtClaim, String)] = Future.fromTry {
      val unvalidatedJwtTry = JwtJson.decodeAll(
        stateJwtStr,
        internalSecretKey,
        Seq(JwtAlgorithm_HS256),
        JwtOptions(signature = withSignature, expiration = false, notBefore = false, leeway = 0)
      )
      LOG.info(
        s"#StateTokenOrJcloudJwtAction #getStateTokenOptFuture $stateJwtStr was decoded into: $unvalidatedJwtTry"
      )
      unvalidatedJwtTry
    }
    unvalidatedJwt
      .flatMap {
        case (h, c, _) =>
          val jsValue = Json.parse(c.toJson)
          val clientIdStrOpt = (jsValue \ "clt").asOpt[String]
          val redirectUriStrOpt = (jsValue \ "rur").asOpt[String]
          LOG.info(
            s"#StateTokenOrJcloudJwtAction #getStateTokenOptFuture $stateJwtStr was decoded into: `${jsValue
                .toString()}` clientId=$clientIdStrOpt redirectUriStrOpt=$redirectUriStrOpt"
          )
          (clientIdStrOpt, redirectUriStrOpt) match {
            case (Some(clientId), Some(redirectUriStr)) =>
              oauthClientRepository
                .findFirst(clientId, redirectUriStr, isLocal = true)
                .flatMap {
                  case None    =>
                    LOG.info(
                      s"#StateTokenOrJcloudJwtAction #getStateTokenOptFuture did not find the local client given clientId=$clientId and redirectUriStr=`$redirectUriStr`. skipped all the fun"
                    )
                    Future.failed(
                      bugExceptionCategoryService
                        .generateInvalidStateJwtMissingClient(stateJwtStr, clientId, isLocal)
                    )
                  case Some(_) =>
                    LOG.info(
                      s"#StateTokenOrJcloudJwtAction #getStateTokenOptFuture found the local client given clientId=$clientId and redirectUriStr=`$redirectUriStr!`. skipped all the fun"
                    )
                    h.algorithm match {
                      case Some(hmac: JwtHmacAlgorithm) =>
                        Future
                          .fromTry(
                            JwtJson.decodeAll(
                              stateJwtStr,
                              internalSecretKey,
                              JwtAlgorithm.allHmac(),
                              DEFAULT_JWT_OPTIONS_FOR_VALIDATION
                            )
                          )
                          .map(_ => None)
                          .recoverWith {
                            case e: Exception =>
                              Future.failed(
                                bugExceptionCategoryService
                                  .generateInvalidJwtException(stateJwtStr, hmac.toString, e)
                              )
                          }
                      case Some(alg)                    =>
                        Future.failed(
                          bugExceptionCategoryService
                            .generateUnsupportedAlgorithmException(stateJwtStr, alg.toString)
                        )
                      case None                         =>
                        Future
                          .fromTry(
                            JwtJson.decodeAll(
                              stateJwtStr,
                              internalSecretKey,
                              Seq(JwtAlgorithm.HS256),
                              DEFAULT_JWT_OPTIONS_FOR_VALIDATION
                            )
                          )
                          .map(_ => None)
                          .recoverWith {
                            case e: Exception =>
                              Future.failed(
                                bugExceptionCategoryService.generateInvalidJwtException(
                                  stateJwtStr,
                                  JwtAlgorithm.HS256.toString,
                                  e
                                )
                              )
                          }
                    }
                }
            case (_, _)                                 =>
              Future.failed(
                bugExceptionCategoryService.generateMissingJwtClaimsException(stateJwtStr)
              )
          }
      }
  }

  override def validateClientJwt(
      clientJwtOpt: Option[String],
      isLocal: Boolean = false
  ): Future[OAuthClient] =
    clientJwtOpt match {
      case Some(clientJwt) =>
        LOG.trace(s"Validating client jwt $clientJwt")
        JwtJson.decodeJson(clientJwt, JwtOptions(signature = false)).toOption.map { json =>
          val clientId = (json \ "clt").as[String]
          val redirectUri = (json \ "rur").as[String]
          (clientJwt, clientId, redirectUri)
        } match {
          case Some((jwt, clientId, redirectUri)) =>
            oauthClientRepository.findFirst(clientId, redirectUri, isLocal).flatMap {
              case Some(oAuthClient) =>
                Future
                  .fromTry(
                    Try(JwtJson.validate(jwt, oAuthClient.clientSecret, Seq(JwtAlgorithm_HS256)))
                  )
                  .map(_ => oAuthClient)
              case None              =>
                val exception = new ForbiddenTrackerRestException(
                  s"Error while validating client jwt for client $clientId and redirect Uri $redirectUri"
                )
                Future.failed(exception)
            }
          case None                               =>
            val exception = new ForbiddenTrackerRestException(s"Error while decoding state jwt")
            Future.failed(exception)
        }
      case _               =>
        LOG.error("Missing client jwt from request query strings")
        Future.failed(
          new BadRequestTrackerRestException("Missing client jwt from request query strings")
        )
    }

  override def getClientIdFromToken(token: String): Option[String] =
    decodeTokenAndGetClaim(token, "clt")

  override def getRedirectUriFromToken(token: String): Option[String] =
    decodeTokenAndGetClaim(token, "rur")

  override def getAuthServerUriFromToken(token: String): Option[String] =
    decodeTokenAndGetClaim(token, "url")

  override def getUserIdFromToken(token: String): Option[String] =
    decodeTokenAndGetClaim(token, "sub")

  override def getExalateUrlFromToken(token: String): Option[String] =
    decodeTokenAndGetClaim(token, "eur")

  override def getConnectionValueFromToken(
      token: String,
      withSignature: Boolean = false
  ): Option[ConnectionValue] = {
    val connectionStrOpt = decodeTokenAndGetClaim(token, "con", withSignature)
    connectionStrOpt.flatMap(connectionStr =>
      Try(Json.parse(connectionStr).validate[ConnectionValue].get).toOption
    )
  }

  override def getScopeFromToken(token: String): Option[String] =
    decode(token)
      .flatMap(codeClaims =>
        Try(Json.parse(codeClaims.content))
          .flatMap(value => Try((value \ "scp").as[String]))
      )
      .toOption

  override def getAuthServerExaUserIdFromToken(token: String): Option[String] =
    decode(token).toOption.flatMap(codeClaims => codeClaims.subject)

  private def decode(token: String): Try[JwtClaim] =
    JwtJson.decode(token, JwtOptions(signature = false, expiration = false, notBefore = false))

  private def decodeTokenAndGetClaim(token: String, claim: String, withSignature: Boolean = false) =
    JwtJson
      .decodeJson(
        token,
        internalSecretKey,
        Seq(JwtAlgorithm_HS256),
        JwtOptions(signature = withSignature, expiration = false, notBefore = false)
      )
      .toOption match {
      case Some(json) =>
        Some((json \ claim).as[String])
      case _          =>
        LOG.error("Error while decoding state JWT")
        None
    }

}
