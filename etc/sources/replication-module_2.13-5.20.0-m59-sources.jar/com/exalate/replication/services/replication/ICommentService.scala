package com.exalate.replication.services.replication

import com.exalate.api.domain.IIssueKey
import com.exalate.api.domain.hubobject.IHubIssueReplica
import com.exalate.api.domain.request.ISyncRequest
import com.exalate.api.domain.twintrace.INonPersistentTrace
import com.exalate.domain.issuetracker.IEntityUpdateContext
import com.google.inject.ImplementedBy

import scala.concurrent.Future
import scala.util.Try

@ImplementedBy(classOf[CommentService])
trait ICommentService {

  /** Applies comments to issue
    * @param syncRequest
    * @param issueKey
    * @param newHubIssue
    * @param traces
    * @return
    *   seq of current traces and new comments traces
    */
  def applyComments(
      syncRequest: ISyncRequest,
      issueKey: IIssueKey,
      newHubIssue: IHubIssueReplica,
      traces: Seq[INonPersistentTrace]
  ): Future[Seq[INonPersistentTrace]]

  /** Process comments (process new comments, changed comments and removed comments) and concatenate
    * new comments traces to the current seq of traces
    * @param context
    *   holds sync Request, issue key, enitity/issue, seq of traces, connection, remote twin trace
    *   id
    * @tparam C
    * @return
    *   seq of current traces and new comments traces
    */
  def applyComments[C <: IEntityUpdateContext](context: C): Future[Seq[INonPersistentTrace]]
}
