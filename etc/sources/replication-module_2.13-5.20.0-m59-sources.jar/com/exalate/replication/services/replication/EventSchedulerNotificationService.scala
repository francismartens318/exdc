package com.exalate.replication.services.replication

import akka.actor.ActorRef
import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.hubobject.IHubIssueReplica
import com.exalate.api.domain.twintrace.ITwinTrace
import com.exalate.api.domain.{IIssueKey, INonPersistentConnectContext}
import com.exalate.basic.domain.hubobject.v1.UpdateBasicHubIssue
import com.exalate.replication.services.api.replication.IEventSchedulerNotificationService
import com.exalate.replication.services.replication.worker.EventSchedulerWorkerActor
import com.google.inject.Inject
import com.google.inject.name.Named

class EventSchedulerNotificationService @Inject() (
    @Named("event-scheduler-worker-actor") eventSchedulerActor: ActorRef
) extends IEventSchedulerNotificationService {

  override def scheduleExalateEvent(
      connection: IConnection,
      issueKey: IIssueKey,
      updateHubIssueOption: Option[UpdateBasicHubIssue],
      issueOption: Option[IHubIssueReplica]
  ): Unit =
    eventSchedulerActor ! EventSchedulerWorkerActor.ScheduleExalateEvent(
      connection,
      issueKey,
      updateHubIssueOption,
      issueOption
    )

  def scheduleExalateOrUpdateEvent(
      connection: IConnection,
      issueKey: IIssueKey,
      updateHubIssueOption: Option[UpdateBasicHubIssue] = None,
      issueOption: Option[IHubIssueReplica] = None
  ): Unit =
    eventSchedulerActor ! EventSchedulerWorkerActor.ScheduleExalateOrUpdateEvent(
      connection,
      issueKey,
      updateHubIssueOption,
      issueOption
    )

  def schedulePairOrSyncEvent(
      connection: IConnection,
      issueKey: IIssueKey,
      updateHubIssueOption: Option[UpdateBasicHubIssue] = None,
      issueOption: Option[IHubIssueReplica] = None
  ): Unit =
    scheduleExalateOrUpdateEvent(connection, issueKey, updateHubIssueOption, issueOption)

  def scheduleUpdateEvent(
      connection: IConnection,
      issueKey: IIssueKey,
      basicHubIssue: Option[UpdateBasicHubIssue] = None
  ): Unit =
    eventSchedulerActor ! EventSchedulerWorkerActor.ScheduleUpdateEvent(
      connection,
      issueKey,
      basicHubIssue
    )

  def scheduleUpdateEventForTwinTrace(
      twinTrace: ITwinTrace,
      issueKey: IIssueKey,
      basicHubIssue: Option[UpdateBasicHubIssue] = None
  ): Unit =
    eventSchedulerActor ! EventSchedulerWorkerActor.ScheduleUpdateEventForTwinTrace(
      twinTrace,
      issueKey,
      basicHubIssue
    )

  def scheduleConnectEvent(
      connection: IConnection,
      issueKey: IIssueKey,
      connectRemoteIssueUrn: String,
      connectContextOpt: Option[INonPersistentConnectContext],
      basicHubIssue: Option[UpdateBasicHubIssue]
  ): Unit =
    eventSchedulerActor ! EventSchedulerWorkerActor.ScheduleConnectEvent(
      connection,
      issueKey,
      connectRemoteIssueUrn,
      connectContextOpt,
      basicHubIssue
    )

  def scheduleSyncEventNoChangeCheck(connection: IConnection, issueKey: IIssueKey): Unit =
    eventSchedulerActor ! EventSchedulerWorkerActor.ScheduleSyncEventNoChangeCheck(
      connection,
      issueKey
    )

  def scheduleUnexalateEvent(connection: IConnection, issueKey: IIssueKey): Unit =
    eventSchedulerActor ! EventSchedulerWorkerActor.ScheduleUnexalateEvent(connection, issueKey)

  def scheduleCleanupEvent(connection: IConnection, issueKey: IIssueKey): Unit =
    eventSchedulerActor ! EventSchedulerWorkerActor.ScheduleCleanupEvent(connection, issueKey)

  def scheduleCleanupEventForRemoteIssue(
      connection: IConnection,
      remoteIssueUrn: String,
      entityType: String
  ): Unit =
    eventSchedulerActor ! EventSchedulerWorkerActor.ScheduleCleanupEventForRemoteIssue(
      connection,
      remoteIssueUrn,
      entityType
    )

  override def scheduleCleanupEventForConnection(connectionId: Int, entityType: String): Unit =
    eventSchedulerActor ! EventSchedulerWorkerActor.ScheduleCleanupEventForConnection(
      connectionId,
      entityType
    )

  def scheduleDeleteEvent(connection: IConnection, issueKey: IIssueKey): Unit =
    eventSchedulerActor ! EventSchedulerWorkerActor.ScheduleDeleteEvent(connection, issueKey)

  def scheduleUpdateEvents(
      issueKey: IIssueKey,
      updateIssue: Option[UpdateBasicHubIssue] = None
  ): Unit =
    eventSchedulerActor ! EventSchedulerWorkerActor.ScheduleUpdateEvents(issueKey, updateIssue)

}
