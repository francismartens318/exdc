package com.exalate.replication.services.replication.impersonation

import com.exalate.api.domain.auditlog.IAuditLog
import com.exalate.api.domain.webhook.{INonPersistentWebhookInfo, IWebhookInfo, WebhookEntityType}
import com.exalate.api.persistence.auditlog.IAuditLogRepository
import com.exalate.basic.domain.auditlog.NonPersistentAuditLog
import com.exalate.generic.services.{FullAuditInfo, PartialAuditInfo}
import com.exalate.generic.services.api.IActionComparator
import com.exalate.replication.services.api.replication.impersonation.IAuditLogService
import com.exalate.replication.services.api.replication.worker.IWorkerNotificationService
import com.exalate.services.utils.FutureUtils
import javax.inject.Inject
import play.api.Logger

import scala.concurrent.ExecutionContext
import scala.concurrent.Future

class AuditLogService @Inject() (
    auditLogRepository: IAuditLogRepository,
    workerNotificationService: IWorkerNotificationService,
    actionComparator: IActionComparator
)(implicit ec: ExecutionContext)
    extends IAuditLogService {

  val LOG = Logger("application.services.replication.impersonation.AuditLogService")

  /** Creates auditlog and saves it in DB - AuditLogTable
    * @param issueId
    * @param webhookType
    *   WORKLOG_CREATED, WORKLOG_UPDATED, COMMENT_CREATED, COMMENT_UPDATED, ISSUE_CREATED
    * @param userKey
    * @return
    *   saved IAuditLog
    */
  override def createAuditLog(issueId: Option[String], webhookType: WebhookEntityType)(
      userKey: String
  ): IAuditLog = {
    LOG.debug(
      s"Creating auditLog ${issueId.map(id => s"for issue `$id` ").getOrElse("")}for webhook `${webhookType.name()}`"
    )
    val nonPersistentAuditLog =
      new NonPersistentAuditLog(issueId.orNull, userKey, webhookType, null, null)
    FutureUtils.resultInf(auditLogRepository.save(nonPersistentAuditLog))
  }

  /** Updates audit log in db and sends ProcessWebhookQueue
    * @param auditLogOpt
    *   audit log from which information is taken to update one in DB
    * @param issueId
    * @param entityId
    * @param entityJsonStr
    */
  override def updateAuditLog(
      auditLogOpt: Option[IAuditLog],
      issueId: String,
      entityId: String,
      entityJsonStr: String
  ): Unit =
    auditLogOpt.foreach { auditLog =>
      LOG.debug("Updating auditLog for issue " + issueId)
      val updatedAuditLog = new NonPersistentAuditLog(
        issueId,
        auditLog.getUserKey,
        auditLog.getEntityType,
        entityId,
        entityJsonStr
      )
      val fullAuditLog = FullAuditInfo(
        FutureUtils.resultInf(auditLogRepository.update(auditLog.getId, updatedAuditLog))
      )
      workerNotificationService.sendProcessWebhookQueue(fullAuditLog)
    }

  /** Deletes auditlog from DB by id
    * @param auditLogId
    * @return
    */
  override def delete(auditLogId: Int): Future[None.type] = {
    val f = auditLogRepository.delete(auditLogId)
    f.foreach(_ => workerNotificationService.sendPartialAuditLogRemoved())
    f
  }

  /** Gets a seq of auditlogs from DB for provided webhook
    * @param webhookInfo
    * @return
    */
  override def getFor(
      webhookInfo: IWebhookInfo
  ): Future[(Option[FullAuditInfo], Seq[PartialAuditInfo])] =
    get(
      webhookInfo.getIssueId,
      webhookInfo.getEntityType,
      webhookInfo.getUserKey,
      webhookInfo.getEntityJson
    )
      .map {
        case (fullAudit, partialAudit) =>
          (fullAudit.find(actionComparator.isSameAction(webhookInfo)), partialAudit)
      }

  /** Gets a seq of auditlogs from DB for provided webhook
    * @param webhookInfo
    * @return
    *   A future containing option of the full audit info and all partial audit info.
    */
  override def getFor(
      webhookInfo: INonPersistentWebhookInfo
  ): Future[(Option[FullAuditInfo], Seq[PartialAuditInfo])] =
    get(
      webhookInfo.getIssueId,
      webhookInfo.getEntityType,
      webhookInfo.getUserKey,
      webhookInfo.getEntityJson
    )
      .map {
        case (fullAudit, partialAudit) =>
          (fullAudit.find(actionComparator.isSameAction(webhookInfo)), partialAudit)
      }

  private def get(
      issueId: String,
      entityType: WebhookEntityType,
      userKey: String,
      entityJsonStr: String
  ): Future[(Seq[FullAuditInfo], Seq[PartialAuditInfo])] = {
    LOG.debug(
      "Getting future of (Option[FullAuditInfo], Seq[PartialAuditInfo]) for issue with id " + issueId + " for entity type: " + entityType + " by user " + userKey
    )

    (entityType match {
      case WebhookEntityType.ISSUE_CREATED =>
        auditLogRepository.getFilteredIssueAuditLogs(entityType, userKey)
      case _ => auditLogRepository.getFilteredAuditLogs(issueId, entityType, userKey)
    })
      .map(
        _.map { auditLog =>
          (Option(auditLog.getResultEntityId), Option(auditLog.getResultEntityJson)) match {
            case (Some(_), Some(_)) =>
              // LOG.debug("Got full audit info " + auditLog.getBlobId + " by user " + auditLog.getUserKey)
              FullAuditInfo(auditLog)
            case _                  =>
              // LOG.debug("Got partial audit info " + auditLog.getBlobId + " by user " + auditLog.getUserKey)
              PartialAuditInfo(auditLog)
          }
        }
          .partition(_.isInstanceOf[FullAuditInfo])
          .asInstanceOf[(Seq[FullAuditInfo], Seq[PartialAuditInfo])]
      )
  }

  /** Deletes all PartialAuditLogs from DB
    * @return
    *   None
    */
  override def deleteAllPartialAuditLogs(): Future[None.type] =
    auditLogRepository.deleteAllPartialAuditLogs().map { res =>
      workerNotificationService.sendPartialAuditLogRemoved()
      res
    }

}
