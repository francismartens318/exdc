package com.exalate.replication.services.replication.mapping

import com.exalate.replication.services.api.replication.mapping.ITrackerMatchHelper

class DefaultTrackerMatchHelper extends ITrackerMatchHelper {
  override def applyUserMatch(currentValue: Any)(expectedValue: String): Boolean = false
}
