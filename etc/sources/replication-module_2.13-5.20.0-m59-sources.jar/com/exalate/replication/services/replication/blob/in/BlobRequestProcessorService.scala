package com.exalate.replication.services.replication.blob.in

import com.exalate.api.domain.blob.request.{BlobRequestStatus, IBlobRequest}
import com.exalate.api.domain.connection.{ConnectionStatus, InvitationStatus}
import com.exalate.api.domain.request.{ISyncRequest, RequestStatus}
import com.exalate.api.exception.CategorizedException
import com.exalate.api.persistence.replication.blob.IBlobReplicationRepository
import com.exalate.api.persistence.replication.request.IRequestReplicationRepository
import com.exalate.api.persistence.twintrace.ITwinTraceRepository
import com.exalate.domain.values.{PageRequest, PageResult}
import com.exalate.error.services.api.IBugExceptionCategoryService
import com.exalate.replication.services.api.error._
import com.exalate.replication.services.api.replication.blob.IBlobRequestProcessorService
import com.exalate.replication.services.api.replication.worker.IWorkerNotificationService
import com.exalate.replication.services.replication.blob.request.BlobRequestStateMachine
import com.google.inject.Inject
import play.api.{Configuration, Logger}
import cats.implicits.toTraverseOps
import scala.jdk.CollectionConverters._
import scala.concurrent.{Await, ExecutionContext, Future}

class BlobRequestProcessorService @Inject() (
    persistence: IRequestReplicationRepository,
    errorService: IErrorService,
    blobReplicationRepository: IBlobReplicationRepository,
    blobRequestStateMachine: BlobRequestStateMachine,
    errorHandler: IErrorHandler,
    workerNotificationService: IWorkerNotificationService,
    bugExceptionCategoryService: IBugExceptionCategoryService,
    twinTraceRepository: ITwinTraceRepository,
    configuration: Configuration
)(implicit ec: ExecutionContext)
    extends IBlobRequestProcessorService {

  private val LOG = Logger(
    "application.services.replication.blob.request.BlobRequestProcessorService"
  )

  private lazy val LIMIT =
    configuration.getOptional[Int]("exalate.replication.processing.limit").getOrElse(5)

  /** Process blob requests, it is called from RequestWorkerActor Namely, it preprocess blobs by
    * calling {@link processPages} , updates Sync Request Status in DB, sends Process Requests
    * Notification and finally deletes BlobRequests from DB
    */
  override def processBlobRequests(): Future[Unit] =
    blobReplicationRepository.findSyncRequestsIds().flatMap { syncRequestsIds =>
      LOG.trace(s"Process incoming blobs: Found ${syncRequestsIds.size} pending sync requests")
      syncRequestsIds
        .traverse { syncRequestId =>
          processPages(syncRequestId, LIMIT).flatMap {
            case (processedBlobRequests, notFinishedBlobRequests) =>
              persistence.getSyncRequestById(syncRequestId).flatMap {
                case None              =>
                  LOG.info(
                    s"Couldn't find sync request by id $syncRequestId even though it was there a short while ago. Skipping it."
                  )
                  Future.successful()
                case Some(syncRequest) =>
                  val syncRequestBlobIds = syncRequest.getBlobMetadataList.asScala
                    .map(_.getBlobId)

                  if (processedBlobRequests.map(_._2).toSet == syncRequestBlobIds.toSet) {
                    for {
                      _ <- persistence.updateSyncRequestStatus(
                        syncRequest.getId,
                        RequestStatus.READY
                      )
                      _ <- persistence.deleteBlobRequests(processedBlobRequests.map(_._1))
                      _ = workerNotificationService.sendProcessRequestsNotification()
                    } yield ()
                  } else {
                    if (notFinishedBlobRequests.nonEmpty) {
                      persistence.deleteBlobRequests(notFinishedBlobRequests)
                    }
                    Future.successful()
                  }
              }
          }
        }
        .map(_ => ())
    }

  private def processPages(syncRequestId: Int, limit: Int): Future[(Seq[(Int, String)], Seq[Int])] = {
    val getBlobRequests: PageRequest => Future[PageResult[IBlobRequest]] =
      blobReplicationRepository.getBlobRequestsForSyncRequest(syncRequestId) _

    def processPage2(
        offSet: Int,
        prevProcessedContext: Seq[(Int, String)],
        prevNotFinished: Seq[Int]
    ): Future[(Seq[(Int, String)], Seq[Int])] =
      getBlobRequests(PageRequest(Some(limit), Some(offSet)))
        .flatMap { blobRequestsPageResult =>
          val blobRequests = blobRequestsPageResult.results
          val total = blobRequestsPageResult.total
          val syncContextStr = getSyncContextMessage(blobRequests)
          LOG.debug(
            s"Process incoming blobs: Found ${blobRequests.size} blob requests for sync request $syncRequestId$syncContextStr the total is $total current offset $offSet"
          )

          blobRequests
            .traverse(processBlobRequest)
            .flatMap { blobRequests =>
              val (finishedCorrectly, notFinished) = blobRequests.flatten
                .filter(_.getStatus == BlobRequestStatus.BLOB_PROCESSED)
                .partition(_.isFinishedCorrectly)
              val newProcessedContext = finishedCorrectly
                .map(br => (br.getId, br.getBlobMetadata.getBlobId)) ++ prevProcessedContext
              val newNotFinishedBlobRequestsIds = notFinished.map(_.getId) ++ prevNotFinished
              if (offSet + limit < total) {
                processPage2(offSet + limit, newProcessedContext, newNotFinishedBlobRequestsIds)
              } else {
                Future.successful((newProcessedContext, newNotFinishedBlobRequestsIds))
              }
            }
        }
        .recoverWith {
          case e =>
            LOG.error(
              s"#processPages failed to process page ${offSet / limit} thus skipping this page",
              e
            )
            processPage2(offSet + limit, prevProcessedContext, prevNotFinished)
        }

    processPage2(0, Nil, Nil)
  }

  private def getSyncContextMessage(blobRequests: Seq[IBlobRequest]): String =
    blobRequests.headOption
      .map { br =>
        val syncRequest = br.getSyncRequest
        val relationStr = syncRequest.getConnection.getName
        val issueStr = syncRequest.getReplica.getIssueKey.getURN
        s" for remote issue `$issueStr` for connection `$relationStr`"
      }
      .getOrElse("")

  private def processBlobRequest(blobRequest: IBlobRequest): Future[Option[IBlobRequest]] = {
    val toProcess = blobRequest
    val syncRequest = blobRequest.getSyncRequest

    lazy val localIssueOptFut = twinTraceRepository.getLocalIssueKeyByRemoteTwinTraceId(
      syncRequest.getConnection,
      syncRequest.getRemoteTwinTraceId
    )

    val connection = syncRequest.getConnection
    val remoteIssueKey = syncRequest.getReplica.getIssueKey
    val remoteIssueUrn = remoteIssueKey.getURN

    def startProcessing(toProcess: Option[IBlobRequest]): Future[Option[IBlobRequest]] =
      toProcess match {
        case Some(blobRequest) =>
          canProcessingContinue(blobRequest).flatMap { canProcess =>
            if (canProcess) {
              val blobId = blobRequest.getBlobMetadata.getBlobId
              LOG.info(
                s"Processing request ${blobRequest.getId} on state ${blobRequest.getStatus} " +
                  s"for remote event `${syncRequest.getRemoteSyncEventId}` number `${syncRequest.getRemoteSyncEventNumber}` for blob `$blobId` remote issue urn `$remoteIssueUrn` using connection `${connection.getName}`"
              )
              blobRequestStateMachine
                .getState(blobRequest)
                .transition(blobRequest)
                .flatMap(blobRequest =>
                  errorService.deleteTransportErrorsForSyncRequest(syncRequest).map(_ => blobRequest)
                )
                .recoverWith {
                  case e: CategorizedException =>
                    val context = SyncContext.createWithBlobRequest(connection, blobRequest)
                    val categorizedWithContext = CategorizedExceptionWithContext(context, e)
                    Future.failed(categorizedWithContext)
                  case e: Exception            =>
                    val context = SyncContext.createWithBlobRequest(connection, blobRequest)
                    val bugException =
                      bugExceptionCategoryService.generateBugException(Some(e), None)
                    val categorizedWithContext =
                      CategorizedExceptionWithContext(context, bugException)
                    Future.failed(categorizedWithContext)
                }
                .flatMap { updatedBlobRequest =>
                  startProcessing(updatedBlobRequest)
                }
            } else {
              Future.successful(Some(blobRequest))
            }
          }

        case None => Future.successful(None)
      }

    startProcessing(Some(toProcess)).recover {
      case CategorizedExceptionWithContext(context, e) =>
        logErrorContext(toProcess, e)
        errorHandler.handleError(e, context)
        None
      case e: CategorizedException                     =>
        logErrorContext(toProcess, e)
        localIssueOptFut.map { localIssueOpt =>
          val context = SyncContext(
            connection = Some(connection),
            localIssueKeyOpt = localIssueOpt,
            remoteIssueKeyOpt = Some(remoteIssueKey)
          )
          errorHandler.handleError(e, context)
        }
        None
      case e: Exception                                =>
        logErrorContext(toProcess, e)
        val bugException = bugExceptionCategoryService.generateBugException(Some(e), None)
        localIssueOptFut.map { localIssueOpt =>
          val context = SyncContext(
            connection = Some(connection),
            localIssueKeyOpt = localIssueOpt,
            remoteIssueKeyOpt = Some(remoteIssueKey)
          )
          errorHandler.handleError(bugException, context)
        }
        None
    }
  }

  private def logErrorContext(toProcess: IBlobRequest, e: Exception): Unit = {
    val syncRequest = toProcess.getSyncRequest
    val connection = toProcess.getSyncRequest.getConnection
    val remoteIssueUrn = syncRequest.getReplica.getIssueKey.getURN
    LOG.error(
      s"Exception occurred while processing blob request ID `${toProcess.getId}`, remote sync event `${syncRequest.getRemoteSyncEventId}` number `${syncRequest.getRemoteSyncEventNumber}` for blob `${toProcess.getBlobMetadata.getBlobId}`, remote issue urn `$remoteIssueUrn`, connection `${connection.getName}`",
      e
    )
  }

  private def canProcessingContinue(toProcess: IBlobRequest): Future[Boolean] = {
    val connection = toProcess.getSyncRequest.getConnection

    val isInvitationAccepted = InvitationStatus.ACCEPTED == connection.getInvitationStatus

    val isInvitationActive = ConnectionStatus.ACTIVE == connection.getStatus

    if (!isInvitationAccepted) {
      LOG.warn(
        s"blob request `${toProcess.getId}` for remote sync event `${toProcess.getSyncRequest.getRemoteSyncEventId}` for blob ${toProcess.getBlobMetadata.getBlobId}` and remote issue `${toProcess.getSyncRequest.getReplica.getIssueKey.getURN}` will not be processed because invitation for connection ${connection.getName} is not accepted"
      )
    }

    if (!isInvitationActive) {
      LOG.warn(
        s"blob request `${toProcess.getId}` for remote sync event `${toProcess.getSyncRequest.getRemoteSyncEventId}` for blob ${toProcess.getBlobMetadata.getBlobId}` and remote issue `${toProcess.getSyncRequest.getReplica.getIssueKey.getURN}` will not be processed because connection ${connection.getName} is not active"
      )
    }

    errorService
      .isOk(toProcess)
      .map { isErrorServiceOk =>
        canBeProcessed(toProcess) &&
        isInvitationActive &&
        isInvitationAccepted &&
        isErrorServiceOk
      }
      .recover {
        case _ => false
      }
  }

  private def canBeProcessed(blobRequest: IBlobRequest): Boolean = {
    val status = blobRequest.getStatus
    status != BlobRequestStatus.BLOB_PROCESSED &&
    status != BlobRequestStatus.WAITING_FOR_BLOB &&
    status != BlobRequestStatus.WAITING_BLOB_RESPONSE_RECEIVED &&
    status != BlobRequestStatus.WAITING_BLOB_ERROR_RESPONSE_RECEIVED
  }

}
