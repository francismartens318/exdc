package com.exalate.replication.services.replication

import cats.implicits._
import com.exalate.api.exception.CategorizedException
import com.exalate.error.services.api.IFileSystemExceptionCategoryService
import com.exalate.replication.services.api.node.filesystem.IFileSystemService
import com.exalate.replication.services.persistence.SupportZipRepositoryProvider
import com.exalate.services.utils.IBuildInfoService
import com.exalate.util.UrlUtils
import com.google.inject.Inject
import play.api.{Configuration, Logger}

import java.nio.file.Files
import java.text.SimpleDateFormat
import java.util.Calendar
import scala.concurrent.{ExecutionContext, Future}
import scala.jdk.CollectionConverters._
import scala.util.{Success, Try}

class SupportZipService @Inject() (
    supportZipRepositoryProvider: SupportZipRepositoryProvider,
    fileSystemService: IFileSystemService,
    buildInfoService: IBuildInfoService,
    fileSystemExceptionCategoryService: IFileSystemExceptionCategoryService,
    config: Configuration
)(implicit ec: ExecutionContext) {

  val LOG = Logger("application.services.SupportZipService")

  /** Generates support zip
    * @return
    *   path of the generated file
    */
  def generate(): Future[String] =
    Future.fromTry(fileSystemService.createSupportZipDirectory).flatMap { _ =>
      supportZipRepositoryProvider
        .get()
        .generateDbFiles(fileSystemService.createSupportZipCsvFile)
        .flatMap { seqDBPaths =>
          val timeLog = new SimpleDateFormat("yyyyMMdd-HHmmss").format(Calendar.getInstance.getTime)
          val logPathOpt = fileSystemService.getLogPath.toOption
          val scriptPaths = fileSystemService.getExternalScripts.getOrElse(Nil)

          val allPaths = logPathOpt match {
            case Some(logPath) => seqDBPaths ++ scriptPaths :+ logPath
            case None          => seqDBPaths ++ scriptPaths
          }

          val zipFileName =
            s"exalate_support_${buildInfoService.getNodeName}_${buildInfoService.getNodeVersion}_$timeLog.zip"

          Future
            .fromTry {
              for {
                _ <- cleanOldReports
                _ <- fileSystemService.zipFiles(zipFileName, allPaths)
                _ <- fileSystemService.removeExistingSupportZipDataIfExists(seqDBPaths)
                path <- fileSystemService.getSupportZipDataDir.map(_.resolve(zipFileName))
              } yield path.toString
            }
            .recoverWith {
              case e: CategorizedException =>
                LOG.error(s"Error generating support zip file.", e)
                Future.failed(e)
              case e: Exception            =>
                LOG.error(s"Error generating support zip file.", e)
                Future.failed(
                  fileSystemExceptionCategoryService
                    .categorizeFileSystemExceptionOnGeneratingSupportZip(e)
                )
            }
            .map(fullPath => UrlUtils.concat("/rest/issuehub/files/", fullPath))
        }
    }

  def cleanOldReports: Try[Unit] = {
    def deleteFiles(maxHistorySize: Int): Try[Unit] = for {
      dataDir <- fileSystemService.getSupportZipDataDir
      filesToDelete <- Try(
        Files
          .list(dataDir)
          .iterator()
          .asScala
          .toList
          .filter(_.toString.matches(".*exalate_support_.*\\.zip$"))
          .sorted
          .dropRight(maxHistorySize)
      )
      _ <-
        filesToDelete
          .traverse(p =>
            Try {
              Files.deleteIfExists(p)
              LOG.info(s"Support zip file '${p.toString}' was successfully deleted")
            }
          )
    } yield ()

    for {
      maxHistorySize <- Try(config.getOptional[Int]("exalate.supportzip.max-history-size"))
      _ <- maxHistorySize.map(deleteFiles).getOrElse(Success(()))
    } yield ()
  }.recover {
    case e =>
      LOG.error(s"Error deleting old support zip files: ${e.getMessage}!")
  }

}
