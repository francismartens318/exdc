package com.exalate.replication.services.replication.state

import scala.concurrent.Future

trait IState[T] {
  def transition(context: T): Future[Option[T]]
}
