package com.exalate.replication.services.replication

import com.exalate.api.persistence.twintrace.ITwinTraceRepository
import com.exalate.domain.replication.BasicSyncRequest
import com.exalate.services.utils.FutureUtils
import com.google.inject.Inject

import javax.inject.Singleton
import scala.concurrent.{ExecutionContext, Future}

//todo ihor remove FutureUtils.resultInf
@Singleton
class SyncRequestTypeService @Inject() (twinTraceRepository: ITwinTraceRepository)(implicit
    ec: ExecutionContext
) extends ISyncRequestTypeService {

  override def isOutOfBandRequest(
      basicSyncRequest: BasicSyncRequest,
      remoteTwinTraceId: Int
  ): Boolean = {
    val twinTraceDataOpt = FutureUtils.resultInf(
      twinTraceRepository.getRequestTwinTraceDataByRemoteTwinTraceId(
        basicSyncRequest.connectionId,
        remoteTwinTraceId
      )
    )
    twinTraceDataOpt.exists { twinTraceData =>
      val twinTraceRemoteTwinTraceIdOpt = twinTraceData.remoteTwinTraceId
      val syncRequestRemoteTwinTraceIdOpt = basicSyncRequest.remoteTwinTraceId
      twinTraceRemoteTwinTraceIdOpt.exists { twinTraceRemoteId =>
        syncRequestRemoteTwinTraceIdOpt.exists(_ != twinTraceRemoteId)
      }
    }
  }

  override def isPairOrConnectRequest(
      basicSyncRequest: BasicSyncRequest,
      remoteTwinTraceId: Int
  ): Future[Boolean] =
    twinTraceRepository
      .getRequestTwinTraceDataByRemoteTwinTraceId(basicSyncRequest.connectionId, remoteTwinTraceId)
      .map(_.isEmpty && basicSyncRequest.remoteSyncEventNumber == 1L)

}
