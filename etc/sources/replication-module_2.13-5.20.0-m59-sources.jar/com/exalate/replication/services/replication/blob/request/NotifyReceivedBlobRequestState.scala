package com.exalate.replication.services.replication.blob.request

import com.exalate.api.domain.blob.request.{BlobRequestStatus, IBlobRequest}
import com.exalate.api.persistence.replication.request.IUpdateBlobSyncRequestRepository
import com.exalate.replication.services.api.replication.worker.IWorkerNotificationService
import com.exalate.replication.services.api.transport.ITransportServiceFactory
import com.exalate.replication.services.replication.state.IState
import com.exalate.replication.services.transport.utils.ExalateVersionCheckerUtils
import com.google.inject.Inject

import scala.concurrent.ExecutionContext
import scala.concurrent.Future

class NotifyReceivedBlobRequestState @Inject() (
    transportServiceFactory: ITransportServiceFactory,
    persistence: IUpdateBlobSyncRequestRepository,
    workerNotificationService: IWorkerNotificationService
)(implicit ec: ExecutionContext)
    extends IState[IBlobRequest] {

  /** Performs transition of one of the states of BlobRequestStateMachine: status
    * `NOTIFY_BLOB_REQUEST_RECEIVED`
    * @param blobRequest
    * @return
    *   IBlobRequest
    */
  override def transition(blobRequest: IBlobRequest): Future[Option[IBlobRequest]] = {
    val future =
      if (
        ExalateVersionCheckerUtils.remoteSupportsNoExtraConfirmation(
          blobRequest.getSyncRequest.getConnection
        )
      ) Future.successful(None)
      else
        Future
          .fromTry(transportServiceFactory.get(blobRequest.getSyncRequest.getConnection))
          .flatMap(_.postBlobRequestReceived(blobRequest))

    future
      .flatMap { _ =>
        persistence.updateBlobRequestStatus(blobRequest, BlobRequestStatus.READY).map { br =>
          workerNotificationService.sendProcessBlobRequestsNotification()
          Option(br)
        }
      }
  }

}
