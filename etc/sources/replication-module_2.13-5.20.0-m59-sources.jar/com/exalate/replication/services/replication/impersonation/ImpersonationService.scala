package com.exalate.replication.services.replication.impersonation

import com.exalate.api.domain.webhook.{INonPersistentWebhookInfo, WebhookEntityType}
import com.exalate.api.persistence.auditlog.IAuditLogRepository
import com.exalate.api.persistence.webhook.IWebhookInfoRepository
import com.exalate.basic.domain.BasicIssueKey
import com.exalate.basic.domain.hubobject.v1.UpdateBasicHubIssue
import com.exalate.generic.services.{EntityContext, FullAuditInfo}
import com.exalate.generic.services.api.IActionComparator
import com.exalate.replication.services.api.replication.IEventSchedulerNotificationService
import com.exalate.replication.services.api.replication.impersonation.{
  IAuditLogService,
  IImpersonationService
}
import com.exalate.replication.services.api.trigger.ISyncAutomationService
import com.exalate.services.utils.FutureUtils

import javax.inject.Inject
import play.api.{Configuration, Logger}
import play.api.libs.json.Json

import scala.concurrent.{ExecutionContext, Future}

class ImpersonationService @Inject() (
    auditLogService: IAuditLogService,
    config: Configuration,
    actionComparator: IActionComparator,
    auditLogRepository: IAuditLogRepository,
    webhookInfoRepository: IWebhookInfoRepository,
    eventSchedulerService: IEventSchedulerNotificationService,
    syncAutomationService: ISyncAutomationService
)(implicit ec: ExecutionContext)
    extends IImpersonationService {

  val LOG = Logger("application.services.replication.impersonation.ImpersonationService")

  private lazy val WEBHOOK_OPTIMIZATION_ENABLED: Boolean =
    config.getOptional[Boolean]("exalate.webhook_optimization.enabled").getOrElse(true)

  private lazy val WEBHOOK_OPTIMIZATION_DISABLED = !WEBHOOK_OPTIMIZATION_ENABLED

  /** Handles Webhook Action Decide if a webhook needs to be processed or not. This is decided by
    * checking for: A full audit log for that entity. If there is one, the change was performed by
    * exalate so full audit log gets cleaned up A partial audit log for that issue is found. We
    * persist the webhook info and wait to get a full audit log No auditlog is found. We assume that
    * change was not performed by exalate
    *
    * @param webhookInfo
    * @param updateHubIssueOption
    * @param issueProjectKey
    * @param entityContext
    * @tparam T
    * @return
    */
  override def handleWebhookAction[T <: EntityContext](
      webhookInfo: INonPersistentWebhookInfo,
      updateHubIssueOption: Option[UpdateBasicHubIssue] = None,
      issueProjectKey: Option[String] = None,
      entityContext: Option[T]
  ): Future[None.type] = {
    LOG.debug(
      "Handling webhookAction: " + webhookInfo.getEntityId + " by user " + webhookInfo.getUserKey
    )
    auditLogService.getFor(webhookInfo).flatMap {
      case (Some(matchedAuditLog), _) =>
        // When there is fullAuditInfo we just remove it from repository
        LOG.trace(
          "Full audit log with id " + matchedAuditLog.value.getId + " is going to be removed"
        )
        auditLogRepository.delete(matchedAuditLog.value.getId).map(_ => None)
      case (None, Nil)                =>
        // When there is no fullAuditInfo or partialAuditInfo we start scheduling
        LOG.trace(
          "Full Audit log and partial audit log lists are empty. We check if webhook should be scheduled by user " + webhookInfo.getUserKey + " for issue " + webhookInfo.getIssueUrn
        )
        LOG.trace(s"with info  ${webhookInfo.getEntityJson}")
        val issuekey = new BasicIssueKey(webhookInfo.getIssueId, webhookInfo.getIssueUrn)
        eventSchedulerService.scheduleUpdateEvents(issuekey, None)
        val entityType = webhookInfo.getEntityType
        entityType match {
          case WebhookEntityType.ISSUE_CREATED    =>
            syncAutomationService.checkCriteriaAndExalate(
              issuekey,
              issueProjectKey,
              updateHubIssueOption,
              entityContext
            )
          case _ if WEBHOOK_OPTIMIZATION_DISABLED =>
            syncAutomationService.checkCriteriaAndExalate(
              issuekey,
              issueProjectKey,
              updateHubIssueOption,
              entityContext
            )
          case _                                  =>
            LOG.warn(s"Webhook entity type $entityType is not supported.")
            Future.successful(None)
        }

      case (None, partialAuditLogs) =>
        // There is partialAuditInfo, we wait for a full
        LOG.trace(
          s"There are already ${partialAuditLogs.size} partial audit info(s) for webhook" + webhookInfo.getEntityId
        )
        webhookInfoRepository.save(webhookInfo).map(_ => None)
    }
  }

  /** Parses provided issue json and returns project jey
    * @param issueJsonStr
    * @return
    */
  private def getProjectKeyFromIssueJson(issueJsonStr: String) =
    (Json.parse(issueJsonStr) \ "fields" \ "project" \ "key").asOpt[String]

  /** handles Removing of Partial AuditLog
    * @return
    */
  override def handlePartialAuditLogRemoved(): Future[None.type] =
    webhookInfoRepository
      .findAll()
      .map(_.map { wh =>
        auditLogService.getFor(wh).flatMap {
          case (None, Nil) =>
            LOG.trace("Handling Parial auditlog removed: Webhook is not related to any partial or full audit log, so we can safely assume it is not an Exalate change, time to schedule")
            val issueKey = new BasicIssueKey(wh.getIssueId, wh.getIssueUrn)
            eventSchedulerService.scheduleUpdateEvents(issueKey, None)
            syncAutomationService
              .checkCriteriaAndExalate(
                issueKey,
                getProjectKeyFromIssueJson(wh.getEntityJson),
                None,
                None
              )
              .map(_ => webhookInfoRepository.delete(wh.getId).map(_ => None))
          case _           => Future.successful(None)
        }
      })
      .flatMap(futures => Future.sequence(futures))
      .map(_ => None)

  /** Handles Worker Action: After getting a full audit info. This method will be called to ensure
    * that any persisted webhook for the full audit info is processed.
    * @param fullAuditInfo
    * @return
    */
  override def handleWorkerAction(fullAuditInfo: FullAuditInfo): Future[None.type] = {
    LOG.debug(
      "Handling workerAction for full auditLog id= " + fullAuditInfo.value.getId + " for issue id= " + fullAuditInfo.value.getIssueId + " by user " + fullAuditInfo.value.getUserKey
    )

    webhookInfoRepository
      .getByIssueId(fullAuditInfo.value.getIssueId)
      .flatMap(webhooks =>
        Future.sequence(webhooks.map {
          // Webhook was related to an Exalate change, so no scheduling needs to happen
          case webhook if actionComparator.isSameAction(webhook)(fullAuditInfo)              =>
            LOG.trace(
              "Webhook was related to an Exalate change, so no scheduling needs to happen. WebhookInfoRepository and AuditLogRepository are going to be cleaned up for issue " + fullAuditInfo.value.getIssueId
            )
            for {
              _ <- webhookInfoRepository.delete(webhook.getId)
              _ <- auditLogRepository.delete(fullAuditInfo.value.getId)
            } yield None

          // Webhook is related to a partial audit log, so we need keep waiting
          case webhook if FutureUtils.resultInf(auditLogService.getFor(webhook))._2.nonEmpty =>
            LOG.trace("Webhook is related to a partial audit log, so we need keep waiting")
            Future.successful(None)

          // Webhook is not related to any partial or audit log, so we can safely assume it is not an Exalate change, time to schedule
          case webhook                                                                       =>
            LOG.trace("Webhook is not related to any partial or audit log, so we can safely assume it is not an Exalate change, time to schedule")
            val issuekey = new BasicIssueKey(webhook.getIssueId, webhook.getIssueUrn)
            eventSchedulerService.scheduleUpdateEvents(issuekey, None)
            syncAutomationService
              .checkCriteriaAndExalate(
                issuekey,
                getProjectKeyFromIssueJson(webhook.getEntityJson),
                None,
                None
              )
              .map(_ => webhookInfoRepository.delete(webhook.getId).map(_ => None))
        })
      )
      .map(_ => None)
  }

}
