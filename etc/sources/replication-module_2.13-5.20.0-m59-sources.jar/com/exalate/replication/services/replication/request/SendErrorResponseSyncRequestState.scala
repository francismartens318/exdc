package com.exalate.replication.services.replication.request

import com.exalate.api.domain.connection.SendProtocol
import com.exalate.api.domain.request.RequestStatus
import com.exalate.api.persistence.replication.request.IRequestReplicationRepository
import com.exalate.replication.services.api.transport.ITransportServiceFactory
import com.exalate.replication.services.replication.state.IState
import play.api.Logger

import javax.inject.Inject
import scala.concurrent.{ExecutionContext, Future}

class SendErrorResponseSyncRequestState @Inject() (
    persistence: IRequestReplicationRepository,
    transportServiceFactory: ITransportServiceFactory
)(implicit ec: ExecutionContext)
    extends IState[BasicSyncRequestContext] {

  val LOG = Logger("application.services.replication.request.SendErrorResponseSyncRequestState")

  /** Performs transition of one of the states of SyncRequestStateMachine: status
    * `SEND_ERROR_RESPONSE`
    *
    * @param context
    * @return
    *   BasicSyncRequestContext
    */
  override def transition(
      context: BasicSyncRequestContext
  ): Future[Option[BasicSyncRequestContext]] = {
    val BasicSyncRequestContext(basicSyncRequest, connection) = context
    LOG.info(
      s"#transitioning request `${basicSyncRequest.id}`: sending an error response `${basicSyncRequest.errorResponseMessage
          .getOrElse("")}` (reason=`${basicSyncRequest.errorReason.getOrElse("")}`)"
    )
    Future
      .fromTry(transportServiceFactory.get(connection))
      .flatMap(_.sendErrorResponse(basicSyncRequest, connection))
      .flatMap { _ =>
        val remoteNodeInfo = connection.getRemoteInstance.getNodeInfo
        val sendProtocol = connection.getSendProtocol
        val nextStatus =
          if (remoteNodeInfo.isPollOnly || Option(sendProtocol).contains(SendProtocol.WAIT_FOR_POLL)) {
            RequestStatus.WAITING_ERROR_RESPONSE_RECEIVED
          } else {
            RequestStatus.RESPONSE_SENT
          }
        persistence
          .updateSyncRequestStatus(basicSyncRequest.id, nextStatus)
          .map(_.map(r => context.copy(request = r)))
      }
  }

}
