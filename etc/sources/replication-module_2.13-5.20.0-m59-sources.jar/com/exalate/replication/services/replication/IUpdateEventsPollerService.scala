package com.exalate.replication.services.replication

import java.util.Date

import scala.concurrent.Future

trait IUpdateEventsPollerService {

  def pollForUpdateEvents(creationTime: Date): Future[None.type] = Future.successful(None)

}
