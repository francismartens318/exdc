package com.exalate.replication.services.replication.request

import com.exalate.api.domain.request.RequestStatus
import com.exalate.api.persistence.replication.request.IRequestReplicationRepository
import com.exalate.replication.services.api.replication.IEventSchedulerNotificationService
import com.exalate.replication.services.api.replication.worker.IWorkerNotificationService
import com.exalate.replication.services.replication.state.IState
import play.api.Logger

import javax.inject.Inject
import scala.concurrent.{ExecutionContext, Future}

class TriggerUnexalateSyncRequestState @Inject() (
    eventSchedulerService: IEventSchedulerNotificationService,
    persistence: IRequestReplicationRepository,
    workerNotificationService: IWorkerNotificationService
)(implicit ec: ExecutionContext)
    extends IState[BasicSyncRequestContext] {

  val LOG = Logger("application.services.replication.request.TriggerUnexalateSyncRequestState")

  /** Performs transition of one of the states of SyncRequestStateMachine: status
    * `TRIGGER_UNEXALATE_EVENT`
    *
    * @param context
    * @return
    *   BasicSyncRequestContext
    */
  override def transition(
      context: BasicSyncRequestContext
  ): Future[Option[BasicSyncRequestContext]] = {
    val BasicSyncRequestContext(basicSyncRequest, connection) = context
    basicSyncRequest.updatedReplica.map(_.getIssueKey).foreach { createdIssueKey =>
      eventSchedulerService.scheduleUnexalateEvent(connection, createdIssueKey)
      workerNotificationService.fireAllWorkerNotifications()
    }

    persistence
      .updateSyncRequestStatus(basicSyncRequest.id, RequestStatus.COMPLETE)
      .map(_.map(r => context.copy(request = r)))
  }

}
