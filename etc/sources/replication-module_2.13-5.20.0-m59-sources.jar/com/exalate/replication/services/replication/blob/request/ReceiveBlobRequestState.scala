package com.exalate.replication.services.replication.blob.request

import com.exalate.api.domain.ErrorEntityType
import com.exalate.api.domain.blob.request.{BlobRequestStatus, IBlobRequest}
import com.exalate.api.exception.CategorizedException
import com.exalate.api.exception.bug.rest.{
  MissingBlobRestTransportBugException,
  RestTransportBugException
}
import com.exalate.api.exception.filesystem.CouldNotFindReadableFileExalateFileSystemException
import com.exalate.api.persistence.replication.request.IUpdateBlobSyncRequestRepository
import com.exalate.domain.node.storeblob.{StoredBlob, StoredBlobMetaData}
import com.exalate.replication.services.api.error.{IErrorService, SyncContext}
import com.exalate.replication.services.api.node.storeblob.IStoreBlobService
import com.exalate.replication.services.api.transport.ITransportServiceFactory
import com.exalate.replication.services.hubobject.ReplicaHelper
import com.exalate.replication.services.replication.state.IState
import play.api.Logger

import javax.inject.Inject
import scala.concurrent.{ExecutionContext, Future}

class ReceiveBlobRequestState @Inject() (
    updateBlobRepository: IUpdateBlobSyncRequestRepository,
    storeBlobService: IStoreBlobService,
    transportServiceFactory: ITransportServiceFactory,
    replicaHelper: ReplicaHelper,
    errorService: IErrorService
)(implicit ec: ExecutionContext)
    extends IState[IBlobRequest] {
  val LOG: Logger = Logger("services.replication.blob.request.ReceiveBlobRequestState")

  /** Performs transition of one of the states of BlobRequestStateMachine: status `RECEIVE_BLOB`
    * @param blobRequest
    * @return
    *   IBlobRequest
    */
  override def transition(blobRequest: IBlobRequest): Future[Option[IBlobRequest]] = {
    val blobMetadata = blobRequest.getBlobMetadata
    val syncRequest = blobRequest.getSyncRequest
    val connection = syncRequest.getConnection

    Future
      .fromTry(transportServiceFactory.get(connection))
      .flatMap(_.receiveBlob(blobRequest))
      .flatMap {
        case Some(source) =>
          storeBlobService
            .storeBlob(
              StoredBlob.generateIncomingBlobName(connection.getID, blobRequest.getRemoteBlobEventId),
              source
            )
            .map(Option(_))
        case None         =>
          Future.successful(StoredBlobMetaData.get(blobMetadata))
      }
      .flatMap { fileMetaDataOpt =>
        (if (fileMetaDataOpt.isEmpty) {
           LOG.warn(s"file path not found. This might be caused because blob was removed on the remote side before receiving it. Blob sync will be ignored")
           updateBlobRepository.updateBlobRequestStatus(
             blobRequest,
             BlobRequestStatus.SEND_BLOB_RESPONSE
           )
         } else {
           val storedBlobMetaData = fileMetaDataOpt.get
           storeBlobService
             .getChecksum(storedBlobMetaData)
             .flatMap { _ =>
               updateBlobRepository
                 .updateBlobRequestStatusAndFilePathBlobMetadata(
                   blobRequest,
                   BlobRequestStatus.SEND_BLOB_RESPONSE,
                   storedBlobMetaData.filePath
                 )
             }
         }).map(Option(_))
      }
      .recoverWith {
        // If file is not found either in local side or the remote side then the file transaction is skipped. This is has been the default behaviour of Exalate
        // We want to ensure the transaction is completed eventhough the file attachments are not synced.
        // If there's been a problem with the transmition of the file or someone deleted the file from the system then we skip it
        case e: CouldNotFindReadableFileExalateFileSystemException =>
          skipFileTransaction(blobRequest, e)
        // Remote side file is not found
        // This part of error handling needs to stay here even after the error handling refactoring [MissingBlobRestTransportBugException]
        case e: RestTransportBugException
            if e.getCause.isInstanceOf[MissingBlobRestTransportBugException] =>
          skipFileTransaction(blobRequest, e)
      }
  }

  private def skipFileTransaction(blobRequest: IBlobRequest, exception: CategorizedException) = {
    LOG.error(
      s"Blob request ${blobRequest.getSyncRequest.getId} and transaction of file ${blobRequest.getBlobMetadata.getBlobFilePath} for remote issue ${blobRequest.getSyncRequest.getReplica.getIssueKey.getURN} failed to receive blob. In this case Exalate will skip the file transaction. If this keeps happening please investigate the root cause",
      exception
    )
    // Creating a Warning so user is aware that a file has been skipped
    errorService.createError(
      ErrorEntityType.WARNING,
      exception,
      SyncContext.createWithSyncRequest(
        blobRequest.getSyncRequest.getConnection,
        blobRequest.getSyncRequest
      ),
      None
    )
    updateBlobRepository
      .updateBlobRequestStatus(blobRequest, BlobRequestStatus.SEND_BLOB_RESPONSE)
      .map(Option(_))
  }

}
