package com.exalate.replication.services.replication.blob.request

import com.exalate.api.domain.blob.request.{BlobRequestStatus, IBlobRequest}
import com.exalate.replication.services.replication.state.IState

import javax.inject.Inject

class BlobRequestStateMachine @Inject() (
    notifyReceivedBlobRequestState: NotifyReceivedBlobRequestState,
    readyRequestState: ReadyBlobRequestState,
    receiveBlobRequestState: ReceiveBlobRequestState,
    sendBlobErrorResponseRequestState: SendBlobErrorResponseRequestState,
    sendBlobResponseBlobRequestState: SendBlobResponseBlobRequestState
) {

  /** Gets state of blob request execution. One of the state for the following statuses:
    * NOTIFY_BLOB_REQUEST_RECEIVED, WAITING_FOR_BLOB, READY, RECEIVE_BLOB, SEND_BLOB_RESPONSE,
    * SEND_BLOB_ERROR_RESPONSE, WAITING_BLOB_RESPONSE_RECEIVED,
    * WAITING_BLOB_ERROR_RESPONSE_RECEIVED, BLOB_PROCESSED
    *
    * @param blobRequest
    * @return
    */
  def getState(blobRequest: IBlobRequest): IState[IBlobRequest] =
    blobRequest.getStatus match {
      case BlobRequestStatus.NOTIFY_BLOB_REQUEST_RECEIVED => notifyReceivedBlobRequestState
      case BlobRequestStatus.READY                        => readyRequestState
      case BlobRequestStatus.RECEIVE_BLOB                 => receiveBlobRequestState
      case BlobRequestStatus.SEND_BLOB_ERROR_RESPONSE     => sendBlobErrorResponseRequestState
      case BlobRequestStatus.SEND_BLOB_RESPONSE           => sendBlobResponseBlobRequestState
    }

}
