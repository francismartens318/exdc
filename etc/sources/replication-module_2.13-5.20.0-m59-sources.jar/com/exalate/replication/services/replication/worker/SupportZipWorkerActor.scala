package com.exalate.replication.services.replication.worker

import akka.actor._
import com.exalate.api.domain.progresstracker.ProgressTrackerStatus
import com.exalate.api.persistence.progresstracker.IProgressTrackerRepository
import com.exalate.replication.services.api.replication.IEventSchedulerFromTrackerService
import com.exalate.replication.services.replication.SupportZipService
import com.exalate.replication.services.replication.worker.SupportZipWorkerActor.GenerateSupportZip
import com.exalate.replication.services.utils.LoggingUtils.tryWithLoggedBugs
import com.google.inject.Inject
import play.api.Logger
import scala.concurrent.ExecutionContext

object SupportZipWorkerActor {
  case class GenerateSupportZip(taskId: Int)
}

class SupportZipWorkerActor @Inject() (
    progressTrackerRepository: IProgressTrackerRepository,
    supportZipService: SupportZipService
) extends Actor {

  val LOG: Logger = Logger("application.services.replication.worker.SupportZipWorkerActor")

  implicit private val ec: ExecutionContext = context.dispatcher

  def receive: Receive = {
    case GenerateSupportZip(taskId) =>
      tryWithLoggedBugs {
        LOG.info("SupportZipWorkerActor:Generating support zip")
        val downloadUrlFuture = supportZipService.generate()
        downloadUrlFuture
          .map { downloadUrl =>
            progressTrackerRepository.updateProgressTracker(
              taskId,
              ProgressTrackerStatus.DONE,
              downloadUrl
            )
            LOG.info("SupportZipWorkerActor:Generating support zip - done")
          }
          .recover {
            case e =>
              progressTrackerRepository.addError(taskId, "Error generating support zip file")
              progressTrackerRepository.updateProgressTracker(
                taskId,
                ProgressTrackerStatus.DONE,
                null
              )
              LOG.error("Error generating support zip file", e)
          }
      }

    case _ =>
      tryWithLoggedBugs {
        LOG.trace("SupportZipWorkerActor:Can not recognize incoming message")
      }
  }

}
