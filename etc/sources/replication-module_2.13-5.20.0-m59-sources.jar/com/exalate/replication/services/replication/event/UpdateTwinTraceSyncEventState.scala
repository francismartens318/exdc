package com.exalate.replication.services.replication.event

import com.exalate.api.domain.IPersistentReplica
import com.exalate.api.domain.event.{EventStatus, ISyncEvent}
import com.exalate.api.domain.twintrace.TwinTraceStatus.{INITIAL, SYNCHRONIZED}
import com.exalate.api.domain.twintrace.{ITrace, ITwinTrace, TraceAction}
import com.exalate.api.persistence.replication.event.IEventReplicationRepository
import com.exalate.api.persistence.twintrace.ITwinTraceRepository
import com.exalate.basic.domain.BasicNonPersistentTrace
import com.exalate.domain.replication.BasicSyncEvent
import com.exalate.error.services.api.IBugExceptionCategoryService
import com.exalate.persistence.RepositoryUtils
import com.exalate.replication.services.api.replication.worker.IWorkerNotificationService
import com.exalate.replication.services.replication.state.IState
import com.exalate.replication.services.utils.TraceUtils

import javax.inject.Inject
import play.api.Logger

import scala.jdk.CollectionConverters._
import scala.concurrent.ExecutionContext
import scala.concurrent.Future

class UpdateTwinTraceSyncEventState @Inject() (
    persistence: IEventReplicationRepository,
    workerNotificationService: IWorkerNotificationService,
    twinTraceRepository: ITwinTraceRepository,
    bugExceptionCategoryService: IBugExceptionCategoryService
)(implicit ec: ExecutionContext)
    extends IState[ISyncEvent] {

  private val LOG: Logger = Logger(
    "application.services.replication.event.UpdateTwinTraceSyncEventState"
  )

  /** Performs transition of one of the states of SyncEventStateMachine: status `UPDATE_TWINTRACE`
    *
    * @param syncEvent
    * @return
    *   ISyncEvent
    */
  override def transition(syncEvent: ISyncEvent): Future[Option[ISyncEvent]] = {
    lazy val relationName = syncEvent.getConnection.getName
    lazy val syncEventId = syncEvent.getId

    val remoteReplica = syncEvent.getRemoteReplica
    twinTraceRepository.getTwinTraceById(syncEvent.getTwinTraceId).flatMap {
      case Some(twinTrace) =>
        val twinTraceStatus = twinTrace.getStatus
        val (lastReceivedResponse, remoteReplicaOpt, traces) =
          getValuesToUpdate(syncEvent, remoteReplica, twinTrace)
        LOG.info(
          s"#transition: updating syncEvent `$syncEventId` for relation `$relationName` to PROCESSED"
        )
        val twinTraceStatusOpt = if (twinTraceStatus == INITIAL) Some(SYNCHRONIZED) else None
        persistence
          .updateTwinTraceAndSyncEventStatus(
            twinTrace,
            twinTraceStatusOpt,
            lastReceivedResponse,
            remoteReplicaOpt,
            traces,
            syncEvent,
            if (BasicSyncEvent.isCleanupOrUnexalateEvent(syncEvent)) EventStatus.REMOVE_LINK
            else EventStatus.PROCESSED,
            RepositoryUtils.toIntOpt(Option[Integer](syncEvent.getRemoteTwinTraceId))
          )
          .map { eventOpt =>
            eventOpt.map { event =>
              workerNotificationService.fireAllWorkerNotifications()
              event
            }
          }

      case None =>
        val localIssueKey = syncEvent.getLocalReplica.getIssueKey

        // Is a bug situation, handled because scala wants us to handle all the cases when matching an Option
        val noTwinTraceBugException = bugExceptionCategoryService.generateNoTwinTraceBugException(
          Option(relationName),
          Option(syncEventId),
          None,
          Option(localIssueKey),
          Option(remoteReplica).map(_.getIssueKey)
        )
        LOG.error(
          s"No twin trace was found, connection is `$relationName`, sync event ID `$syncEventId`, local issue `$localIssueKey`.",
          noTwinTraceBugException
        )
        Future.failed(noTwinTraceBugException)
    }
  }

  private def getValuesToUpdate(
      syncEvent: ISyncEvent,
      remoteReplica: IPersistentReplica,
      twinTrace: ITwinTrace
  ): (Option[Int], Option[IPersistentReplica], Option[Seq[BasicNonPersistentTrace]]) = {

    if (BasicSyncEvent.isCleanupEvent(syncEvent)) {
      return (Some(1), None, None)
    }

    val lastReceivedResponseOpt =
      Option(syncEvent.getId).filter(_ > twinTrace.getLastReceivedResponse)

    val remoteReplicaOpt = Option(twinTrace.getRemoteReplica) match {
      // We will only update the remote replica if
      // The new remote replica is newer (based on valid on time) than the current one
      case Some(r) =>
        if (r.getValidOn.getTimeMillis < remoteReplica.getValidOn.getTimeMillis)
          Option(remoteReplica)
        else None
      // Or there is no remote replica on the twin trace
      case None    => Option(remoteReplica)
    }

    val nonPersistentTraces =
      if (TraceUtils.listEqualsIgnoreOrder(twinTrace.getAllFieldTraces, syncEvent.getTraces)) {
        None
      } else {
        Option(syncEvent.getTraces.asScala.toSeq.map { t =>
          new BasicNonPersistentTrace()
            .from(t)
            .setAction(TraceAction.NONE)
        })
      }

    (lastReceivedResponseOpt, remoteReplicaOpt, nonPersistentTraces)
  }

}
