package com.exalate.replication.services.replication.blob.event

import com.exalate.api.domain.blob.event.{BlobEventStatus, IBlobEvent}
import com.exalate.api.domain.connection.ReceiveProtocol
import com.exalate.api.persistence.replication.blobevent.IBlobEventReplicationRepository
import com.exalate.domain.node.storeblob.StoredBlobMetaData
import com.exalate.error.services.api.IBugExceptionCategoryService
import com.exalate.replication.services.api.node.storeblob.IStoreBlobService
import com.exalate.replication.services.api.replication.worker.IWorkerNotificationService
import com.exalate.replication.services.api.transport.ITransportServiceFactory
import com.exalate.replication.services.replication.state.IState
import play.api.Logger

import javax.inject.Inject
import scala.concurrent.{ExecutionContext, Future}

class PublishBlobIfNeededEventState @Inject() (
    persistence: IBlobEventReplicationRepository,
    transportServiceFactory: ITransportServiceFactory,
    storeBlobService: IStoreBlobService,
    workerNotificationService: IWorkerNotificationService,
    bugExceptionCategoryService: IBugExceptionCategoryService
)(implicit ec: ExecutionContext)
    extends IState[IBlobEvent] {

  val LOG = Logger("application.services.replication.blob.event.PublishBlobIfNeededEventState")

  /** Performs transition of one of the states of BlobEventStateMachine: status
    * `PUBLISH_BLOB_IF_NEEDED`
    * @param blobEvent
    * @return
    */
  override def transition(blobEvent: IBlobEvent): Future[Option[IBlobEvent]] = {
    val connection = blobEvent.getSyncEvent.getConnection
    val receiveProtocol = connection.getReceiveProtocol

    if (ReceiveProtocol.POLL == receiveProtocol) {
      val transportService = transportServiceFactory.get(connection).get
      val blobMetadata = blobEvent.getBlobMetadata
      StoredBlobMetaData.get(blobMetadata) match {
        case Some(blobMetaData) =>
          storeBlobService.retrieveBlob(blobMetaData).flatMap {
            case Some(file) =>
              transportService.publishBlob(blobEvent, file).flatMap { _ =>
                persistence
                  .updateBlobEventStatus(blobEvent, BlobEventStatus.WAITING_FOR_BLOB_RESPONSE)
                  .map { be =>
                    workerNotificationService.sendProcessBlobEventsNotification()
                    Some(be)
                  }
              }
            case None       =>
              val noBlobInFilePathBugException =
                bugExceptionCategoryService.generateNoBlobInFilePathBugException(
                  blobMetaData.filePath,
                  blobMetadata.getId,
                  blobEvent.getId,
                  None
                )
              val msg =
                s"File not detected in filepath `$blobMetaData` for blob metadata ID `${blobMetadata.getId}` for blob event ID `${blobEvent.getId}`," +
                  s" but it had to be stored there during the Store Blob Event State."
              LOG.error(msg, noBlobInFilePathBugException)
              Future.failed(noBlobInFilePathBugException)
          }

        case None =>
          val msg =
            s"Blob metadata ID `${blobMetadata.getId}` for blob event `${blobEvent.getId}` does not contain any file path," +
              s" but it should been set during the Store Blob Event State."
          val noBlobFilePathBugException = bugExceptionCategoryService
            .generateNoBlobFilePathBugException(blobMetadata.getId, blobEvent.getId)
          LOG.error(msg, noBlobFilePathBugException)
          Future.failed(noBlobFilePathBugException)
      }
    } else {
      persistence.updateBlobEventStatus(blobEvent, BlobEventStatus.WAITING_FOR_BLOB_RESPONSE).map {
        be =>
          workerNotificationService.sendProcessBlobEventsNotification()
          Some(be)
      }
    }
  }

}
