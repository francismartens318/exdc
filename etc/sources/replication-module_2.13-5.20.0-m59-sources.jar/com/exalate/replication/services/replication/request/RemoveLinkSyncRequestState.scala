package com.exalate.replication.services.replication.request

import com.exalate.api.domain.request.RequestStatus
import com.exalate.api.persistence.replication.request.IRequestReplicationRepository
import com.exalate.api.persistence.twintrace.ITwinTraceRepository
import com.exalate.domain.replication.BasicSyncRequest
import com.exalate.error.services.api.IBugExceptionCategoryService
import com.exalate.generic.services.api.ITrackerHubObjectService
import com.exalate.replication.services.replication.state.IState
import play.api.Logger

import javax.inject.Inject
import scala.concurrent.{ExecutionContext, Future}

class RemoveLinkSyncRequestState @Inject() (
    persistence: IRequestReplicationRepository,
    twinTraceRepository: ITwinTraceRepository,
    hubObjectService: ITrackerHubObjectService,
    bugExceptionCategoryService: IBugExceptionCategoryService
)(implicit ec: ExecutionContext)
    extends IState[BasicSyncRequestContext] {

  val LOG = Logger("application.services.replication.request.RemoveLinkSyncRequestState")

  /** Performs transition of one of the states of SyncRequestStateMachine: status `REMOVE_LINK`
    *
    * @param context
    * @return
    *   BasicSyncRequestContext
    */
  override def transition(
      context: BasicSyncRequestContext
  ): Future[Option[BasicSyncRequestContext]] = {
    val BasicSyncRequestContext(basicSyncRequest, connection) = context
    basicSyncRequest.remoteTwinTraceId match {
      case Some(remoteTwinTraceId) =>
        twinTraceRepository
          .getTwinTraceReplicasByRemoteTwinTraceId(connection.getID, remoteTwinTraceId)
          .flatMap {
            case Some(twinTraceReplicas) =>
              twinTraceReplicas.localReplica
                .map(_.getIssueKey)
                .fold {
                  persistence
                    .updateSyncRequestStatus(basicSyncRequest.id, RequestStatus.COMPLETE)
                    .map(toUpdatedContext(_, context))
                } { localIssueKey =>
                  val issueLinkFieldNameOpt =
                    Option(connection.getTrackerSettings.getIssueLinkFieldName).filter(_.nonEmpty)
                  issueLinkFieldNameOpt
                    .map(hubObjectService.removeEntityLinkField(connection, _, localIssueKey))
                    .getOrElse(Future.successful(None))
                    .flatMap(_ =>
                      persistence
                        .updateSyncRequestStatus(basicSyncRequest.id, RequestStatus.COMPLETE)
                    )
                    .map(toUpdatedContext(_, context))
                }

            // Possible for situation, when side A send pair event to B, failed before tt created on B. And then we do cleanup.
            case None                    =>
              LOG.error(
                s"No twin trace was found for ${basicSyncRequest.syncType.toString} request, connection is `${connection.getName}`, sync request ID `${basicSyncRequest.id}`, remote issue `${basicSyncRequest.replica.getIssueKey}`."
              )
              persistence
                .updateSyncRequestStatus(basicSyncRequest.id, RequestStatus.COMPLETE)
                .map(toUpdatedContext(_, context))
          }

      case _ =>
        val errMsg =
          s"A remote twin trace ID is missed in the sync request with id=${basicSyncRequest.id} though it is expected to be present."
        val ex = bugExceptionCategoryService.generateBugException(None, Some(errMsg))
        Future.failed(ex)
    }
  }

  private def toUpdatedContext(
      updatedRequestOpt: Option[BasicSyncRequest],
      context: BasicSyncRequestContext
  ): Option[BasicSyncRequestContext] =
    updatedRequestOpt.map(r => context.copy(request = r))

}
