package com.exalate.replication.services.replication.in

import com.exalate.api.domain.blob.event.IBlobEvent
import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.event.ISyncEvent
import com.exalate.replication.controllers.handlers._
import com.exalate.replication.services.api.error.IErrorService
import com.exalate.replication.services.api.replication.in.{IPollSchedulerService, IPollerService}
import com.exalate.replication.services.api.transport.rest.v2.{
  IConnectionPollClient,
  INotifyReceivedClient,
  IPollClient
}
import com.exalate.replication.services.api.transport.v5_1.IConnectionPollClientV5
import com.exalate.replication.services.transport.utils.ExalateVersionCheckerUtils
import com.exalate.replication.services.transport.value.{
  BlobErrorResponseValue,
  BlobResponseValue,
  ErrorResponseValue,
  ErrorValue,
  SyncResponseValue
}
import com.exalate.services.utils.pagination.PaginationUtil
import com.google.inject.Inject
import org.slf4j.LoggerFactory

import scala.concurrent.{ExecutionContext, Future}

class PollerService @Inject() (
    pollClient: IPollClient,
    syncRequestHandler: SyncRequestHandler,
    blobRequestHandler: BlobRequestHandler,
    syncResponseHandler: SyncResponseHandler,
    errorResponseHandler: ErrorResponseHandler,
    blobResponseHandler: BlobResponseHandler,
    blobErrorResponseHandler: BlobErrorResponseHandler,
    connectionPollClient: IConnectionPollClient,
    notifyReceivedClient: INotifyReceivedClient,
    errorService: IErrorService,
    connectionPollClientV5: IConnectionPollClientV5
)(implicit ec: ExecutionContext)
    extends IPollerService {

  private val LOG = LoggerFactory.getLogger("application.services.replication.PollerService")

  /** Poll all messages in private to public connection, it is called from
    * {@link com.exalate.replication.services.replication.worker.PollWorkerActor}
    * @param connection
    * @return
    */
  override def pollAllMessages(connection: IConnection): Future[None.type] =
    Future
      .sequence(
        Seq(
          pollSyncRequests(connection),
          pollBlobRequests(connection),
          pollSyncResponses(connection),
          pollSyncErrorResponses(connection),
          pollBlobResponses(connection),
          pollBlobErrorResponses(connection)
        )
      )
      .flatMap(_ => errorService.deletePollingTransportErrors(connection).map(_ => None))

  /** Checks whether connections on the public side should be polled. If remote side supports
    * "checking connection polling", sends a list of connection names in order to check whether they
    * exist on the remote side. Remote side responds with list of names that still exist. Otherwise
    * (if remote side does not support "checking connection polling") the private side will poll
    * entire list of connections.
    *
    * @param connections
    *   A collection of connections that match the local side's criteria to poll (ReceiveProtocol,
    *   ConnectionStatus, InvitationStatus)
    * @return
    *   Future of a collection of connections that should poll taking into account the remote side.
    */
  override def shouldPollRemoteSideAware(connections: Seq[IConnection]): Future[Seq[IConnection]] =
    connections
      .groupBy(_.getRemoteInstance.getNodeInfo.getInstanceUid)
      .foldLeft(Future.successful(Seq.empty[IConnection])) {
        case (result, (_, connectionSeq)) =>
          result.flatMap { r =>
            if (
              ExalateVersionCheckerUtils.remoteSupportsCheckingConnectionsPolling(connectionSeq.head)
            ) {
              val remoteUrl = connectionSeq.head.getRemoteInstance.getUrl.toExternalForm
              connectionPollClientV5
                .shouldBePolled(remoteUrl, connectionSeq)
                .map { response =>
                  r ++ connections.filter(c => response.connectionNameSeq.contains(c.getName))
                }
                .recoverWith {
                  case _ => Future.successful(r ++ connectionSeq)
                }
            } else {
              Future.successful(r ++ connectionSeq)
            }
          }
      }

  /** Polls for Sync Requests (private <> public connection)
    * @param connection
    * @return
    */
  private def pollSyncRequests(connection: IConnection): Future[None.type] =
    if (ExalateVersionCheckerUtils.remoteSupportsHeaderInRequest(connection)) {
      def getPage(prevPage: Option[PollingPage]): Future[Option[PollingPage]] = {
        val syncRequestsIds = accumulateIds(prevPage)
        connectionPollClient
          .pollSyncRequests(connection, syncRequestsIds)
          .flatMap { responseValue =>
            LOG.trace(
              s"Obtained response with ${responseValue.responses.size} sync requests (${responseValue.remainingAmount} remaining)."
            )
            Future
              .sequence(responseValue.responses.map { requestValue =>
                val errorOrSrOptFuture = syncRequestHandler.handleSyncRequest(requestValue)
                errorOrSrOptFuture.foreach {
                  case Left(ErrorValue(className, message)) =>
                    LOG.error(
                      s"#pollSyncRequests An error occurred while attempting to schedule a sync request. Error name: `$className`. Error message: `$message`"
                    )
                  case Right(None)                          =>
                    LOG.debug("#pollSyncRequests notifying even though no new request was scheduled, since this sync request was already received")
                    if (ExalateVersionCheckerUtils.remoteSupportsNoExtraConfirmation(connection))
                      Future.successful(None)
                    else notifyReceivedClient.postRequestReceived(requestValue, connection)
                  case Right(Some(sr))                      =>
                    LOG.debug("#pollSyncRequests notifying since a request was scheduled")
                    if (ExalateVersionCheckerUtils.remoteSupportsNoExtraConfirmation(connection))
                      Future.successful(None)
                    else notifyReceivedClient.postRequestReceived(sr)
                }
                errorOrSrOptFuture.map(_ => None)
              })
              // FIXME: We're notifying that we'd received all the ids, even though some could've failed
              .map(_ =>
                Option(
                  PollingPage(
                    syncRequestsIds,
                    responseValue.responses.map(_.syncEventId).toSet,
                    prevPage.map(_.ids).getOrElse(Set.empty[Int])
                  )
                )
              )
          }
      }
      paginate(getPage)
    } else {
      LOG.trace("Polling for all sync requests for connection " + connection.getName)
      pollClient
        .pollSyncRequests(connection)
        .flatMap { requestValueSeq =>
          Future.sequence(
            requestValueSeq.map { requestValue =>
              val future = syncRequestHandler.handleSyncRequest(requestValue)
              future.foreach {
                case Left(ErrorValue(className, message)) =>
                  LOG.error(
                    s"#pollSyncRequests (old API) An error occurred while attempting to schedule a sync request. Error name: `$className`. Error message: `$message`"
                  )
                case Right(None)                          =>
                  LOG.debug("#pollSyncRequests (old API) notifying even though no new request was scheduled, since this sync request was already received")
                  if (ExalateVersionCheckerUtils.remoteSupportsNoExtraConfirmation(connection))
                    Future.successful(None)
                  else notifyReceivedClient.postRequestReceived(requestValue, connection)
                case Right(Some(sr))                      =>
                  LOG.debug("#pollSyncRequests (old API) notifying since a request was scheduled")
                  if (ExalateVersionCheckerUtils.remoteSupportsNoExtraConfirmation(connection))
                    Future.successful(None)
                  else notifyReceivedClient.postRequestReceived(sr)
              }
              future.map(_ => None)
            }
          )
        }
        .map(_ => None)
    }

  /** Polls for blob requests (private <> public connection)
    * @param connection
    * @return
    */
  private def pollBlobRequests(connection: IConnection): Future[None.type] =
    if (ExalateVersionCheckerUtils.remoteSupportsHeaderInRequest(connection)) {
      def getPage(prevPage: Option[PollingPage]): Future[Option[PollingPage]] = {
        val blobEventIds = accumulateIds(prevPage)
        connectionPollClient
          .pollBlobRequests(connection, blobEventIds)
          .flatMap { responseValue =>
            Future
              .sequence(responseValue.responses.map { blobRequestValue =>
                val eventualMaybeValue = blobRequestHandler.handleBlobRequest(blobRequestValue)
                eventualMaybeValue.map {
                  case Right(None)              =>
                    if (ExalateVersionCheckerUtils.remoteSupportsNoExtraConfirmation(connection))
                      Future.successful(None)
                    else notifyReceivedClient.postBlobRequestReceived(blobRequestValue, connection)
                  case Right(Some(blobRequest)) =>
                    if (ExalateVersionCheckerUtils.remoteSupportsNoExtraConfirmation(connection))
                      Future.successful(None)
                    else notifyReceivedClient.postBlobRequestReceived(blobRequest)
                  case Left(errorValue)         =>
                    LOG.error(
                      s"An error occurred while attempting to schedule a blob request. Error name: `${errorValue.className}`. Error message: `${errorValue.message}`"
                    )
                }
                eventualMaybeValue
              })
              .map { _ =>
                LOG.trace(
                  s"Obtained response with ${responseValue.responses.size} blob requests (${responseValue.remainingAmount} remaining)."
                )
                Option(
                  PollingPage(
                    blobEventIds,
                    responseValue.responses.flatMap(_.blobEventId).toSet,
                    prevPage.map(_.ids).getOrElse(Set.empty[Int])
                  )
                )
              }
          }
      }
      paginate(getPage)
    } else {
      LOG.trace("Polling for all blob requests for connection " + connection.getName)
      pollClient
        .pollBlobRequests(connection)
        .flatMap { blobRequestValueSeq =>
          Future.sequence(
            blobRequestValueSeq.map { blobRequestValue =>
              val brFuture = blobRequestHandler.handleBlobRequest(blobRequestValue)
              brFuture.foreach {
                case Right(None)              =>
                  if (ExalateVersionCheckerUtils.remoteSupportsNoExtraConfirmation(connection))
                    Future.successful(None)
                  else notifyReceivedClient.postBlobRequestReceived(blobRequestValue, connection)
                case Right(Some(blobRequest)) =>
                  if (ExalateVersionCheckerUtils.remoteSupportsNoExtraConfirmation(connection))
                    Future.successful(None)
                  else notifyReceivedClient.postBlobRequestReceived(blobRequest)
                case Left(errorValue)         =>
                  LOG.error(
                    s"An error occurred while attempting to schedule a blob request. Error name: `${errorValue.className}`. Error message: `${errorValue.message}`"
                  )
              }
              brFuture
            }
          )
        }
        .map(_ => None)
    }

  /** Polls for sync response (private <> public connection)
    * @param connection
    * @return
    */
  private def pollSyncResponses(connection: IConnection): Future[None.type] = {
    def handleSyncResponseValue(
        syncResponseValue: SyncResponseValue
    ): Future[Option[ISyncEvent]] = {
      val eventOptFuture = syncResponseHandler.handleSyncResponse(syncResponseValue)
      eventOptFuture.foreach(_.foreach { syncEvent =>
        if (ExalateVersionCheckerUtils.remoteSupportsNoExtraConfirmation(connection))
          Future.successful(None)
        else notifyReceivedClient.postResponseReceived(syncEvent)
      })
      eventOptFuture
    }
    if (ExalateVersionCheckerUtils.remoteSupportsHeaderInRequest(connection)) {
      def getPage(prevPage: Option[PollingPage]): Future[Option[PollingPage]] = {
        val syncEventIds = accumulateIds(prevPage)
        connectionPollClient
          .pollSyncResponses(connection, syncEventIds)
          .flatMap { responseValue =>
            LOG.trace(
              s"Obtained response with ${responseValue.responses.size} blob requests (${responseValue.remainingAmount} remaining)."
            )
            Future
              .sequence(
                responseValue.responses.map(handleSyncResponseValue)
              )
              .map(_ =>
                Option(
                  PollingPage(
                    syncEventIds,
                    responseValue.responses.map(_.syncEventId).toSet,
                    prevPage.map(_.ids).getOrElse(Set.empty[Int])
                  )
                )
              )
          }
      }
      paginate(getPage)
    } else {
      LOG.trace("Polling for all sync responses for connection " + connection.getName)
      pollClient
        .pollSyncResponses(connection)
        .flatMap { syncResponseValueSeq =>
          Future.sequence(
            syncResponseValueSeq.map(handleSyncResponseValue)
          )
        }
        .map(_ => None)
    }
  }

  /** Polls for sync error response(private <> public connection)
    * @param connection
    * @return
    */
  private def pollSyncErrorResponses(connection: IConnection): Future[None.type] = {
    def handleSyncErrorResponseValue(
        errorResponseValue: ErrorResponseValue
    ): Future[Either[ErrorValue, Option[ISyncEvent]]] = {
      val eventOptFuture = errorResponseHandler.handleErrorResponse(errorResponseValue)
      eventOptFuture.foreach(_.right.foreach(_.foreach { syncEvent =>
        if (ExalateVersionCheckerUtils.remoteSupportsNoExtraConfirmation(connection))
          Future.successful(None)
        else notifyReceivedClient.postResponseReceived(syncEvent)
      }))
      eventOptFuture
    }
    if (ExalateVersionCheckerUtils.remoteSupportsHeaderInRequest(connection)) {
      def getPage(prevPage: Option[PollingPage]): Future[Option[PollingPage]] = {
        val syncEventIds = accumulateIds(prevPage)
        connectionPollClient
          .pollSyncErrorResponses(connection, syncEventIds)
          .flatMap { responseValue =>
            LOG.trace(
              s"Obtained response with ${responseValue.responses.size} error sync responses (${responseValue.remainingAmount} remaining)."
            )
            Future
              .sequence(responseValue.responses.map(handleSyncErrorResponseValue))
              .map(_ =>
                Option(
                  PollingPage(
                    syncEventIds,
                    responseValue.responses.map(_.syncEventId).toSet,
                    prevPage.map(_.ids).getOrElse(Set.empty[Int])
                  )
                )
              )
          }
      }
      paginate(getPage)
    } else {
      LOG.trace("Polling for all error responses for connection " + connection.getName)
      pollClient
        .pollSyncErrorResponses(connection)
        .flatMap { errorResponseValueSeq =>
          Future.sequence(errorResponseValueSeq.map(handleSyncErrorResponseValue))
        }
        .map(
          _.foreach(errorValueOpt =>
            errorValueOpt.left.foreach(errorValue =>
              LOG.error(
                s"An error occurred while attempting to handle an error sync response. Error name: `${errorValue.className}`. Error message: `${errorValue.message}`"
              )
            )
          )
        )
        .map(_ => None)
    }
  }

  /** Polls for blob response (private <> public connection)
    * @param connection
    * @return
    */
  private def pollBlobResponses(connection: IConnection): Future[None.type] = {
    def handleBlobResponseValue(
        blobResponseValue: BlobResponseValue
    ): Future[Option[IBlobEvent]] = {
      val blobEventOptFuture = blobResponseHandler.handleBlobResponse(blobResponseValue)
      blobEventOptFuture.foreach(
        _.foreach(blobEvent =>
          if (ExalateVersionCheckerUtils.remoteSupportsNoExtraConfirmation(connection))
            Future.successful(None)
          else notifyReceivedClient.postBlobResponseReceived(blobEvent)
        )
      )
      blobEventOptFuture
    }
    if (ExalateVersionCheckerUtils.remoteSupportsHeaderInRequest(connection)) {
      def getPage(prevPage: Option[PollingPage]): Future[Option[PollingPage]] = {
        val blobEventIds = accumulateIds(prevPage)
        connectionPollClient
          .pollBlobResponses(connection, blobEventIds)
          .flatMap { responseValue =>
            LOG.trace(
              s"Obtained response with ${responseValue.responses.size} blob responses (${responseValue.remainingAmount} remaining)."
            )
            Future
              .sequence(responseValue.responses.map(handleBlobResponseValue))
              .map(_ =>
                Option(
                  PollingPage(
                    blobEventIds,
                    responseValue.responses.flatMap(_.blobEventId).toSet,
                    prevPage.map(_.ids).getOrElse(Set.empty[Int])
                  )
                )
              )
          }
      }
      paginate(getPage)
    } else {
      LOG.trace("Polling for all blob responses for connection " + connection.getName)
      pollClient
        .pollBlobResponses(connection)
        .flatMap { blobResponseValueSeq =>
          Future.sequence(blobResponseValueSeq.map(handleBlobResponseValue))
        }
        .map(_ => None)
    }
  }

  /** Polls for blob error response (private <> public connection)
    * @param connection
    * @return
    */
  private def pollBlobErrorResponses(connection: IConnection): Future[None.type] = {
    def handleBlobErrorResponseValue(
        blobErrorResponseValue: BlobErrorResponseValue
    ): Future[Option[IBlobEvent]] = {
      val blobEventOptFuture =
        blobErrorResponseHandler.handleBlobErrorResponse(blobErrorResponseValue)
      blobEventOptFuture.foreach(
        _.foreach(blobEvent =>
          if (ExalateVersionCheckerUtils.remoteSupportsNoExtraConfirmation(connection))
            Future.successful(None)
          else notifyReceivedClient.postBlobResponseReceived(blobEvent)
        )
      )
      blobEventOptFuture
    }
    if (ExalateVersionCheckerUtils.remoteSupportsHeaderInRequest(connection)) {
      def getPage(prevPage: Option[PollingPage]): Future[Option[PollingPage]] = {
        val blobEventIds = accumulateIds(prevPage)
        connectionPollClient
          .pollBlobErrorResponses(connection, blobEventIds)
          .flatMap { responseValue =>
            LOG.trace(
              s"Obtained response with ${responseValue.responses.size} blob error responses (${responseValue.remainingAmount} remaining)."
            )
            Future
              .sequence(responseValue.responses.map(handleBlobErrorResponseValue))
              .map(_ =>
                Option(
                  PollingPage(
                    blobEventIds,
                    responseValue.responses.flatMap(_.blobEventId).toSet,
                    prevPage.map(_.ids).getOrElse(Set.empty[Int])
                  )
                )
              )
          }
      }
      paginate(getPage)
    } else {
      LOG.trace("Polling for all blob error responses for connection " + connection.getName)
      pollClient
        .pollBlobErrorResponses(connection)
        .flatMap { blobErrorResponseValueSeq =>
          Future.sequence(blobErrorResponseValueSeq.map(handleBlobErrorResponseValue))
        }
        .map(_ => None)
    }
  }

  /** paginates through the pages generated by getPageFn, stops when either getPageFn returns
    * Future[None.type] or Future[Some(PollingPage(_, 0, _))]
    * @param getPageFn
    *   \- function producing pages for pagination
    */
  private def paginate(getPageFn: Option[PollingPage] => Future[Option[PollingPage]]) =
    PaginationUtil.paginate(
      getPageFn,
      { (pp: PollingPage) =>
        val noIdsReturnedFromCurPolling = pp.ids.isEmpty
        if (noIdsReturnedFromCurPolling) {
          LOG.trace("#paginate no ids remain since last polling #nothingRemains")
          true
        } else {
          val idsAreSame = pp.ids == pp.prevIds
          if (idsAreSame) {
            LOG.warn(
              s"#paginate same amount remains after getting these sync event ids: ${pp.ids.mkString(", ")}"
            )
            true
          } else false
        }
      }
    )

  private def accumulateIds(prevPageOpt: Option[PollingPage]): Set[Int] = prevPageOpt match {
    case None    => Set.empty[Int]
    case Some(v) => v.idAcc ++ v.ids
  }

}

case class PollingPage(idAcc: Set[Int], ids: Set[Int], prevIds: Set[Int])
