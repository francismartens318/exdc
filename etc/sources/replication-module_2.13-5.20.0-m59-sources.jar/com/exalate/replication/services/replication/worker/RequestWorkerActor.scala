package com.exalate.replication.services.replication.worker

import akka.actor._
import com.exalate.replication.services.api.replication.blob.IBlobRequestProcessorService
import com.exalate.replication.services.api.replication.in.IRequestProcessorService
import com.exalate.replication.services.replication.worker.messages.RequestWorkerMessages
import com.google.inject.Inject
import play.api.Logger

import scala.concurrent.ExecutionContextExecutor
import scala.util.{Failure, Success}

/** @see
  *   http://doc.akka.io/docs/akka/snapshot/scala/actors.html
  *
  * How do we ensure that we only process the last message? Let's imagine that we receive
  * ProcessRequests (PR) every 5 seconds
  *
  * Let's imagine that when the worker starts processing messages it has the following queue: \|PR |
  * waiting
  * | PR |
  * |:---|
  * | PR |
  *
  * The worker starts in "waiting" and takes the first message, puts the AfterTheLastMessage into
  * the queue and becomes waitingForAfterTheLastMessage: \|PR | waitingForAfterTheLastMessage
  * | PR  |
  * |:----|
  * | ALM |
  *
  * The worker ignores the next message (since he searchesForWork) \|PR |
  * waitingForAfterTheLastMessage
  * | PR  |
  * |:----|
  * | ALM |
  *
  * The worker ignores the next message (since he searchesForWork) \|PR |
  * waitingForAfterTheLastMessage \|ALM |
  *
  * The worker processes the ALM and actually executes the processing logic
  *
  * How do we ensure that we don't accumulate the queue of messages? Let's take the previous example
  * and assume that while Exalate processes each message, it gets one more message to the queue:
  * \|PR| waiting
  * | PR |
  * |:---|
  * | PR |
  *
  * The worker starts in "waiting" and takes the first message, puts the AfterTheLastMessage into
  * the queue and becomes waitingForAfterTheLastMessage: \|PR | waitingForAfterTheLastMessage
  * | PR  |
  * |:----|
  * | ALM |
  * | PR  |
  *
  * The worker ignores the next message (since he searchesForWork) \|PR |
  * waitingForAfterTheLastMessage
  * | PR  |
  * |:----|
  * | ALM |
  * | PR  |
  * | PR  |
  *
  * The worker ignores the next message (since he searchesForWork) \|PR |
  * waitingForAfterTheLastMessage
  * | ALM |
  * |:----|
  * | PR  |
  * | PR  |
  * | PR  |
  *
  * The worker processes the ALM and actually executes the processing logic \|PR |
  * waitingForAfterTheLastMessage
  * | PR |
  * |:---|
  * | PR |
  * | PR |
  *
  * Once that ALM processing future has completed, the worker goes back to waiting: \|PR | waiting
  * | PR |
  * |:---|
  * | PR |
  *
  * And the process continues
  */

object RequestWorkerActor {

  def props(
      requestProcessorService: IRequestProcessorService,
      blobRequestProcessorService: IBlobRequestProcessorService
  ): Props = Props(new RequestWorkerActor(requestProcessorService, blobRequestProcessorService))

}

class RequestWorkerActor @Inject() (
    requestProcessorService: IRequestProcessorService,
    blobRequestProcessorService: IBlobRequestProcessorService
) extends Actor {
  private val LOG: Logger = Logger("application.services.replication.worker.RequestWorkerActor")
  implicit private val ec: ExecutionContextExecutor = context.dispatcher

  import RequestWorkerMessages._

  def receive: Receive = waiting

  private val waiting: Receive = {
    case ProcessRequests =>
      LOG.trace("RequestWorkerActor:waiting:_")
      self ! AfterTheLastMessage
      context.become(waitingForAfterTheLastMessage)
  }

  private def waitingForAfterTheLastMessage: Receive = {
    case AfterTheLastMessage =>
      LOG.trace(
        "RequestWorkerActor:waitingForAfterTheLastMessage AfterTheLastMessage - ProcessBlobRequests"
      )
      blobRequestProcessorService.processBlobRequests() onComplete {
        case Success(_)  =>
          LOG.trace(
            "RequestWorkerActor:waitingForAfterTheLastMessage AfterTheLastMessage - processSyncRequests"
          )
          processSyncRequests()
        case Failure(ex) =>
          LOG.error(
            s"#processBlobRequests failed to process processBlobRequests",
            ex
          )
          processSyncRequests()

      }

    case ProcessRequests =>
      // We avoid processing unnecessary messages, relaying that if we are in this actor state, there is a AfterTheLastMessage on the queue
      LOG.trace("RequestWorkerActor:waitingForAfterTheLastMessage:_")
  }

  private def processSyncRequests(): Unit =
    requestProcessorService
      .processSyncRequests()
      .onComplete {
        case Success(_)         =>
          LOG.trace(
            "RequestWorkerActor:waitingForAfterTheLastMessage AfterTheLastMessage - processSyncRequests - Success"
          )
          context.become(waiting)
        case Failure(exception) =>
          LOG.error(
            "RequestWorkerActor:waitingForAfterTheLastMessage AfterTheLastMessage - processSyncRequests - Failure",
            exception
          )
          context.become(waiting)
      }

}
