package com.exalate.replication.services.replication.worker

import akka.actor._
import akka.pattern.pipe
import com.exalate.api.domain.connection.{IConnection, InvitationStatus}
import com.exalate.api.persistence.relation.IRelationRepository
import com.exalate.domain.transport.message.{ExalateMessage, MessageType}
import com.exalate.domain.values.connection.InvitationValue
import com.exalate.domain.values.v3_4.CreateInvitedConnectionValue
import com.exalate.replication.services.api.config.IConnectionService
import com.exalate.replication.services.api.error.IErrorService
import com.exalate.replication.services.api.message.IExalateMessageService
import com.exalate.replication.services.api.replication.in.IPollSchedulerService
import com.exalate.replication.services.api.replication.oauth.IOAuthService
import com.exalate.replication.services.api.replication.worker.IWorkerNotificationService
import com.exalate.replication.services.transport.v1.rest.IConnectionClient
import com.exalate.replication.services.transport.value.ExaCompFormatters._
import com.exalate.replication.services.utils.ActorLoggingService
import com.exalate.services.utils.FutureUtils
import com.exalate.util.DateUtil
import com.google.inject.Inject
import play.api.Logger
import play.api.libs.json.Json

import scala.concurrent.{ExecutionContext, Future}
import scala.util.Try

object ConnectionEventWorkerActor {
  private[worker] case object AfterTheLastMessage
  private[worker] case object AfterTheLastMessageResult
}

class ConnectionEventWorkerActor @Inject() (
    connectionService: IConnectionService,
    connectionRepository: IRelationRepository,
    errorService: IErrorService,
    workerNotificationService: IWorkerNotificationService,
    pollSchedulerService: IPollSchedulerService,
    exalateMessageService: IExalateMessageService,
    oauthService: IOAuthService,
    actorLoggingService: ActorLoggingService,
    connectionClient: IConnectionClient
)(implicit ec: ExecutionContext)
    extends Actor
      with Stash {
  val LOG: Logger = Logger("application.services.replication.worker.ConnectionEventWorkerActor")

  import ConnectionEventWorkerActor._

  // worker starts in waiting state
  def receive: Receive = waiting

  /** Method handles one of the 4 messages at once, scheduled to the actor:
    *   1. ReviewInvitationStatus - sends to it self new message AfterTheLastMessage and switching
    *      to {@link waitingForAfterTheLastMessage} 2. ConnectionInitiated - performs necessary jobs
    *      when a connection is initiated 3. ConnectionAccepted 4. ConnectionUpdated and default,
    *      which is non of the above mentioned, the default one is just for logging.
    *
    * 'orElse' makes sure that we do not skip non of the pre-defined (one of the 4 above mentioned)
    * scheduled jobs.
    */
  private val waiting: Receive = _waiting
    .orElse(connectionInitiatedHandler)
    .orElse(connectionAcceptedHandler)
    .orElse(connectionUpdatedHandler)
    .orElse(defaultHandler("waiting"))

  /** Method handles one of the 4 messages at once, scheduled to the actor:
    *   1. AfterTheLastMessage - performs `resendInvitationAcceptedMessage`,
    *      `pollForAcceptedMessage`, `resendInvitation` and then switching back to {@link waiting}
    *      2. ConnectionInitiated - performs necessary jobs when a connection is initiated 3.
    *      ConnectionAccepted 4. ConnectionUpdated
    */
  def waitingForAfterTheLastMessage: Receive = _waitingForAfterTheLastMessage
    .orElse(connectionInitiatedHandler)
    .orElse(connectionAcceptedHandler)
    .orElse(connectionUpdatedHandler)
    .orElse(defaultHandler("waitingForAfterTheLastMessage"))

  /** Handles one job, which is `ReviewInvitationStatus`. This job is scheduled every 10 secs from
    * {@link WorkerSchedulerService}
    *
    * Important: this method should have only one `case` in order to have proper execution of
    * {@link waiting} method, namely `orElse`
    */
  private def _waiting: Receive = {
    case ReviewInvitationStatus =>
      actorLoggingService.tryWithLoggedBugs {
        LOG.trace("ConnectionEventWorkerActor:ReviewInvitationStatus:_")
        self ! AfterTheLastMessage
        context.become(waitingForAfterTheLastMessage)
      }
  }

  /** Handles one job, which is `AfterTheLastMessage`. This job is obtained from {@link _waiting}
    * after everything performed is returning back to {@link waiting} receiver
    */
  private def _waitingForAfterTheLastMessage: Receive = {
    case AfterTheLastMessage =>
      actorLoggingService.tryWithLoggedBugs {
        LOG.trace("ConnectionEventWorkerActor:waitingForAfterTheLastMessage checking remote status")
        val connectionEventResultFut =
          for {
            _ <- connectionService
              .resendInvitationAcceptedMessage()
              .recover {
                case e =>
                  LOG.error(
                    "#_waitingForAfterTheLastMessage #resendInvitationAcceptedMessage failed",
                    e
                  )
                  None
              }
            _ <- connectionService
              .pollForAcceptedMessage()
              .recover {
                case e =>
                  LOG.error("#_waitingForAfterTheLastMessage #pollForAcceptedMessage failed", e)
                  None
              }
            _ <- resendInvitation()
              .recover {
                case e =>
                  LOG.error("#_waitingForAfterTheLastMessage #resendInvitation failed", e)
                  None
              }
          } yield AfterTheLastMessageResult

        connectionEventResultFut pipeTo self
        context.become(connectionEventResultHandler, discardOld = false)
      }
  }

  /** Stashes all messages until the `AfterTheLastMessageResult` received
    */
  private def connectionEventResultHandler: Receive = {
    case AfterTheLastMessageResult =>
      unstashAll()
      context.become(waiting)
    case _                         => stash()
  }

  /** Handles `ConnectionInitiated` job
    */
  private def connectionInitiatedHandler: Receive = {
    case ConnectionInitiated(connectionId, connectionName, adminUserKeyOpt) =>
      actorLoggingService.tryWithLoggedBugs {
        LOG.trace(
          s"ConnectionEventWorkerActor:waitingForAfterTheLastMessage #ConnectionInitiated($connectionId, $connectionName, $adminUserKeyOpt)"
        )
        FutureUtils.resultInf(for {
          connectionOpt <- connectionRepository.getConnectionFuture(connectionId)
          res <- connectionOpt match {
            case None             =>
              Future.successful(None)
            case Some(connection) =>
              workerNotificationService.fireAllWorkerNotifications()
              if (connection.isVisual) Future.fromTry(resendInvitation(connection, adminUserKeyOpt))
              else Future.successful(None)
          }
        } yield res)
      }
  }

  /** Handles `ConnectionUpdated` job
    */
  private def connectionUpdatedHandler: Receive = {
    case ConnectionUpdated(connectionId, connectionName, connectionDraftValue) =>
      actorLoggingService.tryWithLoggedBugs {
        LOG.trace(
          s"ConnectionEventWorkerActor:waitingForAfterTheLastMessage #ConnectionUpdated($connectionId, $connectionName, $connectionDraftValue)"
        )
        FutureUtils.resultInf(for {
          connectionOpt <- connectionRepository.getConnectionFuture(connectionId)
          result <- connectionOpt match {
            case None             =>
              Future.successful(None)
            case Some(connection) =>
              pollSchedulerService.handlePollScheduleOnUpdate(connection)
              workerNotificationService.fireAllWorkerNotifications()
              connectionDraftValue match {
                case None             => Future.successful(None)
                case Some(draftValue) =>
                  errorService.resolveForConnection(connection.getID)
                  exalateMessageService
                    .send(
                      ExalateMessage(
                        Json.stringify(Json.toJson(draftValue)),
                        MessageType.CONNECTION_DRAFT_REQUEST.toString,
                        connectionId
                      )
                    )
                    .map(_ => None)
              }
          }
        } yield result)
      }
  }

  /** Handles `ConnectionAccepted` job
    */
  private def connectionAcceptedHandler: Receive = {
    case ConnectionAccepted(connectionId, connectionName, adminUserKeyOpt) =>
      actorLoggingService.tryWithLoggedBugs {
        LOG.trace(
          s"ConnectionEventWorkerActor:waitingForAfterTheLastMessage #ConnectionAccepted($connectionId, $connectionName, $adminUserKeyOpt)"
        )
        FutureUtils.resultInf(for {
          connectionOpt <- connectionRepository.getConnectionFuture(connectionId)
          res = connectionOpt match {
            case None    =>
              None
            case Some(_) =>
              workerNotificationService.fireAllWorkerNotifications()
          }
        } yield res)
      }
  }

  private def resendInvitation(): Future[None.type] =
    for {
      pendingCs <- connectionRepository.findConnectionsWithStatus(InvitationStatus.PENDING)
      visualPendingCs = pendingCs.filter(_.isVisual)
      _ = visualPendingCs
        .map(c => resendInvitation(c, None))
    } yield None

  private def resendInvitation(
      connection: IConnection,
      adminUserKeyOpt: Option[String]
  ): Try[None.type] = FutureUtils.toTry {
    val instanceUidOpt = Option(connection.getRemoteInstance)
      .flatMap(i => Option(i.getNodeInfo))
      .flatMap(ni => Option(ni.getInstanceUid))
    instanceUidOpt match {
      case None              =>
        LOG.info(
          s"#sendInvitation: " +
            s"no instance uid for " +
            s"connection `${connection.getName}` at ${DateUtil.dateNowStr()} " +
            s"waiting until the next retry"
        )
        Future.successful(None)
      case Some(instanceUid) =>
        for {
          invitationValue <- connectionService.getInvitationForAccepting(connection)
          t <- adminUserKeyOpt match {
            case Some(adminUserKey) =>
              oauthService.findFirstOAuthDataWithAccessToken(instanceUid, adminUserKey)
            case _                  =>
              oauthService.findFirstValidOAuthDataWithAccessTokenAndRemoveIfRevoked(instanceUid)
          }
          remoteInstanceName = getRemoteInstanceName(connection)
          _ <- t match {
            case None            =>
              LOG.info(
                s"#sendInvitation: " +
                  s"no access token for " +
                  s"connection `${connection.getName}` at ${DateUtil.dateNowStr()} " +
                  s"waiting until the next retry"
              )
              Future.successful(None)
            case Some(oauthData) =>
              sendInvitation(
                connection,
                invitationValue,
                remoteInstanceName,
                oauthData.getAccessToken
              )
          }
        } yield None
    }
  }

  private def sendInvitation(
      connection: IConnection,
      invitationValue: InvitationValue,
      remoteInstanceName: String,
      accessToken: String
  ) = {
    LOG.info(
      s"#sendInvitation: " +
        s"asking the remote instance `$remoteInstanceName` " +
        s"to create a connection `${connection.getName}` at ${DateUtil.dateNowStr()}"
    )
    connectionClient
      .createInvitedConnectionExternalAuth(
        connection,
        CreateInvitedConnectionValue(accessToken, invitationValue)
      )
      .map {
        case true  =>
          // celebrate!
          connectionService
            .updateInvitationStatus(connection.getName, InvitationStatus.ACCEPTED)
            .foreach { _ =>
              LOG.info(
                s"#sendInvitation: updating invitation status for connection `${connection.getName}` " +
                  s"since the remote side `$remoteInstanceName` created the connection " +
                  s"at ${DateUtil.dateNowStr()}"
              )
              workerNotificationService
                .fireStartMessageBatching() // this call is optimizing the message sending -
              // basically, as soon as the connection is accepted, we want to push options from this side to the other side (and the way around)
            }
          None
        case false =>
          // retry
          LOG.info(
            s"#sendInvitation: the remote side didn't create connection`${connection.getName}` " +
              s"sleeping until the next retry " +
              s"at ${DateUtil.dateNowStr()}"
          )
          None
      }
  }

  private def getRemoteInstanceName(connection: IConnection) =
    Option(connection.getRemoteInstance).flatMap(i => Option(i.getName)).getOrElse("")

  private def defaultHandler(state: String): Receive = {
    case _ =>
      actorLoggingService.tryWithLoggedBugs {
        LOG.trace(s"ConnectionEventWorkerActor:$state _")
      }
  }

}
