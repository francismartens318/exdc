package com.exalate.replication.services.replication.request

import com.exalate.api.domain.IPersistentReplica
import com.exalate.api.domain.request.RequestStatus
import com.exalate.api.domain.twintrace.{ITrace, TraceAction}
import com.exalate.api.persistence.replication.request.{
  ICreateOrUpdateTwinTraceSyncRequestStateRepository,
  IRequestReplicationRepository
}
import com.exalate.api.persistence.twintrace.ITwinTraceRepository
import com.exalate.api.persistence.twintrace.ITwinTraceRepository.TwinTraceReplicas
import com.exalate.basic.domain.BasicNonPersistentTrace
import com.exalate.domain.replication.BasicSyncRequest
import com.exalate.error.services.api.IBugExceptionCategoryService
import com.exalate.replication.services.replication.state.IState
import com.exalate.replication.services.utils.TraceUtils
import play.api.Logger

import javax.inject.Inject
import scala.concurrent.{ExecutionContext, Future}

class CreateOrUpdateTwinTraceSyncRequestState @Inject() (
    persistence: IRequestReplicationRepository,
    createOrUpdateTwinTraceRepository: ICreateOrUpdateTwinTraceSyncRequestStateRepository,
    twinTraceRepository: ITwinTraceRepository,
    bugExceptionCategoryService: IBugExceptionCategoryService
)(implicit ec: ExecutionContext)
    extends IState[BasicSyncRequestContext] {

  val LOG = Logger(
    "application.services.replication.request.CreateOrUpdateTwinTraceSyncRequestState"
  )

  /** Performs transition of one of the states of SyncRequestStateMachine: status
    * `CREATE_OR_UPDATE_TWINTRACE`
    *
    * @param context
    * @return
    *   BasicSyncRequestContext
    */
  override def transition(
      context: BasicSyncRequestContext
  ): Future[Option[BasicSyncRequestContext]] = {
    val BasicSyncRequestContext(basicSyncRequest, connection) = context
    basicSyncRequest.remoteTwinTraceId match {
      case Some(remoteTwinTraceId) =>
        val remoteIssueUrn = basicSyncRequest.replica.getIssueKey.getURN
        (for {
          requestTraces <- persistence.findRequestTraces(basicSyncRequest.id)
          twinTraceReplicasAndTracesOpt <- twinTraceRepository
            .getTwinTraceReplicasAndTracesByRemoteTwinTraceId(connection.getID, remoteTwinTraceId)
        } yield (requestTraces, twinTraceReplicasAndTracesOpt)).flatMap {
          case (requestTraces, Some(twinTraceReplicasAndTraces))                =>
            handleNonFirstRequest(basicSyncRequest, requestTraces, twinTraceReplicasAndTraces)
              .map(toUpdatedContext(_, context))
          case (requestTraces, _) if basicSyncRequest.createdIssueKey.isDefined =>
            LOG.info(
              s"#transitioning request `${basicSyncRequest.id}` for remote issue `$remoteIssueUrn`: creating twin trace"
            )
            val nonPersistentTraces = requestTraces.map(t =>
              new BasicNonPersistentTrace().from(t).setAction(TraceAction.NONE)
            )
            createOrUpdateTwinTraceRepository
              .createTwinTraceAndSetRequestStatus(
                basicSyncRequest,
                connection,
                RequestStatus.SEND_RESPONSE,
                nonPersistentTraces
              )
              .map(toUpdatedContext(_, context))
          case _                                                                =>
            LOG.error(
              s"#transitioning request `${basicSyncRequest.id}` for remote issue `$remoteIssueUrn`: could not find neither a local twin trace not `createdIssueKey`."
            )
            Future.successful(None)
        }

      case _ =>
        val errMsg =
          s"A remote twin trace ID is missed in the sync request with id=${basicSyncRequest.id} though it is expected to be present."
        val ex = bugExceptionCategoryService.generateBugException(None, Some(errMsg))
        Future.failed(ex)
    }
  }

  private def toUpdatedContext(
      updatedRequestOpt: Option[BasicSyncRequest],
      context: BasicSyncRequestContext
  ): Option[BasicSyncRequestContext] =
    updatedRequestOpt.map(r => context.copy(request = r))

  private def handleNonFirstRequest(
      request: BasicSyncRequest,
      requestTraces: Seq[ITrace],
      twinTraceReplicasAndTraces: (TwinTraceReplicas, Seq[ITrace])
  ): Future[Option[BasicSyncRequest]] = {
    val requestReplica = request.replica
    val remoteIssueUrn = requestReplica.getIssueKey.getURN
    // We assume that if the request is non a pair request, twin trace will be present
    val twinTraceReplicas = twinTraceReplicasAndTraces._1
    val twinTraceId = twinTraceReplicas.twinId
    val twinTraceRemoteReplica = twinTraceReplicas.remoteReplica
    val twinTraceTraces = twinTraceReplicasAndTraces._2
    val tracesOpt =
      if (TraceUtils.seqEqualsIgnoreOrder(twinTraceTraces, requestTraces)) None
      else
        Some(
          requestTraces.map(t => new BasicNonPersistentTrace().from(t).setAction(TraceAction.NONE))
        )
    // Requests for unexalated unidirectional twin trace should never get here, because the twin trace is created on UNEXALATED state and never changes its status
    LOG.info(
      s"#transitioning request `${request.id}` for remote issue `$remoteIssueUrn`: updating the twin trace $twinTraceId"
    )
    val remoteReplicaParameter = getLatestReplicaOpt(twinTraceRemoteReplica, requestReplica)
    createOrUpdateTwinTraceRepository.updateTwinTraceAndSetRequestStatus(
      twinTraceReplicas,
      request,
      RequestStatus.SEND_RESPONSE,
      remoteReplicaParameter,
      tracesOpt
    )
  }

  private def getLatestReplicaOpt(
      previousRemoteReplica: Option[IPersistentReplica],
      remoteReplica: IPersistentReplica
  ): Option[IPersistentReplica] =
    previousRemoteReplica match {
      // We will only update the remote replica if
      // The new remote replica is newer (based on valid on time) than the current one
      case Some(r) =>
        Some(remoteReplica).filter(remoteR =>
          r.getValidOn.getTimeMillis < remoteR.getValidOn.getTimeMillis
        )
      // Or there is no remote replica on the twin trace
      case None    => Some(remoteReplica)
    }

}
