package com.exalate.replication.services.replication.event

import com.exalate.api.domain.event.EventStatus._
import com.exalate.api.domain.event.ISyncEvent
import com.exalate.api.exception.bug.BugException
import com.exalate.replication.services.replication.state.IState
import play.api.Logger

import javax.inject.Inject

class SyncEventStateMachine @Inject() (
    readyEventState: ReadySyncEventState,
    storeBlobEventState: StoreBlobSyncEventState,
    sendSyncRequestEventState: SendSyncRequestEventState,
    notifyResponseReceivedSyncEventState: NotifyResponseReceivedSyncEventState,
    responseReadyEventState: ResponseReadyEventState,
    errorResponseReadyEventState: ErrorResponseReadyEventState,
    updateTwinTraceSyncEventState: UpdateTwinTraceSyncEventState,
    sendBlobsEventState: SendBlobsEventState,
    addLinkSyncEventState: AddLinkSyncEventState,
    removeLinkSyncEventState: RemoveLinkSyncEventState,
    deleteTwinTraceSyncEventState: DeleteTwinTraceSyncEventState
) {

  private val LOG = Logger(classOf[SyncEventStateMachine])

  /** Gets state of Sync Event execution. One of the state for the following statuses: READY,
    * STORE_BLOB, SEND_REQUEST, SEND_BLOBS, WAITING_REQUEST_RECEIVED, WAITING_FOR_RESPONSE,
    * NOTIFY_RESPONSE_RECEIVED, RESPONSE_READY, ERROR_RESPONSE_READY, ADD_LINK, REMOVE_LINK,
    * UPDATE_TWINTRACE, DELETE_TWINTRACE, PROCESSED
    *
    * @param syncEvent
    * @return
    */
  def getState(syncEvent: ISyncEvent): IState[ISyncEvent] =
    syncEvent.getStatus match {
      case READY                    => readyEventState
      case STORE_BLOB               => storeBlobEventState
      case SEND_REQUEST             => sendSyncRequestEventState
      case NOTIFY_RESPONSE_RECEIVED => notifyResponseReceivedSyncEventState
      case RESPONSE_READY           => responseReadyEventState
      case ERROR_RESPONSE_READY     => errorResponseReadyEventState
      case UPDATE_TWINTRACE         => updateTwinTraceSyncEventState
      case SEND_BLOBS               => sendBlobsEventState
      case ADD_LINK                 => addLinkSyncEventState
      case REMOVE_LINK              => removeLinkSyncEventState
      case DELETE_TWINTRACE         => deleteTwinTraceSyncEventState
      case WAITING_FOR_RESPONSE | PROCESSED | ASSIGN_NUMBER | WAITING_REQUEST_RECEIVED =>
        LOG.error("Got to an event state that is not supported.")
        throw new BugException("Got to an event state that is not supported.")
    }

}
