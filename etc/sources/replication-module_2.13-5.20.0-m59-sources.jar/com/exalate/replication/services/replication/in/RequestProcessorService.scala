package com.exalate.replication.services.replication.in

import cats.Parallel
import cats.data.EitherT
import cats.data.EitherT.{cond, leftT, liftF, rightT}
import cats.implicits.catsSyntaxApplicativeError
import cats.instances.future._
import cats.syntax.foldable._
import cats.syntax.parallel._
import cats.syntax.traverse._
import com.exalate.api.domain.connection.{ConnectionStatus, IConnection, InvitationStatus}
import com.exalate.api.domain.request.RequestStatus
import com.exalate.api.domain.twintrace.{TwinTraceStatus, TwinType}
import com.exalate.api.domain.{ErrorReason, IIssueKey, SyncRequestEventType}
import com.exalate.api.exception.CategorizedException
import com.exalate.api.persistence.replication.request.IRequestReplicationRepository
import com.exalate.api.persistence.twintrace.ITwinTraceRepository
import com.exalate.api.persistence.twintrace.ITwinTraceRepository.RequestTwinTraceData
import com.exalate.domain.replication.BasicSyncRequest
import com.exalate.error.services.api.IBugExceptionCategoryService
import com.exalate.replication.services.api.config.IConnectionService
import com.exalate.replication.services.api.error._
import com.exalate.replication.services.api.node.lifecycle.ILifecycleInfoService
import com.exalate.replication.services.api.replication.ICleanUpService
import com.exalate.replication.services.api.replication.in.IRequestProcessorService
import com.exalate.replication.services.replication.{KeepProcess, ShouldProcess, StopProcess}
import com.exalate.replication.services.replication.request.{
  BasicSyncRequestContext,
  SyncRequestStateMachine
}
import com.exalate.services.utils.CollectionService
import play.api.Logger

import javax.inject.Inject
import scala.concurrent.{ExecutionContext, Future}

class RequestProcessorService @Inject() (
    syncRequestStateMachine: SyncRequestStateMachine,
    requestReplicationRepository: IRequestReplicationRepository,
    errorHandler: IErrorHandler,
    twinTraceRepository: ITwinTraceRepository,
    errorService: IErrorService,
    lifecycleInfoService: ILifecycleInfoService,
    cleanupService: ICleanUpService,
    bugExceptionCategoryService: IBugExceptionCategoryService,
    connectionService: IConnectionService
)(implicit ec: ExecutionContext)
    extends IRequestProcessorService {

  implicit private val parFuture: Parallel[Future] = Parallel.identity[Future]

  private val LOG = Logger("application.services.replication.request.RequestProcessorService")

  override def processSyncRequests(): Future[Unit] =
    for {
      _ <-
        if (lifecycleInfoService.isExpired) errorService.ensureExpiredError()
        else Future.successful(None)
      twinTraceIds <- requestReplicationRepository.findRemoteTwinTraceIds()
      twinTraceIdsGroup = CollectionService.splitIntoNGroups(twinTraceIds, 4)
      _ <- twinTraceIdsGroup
        .parTraverse {
          _.traverse {
            case (connectionId, remoteTwinTraceId) =>
              for {
                _ <- cleanUpOutOfBandRequests(connectionId, remoteTwinTraceId)
                basicSyncRequests <- requestReplicationRepository
                  .findBasicSyncRequestsForRemoteTwinTraceId(connectionId, remoteTwinTraceId)
                _ <- basicSyncRequests
                  .groupBy(_.connectionId)
                  .toList
                  .traverse_ {
                    case (connectionId: Int, requestsByConnection: Seq[BasicSyncRequest]) =>
                      connectionService.get(connectionId).flatMap {
                        case Some(connection) =>
                          requestsByConnection.find(BasicSyncRequest.isCleanupRequest) match {
                            case Some(cleanupRequest) =>
                              val syncContextStr = getSyncContextMessage(
                                connection.getName,
                                Some(cleanupRequest)
                              )
                              LOG.trace(s"Found clean up sync request $syncContextStr")
                              processSyncRequestsForIssue(connection, List(cleanupRequest))
                            case None                 =>
                              val syncContextStr = getSyncContextMessage(
                                connection.getName,
                                requestsByConnection.headOption
                              )
                              LOG.trace(
                                s"Found ${requestsByConnection.size} sync requests $syncContextStr"
                              )
                              processSyncRequestsForIssue(connection, requestsByConnection.toList)
                          }
                        case None             =>
                          LOG.warn(s"Could not find a connection by ID=$connectionId while processing sync requests.")
                          Future.successful(())
                      }
                  }
              } yield ()
          }
        }
    } yield ()

  private def cleanUpOutOfBandRequests(connectionId: Int, remoteTwinTraceId: Int) =
    requestReplicationRepository
      .findOutOfBandRequestsForRemoteTwinTraceId(connectionId, remoteTwinTraceId)
      .flatMap(_.traverse(cleanupService.handleProcessedRequest))

  private def getSyncContextMessage(
      connectionName: String,
      basicSyncRequest: Option[BasicSyncRequest]
  ): String =
    basicSyncRequest
      .map { sr =>
        val issueStr = sr.replica.getIssueKey.getURN
        s" for remote issue `$issueStr` for connection `$connectionName`"
      }
      .getOrElse("")

  private def processSyncRequestsForIssue(
      connection: IConnection,
      requests: List[BasicSyncRequest]
  ): Future[Unit] = {

    def loop(
        requests: List[BasicSyncRequest],
        shouldProcess: ShouldProcess
    ): Future[ShouldProcess] =
      requests match {
        case Nil          => Future.successful(shouldProcess)
        case head :: tail =>
          if (shouldProcess == KeepProcess) {
            processSyncRequest(connection, head).flatMap { updatedAcc =>
              loop(tail, updatedAcc)
            }
          } else {
            Future.successful(shouldProcess)
          }
      }

    loop(requests, KeepProcess).map(_ => ())
  }

  private def getNextEventNumberToProcess(
      requestTwinTraceData: Option[RequestTwinTraceData]
  ): Long =
    requestTwinTraceData.map(_.lastProcessedRemoteEventNumber + 1).getOrElse(1L)

  private def canBeProcessed(
      connectionName: String,
      basicSyncRequest: BasicSyncRequest,
      requestTwinTraceData: Option[RequestTwinTraceData]
  ): Boolean =
    if (BasicSyncRequest.isCleanupRequest(basicSyncRequest)) {
      true
    } else {
      requestTwinTraceData match {
        case Some(RequestTwinTraceData(_, twinType, twinStatus, _, _)) =>
          val isChild: Boolean = TwinType.CHILD.equals(twinType)
          val isInitial: Boolean = TwinTraceStatus.INITIAL.equals(twinStatus)
          val canBeProcessed = isChild || !isInitial
          if (!canBeProcessed) {
            val remoteIssueKey: IIssueKey = basicSyncRequest.replica.getIssueKey
            LOG.info(
              "The sync request for the remote event `" + basicSyncRequest.remoteSyncEventId + "` " + "for issue `" + basicSyncRequest.syncedTo + "` " + "and remote issue `" + remoteIssueKey.getURN + "` " + "and connection `" + connectionName + "` " + "can not be processed because the local twin trace isChild = false and `isInitial` = `" + isInitial + "`"
            )
          }
          canBeProcessed

        case None => true
      }
    }

  private def processSyncRequest(
      connection: IConnection,
      basicSyncRequest: BasicSyncRequest
  ): Future[ShouldProcess] = {

    val syncRequestProcessResult = for {
      isPresent <- liftF(requestReplicationRepository.isPresent(basicSyncRequest.id))
      _ <- cond[Future](isPresent, (), StopProcess)

      connectionName = connection.getName
      remoteIssueKey = basicSyncRequest.replica.getIssueKey
      remoteIssueUrn = remoteIssueKey.getURN
      remoteEventId = basicSyncRequest.remoteSyncEventId

      _ = LOG.trace(
        s"Attempting to process sync request '${basicSyncRequest.id}' of type `${basicSyncRequest.syncType}`, number '${basicSyncRequest.remoteSyncEventNumber}' on status '${basicSyncRequest.status}' for the remote event `$remoteEventId` for connection '$connectionName' and remote issue '$remoteIssueUrn'"
      )

      twinTraceData <- liftF(
        twinTraceRepository.getRequestTwinTraceDataByRemoteTwinTraceId(
          basicSyncRequest.connectionId,
          basicSyncRequest.remoteTwinTraceId.get
        )
      )

      isReadyForProcessing = canBeProcessed(connectionName, basicSyncRequest, twinTraceData)
      _ <- cond[Future](isReadyForProcessing, (), StopProcess)

      v <- liftF(shouldProcess(basicSyncRequest, twinTraceData, connectionName))
      _ <- cond[Future](v._2, (), StopProcess)

      processedRequest <- processRequest(v._1, connection)
      _ <-
        if (processedRequest.status == RequestStatus.PROCESSED) {
          cleanupService
            .handleProcessedRequest(processedRequest)
            .attemptT
            .map(_ => ())
            .leftMap { e =>
              LOG.error(s"Error while handling processed request ${processedRequest.id}", e)
              StopProcess
            }
        } else {
          rightT[Future, StopProcess.type](())
        }
    } yield KeepProcess

    syncRequestProcessResult.value
      .map {
        case Left(_)  => StopProcess
        case Right(_) => KeepProcess
      }
      .recoverWith {
        case CategorizedExceptionWithContext(context, e) =>
          logErrorContext(basicSyncRequest, connection.getName, e)
          errorHandler
            .handleError(e, context)
            .map(_ => StopProcess)
        case e: CategorizedException                     =>
          logErrorContext(basicSyncRequest, connection.getName, e)
          for {
            localIssueKey <- getLocalIssueKey(basicSyncRequest, connection)
            context = SyncContext(
              connection = Option(connection),
              localIssueKeyOpt = localIssueKey,
              remoteIssueKeyOpt = Option(basicSyncRequest.replica.getIssueKey)
            )
            _ <- errorHandler.handleError(e, context)
          } yield StopProcess
        case exception: Exception                        =>
          logErrorContext(basicSyncRequest, connection.getName, exception)
          for {
            localIssueKey <- getLocalIssueKey(basicSyncRequest, connection)
            context = SyncContext(
              connection = Some(connection),
              localIssueKeyOpt = localIssueKey,
              remoteIssueKeyOpt = Some(basicSyncRequest.replica.getIssueKey)
            )
            bugException = bugExceptionCategoryService.generateBugException(Some(exception), None)
            _ <- errorHandler.handleError(bugException, context)
          } yield StopProcess
      }
  }

  private def shouldProcess(
      basicSyncRequest: BasicSyncRequest,
      twinTraceData: Option[RequestTwinTraceData],
      connectionName: String
  ): Future[(BasicSyncRequest, Boolean)] = {
    val toProcess = basicSyncRequest
    val nextEventNumberToProcess = getNextEventNumberToProcess(twinTraceData)
    val remoteEventNumber = toProcess.remoteSyncEventNumber

    if (
      BasicSyncRequest.isCleanupRequest(
        toProcess
      ) || toProcess.status == RequestStatus.PROCESSED
    ) {
      Future.successful(toProcess, true)
    } else if (remoteEventNumber < nextEventNumberToProcess) {
      requestReplicationRepository
        .updateRequestWhenError(
          toProcess.id,
          RequestStatus.SEND_ERROR_RESPONSE,
          s"Request with remote event number $remoteEventNumber for remote twin trace ${toProcess.remoteTwinTraceId
              .getOrElse("NO ID")} was already processed",
          ErrorReason.OUT_OF_BAND_REQUEST
        )
        .map {
          case Some(value) => value
          case None        =>
            LOG.warn(
              s"Could not update request with remote event number $remoteEventNumber for remote twin trace ${toProcess.remoteTwinTraceId
                  .getOrElse("NO ID")} to status SEND_ERROR_RESPONSE"
            )
            basicSyncRequest
        }
        .map(value => (value, true))
    } else {
      Future.successful(
        toProcess,
        isNextRequest(toProcess, nextEventNumberToProcess, twinTraceData.isDefined, connectionName)
      )
    }
  }

  private def processRequest(
      toProcess: BasicSyncRequest,
      connection: IConnection
  ): EitherT[Future, StopProcess.type, BasicSyncRequest] = {

    def loop(toProcess: BasicSyncRequest): EitherT[Future, StopProcess.type, BasicSyncRequest] =
      canProcessingContinue(toProcess, connection).flatMap {
        case StopProcess => rightT(toProcess)
        case KeepProcess =>
          val remoteIssueUrn = toProcess.replica.getIssueKey.getURN
          LOG.info(
            s"Processing request ${toProcess.id} of type `${toProcess.syncType}`, on state ${toProcess.status} for remote event `${toProcess.remoteSyncEventId}` number `${toProcess.remoteSyncEventNumber}` for remote issue urn `$remoteIssueUrn` using connection `${connection.getName}` and remote twin trace id ${toProcess.remoteTwinTraceId}"
          )

          val context = BasicSyncRequestContext(toProcess, connection)

          liftF(
            syncRequestStateMachine
              .getState(context)
              .transition(context)
              .flatMap(r => errorService.deleteTransportErrorsForSyncRequest(toProcess).map(_ => r))
              .recoverWith {
                case e: CategorizedException =>
                  LOG.error(
                    s"CategorizedException occurred during processing request ${toProcess.id} of type `${toProcess.syncType}`, on state ${toProcess.status} for remote event `${toProcess.remoteSyncEventId}` number `${toProcess.remoteSyncEventNumber}` for remote issue urn `$remoteIssueUrn` using connection `${connection.getName}` and remote twin trace id ${toProcess.remoteTwinTraceId}.\n" +
                      s"Details: ${e.getMessage}."
                  )
                  val context = SyncContext.createWithBasicSyncRequest(connection, toProcess)
                  val categorizedWithContext = CategorizedExceptionWithContext(context, e)
                  Future.failed(categorizedWithContext)
                case e: Exception            =>
                  LOG.error(
                    s"Error occurred during processing request ${toProcess.id} of type `${toProcess.syncType}`, on state ${toProcess.status} for remote event `${toProcess.remoteSyncEventId}` number `${toProcess.remoteSyncEventNumber}` for remote issue urn `$remoteIssueUrn` using connection `${connection.getName}` and remote twin trace id ${toProcess.remoteTwinTraceId}.\n" +
                      s"Details: ${e.getMessage}."
                  )
                  val context = SyncContext.createWithBasicSyncRequest(connection, toProcess)
                  val bugException = bugExceptionCategoryService.generateBugException(Some(e), None)
                  val categorizedWithContext = CategorizedExceptionWithContext(context, bugException)
                  Future.failed(categorizedWithContext)
              }
          ).flatMap {
            case Some(updatedContext) => loop(updatedContext.request)
            case None                 => leftT(StopProcess)
          }
      }

    loop(toProcess)
  }

  private def logErrorContext(
      basicSyncRequest: BasicSyncRequest,
      connectionName: String,
      e: Exception
  ): Unit = {
    val remoteIssueUrn = basicSyncRequest.replica.getIssueKey.getURN
    LOG.error(
      s"Exception occurred while processing sync request ID `${basicSyncRequest.id}`, remote event `${basicSyncRequest.remoteSyncEventId}` number `${basicSyncRequest.remoteSyncEventNumber}` for remote issue urn `$remoteIssueUrn`, connection `$connectionName`.",
      e
    )
  }

  private def canProcessingContinue(
      toProcess: BasicSyncRequest,
      connection: IConnection
  ): EitherT[Future, StopProcess.type, ShouldProcess] =
    if (
      toProcess.status != RequestStatus.PROCESSED &&
      toProcess.status != RequestStatus.WAITING_RESPONSE_RECEIVED &&
      toProcess.status != RequestStatus.WAITING_ERROR_RESPONSE_RECEIVED
    ) {

      val connectionName = connection.getName
      val remoteSyncEventId = toProcess.remoteSyncEventId
      val remoteReplica = toProcess.replica
      val remoteIssueKey = remoteReplica.getIssueKey
      val remoteIssueUrn = remoteIssueKey.getURN

      val isInvitationAccepted = InvitationStatus.ACCEPTED == connection.getInvitationStatus
      val isConnectionActive = ConnectionStatus.ACTIVE == connection.getStatus
      val isCleanupRequest = BasicSyncRequest.isCleanupRequest(toProcess)

      if (!isCleanupRequest && !isInvitationAccepted) {
        LOG.warn(
          s"sync request `${toProcess.id}` for remote sync event `$remoteSyncEventId` and remote issue `$remoteIssueUrn` will not be processed because invitation for connection `$connectionName` is not accepted"
        )
      }

      if (!isCleanupRequest && !isConnectionActive) {
        LOG.warn(
          s"sync request `${toProcess.id}` for remote sync event `$remoteSyncEventId` and remote issue `$remoteIssueUrn` will not be processed because connection `$connectionName` is not active"
        )
      }

      liftF(errorService.isOk(toProcess, connection)).map { notBlockedByError =>
        val canContinue = isCleanupRequest ||
          (notBlockedByError &&
            toProcess.status != RequestStatus.RECEIVING_BLOBS &&
            isConnectionActive &&
            isInvitationAccepted)

        if (!isCleanupRequest && !notBlockedByError)
          LOG.trace(
            s"sync request `${toProcess.id}` for remote sync event `$remoteSyncEventId` and remote issue `$remoteIssueUrn` can not be processed since there is a blocking error."
          )

        if (canContinue) KeepProcess else StopProcess
      }
    } else {
      rightT(StopProcess)
    }

  private def isNextRequest(
      toProcess: BasicSyncRequest,
      nextEventNumberToProcess: Long,
      twinTraceExists: Boolean,
      connectionName: String
  ): Boolean = {
    val isCleanupRequest = BasicSyncRequest.isCleanupRequest(toProcess)

    val remoteSyncEventId = toProcess.remoteSyncEventId
    val remoteReplica = toProcess.replica
    val remoteIssueKey = remoteReplica.getIssueKey
    val remoteIssueUrn = remoteIssueKey.getURN
    val remoteIssueId = remoteIssueKey.getIdStr
    val remoteEventNumber = toProcess.remoteSyncEventNumber
    val hasNextEventNumber: Boolean =
      isCleanupRequest || toProcess.status == RequestStatus.PROCESSED || nextEventNumberToProcess
        .equals(remoteEventNumber)
    if (!hasNextEventNumber) {
      LOG.debug(
        s"""#gap: request for the remote issue `$remoteIssueUrn` ($remoteIssueId) under connection `$connectionName` ('${toProcess.connectionId}') for remote event number `$remoteEventNumber` ('$remoteSyncEventId')
            while Exalate still needs to process request for event number `$nextEventNumberToProcess`. Stopping the processing of requests for remote issue `$remoteIssueUrn` ('$remoteIssueId') under connection `$connectionName`"""
      )
      return false
    }

    if (
      Option(toProcess.syncType).contains(
        SyncRequestEventType.UPDATE
      ) && remoteEventNumber == 1 && !twinTraceExists
    ) {
      return false
    }

    true
  }

  /** Tries to get a local issue key from the sync request: first through the get synced to field If
    * not available through the get created issue key field If not available through the get updated
    * replica field
    */
  private def getLocalIssueKey(
      basicSyncRequest: BasicSyncRequest,
      connection: IConnection
  ): Future[Option[IIssueKey]] =
    basicSyncRequest.remoteTwinTraceId match {
      case Some(remoteTwinTraceId) =>
        twinTraceRepository
          .getLocalIssueKeyByRemoteTwinTraceId(connection, remoteTwinTraceId)
          .map(
            _.orElse(basicSyncRequest.createdIssueKey)
              .orElse(basicSyncRequest.updatedReplica.map(_.getIssueKey))
          )
      case _                       => Future.successful(None)
    }

}
