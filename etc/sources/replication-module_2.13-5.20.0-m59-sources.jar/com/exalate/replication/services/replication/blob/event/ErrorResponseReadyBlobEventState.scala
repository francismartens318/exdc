package com.exalate.replication.services.replication.blob.event

import com.exalate.api.domain.blob.event.{BlobEventStatus, IBlobEvent}
import com.exalate.api.domain.event.ISyncEvent
import com.exalate.api.persistence.replication.blobevent.IBlobEventReplicationRepository
import com.exalate.error.services.api.{
  IAvailabilityNetworkExceptionCategoryService,
  IBugExceptionCategoryService
}
import com.exalate.replication.services.api.error.{IErrorService, SyncContext}
import com.exalate.replication.services.api.replication.ISyncEventService
import com.exalate.replication.services.api.replication.worker.IWorkerNotificationService
import com.exalate.replication.services.replication.state.IState
import com.google.inject.Inject

import scala.concurrent.{ExecutionContext, Future}

class ErrorResponseReadyBlobEventState @Inject() (
    persistence: IBlobEventReplicationRepository,
    errorService: IErrorService,
    syncEventService: ISyncEventService,
    workerNotificationService: IWorkerNotificationService,
    networkExceptionCategoryService: IAvailabilityNetworkExceptionCategoryService,
    bugExceptionCategoryService: IBugExceptionCategoryService
)(implicit ec: ExecutionContext)
    extends IState[IBlobEvent] {

  /** Performs transition of one of the states of BlobEventStateMachine: status
    * `BLOB_ERROR_RESPONSE_READY`
    * @param blobEvent
    * @return
    *   IBlobEvent
    */
  override def transition(blobEvent: IBlobEvent): Future[Option[IBlobEvent]] = {
    val syncEvent: ISyncEvent = blobEvent.getSyncEvent
    syncEventService.getRemoteIssueKey(syncEvent).flatMap { remoteIssueKeyOpt =>
      val syncContext =
        SyncContext.createWithBlobEvent(blobEvent).copy(remoteIssueKeyOpt = remoteIssueKeyOpt)
      val exc =
        networkExceptionCategoryService
          .categorizeBlobException(blobEvent)
          .getOrElse(
            bugExceptionCategoryService.generateRestExalateTransportBugException(detailsOpt =
              Option(blobEvent.getErrorResponseMessage)
            )
          )

      errorService
        .createError(exc, syncContext, None)
        .flatMap { _ =>
          blobEvent.setBlobErrorReason(null)
          blobEvent.setErrorResponseMessage(null)
          persistence
            .updateBlobEventStatusAndErrorReasonAndErrorResponseMessage(
              blobEvent,
              BlobEventStatus.READY
            )
            .map { be =>
              workerNotificationService.sendProcessBlobEventsNotification()
              be
            }
        }
    }
  }

}
