package com.exalate.replication.services.replication.event

import com.exalate.api.domain.SyncRequestEventType
import com.exalate.api.domain.event.{EventStatus, ISyncEvent}
import org.apache.commons.lang3.StringUtils

import javax.inject.Inject

class WaitingRequestReceivedService @Inject() () {

  def getNextStatus(syncEvent: ISyncEvent) = {
    val connectContext = Option(syncEvent.getConnectContext)
    if (
      (syncEvent.getSyncType == SyncRequestEventType.CONNECT && !connectContext.forall(
        _.isTriggerUpdate
      )) || isDeleteEvent(syncEvent) || isUnexalateEvent(syncEvent) || noBlobsOnEvent(syncEvent)
    ) {
      EventStatus.WAITING_FOR_RESPONSE
    } else {
      EventStatus.SEND_BLOBS
    }
  }

  private def noBlobsOnEvent(syncEvent: ISyncEvent) = syncEvent.getBlobMetadataList.isEmpty

  private def isConnectEvent(syncEvent: ISyncEvent) =
    StringUtils.isNotEmpty(syncEvent.getConnectRemoteIssueUrn)

  private def isDeleteEvent(syncEvent: ISyncEvent) =
    StringUtils.isNotEmpty(syncEvent.getDeletedIssueUrn)

  private def isUnexalateEvent(syncEvent: ISyncEvent) =
    StringUtils.isNotEmpty(syncEvent.getUnexalateIssueUrn)

}
