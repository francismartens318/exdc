package com.exalate.replication.services.replication.request

import com.exalate.api.domain.connection.IConnection
import com.exalate.domain.replication.BasicSyncRequest

case class BasicSyncRequestContext(request: BasicSyncRequest, connection: IConnection)
