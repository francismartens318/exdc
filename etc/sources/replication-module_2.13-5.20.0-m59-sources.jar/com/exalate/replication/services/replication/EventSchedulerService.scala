package com.exalate.replication.services.replication

import com.exalate.api.domain._
import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.connection.fieldvalues.ConnectionMode
import com.exalate.api.domain.editor.error.EditorErrorSide
import com.exalate.api.domain.event.{EventStatus, ISyncEvent}
import com.exalate.api.domain.hubobject.v1_9.IHubIssue
import com.exalate.api.domain.hubobject.{EntityType, IHubIssueReplica, IHubPayload}
import com.exalate.api.domain.twintrace._
import com.exalate.api.exception.CategorizedException
import com.exalate.api.exception.bug.BugException
import com.exalate.api.hubobject.v1.IHubIssueProcessorPreparationService
import com.exalate.api.persistence.relation.IRelationRepository
import com.exalate.api.persistence.replication.event.IEventScheduleRepository
import com.exalate.api.persistence.scopes.IScopesRepository
import com.exalate.api.persistence.twintrace.ITwinTraceRepository
import com.exalate.basic.domain.BasicIssueKey
import com.exalate.basic.domain.hubobject.v1.BasicHubIssue
import com.exalate.domain.twintrace.TwinTraceCreateParams
import com.exalate.error.services.api.IBugExceptionCategoryService
import com.exalate.generic.services.api.ITrackerHubObjectService
import com.exalate.replication.services.api.error.{IErrorHandler, IErrorService, SyncContext}
import com.exalate.replication.services.api.hubobject.{IConnectTracesService, IReplicaHelper}
import com.exalate.replication.services.api.processor.ICreateReplicaProcessor
import com.exalate.replication.services.api.replication.IEventSchedulerService
import com.exalate.replication.services.api.replication.scope.IScopeQueryService
import com.exalate.replication.services.api.replication.worker.IWorkerNotificationService
import com.exalate.replication.services.script.ScriptGeneratorService
import com.google.common.collect.Maps
import javax.inject.Inject
import play.api.Logger

import scala.collection.JavaConverters
import scala.concurrent.{ExecutionContext, Future}
import scala.util.Try

class EventSchedulerService @Inject() (
    replicaHelper: IReplicaHelper,
    persistence: IEventScheduleRepository,
    relationRepository: IRelationRepository,
    twinTraceRepository: ITwinTraceRepository,
    workerNotificationService: IWorkerNotificationService,
    errorHandler: IErrorHandler,
    trackerHubObjectService: ITrackerHubObjectService,
    createReplicaProcessor: ICreateReplicaProcessor,
    cleanUpService: CleanUpService,
    hubIssueProcessorPreparationService: IHubIssueProcessorPreparationService,
    connectTracesService: IConnectTracesService,
    bugExceptionCategoryService: IBugExceptionCategoryService,
    scopeQueryService: IScopeQueryService,
    scopesRepository: IScopesRepository,
    errorService: IErrorService
)(implicit ec: ExecutionContext)
    extends IEventSchedulerService {

  val LOG = Logger("application.services.replication.event.EventSchedulerService")

  /** The method covers the usecase when the bulk exalate button would also initiate sync for
    * entities, which are already synced. For instance, an admin changes the data filter and wants
    * all the existing syncs to be triggered.
    */
  override def schedulePairOrSyncEvent(
      connection: IConnection,
      issueKey: IIssueKey,
      payload: IHubPayload,
      twinTraceOpt: Option[ITwinTrace]
  ): Future[Option[ISyncEvent]] =
    twinTraceOpt match {
      case Some(twinTrace) =>
        scheduleSyncEventForIssueAndTwinTrace(issueKey, payload, twinTrace)
          .recover {
            val context =
              SyncContext(connection = Some(connection), localIssueKeyOpt = Some(issueKey))
            val actType = Some(ErrorActType.SYNC)
            recoverScheduling(context, actType)
          }
      case None            =>
        scheduleExalateEvent(connection, issueKey, payload, twinTraceOpt)
    }

  /** Schedule Exalate Event (sync event): checks whether exits sync request for local issue, if not
    * creates Replica and Schedule Pair Event
    * @param connection
    * @param issueKey
    * @param payload
    * @param twinTraceOpt
    * @return
    *   ISyncEvent
    */
  override def scheduleExalateEvent(
      connection: IConnection,
      issueKey: IIssueKey,
      payload: IHubPayload,
      twinTraceOpt: Option[ITwinTrace]
  ): Future[Option[ISyncEvent]] =
    twinTraceOpt match {
      case None    =>
        persistence
          .syncRequestForLocalIssueExists(issueKey.getIdStr, connection, issueKey.getEntityType)
          .flatMap { exists =>
            if (exists) {
              LOG.warn(
                s"Could not schedule pair event for ${issueKey.getEntityType}  `" + issueKey.getURN + "` because there is a sync request being processed for that issue."
              )
              Future.successful(None)
            } else createReplicaAndSchedulePairEvent(connection, issueKey, payload)
          }
          .recover {
            val context =
              SyncContext(connection = Some(connection), localIssueKeyOpt = Some(issueKey))
            val actType = Some(ErrorActType.PAIR)
            recoverScheduling(context, actType)
          }
      case Some(_) =>
        LOG.trace(
          s"Exalate event for ${issueKey.getEntityType}  $issueKey  with connection ${connection.getName} won't be scheduled because ${issueKey.getEntityType}  is already under sync"
        )
        Future.successful(None)

    }

  /** Schedule update event: schedule Sync Event for Issue And TwinTrace
    * @param connection
    * @param issueKey
    * @param payload
    * @param twinTraceOpt
    * @return
    *   sync event
    */
  override def scheduleUpdateEvent(
      connection: IConnection,
      issueKey: IIssueKey,
      payload: IHubPayload,
      twinTraceOpt: Option[ITwinTrace]
  ): Future[Option[ISyncEvent]] =
    twinTraceOpt match {
      case Some(twinTrace) =>
        scheduleSyncEventForIssueAndTwinTrace(issueKey, payload, twinTrace)
          .recover {
            val context =
              SyncContext(connection = Some(connection), localIssueKeyOpt = Some(issueKey))
            val actType = Some(ErrorActType.SYNC)
            recoverScheduling(context, actType)
          }
      case None            =>
        LOG.debug(
          s"#scheduleUpdateEvent NOT scheduling sync for ${issueKey.getEntityType} ${issueKey.getIdStr} (${issueKey.getURN})"
        )
        Future.successful(None)
    }

  /** Creates Replica based on the provided data and Schedule Pair Event
    * @param connection
    * @param issueKey
    * @param payload
    * @return
    *   sync event
    */
  private def createReplicaAndSchedulePairEvent(
      connection: IConnection,
      issueKey: IIssueKey,
      payload: IHubPayload
  ): Future[Option[ISyncEvent]] =
    getTwinTraceCreateParams(connection, payload.getHubIssue)
      .flatMap { ttParams =>
        createReplicaProcessor
          .createHubReplica(connection, payload, issueKey, None)
          .flatMap { nonPersistentReplica =>
            val emptyHubIssue = new BasicHubIssue
            val generatedHubIssue = nonPersistentReplica.getPayload.getHubIssue
            if (emptyHubIssue.equals(generatedHubIssue)) {
              LOG.warn(s"Sync event for ${issueKey.getEntityType} ${issueKey.getURN} was not scheduled as the replica was not touched on outgoing script")
              Future.successful(None)
            } else {
              schedulePairEvent(nonPersistentReplica, connection, ttParams)
                .flatMap { r =>
                  errorService.deleteSchedulingErrors(connection, Some(issueKey)).map(_ => r)
                }
            }
          }
      }

  /** Schedule Connect Event
    * @param connection
    * @param issueKey
    * @param fullIssuePayload
    * @param connectRemoteIssueUrn
    * @param connectContextOpt
    * @return
    *   sync event
    */
  override def scheduleConnectEvent(
      connection: IConnection,
      issueKey: IIssueKey,
      fullIssuePayload: IHubPayload,
      connectRemoteIssueUrn: String,
      connectContextOpt: Option[INonPersistentConnectContext]
  ): Future[Option[ISyncEvent]] =
    twinTraceRepository
      .getTwinTraceByLocalIssueKeyFuture(connection, issueKey)
      .flatMap {
        case Some(tt)
            if Option(tt.getRemoteReplica)
              .flatMap(r => Option(r.getIssueKey))
              .flatMap(k => Option(k.getURN))
              .contains(connectRemoteIssueUrn) =>
          Future.successful(None)
        case _ =>
          persistence
            .syncRequestForLocalIssueExists(issueKey.getIdStr, connection, issueKey.getEntityType)
            .flatMap { exists =>
              if (exists) {
                LOG.warn(
                  "Could not schedule connect event for ${issueKey.getEntityType} `" + issueKey.getURN + "` because there is a sync request being processed for that issue."
                )
                Future.successful(None)
              } else
                createReplicaProcessor
                  .createHubReplica(connection, fullIssuePayload, issueKey, None)
                  .flatMap { npReplica =>
                    val emptyHubIssue = new BasicHubIssue
                    val generatedHubIssue = npReplica.getPayload.getHubIssue
                    if (emptyHubIssue.equals(generatedHubIssue)) {
                      LOG.warn(s"Sync event for ${issueKey.getEntityType} ${issueKey.getURN} was not scheduled as the replica was not touched on outgoing script")
                      Future.successful(None)
                    } else {
                      val connectTraces = connectTracesService.getConnectTraces(
                        fullIssuePayload.getHubIssue,
                        connectContextOpt,
                        connection
                      )
                      for {
                        ttParams <- getTwinTraceCreateParams(connection, generatedHubIssue)
                        event <- persistence.persistConnectEvent(
                          connection,
                          npReplica,
                          connectRemoteIssueUrn,
                          connectContextOpt,
                          connectTraces,
                          ttParams
                        )
                        _ = workerNotificationService.sendProcessEventsNotification()
                      } yield event
                    }
                  }
            }
      }
      .flatMap(r => errorService.deleteSchedulingErrors(connection, Some(issueKey)).map(_ => r))
      .recover {
        val context = SyncContext(connection = Some(connection), localIssueKeyOpt = Some(issueKey))
        val actType = Some(ErrorActType.CONNECT)
        recoverScheduling(context, actType)
      }

  /** schedule Sync Event for provided Issue and TwinTrace
    * @param issueKey
    * @param payload
    * @param twinTrace
    * @return
    *   sync event
    */
  private def scheduleSyncEventForIssueAndTwinTrace(
      issueKey: IIssueKey,
      payload: IHubPayload,
      twinTrace: ITwinTrace
  ): Future[Option[ISyncEvent]] = {
    val connection = twinTrace.getConnection
    if (twinTrace.getStatus == TwinTraceStatus.UNEXALATED) {
      LOG.warn(
        "Could not schedule sync event for twin trace `" + twinTrace.getId + "` because its status is 'UNEXALATED'"
      )
      Future.successful(None)
    } else if (twinTrace.getStatus == TwinTraceStatus.REMOTE_ISSUE_DELETED) {
      LOG.warn(
        "Could not schedule sync event for twin trace `" + twinTrace.getId + "` because its status is 'REMOTE_ISSUE_DELETED'"
      )
      Future.successful(None)
    } else {
      LOG.debug(
        s"#scheduleSyncEventForIssueAndTwinTrace scheduling sync for ${issueKey.getEntityType} ${issueKey.getIdStr} (${issueKey.getURN}) - preparing to run the outgoing sync script"
      )
      createReplicaProcessor
        .createHubReplica(connection, payload, issueKey, None)
        .flatMap { replicaAfterDataFilter =>
          val emptyHubIssue = new BasicHubIssue
          val generatedHubIssue = replicaAfterDataFilter.getPayload.getHubIssue
          if (emptyHubIssue.equals(generatedHubIssue)) {
            LOG.warn(
              s"Sync event for ${issueKey.getEntityType} ${issueKey.getURN} was not scheduled as the replica was not touched on outgoing script"
            )
            Future.successful(None)
          } else {
            scheduleSyncEvent(replicaAfterDataFilter, twinTrace, connection) match {
              case Some(f) => f.map(r => Some(r))
              case None    =>
                LOG.debug(
                  s"Could not schedule sync event for ${issueKey.getURN} as there were no changes on local replica after running data filter"
                )
                Future.successful(None)
            }
          }
        }
    }
  }

  /** Schedule Pair Event: creates replica and TwinTrace and PairEvent, then sends Process Events
    * Notification
    * @param nonPersistentReplica
    * @param connection
    * @param ttParams
    * @return
    *   sync event
    */
  private def schedulePairEvent(
      nonPersistentReplica: INonPersistentReplica,
      connection: IConnection,
      ttParams: Option[TwinTraceCreateParams]
  ): Future[Option[ISyncEvent]] =
    persistence
      .createReplicaAndTwinTraceAndPairEvent(connection, nonPersistentReplica, ttParams)
      .map(_.map { pairEvent =>
        val syncEventId = pairEvent.getId
        val localReplica = pairEvent.getLocalReplica
        val issueKey = localReplica.getIssueKey
        val issueUrn = issueKey.getURN
        val connectionName = connection.getName
        LOG.info(
          s"#schedulePairEvent: created the pair syncEvent `$syncEventId` for the ${issueKey.getEntityType} `$issueUrn` and connection `$connectionName`"
        )
        workerNotificationService.sendProcessEventsNotification()
        pairEvent
      })

  /** Gets Twin Trace Create Params which distinguish whether apply scopes of the local side or
    * remote
    * @param connection
    * @param hubIssueReplica
    * @return
    *   value use Remote Scope: true or false
    */
  private def getTwinTraceCreateParams(
      connection: IConnection,
      hubIssueReplica: IHubIssueReplica
  ): Future[Option[TwinTraceCreateParams]] = {
    lazy val hasProperConnectionMode =
      Option(connection.getMode).contains(ConnectionMode.CONFIGURE_BOTH_SIDES.toString)
    val ttParams =
      if (
        connection.isLocal && hasProperConnectionMode && hubIssueReplica.isInstanceOf[BasicHubIssue]
      ) {
        val hubIssue = hubIssueReplica.asInstanceOf[BasicHubIssue]
        scopesRepository
          .getByConnectionId(connection.getID)
          .map(scopes =>
            scopes.foldLeft(Option.empty[Boolean]) {
              case (r @ Some(_), _) => r
              case (None, scope)    =>
                val scopeUidOpt = Option(hubIssue.get(ScriptGeneratorService.EXALATE_SCOPE_UID))
                val scopeSideOpt = Option(hubIssue.get(ScriptGeneratorService.EXALATE_SCOPE_SIDE))
                (scopeUidOpt, scopeSideOpt) match {
                  case (Some(uid), Some(side)) =>
                    if (uid == scope.local.scopeUid && side == EditorErrorSide.LOCAL.toString)
                      Some(false)
                    else if (uid == scope.remote.scopeUid && side == EditorErrorSide.REMOTE.toString)
                      Some(true)
                    else None
                  case _                       =>
                    // TODO 7682d878-9a6b-11ea-bb37-0242ac130002 (search for other todos with the same UUID) we should not try to backtrack due to which scope was the issue exalated, rather when we call .schedule sync, the Option[TwinTraceCreateParams] should be passed along with the call
                    if (scopeQueryService.matches(hubIssue, scope.local)) Some(false)
                    else if (scopeQueryService.matches(hubIssue, scope.remote)) Some(true)
                    else None
                }
            } match {
              case uRSOpt @ Some(_) =>
                Some(TwinTraceCreateParams(useRemoteScope = uRSOpt))
              case None             =>
                // neither of the scopes matches the issue - bug situation, scopes don't match but we are still scheduling sync?
                val scopeStr = scopes
                  .map(_.prettyPrintStr)
                  .mkString("`,`")
                LOG.error(
                  "",
                  new BugException(
                    s"neither of the scopes `$scopeStr` matches the ${hubIssue.getEntityName} `${hubIssue.getKey}` but for some reason, we are still scheduling sync for it. Exalate didn't infer the side for local sync"
                  )
                )
                None
            }
          )
      } else Future.successful(None)
    ttParams
  }

  /** schedule Sync Event
    *
    * @param replicaAfterDataFilter
    * @param twinTrace
    * @param connection
    * @return
    */
  private def scheduleSyncEvent(
      replicaAfterDataFilter: INonPersistentReplica,
      twinTrace: ITwinTrace,
      connection: IConnection
  ): Option[Future[ISyncEvent]] =
    // We relay on the fact that a Unexalated twin trace will no arrive to this point to the local replica will be present
    Some(twinTrace.getLocalReplica)
      .filter { currentLocalReplica =>
        replicaHelper.hasChanges(currentLocalReplica, replicaAfterDataFilter)
      }
      .map { _ =>
        prepareTraces(replicaAfterDataFilter, twinTrace, connection)
      }
      .map { preparedTraces =>
        scheduleSyncEvent(replicaAfterDataFilter, twinTrace, preparedTraces)
      }

  /** prepares traces: gets old issue and new one and infer and Set Local Trace Actions
    * @param nonPersistentReplica
    * @param twinTrace
    * @param connection
    * @return
    *   prepared Trace List
    */
  def prepareTraces(
      nonPersistentReplica: INonPersistentReplica,
      twinTrace: ITwinTrace,
      connection: IConnection
  ): Seq[INonPersistentTrace] = {
    val oldIssueOpt = Option(twinTrace.getLocalReplica)
      .flatMap(r => Try(replicaHelper.toNonPersistentReplica(r)).toOption)
      .map(_.getPayload.getHubIssue.asInstanceOf[IHubIssue])

    if (oldIssueOpt.isEmpty) {
      LOG.warn(
        s"Problems getting the current local replica payload so an empty one will be used, the entity key is ${nonPersistentReplica.getIssueKey}"
      )
    }
    val oldHubIssue: IHubIssue = oldIssueOpt.getOrElse(new BasicHubIssue)
    val newHubIssue: IHubIssue = nonPersistentReplica.getPayload.getHubIssue.asInstanceOf[IHubIssue]
    val traceList = twinTrace.getAllFieldTraces
    // TODO: maybe we can do this in parallel - prepare traces and get the blob metadata list
    // to do that, we may just wrap the traces preparation in a future
    // have another future of the blob metadata running after it
    // then we sequence them together, and voila! Parallel execution
    val preparedTraceList = hubIssueProcessorPreparationService.inferAndSetLocalTraceActions(
      traceList,
      oldHubIssue,
      newHubIssue
    )
    val preparedTraces = JavaConverters.asScalaBufferConverter(preparedTraceList).asScala.toList

    preparedTraces
  }

  /** Schedule Sync Event: creates replica and Sync Event then update TwinTrace and sends
    * ProcessEventsNotification
    * @param nonPersistentReplica
    * @param twinTrace
    * @param preparedTraces
    * @return
    *   sync event
    */
  private def scheduleSyncEvent(
      nonPersistentReplica: INonPersistentReplica,
      twinTrace: ITwinTrace,
      preparedTraces: Seq[INonPersistentTrace]
  ): Future[ISyncEvent] = {
    val connection = twinTrace.getConnection
    persistence
      .createReplicaAndSyncEventAndUpdateTwinTrace(twinTrace, nonPersistentReplica, preparedTraces)
      .map { syncEvent =>
        val syncEventId = syncEvent.getId
        val issueUrn: Option[String] = Option(syncEvent.getLocalReplica).map(_.getIssueKey.getURN)
        val connectionName: String = connection.getName
        LOG.info(
          s"#scheduleSyncEvent: created the syncEvent `$syncEventId` for the entity `$issueUrn` and connection `$connectionName`"
        )
        workerNotificationService.sendProcessEventsNotification()
        syncEvent
      }
  }

  /** Schedules Sync Event without change checking
    * @param connection
    * @param issueKey
    * @return
    *   sync event
    */
  override def scheduleSyncEventNoChangeCheck(
      connection: IConnection,
      issueKey: IIssueKey
  ): Future[Option[ISyncEvent]] =
    // We can be sure that when calling .value, the Future is already completed as we are using readyInf on it.
    twinTraceRepository
      .getTwinTraceByLocalIssueKeyFuture(connection, issueKey)
      .flatMap {
        case Some(twinTrace) =>
          trackerHubObjectService.getHubPayloadFromTracker(issueKey, connection).flatMap {
            case Some(payload) =>
              createReplicaProcessor
                .createHubReplica(connection, payload, issueKey, None)
                .flatMap { nonPersistentReplica =>
                  val emptyHubIssue = new BasicHubIssue
                  val generatedHubIssue = nonPersistentReplica.getPayload.getHubIssue
                  if (emptyHubIssue.equals(generatedHubIssue)) {
                    LOG.warn(s"Sync event for ${issueKey.getEntityType} ${issueKey.getURN} was not scheduled as the replica was not touched on outgoing script")
                    Future.successful(None)
                  } else {
                    val preparedTraces = prepareTraces(nonPersistentReplica, twinTrace, connection)
                    scheduleSyncEvent(nonPersistentReplica, twinTrace, preparedTraces)
                      .map(r => Some(r))
                  }
                }
            case None          => Future.successful(None)
          }

        case None => Future.successful(None)
      }
      .recover {
        val context = SyncContext(connection = Some(connection), localIssueKeyOpt = Some(issueKey))
        val actType = Some(ErrorActType.SYNC)
        recoverScheduling(context, actType)
      }

  /** Schedules unexalate event
    * @param connection
    * @param issueKey
    * @return
    */
  override def scheduleUnexalateEvent(
      connection: IConnection,
      issueKey: IIssueKey
  ): Future[Option[ISyncEvent]] =
    scheduleUnexalateOrCleanupOrDeleteEvent(connection.getID, issueKey) {
      (twinTrace: ITwinTrace, replica: INonPersistentReplica) =>
        persistence.persistUnexalateEvent(
          twinTrace,
          getUnexalateEventStatus(twinTrace.getStatus),
          replica,
          connection
        )
    }
      .recover {
        val context = SyncContext(connection = Some(connection), localIssueKeyOpt = Some(issueKey))
        val actType = Some(ErrorActType.UNEXALATE)
        recoverScheduling(context, actType)
      }

  /** Schedules cleanup event
    * @param connection
    * @param issueKey
    * @return
    *   sync event
    */
  override def scheduleCleanupEvent(
      connection: IConnection,
      issueKey: IIssueKey
  ): Future[Option[ISyncEvent]] = {
    LOG.debug(s"scheduleCleanupEvent for connection ${connection.getID} and issueKey $issueKey")
    scheduleUnexalateOrCleanupOrDeleteEvent(connection.getID, issueKey) {
      (twinTrace: ITwinTrace, replica: INonPersistentReplica) =>
        persistence.persistCleanupEvent(
          twinTrace,
          getUnexalateEventStatus(twinTrace.getStatus),
          replica,
          connection
        )
    }
      .recover {
        val context = SyncContext(connection = Some(connection), localIssueKeyOpt = Some(issueKey))
        val actType = Some(ErrorActType.UNEXALATE)
        recoverScheduling(context, actType)
      }
  }

  /** Atm not used. Schedules cleanup event for provided remote issue and connection
    * @param connection
    * @param remoteIssueUrn
    * @param entityType
    * @return
    *   sync event
    */
  override def scheduleCleanupEventForRemoteIssue(
      connection: IConnection,
      remoteIssueUrn: String,
      entityType: String
  ): Future[Option[ISyncEvent]] = {
    val connectionId = connection.getID
    LOG.debug(
      s"scheduleCleanupEventForRemoteIssue for connection $connectionId and remoteIssueUrn $remoteIssueUrn"
    )

    twinTraceRepository
      .getTwinTraceByRelationAndRemoteIssueUrnFuture(
        connection,
        remoteIssueUrn,
        entityType,
        Maps.newHashMap()
      )
      .flatMap { // TODO EXAEDIT-873 think about service now custom keys).flatMap {
        case Some(twinTrace) if Option(twinTrace.getLocalReplica).isDefined =>
          val replica = createReplicaProcessor.createHubReplicaForDeletedIssue(
            twinTrace.getLocalReplica.getIssueKey,
            connectionId
          )
          val syncEventFuture = persistence.persistCleanupEvent(
            twinTrace,
            getUnexalateEventStatus(twinTrace.getStatus),
            replica,
            connection
          )
          syncEventFuture.foreach(_ => workerNotificationService.sendProcessEventsNotification())
          syncEventFuture.map(Some(_))
        case None                                                           =>
          val replica = createReplicaProcessor.createHubReplicaForDeletedIssue(
            new BasicIssueKey("0", "KEY-0"),
            connectionId
          )
          val syncEventFuture =
            persistence.persistCleanUpEventForRemoteIssue(replica, connection, remoteIssueUrn)
          syncEventFuture.foreach(_ => workerNotificationService.sendProcessEventsNotification())
          syncEventFuture.map(Some(_))
        case _ => Future.successful(None)
      }
  }

  /** Schedules cleanup event for provided connection
    * @param connectionId
    * @param entityType
    * @return
    *   sync event
    */
  override def scheduleCleanupEventForConnection(
      connectionId: Int,
      entityType: String
  ): Future[None.type] = {

    def scheduleCleanupEventsByTwinTraceSeq(connection: IConnection, localIssueKeys: Seq[IIssueKey]) =
      Future.sequence(
        localIssueKeys.map(issueKey =>
          Option(issueKey) match {
            case Some(localIssueKey) =>
              scheduleCleanupEvent(connection, localIssueKey)
            case _                   =>
              LOG.debug(
                s"Trying to schedule cleanUpConnectionOnBoth for connection $connectionId but no local issue found."
              )
              Future.successful(None)
          }
        )
      )

    relationRepository.getConnectionFuture(connectionId) flatMap {
      case Some(connection) if connection.isLocal =>
        cleanUpService
          .cleanUpSyncInfoForConnectionKeepTwinTrace(connection, entityType)
          .map(_ => None)

      case Some(connection) =>
        for {
          _ <- cleanUpService.cleanUpScheduleErrorForConnection(connection, entityType)
          localIssueKeys <-
            if (EntityType.ALL.equals(entityType)) {
              twinTraceRepository.getLocalIssueKeysForConnectionFuture(connection.getID)
            } else {
              twinTraceRepository.getLocalIssueKeysForConnectionAndEntityTypeFuture(
                connection.getID,
                entityType
              )
            }
          _ <- scheduleCleanupEventsByTwinTraceSeq(connection, localIssueKeys)
        } yield None
      case _                =>
        LOG.debug(
          s"Trying to scheduleCleanupEventForConnection for connection $connectionId but no connection found."
        )
        Future.successful(None)
    }
  }

  /** Schedule delete event for provided connection and issue
    * @param connectionId
    * @param issueKey
    * @return
    *   sync event
    */
  override def scheduleDeleteEvent(
      connection: IConnection,
      issueKey: IIssueKey
  ): Future[Option[ISyncEvent]] =
    scheduleUnexalateOrCleanupOrDeleteEvent(connection.getID, issueKey) {
      (twinTrace: ITwinTrace, replica: INonPersistentReplica) =>
        persistence.persistDeleteEvent(
          twinTrace,
          getDeleteEventStatus(twinTrace.getStatus),
          replica,
          connection
        )
    }
      .recoverWith {
        case e =>
          relationRepository.getConnectionFuture(connection.getID).map { connectionOpt =>
            val context = SyncContext(connection = connectionOpt, localIssueKeyOpt = Some(issueKey))
            val actType = Some(ErrorActType.DELETE)
            recoverScheduling(context, actType)(e)
          }
      }

  private def scheduleUnexalateOrCleanupOrDeleteEvent(connectionId: Int, issueKey: IIssueKey)(
      getSyncEvtOpt: (ITwinTrace, INonPersistentReplica) => Future[ISyncEvent]
  ): Future[Option[ISyncEvent]] =
    twinTraceRepository
      .getTwinTraceByRelationAndLocalIssueUrnFuture(
        connectionId,
        issueKey.getURN,
        issueKey.getEntityType,
        issueKey.getFieldValues
      )
      .flatMap {
        case Some(twinTrace) if twinTrace.getStatus != TwinTraceStatus.UNEXALATED =>
          val replica =
            createReplicaProcessor.createHubReplicaForDeletedIssue(issueKey, connectionId)
          val syncEventFuture = getSyncEvtOpt(twinTrace, replica)
          syncEventFuture.foreach(_ => workerNotificationService.sendProcessEventsNotification())
          syncEventFuture.map(Some(_))
        case _ => Future.successful(None)
      }

  /** Gets event status: if twin Trace Status `REMOTE_ISSUE_DELETED` -> `DELETE_TWINTRACE` otherwise
    * `READY`
    * @param twinTraceStatus
    * @return
    *   `DELETE_TWINTRACE` or `READY`
    */
  private def getDeleteEventStatus(twinTraceStatus: TwinTraceStatus): EventStatus =
    if (twinTraceStatus == TwinTraceStatus.REMOTE_ISSUE_DELETED) EventStatus.DELETE_TWINTRACE
    else EventStatus.READY

  /** Gets event status: if twin Trace Status `REMOTE_ISSUE_DELETED` -> `REMOVE_LINK` otherwise
    * `READY`
    * @param twinTraceStatus
    * @return
    *   `DELETE_TWINTRACE` or `READY`
    */
  private def getUnexalateEventStatus(twinTraceStatus: TwinTraceStatus): EventStatus =
    if (twinTraceStatus == TwinTraceStatus.REMOTE_ISSUE_DELETED) EventStatus.REMOVE_LINK
    else EventStatus.READY

  def recoverScheduling(
      syncContext: SyncContext,
      actTypeOpt: Option[ErrorActType]
  ): PartialFunction[Throwable, None.type] = {
    case e: CategorizedException =>
      logErrorContext(syncContext, actTypeOpt, e)
      errorHandler.handleScheduleError(e, syncContext, actTypeOpt)
      None
    case e: Exception            =>
      logErrorContext(syncContext, actTypeOpt, e)
      val bugException = bugExceptionCategoryService.generateBugException(Some(e), None)
      errorHandler.handleScheduleError(bugException, syncContext, actTypeOpt)
      None
  }

  private def logErrorContext(
      syncContext: SyncContext,
      actTypeOpt: Option[ErrorActType],
      e: Exception
  ): Unit =
    LOG.error(
      s"Exception occurred while scheduling${actTypeOpt.map(eType => s" `${eType.name()}`").getOrElse("")} event${syncContext.localIssueKeyOpt
          .map(localKey => s" for local issue $localKey")
          .getOrElse("")}, connection `${syncContext.connection.get.getName}`${syncContext.remoteIssueKeyOpt
          .map(remoteKey => s", remote issue `$remoteKey`.")
          .getOrElse(".")}",
      e
    )

}
