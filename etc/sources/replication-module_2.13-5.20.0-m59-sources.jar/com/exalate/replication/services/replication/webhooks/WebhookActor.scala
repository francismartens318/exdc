package com.exalate.replication.services.replication.webhooks

import akka.actor.{Actor, Props}
import com.exalate.api.domain.IIssueKey
import com.exalate.api.persistence.relation.IRelationRepository
import com.exalate.api.persistence.twintrace.ITwinTraceRepository
import com.exalate.basic.domain.BasicIssueKey
import com.exalate.basic.domain.hubobject.v1.UpdateBasicHubIssue
import com.exalate.basic.domain.webhook.NonPersistentWebhookInfo
import com.exalate.generic.services.EntityContext
import com.exalate.replication.services.api.replication.IEventSchedulerNotificationService
import com.exalate.replication.services.api.replication.impersonation.IImpersonationService
import com.exalate.replication.services.api.trigger.ISyncAutomationService
import com.exalate.replication.services.replication.webhooks.WebhookActor.Messages.{
  IssueDeletedMessageGeneric,
  IssueLinkUpdated,
  IssueUpdatedMessageGeneric,
  WebhookActionReceived
}
import com.exalate.services.utils.FutureUtils
import com.google.inject.Inject
import play.api.Logger

import scala.concurrent.Future

object WebhookActor {

  object Messages {

    sealed trait WebhookMessage

    case class IssueUpdatedMessageGeneric(
        issueKey: BasicIssueKey,
        projectKeyOpt: Option[String],
        updateHubIssueOpt: Option[UpdateBasicHubIssue],
        entityContext: Option[EntityContext],
        webhookDateOpt: Option[Long]
    ) extends WebhookMessage

    case class IssueDeletedMessageGeneric(issueKey: BasicIssueKey) extends WebhookMessage

    case class IssueLinkUpdated(
        sourceIssueKey: IIssueKey,
        destinationIssueKey: IIssueKey,
        projectKeyOpt: Option[String]
    ) extends WebhookMessage // jcloud

    case class WebhookActionReceived(
        webhookInfo: NonPersistentWebhookInfo,
        updateIssue: Option[UpdateBasicHubIssue] = None,
        projectKeyOpt: Option[String]
    ) extends WebhookMessage // jcloud

  }

  def props(
      eventSchedulerNotificationService: IEventSchedulerNotificationService,
      connectionRepository: IRelationRepository,
      twinTraceRepository: ITwinTraceRepository,
      impersonationService: IImpersonationService,
      syncAutomationService: ISyncAutomationService
  ): Props = Props(
    new WebhookActor(
      eventSchedulerNotificationService,
      connectionRepository,
      twinTraceRepository,
      impersonationService,
      syncAutomationService
    )
  )

}

class WebhookActor @Inject() (
    eventSchedulerNotificationService: IEventSchedulerNotificationService,
    connectionRepository: IRelationRepository,
    twinTraceRepository: ITwinTraceRepository,
    impersonationService: IImpersonationService,
    syncAutomationService: ISyncAutomationService
) extends Actor {

  val LOG: Logger = Logger("application.services.replication.worker.WebhookActor")

  implicit private val executor = context.dispatcher

  override def receive: Receive = {
    case IssueUpdatedMessageGeneric(
          issueKey: BasicIssueKey,
          issueProjectOpt: Option[String],
          updateHubIssueOpt: Option[UpdateBasicHubIssue],
          entityContext: Option[EntityContext],
          webhookDateOpt: Option[Long]
        ) => // jcloud(IssueUpdated),  azure(UpsertWebhookMessage), github(IssueUpdatedMessage)
      FutureUtils.readyInf(
        scheduleEvents(issueKey, issueProjectOpt, updateHubIssueOpt, entityContext)
      )

    case IssueDeletedMessageGeneric(issueKey) =>
      twinTraceRepository
        .findTwinTracesByIssueId(issueKey.getIdStr, issueKey.getEntityType, issueKey.getFieldValues)
        .map(_.map(_.getConnection))
        .foreach(_.map(c => eventSchedulerNotificationService.scheduleDeleteEvent(c, issueKey)))

    case IssueLinkUpdated(sourceIssueKey, destinationIssueKey, projectKeyOpt) => // jcloud
      LOG.debug("Processing issue link updated webhook")
      FutureUtils.readyInf(
        Future.sequence(
          Seq(
            scheduleEvents(sourceIssueKey, projectKeyOpt),
            scheduleEvents(destinationIssueKey, projectKeyOpt)
          )
        )
      )

    case WebhookActionReceived(webhookInfo, updateIssue, pKey) => // jcloud
      FutureUtils.readyInf(
        impersonationService
          .handleWebhookAction(webhookInfo, updateIssue, pKey, None)
          .recover {
            case e: Exception =>
              LOG.error(
                s"Failed to handleWebhookAction with webhookInfo : ${webhookInfo.toString}. Detailed info: ${e.getLocalizedMessage}"
              )
          }
      )

  }

  private def scheduleEvents(
      issueKey: IIssueKey,
      issueProject: Option[String] = None,
      updateHubIssueOption: Option[UpdateBasicHubIssue] = None,
      entityContext: Option[EntityContext] = None
  ) = {
    LOG.trace(s"Scheduling update events for issue $issueKey")
    eventSchedulerNotificationService.scheduleUpdateEvents(issueKey, updateHubIssueOption)
    syncAutomationService.checkCriteriaAndExalate(
      issueKey.asInstanceOf[BasicIssueKey],
      issueProject,
      updateHubIssueOption,
      entityContext
    )
  }

}
