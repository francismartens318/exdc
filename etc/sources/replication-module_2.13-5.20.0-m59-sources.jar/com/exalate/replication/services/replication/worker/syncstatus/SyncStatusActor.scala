package com.exalate.replication.services.replication.worker.syncstatus

import akka.actor.{Actor, Props}
import com.exalate.api.domain.IIssueKey
import com.exalate.replication.services.api.config.ISyncStatusService
import com.google.inject.Inject
import play.api.Logger
import akka.pattern.pipe
import com.exalate.replication.services.replication.worker.syncstatus.SyncStatusActor.Messages.SyncStatusMessage

import scala.concurrent.duration._
import scala.concurrent.{Await, Future}

object SyncStatusActor {

  object Messages {
    case class SyncStatusMessage(issueKey: IIssueKey)
  }

  def props(syncStatusService: ISyncStatusService): Props = Props(
    new SyncStatusActor(syncStatusService)
  )

}

class SyncStatusActor @Inject() (syncStatusService: ISyncStatusService) extends Actor {

  private val LOG: Logger = Logger("application.services.replication.worker.SyncStatusActor")

  implicit private val ec = context.dispatcher

  def receive: Receive = {
    case SyncStatusMessage(issueKey) =>
      LOG.trace(
        s"Processing sync status message for ${issueKey.getEntityType} with id ${issueKey.getIdStr} and urn ${issueKey.getURN}."
      )
      syncStatusService
        .getSyncStatusesByIssueId(issueKey)
        .pipeTo(sender())
        .recoverWith {
          case e: Exception =>
            LOG.error(s"Error while trying to getSyncStatusesByIssueId.", e)
            Future.successful(None)
        }
    case _ => LOG.warn("SyncStatusActor received message different from SyncStatusMessage.")

  }

}
