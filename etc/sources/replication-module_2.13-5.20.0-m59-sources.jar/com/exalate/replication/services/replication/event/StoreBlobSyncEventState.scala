package com.exalate.replication.services.replication.event

import com.exalate.api.domain.ErrorEntityType
import com.exalate.api.domain.event.{EventStatus, ISyncEvent}
import com.exalate.api.exception.IssueTrackerException
import com.exalate.api.exception.network.RetriesForBlobExceededAvailabilityNetworkException
import com.exalate.api.persistence.replication.event.IEventReplicationRepository
import com.exalate.basic.domain.NonPersistentBlobMetadata
import com.exalate.domain.exception.network.BlobDownloadTimeoutException
import com.exalate.domain.node.storeblob.StoredBlob
import com.exalate.error.services.api.IAvailabilityNetworkExceptionCategoryService
import com.exalate.generic.services.api.ITrackerHubObjectService
import com.exalate.replication.services.api.error.{IErrorService, SyncContext}
import com.exalate.replication.services.api.hubobject.{IBlobMetadataService, IReplicaHelper}
import com.exalate.replication.services.api.node.storeblob.IStoreBlobService
import com.exalate.replication.services.replication.state.IState
import com.exalate.services.utils.FutureUtils
import play.api.{Configuration, Logger}

import javax.inject.Inject
import scala.jdk.CollectionConverters._
import scala.concurrent.{ExecutionContext, Future}
import scala.util.{Failure, Success}

class StoreBlobSyncEventState @Inject() (
    persistence: IEventReplicationRepository,
    replicaHelper: IReplicaHelper,
    blobMetadataService: IBlobMetadataService,
    hubObjectService: ITrackerHubObjectService,
    errorService: IErrorService,
    storeBlobService: IStoreBlobService,
    configuration: Configuration,
    availabilityNetworkExceptionCategoryService: IAvailabilityNetworkExceptionCategoryService
)(implicit ec: ExecutionContext)
    extends IState[ISyncEvent] {

  private val LOG: Logger = Logger("application.services.replication.event.StoreBlobEventState")

  private lazy val MAX_NUMBER_RETRIES =
    configuration.getOptional[Int]("exalate.replication.event.storeblob.retries").getOrElse(5)

  /** Performs transition of one of the states of SyncEventStateMachine: status `STORE_BLOB` the
    * next state will be `SEND_REQUEST`
    *
    * @param event
    * @return
    *   ISyncEvent
    */
  override def transition(event: ISyncEvent): Future[Option[ISyncEvent]] = {
    lazy val syncEventId = event.getId
    val nonPersistentLocalReplica = replicaHelper.toNonPersistentReplica(event.getLocalReplica)

    persistence
      .findSyncingBlobMetadataForTwinTrace(event.getTwinTraceId)
      .map { existingMd =>
        blobMetadataService.getAddedBlobIds(
          nonPersistentLocalReplica,
          event.getTraces.asScala.toSeq,
          existingMd
        )
      }
      // FIXME: Here we are awaiting where maybe we shouldn't need to, I didn't want to risk having problems with concurrently executing getStoreAndComputeChecksumOfLocalBlob
      .map(
        _.map(blobId =>
          (
            blobId,
            FutureUtils
              .readyInf(getStoreAndComputeChecksumOfLocalBlob(event, blobId))
              .value
              .get
          )
        )
      )
      .flatMap { blobIdAndFilePathWithChecksumTrySeq =>
        // Ignore the attachments which weren't retrieved after 5 retries
        val filteredBlobIdAndFilePathWithChecksumTrySeq =
          blobIdAndFilePathWithChecksumTrySeq.filterNot(_._2 match {
            case Failure(_: RetriesForBlobExceededAvailabilityNetworkException) => true
            case _                                                              => false
          })
        filteredBlobIdAndFilePathWithChecksumTrySeq.find {
          case (_, checksumTry) => checksumTry.isFailure
        } match {

          case Some((blobId, Failure(e: IssueTrackerException))) =>
            LOG.error(
              s"#transitioning event `$syncEventId`: Blob $blobId checksum failed with IssueTrackerException",
              e
            )
            errorService
              .createError(ErrorEntityType.ISSUE, e, SyncContext.createWithSyncEvent(event), None)
              .map(_ => None)

          case Some((blobId, Failure(e: BlobDownloadTimeoutException))) =>
            LOG.error(
              s"#transitioning event `$syncEventId`: Blob $blobId checksum failed with BlobDownloadTimeoutException",
              e
            )
            Future.failed(e)
          case Some((blobId, Failure(e)))                               =>
            LOG.error(
              s"#transitioning event `$syncEventId`: Blob $blobId checksum failed with Exception",
              e
            )
            Future.failed(e)

          case None =>
            LOG.debug(
              s"#transitioning event `$syncEventId`: all checksum were calculated successfully"
            )
            val npBlobMetadata =
              filteredBlobIdAndFilePathWithChecksumTrySeq
                .flatMap {
                  case (blobId: String, Success(Some((filePath, checksum)))) =>
                    Option(new NonPersistentBlobMetadata(blobId, filePath, checksum))
                  case (_, Success(None))                                    => None
                }

            persistence.createBlobMetadataAndUpdateEventStatus(
              event,
              EventStatus.SEND_REQUEST,
              npBlobMetadata
            )
        }
      }
  }

  private def getStoreAndComputeChecksumOfLocalBlob(
      syncEvent: ISyncEvent,
      blobId: String,
      retries: Int = 0
  ): Future[Option[(String, String)]] = {
    val syncEventId = syncEvent.getId
    lazy val localIssueUrn = syncEvent.getLocalReplica.getIssueKey.getURN
    LOG.debug(
      s"#transitioning event `$syncEventId` for local issue `$localIssueUrn`: Getting attachment body stream for blob $blobId"
    )
    hubObjectService
      .getAttachmentBodyStream(
        blobId,
        syncEvent.getConnection,
        syncEvent.getLocalReplica.getIssueKey
      )
      .flatMap {
        case Some(bodyStream) =>
          for {
            storedBlobMetaData <- storeBlobService.storeBlob(
              StoredBlob.generateOutgoingBlobName(syncEventId, blobId),
              bodyStream
            )
            checksumInfo <- storeBlobService.getChecksum(storedBlobMetaData)
          } yield Option((storedBlobMetaData.filePath, checksumInfo.checksum))
        case None             => Future.successful(None)
      }
      .recoverWith {
        case e: IssueTrackerException if retries < MAX_NUMBER_RETRIES  =>
          LOG.warn(
            s"#transitioning event `$syncEventId` for local issue `$localIssueUrn`: Blob $blobId failed on being retrieved/stored/checksum, it will be retried",
            e
          )
          getStoreAndComputeChecksumOfLocalBlob(syncEvent, blobId, retries + 1)
        case _: IssueTrackerException if retries >= MAX_NUMBER_RETRIES =>
          val details =
            s"#transitioning event `$syncEventId` for local issue `$localIssueUrn`: Blob could not be retrieved after attempting to download it $MAX_NUMBER_RETRIES times. It will be ignored"
          val exception = availabilityNetworkExceptionCategoryService
            .generateRetriesForBlobExceededNetworkException(MAX_NUMBER_RETRIES, details)
          LOG.error(details, exception)
          Future.failed(exception)
        case e: Exception                                              =>
          LOG.error(
            s"#transitioning event `$syncEventId` for local issue `$localIssueUrn`: Blob $blobId failed on being retrieved/stored/checksum",
            e
          )
          Future.failed(e)
      }
  }

}
