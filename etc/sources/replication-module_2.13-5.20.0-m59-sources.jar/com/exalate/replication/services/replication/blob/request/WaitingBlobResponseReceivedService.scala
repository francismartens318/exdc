package com.exalate.replication.services.replication.blob.request

import com.exalate.api.domain.blob.request.{BlobRequestStatus, IBlobRequest}

import javax.inject.Inject

class WaitingBlobResponseReceivedService @Inject() () {

  def getNextStatus(blobRequest: IBlobRequest): BlobRequestStatus =
    BlobRequestStatus.BLOB_PROCESSED

}
