package com.exalate.replication.services.replication.blob.event

import javax.inject.Inject

import com.exalate.api.domain.blob.event.{BlobEventStatus, IBlobEvent}
import com.exalate.api.persistence.replication.blobevent.IBlobEventReplicationRepository
import com.exalate.replication.services.replication.state.IState
import play.api.Logger

import scala.concurrent.ExecutionContext
import scala.concurrent.Future

class ReadyBlobEventState @Inject() (persistence: IBlobEventReplicationRepository)(implicit
    ec: ExecutionContext
) extends IState[IBlobEvent] {

  val LOG = Logger("application.services.replication.blob.event.ReadyBlobEventState")

  /** Performs transition of one of the states of BlobEventStateMachine: status `READY`
    * @param blobEvent
    * @return
    *   IBlobEvent
    */
  override def transition(blobEvent: IBlobEvent): Future[Option[IBlobEvent]] =
    persistence.updateBlobEventStatus(blobEvent, BlobEventStatus.SEND_BLOB_REQUEST).map(Some(_))

}
