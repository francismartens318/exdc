package com.exalate.replication.services.replication.worker.messages

object RequestWorkerMessages {

  object ProcessRequests

  object AfterTheLastMessage

}
