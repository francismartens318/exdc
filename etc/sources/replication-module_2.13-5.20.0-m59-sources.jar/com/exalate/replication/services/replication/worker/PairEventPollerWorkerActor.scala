package com.exalate.replication.services.replication.worker

import akka.actor.{Actor, Props}
import com.exalate.api.exception.bug.BugException
import com.exalate.api.persistence.trigger.ITriggerRepository
import com.exalate.replication.services.api.trigger.ITriggerPairPollSchedulerService
import com.exalate.replication.services.replication.worker.PairEventPollerWorkerActor.Messages.SchedulePairEvents
import com.google.inject.Inject
import play.api.{Configuration, Logger}

import java.time.Instant
import java.time.temporal.ChronoUnit
import java.util.Date
import java.util.concurrent.TimeUnit
import scala.concurrent.Future
import scala.concurrent.duration._
import scala.util.{Failure, Success}

/** Worker receives message "SchedulePairEvents" on app startup from
  * ITrackerUpdatePollSchedulerService, or when trigger created/updated, then it poll tracker for
  * updates and sends "SchedulePairEvents" message to itself every x seconds.
  *
  * Should be used only in nodes that support polling. Other way - should be implemented and used
  * webhook logic. To use it - add to DIModule:
  * bindActor[PairEventPollerWorkerActor](classOf[PairEventPollerWorkerActor],
  * NodeSettings.PAIR_EVENT_POLLER_WORKER_ACTOR)
  */

object PairEventPollerWorkerActor {

  object Messages {

    case class SchedulePairEvents(creationTime: Instant, lastPollingInstant: Option[Instant] = None)

  }

}

abstract class PairEventPollerWorkerActor(
    triggerRepository: ITriggerRepository,
    triggerPollingService: ITriggerPairPollSchedulerService,
    configuration: Configuration
) extends Actor {

  val LOG: Logger = Logger("application.services.replication.worker.PairEventPollerWorkerActor")

  implicit private val ec = context.dispatcher

  private val DELAY_POLL_TIME: FiniteDuration = configuration
    .getOptional[FiniteDuration]("com.exalate.schedule.poll.pair.time")
    .getOrElse(50.seconds)

  def BUG_EXCEPTION(cause: Exception) =
    new BugException("Error occured during triggers execution. Will try again", cause)

  override def receive: Receive = {
    case m @ SchedulePairEvents(creationTime, lastPollingInstant) =>
      LOG.trace(s"waitingForAfterTheLastMessage:polling with $m")
      val lastPollingDateOrCreation = lastPollingInstant.getOrElse(creationTime)
      val nextLastPollingInstant = Some(computeNextLastPollingDate(lastPollingDateOrCreation))

      triggerRepository
        .getAllActive()
        .map(_.map { trigger =>
          LOG.trace(
            s"PairEventPollerWorkerActor:waiting:SchedulePairEvents trigger ${trigger.getId} with last polling data $lastPollingDateOrCreation"
          )

          triggerPollingService
            .pollAndSchedule(trigger.getId, Date.from(lastPollingDateOrCreation))
            .recoverWith {
              case e: Exception =>
                Future.successful(
                  Some(
                    new BugException(
                      s"Error while polling and schedule for trigger ${trigger.getId} with polling date $lastPollingDateOrCreation",
                      e
                    )
                  )
                )
            }
        })
        .flatMap(pollResults => Future.sequence(pollResults))
        .map(_.flatten)
        .onComplete {
          case Success(Nil)       =>
            val schedulePairEvents = m.copy(lastPollingInstant = nextLastPollingInstant)
            context.system.scheduler.scheduleOnce(DELAY_POLL_TIME, self, schedulePairEvents)
          case Success(errors)    =>
            errors.foreach(exception => LOG.error(exception.getMessage, exception))
            context.system.scheduler.scheduleOnce(DELAY_POLL_TIME, self, m)
          case Failure(exception) =>
            LOG.error(s"Error during triggers execution. Will try again in 50 seconds", exception)
            context.system.scheduler.scheduleOnce(DELAY_POLL_TIME, self, m)

        }
  }

  def computeNextLastPollingDate(lastPollingInstant: Instant): Instant
}

object FixedPairEventPollerWorkerActor {

  def props(
      triggerRepository: ITriggerRepository,
      triggerPollingService: ITriggerPairPollSchedulerService,
      configuration: Configuration
  ): Props = Props(
    new FixedPairEventPollerWorkerActor(triggerRepository, triggerPollingService, configuration)
  )

}

class FixedPairEventPollerWorkerActor @Inject() (
    triggerRepository: ITriggerRepository,
    triggerPollingService: ITriggerPairPollSchedulerService,
    configuration: Configuration
) extends PairEventPollerWorkerActor(triggerRepository, triggerPollingService, configuration) {
  override def computeNextLastPollingDate(lastPollingInstant: Instant): Instant = Instant.now()
}

object IndexBasedPairEventPollerWorkerActor {

  def props(
      triggerRepository: ITriggerRepository,
      triggerPollingService: ITriggerPairPollSchedulerService,
      configuration: Configuration
  ): Props = Props(
    new IndexBasedPairEventPollerWorkerActor(triggerRepository, triggerPollingService, configuration)
  )

}

class IndexBasedPairEventPollerWorkerActor @Inject() (
    triggerRepository: ITriggerRepository,
    triggerPollingService: ITriggerPairPollSchedulerService,
    configuration: Configuration
) extends PairEventPollerWorkerActor(triggerRepository, triggerPollingService, configuration) {

  private val MINUTES_TO_UPDATE_POLL_TIME = 20.minutes

  def computeNextLastPollingDate(lastPollingInstant: Instant): Instant = {
    val milliSinceLastPolling = Instant.now().toEpochMilli - lastPollingInstant.toEpochMilli
    val minutesSinceLastPolling =
      TimeUnit.MINUTES.convert(milliSinceLastPolling, TimeUnit.MILLISECONDS)

    if (minutesSinceLastPolling >= MINUTES_TO_UPDATE_POLL_TIME.toMinutes) {
      /*
       Because indexing on zendesk might take a few minutes for zendesk to index your tickets, we are updating the last polling date to 10 minutes after the last poll time
       That was it is ensured we still give 10 minutes to existing tickets to be indexed
       */
      // TODO: show the new data rather be now - 10 mins ?
      val tenMinutesAfterLastPolling = lastPollingInstant.plus(
        (60 * 1000) * (MINUTES_TO_UPDATE_POLL_TIME.toMinutes - 10),
        ChronoUnit.MILLIS
      )

      LOG.debug(
        s"Diff with previous last poll date is more than ${MINUTES_TO_UPDATE_POLL_TIME.toMinutes} minutes ($minutesSinceLastPolling), updating lastPollingDateTime from $lastPollingInstant to $tenMinutesAfterLastPolling"
      )

      tenMinutesAfterLastPolling
    } else {
      LOG.debug(
        s"Diff with previous last poll date is less than ${MINUTES_TO_UPDATE_POLL_TIME.toMinutes} minutes ($minutesSinceLastPolling), Exalate will wait for Zendesk to finish indexing new ticket updates"
      )
      lastPollingInstant
    }
  }

}
