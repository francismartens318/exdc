package com.exalate.replication.services.replication.blob.event

import com.exalate.api.domain.blob.event.{BlobEventStatus, IBlobEvent}
import com.exalate.api.persistence.replication.blobevent.IBlobEventReplicationRepository
import com.exalate.replication.services.api.replication.worker.IWorkerNotificationService
import com.exalate.replication.services.api.transport.ITransportServiceFactory
import com.exalate.replication.services.replication.state.IState
import com.exalate.replication.services.transport.utils.ExalateVersionCheckerUtils
import com.google.inject.Inject

import scala.concurrent.ExecutionContext
import scala.concurrent.Future

class NotifyResponseReceivedBlobEventState @Inject() (
    transportServiceFactory: ITransportServiceFactory,
    blobEventReplicationRepository: IBlobEventReplicationRepository,
    workerNotificationService: IWorkerNotificationService
)(implicit ec: ExecutionContext)
    extends IState[IBlobEvent] {

  /** Performs transition of one of the states of BlobEventStateMachine: status
    * `NOTIFY_BLOB_RESPONSE_RECEIVED`
    * @param blobEvent
    * @return
    *   IBlobEvent
    */
  override def transition(blobEvent: IBlobEvent): Future[Option[IBlobEvent]] = {
    val future =
      if (
        ExalateVersionCheckerUtils.remoteSupportsNoExtraConfirmation(
          blobEvent.getSyncEvent.getConnection
        )
      ) Future.successful(None)
      else
        Future
          .fromTry(transportServiceFactory.get(blobEvent.getSyncEvent.getConnection))
          .flatMap(_.postBlobResponseReceived(blobEvent))

    future
      .flatMap { _ =>
        Option(blobEvent.getBlobErrorReason) match {
          case Some(_) =>
            blobEventReplicationRepository
              .updateBlobEventStatus(blobEvent, BlobEventStatus.BLOB_ERROR_RESPONSE_READY)
              .map { be =>
                workerNotificationService.sendProcessBlobEventsNotification()
                Some(be)
              }
          case None    =>
            blobEventReplicationRepository
              .updateBlobEventStatus(blobEvent, BlobEventStatus.BLOB_PROCESSED)
              .map { be =>
                workerNotificationService.sendProcessBlobEventsNotification()
                Some(be)
              }
        }
      }
  }

}
