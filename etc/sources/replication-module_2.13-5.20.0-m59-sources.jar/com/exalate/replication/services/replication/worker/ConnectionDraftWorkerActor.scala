package com.exalate.replication.services.replication.worker

import akka.actor.Actor
import com.exalate.api.ILoggingService
import com.exalate.api.persistence.connectiondraft.IConnectionDraftRepository
import com.exalate.replication.services.replication.worker.ConnectionDraftWorkerActor.DeleteOldConnectionDrafts
import com.exalate.replication.services.utils.ActorLoggingService
import com.google.inject.Inject

object ConnectionDraftWorkerActor {
  case object DeleteOldConnectionDrafts
}

class ConnectionDraftWorkerActor @Inject() (
    connectionDraftRepository: IConnectionDraftRepository,
    loggingService: ILoggingService,
    actorLoggingService: ActorLoggingService
) extends Actor {

  override def receive: Receive = {
    case DeleteOldConnectionDrafts =>
      actorLoggingService.tryWithLoggedBugs {
        loggingService.trace(
          "ConnectionDraftWorkerActor: deleting old REJECTED and PUBLISHED drafts"
        )
        connectionDraftRepository.deleteOldProcessedDrafts()
      }

    case _ =>
      actorLoggingService.tryWithLoggedBugs {
        loggingService.trace("ConnectionDraftWorkerActor: waiting:_")
      }
  }

}
