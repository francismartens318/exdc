package com.exalate.replication.services.replication.blob.event

import com.exalate.api.domain.blob.event.{BlobEventStatus, IBlobEvent}

import javax.inject.Inject

class WaitingBlobRequestReceivedService @Inject() () {

  def getNextStatus(blobEvent: IBlobEvent): BlobEventStatus =
    BlobEventStatus.PUBLISH_BLOB_IF_NEEDED

}
