package com.exalate.replication.services.replication.worker

import java.util.Date
import akka.actor.{Actor, Props}
import com.exalate.replication.services.replication.IUpdateEventsPollerService
import com.exalate.replication.services.replication.worker.UpdateEventPollerWorkerActor.Messages.PollForUpdateEvents
import com.google.inject.Inject
import play.api.{Configuration, Logger}

import scala.concurrent.ExecutionContext
import scala.concurrent.duration.{DurationInt, FiniteDuration}

/** Worker receives message "PollForUpdateEvents" on app startup from
  * ITrackerUpdatePollSchedulerService, then it poll tracker for updates and sends
  * "PollForUpdateEvents" message to itself every x seconds.
  *
  * Should be used only in nodes that support polling. Other way - should be implemented and used
  * webhook logic. To use it - add to DIModule:
  * bindActor[UpdateEventPollerWorkerActor](classOf[UpdateEventPollerWorkerActor],
  * "update-event-poller-worker-actor")
  */
object UpdateEventPollerWorkerActor {

  object Messages {

    case class PollForUpdateEvents(creationTime: Date)

  }

  def props(
      updateEventsPollerService: IUpdateEventsPollerService,
      configuration: Configuration
  ): Props = Props(new UpdateEventPollerWorkerActor(updateEventsPollerService, configuration))

}

class UpdateEventPollerWorkerActor @Inject() (
    updateEventsPollerService: IUpdateEventsPollerService,
    configuration: Configuration
) extends Actor {

  val LOG: Logger = Logger(classOf[UpdateEventPollerWorkerActor])

  implicit private val executor: ExecutionContext = context.dispatcher

  private var lastUpdatePollingDate: Option[Date] = None

  private val POLL_TIME: FiniteDuration = configuration
    .getOptional[FiniteDuration]("com.exalate.schedule.poll.update.time")
    .getOrElse(50.seconds)

  def receive: Receive = {
    case m @ PollForUpdateEvents(creationTime) =>
      val lastPollingDateOrCreation = lastUpdatePollingDate.getOrElse(creationTime)
      val now = new Date(new Date().getTime - (1000 * 5))
      LOG.debug(s"Processing PollForUpdateEvents with last polling date $lastPollingDateOrCreation")
      updateEventsPollerService
        .pollForUpdateEvents(lastPollingDateOrCreation)
        .onComplete { _ =>
          lastUpdatePollingDate = Some(now)
          context.system.scheduler.scheduleOnce(POLL_TIME, self, m)
        }

  }

}
