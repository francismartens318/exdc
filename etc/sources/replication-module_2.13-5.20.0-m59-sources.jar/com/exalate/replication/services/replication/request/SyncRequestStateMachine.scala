package com.exalate.replication.services.replication.request

import com.exalate.api.domain.request.{ISyncRequest, RequestStatus}
import com.exalate.replication.services.replication.state.IState

import javax.inject.Inject

class SyncRequestStateMachine @Inject() (
    readyRequestState: ReadySyncRequestState,
    notifyReceivedSyncRequestState: NotifyReceivedSyncRequestState,
    createIssueState: CreateIssueSyncRequestState,
    updateIssueState: UpdateIssueSyncRequestState,
    createReplicaState: CreateReplicaSyncRequestState,
    createOrUpdateTwinTraceState: CreateOrUpdateTwinTraceSyncRequestState,
    sendErrorResponseState: SendErrorResponseSyncRequestState,
    sendResponseState: SendResponseSyncRequestState,
    markTwinTraceForCleanUpSyncRequestState: MarkTwinTraceForCleanUpSyncRequestState,
    addLinkSyncRequestState: AddLinkSyncRequestState,
    removeLinkSyncRequestState: RemoveLinkSyncRequestState,
    responseSentSyncRequestState: ResponseSentSyncRequestState,
    triggerSyncEventSyncRequestState: TriggerSyncEventSyncRequestState,
    triggerUnexalatetSyncRequestState: TriggerUnexalateSyncRequestState,
    completeRequestState: CompleteRequestState
) {

  /** Gets state of Sync Request execution. One of the state for the following statuses:
    *
    * @param syncRequestContext
    *   NOTIFY_REQUEST_RECEIVED, RECEIVING_BLOBS, READY, CREATE_ISSUE, UPDATE_ISSUE, ADD_LINK,
    *   REMOVE_LINK, DELETE_TWIN_TRACE, CREATE_REPLICA, CREATE_OR_UPDATE_TWINTRACE, SEND_RESPONSE,
    *   WAITING_RESPONSE_RECEIVED, WAITING_ERROR_RESPONSE_RECEIVED, PROCESSED, RESPONSE_SENT,
    *   TRIGGER_SYNC_EVENT, TRIGGER_UNEXALATE_EVENT, SEND_ERROR_RESPONSE, COMPLETE
    * @return
    */
  def getState(syncRequestContext: BasicSyncRequestContext): IState[BasicSyncRequestContext] =
    syncRequestContext.request.status match {
      case RequestStatus.NOTIFY_REQUEST_RECEIVED    => notifyReceivedSyncRequestState
      case RequestStatus.READY                      => readyRequestState
      case RequestStatus.CREATE_ISSUE               => createIssueState
      case RequestStatus.UPDATE_ISSUE               => updateIssueState
      case RequestStatus.DELETE_TWIN_TRACE          => markTwinTraceForCleanUpSyncRequestState
      case RequestStatus.CREATE_OR_UPDATE_TWINTRACE => createOrUpdateTwinTraceState
      case RequestStatus.CREATE_REPLICA             => createReplicaState
      case RequestStatus.SEND_ERROR_RESPONSE        => sendErrorResponseState
      case RequestStatus.SEND_RESPONSE              => sendResponseState
      case RequestStatus.ADD_LINK                   => addLinkSyncRequestState
      case RequestStatus.REMOVE_LINK                => removeLinkSyncRequestState
      case RequestStatus.RESPONSE_SENT              => responseSentSyncRequestState
      case RequestStatus.TRIGGER_SYNC_EVENT         => triggerSyncEventSyncRequestState
      case RequestStatus.TRIGGER_UNEXALATE_EVENT    => triggerUnexalatetSyncRequestState
      case RequestStatus.COMPLETE                   => completeRequestState
    }

}
