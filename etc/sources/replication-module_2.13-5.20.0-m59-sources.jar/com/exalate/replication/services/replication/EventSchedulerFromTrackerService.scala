package com.exalate.replication.services.replication

import com.exalate.api.domain.connection.{ConnectionStatus, IConnection}
import com.exalate.api.domain.event.ISyncEvent
import com.exalate.api.domain.hubobject.{IHubIssueReplica, IHubPayload}
import com.exalate.api.domain.twintrace.ITwinTrace
import com.exalate.api.domain.{ErrorActType, IIssueKey, INonPersistentConnectContext}
import com.exalate.api.exception.CategorizedException
import com.exalate.api.persistence.twintrace.ITwinTraceRepository
import com.exalate.basic.domain.BasicHubPayload
import com.exalate.basic.domain.hubobject.v1.{BasicHubIssue, UpdateBasicHubIssue}
import com.exalate.basic.domain.util.SemanticVersionService
import com.exalate.error.services.api.IBugExceptionCategoryService
import com.exalate.generic.services.api.ITrackerHubObjectService
import com.exalate.replication.services.api.error.{IErrorHandler, SyncContext}
import com.exalate.replication.services.api.node.ISelfNodeInfoService
import com.exalate.replication.services.api.replication.{
  IEventSchedulerFromTrackerService,
  IEventSchedulerService
}
import com.google.inject.Inject
import play.api.Logger

import scala.concurrent.ExecutionContext
import scala.concurrent.Future

class EventSchedulerFromTrackerService @Inject() (
    twinTraceRepository: ITwinTraceRepository,
    trackerHubObjectService: ITrackerHubObjectService,
    eventSchedulerService: IEventSchedulerService,
    errorHandler: IErrorHandler,
    bugExceptionCategoryService: IBugExceptionCategoryService,
    selfNodeInfoService: ISelfNodeInfoService
)(implicit ec: ExecutionContext)
    extends IEventSchedulerFromTrackerService {

  private val LOG: Logger = Logger(
    "application.services.replication.event.EventSchedulerFromTrackerService"
  )

  override def scheduleExalateEvent(
      issueKey: IIssueKey,
      connection: IConnection,
      updateHubIssueOption: Option[UpdateBasicHubIssue],
      issueOption: Option[IHubIssueReplica]
  ): Future[Option[ISyncEvent]] =
    scheduleExalate(
      issueKey,
      connection,
      eventSchedulerService.scheduleExalateEvent _,
      updateHubIssueOption,
      issueOption
    )

  override def scheduleExalateOrUpdateEvent(
      issueKey: IIssueKey,
      connection: IConnection,
      updateHubIssueOption: Option[UpdateBasicHubIssue] = None,
      issueOption: Option[IHubIssueReplica] = None
  ): Future[Option[ISyncEvent]] =
    scheduleExalateOrUpdate(
      issueKey,
      connection,
      eventSchedulerService.schedulePairOrSyncEvent _,
      updateHubIssueOption,
      issueOption
    )

  override def scheduleUpdateEvent(
      issueKey: IIssueKey,
      connection: IConnection,
      issue: Option[UpdateBasicHubIssue] = None
  ): Future[Option[ISyncEvent]] =
    scheduleExalateOrUpdate(
      issueKey,
      connection,
      eventSchedulerService.scheduleUpdateEvent _,
      issue,
      None
    )

  override def scheduleUpdateEventForTwinTrace(
      issueKey: IIssueKey,
      twinTrace: ITwinTrace,
      issue: Option[UpdateBasicHubIssue] = None
  ): Future[Option[ISyncEvent]] =
    scheduleExalateOrUpdate(
      issueKey,
      twinTrace,
      eventSchedulerService.scheduleUpdateEvent _,
      issue,
      None
    )

  override def scheduleSyncEventNoChangeCheck(
      issueKey: IIssueKey,
      connection: IConnection
  ): Future[Option[ISyncEvent]] =
    if (connection.getStatus == ConnectionStatus.ACTIVE) {
      eventSchedulerService.scheduleSyncEventNoChangeCheck(connection, issueKey)
    } else {
      Future.successful(None)
    }

  override def scheduleDeleteEvent(
      issueKey: IIssueKey,
      connection: IConnection
  ): Future[Option[ISyncEvent]] =
    eventSchedulerService.scheduleDeleteEvent(connection, issueKey)

  override def scheduleUnexalateEvent(
      issueKey: IIssueKey,
      connection: IConnection
  ): Future[Option[ISyncEvent]] =
    eventSchedulerService.scheduleUnexalateEvent(connection, issueKey)

  override def scheduleCleanupEvent(
      issueKey: IIssueKey,
      connection: IConnection
  ): Future[Option[ISyncEvent]] =
    eventSchedulerService.scheduleCleanupEvent(connection, issueKey)

  override def scheduleCleanupEventForRemoteIssue(
      remoteIssueUrn: String,
      connection: IConnection,
      entityType: String
  ): Future[Option[ISyncEvent]] =
    eventSchedulerService.scheduleCleanupEventForRemoteIssue(connection, remoteIssueUrn, entityType)

  override def scheduleCleanupEventForConnection(
      connectionId: Int,
      entityType: String
  ): Future[None.type] =
    eventSchedulerService.scheduleCleanupEventForConnection(connectionId, entityType)

  override def scheduleConnectEvent(
      issueKey: IIssueKey,
      connection: IConnection,
      remoteIssueUrn: String,
      connectContext: Option[INonPersistentConnectContext],
      issue: Option[UpdateBasicHubIssue]
  ): Future[Option[ISyncEvent]] =
    if (
      connection.isLocal && issueKey.getURN.equals(
        remoteIssueUrn
      ) && issueKey.getEntityType == "issue"
    ) {
      Future.successful(None)
    } else {
      scheduleEvent(
        issueKey,
        connection,
        issue,
        (r, key, payload) =>
          eventSchedulerService.scheduleConnectEvent(
            connection,
            key,
            payload,
            remoteIssueUrn,
            connectContext
          )
      )
        .recover {
          case e: CategorizedException =>
            val context =
              SyncContext(connection = Some(connection), localIssueKeyOpt = Some(issueKey))
            val actTypeOpt = Some(ErrorActType.CONNECT)
            LOG.error(
              s"Exception occurred while scheduling connect event for local issue `$issueKey`, connection `${connection.getName}`, remote issue `$remoteIssueUrn`.",
              e
            )
            errorHandler.handleScheduleError(e, context, actTypeOpt)
            None
          case e: Exception            =>
            val context =
              SyncContext(connection = Some(connection), localIssueKeyOpt = Some(issueKey))
            val actTypeOpt = Some(ErrorActType.CONNECT)
            val bugException = bugExceptionCategoryService.generateBugException(Some(e), None)
            LOG.error(
              s"Exception occurred while scheduling connect event for local issue `$issueKey`, connection `${connection.getName}`, remote issue `$remoteIssueUrn`.",
              e
            )
            errorHandler.handleScheduleError(bugException, context, actTypeOpt)
            None
        }
    }

  private def scheduleEvent(
      issueKey: IIssueKey,
      connection: IConnection,
      issue: Option[UpdateBasicHubIssue],
      scheduleAction: (IConnection, IIssueKey, IHubPayload) => Future[Option[ISyncEvent]]
  ): Future[Option[ISyncEvent]] =
    if (connection.getStatus == ConnectionStatus.ACTIVE) {
      trackerHubObjectService.getHubPayloadFromTracker(issueKey, connection, issue).flatMap {
        case Some(payload) => scheduleAction(connection, issueKey, payload)
        case None          => Future.successful(None)
      }
    } else {
      Future.successful(None)
    }

  private def mergeIssues(base: BasicHubIssue, dominant: Option[UpdateBasicHubIssue]): BasicHubIssue =
    dominant
      .map { d =>
        if (d.isStatusSet) {
          base.setStatus(d.getStatus)
        }
        base
      }
      .getOrElse(base)

  private def scheduleExalateOrUpdate(
      issueKey: IIssueKey,
      connection: IConnection,
      scheduleAction: (
          IConnection,
          IIssueKey,
          IHubPayload,
          Option[ITwinTrace]
      ) => Future[Option[ISyncEvent]],
      updateHubIssueOption: Option[UpdateBasicHubIssue],
      issueOption: Option[IHubIssueReplica]
  ): Future[Option[ISyncEvent]] =
    if (connection.getStatus == ConnectionStatus.ACTIVE) {
      twinTraceRepository.getTwinTraceByLocalIssueKeyFuture(connection, issueKey).flatMap {
        twinTraceOption =>
          issueOption match {
            case Some(issue) =>
              val hubObjectVersion =
                SemanticVersionService.get(selfNodeInfoService.getMaxHubObjectVersion)
              val hubPayload = new BasicHubPayload(hubObjectVersion, issue)
              scheduleAction(connection, issueKey, hubPayload, twinTraceOption)
            case None        =>
              scheduleSyncWithPayloadFromTracker(
                issueKey,
                connection,
                scheduleAction,
                updateHubIssueOption,
                twinTraceOption
              )
          }
      }
    } else {
      Future.successful(None)
    }

  private def scheduleExalateOrUpdate(
      issueKey: IIssueKey,
      twinTrace: ITwinTrace,
      scheduleAction: (
          IConnection,
          IIssueKey,
          IHubPayload,
          Option[ITwinTrace]
      ) => Future[Option[ISyncEvent]],
      updateHubIssueOption: Option[UpdateBasicHubIssue],
      issueOption: Option[IHubIssueReplica]
  ): Future[Option[ISyncEvent]] = {
    val connection = twinTrace.getConnection
    if (connection.getStatus == ConnectionStatus.ACTIVE) {
      issueOption match {
        case Some(issue) =>
          LOG.debug(
            s"#scheduleExalateOrUpdate scheduling an update for ${issueKey.getEntityType} ${issueKey.getIdStr} (${issueKey.getURN}) under twin trace ${twinTrace.getId} (remote twin trace ${twinTrace.getRemoteTwinTraceId}) using payload from before"
          )
          val hubObjectVersion =
            SemanticVersionService.get(selfNodeInfoService.getMaxHubObjectVersion)
          val hubPayload = new BasicHubPayload(hubObjectVersion, issue)
          scheduleAction(connection, issueKey, hubPayload, Option(twinTrace))
        case None        =>
          LOG.debug(
            s"#scheduleExalateOrUpdate scheduling an update for ${issueKey.getEntityType} ${issueKey.getIdStr} (${issueKey.getURN}) under twin trace ${twinTrace.getId} (remote twin trace ${twinTrace.getRemoteTwinTraceId}) using payload fetched from the issue tracker"
          )
          scheduleSyncWithPayloadFromTracker(
            issueKey,
            connection,
            scheduleAction,
            updateHubIssueOption,
            Option(twinTrace)
          )
      }
    } else {
      LOG.debug(
        s"#scheduleExalateOrUpdate NOT scheduling an update for ${issueKey.getEntityType} ${issueKey.getIdStr} (${issueKey.getURN}) under twin trace ${twinTrace.getId} (remote twin trace ${twinTrace.getRemoteTwinTraceId}) since connection ${connection.getName} (${connection.getID}) is deactivated!"
      )
      Future.successful(None)
    }
  }

  private def scheduleExalate(
      issueKey: IIssueKey,
      connection: IConnection,
      scheduleAction: (
          IConnection,
          IIssueKey,
          IHubPayload,
          Option[ITwinTrace]
      ) => Future[Option[ISyncEvent]],
      updateHubIssueOption: Option[UpdateBasicHubIssue],
      issueOption: Option[IHubIssueReplica]
  ): Future[Option[ISyncEvent]] =
    if (connection.getStatus == ConnectionStatus.ACTIVE) {
      twinTraceRepository.getTwinTraceByLocalIssueKeyFuture(connection, issueKey).flatMap {
        twinTraceOption =>
          issueOption match {
            case Some(issue) =>
              val hubObjectVersion =
                SemanticVersionService.get(selfNodeInfoService.getMaxHubObjectVersion)
              val hubPayload = new BasicHubPayload(hubObjectVersion, issue)
              scheduleAction(connection, issueKey, hubPayload, twinTraceOption)
            case None        =>
              scheduleSyncWithPayloadFromTracker(
                issueKey,
                connection,
                scheduleAction,
                updateHubIssueOption,
                twinTraceOption
              )
          }
      }
    } else {
      Future.successful(None)
    }

  private def scheduleSyncWithPayloadFromTracker(
      issueKey: IIssueKey,
      connection: IConnection,
      scheduleAction: (
          IConnection,
          IIssueKey,
          IHubPayload,
          Option[ITwinTrace]
      ) => Future[Option[ISyncEvent]],
      issue: Option[UpdateBasicHubIssue],
      twinTraceOpt: Option[ITwinTrace]
  ): Future[Option[ISyncEvent]] =
    trackerHubObjectService
      .getHubPayloadFromTracker(issueKey, connection, issue)
      .map(h => (twinTraceOpt, h))
      .flatMap {
        case (ttOpt, Some(payload)) if payload.getHubIssue.isInstanceOf[BasicHubIssue] =>
          LOG.debug(
            s"#scheduleSyncWithPayloadFromTracker scheduling sync for ${issueKey.getEntityType} ${issueKey.getIdStr} (${issueKey.getURN})"
          )
          val mergedIssue = mergeIssues(payload.getHubIssue.asInstanceOf[BasicHubIssue], issue)
          val updatedPayload =
            new BasicHubPayload(payload.getVersion, mergedIssue, payload.getIssueUrl)
          scheduleAction(connection, issueKey, updatedPayload, ttOpt)
        case (ttOpt, Some(payload))                                                    =>
          LOG.debug(
            s"#scheduleSyncWithPayloadFromTracker scheduling sync for ${issueKey.getEntityType} ${issueKey.getIdStr} (${issueKey.getURN})"
          )
          scheduleAction(connection, issueKey, payload, ttOpt)
        case (_, None)                                                                 =>
          LOG.warn(s"Sync or pair event was not scheduled for ${issueKey.getURN} as the issue could not be found by exalate")
          Future.successful(None)
      }
      .recover {
        case e: CategorizedException =>
          LOG.error(
            s"Exception occurred while scheduling sync or pair event for local issue `$issueKey`, connection `${connection.getName}`.",
            e
          )
          val context = SyncContext(connection = Some(connection), localIssueKeyOpt = Some(issueKey))
          val actTypeOpt = twinTraceOpt.map(_ => ErrorActType.SYNC).orElse(Option(ErrorActType.PAIR))
          errorHandler.handleScheduleError(e, context, actTypeOpt)
          None
        case e: Exception            =>
          LOG.error(
            s"Exception occurred while scheduling sync or pair event for local issue `$issueKey`, connection `${connection.getName}`.",
            e
          )
          val context = SyncContext(connection = Some(connection), localIssueKeyOpt = Some(issueKey))
          val actTypeOpt = twinTraceOpt.map(_ => ErrorActType.SYNC).orElse(Option(ErrorActType.PAIR))
          val bugException = bugExceptionCategoryService.generateBugException(Some(e), None)
          errorHandler.handleScheduleError(bugException, context, actTypeOpt)
          None
      }

}
