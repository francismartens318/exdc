package com.exalate.replication.services.replication.worker

import akka.actor.{ActorRef, ActorSystem}
import com.exalate.replication.services.api.config.IConnectionService
import com.exalate.replication.services.api.error.IErrorService
import com.exalate.replication.services.api.node.lifecycle.ILifecycleInfoService
import com.exalate.replication.services.api.replication.impersonation.IAuditLogService
import com.exalate.replication.services.api.replication.in.{IPollSchedulerService, IPollerService}
import com.exalate.replication.services.api.replication.worker.IWorkerNotificationService
import com.exalate.replication.services.api.trigger.{
  ITrackerUpdatePollSchedulerService,
  ITriggerSchedulerService
}
import com.exalate.replication.services.error.retry.RateLimitedTaskProcessorActor
import com.exalate.replication.services.message.worker.{
  InMessageActor,
  MessageBatcherActor,
  MessageSenderActor,
  MessageUnbatcherActor
}
import com.google.inject.name.Named
import com.google.inject.{Inject, Singleton}
import play.api.Logger
import play.api.db.evolutions.ApplicationEvolutions
import play.api.inject.ApplicationLifecycle

import scala.concurrent.duration._
import scala.concurrent.{ExecutionContext, Future}

@Singleton
class WorkerSchedulerService @Inject() (
    applicationEvolutions: ApplicationEvolutions,
    @Named("status-worker-actor") statusWorkerActor: ActorRef,
    @Named("error-worker-actor") errorWorkerActor: ActorRef,
    @Named("rate-limited-task-processor-actor") rateLimitedTaskProcessorActor: ActorRef,
    @Named("message-batcher-actor") messageBatcherActor: ActorRef,
    @Named("message-unbatcher-actor") messageUnbatcherActor: ActorRef,
    @Named("incoming-message-actor") incomingMessageActor: ActorRef,
    @Named("message-sender-actor") messageSenderActor: ActorRef,
    @Named("connection-draft-actor") connectionDraftActor: ActorRef,
    @Named("poll-worker-actor") pollWorkerActor: ActorRef,
    system: ActorSystem,
    errorService: IErrorService,
    triggerSchedulerService: ITriggerSchedulerService,
    trackerUpdatePollSchedulerService: ITrackerUpdatePollSchedulerService,
    pollSchedulerService: IPollSchedulerService,
    lifecycle: ApplicationLifecycle,
    lifecycleInfoService: ILifecycleInfoService,
    auditLogService: IAuditLogService,
    workerNotificationService: IWorkerNotificationService
)(implicit ec: ExecutionContext) {

  private val LOG = Logger("application.services.replication.worker.WorkerSchedulerService")

  LOG.info("Starting workers")

  LOG.info("Deleting all partial audit logs")
  auditLogService
    .deleteAllPartialAuditLogs()
    .map(_ => workerNotificationService.fireAllWorkerNotifications())

  LOG.info("WorkerSchedulerService is looking for active connections with `POLL` ReceiveProtocol")

  triggerSchedulerService.addSchedule() // scheduling for pairEvents
  trackerUpdatePollSchedulerService.addSchedule()

  val rateLimitedTaskProcessingInterval: FiniteDuration = 5.seconds
  val statusCheckInterval: FiniteDuration = 20.seconds
  val resolveErrorsInterval: FiniteDuration = 50.seconds

  LOG.info(s"Checking remote status interval duration set to ${statusCheckInterval.length} seconds")

  private val checkStatusSchedule = system.scheduler.scheduleWithFixedDelay(
    10.seconds,
    statusCheckInterval,
    statusWorkerActor,
    ReviewInvitationStatus
  )

  private val processMessagesSchedule = system.scheduler.scheduleWithFixedDelay(
    5.seconds,
    statusCheckInterval,
    messageBatcherActor,
    MessageBatcherActor.ProcessMessages
  )

  private val processIncomingChunksIntoMessagesSchedule = system.scheduler.scheduleWithFixedDelay(
    5.seconds,
    statusCheckInterval,
    messageUnbatcherActor,
    MessageUnbatcherActor.ProcessIncomingChunksIntoMessages
  )

  private val sendMessagesSchedule = system.scheduler.scheduleWithFixedDelay(
    5.seconds,
    statusCheckInterval,
    messageSenderActor,
    MessageSenderActor.SendMessages
  )

  private val incomingMessageSchedule = system.scheduler.scheduleWithFixedDelay(
    5.seconds,
    statusCheckInterval,
    incomingMessageActor,
    InMessageActor.ProcessIncomingMessagesInReadyStatus
  )

  private val checkConnectionDraftStatusSchedule = system.scheduler.scheduleWithFixedDelay(
    30.seconds,
    statusCheckInterval,
    connectionDraftActor,
    ConnectionDraftWorkerActor.DeleteOldConnectionDrafts
  )

  private val resolveErrorsSchedule = system.scheduler.scheduleWithFixedDelay(
    30.seconds,
    resolveErrorsInterval,
    errorWorkerActor,
    ErrorWorkerActor.ResolveErrors
  )

  LOG.info(
    s"Processing Rate Limited Tasks interval duration set to ${rateLimitedTaskProcessingInterval.length} seconds"
  )

  private val rateLimitedTaskProcessorSchedule = system.scheduler.scheduleWithFixedDelay(
    5.seconds,
    rateLimitedTaskProcessingInterval,
    rateLimitedTaskProcessorActor,
    RateLimitedTaskProcessorActor.Process
  )

  private val pollerSchedule = system.scheduler.scheduleOnce(
    5.seconds,
    pollWorkerActor,
    PollWorkerActor.PollAll()
  )

  errorService.resolveAllErrors
  lifecycleInfoService.ensureLifecycle()

  lifecycle.addStopHook { () =>
    // onStop
    Future.successful {
      LOG.info("Stopping workers")
      checkStatusSchedule.cancel()
      processMessagesSchedule.cancel()
      processIncomingChunksIntoMessagesSchedule.cancel()
      sendMessagesSchedule.cancel()
      incomingMessageSchedule.cancel()
      checkConnectionDraftStatusSchedule.cancel()
      resolveErrorsSchedule.cancel()
      rateLimitedTaskProcessorSchedule.cancel()
      pollerSchedule.cancel()
      pollSchedulerService.removeAllSchedules()
      triggerSchedulerService.removeSchedule()
      trackerUpdatePollSchedulerService.removeAllSchedules()
    }
  }
}
