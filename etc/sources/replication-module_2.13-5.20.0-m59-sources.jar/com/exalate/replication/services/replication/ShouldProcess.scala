package com.exalate.replication.services.replication

sealed trait ShouldProcess

final case object KeepProcess extends ShouldProcess

final case object StopProcess extends ShouldProcess
