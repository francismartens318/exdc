package com.exalate.replication.services.replication.mapping

import com.exalate.api.ILoggingService
import com.exalate.api.domain.IIssueKey
import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.connection.fieldvalues.ConnectionMode
import com.exalate.api.domain.editor.error.EditorErrorSide
import com.exalate.api.domain.editor.mappings.MappingType
import com.exalate.api.domain.hubobject.IHubIssueReplica
import com.exalate.api.domain.hubobject.v1_2.{HubCustomFieldType, IHubCustomField, IHubLabel}
import com.exalate.api.domain.request.ISyncRequest
import com.exalate.api.exception.RetriableException
import com.exalate.api.exception.bug.BugException
import com.exalate.api.exception.script.editor.{
  MappingLocalFieldNotFoundException,
  MappingLocalValueDisabledException,
  MappingLocalValueNotFoundException
}
import com.exalate.api.exception.script.{ScriptException, ScriptProcessors}
import com.exalate.api.hubobject.jira.{IAttachmentHelper, ICommentHelper}
import com.exalate.api.persistence.mappings.IMappingsRepository
import com.exalate.api.persistence.twintrace.ITwinTraceRepository
import com.exalate.api.processor.IExalateProcessor
import com.exalate.basic.domain.hubobject.v1._
import com.exalate.domain.editor._
import com.exalate.domain.editor.mappings.Arrow._
import com.exalate.domain.editor.mappings.AttachmentFilterValueUnit.toBytes
import com.exalate.domain.editor.mappings.{Arrow, _}
import com.exalate.domain.exception.editor._
import com.exalate.domain.transport.trackeroptions.EditorFields._
import com.exalate.domain.transport.trackeroptions.{EditorFields, RecoveryKey}
import com.exalate.domain.values.connection.ConnectionValue
import com.exalate.domain.values.{EditorFieldTypeValue, EditorFieldValue, NodeInfoValue}
import com.exalate.replication.services.api.issuetracker.IInstanceEditorFieldService
import com.exalate.replication.services.api.issuetracker.script.{
  IExalateHelper,
  IScriptGeneratorService
}
import com.exalate.replication.services.api.processor.{
  IScriptVariableService,
  IScriptVariableServiceFactory,
  LocalInstanceAggregate
}
import com.exalate.replication.services.api.replication.mapping.{
  IMappingService,
  ITrackerMatchHelper
}
import com.exalate.replication.services.api.replication.scope.ITrackerScopeAndMappingHelper
import com.exalate.replication.services.processor._
import com.exalate.replication.services.script._
import com.exalate.replication.services.transport.v1.rest.NodeInfoProvider
import com.exalate.services.utils.FutureUtils
import com.exalate.util.json.gson.GsonCaseClassValueJsonService
import com.google.inject.Inject
import groovy.lang.Closure
import org.apache.commons.lang3.exception.ExceptionUtils

import java.{lang, util}
import scala.collection.JavaConverters
import scala.collection.JavaConverters._
import scala.concurrent.{ExecutionContext, Future}
import scala.util.{Failure, Success, Try}

class MappingService @Inject() (
    processor: IExalateProcessor,
    mappingsRepository: IMappingsRepository,
    scriptVariableServiceFactory: IScriptVariableServiceFactory,
    trackerScopeAndMappingHelper: ITrackerScopeAndMappingHelper,
    loggingService: ILoggingService,
    commentHelper: ICommentHelper,
    attachmentHelper: IAttachmentHelper,
    twinTraceRepository: ITwinTraceRepository,
    nodeInfoProvider: NodeInfoProvider,
    instanceEditorFieldService: IInstanceEditorFieldService,
    trackerMatchHelper: ITrackerMatchHelper,
    scriptGeneratorService: IScriptGeneratorService,
    exalateHelper: IExalateHelper
)(implicit ec: ExecutionContext)
    extends IMappingService {

  private val scriptVariableService: IScriptVariableService =
    scriptVariableServiceFactory.getScriptVariableService()

  /** Performs visual mapping rules in order form a replica and send entity data to the remote side
    * (kind of outgoing rules) It is called from
    * {@link com.exalate.replication.services.processor.CreateReplicaProcessor}
    * @param ruleExecutionParams
    * @return
    *   prepared replica
    */
  def send(ruleExecutionParams: OutRuleExecutionParams): Future[BasicHubIssue] =
    ruleExecutionParams match {
      case OutRuleExecutionParams(
            localIssueKey: IIssueKey,
            connection: IConnection,
            issueHubReplica: IHubIssueReplica,
            replica: IHubIssueReplica,
            context: util.HashMap[String, Object]
          ) =>
        val issue = issueHubReplica.asInstanceOf[BasicHubIssue]
        ConnectionMode.values().find(_.name() == connection.getMode) match {
          case None    => Future.successful(replica.asInstanceOf[BasicHubIssue])
          case Some(_) =>
            for {
              mappings <- mappingsRepository.getByConnectionId(connection.getID)
              result <- mappings.foldLeft(Future.successful(issue)) {
                case (result, m @ Mappings(_, _, _, _, _, _, _, Some(outScript))) =>
                  result.flatMap { _ =>
                    val swapSides =
                      Option(issue.get(ScriptGeneratorService.EXALATE_SCOPE_SIDE)) match {
                        case Some(value) => value.equals(EditorErrorSide.REMOTE.toString)
                        case _           => true
                      }
                    executeOutScriptRule(m, outScript, swapSides, ruleExecutionParams)
                  }
                case (result, Mappings(_, _, Some(local), _, _, _, _, _))         =>
                  result.flatMap(applyFilters(local, _))
                case (result, _)                                                  =>
                  result
              }
            } yield result // TODO we currently expose everything, but the intention is that the rules are scanned and influence what is exposed
        }
    }

  /** Distinguish whether we need to send data using visual mapping rules or to receive
    * @param arrow
    *   L (left), R (right), LR (both direction)
    * @param swapSides
    *   whether we need to swap side or not (basicaly for local connections)
    * @param receivingFieldKey
    * @param receivingEditorField
    * @param issue
    * @param receivingEditorFieldValues
    * @return
    *   true or false
    */
  private def shouldReceive(
      arrow: String,
      swapSides: Boolean,
      receivingFieldKey: String,
      receivingEditorField: Option[EditorFieldValue],
      issue: BasicHubIssue,
      receivingEditorFieldValues: Seq[EditorFieldValue]
  ): Boolean = {
    val lr = arrow == LR.toString
    lazy val correctDirection =
      if (swapSides) arrow == R.toString
      else arrow == L.toString
    // TODO JCLOUD-1369 replace with field dependencies
    lazy val notEpicNameException = {
      val isEpicNameField = receivingEditorField.exists(_.label == "Epic Name")
      lazy val receivingIssueTypeOpt = getIssueValueByKey(
        issue,
        ISSUE_TYPE.toString,
        receivingEditorFieldValues.find(_.key == ISSUE_TYPE.toString)
      )
      lazy val notEpic = receivingIssueTypeOpt.exists(_.value != "Epic")
      val epicNameException =
        isEpicNameField && notEpic // if you're trying to receive epic name field into any other field than epic
      !epicNameException
    }
    lazy val notParentIdException = true
    // END: JCLOUD-1369 replace with field dependencies
    (lr || correctDirection) && notEpicNameException && notParentIdException
  }

  /** Performs visual mapping rules in order to form an issue/entity from obtained replica and
    * further create or update the issue/entity
    *
    * @param visualRuleExecutionParams
    *   containes connection, list of traces, issue, issueBeforeUpdating, replica, seq of
    *   blobMetadata, map of context, syncRequest
    * @return
    *   new issue with applied visual rules
    */
  override def receive(
      params: VisualRuleExecutionParams
  ): Future[BasicHubIssue] = {
    val replica = params.context.get("replica").asInstanceOf[BasicHubIssue]
    replica.lock()

    lazy val localFieldValuesFuture = instanceEditorFieldService.getLocalEditorFieldValues()
    lazy val remoteFieldValuesFuture =
      if (params.connection.isLocal) localFieldValuesFuture
      else
        Future.successful(
          instanceEditorFieldService.getRemoteEditorFieldValues(params.connection.getRemoteInstance)
        )

    for {
      mappingsSeq <- mappingsRepository.getByConnectionId(params.connection.getID)
      swapSides <- shouldSwapSides(params.syncRequest)
      r <- mappingsSeq.foldLeft(Future.successful(params.issue)) { (updatedFuture, ms) =>
        ms match {
          case Mappings(_, _, Some(local), Some(arrow), maps, Some(remote), None, _) =>
            for {
              updated <- updatedFuture
              localFieldValues <- localFieldValuesFuture
              remoteFieldValues <- remoteFieldValuesFuture
              updatedByMapping <- applyMapping(
                ms,
                local,
                remote,
                arrow,
                maps,
                updated,
                replica,
                params.syncRequest,
                swapSides,
                localFieldValues,
                remoteFieldValues
              )
            } yield updatedByMapping
          case Mappings(_, _, _, _, _, _, Some(scripts), _)                          =>
            for {
              _ <- updatedFuture
              updatedByMapping <- executeInScriptRule(
                ms,
                scripts,
                swapSides,
                params
              )
            } yield updatedByMapping
        }
      }
    } yield r
  }

  /** Process mapping: namely generates script rules based on the visual mapping (for forward
    * compatibility) and upserts it to DB
    * @param connection
    * @param connectionValue
    * @return
    *   seq of mapping values with generated scripts
    */
  override def processMappings(
      connection: IConnection,
      connectionValue: ConnectionValue
  ): Future[Seq[MappingValue]] =
    connectionValue.mappings
      .map { mappings =>
        if (mappings.nonEmpty) {
          val localFieldValuesFuture = instanceEditorFieldService.getLocalEditorFieldValues()
          val remoteFieldValuesFuture =
            if (connection.isLocal) localFieldValuesFuture
            else
              Future.successful(
                instanceEditorFieldService.getRemoteEditorFieldValues(connection.getRemoteInstance)
              )

          val localFieldValues = FutureUtils.resultInf(localFieldValuesFuture)
          val remoteFieldValues = FutureUtils.resultInf(remoteFieldValuesFuture)
          val mappingsUpdated = mappings.map { mappingValue =>
            val mV = mappingValue.`type` match {
              case MappingType.MAPPING =>
                scriptGeneratorService.generateScriptRules(
                  mappingValue,
                  connectionValue,
                  localFieldValues,
                  remoteFieldValues
                ) match {
                  case (Success(inscriptStr), Success(outscriptStr)) =>
                    mappingValue.copy(script = Some(inscriptStr), outScript = Some(outscriptStr))
                  case (Failure(exception), _)                       =>
                    val errorMessage =
                      s"Failed to generate mapping incoming scripts for local field ${mappingValue.local
                          .map(_.field.key)
                          .orNull} and remote field ${mappingValue.remote.map(_.field.key).orNull} "
                    throw ScriptEditorException(
                      errorMessage,
                      mappingValue.toMappings(connection.getID),
                      Some(exception)
                    )
                  case (_, Failure(exception))                       =>
                    val errorMessage =
                      s"Failed to generate mapping outgoing scripts for local field ${mappingValue.local
                          .map(_.field.key)
                          .orNull} and remote field ${mappingValue.remote.map(_.field.key).orNull} "
                    throw ScriptEditorException(
                      errorMessage,
                      mappingValue.toMappings(connection.getID),
                      Some(exception)
                    )
                }

              case MappingType.SCRIPT => mappingValue
              case _                  => mappingValue
            }
            // making sure that only non-empty out-script is upserted
            mV.copy(
              outScript = mV.outScript
                .filter(_.trim.nonEmpty)
            )
          }

          mappingsRepository.upsert(mappingsUpdated, connection.getID).map(_ => mappingsUpdated)
        } else {
          Future.successful(Nil)
        }

      }
      .getOrElse(Future.successful(Seq()))

  /** Executes Incoming Script Rules
    * @param m
    *   Mappings
    * @param script
    * @param swapSides
    *   true or false
    * @param visualRuleExecutionParams
    * @return
    *   issue after rules are applied
    */
  private def executeInScriptRule(
      m: Mappings,
      script: String,
      swapSides: Boolean,
      visualRuleExecutionParams: VisualRuleExecutionParams
  ) = visualRuleExecutionParams match {
    case VisualRuleExecutionParams(
          connection,
          traces,
          issue,
          issueBeforeUpdating,
          replica,
          blobMetadataSeq,
          context,
          syncRequest
        ) =>
      val sendingInstanceName =
        if (swapSides) connection.getLocalInstanceName
        else connection.getRemoteInstance.getName
      val receivingInstanceName =
        if (swapSides) connection.getRemoteInstance.getName
        else connection.getLocalInstanceName

      val ctx = new util.HashMap[String, Object](
        scriptVariableService.updateIncomingSyncContext(
          context,
          connection,
          issue,
          replica,
          m,
          swapSides,
          sendingInstanceName,
          receivingInstanceName
        )
      )

      val f = Future.fromTry(
        Try {
          CreateIssueProcessor.threadLocalContext.set(ctx)
          ChangeIssueProcessor.threadLocalContext.set(ctx)
          processor.executeProcessor(script, ctx, ScriptProcessors.RULE)
          val updatedIssue = context.get("issue").asInstanceOf[BasicHubIssue]
          updatedIssue
        }
          .recoverWith {
            case e: ScriptException =>
              val ts =
                JavaConverters.asScalaBufferConverter(ExceptionUtils.getThrowableList(e)).asScala
              ts.reverse
                .foldLeft(Option.empty[Exception]) {
                  case (eOpt @ Some(_), _) => eOpt // found a handled exception
                  case (None, cause)
                      if cause.isInstanceOf[RetriableException] || cause
                        .isInstanceOf[EditorCategorizedException] =>
                    Some(cause.asInstanceOf[Exception])
                  case _                   => None
                } match {
                case Some(handledException) =>
                  Failure(handledException)
                case None                   =>
                  val message = Option(ExceptionUtils.getRootCauseMessage(e))
                    .getOrElse(
                      s"The script: \n```\n$script\n```\nfailed with the following exception: ${Option(
                          e.getCause
                        ).getOrElse(e).getClass.getSimpleName}"
                    )
                  val exception = ScriptEditorException(message, m, Some(e))
                  Failure(exception)
              }
          }
      )
      CreateIssueProcessor.threadLocalContext.remove()
      ChangeIssueProcessor.threadLocalContext.remove()
      f
  }

  /** Executes Outgoing Script Rules
    * @param m
    *   Mappings
    * @param script
    * @param swapSides
    * @param outRuleExecutionParams
    * @return
    *   formed replica based on the rules
    */
  private def executeOutScriptRule(
      m: Mappings,
      script: String,
      swapSides: Boolean,
      params: OutRuleExecutionParams
  ): Future[BasicHubIssue] = {
    val sendingInstanceName =
      if (swapSides) params.connection.getLocalInstanceName
      else params.connection.getRemoteInstance.getName

    val localInstance = new LocalInstanceAggregate(params.issue.asInstanceOf[BasicHubIssue])

    if (VariableNameScriptService.isValidGroovyVariableName(sendingInstanceName)) {
      params.context.put(sendingInstanceName, localInstance)
    }
    val on = new util.HashMap[String, Object]()
    on.put(sendingInstanceName, localInstance)
    params.context.put(VariableNameScriptService.instanceWrapperVariableName, on)
    params.context.put(
      "ExalateAPI",
      JavaConverters
        .mapAsJavaMapConverter(
          Map(
            FieldDataType.OPTION.toString -> new OptionExalateAPI(trackerScopeAndMappingHelper),
            FieldDataType.DATE.toString -> new DateExalateAPI(),
            FieldDataType.TEXT.toString -> new TextExalateAPI(trackerScopeAndMappingHelper),
            FieldDataType.USER.toString -> new UserExalateAPI(trackerScopeAndMappingHelper),
            FieldDataType.MULTI.toString -> JavaConverters
              .mapAsJavaMapConverter(
                Map(
                  FieldDataType.FILE.toString -> new MultiFileExalateAPI(attachmentHelper),
                  FieldDataType.COMMENT.toString -> new MultiCommentExalateAPI(),
                  FieldDataType.TEXT.toString -> new MultiTextExalateAPI()
                )
              )
              .asJava
          )
        )
        .asJava
    )
    params.context.put("ExalateHelper", exalateHelper)

    params.context.put(
      "executionInstanceName",
      sendingInstanceName
    ) // since it is outgoing rule executionInstanceName == sendingInstanceName
    params.context.put("sendingInstanceName", sendingInstanceName)

    params.context.put("swapSides", new lang.Boolean(swapSides))
    params.context.put("mappings", m)

    val f = Future.fromTry(
      Try {
        CreateReplicaProcessor.threadLocalContext.set(params.context)
        val returned = processor.executeProcessor(script, params.context, ScriptProcessors.RULE)
        val result = Option(returned)
          .collect { case bhi: BasicHubIssue => bhi }
          .getOrElse(params.issue.asInstanceOf[BasicHubIssue])
        result
      }
        .recoverWith {
          case e: ScriptException =>
            val ts =
              JavaConverters.asScalaBufferConverter(ExceptionUtils.getThrowableList(e)).asScala
            ts.reverse
              .foldLeft(Option.empty[Exception]) {
                case (eOpt @ Some(_), _) => eOpt // found a handled exception
                case (None, cause)
                    if cause.isInstanceOf[RetriableException] || cause
                      .isInstanceOf[EditorCategorizedException] =>
                  Some(cause.asInstanceOf[Exception])
                case _                   => None
              } match {
              case Some(handledException) =>
                Failure(handledException)
              case None                   =>
                val message = Option(ExceptionUtils.getRootCauseMessage(e))
                  .getOrElse(
                    s"The script: \n```\n$script\n```\nfailed with the following exception: ${Option(
                        e.getCause
                      ).getOrElse(e).getClass.getSimpleName}"
                  )
                val exception = ScriptEditorException(message, m, Some(e))
                Failure(exception)
            }
        }
    )
    CreateReplicaProcessor.threadLocalContext.remove()
    f
  }

  /** Applies filter of the mapping rules, especially it is related to size of attachments, type of
    * comments
    * @param inputFieldType
    * @param filterInput
    * @return
    */
  private def applyFilters(
      inputFieldType: MappingFieldTypeValue,
      filterInput: BasicHubIssue
  ): Future[BasicHubIssue] =
    inputFieldType.filters.toSeq.flatten
      .foldLeft(Future.successful(filterInput)) {
        case (inputFilteredAccumulator, inputFilter) =>
          inputFilteredAccumulator.flatMap(applyFilter(inputFieldType, _, inputFilter))
      }

  /** Process of applying filted of attachments and comments
    * @param field
    * @param issueOrReplica
    * @param filter
    * @return
    */
  def applyFilter(
      field: MappingFieldTypeValue,
      issueOrReplica: BasicHubIssue,
      filter: FilterKey
  ): Future[BasicHubIssue] = {
    EditorFields.withNameOpt(field.field.key) match {
      case Some(ATTACHMENTS) =>
        if (filter.isActive.contains(true)) {
          (AttachmentFilters.withNameOpt(filter.key), filter.value) match {
            case (
                  Some(AttachmentFilters.SKIP_FILESIZE_LESS_THAN),
                  Some(FilterKeyValue(unit, value))
                ) =>
              issueOrReplica.setAttachments(
                filterNotFn(issueOrReplica.getAttachments, f => f.getFilesize < toBytes(unit, value))
              )
            case (
                  Some(AttachmentFilters.SKIP_FILESIZE_LESS_OR_EQUAL),
                  Some(FilterKeyValue(unit, value))
                ) =>
              issueOrReplica.setAttachments(
                filterNotFn(issueOrReplica.getAttachments, f => f.getFilesize <= toBytes(unit, value))
              )
            case (
                  Some(AttachmentFilters.SKIP_FILESIZE_GREATER_OR_EQUAL),
                  Some(FilterKeyValue(unit, value))
                ) =>
              issueOrReplica.setAttachments(
                filterNotFn(issueOrReplica.getAttachments, f => f.getFilesize >= toBytes(unit, value))
              )
            case (
                  Some(AttachmentFilters.SKIP_FILESIZE_GREATER_THAN),
                  Some(FilterKeyValue(unit, value))
                ) =>
              issueOrReplica.setAttachments(
                filterNotFn(issueOrReplica.getAttachments, f => f.getFilesize > toBytes(unit, value))
              )
            case (None, _) =>
              loggingService.error(
                s"BUG: it is possible to configure an attachment filter `$filter.key`"
              )
            case (_, None) =>
              loggingService.error(
                s"BUG: it is possible to configure an attachment filter `$filter.key` without a unit and a value"
              )
          }
        }
      case Some(COMMENTS)    =>
        CommentFilters.withNameOpt(filter.key) match {
          case Some(CommentFilters.SKIP_ALL)      =>
            issueOrReplica.setComments(new util.ArrayList[BasicHubComment]())
          case Some(CommentFilters.SKIP_NONE)     =>
          case Some(CommentFilters.SKIP_EXTERNAL) =>
            issueOrReplica.setComments(
              filterNotFn(
                issueOrReplica.getComments,
                c =>
                  !c.isInternal && (Option(c.getGroupLevel).isEmpty && Option(
                    c.getRoleLevel
                  ).isEmpty)
              )
            )
          case Some(CommentFilters.SKIP_INTERNAL) =>
            issueOrReplica.setComments(
              filterNotFn(
                issueOrReplica.getComments,
                c =>
                  c.isInternal || Option(c.getGroupLevel).isDefined || Option(
                    c.getRoleLevel
                  ).isDefined
              )
            )
          case None                               =>
            loggingService.error(s"BUG: it is possible to configure a comment filter `$filter.key`")
        }
      case _                 =>
    }
    Future.successful(issueOrReplica)
  }

  /** Visual mapping rules execution process
    * @param m
    *   Mappings
    * @param localField
    * @param remoteField
    * @param arrow
    * @param mapsOpt
    * @param issue
    * @param replica
    * @param syncRequest
    * @param swapSides
    * @param receivingEditorFieldValues
    * @param sendingEditorFieldValues
    * @return
    *   issue after rules were applied
    */
  def applyMapping(
      m: Mappings,
      localField: MappingFieldTypeValue,
      remoteField: MappingFieldTypeValue,
      arrow: String,
      mapsOpt: Option[Seq[MapValue]],
      issue: BasicHubIssue,
      replica: BasicHubIssue,
      syncRequest: ISyncRequest,
      swapSides: Boolean,
      receivingEditorFieldValues: Seq[EditorFieldValue],
      sendingEditorFieldValues: Seq[EditorFieldValue]
  ) = {
    val sendingField =
      if (swapSides) localField
      else remoteField
    val receivingField =
      if (swapSides) remoteField
      else localField

    val sendingEditorField = sendingEditorFieldValues.find(fv => fv.key == sendingField.field.key)
    val receivingEditorField =
      receivingEditorFieldValues.find(fv => fv.key == receivingField.field.key)

    val arrowOpt = Arrow.withNameOpt(arrow)
    val properArrow = (arrowOpt, swapSides) match {
      case (Some(a), true) => swapArrow(a).toString
      case _               => arrow
    }

    val isReceive = shouldReceive(
      arrow,
      swapSides,
      receivingField.field.key,
      receivingEditorField,
      issue,
      receivingEditorFieldValues
    )
    lazy val sentValueByKey = getIssueValueByKey(replica, sendingField.field.key, sendingEditorField)
    // apply the field mappings or maps
    val updated = mapsOpt match {
      case Some(maps) if isReceive =>
        // applyMaps(m, maps, issue, sentValueByKey, receivingField, swapSides, receivingEditorField, receivingEditorFieldValues)
        // iterate through maps and apply it in case the map matches
        applyMaps(
          m,
          maps,
          issue,
          sentValueByKey,
          receivingField,
          swapSides,
          receivingEditorField,
          sendingEditorField,
          receivingEditorFieldValues
        )
      case Some(_)                 =>
        Future.successful((true, issue))
      case None                    =>
        sentValueByKey match {
          case None if isReceive =>
            // if there's a mapping for the field, but no value was sent from the remote
            Future.successful((false, issue))
          case Some(sentFieldValue)
              if shouldReceive(
                properArrow,
                swapSides = false,
                receivingField.field.key,
                receivingEditorField,
                issue,
                receivingEditorFieldValues
              ) =>
            applyIssueValueByKey(
              m,
              receivingField,
              sendingField,
              issue,
              replica,
              receivingField.field.key,
              sentFieldValue,
              receivingEditorField,
              sendingEditorField,
              swapSides
            )
              .map((true, _)) // TODO double check recoverWith part
              .recoverWith {
                case _: MappingLocalValueNotFoundException if receivingEditorField.isDefined =>
                  val side =
                    if (swapSides) EditorErrorSide.REMOTE
                    else EditorErrorSide.LOCAL
                  Future.failed(
                    StaleCustomFieldMappingEditorException(m, side, receivingEditorField.get)
                  )
                case e                                                                       =>
                  val side =
                    if (swapSides) EditorErrorSide.REMOTE
                    else EditorErrorSide.LOCAL
                  Future.failed(
                    OverallMappingEditorException(e.getMessage, m, side, receivingEditorField.get)
                  )
              }
          case _                 =>
            Future.successful((true, issue))
        }
    }
    for {
      (matchWasFound, updatedIssue) <- updated
        .recoverWith {
          case _: MappingLocalValueNotFoundException => Future.successful((false, issue))
        }

      // recovery
      result <-
        if (!matchWasFound && isReceive)
          applyRecovery(
            m,
            receivingField,
            sendingField,
            properArrow,
            sentValueByKey,
            updatedIssue,
            syncRequest,
            receivingEditorField,
            sendingEditorField,
            swapSides
          )
        else Future.successful(updatedIssue)
    } yield result
  }

  /** Check whether we need to swap sides (basically for local connection)
    * @param syncRequest
    * @return
    */
  private def shouldSwapSides(syncRequest: ISyncRequest) =
    if (syncRequest.getConnection.isLocal)
      twinTraceRepository
        .getTwinTraceById(syncRequest.getRemoteTwinTraceId)
        .map(_.exists(!_.isUseRemoteScope))
    else Future.successful(false)

  /** Swaps arrows in mapping rules
    * @param arrow
    * @return
    */
  private def swapArrow(arrow: Arrow): Arrow =
    arrow match {
      case L => R
      case R => L
      case _ => arrow
    }

  /** Visual mapping maps applying process
    * @param m
    *   mappings
    * @param maps
    * @param issue
    * @param replicaValueByKey
    * @param fieldToSet
    * @param swapSides
    * @param receivingEditorFieldOpt
    * @param sendingEditorFieldOpt
    * @param receivingEditorFieldValues
    * @tparam LV
    * @return
    */
  private def applyMaps[LV](
      m: Mappings,
      maps: Seq[MapValue],
      issue: BasicHubIssue,
      replicaValueByKey: Option[FieldValue[_]],
      fieldToSet: MappingFieldTypeValue,
      swapSides: Boolean,
      receivingEditorFieldOpt: Option[EditorFieldValue],
      sendingEditorFieldOpt: Option[EditorFieldValue],
      receivingEditorFieldValues: Seq[EditorFieldValue]
  ) =
    maps.foldLeft(Future.successful((false, issue))) { (matchWasFound, map) =>
      val receivingValue =
        if (swapSides) map.remote
        else map.local
      val expectedSentValue =
        if (swapSides) map.local
        else map.remote

      val isShouldReceive = shouldReceive(
        map.arrow,
        swapSides,
        fieldToSet.field.key,
        receivingEditorFieldOpt,
        issue,
        receivingEditorFieldValues
      )
      val isNotSetAlready = !FutureUtils.toTry(matchWasFound).map(_._1).toOption.contains(true)
      val sentValueIsMatched =
        applyMatch(replicaValueByKey, fieldToSet, expectedSentValue, sendingEditorFieldOpt)
      val isIssueMatchesLocalMapValue = isShouldReceive && isNotSetAlready && sentValueIsMatched

      if (isIssueMatchesLocalMapValue)
        setIssueValueByKey(
          issue,
          fieldToSet.field.key,
          FieldValue(fieldToSet.field.key, receivingValue),
          receivingEditorFieldOpt,
          sendingEditorFieldOpt
        )
          .recoverWith {
            case _: MappingLocalValueNotFoundException if receivingEditorFieldOpt.isDefined =>
              if (swapSides) {
                Future.failed(
                  MappingMapsEditorException(
                    m,
                    expectedSentValue,
                    receivingValue,
                    EditorErrorSide.REMOTE,
                    receivingEditorFieldOpt.get
                  )
                )
              } else {
                Future.failed(
                  MappingMapsEditorException(
                    m,
                    receivingValue,
                    expectedSentValue,
                    EditorErrorSide.LOCAL,
                    receivingEditorFieldOpt.get
                  )
                )
              }
            case _: MappingLocalValueDisabledException if receivingEditorFieldOpt.isDefined =>
              if (swapSides) {
                Future.failed(
                  MappingMapsDisabledEditorException(
                    m,
                    expectedSentValue,
                    receivingValue,
                    EditorErrorSide.REMOTE,
                    receivingEditorFieldOpt.get
                  )
                )
              } else {
                Future.failed(
                  MappingMapsDisabledEditorException(
                    m,
                    receivingValue,
                    expectedSentValue,
                    EditorErrorSide.LOCAL,
                    receivingEditorFieldOpt.get
                  )
                )
              }

            case _: MappingLocalFieldNotFoundException if receivingEditorFieldOpt.isDefined =>
              if (swapSides) {
                Future.failed(
                  StaleCustomFieldMappingEditorException(
                    m,
                    EditorErrorSide.REMOTE,
                    receivingEditorFieldOpt.get
                  )
                )
              } else {
                Future.failed(
                  StaleCustomFieldMappingEditorException(
                    m,
                    EditorErrorSide.LOCAL,
                    receivingEditorFieldOpt.get
                  )
                )
              }
          }
          .map(issue => (true, issue))
      else matchWasFound
    }

  private def applyMatch(
      replicaValueByKey: Option[FieldValue[_]],
      fieldToSet: MappingFieldTypeValue,
      expectedSentValue: String,
      sendingEditorFieldOpt: Option[EditorFieldValue]
  ): Boolean =
    sendingEditorFieldOpt match {
      case Some(editorField) if editorField.`type`.key == FieldDataType.USER.toString =>
        replicaValueByKey.exists { rv =>
          trackerMatchHelper.applyUserMatch(rv.value)(expectedSentValue)
        }
      case _ => replicaValueByKey.exists(rv => rv.value == expectedSentValue)
    }

  /** Visual recovery appling process
    * @param m
    *   Mappings
    * @param localField
    * @param remoteField
    * @param arrow
    * @param replicaValueByKey
    * @param issue
    * @param syncRequest
    * @param receivingEditorFieldValue
    * @param sendingEditorFieldValue
    * @param swapSides
    * @return
    *   issue after recovery values is applied
    */
  private def applyRecovery(
      m: Mappings,
      localField: MappingFieldTypeValue,
      remoteField: MappingFieldTypeValue,
      arrow: String,
      replicaValueByKey: Option[FieldValue[_]],
      issue: BasicHubIssue,
      syncRequest: ISyncRequest,
      receivingEditorFieldValue: Option[EditorFieldValue],
      sendingEditorFieldValue: Option[EditorFieldValue],
      swapSides: Boolean
  ) = {
    lazy val localNodeInfoFuture = nodeInfoProvider.get
    localField.recovery match {
      case Some(recovery) =>
        recovery.key match {
          case r if r == RecoveryKey.DEFAULT.toString =>
            getIssueValueFromRecovery(
              localField,
              recovery,
              localNodeInfoFuture,
              receivingEditorFieldValue
            )
              .flatMap {
                case Some(rv) =>
                  setIssueValueByKey(
                    issue,
                    localField.field.key,
                    rv,
                    receivingEditorFieldValue,
                    sendingEditorFieldValue
                  ).recoverWith {
                    case e
                        if e.isInstanceOf[MappingLocalValueNotFoundException] || e
                          .isInstanceOf[MappingLocalValueDisabledException] =>
                      if (swapSides) {
                        Future.failed(
                          RecoveryDefaultMappingEditorException(
                            m,
                            EditorErrorSide.REMOTE,
                            getHumanReadableValue(rv)
                          )
                        )
                      } else {
                        Future.failed(
                          RecoveryDefaultMappingEditorException(
                            m,
                            EditorErrorSide.LOCAL,
                            getHumanReadableValue(rv)
                          )
                        )
                      }

                    case _: MappingLocalValueNotFoundException
                        if receivingEditorFieldValue.isDefined =>
                      if (swapSides) {
                        Future.failed(
                          StaleCustomFieldMappingEditorException(
                            m,
                            EditorErrorSide.REMOTE,
                            receivingEditorFieldValue.get
                          )
                        )
                      } else {
                        Future.failed(
                          StaleCustomFieldMappingEditorException(
                            m,
                            EditorErrorSide.LOCAL,
                            receivingEditorFieldValue.get
                          )
                        )
                      }
                  }
                // Since we support only option and text fields, it is not allowed to set None value thus we have to return failed
                case None     =>
                  Future.failed(new BugException(s"No default value specified in recovery mapping"))
              }
          case r if r == RecoveryKey.ERROR.toString   =>
            val message = s"Problem with ${localField.field.key} field: cannot find mapping for " +
              s"`${replicaValueByKey.map(getHumanReadableValue).getOrElse("None")}` ${remoteField.field.key}. " +
              s"Please check the configuration."
            loggingService.error(message)
            if (swapSides) {
              Future.failed(
                RecoveryMappingEditorException(
                  m,
                  EditorErrorSide.REMOTE,
                  replicaValueByKey.map(getHumanReadableValue).getOrElse("None")
                )
              )
            } else {
              Future.failed(
                RecoveryMappingEditorException(
                  m,
                  EditorErrorSide.LOCAL,
                  replicaValueByKey.map(getHumanReadableValue).getOrElse("None")
                )
              )
            }
          case _                                      => // r if r == RecoveryKey.NONE.toString =>
            Future.successful(issue)
        }
      case None           =>
        Future.failed(
          new BugException(
            s"No recovery specified in mapping: `${localField.field.key}` ${Arrow.withNameOpt(arrow).map(arrowPseudoGraphic).getOrElse("???")} `${remoteField.field.key}`"
          )
        )
    }
  }

  /** Gets value from recovery field
    * @param localField
    * @param recovery
    * @param nodeInfoFuture
    * @param localFieldValueOpt
    * @return
    */
  private def getIssueValueFromRecovery(
      localField: MappingFieldTypeValue,
      recovery: Recovery,
      nodeInfoFuture: Future[NodeInfoValue],
      localFieldValueOpt: Option[EditorFieldValue]
  ): Future[Option[FieldValue[_]]] =
    localFieldValueOpt match {
      case Some(localFieldValue) =>
        localFieldValue.`type` match {
          case EditorFieldTypeValue(k, None) =>
            FieldDataType.withNameOpt(k) match {
              case Some(FieldDataType.OPTION) =>
                Future.successful(
                  recovery.value
                    .flatMap { o =>
                      GsonCaseClassValueJsonService
                        .write(o)
                        .flatMap(j =>
                          GsonCaseClassValueJsonService
                            .read[Map[String, Object]](j, classOf[Map[String, Object]])
                        )
                        .toOption
                        .flatMap(_.get("label"))
                        .map(_.asInstanceOf[String])
                    }
                    .map(v => FieldValue(localField.field.key, v))
                )
              case Some(FieldDataType.TEXT) | Some(FieldDataType.USER) | Some(
                    FieldDataType.COMMENT
                  ) =>
                Future.successful(
                  recovery.value
                    .flatMap { o =>
                      GsonCaseClassValueJsonService
                        .write(o)
                        .flatMap { j =>
                          // TODO ZENDESK-163 read into STRING
                          val asMap =
                            GsonCaseClassValueJsonService
                              .read[Map[String, Object]](j, classOf[Map[String, Object]])
                          if (asMap.toOption.isEmpty) {
                            val asString =
                              GsonCaseClassValueJsonService.read[String](j, classOf[String])
                            asString.map(str => Map("value" -> str))
                          } else {
                            asMap
                          }
                        }
                        .toOption
                        .flatMap(_.get("value"))
                        .map(_.asInstanceOf[String])
                    }
                    .map(v => FieldValue(localField.field.key, v))
                )
              case _                          => Future.successful(None)
            }
          case _                             => Future.successful(None)
        }
      case _                     => Future.successful(None)
    }

  // TODO consider removing FieldValue class altogether and rather convert any value to a human-readable (but strictly structured)
  /** gets Human Readable Value of the visual field
    * @param fv
    * @return
    *   Human Readable text of the provided field value
    */
  private def getHumanReadableValue(fv: FieldValue[_]): String =
    EditorFields.withNameOpt(fv.field) match {
      case Some(ISSUE_TYPE)  => fv.value.asInstanceOf[String]
      case Some(PROJECT)     => fv.value.asInstanceOf[String]
      case Some(SUMMARY)     => fv.value.asInstanceOf[String]
      case Some(PRIORITY)    => fv.value.asInstanceOf[String]
      case Some(STATUS)      => fv.value.asInstanceOf[String]
      case Some(DESCRIPTION) => fv.value.asInstanceOf[String]
      case Some(COMMENTS)    =>
        JavaConverters
          .asScalaBufferConverter(fv.value.asInstanceOf[java.util.List[BasicHubComment]])
          .asScala
          .map(c => s"${c.getAuthor.getKey}: ${c.getBody}")
          .mkString("; ")
      case Some(ATTACHMENTS) =>
        JavaConverters
          .asScalaBufferConverter(fv.value.asInstanceOf[java.util.List[BasicHubAttachment]])
          .asScala
          .map(a => s"${a.getAuthor.getKey}: ${a.getFilename}")
          .mkString("; ")
      case Some(ASSIGNEE)    => fv.value.asInstanceOf[String]
      case Some(REPORTER)    => fv.value.asInstanceOf[String]
      case _                 => fv.value.toString
    }

  /** Gets a value of the provided system field of the issue tracker entity.
    *
    * @param issue
    * @param fieldKey
    *   key of the desired field: PROJECT ISSUE_TYPE, SUMMARY, PRIORITY , STATUS, DESCRIPTION ,
    *   LABELS, COMMENTS, ATTACHMENTS , ASSIGNEE, REPORTER, DUE, AREA_PATH, ITERATION_PATH, etc
    *   (taken from {@link com.exalate.domain.transport.trackeroptions.EditorFields} )
    * @param editorFieldValue
    * @return
    */
  private def getIssueValueByKey(
      issue: BasicHubIssue,
      fieldKey: String,
      editorFieldValue: Option[EditorFieldValue]
  ): Option[FieldValue[_]] =
    EditorFields.withNameOpt(fieldKey) match {
      case Some(ISSUE_TYPE)  =>
        getIssueTypeFromReplica(issue)
          .map(FieldValue(fieldKey, _))
      case Some(PROJECT)     =>
        getProjectKeyFromReplica(issue)
          .map(FieldValue(fieldKey, _))
      case Some(SUMMARY)     =>
        Option(issue.getSummary)
          .flatMap {
            case "" => None
            case v  => Some(FieldValue(fieldKey, v))
          }
      case Some(PRIORITY)    =>
        Option(issue.getPriority)
          .map(_.getName)
          .map(FieldValue(fieldKey, _))
      case Some(STATUS)      =>
        Option(issue.getStatus)
          .map(_.getName)
          .map(FieldValue(fieldKey, _))
      case Some(DESCRIPTION) =>
        Option(issue.getDescription)
          .flatMap {
            case "" => None
            case v  => Some(FieldValue(fieldKey, v))
          }
      case Some(COMMENTS)    =>
        Option(issue.getComments)
          .map(FieldValue(fieldKey, _))
      case Some(ATTACHMENTS) =>
        Option(issue.getAttachments)
          .map(FieldValue(fieldKey, _))
      case Some(LABELS)      =>
        Option(issue.getLabels)
          .map(FieldValue(fieldKey, _))
      case Some(ASSIGNEE)    =>
        Option(issue.getAssignee)
          .map(FieldValue(fieldKey, _))
      case Some(REPORTER)    =>
        Option(issue.getReporter)
          .map(FieldValue(fieldKey, _))

      case _ =>
        // Traverse custom fields entry set to check if there is a custom field with same uid as sending field
        getCustomFieldByKey(issue, fieldKey)
          .flatMap(getFieldValue)
          .map(FieldValue(fieldKey, _))
      // TODO EXAEDIT-873: if getCustomFieldByKey == None => throw StaleCustomFieldMappingEditorException
      //      case _ => None //Future.failed(new BugException(s"Asked to get an unknown field `$key`. Known fields: `${EditorFields.values.mkString("`,`")}`"))
    }

  /** Gets a value of custom field
    * @param basicHubCustomField
    * @return
    */
  private def getFieldValue(basicHubCustomField: IHubCustomField): Option[AnyRef] =
    basicHubCustomField.getType match {
      case HubCustomFieldType.TEXT | HubCustomFieldType.STRING =>
        Option(basicHubCustomField.getValue)
      case HubCustomFieldType.OPTION                           =>
        Option(basicHubCustomField.getValue)
          .map(_.asInstanceOf[BasicHubOption])
          .flatMap(cf => Option(cf.getValue))
      case HubCustomFieldType.USER                             =>
        Option(basicHubCustomField.getValue)
          .map(_.asInstanceOf[BasicHubUser])
      case _                                                   =>
        Option(basicHubCustomField.getValue)
          .map(_.toString)
    }

  /** Sets a value to the provided system field of the issue tracker entity.
    * @param m
    *   Mappings
    * @param receivingField
    * @param sendingField
    * @param issue
    * @param replica
    * @param key
    * @param value
    * @param receivingFieldValue
    * @param sendingFieldValue
    * @param swapSides
    * @tparam RV
    * @return
    */
  private def applyIssueValueByKey[RV](
      m: Mappings,
      receivingField: MappingFieldTypeValue,
      sendingField: MappingFieldTypeValue,
      issue: BasicHubIssue,
      replica: BasicHubIssue,
      key: String,
      value: FieldValue[RV],
      receivingFieldValue: Option[EditorFieldValue],
      sendingFieldValue: Option[EditorFieldValue],
      swapSides: Boolean
  ): Future[BasicHubIssue] =
    EditorFields.withNameOpt(value.field) match {
      case Some(COMMENTS)    =>
        applyComments(
          m,
          receivingField,
          sendingField,
          issue,
          replica,
          value,
          sendingFieldValue,
          swapSides
        )
      case Some(ATTACHMENTS) =>
        issue.setAttachments(attachmentHelper.mergeAttachments(issue, replica))
        Future.successful(issue)
      case _ => setIssueValueByKey(issue, key, value, receivingFieldValue, sendingFieldValue)
    }

  // TODO Review if appliyng attributes should be done globally or to specific fields
  /** Applies comments rules to set value
    * @param m
    *   mappings
    * @param receivingField
    * @param sendingField
    * @param issue
    * @param replica
    * @param value
    * @param sendingEditorFieldValue
    * @param swapSides
    * @tparam RV
    * @return
    */
  private def applyComments[RV](
      m: Mappings,
      receivingField: MappingFieldTypeValue,
      sendingField: MappingFieldTypeValue,
      issue: BasicHubIssue,
      replica: BasicHubIssue,
      value: FieldValue[RV],
      sendingEditorFieldValue: Option[EditorFieldValue],
      swapSides: Boolean
  ): Future[BasicHubIssue] =
    receivingField.attributes match {
      case Some(a) =>
        val attributeOpt = a.headOption
        attributeOpt match {
          case Some(attribute) =>
            attribute.field.key match {
              case "AUTHOR" =>
                issue.setComments(
                  commentHelper.mergeComments(
                    issue,
                    replica,
                    new Closure[Object](commentHelper) {
                      override def call(comment: Object): Object =
                        if (comment.isInstanceOf[BasicHubComment]) {
                          val basicHubComment = comment.asInstanceOf[BasicHubComment]
                          val executorOpt = FutureUtils.resultInf(
                            trackerScopeAndMappingHelper.getUser(
                              basicHubComment.getAuthor,
                              None,
                              None
                            )
                          )

                          executorOpt match {
                            case Some(executor) =>
                              basicHubComment.setExecutor(executor)
                              basicHubComment
                            case None           =>
                              attribute.recovery match {
                                case Some(recovery) =>
                                  recovery.key match {
                                    case r if r == RecoveryKey.DEFAULT.toString =>
                                      FutureUtils.resultInf(
                                        getIssueValueFromRecovery(
                                          attribute,
                                          attribute.recovery.get,
                                          nodeInfoProvider.get,
                                          sendingEditorFieldValue
                                        )
                                          .map(
                                            _.map(rv =>
                                              trackerScopeAndMappingHelper
                                                .getUser(rv.value.asInstanceOf[String], None, None)
                                                .map(
                                                  _.map(executor =>
                                                    basicHubComment.setExecutor(executor)
                                                  )
                                                )
                                            )
                                          )
                                      )
                                    case r if r == RecoveryKey.ERROR.toString   =>
                                      val message = s"Problem with ${receivingField.field.key} field: cannot find mapping for " +
                                        s"`${getHumanReadableValue(value)}` ${sendingField.field.key}. " +
                                        s"Please check the configuration."
                                      loggingService.error(message)
                                      if (swapSides) {
                                        throw RecoveryMappingEditorException(
                                          m,
                                          EditorErrorSide.REMOTE,
                                          getHumanReadableValue(value)
                                        )
                                      } else {
                                        throw RecoveryMappingEditorException(
                                          m,
                                          EditorErrorSide.LOCAL,
                                          getHumanReadableValue(value)
                                        )
                                      }
                                    case _ => // r if r == RecoveryKey.NONE.toString =>
                                  }
                              }
                              basicHubComment
                          }
                        } else {
                          comment
                        }
                    }
                  )
                )
                Future.successful(issue)
              case _        =>
                issue.setComments(commentHelper.mergeComments(issue, replica))
                Future.successful(issue)
            }
          case None            =>
            issue.setComments(commentHelper.mergeComments(issue, replica))
            Future.successful(issue)
        }
      case None    =>
        issue.setComments(commentHelper.mergeComments(issue, replica))
        Future.successful(issue)
    }

  /** Sets a value to the provided system field and custom field of the issue tracker entity.
    * @param issue
    * @param key
    * @param value
    * @param receivingFieldValue
    * @param sendingFieldValue
    * @tparam RV
    * @return
    */
  private def setIssueValueByKey[RV](
      issue: BasicHubIssue,
      key: String,
      value: FieldValue[RV],
      receivingFieldValue: Option[EditorFieldValue],
      sendingFieldValue: Option[EditorFieldValue]
  ): Future[BasicHubIssue] =
    EditorFields.withNameOpt(key) match {
      case Some(ISSUE_TYPE)  => setIssueType(issue, convertToString(value, sendingFieldValue))
      case Some(PROJECT)     => setProject(issue, convertToString(value, sendingFieldValue))
      case Some(SUMMARY)     =>
        Future
          .successful(issue.setSummary(convertToString(value, sendingFieldValue).value))
          .map(_ => issue)
      case Some(PRIORITY)    => setPriority(issue, convertToString(value, sendingFieldValue))
      case Some(STATUS)      => setStatus(issue, convertToString(value, sendingFieldValue))
      case Some(DESCRIPTION) =>
        Future
          .successful(issue.setDescription(convertToString(value, sendingFieldValue).value))
          .map(_ => issue)
      case Some(ATTACHMENTS) =>
        Future
          .successful(
            issue.setAttachments(
              value.asInstanceOf[FieldValue[java.util.List[BasicHubAttachment]]].value
            )
          )
          .map(_ => issue)
      case Some(COMMENTS)    =>
        Future
          .successful(
            issue.setComments(value.asInstanceOf[FieldValue[java.util.List[BasicHubComment]]].value)
          )
          .map(_ => issue)
      case Some(LABELS)      =>
        Future
          .successful(issue.setLabels(value.asInstanceOf[FieldValue[java.util.Set[IHubLabel]]].value))
          .map(_ => issue)
      case Some(ASSIGNEE)    => setAssigne(issue, convertToString(value, sendingFieldValue))
      case Some(REPORTER)    => setReporter(issue, convertToString(value, sendingFieldValue))
      case _                 =>
        setCustomField(issue, key, receivingFieldValue, convertToString(value, sendingFieldValue))
    }

  /** Gets Issue Type From Replica
    * @param replica
    * @return
    */
  private def getIssueTypeFromReplica(replica: BasicHubIssue): Option[String] =
    Option(replica.getType) match {
      case Some(issueType) => Some(issueType.getName)
      case None            =>
        Option(replica.getTypeName).flatMap(s => if (s.trim.isEmpty) None else Some(s))
    }

  /** Gets Project Key From Replica
    * @param replica
    * @return
    */
  private def getProjectKeyFromReplica(replica: BasicHubIssue): Option[String] =
    Option(replica.getProject).map(_.getKey) match {
      case Some(projectKey) => Some(projectKey)
      case None             =>
        Option(replica.getProjectKey).flatMap(s => if (s.trim.isEmpty) None else Some(s))
    }

  private def convertToString(
      value: FieldValue[_],
      sendingFieldOpt: Option[EditorFieldValue]
  ): FieldValue[String] =
    sendingFieldOpt match {
      case Some(editorFieldValue) if editorFieldValue.`type`.key == FieldDataType.TEXT.toString =>
        value.asInstanceOf[FieldValue[String]]
      case Some(editorFieldValue) if editorFieldValue.`type`.key == FieldDataType.USER.toString =>
        Try(value.value.asInstanceOf[BasicHubUser]) match {
          case Success(user) =>
            val userAsString = trackerScopeAndMappingHelper.getUserAsString(user)
            FieldValue(value.field, userAsString)
          case Failure(_)    => value.asInstanceOf[FieldValue[String]]
        }
      case _ => value.asInstanceOf[FieldValue[String]]
    }

  /** Sets status to the provided issue
    * @param issue
    * @param remoteMapValue
    * @return
    *   issue with new status
    */
  private def setStatus(
      issue: BasicHubIssue,
      remoteMapValue: FieldValue[String]
  ): Future[BasicHubIssue] = {
    val projectId = Option(issue.getProject).flatMap(p => Option(p.getIdStr))
    val issueTypeId = Option(issue.getType).flatMap(p => Option(p.getId))
    trackerScopeAndMappingHelper
      .getStatus(remoteMapValue.value, projectId, issueTypeId)
      .flatMap {
        case Some(status) =>
          issue.setStatus(status)
          Future.successful(issue)
        case _            =>
          loggingService.error(s"Status with name $remoteMapValue from mapping was not found")
          Future.failed(
            new MappingLocalValueNotFoundException(
              s"Status with name $remoteMapValue from mapping was not found",
              EditorFields.STATUS.toString,
              remoteMapValue.value
            )
          )
      }
  }

  /** Sets priority to the provided issue
    * @param issue
    * @param remoteMapValue
    * @return
    *   issue with new priority
    */
  private def setPriority(
      issue: BasicHubIssue,
      remoteMapValue: FieldValue[String]
  ): Future[BasicHubIssue] = {
    val projectId = Option(issue.getProject).flatMap(p => Option(p.getIdStr))
    trackerScopeAndMappingHelper
      .getPriority(remoteMapValue.value, projectId)
      .flatMap {
        case Some(priority) =>
          issue.setPriority(priority)
          Future.successful(issue)
        case _              =>
          loggingService.error(s"Priority with name $remoteMapValue from mapping was not found")
          Future.failed(
            new MappingLocalValueNotFoundException(
              s"Priority with name $remoteMapValue from mapping was not found",
              EditorFields.PRIORITY.toString,
              remoteMapValue.value
            )
          )
      }
  }

  /** Sets type to the provided issue
    * @param issue
    * @param remoteMapValue
    * @return
    *   issue with new type
    */
  private def setIssueType(
      issue: BasicHubIssue,
      remoteMapValue: FieldValue[String]
  ): Future[BasicHubIssue] = {
    val projectId = Option(issue.getProject).flatMap(p => Option(p.getIdStr))
    trackerScopeAndMappingHelper
      .getIssueType(remoteMapValue.value, projectId)
      .flatMap {
        case Some(issueType) =>
          issue.setType(issueType)
          issue.setTypeName(remoteMapValue.value)
          Future.successful(issue)
        case _               =>
          loggingService.error(s"Issue type with name $remoteMapValue from mapping was not found")
          Future.failed(
            new MappingLocalValueNotFoundException(
              s"Issue type with name $remoteMapValue from mapping was not found",
              EditorFields.ISSUE_TYPE.toString,
              remoteMapValue.value
            )
          )
      }
  }

  /** Sets project to the provided issue
    * @param issue
    * @param remoteMapValue
    * @return
    *   issue with new project
    */
  private def setProject(
      issue: BasicHubIssue,
      remoteMapValue: FieldValue[String]
  ): Future[BasicHubIssue] =
    trackerScopeAndMappingHelper
      .getProject(remoteMapValue.value)
      .flatMap {
        case Some(project) =>
          issue.setProject(project)
          issue.setProjectKey(remoteMapValue.value)
          Future.successful(issue)
        case _             =>
          loggingService.error(s"Project with name or id $remoteMapValue from mapping was not found")
          Future.failed(
            new MappingLocalValueNotFoundException(
              s"Project with name or id $remoteMapValue from mapping was not found",
              EditorFields.PROJECT.toString,
              remoteMapValue.value
            )
          )
      }

  /** Sets custom field value to the provided issue
    * @param issue
    * @param key
    * @param receivingFieldValueOpt
    * @param sendingMapValue
    * @return
    *   issue with updated custom field value
    */
  private def setCustomField(
      issue: BasicHubIssue,
      key: String,
      receivingFieldValueOpt: Option[EditorFieldValue],
      sendingMapValue: FieldValue[String]
  ): Future[BasicHubIssue] =
    receivingFieldValueOpt
      .flatMap { receivingFieldValue =>
        getCustomFieldByKey(issue, receivingFieldValue.key)
          .orElse(Option(issue.getCustomFields.get(receivingFieldValue.key)))
          .map { icf =>
            val cf = icf.asInstanceOf[BasicHubCustomField]
            cf.getType match {
              case HubCustomFieldType.OPTION =>
                val sentOptionName = sendingMapValue.value
                val projectId = Option(issue.getProject).flatMap(p => Option(p.getIdStr))
                val issueTypeId = Option(issue.getType).flatMap(p => Option(p.getId))
                // TODO EXE-683 turns out that it's not easy to tell whether an option is disabled from the Jira API, so for now always setting the value and relying on Error from issue tracker to handle it
                cf.setValue(sentOptionName)
                Future.successful(issue)
              //          trackerScopeAndMappingHelper
              //            .getCfOption(
              //              cf.getUid,
              //              cf.getName,
              //              sentOptionName,
              //              projectId,
              //              issueTypeId
              //            )
              //            .flatMap {
              //              case None =>
              //                loggingService.error(s"Custom Field `${receivingFieldValue.label}`'s option `$sentOptionName` from mapping was not found")
              //                Future.failed[BasicHubIssue](new MappingLocalValueNotFoundException(s"Custom Field `${receivingFieldValue.label}`'s option `$sentOptionName` from mapping was not found", receivingFieldValue.key, sentOptionName))
              //              case Some(opt) if Option(opt.getDisabled).contains(true) =>
              //                loggingService.error(s"Custom Field `${receivingFieldValue.label}`'s option `$sentOptionName` from mapping was not found")
              //                Future.failed[BasicHubIssue](new MappingLocalValueDisabledException(receivingFieldValue.key, receivingFieldValue.label, sentOptionName))
              //              case Some(opt) =>
              //                cf.setValue(opt)
              //                Future.successful(issue)
              //            }
              case HubCustomFieldType.USER   =>
                val sentUserKey = sendingMapValue.value
                val projectId = Option(issue.getProject).flatMap(p => Option(p.getIdStr))
                val issueTypeId = Option(issue.getType).flatMap(p => Option(p.getId))
                trackerScopeAndMappingHelper
                  .getUser(sentUserKey, projectId, issueTypeId)
                  .flatMap {
                    case Some(user) =>
                      cf.setValue(user)
                      Future.successful(issue)
                    case _          =>
                      loggingService.error(
                        s"User with name or id $sentUserKey from mapping was not found"
                      )
                      Future.failed(
                        new MappingLocalValueNotFoundException(
                          s"User with name or id $sentUserKey from mapping was not found",
                          EditorFields.ASSIGNEE.toString,
                          sentUserKey
                        )
                      )
                  }
              case _                         =>
                cf.setValue(sendingMapValue.value)
                Future.successful(issue)
            }
          }
      }
      .getOrElse {
        loggingService.error(s"Custom field with name or id $key from mapping was not found")
        Future.failed(
          new MappingLocalFieldNotFoundException(
            key,
            receivingFieldValueOpt.map(_.label).getOrElse(key)
          )
        )
      }

  // TODO make one methods from the next 2 (setAssigne, setReporter): they differ only  in issue.setAssignee && issue.setReporter
  /** Sets assignee to the provided issue
    * @param issue
    * @param remoteMapValue
    * @return
    *   issue with new assignee
    */
  private def setAssigne(
      issue: BasicHubIssue,
      remoteMapValue: FieldValue[String]
  ): Future[BasicHubIssue] = {
    val projectId = Option(issue.getProject).flatMap(p => Option(p.getIdStr))
    val issueTypeId = Option(issue.getType).flatMap(p => Option(p.getId))
    trackerScopeAndMappingHelper
      .getUser(remoteMapValue.value, projectId, issueTypeId)
      .flatMap {
        case Some(user) =>
          issue.setAssignee(user)
          Future.successful(issue)
        case _          =>
          loggingService.error(s"User with name or id $remoteMapValue from mapping was not found")
          Future.failed(
            new MappingLocalValueNotFoundException(
              s"User with name or id $remoteMapValue from mapping was not found",
              EditorFields.ASSIGNEE.toString,
              remoteMapValue.value
            )
          )
      }
  }

  /** Sets reporter to the provided issue
    * @param issue
    * @param remoteMapValue
    * @return
    *   issue with new reporter
    */
  private def setReporter(
      issue: BasicHubIssue,
      remoteMapValue: FieldValue[String]
  ): Future[BasicHubIssue] = {
    val projectId = Option(issue.getProject).flatMap(p => Option(p.getIdStr))
    val issueTypeId = Option(issue.getType).flatMap(p => Option(p.getId))
    trackerScopeAndMappingHelper
      .getUser(remoteMapValue.value, projectId, issueTypeId)
      .flatMap {
        case Some(user) =>
          issue.setReporter(user)
          Future.successful(issue)
        case _          =>
          loggingService.error(s"User with name or id $remoteMapValue from mapping was not found")
          Future.failed(
            new MappingLocalValueNotFoundException(
              s"User with name or id $remoteMapValue from mapping was not found",
              EditorFields.ASSIGNEE.toString,
              remoteMapValue.value
            )
          )
      }
  }

  /** GEts custom field from provided issue by ket
    * @param issue
    * @param key
    *   key of the custom field
    * @return
    *   IHubCustomField
    */
  private def getCustomFieldByKey(issue: BasicHubIssue, key: String): Option[IHubCustomField] =
    issue.getCustomFields.asScala.values
      .find(cf =>
        cf != null && cf
          .asInstanceOf[com.exalate.api.domain.hubobject.v1_6.IHubCustomField]
          .getUid == key
      )

  private case class FieldValue[V](field: String, value: V)

  private def filterNotFn[T](list: util.List[T], predicate: T => Boolean): util.List[T] = {
    val javaList = JavaConverters
      .bufferAsJavaListConverter(
        JavaConverters.asScalaBufferConverter(list).asScala.filterNot(predicate)
      )
      .asJava
    new util.ArrayList[T](javaList)
  }

}
