package com.exalate.replication.services.replication

import com.exalate.api.domain.IIssueKey
import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.hubobject.IHubIssueReplica
import com.exalate.api.domain.request.ISyncRequest
import com.exalate.api.domain.twintrace.{INonPersistentTrace, ITwinTrace, TraceAction, TraceType}
import com.exalate.api.domain.webhook.WebhookEntityType
import com.exalate.api.persistence.twintrace.ITwinTraceRepository
import com.exalate.basic.domain.BasicNonPersistentTrace
import com.exalate.basic.domain.hubobject.v1.BasicHubComment
import com.exalate.domain.issuetracker.{EntityUpdateContext, IEntityUpdateContext}
import com.exalate.replication.services.api.issuetracker.ITrackerCommentService
import com.exalate.replication.services.api.replication.impersonation.IAuditLogService
import com.exalate.services.utils.FutureUtils
import com.google.inject.Inject
import play.api.Logger
import play.api.libs.json.Json

import scala.concurrent.{ExecutionContext, Future}
import scala.jdk.CollectionConverters._

class CommentService @Inject() (
    trackerCommentService: ITrackerCommentService,
    twinTraceRepository: ITwinTraceRepository,
    auditLogService: IAuditLogService
)(implicit ec: ExecutionContext)
    extends ICommentService {

  private val LOG = Logger("application.services.replication.CommentService")

  /** Applies comments to issue
    * @param syncRequest
    * @param issueKey
    * @param newHubIssue
    * @param traces
    * @return
    *   seq of current traces and new comments traces
    */
  override def applyComments(
      syncRequest: ISyncRequest,
      issueKey: IIssueKey,
      newHubIssue: IHubIssueReplica,
      traces: Seq[INonPersistentTrace]
  ): Future[Seq[INonPersistentTrace]] =
    applyComments(EntityUpdateContext(newHubIssue, issueKey, syncRequest, traces))

  /** Process comments (process new comments, changed comments and removed comments) and concatenate
    * new comments traces to the current seq of traces
    * @param context
    *   holds sync Request, issue key, enitity/issue, seq of traces, connection, remote twin trace
    *   id
    * @tparam C
    * @return
    *   seq of current traces and new comments traces
    */
  override def applyComments[C <: IEntityUpdateContext](
      context: C
  ): Future[Seq[INonPersistentTrace]] = {
    val syncRequest: ISyncRequest = context.syncRequest
    val issueKey: IIssueKey = context.issueKey
    val newHubIssue: IHubIssueReplica = context.entity
    val traces: Seq[INonPersistentTrace] = context.traces
    val connection = syncRequest.getConnection
    val remoteTwinTraceId = syncRequest.getRemoteTwinTraceId
    val addedComments: Seq[BasicHubComment] = newHubIssue.getAddedComments.asScala.toSeq
    val changedComments: Seq[BasicHubComment] = newHubIssue.getChangedComments.asScala.toSeq
    val removedComments: Seq[BasicHubComment] = newHubIssue.getRemovedComments.asScala.toSeq
    for {
      twitTrace <- twinTraceRepository.getTwinTraceByRemoteTwinTraceId(
        connection.getID,
        remoteTwinTraceId
      )
      newCommentsTraces <- processNewComments(
        connection,
        issueKey,
        newHubIssue,
        addedComments,
        twitTrace,
        context
      )
      _: Seq[INonPersistentTrace] <- processChangedComments(
        connection,
        issueKey,
        changedComments,
        twitTrace,
        context
      )
      _ <- processRemovedComments(connection, removedComments, traces, issueKey, twitTrace, context)
    } yield traces ++ newCommentsTraces
  }

  private def sortComments(comments: Seq[BasicHubComment]): Seq[BasicHubComment] = {
    val isDateDefinedOnAllComments = comments.map(c => Option(c.getCreated)).forall(_.isDefined)
    if (isDateDefinedOnAllComments) comments.sortBy(_.getCreated) else comments
  }

  /** Process new comments: creates new comments, update audit log, creates Comment Trace
    * @param connection
    * @param issueKey
    * @param basicHubIssue
    * @param addedComments
    *   new comments
    * @param tt
    *   Twin Trace
    * @param context
    * @tparam C
    * @return
    *   seq of traces
    */
  private def processNewComments[C <: IEntityUpdateContext](
      connection: IConnection,
      issueKey: IIssueKey,
      basicHubIssue: IHubIssueReplica,
      addedComments: Seq[BasicHubComment],
      tt: Option[ITwinTrace],
      context: C
  ): Future[Seq[INonPersistentTrace]] = {

    LOG.debug("Processing added comments for issue " + issueKey.getURN)

    FutureUtils
      .foldLeft(sortComments(addedComments)) { comment: BasicHubComment =>
        val issueId = issueKey.getIdStr

        val updateAuthorKey = Option(comment.getExecutor).map(_.getKey)
        val userBehalfOnOpt = updateAuthorKey.flatMap(u => trackerCommentService.getUserKey(u))
        LOG.debug(
          s"Adding a comment for issue ${issueKey.getURN} where updateAuthorKey is ${updateAuthorKey.orNull}, userBehalfOnOpt: ${userBehalfOnOpt.orNull}"
        )

        val auditLogOpt = userBehalfOnOpt.map(
          auditLogService.createAuditLog(Some(issueId), WebhookEntityType.COMMENT_CREATED)
        )

        val commentIdFuture =
          trackerCommentService.createComment(comment, userBehalfOnOpt, context)

        commentIdFuture
          .map {
            case (commentId, commentJson) =>
              auditLogService.updateAuditLog(
                auditLogOpt,
                issueId,
                commentId,
                Json.stringify(commentJson)
              )
              commentId
          }
          .flatMap(commentId =>
            createCommentTrace(Option(comment.getRemoteIdStr), tt, comment.getRestrictSync)(
              commentId
            )
          )
          .recoverWith {
            case e: Exception =>
              LOG.error(
                s"Error when processing new comments for issue $issueKey and comment $comment"
              )
              auditLogOpt
                .foreach(auditLog => FutureUtils.resultInf(auditLogService.delete(auditLog.getId)))
              Future.failed(e)
          }
      }
      .map(_.flatten)

  }

  /** Process changed comments: update comments on the issue/entity, update Audit Log
    * @param connection
    * @param issueKey
    * @param changedComments
    *   seq of changed comments
    * @param tt
    *   Twin Trace
    * @param context
    * @tparam C
    * @return
    *   seq of traces
    */
  private def processChangedComments[C <: IEntityUpdateContext](
      connection: IConnection,
      issueKey: IIssueKey,
      changedComments: Seq[BasicHubComment],
      tt: Option[ITwinTrace],
      context: C
  ): Future[Seq[INonPersistentTrace]] = {

    LOG.debug("Processing changed comments for issue " + issueKey.getURN)
    FutureUtils
      .foldLeft(changedComments) { comment: BasicHubComment =>
        Option(comment.getIdStr)
          .map { _ =>
            val issueId = issueKey.getIdStr

            val updateAuthorKey = Option(comment.getExecutor).map(_.getKey)
            val userBehalfOnOpt = updateAuthorKey.flatMap(u => trackerCommentService.getUserKey(u))

            LOG.debug(
              s"Updating a comment for issue ${issueKey.getURN} where updateAuthorKey is ${updateAuthorKey.orNull}, userBehalfOnOpt: ${userBehalfOnOpt.orNull}"
            )

            val auditLogOpt = userBehalfOnOpt.map(
              auditLogService.createAuditLog(Some(issueId), WebhookEntityType.COMMENT_UPDATED)
            )

            val commentIdTry = trackerCommentService.updateComment(comment, userBehalfOnOpt, context)

            commentIdTry
              .map {
                case Some((commentId, commentJson)) =>
                  auditLogService.updateAuditLog(
                    auditLogOpt,
                    issueId,
                    commentId,
                    Json.stringify(commentJson)
                  )
                  FutureUtils.resultInf(
                    createCommentTrace(Option(comment.getRemoteIdStr), tt, comment.getRestrictSync)(
                      commentId
                    )
                  )
                case None                           => None
              }
              .recoverWith {
                case e: Exception =>
                  LOG.error(
                    s"Error when processing changed comments for issue $issueKey and comment $comment"
                  )
                  auditLogOpt.foreach(auditLog =>
                    FutureUtils.resultInf(auditLogService.delete(auditLog.getId))
                  )
                  Future.failed(e)
              }
          }
          .getOrElse {
            LOG.error(
              s"Error when processing changed comment for issue `$issueKey` and comment: $comment. Comment ID is NULL."
            )
            Future.successful(None)
          }
      }
      .map(_.flatten)

  }

  /** Process removed comments: remove corresponding comments on issue/entity
    * @param connection
    * @param removedComments
    *   seq of removed comments
    * @param existingTraces
    * @param issueKey
    * @param twinTrace
    *   Twin Trace
    * @param context
    * @tparam C
    * @return
    *   seq of traces
    */
  private def processRemovedComments[C <: IEntityUpdateContext](
      connection: IConnection,
      removedComments: Seq[BasicHubComment],
      existingTraces: Seq[INonPersistentTrace],
      issueKey: IIssueKey,
      twinTrace: Option[ITwinTrace],
      context: C
  ): Future[Seq[INonPersistentTrace]] = {

    LOG.debug("Processing removed comments for issue " + issueKey.getURN)

    removedComments.foldLeft(Future.successful(Seq[INonPersistentTrace]())) {
      case (toRemoveTracesFut, comment) =>
        toRemoveTracesFut.flatMap { toRemoveTraces =>
          Option(comment.getIdStr) match {
            case Some(commentId) =>
              LOG.debug(s"Removing comment $commentId for issue " + issueKey.getURN)
              val theTraceOpt = existingTraces.find { t =>
                TraceType.COMMENT == t.getType &&
                Option(t.getLocalId).isDefined &&
                t.getLocalId == commentId
              }

              trackerCommentService
                .removeComment(commentId, context)
                .map { _ =>
                  twinTrace.flatMap(tt =>
                    theTraceOpt.map(t => FutureUtils.resultInf(twinTraceRepository.removeTrace(tt, t)))
                  )
                  toRemoveTraces ++ theTraceOpt
                }
            case None            => toRemoveTracesFut
          }
        }
    }
  }

  /** creates Comment Trace
    * @param remoteIdOpt
    * @param twinTraceOpt
    * @param restictSync
    * @param localId
    * @return
    *   Comment Trace
    */
  private def createCommentTrace(
      remoteIdOpt: Option[String],
      twinTraceOpt: Option[ITwinTrace],
      restictSync: Boolean
  )(localId: String): Future[Option[INonPersistentTrace]] = {
    LOG.debug(s"Creating comment trace for $remoteIdOpt")

    (if (restictSync) {
       Some(
         new BasicNonPersistentTrace()
           .setLocalId(localId)
           .setType(TraceType.COMMENT)
           .setAction(TraceAction.NONE)
           .setToSynchronize(false)
       )

     } else {
       remoteIdOpt.map { remoteId =>
         new BasicNonPersistentTrace()
           .setLocalId(localId)
           .setRemoteId(remoteId)
           .setType(TraceType.COMMENT)
           .setAction(TraceAction.NONE)
           .setToSynchronize(true)
       }
     })
      .map { t =>
        twinTraceOpt
          .map(tt => twinTraceRepository.setTrace(tt, t))
          .getOrElse(Future.successful(None))
          .map(_ => Some(t))
      }
      .getOrElse(Future.successful(None))
  }

}
