package com.exalate.replication.services.replication.blob.request

import javax.inject.Inject

import com.exalate.api.domain.blob.request.{BlobRequestStatus, IBlobRequest}
import com.exalate.api.domain.connection.SendProtocol
import com.exalate.api.persistence.replication.request.IUpdateBlobSyncRequestRepository
import com.exalate.replication.services.api.error.IErrorService
import com.exalate.replication.services.api.transport.ITransportServiceFactory
import com.exalate.replication.services.replication.state.IState
import play.api.Logger

import scala.concurrent.ExecutionContext
import scala.concurrent.Future

class SendBlobErrorResponseRequestState @Inject() (
    updateBlobRepository: IUpdateBlobSyncRequestRepository,
    transportServiceFactory: ITransportServiceFactory
)(implicit ec: ExecutionContext)
    extends IState[IBlobRequest] {

  val LOG = Logger("application.services.replication.blob.request.SendBlobErrorResponseRequestState")

  /** Performs transition of one of the states of BlobRequestStateMachine: status
    * `SEND_BLOB_ERROR_RESPONSE`
    * @param blobRequest
    * @return
    *   IBlobRequest
    */
  override def transition(blobRequest: IBlobRequest): Future[Option[IBlobRequest]] = {
    val syncRequest = blobRequest.getSyncRequest
    val connection = syncRequest.getConnection

    LOG.info(
      s"#transitioning blob request `${blobRequest.getId}`: sending a blob error response with reason ${blobRequest.getBlobErrorReason}` and message ${blobRequest.getErrorResponseMessage}"
    )

    Future
      .fromTry(transportServiceFactory.get(connection))
      .flatMap(_.sendBlobErrorResponse(blobRequest))
      .flatMap { _ =>
        val remoteNodeInfo = connection.getRemoteInstance.getNodeInfo
        val sendProtocol = connection.getSendProtocol
        val nextStatus =
          if (remoteNodeInfo.isPollOnly || Option(sendProtocol).contains(SendProtocol.WAIT_FOR_POLL)) {
            BlobRequestStatus.WAITING_BLOB_ERROR_RESPONSE_RECEIVED
          } else {
            BlobRequestStatus.BLOB_PROCESSED
          }
        updateBlobRepository.updateBlobRequestStatus(blobRequest, nextStatus).map(Some(_))
      }
  }

}
