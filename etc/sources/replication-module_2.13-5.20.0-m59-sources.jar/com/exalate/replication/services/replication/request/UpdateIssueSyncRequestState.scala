package com.exalate.replication.services.replication.request

import com.exalate.api.domain._
import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.request.{ISyncRequest, RequestStatus}
import com.exalate.api.domain.twintrace.{ITrace, TraceType}
import com.exalate.api.persistence.replication.request.{
  IRequestReplicationRepository,
  IUpdateIssueSyncRequestStateRepository
}
import com.exalate.api.persistence.twintrace.ITwinTraceRepository
import com.exalate.api.persistence.twintrace.ITwinTraceRepository.TwinTraceReplicas
import com.exalate.domain.replication.BasicSyncRequest
import com.exalate.replication.services.api.hubobject.IReplicaHelper
import com.exalate.replication.services.api.issuetracker.ITriggerWhiteListTrackerService
import com.exalate.replication.services.api.processor.IChangeIssueProcessor
import com.exalate.replication.services.api.replication.IEventSchedulerNotificationService
import com.exalate.replication.services.api.trigger.ITriggerService
import com.exalate.replication.services.replication.request.UpdateIssueSyncRequestState.mergeTraces
import com.exalate.replication.services.replication.state.IState
import play.api.Logger

import javax.inject.Inject
import scala.jdk.CollectionConverters._
import scala.concurrent.{ExecutionContext, Future}
import scala.util.{Failure, Try}

class UpdateIssueSyncRequestState @Inject() (
    persistence: IRequestReplicationRepository,
    eventSchedulerNotServ: IEventSchedulerNotificationService,
    triggerWhiteListTrackerService: ITriggerWhiteListTrackerService,
    triggerService: ITriggerService,
    updateIssueRepository: IUpdateIssueSyncRequestStateRepository,
    twinTraceRepository: ITwinTraceRepository,
    changeIssueProcessor: IChangeIssueProcessor,
    replicaHelper: IReplicaHelper
)(implicit ec: ExecutionContext)
    extends IState[BasicSyncRequestContext] {

  val LOG: Logger = Logger(classOf[UpdateIssueSyncRequestState])

  /** Performs transition of one of the states of SyncRequestStateMachine: status `UPDATE_ISSUE`
    *
    * @param context
    * @return
    *   BasicSyncRequestContext
    */
  override def transition(
      context: BasicSyncRequestContext
  ): Future[Option[BasicSyncRequestContext]] = {
    val BasicSyncRequestContext(basicSyncRequest, _) = context
    persistence.getSyncRequestById(basicSyncRequest.id).flatMap {
      case Some(syncRequest) => transition(syncRequest).map(_.map(r => context.copy(request = r)))
      case _                 =>
        LOG.error(
          s"#transitioning request `${basicSyncRequest.id}`. Could not find a sync request by ID=${basicSyncRequest.id}. Skip processing."
        )
        Future.successful(None)
    }
  }

  private def transition(request: ISyncRequest): Future[Option[BasicSyncRequest]] = {
    val connection = request.getConnection
    val replica: IPersistentReplica = request.getReplica
    twinTraceRepository
      .getTwinTraceReplicasByRemoteTwinTraceId(connection.getID, request.getRemoteTwinTraceId)
      .flatMap {
        case Some(twinTraceReplicas) =>
          changeIssueAndUpdateRequest(request, connection, replica, twinTraceReplicas)

        case None =>
          LOG.error(
            s"#transitioning request `${request.getId}`. Could not find a twin trace by remote twin trace ID=${request.getRemoteTwinTraceId}."
          )
          Future.successful(None)
      }
  }

  private def changeIssueAndUpdateRequest(
      request: ISyncRequest,
      connection: IConnection,
      newRemoteReplica: IPersistentReplica,
      twinTraceReplicas: TwinTraceReplicas
  ): Future[Option[BasicSyncRequest]] =
    (twinTraceReplicas.localReplica, twinTraceReplicas.remoteReplica) match {
      case (Some(localReplica), Some(remoteReplica)) =>
        val requestId = request.getId
        val localIssueKey: IIssueKey = localReplica.getIssueKey
        val oldRemoteReplica = remoteReplica
        val remoteIssueKey = newRemoteReplica.getIssueKey
        val remoteIssueUrn = remoteIssueKey.getURN
        val friendlyReceivedReplica = Try {
          replicaHelper.toNonPersistentReplica(newRemoteReplica)
        }.recoverWith {
          case e: Exception =>
            LOG.error(
              s"#transitioning request `$requestId`  for remote issue `$remoteIssueUrn`: an attempt to convert new replica payload to hub object failed unexpectedly: \nReplica (id ${newRemoteReplica.getId}):\n${newRemoteReplica.getPayload}"
            )
            Failure(e)
        }.get
        val friendlyPrevReplica = Try {
          replicaHelper.toNonPersistentReplica(oldRemoteReplica)
        }.recoverWith {
          case e: Exception =>
            LOG.error(
              s"#transitioning request `$requestId`  for remote issue `$remoteIssueUrn`: an attempt to convert old replica payload to hub object failed unexpectedly: \nReplica (id ${oldRemoteReplica.getId}):\n${oldRemoteReplica.getPayload}"
            )
            Failure(e)
        }.get

        val blobMetadataSeq: Seq[IBlobMetadata] = request.getBlobMetadataList.asScala.toSeq

        val result = for {
          twinTraces <- twinTraceRepository.getTwinTraceByRemoteTwinTraceId(
            connection.getID,
            request.getRemoteTwinTraceId
          )
          tracesFromDB = twinTraces.map(_.getAllFieldTraces.asScala.toList).getOrElse(Nil)
          fieldTraces = groupTracesByType(
            mergeTraces(request.getTraces.asScala.toList, tracesFromDB)
          )
          traces <- changeIssueProcessor.changeIssue(
            connection,
            request,
            friendlyPrevReplica,
            friendlyReceivedReplica,
            localIssueKey,
            blobMetadataSeq,
            fieldTraces
          )
          resultRequest <- updateIssueRepository.persistOnUpdateIssueRequestState(
            request,
            RequestStatus.CREATE_REPLICA,
            traces,
            None,
            None
          )
        } yield resultRequest

        result.foreach { _ =>
          val hubIssue = friendlyReceivedReplica.getPayload.getHubIssue
          val projectKeyOpt = triggerWhiteListTrackerService.extractProject(connection, hubIssue)
          scheduleSyncForOtherTwinTraces(twinTraceReplicas.twinId, localIssueKey, projectKeyOpt)
        }
        result

      case _ =>
        LOG.error(
          s"#transitioning request `${request.getId}`: either local or remote twin trace's replica was not found. " +
            s"Twin trace id: ${twinTraceReplicas.twinId}. Local replica: \n ${twinTraceReplicas.localReplica
                .getOrElse("")}\n Remote replica: \n ${twinTraceReplicas.remoteReplica.getOrElse("")}. Skip processing."
        )
        Future.successful(None)
    }

  private def scheduleSyncForOtherTwinTraces(
      currentTwinTraceId: Int,
      localIssueKey: IIssueKey,
      projectKeyOpt: Option[String]
  ) = {
    twinTraceRepository
      .findTwinTracesByIssueIdExcluding(
        localIssueKey.getIdStr,
        localIssueKey.getEntityType,
        currentTwinTraceId,
        localIssueKey.getFieldValues
      )
      .map(_.map { tt =>
        eventSchedulerNotServ.scheduleUpdateEventForTwinTrace(tt, localIssueKey, None)
      })
    triggerService.executeTriggers(localIssueKey, projectKeyOpt)
  }

  def groupTracesByType(traces: Seq[ITrace]): Map[TraceType, Seq[ITrace]] =
    traces.foldLeft(Map[TraceType, Seq[ITrace]]()) {
      case (map, trace) =>
        val traceType: TraceType = trace.getType
        map.get(traceType) match {
          case Some(ts) => map + (traceType -> (ts :+ trace))
          case None     => map + (traceType -> Seq(trace))
        }
    }

}

object UpdateIssueSyncRequestState {

  def mergeTraces(tracesFromRequest: Seq[ITrace], tracesFromDB: Seq[ITrace]): Seq[ITrace] =
    tracesFromRequest ++
      tracesFromDB.filter(trace =>
        !tracesFromRequest
          .exists(traceFromRequest =>
            traceFromRequest.getLocalId == trace.getLocalId && traceFromRequest.getRemoteId == trace.getRemoteId && traceFromRequest.getType == trace.getType
          )
      )

}
