package com.exalate.replication.services.replication.blob.event

import com.exalate.api.domain.blob.event.{BlobEventStatus, IBlobEvent}
import com.exalate.replication.services.replication.state.IState

import javax.inject.Inject

class BlobEventStateMachine @Inject() (
    readyEventState: ReadyBlobEventState,
    publishBlobIfNeededState: PublishBlobIfNeededEventState,
    sendBlobRequesState: SendBlobRequestBlobEventState,
    errorResponseReadyBlobEventState: ErrorResponseReadyBlobEventState,
    notifyResponseReceivedBlobEventState: NotifyResponseReceivedBlobEventState
) {

  /** Gets state of blob event execution. One of the state for the following statuses: READY,
    * PUBLISH_BLOB_IF_NEEDED, SEND_BLOB_REQUEST, WAITING_BLOB_REQUEST_RECEIVED,
    * WAITING_FOR_BLOB_RESPONSE, BLOB_ERROR_RESPONSE_READY, NOTIFY_BLOB_RESPONSE_RECEIVED,
    * BLOB_PROCESSED
    *
    * @param blobEvent
    * @return
    */
  def getState(blobEvent: IBlobEvent): IState[IBlobEvent] =
    blobEvent.getStatus match {
      case BlobEventStatus.READY                         => readyEventState
      case BlobEventStatus.PUBLISH_BLOB_IF_NEEDED        => publishBlobIfNeededState
      case BlobEventStatus.SEND_BLOB_REQUEST             => sendBlobRequesState
      case BlobEventStatus.BLOB_ERROR_RESPONSE_READY     => errorResponseReadyBlobEventState
      case BlobEventStatus.NOTIFY_BLOB_RESPONSE_RECEIVED => notifyResponseReceivedBlobEventState
    }

}
