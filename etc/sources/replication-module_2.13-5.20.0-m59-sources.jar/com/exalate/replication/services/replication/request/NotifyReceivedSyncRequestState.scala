package com.exalate.replication.services.replication.request

import com.exalate.api.domain.request.RequestStatus
import com.exalate.api.persistence.replication.request.IRequestReplicationRepository
import com.exalate.replication.services.api.replication.worker.IWorkerNotificationService
import com.exalate.replication.services.api.transport.ITransportServiceFactory
import com.exalate.replication.services.replication.state.IState
import com.exalate.replication.services.transport.utils.ExalateVersionCheckerUtils
import com.google.inject.Inject

import scala.concurrent.{ExecutionContext, Future}

class NotifyReceivedSyncRequestState @Inject() (
    transportServiceFactory: ITransportServiceFactory,
    persistence: IRequestReplicationRepository,
    workerNotificationService: IWorkerNotificationService
)(implicit ec: ExecutionContext)
    extends IState[BasicSyncRequestContext] {

  /** Performs transition of one of the states of SyncRequestStateMachine: status
    * `NOTIFY_REQUEST_RECEIVED`
    *
    * @param context
    * @return
    *   BasicSyncRequestContext
    */
  override def transition(
      context: BasicSyncRequestContext
  ): Future[Option[BasicSyncRequestContext]] = {
    val BasicSyncRequestContext(basicSyncRequest, connection) = context
    val notifyFuture =
      if (ExalateVersionCheckerUtils.remoteSupportsNoExtraConfirmation(connection))
        Future.successful(None)
      else
        Future
          .fromTry(transportServiceFactory.get(connection))
          .flatMap(_.postRequestReceived(basicSyncRequest, connection))

    val updatedRequestOpt = for {
      _ <- notifyFuture
      hasBlobs <- persistence.hasBlobMetadata(basicSyncRequest.id)
      nextStatus = if (hasBlobs) RequestStatus.RECEIVING_BLOBS else RequestStatus.READY
      updated <- persistence.updateSyncRequestStatus(basicSyncRequest.id, nextStatus)
    } yield updated

    updatedRequestOpt.foreach(_ => workerNotificationService.sendProcessRequestsNotification())
    updatedRequestOpt.map(_.map(r => context.copy(request = r)))
  }

}
