package com.exalate.replication.services.replication.request

import com.exalate.api.domain.ErrorReason._
import com.exalate.api.domain.request.RequestStatus._
import com.exalate.api.persistence.replication.request.IRequestReplicationRepository
import com.exalate.domain.replication.BasicSyncRequest
import com.exalate.replication.services.replication.state.IState
import play.api.Logger

import javax.inject.Inject
import scala.concurrent.{ExecutionContext, Future}

class ResponseSentSyncRequestState @Inject() (
    persistence: IRequestReplicationRepository
)(implicit ec: ExecutionContext)
    extends IState[BasicSyncRequestContext] {

  val LOG = Logger("application.services.replication.request.ResponseSentRequestState")

  /** Performs transition of one of the states of SyncRequestStateMachine: status `RESPONSE_SENT`
    *
    * @param context
    * @return
    *   BasicSyncRequestContext
    */
  override def transition(
      context: BasicSyncRequestContext
  ): Future[Option[BasicSyncRequestContext]] = {
    val BasicSyncRequestContext(basicSyncRequest, _) = context
    val connectContextOpt = basicSyncRequest.connectContext
    val finishedCorrectly = isFinishedCorrectly(basicSyncRequest)
    val requestStatus =
      if (BasicSyncRequest.isCleanupOrUnexalateOrDeleteRequest(basicSyncRequest)) REMOVE_LINK
      else
        connectContextOpt match {
          // We skip the COMPLETE state for OUT_OF_BAND_REQUESTs because these are the requests for another twin trace, and they should not mess up the requests for the current twin trace
          // We skip the COMPLETE state for SYNC_NOT_PAID because we don't want to mark the request as completed, as we need the other side to resend it
          case Some(connectContext) if finishedCorrectly && connectContext.isTriggerSyncEvent =>
            TRIGGER_SYNC_EVENT
          case Some(connectContext) if finishedCorrectly && connectContext.isTriggerUnexalate =>
            TRIGGER_UNEXALATE_EVENT
          case _
              if !finishedCorrectly && (basicSyncRequest.errorReason.contains(
                OUT_OF_BAND_REQUEST
              ) || basicSyncRequest.errorReason.contains(SYNC_NOT_PAID)) =>
            PROCESSED
          case _ => COMPLETE
        }

    persistence
      .updateSyncRequestStatus(basicSyncRequest.id, requestStatus)
      .map(_.map(r => context.copy(request = r)))
  }

  private def isFinishedCorrectly(basicSyncRequest: BasicSyncRequest): Boolean =
    basicSyncRequest.errorReason.isEmpty && basicSyncRequest.errorResponseMessage.isEmpty

}
