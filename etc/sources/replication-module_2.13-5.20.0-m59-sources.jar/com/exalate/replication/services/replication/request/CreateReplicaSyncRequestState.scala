package com.exalate.replication.services.replication.request

import com.exalate.api.domain.request.{ISyncRequest, RequestStatus}
import com.exalate.api.domain.{ErrorReason, IIssueKey, IPersistentReplica}
import com.exalate.api.persistence.replication.request.{
  ICreateReplicaSyncRequestStateRepository,
  IRequestReplicationRepository
}
import com.exalate.api.persistence.twintrace.ITwinTraceRepository
import com.exalate.basic.domain.NonPersistentConnectContext
import com.exalate.domain.replication.BasicSyncRequest
import com.exalate.generic.services.api.ITrackerHubObjectService
import com.exalate.replication.services.api.hubobject.{IConnectTracesService, IReplicaHelper}
import com.exalate.replication.services.api.processor.ICreateReplicaProcessor
import com.exalate.replication.services.replication.state.IState
import play.api.Logger

import javax.inject.Inject
import scala.concurrent.{ExecutionContext, Future}

class CreateReplicaSyncRequestState @Inject() (
    persistence: IRequestReplicationRepository,
    createReplicaSyncRequestStateRepository: ICreateReplicaSyncRequestStateRepository,
    twinTraceRepository: ITwinTraceRepository,
    createReplicaProcessor: ICreateReplicaProcessor,
    hubObjectService: ITrackerHubObjectService,
    replicaHelper: IReplicaHelper,
    connectTracesService: IConnectTracesService
)(implicit ec: ExecutionContext)
    extends IState[BasicSyncRequestContext] {

  val LOG = Logger("application.services.replication.request.CreateReplicaSyncRequestState")

  /** Performs transition of one of the states of SyncRequestStateMachine: status `CREATE_REPLICA`
    *
    * @param context
    * @return
    *   BasicSyncRequestContext
    */
  override def transition(
      context: BasicSyncRequestContext
  ): Future[Option[BasicSyncRequestContext]] = {
    val BasicSyncRequestContext(basicSyncRequest, connection) = context
    persistence.getSyncRequestById(basicSyncRequest.id).flatMap {
      case Some(syncRequest) => transition(syncRequest).map(_.map(r => context.copy(request = r)))
      case _                 =>
        LOG.error(
          s"#transitioning request `${basicSyncRequest.id}`. Could not find a sync request by ID=${basicSyncRequest.id}. Skip processing."
        )
        Future.successful(None)
    }
  }

  private def transition(request: ISyncRequest): Future[Option[BasicSyncRequest]] = {
    val remoteReplica = request.getReplica
    val remoteIssueUrn = remoteReplica.getIssueKey.getURN
    val connection = request.getConnection
    val requestId = request.getId

    for {
      twinTraceLocalReplicaOpt <- twinTraceRepository.getTwinTraceLocalReplicaByRemoteTwinTraceId(
        connection.getID,
        request.getRemoteTwinTraceId
      )
      localIssueKey <- Future.successful(getLocalIssueKey(request, twinTraceLocalReplicaOpt))
      hubPayloadOpt <- {
        LOG.info(
          s"#transitioning request `$requestId` for remote issue `$remoteIssueUrn`: creating a replica for the issue `$localIssueKey`"
        )
        hubObjectService.getHubPayloadFromTracker(localIssueKey, connection)
      }
      transitionedRequestOpt <- hubPayloadOpt match {
        case None                                                                             =>
          val message =
            s"#transitioning request `$requestId` for remote issue `$remoteIssueUrn`: unable to create replica (of the local issue). The issue has been deleted."
          persistence.updateRequestWhenError(
            request.getId,
            RequestStatus.SEND_ERROR_RESPONSE,
            message,
            ErrorReason.ISSUE_DELETED
          )
        case Some(hubPayload) if Option(hubPayload.getHubIssue.getId).exists(s => s.nonEmpty) =>
          /*
          We only want to run the outgoing script if the hubissue returned by the tracker is not completely empty
          This is used by nodes that cannot read from the issue tracker (Volvo case)
           */
          val connectContextOpt = Option(request.getConnectContext)
            .map(cc =>
              new NonPersistentConnectContext(
                cc.isSynchronizeComments,
                cc.isSynchronizeAttachments,
                cc.isSynchronizeWorklogs,
                cc.isTriggerSyncEvent,
                cc.isTriggerUpdate,
                cc.isTriggerUnexalate
              )
            )
          val connectTracesSeq = connectTracesService.getConnectTraces(
            hubPayload.getHubIssue,
            connectContextOpt,
            connection
          )
          createReplicaProcessor
            .createHubReplica(connection, hubPayload, localIssueKey, Some(request))
            .map((_, connectTracesSeq))
            .flatMap(x =>
              createReplicaSyncRequestStateRepository.updateRequestUpdatedReplicaAndStatus(
                request,
                RequestStatus.CREATE_OR_UPDATE_TWINTRACE,
                x._1,
                x._2
              )
            )
        case Some(hubPayload)                                                                 =>
          val summaryOpt = Option(remoteReplica.getSummary).map(_.toExternalForm)
          val updatedReplica =
            replicaHelper.createNonPersistentReplica(localIssueKey, summaryOpt, hubPayload)
          createReplicaSyncRequestStateRepository.updateRequestUpdatedReplicaAndStatus(
            request,
            RequestStatus.CREATE_OR_UPDATE_TWINTRACE,
            updatedReplica,
            Nil
          )
      }
    } yield transitionedRequestOpt
  }

  def getLocalIssueKey(
      request: ISyncRequest,
      twinTraceLocalReplicaOpt: Option[IPersistentReplica]
  ): IIssueKey =
    Option(request.getCreatedIssueKey)
      // No created issue key filled? This should be an update request then
      .getOrElse {
        twinTraceLocalReplicaOpt
          // if the created issue key is not filled in, then we should have the twin trace
          .get.getIssueKey
      }

}
