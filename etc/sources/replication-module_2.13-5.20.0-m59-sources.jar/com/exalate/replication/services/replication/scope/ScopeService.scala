package com.exalate.replication.services.replication.scope

import com.exalate.api.ILoggingService
import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.editor.error.EditorErrorSide
import com.exalate.api.domain.editor.scopes.SyncCriteria._
import com.exalate.api.domain.editor.scopes.TriggerCriteria._
import com.exalate.api.domain.editor.scopes.{SyncCriteria, TriggerCriteria}
import com.exalate.api.domain.hubobject.{EventTriggerContext, IHubIssueReplica}
import com.exalate.api.domain.request.ISyncRequest
import com.exalate.api.domain.{ErrorActType, ErrorEntityType, IIssueKey}
import com.exalate.api.exception.RetriableException
import com.exalate.api.exception.script.{ScriptException, ScriptProcessors}
import com.exalate.api.persistence.relation.IRelationRepository
import com.exalate.api.persistence.scopes.IScopesRepository
import com.exalate.api.persistence.twintrace.ITwinTraceRepository
import com.exalate.api.processor.IExalateProcessor
import com.exalate.basic.domain.connection.Connection
import com.exalate.basic.domain.hubobject.v1.BasicHubIssue
import com.exalate.domain.editor.FieldDataType
import com.exalate.domain.editor.scopes.{Scope, ScopeValue, SingleSideScope}
import com.exalate.domain.exception.editor.{EditorCategorizedException, ScopeScriptEditorException}
import com.exalate.domain.values.EditorFieldValue
import com.exalate.domain.values.connection.ConnectionValue
import com.exalate.generic.services.api.ITrackerHubObjectService
import com.exalate.replication.services.api.error.{
  IErrorService,
  VisualNotEnoughDataToCreateIssueProcessorException
}
import com.exalate.replication.services.api.issuetracker.IInstanceEditorFieldService
import com.exalate.replication.services.api.issuetracker.script.IScriptGeneratorService
import com.exalate.replication.services.api.replication.IEventSchedulerNotificationService
import com.exalate.replication.services.api.replication.scope.{
  IScopeQueryService,
  IScopeService,
  ITrackerScopeAndMappingHelper
}
import com.exalate.replication.services.script._
import com.exalate.services.utils.FutureUtils
import com.google.inject.Inject
import org.apache.commons.lang3.exception.ExceptionUtils

import java.util
import java.util.UUID
import scala.collection.JavaConverters
import scala.concurrent.{ExecutionContext, Future}
import scala.util.{Failure, Try}

class ScopeService @Inject() (
    processor: IExalateProcessor,
    connectionRepository: IRelationRepository,
    scopesRepository: IScopesRepository,
    scopeQueryService: IScopeQueryService,
    eventSchedulerService: IEventSchedulerNotificationService,
    trackerHubObjectService: ITrackerHubObjectService,
    twinTraceRepository: ITwinTraceRepository,
    errorService: IErrorService,
    instanceEditorFieldService: IInstanceEditorFieldService,
    trackerScopeAndMappingHelper: ITrackerScopeAndMappingHelper,
    scriptGeneratorService: IScriptGeneratorService,
    loggingService: ILoggingService
)(implicit ec: ExecutionContext)
    extends IScopeService {

  val EXALATE_SCOPE_UID = "__EXALATE_SCOPE_UID"

  /** Scope execution process when automatic rules
    * @param issueKey
    * @param hubIssueOpt
    * @return
    *   None
    */
  override def executeScopesForAutomatic(
      issueKey: IIssueKey,
      context: EventTriggerContext = EventTriggerContext.empty()
  ): Future[None.type] =
    executeScopes(issueKey, Seq(TriggerCriteria.AUTOMATIC), None, context)

  /** Scope execution process when manual rules
    * @param issueKey
    * @param connection
    * @param hubIssueOpt
    * @return
    */
  override def executeScopesForManual(
      issueKey: IIssueKey,
      connection: IConnection,
      context: EventTriggerContext = EventTriggerContext.empty()
  ): Future[None.type] =
    executeScopes(
      issueKey,
      Seq(TriggerCriteria.AUTOMATIC, TriggerCriteria.MANUAL),
      Some(connection),
      context
    )

  /** The method which handles scopes execution. For the provided connection, it extracts scopes
    * data from db, and checks whether target issue (provided by issue key) matches scopes rules. If
    * it matches - then exalate issue.
    * @param issueKey
    *   the key of the target issue
    * @param allowedTriggerCriteria
    * @param connection
    * @param hubIssueOpt
    *   optional hubIssue, in case when it exists do not call `getHubPayloadFromTracker`. Used in
    *   Jiranode.
    * @return
    *   \- Future[None.type]
    */
  def executeScopes(
      issueKey: IIssueKey,
      allowedTriggerCriteria: Seq[TriggerCriteria],
      connection: Option[IConnection],
      context: EventTriggerContext
  ): Future[None.type] = {
    val connectionsFuture = connection match {
      case None    =>
        connectionRepository.findConnectionsWithNoTwinTraceForIssueId(issueKey.getIdStr)
      case Some(c) =>
        twinTraceRepository
          .getTwinTraceByLocalIssueKeyFuture(c, issueKey)
          .map {
            case None    =>
              Seq(c) // if there are no twin traces - we can try syncing under this connection
            case Some(_) =>
              Nil // if there are twin traces - we should not try to schedule sync again
          }
    }
    connectionsFuture
      .map(_.filter(_.isVisual))
      .flatMap { connections =>
        connections.foldLeft(Future.successful(Seq.empty[(IConnection, Seq[Scope])])) {
          (result, c) =>
            result.flatMap { tuples =>
              scopesRepository
                .getByConnectionId(c.getID)
                .map(scopes => tuples :+ (c, scopes))
            }
        }
      }
      .flatMap { connectionsToScopesSeq =>
        FutureUtils
          .foldLeft(connectionsToScopesSeq) { connectionToScopes =>
            val connection = connectionToScopes._1
            val scopes = connectionToScopes._2
            if (scopes.nonEmpty) {
              FutureUtils
                .foldLeft(scopes) { sc =>
                  trackerHubObjectService
                    .getHubPayloadFromTracker(issueKey, connection)
                    .map(_.flatMap(_.getHubIssue match {
                      case basicHubIssue: BasicHubIssue =>
                        basicHubIssue.setEventTriggerContext(context)
                        Some(basicHubIssue)
                      case hubIssue                     =>
                        // sprints do not support visual connections and there are no other alternatives so far
                        // in fact we should never get here cause sprint scheduler should not call this method
                        loggingService.warn(s"Unexpected hub issue class: ${hubIssue.getClass}")
                        None
                    }))
                    .flatMap {
                      case None           => Future.successful(None)
                      case Some(hubIssue) =>
                        if (connection.isLocal)
                          exalateIfMatchesElse(
                            sc.local,
                            issueKey,
                            connection,
                            hubIssue,
                            EditorErrorSide.LOCAL,
                            allowedTriggerCriteria
                          ) {
                            exalateIfMatchesElse(
                              sc.remote,
                              issueKey,
                              connection,
                              hubIssue,
                              EditorErrorSide.REMOTE,
                              allowedTriggerCriteria
                            )(Future.successful(None))
                          }
                        else
                          exalateIfMatchesElse(
                            sc.local,
                            issueKey,
                            connection,
                            hubIssue,
                            EditorErrorSide.LOCAL,
                            allowedTriggerCriteria
                          )(Future.successful(None))
                    }
                }
                .map(_ => None)
            } else {
              loggingService.debug(
                s"Scopes are empty for Visual connection `${connection.getName}` thus synchronization is not triggered"
              )
              Future.successful(None)
            }
          }
          .map(_ => None)
      }
  }

  /** Starts exalate process (sync process) if issue matches rules
    * @param singleSideScope
    *   scope rules from one side
    * @param issueKey
    *   key of the issue
    * @param connection
    * @param hubIssue
    * @param side
    *   LOCAL, REMOTE
    * @param allowedTriggerCriteria
    * @param noExalateFn
    *   alternative function if issue {@code issueKey} does not match scope rules
    * @return
    *   None
    */
  private def exalateIfMatchesElse(
      singleSideScope: SingleSideScope,
      issueKey: IIssueKey,
      connection: IConnection,
      hubIssue: BasicHubIssue,
      side: EditorErrorSide,
      allowedTriggerCriteria: Seq[TriggerCriteria]
  )(noExalateFn: => Future[None.type]) = {

    scopeQueryService
      .validate(singleSideScope, side)
      .map(
        _.foreach { e: EditorCategorizedException =>
          errorService.createError(
            ErrorEntityType.WARNING,
            e,
            connection,
            Some(issueKey),
            None,
            Some(ErrorActType.PAIR),
            Some(e.getBlockingKey)
          )
        }
      )
    singleSideScope match {
      case SingleSideScope(_, _, _, _, _, _, _, _, Some(script)) =>
        if (allowedTriggerCriteria.contains(singleSideScope.triggerCriteria)) {
          executeScopeScript(singleSideScope, script: String, hubIssue, connection)
            .map(issue =>
              if (issue.containsKey(EXALATE_SCOPE_UID)) {
                None
              } else {
                noExalateFn
              }
            )
            .map(_ => None)
        } else noExalateFn
      case _                                                     =>
        lazy val matches = scopeQueryService.matches(hubIssue, singleSideScope)
        if (
          singleSideScope.triggerCriteria == TriggerCriteria.AUTOMATIC &&
          Seq(SyncCriteria.ALL, SyncCriteria.QUERY).contains(singleSideScope.syncCriteria) &&
          matches
        )
          // TODO 7682d878-9a6b-11ea-bb37-0242ac130002 (search for other todos with the same UUID) we should pass the Option[TwinTraceCreateParams] here
          Future
            .successful(eventSchedulerService.scheduleExalateOrUpdateEvent(connection, issueKey))
            .map(_ => None)
        else noExalateFn
    }
  }

  /** Performs visual scope rules, applies project (and scope filtering) to an issue/entity from
    * obtained replica for further creating or updating the issue/entity
    * @param replica
    * @param issue
    * @param connectionId
    * @param syncRequest
    * @return
    *   updated issue
    */
  override def receive(
      replica: IHubIssueReplica,
      issue: BasicHubIssue,
      connectionId: Int,
      syncRequest: ISyncRequest
  ): Future[BasicHubIssue] = {
    val hubIssueReplica = replica.asInstanceOf[BasicHubIssue]
    if (Option(issue.getId).isDefined) {
      // don't apply scopes if the issue already exists
      return Future.successful(issue)
    }
    scopesRepository.getByConnectionId(connectionId).flatMap { scopes =>
      if (hubIssueReplica.containsKey(EXALATE_SCOPE_UID)) {
        val scope_uid = hubIssueReplica.get(EXALATE_SCOPE_UID).asInstanceOf[String]

        scopes.find(scope => scope.local.scopeUid.contains(scope_uid)) match {
          case Some(scope) =>
            val connection = syncRequest.getConnection
            for {
              remoteSideTtOptOpt <-
                if (connection.isLocal)
                  twinTraceRepository.getTwinTraceById(syncRequest.getRemoteTwinTraceId).map(Some(_))
                else Future.successful(None)
              (properThisScope, properRemoteScope) = remoteSideTtOptOpt match {
                case Some(Some(remoteTt)) if connection.isLocal =>
                  val shouldUseLocal = remoteTt.isUseRemoteScope
                  if (shouldUseLocal) (scope.local, scope.remote)
                  else (scope.remote, scope.local)

                case _ => (scope.local, scope.remote)
              }
              result <- scopeQueryService.overrideMainFields(issue, properThisScope)
            } yield issue

          case _ =>
            Future.failed(
              new VisualNotEnoughDataToCreateIssueProcessorException(
                hubIssueReplica.getKey,
                scope_uid
              )
            )
        }

      } else {
        scopes.foldLeft(Future.successful(issue)) { (updatedHubIssueFut, scope) =>
          val connection = syncRequest.getConnection
          for {
            updated <- updatedHubIssueFut
            remoteSideTtOptOpt <-
              if (connection.isLocal)
                twinTraceRepository.getTwinTraceById(syncRequest.getRemoteTwinTraceId).map(Some(_))
              else Future.successful(None)
            (properThisScope, properRemoteScope) = remoteSideTtOptOpt match {
              case Some(Some(remoteTt)) if connection.isLocal =>
                val shouldUseLocal = remoteTt.isUseRemoteScope
                if (shouldUseLocal) (scope.local, scope.remote)
                else (scope.remote, scope.local)

              case _ => (scope.local, scope.remote)
            }
            // A <> B
            matches = scopeQueryService.matches(hubIssueReplica, properRemoteScope)
            result <-
              if (matches) scopeQueryService.overrideMainFields(updated, properThisScope)
              else
                Future.failed(
                  new VisualNotEnoughDataToCreateIssueProcessorException(
                    hubIssueReplica.getKey,
                    properRemoteScope.toString
                  )
                )
          } yield result
        }
      }
    }
  }

  /** The method, which extracts scope rules from provided connection value and saves them to DB.
    * @param connection
    * @param connectionValue
    * @return
    *   \- a seq of scopes that was saved to DB
    */
  override def processScopes(
      connection: IConnection,
      connectionValue: ConnectionValue
  ): Future[Seq[ScopeValue]] = {
    loggingService.info(
      s"#processScopes for connection `${connection.getName}` (${connection.getID})"
    )
    connectionValue.scopes
      .map { scopesValues =>
        //      Future.sequence(
        if (scopesValues.nonEmpty) {
          val scopes: Seq[Scope] = scopesValues.map { scope =>
            val scopeUUID = scope.local.scopeUid
              .map(uid => UUID.fromString(uid))
              .getOrElse(UUID.randomUUID())
            val localScope = scope.local.toSingleSideScope(connection.getID, local = true, scopeUUID)
            val remoteScope =
              scope.remote.toSingleSideScope(connection.getID, local = false, scopeUUID)

            val remoteScript = FutureUtils.resultInf(
              Future
                .successful(None)
                .flatMap(_ =>
                  if (connection.isLocal) instanceEditorFieldService.getLocalEditorFieldValues()
                  else
                    Future.successful(
                      instanceEditorFieldService
                        .getRemoteEditorFieldValues(connection.getRemoteInstance)
                    )
                )
                .map { remoteFieldValues =>
                  getScopeScript(
                    remoteScope,
                    EditorErrorSide.REMOTE,
                    connectionValue,
                    remoteFieldValues
                  )
                }
            )
            val localScript = FutureUtils.resultInf(
              instanceEditorFieldService
                .getLocalEditorFieldValues()
                .map(localFieldValues =>
                  getScopeScript(
                    localScope,
                    EditorErrorSide.LOCAL,
                    connectionValue,
                    localFieldValues
                  )
                )
            )
            Scope(localScope.copy(script = localScript), remoteScope.copy(script = remoteScript))
          }
          loggingService.info(
            s"#processScopes updating scopes for connection `${connection.getName}` (${connection.getID}): ${scopes
                .map(s => s"${s.local.scopeUid}: {local:${s.local.script.getOrElse("<None>")},remote:${s.remote.script.getOrElse("<None>")}}")
                .mkString("; ")}"
          )
          scopesRepository
            .upsertScopes(scopes)
            .map(_ => scopes.map(s => s.toScopeValue))
        } else {
          Future.successful(Nil)
        }
      }
      .getOrElse(Future.successful(Nil))
  }

  /** Converts visual scope rules to script
    * @param singleSideScope
    *   scope rules from one side
    * @param side
    *   LOCAL, REMOTE
    * @param connectionValue
    * @param fieldValues
    * @return
    *   script
    */
  private def getScopeScript(
      singleSideScope: SingleSideScope,
      side: EditorErrorSide,
      connectionValue: ConnectionValue,
      fieldValues: Seq[EditorFieldValue]
  ): Option[String] = {
    val queries = singleSideScope.query.getOrElse(Nil)
    val queryFieldValues = fieldValues.filter(efv => queries.exists(q => q.field.key == efv.key))
    val triggerCriteria = singleSideScope.triggerCriteria
    val syncCriteria = singleSideScope.syncCriteria

    (queryFieldValues, triggerCriteria, syncCriteria) match {
      case (queryFieldValues, triggerCriteria, syncCriteria)
          if Seq(AUTOMATIC, MANUAL).contains(triggerCriteria) &&
            Seq(ALL, QUERY).contains(syncCriteria) =>
        Option(
          scriptGeneratorService.generateScriptScopes(
            singleSideScope,
            side,
            connectionValue,
            queryFieldValues
          )
        )
      case (_, _, _) =>
        None
    }
  }

  /** executes scopes using auto generated script, that checks if issue matches main fields and
    * scope filters. if it does, it schedules an exalate event and sets scope uid as issue
    * attribute. if not, does nothing
    *
    * @return
    *   returns updated BasicHubIssue if matches scope
    */
  private def executeScopeScript(
      scope: SingleSideScope,
      script: String,
      issue: BasicHubIssue,
      connection: IConnection
  ) = {

    val connectionWithoutSecret = new Connection(connection, true)
    // TODO Review where context is initialized
    val context = new util.HashMap[String, Object]()
    context.put("connection", connectionWithoutSecret)
    context.put("issue", issue)
    context.put("entity", issue)
    context.put("ExalateHelper", new ExalateHelper(eventSchedulerService))

    context.put(
      "ExalateAPI",
      JavaConverters
        .mapAsJavaMapConverter(
          Map(
            FieldDataType.OPTION.toString -> new OptionExalateAPI(trackerScopeAndMappingHelper),
            FieldDataType.DATE.toString -> new DateExalateAPI(),
            FieldDataType.TEXT.toString -> new TextExalateAPI(trackerScopeAndMappingHelper),
            FieldDataType.USER.toString -> new UserExalateAPI(trackerScopeAndMappingHelper),
            FieldDataType.MULTI.toString -> JavaConverters
              .mapAsJavaMapConverter(
                Map(
                  FieldDataType.TEXT.toString -> new MultiTextExalateAPI()
                )
              )
              .asJava
          )
        )
        .asJava
    )

    val f = Future.fromTry(
      Try {
        processor.executeProcessor(script, context, ScriptProcessors.RULE)
        issue
      }
        .recoverWith {
          case e: ScriptException =>
            val ts =
              JavaConverters.asScalaBufferConverter(ExceptionUtils.getThrowableList(e)).asScala
            ts.find(_.isInstanceOf[RetriableException]) match {
              case Some(retriableException) =>
                Failure(retriableException)
              case None                     =>
                val message = Option(ExceptionUtils.getRootCauseMessage(e))
                  .getOrElse(
                    s"The script: \n```\n$script\n```\nfailed with the following exception: ${Option(
                        e.getCause
                      ).getOrElse(e).getClass.getSimpleName}"
                  )
                val exception = ScopeScriptEditorException(message, scope, Some(e))
                loggingService.error(
                  "com.exalate.replication.services.replication.scope.ScopeService",
                  () => message,
                  () => exception
                )
                Failure(exception)
            }
        }
    )
    f
  }

}
