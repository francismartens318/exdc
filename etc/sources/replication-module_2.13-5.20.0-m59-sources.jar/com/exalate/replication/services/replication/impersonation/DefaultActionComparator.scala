package com.exalate.replication.services.replication.impersonation

import com.exalate.api.domain.webhook.{INonPersistentWebhookInfo, IWebhookInfo}
import com.exalate.generic.services
import com.exalate.generic.services.api.IActionComparator

class DefaultActionComparator extends IActionComparator {

  override def isSameAction(webhookInfo: IWebhookInfo)(auditLog: services.FullAuditInfo): Boolean =
    false

  override def isSameAction(webhookInfo: INonPersistentWebhookInfo)(
      auditLog: services.FullAuditInfo
  ): Boolean = false

}
