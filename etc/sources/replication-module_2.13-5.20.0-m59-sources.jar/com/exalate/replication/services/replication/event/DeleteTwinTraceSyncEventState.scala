package com.exalate.replication.services.replication.event

import com.exalate.api.domain.event.{EventStatus, ISyncEvent}
import com.exalate.api.domain.twintrace.TwinTraceStatus
import com.exalate.api.persistence.replication.event.{
  IEventDeleteTwinTraceRepository,
  IEventReplicationRepository
}
import com.exalate.api.persistence.twintrace.ITwinTraceRepository
import com.exalate.replication.services.replication.state.IState
import com.google.inject.Inject
import play.api.Logger

import scala.concurrent.ExecutionContext
import scala.concurrent.Future

class DeleteTwinTraceSyncEventState @Inject() (
    eventDeleteTwinTraceRepository: IEventDeleteTwinTraceRepository,
    eventReplicationRepository: IEventReplicationRepository,
    twinTraceRepository: ITwinTraceRepository
)(implicit ec: ExecutionContext)
    extends IState[ISyncEvent] {

  private val LOG: Logger = Logger(
    "com.exalate.replication.services.replication.event.DeleteTwinTraceSyncEventState"
  )

  /** Performs transition of one of the states of SyncEventStateMachine: status `DELETE_TWINTRACE`
    * the next state will be `PROCESSED`
    *
    * @param syncEvent
    * @return
    *   ISyncEvent
    */
  override def transition(syncEvent: ISyncEvent): Future[Option[ISyncEvent]] = {
    LOG.info(
      s"#transition: marking the twinTrace to be deleted for the syncEvent `${syncEvent.getId}` for the issue`${syncEvent.getLocalReplica.getIssueKey.getURN}` and connection `${syncEvent.getConnection.getName}`"
    )
    twinTraceRepository.getTwinTraceById(syncEvent.getTwinTraceId).flatMap {
      case Some(twinTrace) =>
        eventDeleteTwinTraceRepository
          .persistOnDeleteTwinTraceSyncEventState(
            syncEvent,
            EventStatus.PROCESSED,
            twinTrace,
            TwinTraceStatus.UNEXALATED
          )
          .map(Some(_))
      case None            =>
        val connection = syncEvent.getConnection
        val localIssueKey = syncEvent.getLocalReplica.getIssueKey
        LOG.debug(
          s"The issue `$localIssueKey` has been already unexalated for relation `${connection.getName}`."
        )
        eventReplicationRepository.updateSyncEventStatus(syncEvent, EventStatus.PROCESSED)
    }
  }

}
