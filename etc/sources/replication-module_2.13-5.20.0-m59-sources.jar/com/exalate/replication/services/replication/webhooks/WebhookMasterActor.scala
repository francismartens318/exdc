package com.exalate.replication.services.replication.webhooks

import akka.actor.{Actor, Props, Terminated}
import akka.routing.{ActorRefRoutee, RoundRobinRoutingLogic, Router}
import com.exalate.api.persistence.relation.IRelationRepository
import com.exalate.api.persistence.twintrace.ITwinTraceRepository
import com.exalate.replication.services.api.replication.IEventSchedulerNotificationService
import com.exalate.replication.services.api.replication.impersonation.IImpersonationService
import com.exalate.replication.services.api.trigger.ISyncAutomationService
import com.exalate.replication.services.replication.webhooks.WebhookActor.Messages.WebhookMessage
import com.google.inject.Inject

object WebhookMasterActor {

  def props(
      eventSchedulerNotificationService: IEventSchedulerNotificationService,
      connectionRepository: IRelationRepository,
      twinTraceRepository: ITwinTraceRepository,
      impersonationService: IImpersonationService,
      syncAutomationService: ISyncAutomationService
  ): Props = Props(
    new WebhookMasterActor(
      eventSchedulerNotificationService,
      connectionRepository,
      twinTraceRepository,
      impersonationService,
      syncAutomationService
    )
  )

}

class WebhookMasterActor @Inject() (
    eventSchedulerNotificationService: IEventSchedulerNotificationService,
    connectionRepository: IRelationRepository,
    twinTraceRepository: ITwinTraceRepository,
    impersonationService: IImpersonationService,
    syncAutomationService: ISyncAutomationService
) extends Actor {

  var router = {
    val routees = Vector.fill(4) {
      val props = WebhookActor.props(
        eventSchedulerNotificationService,
        connectionRepository,
        twinTraceRepository,
        impersonationService,
        syncAutomationService
      )
      val r = context.actorOf(props)
      context.watch(r)
      ActorRefRoutee(r)
    }
    Router(RoundRobinRoutingLogic(), routees)
  }

  def receive = {
    case w: WebhookMessage =>
      router.route(w, sender())
    case Terminated(a)     =>
      router = router.removeRoutee(a)
      val r = context.actorOf(Props[WebhookActor])
      context.watch(r)
      router = router.addRoutee(r)
  }

}
