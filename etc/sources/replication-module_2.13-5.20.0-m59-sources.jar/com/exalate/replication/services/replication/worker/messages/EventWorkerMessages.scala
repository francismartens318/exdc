package com.exalate.replication.services.replication.worker.messages

import com.exalate.generic.services.FullAuditInfo

object EventWorkerMessages {

  object ProcessEvents
  object AfterTheLastMessage
  case class ProcessWebhookQueue(auditLog: FullAuditInfo)

  object ProcessAuditlogRemoved

}
