package com.exalate.replication.services.replication.request

import com.exalate.api.domain.request.RequestStatus
import com.exalate.api.domain.twintrace.TwinTraceStatus
import com.exalate.api.persistence.replication.request.ICompleteSyncRequestStateRepository
import com.exalate.api.persistence.twintrace.ITwinTraceRepository
import com.exalate.error.services.api.IBugExceptionCategoryService
import com.exalate.replication.services.replication.state.IState
import play.api.Logger

import javax.inject.Inject
import scala.concurrent.{ExecutionContext, Future}

class CompleteRequestState @Inject() (
    completeRequestRepository: ICompleteSyncRequestStateRepository,
    twinTraceRepository: ITwinTraceRepository,
    bugExceptionCategoryService: IBugExceptionCategoryService
)(implicit ec: ExecutionContext)
    extends IState[BasicSyncRequestContext] {

  val LOG = Logger("application.services.replication.request.CompleteRequestState")

  /** Performs transition of one of the states of SyncRequestStateMachine: status `COMPLETE`
    *
    * @param context
    * @return
    *   BasicSyncRequestContext
    */
  override def transition(
      context: BasicSyncRequestContext
  ): Future[Option[BasicSyncRequestContext]] = {
    val BasicSyncRequestContext(basicSyncRequest, connection) = context
    basicSyncRequest.remoteTwinTraceId match {
      case Some(remoteTwinTraceId) =>
        twinTraceRepository
          .getRequestTwinTraceDataByRemoteTwinTraceId(connection.getID, remoteTwinTraceId)
          .flatMap { twinTraceDataOpt =>
            val remoteSyncEventNumber = basicSyncRequest.remoteSyncEventNumber
            val twinTraceStatusOpt = twinTraceDataOpt.flatMap {
              case twinTraceData
                  if twinTraceData.twinStatus == TwinTraceStatus.INITIAL && basicSyncRequest.errorReason.isEmpty =>
                Some(TwinTraceStatus.SYNCHRONIZED)
              case _ => None
            }

            val twinTraceDataIfRemoteIsHigher =
              twinTraceDataOpt.find(_.lastProcessedRemoteEventNumber < remoteSyncEventNumber)
            completeRequestRepository
              .persistCompleteRequestState(
                twinTraceDataIfRemoteIsHigher.map(_.twinId),
                basicSyncRequest,
                RequestStatus.PROCESSED,
                twinTraceStatusOpt
              )
              .map(_.map(r => context.copy(request = r)))
          }

      case _ =>
        val errMsg =
          s"A remote twin trace ID is missed in the sync request with id=${basicSyncRequest.id} though it is expected to be present."
        val ex = bugExceptionCategoryService.generateBugException(None, Some(errMsg))
        Future.failed(ex)
    }
  }

}
