package com.exalate.replication.services.config

/** Exception which is thrown when the validation of invitation is failed
  * @param message
  *   of the exception
  */
case class InvitationValidationException(message: String) extends Exception(message)
