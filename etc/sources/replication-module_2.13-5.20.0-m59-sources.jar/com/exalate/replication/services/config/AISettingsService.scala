package com.exalate.replication.services.config

import com.exalate.api.persistence.ai.IAISettingsRepository
import com.exalate.domain.ai.{AISettingsValue, AISettingsValueExtended}
import com.exalate.replication.services.api.config.IAISettingsService
import com.google.inject.Inject
import play.api.Configuration

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

class AISettingsService @Inject() (
    aiSettingsRepository: IAISettingsRepository,
    configuration: Configuration
) extends IAISettingsService {

  private val aiURL = configuration.get[String]("com.exalate.service.ai.url")

  override def get: Future[Option[AISettingsValueExtended]] = aiSettingsRepository
    .get()
    .map(_.map(aiSettingsValue => AISettingsValueExtended(aiSettingsValue, aiURL)))

  override def upsert(aiSettingsVal: AISettingsValue): Future[AISettingsValue] =
    aiSettingsRepository.upsert(aiSettingsVal)

}
