package com.exalate.replication.services.config

import java.net.URL

import com.exalate.api.domain.connection.{IConnection, INonPersistentConnection}

object ConnectionGroupUtils {

  /** Group a seq of connections into seq of seq, where each sub sequence has common instance
    * @param connections
    * @return
    */
  def getGroupedByInstance(connections: Seq[IConnection]): Seq[Seq[IConnection]] = {

    val initialBuckets: Seq[Seq[IConnection]] = Nil
    connections.foldLeft(initialBuckets) {
      case (buckets, con) =>
        if (
          Option(con.getRemoteInstance.getNodeInfo).isEmpty && Option(
            con.getRemoteInstance.getUrl
          ).isEmpty
        ) {
          buckets
        } else {
          buckets
            .find(_.exists(areConnectionsForSameInstance(con)))
            .fold {
              buckets :+ Seq(con)
            } { equalBucket =>
              buckets.map {
                case e if e == equalBucket => equalBucket :+ con
                case x                     => x
              }
            }
        }
    }

  }

  /** Methods that contains logic for checking whether the values of 2 connection belong to the same
    * instance. Is called in {@link areConnectionsForSameInstance} and
    * {@link areConnectionsForSameInstance}
    * @param instanceUid1
    * @param nodeInfoUrl1
    * @param url1
    * @param instanceUid2
    * @param nodeInfoUrl2
    * @param url2
    * @return
    *   true or false
    */
  private def areForSameInstance(
      instanceUid1: Option[String],
      nodeInfoUrl1: Option[String],
      url1: Option[URL]
  )(instanceUid2: Option[String], nodeInfoUrl2: Option[String], url2: Option[URL]): Boolean = {
    val sameUidOpt = for {
      uid1 <- instanceUid1
      uid2 <- instanceUid2
    } yield uid1 == uid2

    val sameNodeInfoUrlOpt = for {
      ni1 <- nodeInfoUrl1
      ni2 <- nodeInfoUrl2
    } yield ni1 == ni2

    val sameInstanceUrlOpt = for {
      url1 <- url1.map(_.toURI)
      url2 <- url2.map(_.toURI)
    } yield url1 == url2

    (sameUidOpt, sameNodeInfoUrlOpt, sameInstanceUrlOpt) match {
      case (Some(true), _, _) | (_, Some(true), _) | (_, _, Some(true)) => true
      case _                                                            => false

    }
  }

  /** Checks whether connections are for the same instance
    * @param theConnection
    * @param otherConnection
    * @return
    *   true or false
    */
  def areConnectionsForSameInstance(
      theConnection: IConnection
  )(otherConnection: IConnection): Boolean = {
    val uid1 =
      Option(otherConnection.getRemoteInstance.getNodeInfo).flatMap(ni => Option(ni.getInstanceUid))
    val uid2 =
      Option(theConnection.getRemoteInstance.getNodeInfo).flatMap(ni => Option(ni.getInstanceUid))
    val ni1 = Option(otherConnection.getRemoteInstance.getNodeInfo).map(_.getExalateUrl)
    val ni2 = Option(theConnection.getRemoteInstance.getNodeInfo).map(_.getExalateUrl)
    val url1 = Option(otherConnection.getRemoteInstance.getUrl)
    val url2 = Option(theConnection.getRemoteInstance.getUrl)
    areForSameInstance(uid1, ni1, url1)(uid2, ni2, url2)
  }

  /** Checks whether connections are for the same instance
    * @param theConnection
    * @param otherConnection
    * @return
    *   true or false
    */
  def areConnectionsForSameInstance(
      theConnection: INonPersistentConnection
  )(otherConnection: IConnection): Boolean = {
    val uid1 =
      Option(otherConnection.getRemoteInstance.getNodeInfo).flatMap(ni => Option(ni.getInstanceUid))
    val uid2 =
      Option(theConnection.getRemoteInstance.getNodeInfo).flatMap(ni => Option(ni.getInstanceUid))
    val ni1 = Option(otherConnection.getRemoteInstance.getNodeInfo).map(_.getExalateUrl)
    val ni2 = Option(theConnection.getRemoteInstance.getNodeInfo).map(_.getExalateUrl)
    val url1 = Option(otherConnection.getRemoteInstance.getUrl)
    val url2 = Option(theConnection.getRemoteInstance.getUrl)
    areForSameInstance(uid1, ni1, url1)(uid2, ni2, url2)
  }

}
