package com.exalate.replication.services.config

import com.exalate.domain.values.FeatureValue

/** Helper that hold a list of features that exalate support. It is done for compatibility
  */
object EditorFeaturesProvider {

  def get(): Option[Seq[FeatureValue]] = Some(
    Seq(
      // add new features, whenever the config has to be done from the latest version only
      FeatureValue(
        "OPTION_FIELDS_WITH_STR_SUPPORT"
      ), // had to change the scripts since in Azure, OPTION custom fields have String values (instead of BasicHubOption ones)
      FeatureValue(
        "EDITOR_CONTEXT_PROGRESS"
      ), // in order to show when all necessary data (cfs and issue tracker options) from remote side is obtained
      FeatureValue(
        "WILDCARD_MAPPINGS_DEFAULT"
      ) // every mapping (but comments, attachments and labels) behaves as if it has a wildcard map: apply maps and if no map found, try to find remote value locally
    )
  )

}
