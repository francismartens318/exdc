package com.exalate.replication.services.config

import com.google.inject.{Inject, Provider}
import play.api.i18n.{Lang, Messages, MessagesApi}

class MessagesEnglishProvider @Inject() (messagesApi: MessagesApi) extends Provider[Messages] {
  override def get(): Messages = messagesApi.preferred(Seq(Lang("en")))
}
