package com.exalate.replication.services.config

import scala.util.Try

object ErrorTypeNameUtil {

  /** Converts root Cause Error Type Name to Human Readable
    * @param rootCauseErrorTypeName
    * @return
    *   Human Readable Error Type Name
    */
  def getHumanReadableErrorTypeName(rootCauseErrorTypeName: String): String =
    Option(rootCauseErrorTypeName)
      .map(e =>
        Try(Class.forName(e)).toOption
          .map(c => c.getSimpleName)
          .getOrElse(e)
      )
      .orNull

}
