package com.exalate.replication.services.config

import com.exalate.api.ILoggingService
import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.connection.fieldvalues.ConnectionMode
import com.exalate.api.domain.nodeinfo.INonPersistentNodeInfo
import com.exalate.domain.editor.FieldDataType
import com.exalate.domain.transport.message.{ExalateMessage, MessageType}
import com.exalate.domain.transport.trackeroptions._
import com.exalate.domain.values.{
  EditorCustomFieldResponseValue,
  EditorFieldValue,
  FeatureValue,
  VisualFieldValue
}
import com.exalate.replication.services.api.config.{EditorSupportService, IEditorFieldContextService}
import com.exalate.replication.services.api.editor.IEditorCustomFieldService
import com.exalate.replication.services.api.issuetracker.ITrackerOptionService
import com.exalate.replication.services.api.replication.worker.IWorkerNotificationService
import com.exalate.replication.services.issuetracker.InstanceEditorFieldService
import com.exalate.replication.services.transport.value.ExaCompFormatters._
import com.exalate.services.utils.FutureUtils.none
import com.exalate.services.utils.pagination.PaginationUtil._
import com.exalate.services.utils.pagination.{Page, SimplePage}
import com.exalate.util.json.gson.GsonCaseClassValueJsonService
import com.google.inject.Inject
import play.api.libs.json.Json

import scala.concurrent.Future.fromTry
import scala.concurrent.{ExecutionContext, Future}
import scala.util.{Failure, Success, Try}

class EditorFieldContextService @Inject() (
    loggingService: ILoggingService,
    workerNotificationService: IWorkerNotificationService,
    trackerOptionService: ITrackerOptionService,
    editorCustomFieldService: IEditorCustomFieldService,
    instanceEditorFieldService: InstanceEditorFieldService
)(implicit ec: ExecutionContext)
    extends IEditorFieldContextService {

  /** Method with collects data for provided connection and push it to the destination side. The
    * data which sent to the remote side is: Local Editor Field Values and CFs
    * @param mode
    *   \- ConnectionMode: CONFIGURE_BOTH_SIDES or CONFIGURE_ONE_SIDE
    * @param isLocalConnection
    * @param connectionFuture
    * @param nodeInfoFuture
    * @return
    */
  override def pushEditorContext(
      mode: Option[ConnectionMode],
      isLocalConnection: Boolean,
      connectionFuture: Future[IConnection],
      nodeInfoFuture: Future[Option[INonPersistentNodeInfo]]
  ): Future[None.type] = {
    loggingService.debug(s"Going to push editor context: mode $mode: is local: $isLocalConnection")
    if (!mode.contains(ConnectionMode.CONFIGURE_BOTH_SIDES)) Future.successful(None)
    else if (isLocalConnection) Future.successful(None)
    else {
      for {
        nodeInfoOpt <- nodeInfoFuture
        exalateUrlOpt = nodeInfoOpt match {
          case Some(nodeInfo) if EditorSupportService.isEditorSupported(nodeInfo) =>
            Option(nodeInfo.getExalateUrl)
          case _                                                                  => None
        }
        r <- Future
          .successful(exalateUrlOpt)
          .flatMap {
            case None             =>
              loggingService.warn("Exalate URL was not found")
              none
            case Some(exalateUrl) =>
              connectionFuture
                .flatMap { connection =>
                  loggingService.trace("Start to prepare data to push to remote side")
                  val connectionId = connection.getID

                  val editorValueOpt =
                    Json.parse(nodeInfoOpt.get.getEditorValue).asOpt[VisualFieldValue]
                  val doesSupportEditorContextProgress =
                    editorValueOpt.exists(_.features.contains(FeatureValue("EDITOR_CONTEXT_PROGRESS")))

                  for {
                    // Push Editor Main Field Options
                    localEditorMainFieldOptions <- instanceEditorFieldService
                      .getLocalEditorMainFieldValues()
                      .map(_.filter(_.`type`.key == FieldDataType.OPTION.toString))
                    mainFieldOptionStreams = getOptionStreams(localEditorMainFieldOptions)
                    resultMainFieldOptions <- pushOptionStreams(mainFieldOptionStreams, connectionId)
                    _ <- pushOptionResponseNumber(
                      resultMainFieldOptions,
                      connectionId,
                      doesSupportEditorContextProgress
                    )

                    // Push Editor Public Field Options
                    localPublicEditorOptionFields <- instanceEditorFieldService
                      .getLocalPublicEditorFieldValues()
                      .map(_.filter(_.`type`.key == FieldDataType.OPTION.toString))
                    localPublicEditorOptionStreams = getOptionStreams(localPublicEditorOptionFields)
                    resultDefaultOptions <- pushOptionStreams(
                      localPublicEditorOptionStreams,
                      connectionId
                    )
                    _ <- pushOptionResponseNumber(
                      resultDefaultOptions,
                      connectionId,
                      doesSupportEditorContextProgress
                    )

                    // Push Editor Custom Fields
                    cfStream = getCustomFieldsStream()
                    cfJsonStream = toCfJsonStream(cfStream)
                    _ = loggingService.trace(
                      s"Going to push Messages with type ${MessageType.CUSTOM_FIELD_RESPONSE.toString}"
                    )
                    resultCf <- pushMessages(
                      cfJsonStream,
                      json =>
                        ExalateMessage(
                          json,
                          MessageType.CUSTOM_FIELD_RESPONSE.toString,
                          connection.getID
                        )
                    )
                    _ <-
                      if (doesSupportEditorContextProgress)
                        Future.fromTry(
                          pushMessage(
                            ExalateMessage(
                              resultCf.toString,
                              MessageType.CUSTOM_FIELD_RESPONSE_NUMBER.toString,
                              connection.getID
                            )
                          )
                        )
                      else
                        Future.successful(None)

                    // Push Editor Custom Field Options
                    localCustomEditorOptionFields <- instanceEditorFieldService
                      .getCustomLocalEditorFieldValues()
                      .map(_.filter(_.`type`.key == FieldDataType.OPTION.toString))
                    customOptionStreams = getOptionStreams(localCustomEditorOptionFields)
                    resultCustomOptions <- pushOptionStreams(customOptionStreams, connectionId)
                    _ <- pushOptionResponseNumber(
                      resultCustomOptions,
                      connectionId,
                      doesSupportEditorContextProgress
                    )
                  } yield None
                }
          }
      } yield r
    }
  }

  private def pushOptionStreams(
      optionStreams: Seq[Stream[Future[SimplePage[OptionResponseContentValue]]]],
      connectionId: Int
  ): Future[Int] = {
    val optionJsonStreams = optionStreams.map(toOptionJsonStream)

    optionJsonStreams.foldLeft(Future.successful(0)) { (progress, optionJsonStream) =>
      progress.flatMap { p =>
        loggingService.trace(
          s"Going to push Messages with type ${MessageType.OPTION_RESPONSE.toString}"
        )
        pushMessages(
          optionJsonStream,
          json => ExalateMessage(json, MessageType.OPTION_RESPONSE.toString, connectionId)
        )
          .map(p + _)
      }
    }
  }

  private def pushOptionResponseNumber(
      result: Int,
      connectionId: Int,
      doesSupportEditorContextProgress: Boolean
  ): Future[None.type] =
    if (doesSupportEditorContextProgress)
      Future.fromTry(
        pushMessage(
          ExalateMessage(result.toString, MessageType.OPTION_RESPONSE_NUMBER.toString, connectionId)
        )
      )
    else
      Future.successful(None)

  /** Get a seq of CFs and convert them to Stream of SimplePage
    * @return
    */
  private def getCustomFieldsStream(): Stream[Future[SimplePage[EditorCustomFieldResponseValue]]] =
    // FIXME EXACOMP-546 the entire stream is a one pager - all the custom fields in memory
    Stream(
      editorCustomFieldService
        .getCustomFieldValues()
        .map(cfs =>
          SimplePage(
            cfs
              .filter(cf =>
                FieldDataType
                  .withNameOpt(cf.`type`.key)
                  .contains(FieldDataType.TEXT) ||
                  FieldDataType
                    .withNameOpt(cf.`type`.key)
                    .contains(FieldDataType.OPTION) ||
                  FieldDataType
                    .withNameOpt(cf.`type`.key)
                    .contains(FieldDataType.USER)
              )
              .map(cf => EditorCustomFieldResponseValue(None, cf.key, cf)),
            isLast = true
          )
        )
    )

  // FIXME Seq[Stream[Future[...]]] - means that we pull all of the fields (both system and custom) metadata into memory - should be Stream[PageLike[Stream[Future[...]]]] where first stream is finite and known
  /** Get a seq of options for provided field and convert them to Stream of SimplePage
    * @param localEditorFields
    * @return
    */
  private def getOptionStreams(
      localEditorFields: Seq[EditorFieldValue]
  ): Seq[Stream[Future[SimplePage[OptionResponseContentValue]]]] =
    localEditorFields
      .map {
        case f if f.key == EditorFields.PROJECT.toString    =>
          trackerOptionService
            .fetchProjectOptionsStream()
            .map(_.map(toOptionResponseValuePage(f.key, None)))
        case f if f.key == EditorFields.ISSUE_TYPE.toString =>
          trackerOptionService
            .fetchIssuetypeOptions()
            .map(_.map(toOptionResponseValuePage(f.key, None)))
        case f if f.key == EditorFields.PRIORITY.toString   =>
          trackerOptionService
            .fetchPriorityOptions()
            .map(_.map(toOptionResponseValuePage(f.key, None)))
        case f if f.key == EditorFields.STATUS.toString     =>
          trackerOptionService
            .fetchStatusOptions()
            .map(_.map(toOptionResponseValuePage(f.key, None)))
        case f                                              =>
          trackerOptionService
            .fetchCustomFieldOptionsWithDependencies(f)
            .map(_.map(toOptionResponseValuePage(f.key, None)))
      }

  /** Collect input data into SimplePage[OptionResponseContentValue]
    * @param field
    *   key of the field PROJECT, ISSUE_TYPE, etc
    * @param jwtOpt
    *   accessToken
    * @param p
    *   page of options obtained from issue tracker
    * @return
    *   SimplePage[OptionResponseContentValue]
    */
  private def toOptionResponseValuePage(field: String, jwtOpt: Option[String])(
      p: Page[IssueTrackerOption]
  ): SimplePage[OptionResponseContentValue] = SimplePage(
    Seq(
      OptionResponseContentValue(
        jwtOpt,
        OptionResponseStatus.SUCCESS.toString,
        field,
        Option(p.results.map(EditorOptionsValueHelper.toIssueTrackerOptionValue))
      )
    ),
    isLast = p.isLast
  )

  /** Converts inside of stream value EditorCustomFieldResponseValue into string
    * @param cfStream
    * @return
    *   Stream[Future[SimplePage[Try[String]]]]
    */
  private def toCfJsonStream(cfStream: Stream[Future[SimplePage[EditorCustomFieldResponseValue]]]) =
    cfStream.map(
      _.map(
        _.map(cfv =>
          GsonCaseClassValueJsonService
            .write[EditorCustomFieldResponseValue](cfv)
            .recoverWith {
              case e: Exception =>
                loggingService.error(
                  "com.exalate.replication.services.config.EditorFieldContextService",
                  () => s"#pushEditorContext failed to serialize custom field value `$cfv`",
                  () => e
                )
                Failure(e)
            }
        )
      )
    )

  /** Converts inside of stream value OptionResponseContentValue into string
    * @param optStream
    * @return
    *   Stream[Future[SimplePage[Try[String]]]]
    */
  private def toOptionJsonStream(
      optStream: Stream[Future[SimplePage[OptionResponseContentValue]]]
  ) =
    optStream.map(
      _.map(
        _.map(optVal =>
          GsonCaseClassValueJsonService
            .write[OptionResponseContentValue](optVal)
            .recoverWith {
              case e: Exception =>
                loggingService.error(
                  "com.exalate.replication.services.config.EditorFieldContextService",
                  () => s"#pushEditorContext failed to serialize option value `$optVal`",
                  () => e
                )
                Failure(e)
            }
        )
      )
    )

  /** Push messages process, and counting of the amount of pushed messages
    * @param optionJsonStream
    * @param messageFn
    * @return
    *   number of messages
    */
  private def pushMessages(
      optionJsonStream: Stream[Future[SimplePage[Try[String]]]],
      messageFn: String => ExalateMessage
  ): Future[Int] =
    foldLeftInfStream[SimplePage[Try[String]], Int](
      optionJsonStream,
      (p: SimplePage[Try[String]]) => p.isLast
    )(Future.successful(0)) { (count: Int, page: SimplePage[Try[String]]) =>
      fromTry(page.results.foldLeft(Success(0): Try[Int]) {
        case (fail: Failure[Int], _) => fail
        case (_, Success(json))      =>
          pushMessage(messageFn(json))
          Success(count + 1)
        case (_, _)                  =>
          Success(count)
      })
    }

  /** Push one single message by firing Send Message
    * @param m
    *   message
    * @return
    *   None
    */
  def pushMessage(m: ExalateMessage): Try[None.type] = {
    loggingService.trace(s"going to push exalate message for connection ${m.connectionId}")
    workerNotificationService.fireSendMessage(m)
    Success(None)
  }

}
