package com.exalate.replication.services.config

import java.net.URL
import com.exalate.api.domain.instance.INonPersistentInstance
import com.exalate.basic.domain.instance.NonPersistentInstance
import com.exalate.domain.values.NodeInfoValue
import com.exalate.replication.services.api.config.IUrlInferringService
import com.exalate.replication.services.api.transport.mapper.IMapperExalateUrlsClient
import com.exalate.replication.services.transport.v1.rest.INodeInfoClient
import com.exalate.replication.services.transport.value.helpers.NodeInfoValueHelper
import com.google.inject.Inject

import scala.concurrent.Future
import scala.concurrent.ExecutionContext

class UrlInferringService @Inject() (
    nodeInfoClient: INodeInfoClient,
    mapperExalateUrlsClient: IMapperExalateUrlsClient
)(implicit ec: ExecutionContext)
    extends IUrlInferringService {

  /** Sets node infoo and exalate urls from mapper to the input {@code nonPersistentInstance}
    * @param nonPersistentInstance
    *   that should be updated
    * @return
    *   updated nonPersistentInstance
    */
  override def setNodeInfoAndUrls(
      nonPersistentInstance: INonPersistentInstance
  ): Future[INonPersistentInstance] =
    getNodeInfoViaDifferentUrls(nonPersistentInstance)

  /** Gets node info
    * @param nonPersistentInstance
    * @return
    */
  private def getNodeInfoViaDifferentUrls(
      nonPersistentInstance: INonPersistentInstance
  ): Future[INonPersistentInstance] =
    getAndSetNodeInfoWithExalateUrl(nonPersistentInstance)
      .recoverWith {
        case e =>
          getAndSetNodeInfoWithTrackerUrl(nonPersistentInstance).recoverWith {
            case _ => Future.failed(e)
          }
      }

  /** Sets node info and urls to the input {@code nonPersistentInstance}
    * @param nonPersistentInstance
    * @return
    */
  override def getAndSetNodeInfoWithTrackerUrl(
      nonPersistentInstance: INonPersistentInstance
  ): Future[INonPersistentInstance] =
    inferExalateUrl(nonPersistentInstance)
      .flatMap(getAndSetNodeInfoWithExalateUrl)

  /** Infer Exalate Url from mapper
    * @param nonPersistentInstance
    * @return
    *   updated nonPersistentInstance
    */
  private def inferExalateUrl(
      nonPersistentInstance: INonPersistentInstance
  ): Future[INonPersistentInstance] =
    mapperExalateUrlsClient
      .getExalateUrl(nonPersistentInstance.getUrl)
      .map(swapExalateAndIssueTrackerUrls(nonPersistentInstance))

  /** Gets node info by sending request and set a response to the input
    * {@code nonPersistentInstance}
    * @param nonPersistentInstance
    * @return
    *   updated nonPersistentInstance with node info
    */
  override def getAndSetNodeInfoWithExalateUrl(
      nonPersistentInstance: INonPersistentInstance
  ): Future[INonPersistentInstance] =
    nodeInfoClient
      .getNodeInfo(nonPersistentInstance)
      .map(setNodeInfo(nonPersistentInstance))

  /** Swaps Exalate And Issue Tracker Urls
    * @param nonPersistentInstance
    *   instance data that should be updated
    * @param exalateUrl
    *   extracted url from mapper
    * @return
    *   updated nonPersistentInstance
    */
  private def swapExalateAndIssueTrackerUrls(nonPersistentInstance: INonPersistentInstance)(
      exalateUrl: URL
  ): INonPersistentInstance =
    new NonPersistentInstance(
      nonPersistentInstance.getName,
      nonPersistentInstance.getDescription,
      exalateUrl,
      nonPersistentInstance.getUrl,
      nonPersistentInstance.getStatus,
      nonPersistentInstance.getNodeInfo,
      nonPersistentInstance.getIssueTrackerSettings,
      nonPersistentInstance.getRemoteUsername,
      nonPersistentInstance.getRemoteUserPassword,
      nonPersistentInstance.isAuthenticationRequired,
      nonPersistentInstance.getCustomFieldValues,
      nonPersistentInstance.getFieldValues
    )

  /** Update nodeInfo in the input {@code nonPersistentInstance}
    * @param nonPersistentInstance
    *   instance data that should be updated
    * @param nodeInfoValue
    *   new node info
    * @return
    *   updated nonPersistentInstance
    */
  private def setNodeInfo(nonPersistentInstance: INonPersistentInstance)(
      nodeInfoValue: NodeInfoValue
  ) =
    new NonPersistentInstance(
      nonPersistentInstance.getName,
      nonPersistentInstance.getDescription,
      nonPersistentInstance.getUrl,
      nonPersistentInstance.getIssueTrackerUrl,
      nonPersistentInstance.getStatus,
      NodeInfoValueHelper.toNonPersistentNodeInfo(nodeInfoValue),
      nonPersistentInstance.getIssueTrackerSettings,
      nonPersistentInstance.getRemoteUsername,
      nonPersistentInstance.getRemoteUserPassword,
      nonPersistentInstance.isAuthenticationRequired,
      nonPersistentInstance.getCustomFieldValues,
      nonPersistentInstance.getFieldValues
    )

  /** Gets nodeinfo via different urls: uses input url, if it fails goes to mapper and gets exalate
    * url and then makes a request with it
    * @param url
    * @param remoteUsername
    * @param remotePassword
    * @return
    *   Future[NodeInfoValue]
    */
  override def getNodeInfoViaDifferentUrls(
      url: String,
      remoteUsername: Option[String],
      remotePassword: Option[String]
  ): Future[NodeInfoValue] =
    nodeInfoClient
      .getNodeInfo(url, remoteUsername, remotePassword)
      .recoverWith {
        case e =>
          val issueTrackerUrl = new URL(url)
          mapperExalateUrlsClient
            .getExalateUrl(issueTrackerUrl)
            .recoverWith { case _ => Future.failed(e) }
            .flatMap { nodeUrl =>
              nodeInfoClient
                .getNodeInfo(nodeUrl.toExternalForm, None, None)
            }

      }

}
