package com.exalate.replication.services.config

import javax.inject.Inject
import com.exalate.api.domain.connection.INonPersistentConnection
import com.exalate.api.exception.script.CompilationErrorScriptException
import com.exalate.api.processor.IExalateProcessor
import com.exalate.replication.services.api.config.IValidateRelationService
import org.apache.commons.lang3.StringUtils

import scala.concurrent.Future
import scala.util.{Failure, Success, Try}

class ValidateRelationService @Inject() (exalateProcessor: IExalateProcessor)
    extends IValidateRelationService {

  /** Validate Scripts
    * @param nonPersistentRelation
    * @return
    */
  override def validate(nonPersistentRelation: INonPersistentConnection): Future[None.type] =
    Future.fromTry(validateScripts(nonPersistentRelation))

  /** Validate Scripts
    * @param relation
    *   connection
    * @return
    */
  private def validateScripts(relation: INonPersistentConnection): Try[None.type] = {
    val dataFilter = relation.getDataFilter
    val createProcessor = relation.getCreateProcessor
    val changeProcessor = relation.getChangeProcessor

    validateCode(dataFilter, "Data Filter")
      .flatMap(_ => validateCode(createProcessor, "Create Processor"))
      .flatMap(_ => validateCode(changeProcessor, "Change Processor"))

  }

  /** Validate part of the entire script: Create Processor, Change Processor or Data Filter
    * @param code
    *   Create Processor, Change Processor or Data Filter
    * @param field
    *   name of the field where code taken from
    * @return
    *   None
    */
  def validateCode(code: String, field: String): Try[None.type] =
    if (StringUtils.isNotBlank(code)) {
      Try(
        exalateProcessor.compile(code)
      ).flatMap(_ => Success(None))
        .recoverWith {
          case e: CompilationErrorScriptException =>
            Failure(new CompilationErrorScriptException(s"$field:'${e.getMessage}'"))
        }
    } else {
      Success(None)
    }

}
