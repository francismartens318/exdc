package com.exalate.replication.services.config

import com.exalate.api.ILoggingService
import com.exalate.api.domain.ErrorEntityType
import com.exalate.api.domain.connection._
import com.exalate.api.domain.connection.fieldvalues.{
  ConnectionMode,
  ConnectionWasPublished,
  FieldValues
}
import com.exalate.api.domain.connectiondraft.{ConnectionDraftOperation, ConnectionDraftStatus}
import com.exalate.api.domain.instance.InstanceStatus.{ACTIVE, DEACTIVATED, INITIAL}
import com.exalate.api.domain.instance.{INonPersistentInstance, InstanceStatus}
import com.exalate.api.domain.nodeinfo.INonPersistentNodeInfo
import com.exalate.api.exception.bug.BugException
import com.exalate.api.persistence.connectiondraft.IConnectionDraftRepository
import com.exalate.api.persistence.error.IErrorRepository
import com.exalate.api.persistence.instance.IInstanceRepository
import com.exalate.api.persistence.mappings.IMappingsRepository
import com.exalate.api.persistence.metrics.IMetricsRepository
import com.exalate.api.persistence.relation.IRelationRepository
import com.exalate.api.persistence.replication.event.IEventReplicationRepository
import com.exalate.api.persistence.replication.request.IRequestReplicationRepository
import com.exalate.api.persistence.scopes.IScopesRepository
import com.exalate.api.persistence.trigger.ITriggerRepository
import com.exalate.api.persistence.twintrace.ITwinTraceRepository
import com.exalate.basic.domain.connection.NonPersistentConnectionIssueTrackerSettings
import com.exalate.basic.domain.instance.NonPersistentInstance
import com.exalate.basic.domain.util.SemanticVersionService
import com.exalate.domain.editor.mappings.Arrow._
import com.exalate.domain.editor.mappings.{MapValue, MappingValue}
import com.exalate.domain.editor.scopes.{Scope, ScopeValue, SingleSideScopeValue}
import com.exalate.domain.metrics.MetricEvents
import com.exalate.domain.transport.message.ExalateMessage
import com.exalate.domain.values._
import com.exalate.domain.values.connection._
import com.exalate.domain.values.v2_5.connection.AcceptInvitationValue
import com.exalate.domain.values.v4.{ConnectionInfoValue, ConnectionNameValue}
import com.exalate.error.services.api.IBugExceptionCategoryService
import com.exalate.replication.services.api.config.IConnectionService.ConnectionId
import com.exalate.replication.services.api.config._
import com.exalate.replication.services.api.error.GettingNodeInfoFailedException
import com.exalate.replication.services.api.issuetracker.IInstanceNameService
import com.exalate.replication.services.api.license.ILicenseService
import com.exalate.replication.services.api.replication.ICleanServiceWrapper
import com.exalate.replication.services.api.replication.in.IPollSchedulerService
import com.exalate.replication.services.api.replication.mapping.IMappingService
import com.exalate.replication.services.api.replication.oauth.IOAuthService
import com.exalate.replication.services.api.replication.scope.IScopeService
import com.exalate.replication.services.api.replication.worker.IWorkerNotificationService
import com.exalate.replication.services.api.transport.IConnectionValueHelper
import com.exalate.replication.services.api.transport.v3_6.IExternalBasicConnectionClient
import com.exalate.replication.services.config.ConnectionService.SECRET_LENGTH
import com.exalate.replication.services.replication.worker.{
  ConnectionAccepted,
  ConnectionInitiated,
  ConnectionUpdated
}
import com.exalate.replication.services.transport.utils.InstanceConverter
import com.exalate.replication.services.transport.v1.rest.{
  IConnectionClient,
  INodeInfoClient,
  NodeInfoProvider
}
import com.exalate.replication.services.transport.value.helpers.NodeInfoValueHelper
import com.exalate.services.utils.FutureUtils
import com.exalate.util.DateUtil
import com.exalate.util.json.gson.GsonCaseClassValueJsonService
import com.google.inject.Inject
import org.apache.commons.codec.binary.Base64
import play.api.libs.json._

import java.sql.Timestamp
import java.text.SimpleDateFormat
import java.util
import java.util.UUID
import scala.collection.JavaConverters._
import scala.concurrent.{ExecutionContext, Future}
import scala.util.{Failure, Random, Success, Try}

class ConnectionService @Inject() (
    connectionRepository: IRelationRepository,
    validateConnectionService: IValidateRelationService,
    generalSettingsService: IGeneralSettingsService,
    nodeInfoClient: INodeInfoClient,
    urlInferringService: IUrlInferringService,
    nodeInfoProvider: NodeInfoProvider,
    triggerRepository: ITriggerRepository,
    licenseService: ILicenseService,
    connectionValueHelper: IConnectionValueHelper,
    twinTraceRepository: ITwinTraceRepository,
    connectionClient: IConnectionClient,
    pollSchedulerService: IPollSchedulerService,
    workerNotificationService: IWorkerNotificationService,
    bugExceptionCategoryService: IBugExceptionCategoryService,
    trackerExtraLogicService: ITrackerExtraLogicService,
    loggingService: ILoggingService,
    connectionDraftRepository: IConnectionDraftRepository,
    scopesRepository: IScopesRepository,
    mappingsRepository: IMappingsRepository,
    editorFieldContextService: IEditorFieldContextService,
    oauthService: IOAuthService,
    externalBasicConnectionClient: IExternalBasicConnectionClient,
    basicConnectionService: IBasicConnectionService,
    mappingService: IMappingService,
    scopeService: IScopeService,
    instanceRepository: IInstanceRepository,
    connectionNameService: IInstanceNameService,
    errorRepository: IErrorRepository,
    metricPersis: IMetricsRepository,
    eventReplicationRepository: IEventReplicationRepository,
    requestReplicationRepository: IRequestReplicationRepository,
    cleanService: ICleanServiceWrapper
)(implicit ec: ExecutionContext)
    extends IConnectionService {
  private val CONFIGURE_BOTH_SIDES_MODE: String = ConnectionMode.CONFIGURE_BOTH_SIDES.toString
  private val SCRIPT_MODE: String = ConnectionMode.SCRIPT.toString

  /** Gets a connection from DB by name
    * @param connectionName
    * @return
    */
  override def get(connectionName: String): Future[Option[IConnection]] =
    connectionRepository.getConnectionFuture(connectionName)

  /** Gets a connection from DB by id
    * @param connectionId
    * @return
    */
  override def get(connectionId: Int): Future[Option[IConnection]] =
    connectionRepository.getConnectionFuture(connectionId)

  override def findAllIds(projectId: Option[String] = None): Future[Seq[ConnectionId]] =
    connectionRepository.findConnectionIdsAndMainFieldInfosFuture.map {
      connectionIdsAndMainFieldInfos =>
        connectionIdsAndMainFieldInfos
          .filter { item =>
            val mainFieldInfoValueOpt: Option[MainFieldInfoValue] =
              syncMainFieldInfoStrToValue(item.mainFieldInfo)

            val shouldInclude =
              (projectId, mainFieldInfoValueOpt) match {
                case (None, _)                               => true
                case (_, None)                               => false
                case (Some(prjId), Some(mainFieldInfoValue)) =>
                  mainFieldInfoValue.local.toSeq.flatten.map(_.value.value).contains(prjId)
              }

            shouldInclude
          }
          .map(_.id)
    }

  private def syncMainFieldInfoStrToValue(
      syncMainFieldInfoStr: Option[String]
  ): Option[MainFieldInfoValue] = syncMainFieldInfoStr
    .filter(_.nonEmpty)
    .flatMap(mainFieldInfoValue => Json.parse(mainFieldInfoValue).asOpt[MainFieldInfoValue])

  /** Gets a list of all Simplified connections from DB or for particular project
    *
    * @return
    *   This method returns only the following data of the connection * id * name * description *
    *   send protocol * receive protocol * status and invitation status * instance information
    *   without node info
    */
  // TODO: remove field values
  // TODO we should create a case class for this and return it instead of the actual IConnection
  override def findAllSimplified(
      fieldValues: Map[String, String] = Map.empty,
      connectionNameOpt: Option[String] = None,
      projectId: Option[String] = None,
      pageRequest: PageRequest = PageRequest.ALL
  ): Future[(Seq[IConnection], Int)] =
    connectionRepository
      .findSimplifiedConnectionsFuture(connectionNameOpt, pageRequest)
      .map { result =>
        val filteredConnections = result.results.filter { c =>
          val connectionFieldValues: Map[String, String] =
            Option(c.getTrackerSettings.getFieldValues).map(_.asScala.toMap).getOrElse(Map.empty)
          val mainFieldInfoValueOpt: Option[MainFieldInfoValue] =
            syncMainFieldInfoStrToValue(Option(c.getSyncMainFieldInfo))

          // if projectId is not provided we should include connection
          // if projectId is provided but we do not have mainFieldInfoValue we should NOT include connection
          // if both are provided check whether mainFieldInfoValueOpt has projectId
          val shouldInclude =
            if (projectId.forall(_.isEmpty)) true
            else if (mainFieldInfoValueOpt.isEmpty) false
            else if (c.isLocal) {
              mainFieldInfoValueOpt.get.local.toSeq.flatten
                .map(_.value.value)
                .contains(projectId.get) ||
              mainFieldInfoValueOpt.get.remote.toSeq.flatten
                .map(_.value.value)
                .contains(projectId.get)
            } else
              mainFieldInfoValueOpt.get.local.toSeq.flatten
                .map(_.value.value)
                .contains(projectId.get)

          (fieldValues.toSet.subsetOf(
            connectionFieldValues.toSet
          ) // making sure that editor connections can still have tracker-specific field values
          && shouldInclude)
        }
        (filteredConnections, result.total)
      }

  /** Validates provided invitation Value and prepares CommunicationValue for it
    * @param invitationValue
    * @return
    *   the updated InvitationValue
    */
  override def validateAndPrepareInvitation(
      invitationValue: InvitationValue
  ): Future[InvitationValue] =
    for {
      localNodeInfo <- nodeInfoProvider.get
      iv <- invitationValue.invitedInstanceUid match {
        case None                     =>
          Future.successful(invitationValue)
        case Some(invitedInstanceUid) =>
          val localInstanceUidOpt = localNodeInfo.instanceUid
          localInstanceUidOpt match {
            case Some(localInstanceUid) if localInstanceUid == invitedInstanceUid =>
              Future.successful(invitationValue)
            case _                                                                =>
              Future.failed(
                InvitationValidationException("The invitation was not intended for this instance")
              )
          }
      }
      invitingCommunication = iv.connection.communication
      localReceiveProtocol = inferLocalReceiveProtocol(invitingCommunication.sendProtocol)
      invitedComValue = CommunicationValue(
        "DIRECT_HTTP",
        Some(localReceiveProtocol.name),
        invitingCommunication.remoteUrl,
        iv.nodeInfo.baseUrl,
        None,
        Some(localNodeInfo),
        None,
        None,
        None
      )
    } yield iv.copy(
      connection = iv.connection.copy(
        communication = invitedComValue,
        syncRules = iv.connection.syncRules.map(_.copy(fieldValues = None))
      )
    )

  /** Delete provided connection and its usages from DB
    * @param connection
    * @return
    */
  override def deleteConnectionAndUsage(connection: IConnection): Future[None.type] =
    for {
      _ <- licenseService.updateLicenseUsages(
        connection.getRemoteInstance.getID,
        payed = false
      ) // bug: XLT-4795 if we delete one connection with paid instance the other connections for that instance would lose their payed status
      _ <- connectionRepository
        .deleteConnectionAndUsages(connection)
        .map(result => cleanService.deleteRelatedBlobs(result.blobPathsToDelete))
        .map { _ =>
          pollSchedulerService.removePollScheduleIfExists(connection.getID)
          workerNotificationService.fireAllWorkerNotifications()
        }
    } yield None

  /** Gets connection context, namely triggers count & issues Count
    * @param connectionId
    * @return
    */
  override def getConnectionContext(connectionId: Int): Future[Option[ConnectionInfoValue]] =
    for {
      instanceOpt <- get(connectionId).map(_.map(_.getRemoteInstance))
      triggersCountOpt <- instanceOpt
        .map(i => triggerRepository.getCountForInstance(i.getID).map(Some.apply))
        .getOrElse(Future.successful(None))
      issuesCountOpt <- instanceOpt
        .map(i => twinTraceRepository.getCountForInstance(i.getID).map(Some.apply))
        .getOrElse(Future.successful(None))
    } yield issuesCountOpt.map(ic => ConnectionInfoValue(triggersCountOpt.get, ic))

  /** Gets node info of the remote instnace from provided connection
    * @param npConn
    * @return
    */
  private def getNodeInfo(npConn: INonPersistentConnection): Option[INonPersistentNodeInfo] =
    Option(npConn.getRemoteInstance).flatMap(i => Option(i.getNodeInfo))

  /** Connection initialization method, which includes creating of connection (saving to Db), firing
    * Connection Initiated Event and pushing Editor Context to the remote side
    * @param nonPersistentConnection
    *   \- non Persistent Connection value obtained from connectionValue from frontend
    * @param adminUserKeyOpt
    * @return
    *   Tuple(message, connection)
    */
  override def initiate(
      nonPersistentConnection: INonPersistentConnection,
      adminUserKeyOpt: Option[String]
  ): Future[(String, IConnection)] = {
    val betweenStr = Option(nonPersistentConnection.getRemoteInstance)
      .flatMap(i => Option(i.getName))
      .map(n => s"between `${nonPersistentConnection.getLocalInstanceName}` and `$n`")
      .getOrElse("")
    loggingService.info(
      s"#initate connection: `${nonPersistentConnection.getName}`$betweenStr at ${DateUtil.dateNowStr()}"
    )
    val mode = Option(nonPersistentConnection.getMode)
    val connectionModeOpt = getConnectionMode(mode)
    lazy val remoteInstanceName = Option(nonPersistentConnection.getRemoteInstance)
      .flatMap(i => Option(i.getName))
      .getOrElse("No remote instance name")

    val withNodeInfoFuture = setNodeInfo(nonPersistentConnection, None)
    val nodeInfoFuture = withNodeInfoFuture.map(getNodeInfo)

    val connectionFuture = for {
      withNodeInfo <- withNodeInfoFuture
      nodeInfoOpt = getNodeInfo(withNodeInfo)
      _ <- shouldConnectionBeInitiatedUpgraded(connectionModeOpt)
      // validate that the user, initiating a visual connection has a proper token
      _ <- (connectionModeOpt, nodeInfoOpt, adminUserKeyOpt) match {

        case (Some(ConnectionMode.CONFIGURE_BOTH_SIDES), Some(nodeInfo), Some(adminUserKey))
            if Option(nodeInfo.getInstanceUid).isDefined && !nonPersistentConnection.isLocal =>
          val remoteInstanceUid = nodeInfo.getInstanceUid
          oauthService
            .findFirstOAuthDataWithAccessToken(remoteInstanceUid, adminUserKey)
            .flatMap {
              case None    =>
                Future.failed(
                  new BugException(
                    s"#initiate No access token found for remoteInstanceUid=`$remoteInstanceUid` and user=`$adminUserKey` not creating the connection `${nonPersistentConnection.getName}`. Please create a new connection."
                  )
                )
              case Some(_) => Future.successful(None)
            }
        case (Some(ConnectionMode.CONFIGURE_BOTH_SIDES), _, None)
            if !nonPersistentConnection.isLocal =>
          Future.failed(
            new BugException(
              s"#initiate No user detected in context! Can't create a visual connection."
            )
          )
        case (Some(ConnectionMode.CONFIGURE_BOTH_SIDES), _, _)
            if !nonPersistentConnection.isLocal =>
          Future.failed(
            new BugException(
              s"#initiate Failed to communicate with the remote instance $remoteInstanceName. Please try again."
            )
          )
        case _ =>
          Future.successful(None)
      }
      withSecret = setConnectionInvitationSecret(withNodeInfo)
      connection <- create(withSecret)
      _ <- trackerExtraLogicService.afterCreateConnection(
        connection,
        Option(nonPersistentConnection.getTrackerSettings.getFieldValues)
      )
      _ = workerNotificationService.fireConnectionInitiatedEvent(
        ConnectionInitiated(connection.getID, connection.getName, adminUserKeyOpt)
      )
    } yield connection

    val local = nonPersistentConnection.isLocal
    editorFieldContextService.pushEditorContext(
      connectionModeOpt,
      local,
      connectionFuture,
      nodeInfoFuture
    )

    connectionFuture.map(connection => (generateResultMessage(connection), connection))
  }

  /** Gets {@link ConnectionMode} value from provided string
    * @param mode
    * @return
    */
  private def getConnectionMode(mode: Option[String]): Option[ConnectionMode] =
    mode.flatMap(m => ConnectionMode.values().find(_.name() == m))

  /** Accepts invitation: fire Connection Accepted Event, push Editor Context
    * @param connection
    *   \- Non Persistent Connection
    * @param iv
    *   \- invication value
    * @param adminUserKey
    * @return
    *   Tuple (message, updated connection )
    */
  override def accept(
      connection: INonPersistentConnection,
      iv: InvitationValue,
      adminUserKey: Option[String]
  ): Future[(String, IConnection)] = {
    connection.setInvitationSecret(iv.invitationSecret)
    connection.setInvitationStatus(InvitationStatus.SEND_ACCEPTED)
    val nonPersistentNodeInfo = NodeInfoValueHelper.toNonPersistentNodeInfo(iv.nodeInfo)
    connection.getRemoteInstance.setNodeInfo(nonPersistentNodeInfo)

    val connectionFuture = for {
      c <- create(connection)
      //      optionRequestContentValueSeq <- editorFieldContextService.prepareOptionRequestValueSeq(c, adminUserKey)
      _ = workerNotificationService.fireConnectionAcceptedEvent(
        ConnectionAccepted(c.getID, c.getName, adminUserKey)
      )
      updatedC <- acceptInvitation(c)
      _ <- trackerExtraLogicService.afterCreateConnection(
        updatedC,
        Option(connection.getTrackerSettings.getFieldValues)
      )
    } yield updatedC

    loggingService.info(
      "Connection (" + connection.getName + ") creation was scheduled and going to push editor context to the remote side"
    )
    editorFieldContextService.pushEditorContext(
      getConnectionMode(Option(connection.getMode)),
      connection.isLocal,
      connectionFuture,
      Future.successful(Some(nonPersistentNodeInfo))
    )

    connectionFuture.map { updatedC =>
      val resultMessage = generateResultMessage(updatedC)
      (resultMessage, updatedC)
    }
  }

  /** Generate result message when connection was initiated or when connection was accepted
    * @param connection
    * @return
    *   generated message
    */
  private def generateResultMessage(connection: IConnection): String = {
    val connectionName = connection.getName

    if (connection.isLocal) {
      s"""Congratulations! Your local connection <b>$connectionName</b> has been successfully created.
         | You are all set to start synchronizing issues within your issue tracker. """.stripMargin
    } else if (connection.getInvitationStatus == InvitationStatus.PENDING) {
      s"""Almost done! Connection <b>$connectionName</b> has been successfully created. As soon as it's active, you can sync!
         |To activate it, please make sure your partner (administrator of the Destination Instance) accepted the Invitation.""".stripMargin
    } else if (connection.getStatus == ConnectionStatus.DEACTIVATED) {
      s"""Congratulations! Connection <b>$connectionName</b> has been successfully created.
         | Activate the Connection to synchronize issues. """.stripMargin
    } else if (connection.getInvitationStatus == InvitationStatus.ACCEPTED) {
      s"""Congratulations! Connection <b>$connectionName</b> has been successfully created.
         |If your partner (administrator of the Destination Instance) configured a connection with the same name,
         | you are all set. Synchronize an issue!""".stripMargin
    } else {
      ""
    }
  }

  /** Create connection using preprocesed data from {@code nonPersistentConnection}
    * @param nonPersistentConnection
    * @return
    *   \- created connection
    */
  // TODO: remove trackerSettings.getFieldValues
  private def create(nonPersistentConnection: INonPersistentConnection): Future[IConnection] = {
    val trackerSettings = nonPersistentConnection.getTrackerSettings
    val nonPersistentTrackerSettings = new NonPersistentConnectionIssueTrackerSettings(
      trackerSettings.getIssueTrackerType,
      trackerSettings.getCreateLinks,
      trackerSettings.getCreateSyncPanelLinks,
      trackerSettings.getIssueFilter,
      trackerSettings.getHpqcProject,
      trackerSettings.getHpqcDomain,
      trackerSettings.getIssueLinkFieldName,
      new util.HashMap[String, String]()
    )

    if (nonPersistentConnection.isLocal) {
      nonPersistentConnection.setInvitationStatus(InvitationStatus.ACCEPTED)
    }

    for {
      _ <- validateConnectionService.validate(nonPersistentConnection)
      connectionWithStatus = setConnectionInvitationStatus(nonPersistentConnection)
      paymentModel <- licenseService.isInstanceForConnectionPayed(connectionWithStatus)
      connectionWithStatusAndPublishTracker = trackFirstPublishStarted(connectionWithStatus)
      connection <- connectionRepository.createConnection(
        connectionWithStatusAndPublishTracker,
        Some(nonPersistentTrackerSettings)
      )
      _ <- licenseService.updateLicenseUsages(connection.getRemoteInstance.getID, paymentModel)
    } yield connection
  }

  /** Sets `ConnectionWasPublished.FALSE` to {@code nonPersistentConnection} It is used before
    * creating connection
    * @param nonPersistentConnection
    * @return
    */
  private def trackFirstPublishStarted(
      nonPersistentConnection: INonPersistentConnection
  ): INonPersistentConnection =
    trackFirstPublish(nonPersistentConnection, ConnectionWasPublished.FALSE)

  /** Sets `ConnectionWasPublished.TRUE` to {@code nonPersistentConnection}
    * @param nonPersistentConnection
    * @return
    */
  private def trackFirstPublishFinished(
      nonPersistentConnection: INonPersistentConnection
  ): INonPersistentConnection =
    trackFirstPublish(nonPersistentConnection, ConnectionWasPublished.TRUE)

  /** Updates provided {@code nonPersistentConnection} with new ConnectionWasPublished status
    * @param nonPersistentConnection
    * @param wasPublished
    * @return
    *   updated INonPersistentConnection
    */
  private def trackFirstPublish(
      nonPersistentConnection: INonPersistentConnection,
      wasPublished: ConnectionWasPublished
  ): INonPersistentConnection = {
    val connectionFieldValues = nonPersistentConnection.getFieldValues
    val additionalConnectionFieldValues =
      if (isEditor(nonPersistentConnection))
        Map(FieldValues.WAS_PUBLISHED.toString -> wasPublished.toString)
      else Map.empty[String, String]
    val updatedConnectionFieldValues =
      connectionFieldValues.asScala.toMap ++ additionalConnectionFieldValues
    val updatedConnectionFieldValuesJMap = updatedConnectionFieldValues.asJava
    nonPersistentConnection.setFieldValues(updatedConnectionFieldValuesJMap)
    nonPersistentConnection
  }

  /** Check whether the connection support visual editor
    * @param nonPersistentConnection
    * @return
    */
  private def isEditor(nonPersistentConnection: INonPersistentConnection) =
    Option(nonPersistentConnection.getFieldValues)
      .flatMap(fieldValues => Option(fieldValues.get(FieldValues.MODE.toString)))
      .contains(ConnectionMode.CONFIGURE_BOTH_SIDES.toString)

  /** Updates connection data in DB
    * @param connectionId
    * @param nonPersConnection
    * @return
    */
  // TODO: remove trackerSettings.getFieldValues
  private[config] def update(
      connectionId: Int,
      nonPersConnection: INonPersistentConnection
  ): Future[IConnection] = {
    val trackerSettings = nonPersConnection.getTrackerSettings
    val nonPersistentTrackerSettings = new NonPersistentConnectionIssueTrackerSettings(
      trackerSettings.getIssueTrackerType,
      trackerSettings.getCreateLinks,
      trackerSettings.getCreateSyncPanelLinks,
      trackerSettings.getIssueFilter,
      trackerSettings.getHpqcProject,
      trackerSettings.getHpqcDomain,
      trackerSettings.getIssueLinkFieldName,
      trackerSettings.getFieldValues
    )
    val updatedFieldValues = nonPersConnection.getFieldValues
    for {
      existingConnectionOpt <- connectionRepository.getConnectionFuture(connectionId)
      _ <- validateConnectionService.validate(nonPersConnection)
      connectionWithNodeInfo <- setNodeInfo(nonPersConnection, existingConnectionOpt)
      _ <- connectionRepository.updateFieldValues(connectionId, updatedFieldValues)
      connection <- connectionRepository.updateConnection(
        connectionId,
        connectionWithNodeInfo,
        Some(nonPersistentTrackerSettings)
      )
    } yield connection
  }

  /** Method is call for updating connection (pressing button publish on UI). It updates connection
    * info and fire Connection Updated Event with generated connection draft Request Value
    * @param connectionId
    *   \- id of the connection the is going to be updated
    * @param nonPersConnection
    * @param scopes
    *   \- already processed scopes
    * @param mappings
    *   \- already procesed mappings
    * @param accessToken
    * @return
    *   the updated connection
    */
  override def update(
      connectionId: Int,
      nonPersConnection: INonPersistentConnection,
      scopes: Seq[ScopeValue],
      mappings: Seq[MappingValue],
      accessToken: Option[String]
  ): Future[IConnection] =
    for {
      existingConnection <- connectionRepository.getConnectionFuture(connectionId)
      connectionDraftOpt <-
        if (
          nonPersConnection.isLocal || existingConnection
            .flatMap(c => Option(c.getFieldValues.get("mode")))
            .isEmpty
        ) Future.successful(None)
        else
          connectionDraftRepository
            .createOutgoingDraft(connectionId, ConnectionDraftOperation.UPDATE)
            .map(Some(_))
      npConnectionWithPublishTracked =
        if (nonPersConnection.isLocal) trackFirstPublishFinished(nonPersConnection)
        else nonPersConnection
      _ <-
        if (npConnectionWithPublishTracked.isLocal)
          connectionRepository.updateFieldValues(connectionId, nonPersConnection.getFieldValues)
        else
          Future.successful(None)
      connection <- update(connectionId, npConnectionWithPublishTracked)
      _ <- trackerExtraLogicService.afterUpdateConnection(connection)
      _ <- {
        if (connection.isVisual) {
          trackerExtraLogicService
            .afterPublish(connection, scopes, mappings)
            .recover {
              case e =>
                loggingService.error(
                  "com.exalate.replication.services.config.ConnectionService",
                  () =>
                    s"Failed to process issue-tracker-specific logic after publish for connection `${connection.getName}`",
                  () => e
                )
                None
            }
        } else Future.successful(None)
      }
      draftRequestValueOpt <- prepareConnectionDraftValueRequestJsonStr(
        connection,
        connectionDraftOpt,
        scopes,
        mappings,
        accessToken
      )
      _ = workerNotificationService.fireConnectionUpdatedEvent(
        ConnectionUpdated(connectionId, connection.getName, draftRequestValueOpt)
      )
    } yield connection

  /** Prepare connection draft request value in order to send it on the remote side
    * @param connection
    * @param connectionDraftOpt
    *   \- connection draft optionally
    * @param scopes
    *   \- seq of scope values
    * @param mappings
    *   \- seq of mapping value
    * @param accessToken
    * @return
    */
  override def prepareConnectionDraftValueRequestJsonStr(
      connection: IConnection,
      connectionDraftOpt: Option[ConnectionDraft],
      scopes: Seq[ScopeValue],
      mappings: Seq[MappingValue],
      accessToken: Option[String]
  ): Future[Option[ConnectionDraftRequestValue]] =
    connectionDraftOpt match {
      case None                  => Future.successful(None)
      case Some(connectionDraft) =>
        Option(connection.getRemoteInstance.getNodeInfo)
          .flatMap(ni => Option(ni.getExaCompVersion)) match {
          case None                 => Future.successful(None)
          case Some(exaCompVersion) =>
            if (SemanticVersionService.get(exaCompVersion).getMajor >= 5L) {
              val mps = mappings.map(removeMappingId)
              Future.successful(
                connectionValueHelper.toConnectionDraftValueRequest(
                  connectionDraft,
                  scopes,
                  mps,
                  accessToken
                )
              )
            } else Future.successful(None)
        }
    }

  /** Process received message by extracting connection draft from it and update connection with
    * this value.
    *
    * This method is called from
    * {@link com.exalate.replication.services.message.ExalateMessageService} when received message
    * has status {@link com.exalate.domain.transport.message.MessageType.CONNECTION_DRAFT_REQUEST}
    * @param exaMsg
    * @return
    */
  override def updateFromConnectionDraftRequestMessageAndPrepareResponse(
      exaMsg: ExalateMessage
  ): Future[ConnectionDraftResponseValue] = {
    val connectionID = exaMsg.connectionId
    val connectionDraftJsonStr = exaMsg.content
    val connectionDraftValueTry =
      Json.parse(connectionDraftJsonStr).validate[ConnectionDraftRequestValue] match {
        case JsSuccess(value, _) => Success(value)
        case JsError(errors)     => Failure(new Exception(errors.mkString(", ")))
      }
    Future
      .fromTry(connectionDraftValueTry)
      .recoverWith {
        case e =>
          val exception =
            bugExceptionCategoryService.generateJsonIntoValueConvertingFailedBugException(
              connectionDraftJsonStr,
              "ConnectionDraftValueRequest",
              Option(e.getMessage)
            )
          loggingService.error(
            s"Failed to convert JSON `$connectionDraftJsonStr` into ConnectionDraftValueRequest",
            exception
          )
          Future.failed(exception)
      }
      .flatMap { cdvr =>
        connectionRepository.getConnectionFuture(connectionID).flatMap {
          case None    =>
            val exc = bugExceptionCategoryService
              .generateBugException(None, Some(s"Couldn't find a connection with id `$connectionID`"))
            loggingService.error(
              s"Received a message to update connection with id `$connectionID`. But couldn't find such connection."
            )
            Future.failed(exc)
          case Some(c) =>
            val npConn = connectionValueHelper.toNonPersistentConnection(c)
            // Currently a connection is updated without any changes
            updateWithConnectionDraftResponse(connectionID, c, npConn, cdvr)
        }
      }
  }

  /** Updates connection data in DB based on the input connection draft request, namely it updates
    * scopes, mappings and related to connection info
    *
    * @param connectionId
    * @param connection
    * @param nonPersConnection
    * @param cdvRequest
    *   \- connection draft request
    * @return
    *   ConnectionDraftResponseValue which has status SENDING, PUBLISHED, REJECTED and draft id
    */
  private def updateWithConnectionDraftResponse(
      connectionId: Int,
      connection: IConnection,
      nonPersConnection: INonPersistentConnection,
      cdvRequest: ConnectionDraftRequestValue
  ): Future[ConnectionDraftResponseValue] =
    cdvRequest.accessToken match {
      case None =>
        loggingService.error(
          s"Received a message to update connection with id `$connectionId`. But admin proof token is not present in the message. ConnectionDraftRequestValue: $cdvRequest"
        )
        val draftResponseValue =
          ConnectionDraftResponseValue(cdvRequest.draftId, ConnectionDraftStatus.REJECTED.toString)
        Future.successful(draftResponseValue)

      case Some(token) =>
        oauthService
          .validateToken(token)
          .map(_ => true)
          .recover { case _ => false }
          .flatMap { valid =>
            val mappings = swapMappingsDirection(cdvRequest.mappings)
            val scopes = swapScopesDirection(cdvRequest.scopes)
            val (draftStatus, future) = if (!valid) {
              loggingService.error(
                s"Connection Draft Request (with id ${cdvRequest.draftId}) accesstoken for connection ${nonPersConnection.getName} is invalid. Status: REJECTED"
              )
              (ConnectionDraftStatus.REJECTED, Future.successful(None))
            } else {
              val fut = updateScopes(connectionId, cdvRequest)
                .recover { case _ => None }
                .flatMap { _ =>
                  mappingsRepository
                    .upsert(mappings, connectionId)
                    .recover { case _ => None }
                }

              loggingService.debug(
                s"Connection Draft (with id ${cdvRequest.draftId}) Status for connection ${nonPersConnection.getName}: PUBLISHED"
              )
              (ConnectionDraftStatus.PUBLISHED, fut)
            }
            Try(new Timestamp(cdvRequest.createdOn)) match {
              case Failure(e)         =>
                val errMsg = "Couldn't read connection draft creation date from json."
                loggingService.error(errMsg, e)
                val exception = bugExceptionCategoryService.generateBugException(None, Some(errMsg))
                Future.failed(exception)
              case Success(createdOn) =>
                val npConnWithPublishTracked = trackFirstPublishFinished(nonPersConnection)
                for {
                  _ <- future
                  _ <- update(connectionId, npConnWithPublishTracked)
                  _ <- {
                    if (draftStatus == ConnectionDraftStatus.PUBLISHED) {
                      trackerExtraLogicService.afterPublish(connection, scopes, mappings)
                    } else {
                      Future.successful(None)
                    }
                  }
                  _ = workerNotificationService.fireAllWorkerNotifications()
                  draftResponseValue = ConnectionDraftResponseValue(
                    cdvRequest.draftId,
                    draftStatus.toString
                  )
                } yield draftResponseValue

            }
          }
    }

  /** Swaps mappings direction. It is used on the side, where the mapping rules are being received,
    * and remote side should be local
    * @param mappings
    *   \- seq og mapping vaues
    * @return
    */
  private def swapMappingsDirection(mappings: Seq[MappingValue]): Seq[MappingValue] =
    mappings
      .map(removeMappingId)
      .map(swapMappingDirection)

  /** Swaps scopes direction. It is used on the side, where the scope rules are being received, and
    * remote side should be local
    * @param scopes
    * @return
    */
  private def swapScopesDirection(scopes: Seq[ScopeValue]): Seq[ScopeValue] =
    scopes.map(scope => scope.copy(local = scope.remote, remote = scope.local))

  /** Sets mapping id to None
    * @param mappingValue
    * @return
    *   updated MappingValue
    */
  private def removeMappingId(mappingValue: MappingValue): MappingValue =
    mappingValue.copy(id = None)

  /** Swaps mapping direction
    * @param mappingValue
    * @return
    */
  private def swapMappingDirection(mappingValue: MappingValue): MappingValue =
    mappingValue.copy(
      local = mappingValue.remote,
      remote = mappingValue.local,
      arrow = mappingValue.arrow.map(swapArrow),
      maps = swapMapDirections(mappingValue.maps)
    )

  /** Swaps mapping maps direction
    * @param mapsOpt
    * @return
    */
  private def swapMapDirections(mapsOpt: Option[Seq[MapValue]]): Option[Seq[MapValue]] =
    mapsOpt.map(
      _.map(m =>
        m.copy(
          local = m.remote,
          arrow = swapArrow(m.arrow),
          remote = m.local
        )
      )
    )

  /** Swaps arrow of the mapping rules
    * @param arrow
    * @return
    */
  private def swapArrow(arrow: String): String =
    arrow match {
      case l if l == L.toString => R.toString
      case r if r == R.toString => L.toString
      case _                    => arrow
    }

  /** Updates scopes with value from provided ConnectionDraftRequestValue
    * @param connectionId
    * @param cdvRequest
    *   \- ConnectionDraftRequestValue
    * @return
    *   None
    */
  private def updateScopes(
      connectionId: Int,
      cdvRequest: ConnectionDraftRequestValue
  ): Future[None.type] =
    cdvRequest.scopes.foldLeft(Future.successful(None)) {
      case (resultFuture, ScopeValue(local: SingleSideScopeValue, remote: SingleSideScopeValue)) =>
        val scopeUUID: UUID = (local.scopeUid, remote.scopeUid) match {
          case (Some(lUid), Some(rUid)) if lUid == rUid =>
            UUID.fromString(lUid)
          case (Some(lUid), Some(rUid)) if lUid != rUid =>
            loggingService.error(
              s"#updateWithConnectionDraftResponse received scope with different scope UIDs for local `$lUid` and for remote `$rUid` scope parts, using local: `$lUid`"
            )
            UUID.fromString(lUid)
          case (Some(lUid), None)                       =>
            loggingService.error(
              s"#updateWithConnectionDraftResponse received scope with no scope UID for remote scope part, using local: `$lUid`"
            )
            UUID.fromString(lUid)
          case (None, Some(rUid))                       =>
            loggingService.error(
              s"#updateWithConnectionDraftResponse received scope with no scope UID for local scope part, using remote: `$rUid`"
            )
            UUID.fromString(rUid)
          case (None, None)                             =>
            val uuid = UUID.randomUUID()
            loggingService.error(
              s"#updateWithConnectionDraftResponse received scope with no scope UIDs generating a new one: `$uuid`"
            )
            uuid
        }
        loggingService.debug(
          s"#updateWithConnectionDraftResponse #updateScopes received a cdvRequest: `${cdvRequest.toString}`"
        )
        val localScope = remote.toSingleSideScope(connectionId, local = true, scopeUUID)
        val remoteScope = local.toSingleSideScope(connectionId, local = false, scopeUUID)
        resultFuture
          .flatMap(_ => scopesRepository.upsertScopes(Seq(Scope(localScope, remoteScope))))
      case (resultFuture, _)                                                                     =>
        resultFuture
    }

  /** Updates connection draft value in Db with new provided value and updates fields value under
    * connection by setting ConnectionWasPublished.TRUE
    * @param exaMsg
    *   \- obtained exalate message
    * @return
    */
  override def updateConnectionDraftFromResponseMessage(exaMsg: ExalateMessage): Future[None.type] = {
    val connectionDraftResponseJsonStr = exaMsg.content
    val connectionDraftValueTry =
      Json.parse(connectionDraftResponseJsonStr).validate[ConnectionDraftResponseValue] match {
        case JsSuccess(value, _) => Success(value)
        case JsError(errors)     => Failure(new Exception(errors.mkString(", ")))
      }
    Future
      .fromTry(connectionDraftValueTry)
      .recoverWith {
        case e =>
          val exception =
            bugExceptionCategoryService.generateJsonIntoValueConvertingFailedBugException(
              connectionDraftResponseJsonStr,
              "ConnectionDraftValueResponse",
              Option(e.getMessage)
            )
          loggingService.error(
            s"Failed to convert JSON `$connectionDraftResponseJsonStr` into ConnectionDraftValueResponse",
            exception
          )
          Future.failed(exception)
      }
      .flatMap { connectionDraftResponseValue =>
        val draftId = connectionDraftResponseValue.draftId
        val draftStatus = ConnectionDraftStatus.valueOf(connectionDraftResponseValue.status)
        for {
          connectionDraft <- connectionDraftRepository.updateDraftProcessed(draftId, draftStatus)
          connectionId = connectionDraft.connectionId
          maybeConnection <- connectionRepository.getConnectionFuture(connectionId)
          _ <- maybeConnection match {
            case None             => Future.successful(None)
            case Some(connection) =>
              val npConn = connectionValueHelper.toNonPersistentConnection(connection)
              val updatedConn = trackFirstPublishFinished(npConn)
              val updatedFieldValues = updatedConn.getFieldValues
              loggingService.debug(
                s"#updateConnectionDraftFromResponseMessage tracking the fact that a draft was published ${updatedFieldValues
                    .get(FieldValues.WAS_PUBLISHED.toString)}"
              )
              connectionRepository.updateFieldValues(connectionId, updatedFieldValues)
          }
          _ = workerNotificationService.fireAllWorkerNotifications()
        } yield None
      }
      .map(_ => None)
  }

  private def setNodeInfo(
      connection: INonPersistentConnection,
      existingConnection: Option[IConnection]
  ): Future[INonPersistentConnection] = {
    existingConnection
      .map(_.getRemoteInstance)
      .flatMap(i => Option(i.getNodeInfo))
      .map(ni => NodeInfoValueHelper.toNonPersistentNodeInfo(NodeInfoValueHelper.toNodeInfoValue(ni)))
      .foreach(connection.getRemoteInstance.setNodeInfo)

    if (connection.isLocal) {
      return nodeInfoProvider.get
        .map(NodeInfoValueHelper.toNonPersistentNodeInfo)
        .map { ni =>
          connection.getRemoteInstance.setNodeInfo(ni)
          connection
        }
    }

    if (connection.getSendProtocol == SendProtocol.DIRECT_HTTP) {
      urlInferringService
        .setNodeInfoAndUrls(connection.getRemoteInstance)
        .map { i =>
          connection.setRemoteInstance(i)
          connection
        }
        .recover {
          case e: Exception => connection
        }
    } else {
      Future.successful(connection)
    }
  }

  /** Decided wheter the connection invitation status should be set as ACCEPTED or PENDING depending
    * if remote support invitations.
    *
    * @param nonPersistentConnection
    *   that is created/updated
    * @return
    */
  private def setConnectionInvitationStatus(
      nonPersistentConnection: INonPersistentConnection
  ): INonPersistentConnection =
    Option(nonPersistentConnection.getRemoteInstance.getNodeInfo)
      .filter(ni => Option(ni.getExaCompVersion).isEmpty) // Remote does not support invitations
      .map { _ =>
        nonPersistentConnection.setInvitationStatus(InvitationStatus.ACCEPTED)
        nonPersistentConnection
      }
      .getOrElse(nonPersistentConnection)

  /** Sets Invitation Secret to the provided non Persistent Connection
    * @param nonPersistentConnection
    * @return
    *   updated non Persistent Connection
    */
  private def setConnectionInvitationSecret(
      nonPersistentConnection: INonPersistentConnection
  ): INonPersistentConnection = {
    def hasNoExaCompVersion(nodeInfoOpt: Option[INonPersistentNodeInfo]): Boolean =
      nodeInfoOpt.isDefined &&
        nodeInfoOpt
          .flatMap(ni => Option(ni.getExaCompVersion))
          .isEmpty
    Option(nonPersistentConnection.getRemoteInstance.getNodeInfo) match {
      case nodeInfoOpt if hasNoExaCompVersion(nodeInfoOpt) =>
        nonPersistentConnection
      case _                                               =>
        nonPersistentConnection.setInvitationSecret(generateInvitationSecret)
        nonPersistentConnection
    }
  }

  private def generateInvitationSecret =
    Random.alphanumeric
      .take(SECRET_LENGTH)
      .mkString

  /** infer Local Receive Protocol based on {@code invitedSendProtocol}
    * @param invitedSendProtocol
    * @return
    *   ReceiveProtocol: DIRECT_HTTP or POLL
    */
  private def inferLocalReceiveProtocol(invitedSendProtocol: String): ReceiveProtocol =
    SendProtocol.valueOf(invitedSendProtocol) match {
      case SendProtocol.DIRECT_HTTP   => ReceiveProtocol.DIRECT_HTTP
      case SendProtocol.WAIT_FOR_POLL => ReceiveProtocol.POLL
    }

  /** Apply Accepted Invitation Message, then in case mode of the connection was changed - push
    * Editor Context, then update License Usage, fire All Worker Notifications and fire Message
    * Batching
    * @param connectionName
    * @param acceptInvitationValue
    * @return
    *   None
    */
  override def applyAcceptedInvitationMessage(
      connectionName: String,
      acceptInvitationValue: AcceptInvitationValue
  ): Future[None.type] = acceptInvitationValue match {
    case AcceptInvitationValue(invitationSecret, invitedSendProtocol, nodeInfoValue, mode) =>
      get(connectionName).flatMap {
        case Some(connection) if connection.getInvitationStatus != InvitationStatus.ACCEPTED =>
          val remoteNodeInfo = NodeInfoValueHelper.toNonPersistentNodeInfo(nodeInfoValue)
          val localReceiveProtocol = inferLocalReceiveProtocol(invitedSendProtocol)
          val modeBeforeAccept = connection.getMode

          val fieldValuesOpt =
            if (
              connection.isBasic && !mode.contains(
                ConnectionMode.CONFIGURE_BOTH_SIDES.toString
              ) && nodeInfoValue.basicConnection.isEmpty
            ) {
              val fieldValues = new util.HashMap[String, String](connection.getFieldValues)
              fieldValues.remove(FieldValues.MODE.toString)
              connection.setFieldValues(fieldValues)
              Some(fieldValues)
            } else {
              mode
                .map { m =>
                  val fieldValues = new util.HashMap[String, String](connection.getFieldValues)
                  fieldValues.put(FieldValues.MODE.toString, m)
                  fieldValues
                }
            }

          val fieldValuesOptJson = fieldValuesOpt.map(fv => Json.stringify(Json.toJson(fv.asScala)))
          val connectionFuture = connectionRepository.applyAcceptedInvitationMessage(
            connection.getID,
            invitationSecret,
            localReceiveProtocol,
            remoteNodeInfo,
            fieldValuesOptJson
          )
          loggingService.trace(
            "Connection was accepted. Going to push editor context (" + mode.exists(
              _ != modeBeforeAccept
            ) + ")"
          )
          if (mode.exists(_ != modeBeforeAccept)) {
            editorFieldContextService.pushEditorContext(
              getConnectionMode(Option(connection.getMode)),
              connection.isLocal,
              connectionFuture,
              Future.successful(Some(remoteNodeInfo))
            )
          }

          for {
            updatedConnection <- connectionFuture
            payed <- licenseService.isInstanceForConnectionPayed(connection)
            _ <- licenseService.updateLicenseUsages(updatedConnection.getRemoteInstance.getID, payed)
            _ = pollSchedulerService.handlePollScheduleOnUpdate(updatedConnection)
            _ = workerNotificationService.fireAllWorkerNotifications()
            _ = workerNotificationService.fireStartMessageBatching()
          } yield None

        case None =>
          val exception =
            bugExceptionCategoryService.generateNoConnectionBugException(connectionName)
          loggingService.error(s"Connection with name `$connectionName` was not found.", exception)
          Future.failed(exception)

        case _ => Future.successful(None)
      }
  }

  /** Gets connection from repo by name and update invitation status
    * @param connectionName
    *   name of the connection
    * @param invitationStatus
    *   new invitation status
    * @return
    *   Updated connection
    */
  override def updateInvitationStatus(
      connectionName: String,
      invitationStatus: InvitationStatus
  ): Future[IConnection] =
    for {
      cOpt <- get(connectionName)
      result <- cOpt match {
        case Some(connection) =>
          for {
            updatedConnection <- connectionRepository
              .updateInvitationStatus(connection.getID, invitationStatus)
            _ = pollSchedulerService.handlePollScheduleOnUpdate(updatedConnection)
            _ = workerNotificationService.fireAllWorkerNotifications()
          } yield updatedConnection
        case None             =>
          val exception =
            bugExceptionCategoryService.generateNoConnectionBugException(connectionName)
          loggingService.error(s"Connection with name `$connectionName` was not found.", exception)
          Future.failed(exception)
      }
    } yield result

  /** If connection invitation status is `SEND_ACCEPTED`, generates AcceptInvitationValue
    * @param connection
    * @return
    *   AcceptInvitationValue
    */
  override def getInvitationAcceptedMessage(
      connection: IConnection
  ): Future[Option[AcceptInvitationValue]] =
    if (connection.getInvitationStatus == InvitationStatus.SEND_ACCEPTED) {
      nodeInfoProvider.get
        .map(nodeInfo =>
          AcceptInvitationValue(
            connection.getInvitationSecret,
            connection.getSendProtocol.name(),
            nodeInfo,
            Option(connection.getMode)
          )
        )
        .map(Some.apply)
    } else {
      Future.successful(None)
    }

  /** Process of accepting invitation, if Send Protocol of the {@code connection} is DIRECT_HTTP
    * then notify remote side that Connection is Accepted and update invitation status
    * @param connection
    * @return
    *   updated connection
    */
  override def acceptInvitation(connection: IConnection): Future[IConnection] =
    if (connection.getSendProtocol == SendProtocol.DIRECT_HTTP) {
      connectionClient
        .notifyConnectionAccepted(connection, getInvitationAcceptedMessage(connection))
        .flatMap { succeed =>
          if (succeed) updateInvitationStatus(connection.getName, InvitationStatus.ACCEPTED)
          else Future.successful(connection)
        }
    } else {
      Future.successful(connection)
    }

  /** Script validation
    * @param script
    *   \- script
    * @param field
    *   \- name of the field: DataFilter, ChangeProcesor etc.
    * @return
    */
  override def validateScripts(script: String, field: String): Try[None.type] =
    validateConnectionService.validateCode(script, field)

  /** Generates invitation message. It is called on the front end request: PUT
    * /rest/issuehub/4.0/connections/:id/generate
    * @param connection
    * @return
    *   invitation message
    */
  override def getInvitationMessageForInviting(
      connection: IConnection
  ): Future[InvitationGenerateResultValue] =
    connectionValueHelper.toConnectionValue(connection).flatMap { connectionValue =>
      val communication = connectionValue.communication

      (Option(connection.getRemoteInstance.getUrl) match {
        case None    => Future.successful(None)
        case Some(_) =>
          nodeInfoClient.getNodeInfo(connection.getRemoteInstance).map(Some.apply).recover {
            case e: Exception => None
          }
      })
        .flatMap(remoteNodeInfoOpt =>
          generalSettingsService.get.map(localSettings => (remoteNodeInfoOpt, localSettings.get))
        )
        .flatMap {
          case (nodeInfoValueOpt, generalSettings) =>
            val localIssueTrackerUrl = generalSettings.getIssueTrackerUrl
            generateInvitationCode(
              connectionValue,
              nodeInfoValueOpt.flatMap(_.instanceUid),
              connection.getInvitationSecret
            ).map { invitationCode =>
              nodeInfoValueOpt match {
                case Some(nodeInfoValue) =>
                  val invitationText = if (nodeInfoValue.exaCompVersion.isDefined) {
                    s"""Hello,<br/>
                       |A partner from Instance <a href=$localIssueTrackerUrl rel="noopener noreferrer" target="_blank">$localIssueTrackerUrl</a> would like to sync with your
                       |Instance ${communication.remoteUrl
                        .map(url =>
                          s"<a href=$url rel='noopener noreferrer' target='_blank'>$url</a>"
                        )
                        .getOrElse("")} via Exalate.<br/>
                       |To review the invitation details:<br/>
                       |<ol>
                       |<li>
                       |<div class='invitation-code'>Navigate to Connections, click <b>Accept invitation</b> and apply
                       |<a href="https://docs.exalate.com/docs/how-to-apply-an-invitation-code" target="_blank">invitation code</a>:
                       |<br/>
                       |// ---------- Begin Invitation code ----------<br/>
                       |<code>$invitationCode</code><br/>
                       |// ---------- End Invitation code ------------<br/>
                       |</div>
                       |</li>
                       |<li>Follow the wizard steps accepting the invitation (if you agree with the details).</li>
                       |<li>Now you’re ready to <a href="https://docs.exalate.com/docs/synchronization-operations" target="_blank">synchronize issues</a>!</li>
                       |</ol><br/>
                       |Feedback, questions, bumps? Send a mail to <a href="mailto:support@exalate.com">
                       |support@exalate.com</a>""".stripMargin
                  } else {
                    s"""Hello,<br/>
                       |A partner from Instance <a href=$localIssueTrackerUrl target="_blank">$localIssueTrackerUrl</a> would like to sync with your
                       |Instance ${communication.remoteUrl
                        .map(url => s"<a href=$url target='_blank'>$url</a>")
                        .getOrElse("")} via Exalate.<br/>
                       |To review the invitation details:<br/>
                       |<ol>
                       |<li>Navigate to Instances, create and configure an Instance to point to $localIssueTrackerUrl.
                       |<a href="https://docs.idalko.com/exalate/x/xIIrAQ" target="_blank">More details</a>
                       |</li>
                       |<li>Navigate to Relations and configure a relation with name '${connectionValue.name}' (no quotes).
                       |<a href="https://docs.idalko.com/exalate/x/xoIrAQ" target="_blank">More details</a>
                       |</li>
                       | <li>Now you’re ready to <a href="https://docs.idalko.com/exalate/x/wIIrAQ" target="_blank">synchronize issues</a>!</li>
                       |</ol><br/>
                       |Feedback, questions, bumps? Send a mail to <a href="mailto:support@exalate.com">
                       |support@exalate.com</a>""".stripMargin
                  }

                  InvitationGenerateResultValue(invitationText, invitationCode)

                case None =>
                  val invitationText =
                    s"""Hello,<br/>
                       |A partner from Instance <a href=$localIssueTrackerUrl target="_blank">$localIssueTrackerUrl</a> would like to sync with your
                       |Instance ${communication.remoteUrl
                        .map(url => s"<a href=$url target='_blank'>$url</a>")
                        .getOrElse("")} via Exalate.<br/>
                       |To review the invitation details:<br/>
                       |<ol>
                       |<li><a href="https://docs.idalko.com/exalate/x/woIrAQ" target="_blank">Install Exalate</a></li>
                       |<li>
                       |<div class='invitation-code'>Follow <a href="https://docs.idalko.com/exalate/x/vYIrAQ" target="_blank">the instructions</a> to apply the invitation code:
                       |<br/>
                       |// ---------- Begin Invitation code ----------<br/>
                       |<code>$invitationCode</code><br/>
                       |// ---------- End Invitation code ------------<br/>
                       |</div>
                       |</li>
                       |<li>Now you’re ready to <a href="https://docs.idalko.com/exalate/x/wIIrAQ" target="_blank">synchronize issues</a>!</li>
                       |</ol><br/>
                       |Feedback, questions, bumps? Send a mail to <a href="mailto:support@exalate.com">
                       |support@exalate.com</a>""".stripMargin
                  InvitationGenerateResultValue(invitationText, invitationCode)
              }
            }
        }
    }

  override def getInvitationForBasicConnection(
      connection: IConnection
  ): Future[InvitationGenerateResultValue] = {
    val invitationCodeF = for {
      connectionValue <- connectionValueHelper.toConnectionValue(connection)
      remoteNodeInfoOpt <- Option(connection.getRemoteInstance.getUrl) match {
        case None    => Future.successful(None)
        case Some(_) =>
          nodeInfoClient.getNodeInfo(connection.getRemoteInstance).map(Some.apply).recover {
            case e: Exception => None
          }
      }
      (nodeInfoValueOpt, _) <- generalSettingsService.get.map(localSettings =>
        (remoteNodeInfoOpt, localSettings.get)
      )
      code <- generateInvitationCodeForBasicConnection(
        connectionValue,
        nodeInfoValueOpt.flatMap(_.instanceUid),
        connection.getInvitationSecret
      )
    } yield code

    invitationCodeF.map(invitationCode =>
      InvitationGenerateResultValue("Invitation code for basic connection", invitationCode)
    )
  }

  /** Generates invitation value for accepting connection
    * @param connection
    *   \- connection
    * @return
    *   invitation value
    */
  override def getInvitationForAccepting(connection: IConnection): Future[InvitationValue] =
    nodeInfoProvider.get.flatMap { localNodeInfo =>
      connectionValueHelper.toConnectionValue(connection).flatMap { connectionValue =>
        val updatedCommValue = connectionValue.communication.copy(
          localUrl = connectionValue.communication.remoteUrl,
          remoteUrl = localNodeInfo.baseUrl
        )
        val updatedConnectionValue = connectionValue.copy(communication = updatedCommValue)
        val remoteInstanceUidOpt = Option(connection.getRemoteInstance)
          .flatMap(i => Option(i.getNodeInfo))
          .map(_.getInstanceUid)
        generateInvitationCodeValue(
          updatedConnectionValue,
          remoteInstanceUidOpt,
          connection.getInvitationSecret
        )
      }
    }

  /** Resends Invitation Accepted Message. Called from
    * {@link com.exalate.replication.services.replication.worker.ConnectionEventWorkerActor._waitingForAfterTheLastMessage}
    * @return
    *   None
    */
  override def resendInvitationAcceptedMessage(): Future[None.type] =
    connectionRepository
      .findConnectionsWithStatus(InvitationStatus.SEND_ACCEPTED)
      .map(_.map(acceptInvitation))
      .map(_ => None)

  /** Polling for accepted message Used for Private to public connections
    * @return
    *   None
    */
  override def pollForAcceptedMessage(): Future[None.type] = {
    val pendingConnectionsFut =
      connectionRepository.findConnectionsWithStatus(InvitationStatus.PENDING)

    pendingConnectionsFut
      .flatMap { connections =>
        Future.sequence(
          connections
            .filterNot(_.getSendProtocol == SendProtocol.WAIT_FOR_POLL)
            .map { c =>
              val nonPersistentInstance =
                InstanceConverter.toNonPersistentInstance(c.getRemoteInstance)
              val eventualInstance = setNodeInfoAndStatusOnInstance(nonPersistentInstance)

              eventualInstance.flatMap {
                // if instances' status is INITIAL it means the node info was not retrieved.
                // we must not try to get accepted messsage in that case because of exalate url, it can be pointed to issue tracker url instead of exalate url.
                // exalate url will be set later on from node info, to be sure it's a right one and it points to exalate
                case i if i.getStatus == InstanceStatus.INITIAL =>
                  Future.failed(
                    new GettingNodeInfoFailedException(
                      s"Couldn't retrieve node info for connection ${c.getName}"
                    )
                  )
                case i                                          =>
                  c.getRemoteInstance.setUrl(i.getUrl)
                  connectionClient.getAcceptedMessage(c).map(_.map((c.getName, _)))
              }

            }
        )
      }
      .map(_.flatten.map {
        case (connectionName, aiv @ AcceptInvitationValue(secret, sendProtocol, ni, modeOpt)) =>
          applyAcceptedInvitationMessage(connectionName, aiv)
      })
      .flatMap(Future.sequence(_))
      .map(_ => None)
      .recover {
        case e: GettingNodeInfoFailedException => None
      }
  }

  /** Review Invitation Status (is not used)
    * @return
    *   None
    */
  override def reviewInvitationStatus(): Future[None.type] = {
    val pendingConnectionsFut = connectionRepository
      .findConnectionsWithStatus(InvitationStatus.PENDING)
      .map(_.filter(_.getSendProtocol == SendProtocol.DIRECT_HTTP))

    val pendingConnectionsWithNodeInfo: Future[Seq[(IConnection, Option[NodeInfoValue])]] =
      pendingConnectionsFut.flatMap { pendingConnections =>
        Future.sequence(
          pendingConnections
            .map { c =>
              nodeInfoClient
                .getNodeInfo(c.getRemoteInstance)
                .map(Some.apply)
                .recover {
                  case e: Exception => None
                }
                .map(nodeInfoOpt => (c, nodeInfoOpt))
            }
        )
      }

    pendingConnectionsWithNodeInfo
      .flatMap(conSeq =>
        Future.sequence(
          conSeq
            .filter {
              case (_, Some(nodeInfoValue)) if nodeInfoValue.exaCompVersion.isEmpty =>
                true // Remote does not support invitations
              case _                                                                => false
            }
            .map {
              case (c, _) => updateInvitationStatus(c.getName, InvitationStatus.ACCEPTED)
            }
        )
      )
      .map(_ => None)

  }

  /** Calls {@link IExternalBasicConnectionClient.upgradeRemoteSide()} in order to upgrade remote
    * side. the response of the remote side has:
    *   1. node info, we save it our DB (since BASIC connection was created by invitation that has
    *      not full node info, there is no info about editor) 2. syncMainFieldInfo: info about
    *      remote project that was chosen during connection establishing and which looks like
    *      {"local":[{"key":"PROJECT","value":{"value":"10000","label":"Test 1(T1)"}}]} we need it
    *      in order to for visual rules.
    * @param connection
    * @param connectionMode
    * @return
    */
  private def upgradeRemoteSide(
      connection: IConnection,
      connectionMode: String
  ): Future[(IConnection, Option[NodeInfoValue])] =
    if (SendProtocol.WAIT_FOR_POLL.equals(connection.getSendProtocol)) {
      val errMsg = "Couldn't read upgrade remote connection. It is private"
      loggingService.error(errMsg)
      val exception = bugExceptionCategoryService.generateBugException(None, Some(errMsg))
      Future.failed(exception)
    } else if (!connection.isLocal) {

      val accessTokenOpt = Option(connection.getRemoteInstance)
        .flatMap(i => Option(i.getNodeInfo))
        .flatMap(ni => Option(ni.getInstanceUid))
        .flatMap(instanceUid =>
          FutureUtils.resultInf(oauthService.findFirstOAuthDataWithAccessToken(instanceUid))
        )
        .map(_.getAccessToken)

      val nodeInfoValue = FutureUtils.resultInf(nodeInfoProvider.get)
      externalBasicConnectionClient
        .upgradeRemoteSide(connection, connectionMode, accessTokenOpt, nodeInfoValue)
        .flatMap {
          case Some(response) =>
            loggingService.info(s"#upgradeConnection: Obtained info from remote side: $response")

            updateNodeInfo(connection, response.nodeInfo)

            // {"local":[{"key":"PROJECT","value":{"value":"10000","label":"Test 1(T1)"}}]}
            val remoteMainFieldInfoStrOpt = response.syncMainFieldInfo
              .flatMap { remoteMainFieldInfoStr =>
                Json.parse(remoteMainFieldInfoStr).validate[MainFieldInfoValue].asOpt
              }
              .flatMap(_.local)
            val localMainFieldInfoStrOpt = Option(connection.getSyncMainFieldInfo)
              .flatMap { localMainFieldInfoStr =>
                Json.parse(localMainFieldInfoStr).validate[MainFieldInfoValue].asOpt
              }
              .flatMap(_.local)

            (localMainFieldInfoStrOpt, remoteMainFieldInfoStrOpt) match {
              case (None, None) =>
                connection.setSyncMainFieldInfo(null)
              case (_, _)       =>
                val mainFieldInfo =
                  MainFieldInfoValue(localMainFieldInfoStrOpt, remoteMainFieldInfoStrOpt)
                val mainFieldInfoJs = Json.stringify(Json.toJson(mainFieldInfo))
                connection.setSyncMainFieldInfo(mainFieldInfoJs)
                connectionRepository.updateFieldValues(connection.getID, connection.getFieldValues)
            }

            Future.successful((connection, Some(response.nodeInfo)))
          case _              =>
            val errMsg = "Couldn't read upgrade remote connection."
            loggingService.error(errMsg)
            val exception = bugExceptionCategoryService.generateBugException(None, Some(errMsg))
            Future.failed(exception)
        }
    } else {
      Future.successful((connection, None))
    }

  /** Performs upgrading of BASIC connection: * change mode from BASIC to the target one * makes a
    * request to upgrade remote node * if the new mode is CONFIGURE_BOTH_SIDES - pushEditorContext
    * @param connection
    * @param connectionMode
    *   \- new mode: CONFIGURE_BOTH_SIDES or SCRIPT
    * @return
    */
  override def upgradeConnectionFromUI(
      connection: IConnection,
      connectionMode: String
  ): Future[IConnection] = {
    loggingService.info(
      s"Upgrading connection `${connection.getName}`, changing mode from `${connection.getMode}` to `CONFIGURE_BOTH_SIDES`"
    )
    Try(ConnectionMode.valueOf(connectionMode)) match {
      case Failure(exception) => Future.failed(exception)
      case Success(mode)      =>
        for {
          _ <- shouldConnectionBeInitiatedUpgraded(Option(mode))
          (_, remoteNodeInfoOpt) <- upgradeRemoteSide(connection, connectionMode)
          updatedConnection <- changeMode(connection, connectionMode)
          remoteNodeInfo = remoteNodeInfoOpt.map(NodeInfoValueHelper.toNonPersistentNodeInfo)
          _ <- editorFieldContextService.pushEditorContext(
            getConnectionMode(Option(updatedConnection.getMode)),
            updatedConnection.isLocal,
            Future.successful(updatedConnection),
            Future.successful(remoteNodeInfo)
          )
        } yield updatedConnection
    }

  }

  private def shouldConnectionBeInitiatedUpgraded(
      connectionModeOpt: Option[ConnectionMode]
  ): Future[None.type] =
    connectionModeOpt match {
      case Some(connectionMode) =>
        licenseService.isConnectionValid(connectionMode).flatMap {
          case true => Future.successful(None)
          case _    =>
            Future.failed(new BugException(s"#initiate License does not support $connectionMode"))
        }
      case None                 => Future.successful(None)
    }

  private def updateNodeInfo(connection: IConnection, nodeInfo: NodeInfoValue): Future[None.type] =
    Option(connection.getRemoteInstance)
      .map(_.getID) match {
      case Some(instanceId) =>
        instanceRepository.getInstanceFuture(instanceId).flatMap {
          case Some(instance) =>
            loggingService.debug(
              s"Updating instance with id $instanceId. Setting up node info : $nodeInfo for connection ${connection.getName}"
            )
            instanceRepository
              .updateNodeInfo(
                instance.getNodeInfo,
                NodeInfoValueHelper.toNonPersistentNodeInfo(nodeInfo)
              )
              .map(_ => None)

          case _ =>
            loggingService
              .error(s"Cannot get instance by id $instanceId for connection ${connection.getName}")
            Future.successful(None)
        }
      case None             =>
        loggingService.error(s"Cannot get remote instance id for connection ${connection.getName}")
        Future.successful(None)
    }

  /** Handles upgrading of the connection when request comes from the remote side. * update current
    * node info in DB (since the node info does not have info about editor) * if the new mod is
    * CONFIGURE_BOTH_SIDES - validate access token, change mode and push editor context * otherwise
    * only change mode
    * @param connection
    * @param connectionMode
    *   \- new mode: CONFIGURE_BOTH_SIDES or SCRIPT
    * @param accessTokenOpt
    * @param nodeInfo
    * @return
    */
  override def upgradeConnectionFromRemote(
      connection: IConnection,
      connectionMode: String,
      accessTokenOpt: Option[String],
      nodeInfo: NodeInfoValue
  ): Future[None.type] = {
    loggingService.info(
      s"Upgrading connection ${connection.getName} from remote side to connection mode $connectionMode and using access token : $accessTokenOpt"
    )
    updateNodeInfo(connection, nodeInfo)

    if (
      ConnectionMode.CONFIGURE_BOTH_SIDES.toString.equals(
        connectionMode
      ) && accessTokenOpt.isDefined
    ) {
      val adminProofToken = accessTokenOpt.get
      oauthService
        .validateToken(adminProofToken)
        .flatMap { _ =>
          val updatedConnectionFuture = changeMode(connection, connectionMode)
          updatedConnectionFuture.foreach { updatedConnection =>
            loggingService.debug(
              "Access token was validated and mode was changed successfully. Going to push editor context"
            )
            val remoteNodeInfo = NodeInfoValueHelper.toNonPersistentNodeInfo(nodeInfo)
            editorFieldContextService.pushEditorContext(
              getConnectionMode(Option(updatedConnection.getMode)),
              updatedConnection.isLocal,
              Future.successful(updatedConnection),
              Future.successful(Some(remoteNodeInfo))
            )
          }
          updatedConnectionFuture
        }
        .map(_ => None)
    } else if (!ConnectionMode.CONFIGURE_BOTH_SIDES.toString.equals(connectionMode)) {
      changeMode(connection, connectionMode).map(_ => None)
    } else {
      val errMsg =
        "Cannot update connection mode to `CONFIGURE_BOTH_SIDES` without valid access token"
      loggingService.error(errMsg)
      val exception = bugExceptionCategoryService.generateBugException(None, Some(errMsg))
      Future.failed(exception)

    }
  }

  /** Performs changing mode: from BASIC to CONFIGURE_BOTH_SIDES_MODE ot Scripted
    * @param connection
    * @param connectionMode
    * @return
    */
  override def changeMode(connection: IConnection, connectionMode: String): Future[IConnection] = {
    connectionMode match {
      case CONFIGURE_BOTH_SIDES_MODE =>
        connection.setMode(ConnectionMode.CONFIGURE_BOTH_SIDES.toString)
        connection.setUpgradeDate(DateUtil.dateNowStr)
        val fieldValues = new util.HashMap[String, String](connection.getFieldValues)
        connectionRepository.updateFieldValues(connection.getID, fieldValues)
      case SCRIPT_MODE               =>
        connection.setMode(null)
        connection.setUpgradeDate(DateUtil.dateNowStr)
        val fieldValues = new util.HashMap[String, String](connection.getFieldValues)
        connectionRepository.updateFieldValues(connection.getID, fieldValues)
      case _                         =>
        loggingService.warn("Unknown connection mode")
    }
    Future.successful(connection)
  }

  /** Generates visual rules from basic and update connection
    * @param connection
    * @param accessToken
    * @return
    */
  override def generateVisualRulesFromBasic(
      connection: IConnection,
      accessToken: Option[String]
  ): Future[IConnection] = {
    val scopesMappingsConnectionF = for {
      // generate scopes and mapping,
      scopeValuesOpt <- basicConnectionService.generateDefaultScopeRules(connection)
      mappingValuesOpt <- basicConnectionService.generateDefaultMappingRules(
        connection,
        scopeValuesOpt
      )
      // set generated scopes and mappings to connectionValue
      connectionValue <- connectionValueHelper.toConnectionValue(connection)
      connectionValueUpdated = connectionValue.copy(
        scopes = scopeValuesOpt,
        mappings = mappingValuesOpt
      )
      // process Scopes & Mappings - saving them to DB
      draftScopes <- scopeService.processScopes(connection, connectionValueUpdated)
      mappings <- mappingService.processMappings(connection, connectionValueUpdated)
    } yield (draftScopes, mappings, connectionValueUpdated)

    scopesMappingsConnectionF.flatMap { scopesMappingsConnection =>
      val newConnection =
        connectionValueHelper.toInstanceAndRelationOnConnection(scopesMappingsConnection._3)
      update(
        connection.getID,
        newConnection,
        scopesMappingsConnection._1,
        scopesMappingsConnection._2,
        accessToken
      )
    }
  }

  override def generateConnectionName(remoteInstanceName: String): Future[ConnectionNameValue] = {
    loggingService.info(
      s"Going to generate a name for connection between local and remote `$remoteInstanceName` sides"
    )

    for {
      localInstanceName <- connectionNameService.generateLocalInstanceName()
      newConnectionName = s"${localInstanceName}_to_$remoteInstanceName"
      connectionOpt <- connectionRepository.getConnectionFuture(newConnectionName)
      newConnectionNameValue = ConnectionNameValue(
        if (connectionOpt.isDefined) Some(s"${newConnectionName}_${DateUtil.dateNowStr}")
        else Some(newConnectionName),
        Some(localInstanceName),
        Some(remoteInstanceName)
      )
    } yield newConnectionNameValue
  }

  private def generateInvitationCodeValue(
      cv: ConnectionValue,
      invitedInstanceUid: Option[String],
      invitationSecret: String
  ): Future[InvitationValue] = {
    val simplifiedConnectionValue = generateSimplifiedConnectionValue(cv)

    nodeInfoProvider.get
      .map(ni => InvitationValue(invitationSecret, invitedInstanceUid, ni, simplifiedConnectionValue))
  }

  private def generateSimplifiedConnectionValue(cv: ConnectionValue) =
    // Sync Rules are not needed for invitation
    ConnectionValue(
      id = None,
      name = cv.name,
      status = None,
      mode = cv.mode,
      invitationStatus = None,
      description = cv.description,
      syncRules = None,
      communication = cv.communication
        .copy(
          localNodeInfo = None,
          remoteNodeInfo = None
        ),
      isLocal = None,
      localInstanceName = cv.remoteInstanceName,
      remoteInstanceName = cv.localInstanceName,
      scopes = None,
      mappings = None
    )

  private def generateInvitationCode(
      cv: ConnectionValue,
      invitedInstanceUid: Option[String],
      invitationSecret: String
  ): Future[String] =
    generateInvitationCodeValue(cv, invitedInstanceUid, invitationSecret)
      .map(toInvitationCodeStr)

  private def generateInvitationCodeForBasicConnection(
      cv: ConnectionValue,
      invitedInstanceUid: Option[String],
      invitationSecret: String
  ): Future[String] =
    generateInvitationCodeValueForBasicConnection(cv, invitedInstanceUid, invitationSecret)
      .map(toInvitationCodeStr)

  private def generateInvitationCodeValueForBasicConnection(
      cv: ConnectionValue,
      invitedInstanceUid: Option[String],
      invitationSecret: String
  ): Future[InvitationValue] = {
    // Sync Rules are not needed for invitation
    val simplifiedConnectionValue = generateSimplifiedConnectionValue(cv)

    nodeInfoProvider.get
      .map { ni =>
        val simplifiedNodeInfoValue = ni.copy(
          issueTrackerUrl = None,
          issueTrackerVersion = "",
          nodeAppVersion = "",
          exalatePluginVersion = "",
          pollOnly = None,
          rawExaCompVersion = None,
          editor = None,
          iconUrl = None,
          basicConnection = Some(BasicConnectionValue(Seq.empty[SupportedEditorField]))
        )
        InvitationValue(
          invitationSecret,
          invitedInstanceUid,
          simplifiedNodeInfoValue,
          simplifiedConnectionValue
        )
      }
  }

  private def toInvitationCodeStr(
      invitationValue: InvitationValue
  ): String =
    Base64.encodeBase64String(Json.toJson(invitationValue).toString().getBytes)

  // Receive a nonPersistentInstance and get node info if status is ACTIVE. If node info cannot be retrieved move status to INITIAL
  private def setNodeInfoAndStatusOnInstance(
      nonPersistentInstance: INonPersistentInstance
  ): Future[INonPersistentInstance] =
    Option(nonPersistentInstance.getStatus).getOrElse(Some(INITIAL)) match {
      case ACTIVE | INITIAL =>
        Option(nonPersistentInstance.getNodeInfo) match {
          case Some(nodeInfo) if nodeInfo.isPollOnly => Future.successful(nonPersistentInstance)
          case _ if Option(nonPersistentInstance.getUrl).isEmpty =>
            Future.successful(setStatus(nonPersistentInstance, DEACTIVATED))
          case _                                                 =>
            getNodeInfoViaDifferentUrls(nonPersistentInstance)
              .map(updatedInstance => setStatus(updatedInstance, ACTIVE))
              .recover { case _ => setStatus(nonPersistentInstance, INITIAL) }
        }
      case _                => Future.successful(nonPersistentInstance)
    }

  private def getNodeInfoViaDifferentUrls(
      nonPersistentInstance: INonPersistentInstance
  ): Future[INonPersistentInstance] =
    urlInferringService
      .getAndSetNodeInfoWithExalateUrl(nonPersistentInstance)
      .recoverWith {
        case e =>
          urlInferringService.getAndSetNodeInfoWithTrackerUrl(nonPersistentInstance).recoverWith {
            case _ => Future.failed(e)
          }
      }

  private def setStatus(nonPersistentInstance: INonPersistentInstance, status: InstanceStatus) =
    new NonPersistentInstance(
      nonPersistentInstance.getName,
      nonPersistentInstance.getDescription,
      nonPersistentInstance.getUrl,
      nonPersistentInstance.getIssueTrackerUrl,
      status,
      nonPersistentInstance.getNodeInfo,
      nonPersistentInstance.getIssueTrackerSettings,
      nonPersistentInstance.getRemoteUsername,
      nonPersistentInstance.getRemoteUserPassword,
      nonPersistentInstance.isAuthenticationRequired,
      nonPersistentInstance.getCustomFieldValues,
      nonPersistentInstance.getFieldValues
    )

  override def test(nonPersistentInstance: INonPersistentInstance): Future[INonPersistentNodeInfo] =
    getNodeInfoViaDifferentUrls(nonPersistentInstance).map(_.getNodeInfo)

  override def getConnectionsPaginated(
      offset: Option[ConnectionId],
      limit: Option[ConnectionId],
      sorting: List[String],
      projectId: Option[String],
      connectionName: Option[String],
      relationIssueTrackerSettingsFieldValuesKeys: Set[String]
  ): Future[PaginationValueWrite[ConnectionValueForList]] =
    connectionRepository
      .getConnectionsPaginated(
        offset,
        limit,
        sorting,
        projectId,
        connectionName,
        relationIssueTrackerSettingsFieldValuesKeys
      )
      .flatMap { paginationValueWrite =>
        Option(paginationValueWrite.results)
          .map { results =>
            val modifiedResults = results.map(connectionValueForList =>
              connectionValueForList.id
                .map(connectionId =>
                  oauthService
                    .getTokens(connectionId)
                    .map(tokens =>
                      connectionValueForList.copy(hasRemoteAccess = Some(!tokens.isEmpty))
                    )
                )
                .getOrElse(Future.successful(connectionValueForList))
            )
            val modifiedResultsFuture = Future.sequence(modifiedResults)
            modifiedResultsFuture
              .map(modifiedResultsSeq => paginationValueWrite.copy(results = modifiedResultsSeq))
          }
          .getOrElse(Future.successful(paginationValueWrite))
      }

  override def getConnectionInfo(): Future[Seq[ConnectionInfo]] =
    connectionRepository.findConnectionsFuture.flatMap(connections =>
      FutureUtils.foldLeft(connections) { connection =>
        val mode =
          if (connection.getMode == null) ConnectionMode.SCRIPT.toString else connection.getMode
        val wasUpgraded = connection.getUpgradeDate != null
        val connectionType = getConnectionTypeStr(connection)
        for {
          lastSuccessfulSyncDate <- twinTraceRepository.getLastSuccessfulSyncDateForConnection(
            connection
          )
          lastSuccessfulSyncDateStr = lastSuccessfulSyncDate.map(ld =>
            new SimpleDateFormat("dd/MMM/yyyy HH:mm:ss").format(ld)
          )
          numberOfIssuesUnderSync <- twinTraceRepository.getSynchronizedCountForConnection(
            connection
          )
          numberOfNodeLevelErrors <- errorRepository.countErrorsForConnectionAndLevel(
            connection,
            ErrorEntityType.NODE.name
          )
          numberOfConnectionLevelErrors <- errorRepository.countErrorsForConnectionAndLevel(
            connection,
            ErrorEntityType.RELATION.name
          )
          numberOfTriggerLevelErrors <- errorRepository.countErrorsForConnectionAndLevel(
            connection,
            ErrorEntityType.TRIGGER.name
          )
          numberOfIssueLevelErrors <- errorRepository.countErrorsForConnectionAndLevel(
            connection,
            ErrorEntityType.ISSUE.name
          )
          numberOfWarningLevelErrors <- errorRepository.countErrorsForConnectionAndLevel(
            connection,
            ErrorEntityType.WARNING.name
          )
          numberOfEntitiesInSyncEventQueue <- eventReplicationRepository.getNumberOfEntities()
          numberOfEntitiesInSyncRequestQueue <- requestReplicationRepository.getNumberOfEntities()
          metricValues <- metricPersis.getByConnectionId(connection.getID)
          isSyncedFirstIssue = metricValues.exists(
            _.eventName.equals(MetricEvents.EXALATE_STARTED.toString)
          )
          metricInfo = metricValues.map(m =>
            MetricInfo(
              m.eventName,
              new SimpleDateFormat("dd/MMM/yyyy HH:mm:ss").format(new Timestamp(m.eventDate)),
              m.eventDuration
            )
          )
        } yield ConnectionInfo(
          connection.getName,
          mode,
          wasUpgraded,
          lastSuccessfulSyncDateStr,
          numberOfIssuesUnderSync,
          numberOfNodeLevelErrors,
          numberOfConnectionLevelErrors,
          numberOfTriggerLevelErrors,
          numberOfIssueLevelErrors,
          numberOfWarningLevelErrors,
          numberOfEntitiesInSyncEventQueue,
          numberOfEntitiesInSyncRequestQueue,
          Option(connection.getRemoteInstance)
            .flatMap(i => Option(i.getNodeInfo))
            .map(_.getIssueTrackerUrl),
          Option(connection.getRemoteInstance)
            .flatMap(i => Option(i.getNodeInfo))
            .map(_.getExalateUrl),
          connectionType,
          isSyncedFirstIssue,
          metricInfo
        )
      }
    )

  override def deactivateAllConnections(): Future[None.type] =
    connectionRepository.deActivateAllConnection()

  private def getConnectionTypeStr(connection: IConnection) =
    if (connection.isLocal) {
      "local"
    } else if (ReceiveProtocol.POLL.equals(connection.getReceiveProtocol)) {
      "private"
    } else { "public" }

}

object ConnectionService {
  val SECRET_LENGTH = 32;
}
