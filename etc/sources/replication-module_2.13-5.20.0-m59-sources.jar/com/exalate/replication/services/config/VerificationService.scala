package com.exalate.replication.services.config

import com.exalate.api.domain.ErrorEntityType
import com.exalate.api.exception.bug.PersistenceBugException
import com.exalate.api.exception.{CategorizedException, VerifyCodeErrors, VerifyNodeException}
import com.exalate.api.persistence.exalateadmin.IExalateAdminRepository
import com.exalate.basic.domain.exalateadmin.NonPersistentExalateAdmin
import com.exalate.replication.services.api.license.ILicenseService
import com.exalate.replication.services.api.node.lifecycle.ILifecycleInfoService
import com.exalate.replication.services.transport.v1.rest.EvaluationClient
import com.google.inject.Inject

import scala.concurrent.{ExecutionContext, Future}

class VerificationService @Inject() (
    lifecycleInfoService: ILifecycleInfoService,
    evaluationClient: EvaluationClient,
    adminRepository: IExalateAdminRepository,
    licenseService: ILicenseService
)(implicit ec: ExecutionContext) {

  /** Flow: ** acceptEula - we don't do anything until eula is accepted ** setVerified - it's enough
    * to get mail with url and accept eula to set verify ** set license - once eula is accepted and
    * node verified - we set license ** set admin - once eula is accepted and node verified - we set
    * admin **
    *
    * @return
    */

  def verifyNode(instanceUid: String): Future[None.type] =
    lifecycleInfoService.acceptEula
      .recoverWith {
        case e: PersistenceBugException =>
          throw new VerifyNodeException(VerifyCodeErrors.EULA, VerifyCodeErrors.EULA.getMessage)
      }
      .flatMap(_ =>
        lifecycleInfoService
          .setVerified()
          .flatMap(_ =>
            evaluationClient
              .getLicense(instanceUid)
              .flatMap { licOpt =>
                licOpt
                  .map { l =>
                    val npAdmin = new NonPersistentExalateAdmin(
                      l.email.split("@").headOption.getOrElse("admin"),
                      l.email,
                      ErrorEntityType.ISSUE
                    )

                    adminRepository
                      .createAdmin(npAdmin)
                      .recoverWith {
                        case e: PersistenceBugException =>
                          licenseService
                            .save(l.licenseKey)
                            .recoverWith {
                              case e: PersistenceBugException =>
                                throw new VerifyNodeException(
                                  VerifyCodeErrors.ADMIN_LICENSE,
                                  VerifyCodeErrors.ADMIN_LICENSE.getMessage
                                )
                            }
                            .map(_ =>
                              throw new VerifyNodeException(
                                VerifyCodeErrors.ADMIN,
                                VerifyCodeErrors.ADMIN.getMessage
                              )
                            )
                      }
                      .flatMap(_ =>
                        licenseService
                          .save(l.licenseKey)
                          .recoverWith {
                            case e: PersistenceBugException =>
                              throw new VerifyNodeException(
                                VerifyCodeErrors.LICENSE,
                                VerifyCodeErrors.LICENSE.getMessage
                              )
                          }
                          .map(_ => None)
                      )

                  }
                  .getOrElse(
                    throw new VerifyNodeException(
                      VerifyCodeErrors.GET_LICENSE,
                      "License result is empty."
                    )
                  )
              }
              .recoverWith {
                case e: CategorizedException if !e.isInstanceOf[VerifyNodeException] =>
                  throw new VerifyNodeException(
                    VerifyCodeErrors.GET_LICENSE,
                    VerifyCodeErrors.GET_LICENSE.getMessage
                  )
              }
          )
          .recoverWith {
            case e: PersistenceBugException =>
              throw new VerifyNodeException(
                VerifyCodeErrors.VERIFY,
                VerifyCodeErrors.VERIFY.getMessage
              )
          }
      )

}
