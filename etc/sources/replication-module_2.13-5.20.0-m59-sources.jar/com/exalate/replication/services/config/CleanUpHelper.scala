package com.exalate.replication.services.config

import com.exalate.api.CleanUpResult
import com.exalate.api.domain.connection.IConnection
import com.exalate.api.persistence.relation.IRelationRepository
import com.exalate.basic.domain.util.SemanticVersionService
import com.exalate.domain.values.ConnectFile
import com.exalate.error.services.api.IFileSystemExceptionCategoryService
import com.exalate.replication.services.utils.ConfigPropertyService
import com.exalate.util.UrlUtils
import com.google.inject.Inject
import org.apache.commons.io.IOUtils
import play.api.Logger
import play.api.libs.json.{JsObject, Json}

import java.io.{BufferedWriter, File, FileWriter}
import java.nio.file.{InvalidPathException, Paths}
import java.text.SimpleDateFormat
import java.util.Calendar
import scala.concurrent.{ExecutionContext, Future}
import scala.util.{Failure, Success, Try}

class CleanUpHelper @Inject() (
    configuration: ConfigPropertyService,
    relationRepository: IRelationRepository,
    fileSystemExceptionCategoryService: IFileSystemExceptionCategoryService
)(implicit ec: ExecutionContext) {

  private val LOG = Logger(classOf[CleanUpHelper])

  val DATA_DIRECTORY = "exalate.sync.data.dir"

  private val cleanUpBothVersion = SemanticVersionService.create(1, 23, 0)

  /** Checks whether remote side supports clean up feature
    *
    * @param connection
    * @return
    */
  def remoteSupportsCleanup(connection: IConnection): Boolean = {
    val remoteExaVersionOpt = Option(connection.getRemoteInstance.getNodeInfo)
      .flatMap(remoteNodeInfo => Option(remoteNodeInfo.getExaCompVersion))
    remoteExaVersionOpt.exists { remoteExaVersion =>
      val remoteVersion = SemanticVersionService.get(remoteExaVersion)
      !SemanticVersionService.isLeftOlderThanRight(remoteVersion, cleanUpBothVersion)
    }
  }

  /** Converts CleanUpResult to JsObject
    *
    * @param cleanUpResultFut
    * @return
    */
  def getJsonObjFromCleanUp(cleanUpResultFut: Future[CleanUpResult]): Future[Seq[JsObject]] =
    cleanUpResultFut
      .flatMap { cleanUpResult =>
        Future.sequence(cleanUpResult.issuePairs.map {
          case (connectionId, issuePairsForRelation) =>
            val jsonPairs = issuePairsForRelation.map(p =>
              Json.obj("localIssueUrn" -> p._1, "remoteIssueUrn" -> p._2)
            )
            val connectionNameFuture =
              relationRepository.getConnectionFuture(connectionId).map(_.fold("unknown")(_.getName))
            val fileFuture = Future.fromTry(
              getCsvFile(issuePairsForRelation, "CONNECTION", Some(connectionId.toString))
            )
            for {
              connectionName <- connectionNameFuture
              file <- fileFuture
            } yield Json.obj(
              "relationName" -> connectionName,
              "issuePairs" -> jsonPairs,
              "file" -> Json.toJson(file)
            )
        })
      }
      .map(_.toSeq)

  /** Creates CSV file of the clean up result
    *
    * @param issuePairs
    * @param level
    * @param entityNameOpt
    * @return
    */
  def getCsvFile(
      issuePairs: Seq[(String, String)],
      level: String,
      entityNameOpt: Option[String]
  ): Try[ConnectFile] = {
    val fileContent = issuePairs
      .map(pair => s"${pair._1},${pair._2}")
      .mkString("\n")
    createCleanUpResultCsvFile(level, entityNameOpt, fileContent)
  }

  /** Creates Csv File with CleanUp Result
    *
    * @param level
    * @param entityNameOpt
    * @param fileContent
    * @return
    *   ConnectFile
    */
  def createCleanUpResultCsvFile(
      level: String,
      entityNameOpt: Option[String],
      fileContent: String
  ): Try[ConnectFile] =
    getCleanUpResultTempDir
      .flatMap { filePath =>
        val csvFileName = getCleanUpResultFileName(level, entityNameOpt)
        val absolutePathStr = Paths.get(filePath, csvFileName).toAbsolutePath.toString
        val file = new File(absolutePathStr)
        var writer: BufferedWriter = null

        try
          if (file.canWrite) {
            writer = new BufferedWriter(new FileWriter(file))
            writer.write(fileContent)
            Success(
              ConnectFile(csvFileName, UrlUtils.concat("/rest/issuehub/files/" + absolutePathStr))
            )
          } else {
            Success(
              ConnectFile(csvFileName, UrlUtils.concat("/rest/issuehub/files/" + absolutePathStr))
            )
          }

        catch {
          case e: Exception =>
            Failure(fileSystemExceptionCategoryService.generateExalateCleanupFileSystemException(e))
        } finally IOUtils.closeQuietly(writer)
      }
      .recoverWith {
        case e: InvalidPathException =>
          LOG.error(s"Unable to resolve a path string into Path.", e)
          Failure(fileSystemExceptionCategoryService.generateExalateInvalidPathException(e, None))
      }

  /** Gets a temp dir of clean up results
    *
    * @return
    */
  private def getCleanUpResultTempDir: Try[String] = configuration.getPropertyValue(DATA_DIRECTORY)

  /** Generates a file name of clean up results
    *
    * @param level
    * @param entityNameOpt
    * @return
    *   name of the file
    */
  private def getCleanUpResultFileName(level: String, entityNameOpt: Option[String]): String =
    s"connect-${level.toLowerCase}-${entityNameOpt.map(_ + "-").getOrElse("")}${new SimpleDateFormat("yyyyMMdd_HHmmss")
        .format(Calendar.getInstance.getTime)}.csv"

}
