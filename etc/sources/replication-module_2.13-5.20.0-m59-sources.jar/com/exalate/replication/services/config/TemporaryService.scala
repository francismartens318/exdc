package com.exalate.replication.services.config

import com.exalate.api.ILoggingService
import com.exalate.api.persistence.invitation.ITemporaryDataRepository
import com.exalate.domain.TemporaryData
import com.exalate.replication.services.api.config.ITemporaryService
import com.google.inject.Inject

import scala.concurrent.Future

class TemporaryService @Inject() (
    temporaryRepository: ITemporaryDataRepository,
    loggingService: ILoggingService
) extends ITemporaryService {

  private val LOG = loggingService

  override def get(temporaryId: String): Future[Option[TemporaryData]] = {
    LOG.info(s"Fetching temporary details for id $temporaryId")
    temporaryRepository.get(temporaryId)
  }

  override def store(temporaryData: TemporaryData): Future[Int] = {
    LOG.info(s"Storing temporary details for id ${temporaryData.id}")
    temporaryRepository.upsert(temporaryData)
  }

  override def delete(temporaryId: String): Future[Int] = {
    LOG.info(s"Deleting temporary details for id $temporaryId")
    temporaryRepository.delete(temporaryId)
  }

  override def deleteInvitationDetails(
      invitedInstanceUid: Option[String] = None,
      connectionName: Option[String] = None
  ): Future[Int] = {
    LOG.info(
      s"Deleting temporary details for invitation instance id $invitedInstanceUid and connection name $connectionName"
    )
    temporaryRepository.deleteInvitationDetails(invitedInstanceUid, connectionName)
  }

}
