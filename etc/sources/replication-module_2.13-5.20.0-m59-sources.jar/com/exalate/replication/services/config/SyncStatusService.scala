package com.exalate.replication.services.config

import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.error.IErrorInfo
import com.exalate.api.domain.twintrace._
import com.exalate.api.domain.{IIssueKey, IPersistentReplica, ISummary}
import com.exalate.api.persistence.config.ISyncPanelRepository
import com.exalate.api.persistence.error.IErrorRepository
import com.exalate.api.persistence.twintrace.ITwinTraceRepository
import com.exalate.basic.domain.syncstatus.RemoteIssueUrlContext
import com.exalate.basic.domain.{BasicIssueKey, ErrorInfo}
import com.exalate.generic.services.api.ITrackerHubObjectService
import com.exalate.replication.services.api.config._
import com.exalate.replication.services.api.transport.ITransportServiceFactory
import com.google.inject.Inject
import play.api.Logger
import play.api.libs.json.Json

import scala.concurrent.{ExecutionContext, Future}

class SyncStatusService @Inject() (
    errorRepository: IErrorRepository,
    twinTraceRepository: ITwinTraceRepository,
    syncPanelRepository: ISyncPanelRepository,
    transportServiceFactory: ITransportServiceFactory,
    nodeHubObjectService: ITrackerHubObjectService
)(implicit ec: ExecutionContext)
    extends ISyncStatusService {

  private val LOG: Logger = Logger("application.services.replication.config.SyncStatusService")

  /** Gets a sync status of an issue by the issue key
    * @param issueKey
    * @return
    *   SyncStatusesBean
    */
  override def getSyncStatusesByIssueId(
      issueKey: IIssueKey,
      belongsToProject: Boolean = true
  ): Future[Option[SyncStatusesBean]] = {
    LOG.debug(s"Getting sync statuses by issueKey : $issueKey")
    twinTraceRepository
      .findTwinTracesByIssueIdSimplified(
        issueKey.getIdStr,
        issueKey.getEntityType,
        issueKey.getFieldValues
      )
      .flatMap { twinTraces =>
        if (twinTraces.isEmpty) {
          LOG.debug(s"List of Twin Traces is empty for issue `${issueKey.getIdStr}`")
          // FIX-ME: There could be a sync request even if there is no twin trace
          getErrorInfoByIssueId(issueKey)
            .map(errorInfoSetOpt =>
              errorInfoSetOpt.map(errorInfoTuple =>
                SyncStatusBean(
                  SyncStatus.ERROR,
                  errorInfoTuple._1,
                  -1,
                  errorInfoTuple._2.getName,
                  errorInfoTuple._2.getTrackerSettings.getCreateSyncPanelLinks,
                  Public(None),
                  errorInfoTuple._2.getID,
                  None
                )
              )
            )
            .map(syncStatuses => Some(SyncStatusesBean(syncStatuses.toSet, belongsToProject)))
        } else {
          LOG.debug(s"Found ${twinTraces.size} twin traces for issue  `${issueKey.getIdStr}`")
          Future.sequence(getSyncStatuses(twinTraces)).map { syncStatuses =>
            Some(SyncStatusesBean(syncStatuses, belongsToProject))
          }
        }
      }
  }

  /** Gets a sync status of an issue by the issue urn
    * @param fieldValues
    * @param issueUrn
    * @param entityType
    * @return
    */
  def getSyncStatusesByIssueUrn(
      fieldValues: Map[String, String],
      issueUrn: String,
      entityType: String
  ): Future[Option[SyncStatusesBean]] =
    nodeHubObjectService.getLocalKeyForFieldValues(issueUrn, fieldValues, entityType).flatMap {
      case Some(issueKey: IIssueKey) => getSyncStatusesByIssueId(issueKey)
      case None                      => Future.successful(None)
    }

  override def getSyncStatusesByIssueUrnAndProjId(
      expectedProjectId: String,
      issueUrn: String,
      entityType: String
  ): Future[Option[SyncStatusesBean]] =
    nodeHubObjectService.getEntityJsValue(issueUrn, entityType).flatMap {
      case Some(entityJsValue) =>
        val actualProjectId = (entityJsValue \ "fields" \ "project" \ "id").asOpt[String]
        val id = (entityJsValue \ "id").as[String]
        val issueKey = new BasicIssueKey(id, issueUrn)
        if (actualProjectId.contains(expectedProjectId)) {
          getSyncStatusesByIssueId(issueKey)
        } else {
          getSyncStatusesByIssueId(issueKey, belongsToProject = false)
        }
      case None                => Future.successful(None)
    }

  /** Gets a list of sync statuses that corresponds to each twin trace in the provided seq
    *
    * @param twinTraces
    * @return
    */
  private def getSyncStatuses(twinTraces: Seq[ITwinTrace]): Set[Future[SyncStatusBean]] =
    twinTraces.map { twinTrace =>
      getErrorInfo(twinTrace)
        .flatMap { errorInfo =>
          LOG.debug(s"Error Info $errorInfo ")
          getSyncStatus(twinTrace, errorInfo).map((_, errorInfo))
        }
        .flatMap(v => getRemoteIssueUrlContext(twinTrace).map(rIUC => (v._1, v._2, rIUC)))
        .map {
          case (syncStatus, errorInfo, remoteIssueUrlContextOpt) =>
            val localEntitySummary = Option(twinTrace.getLocalReplica)
              .flatMap(r => Option(r.getSummary))
              .flatMap(s => Option(s.toExternalForm))
            SyncStatusBean(
              syncStatus,
              errorInfo,
              twinTrace.getId,
              twinTrace.getConnection.getName,
              twinTrace.getConnection.getTrackerSettings.getCreateSyncPanelLinks,
              remoteIssueUrlContextOpt,
              twinTrace.getConnection.getID,
              localEntitySummary
            )
        }
    }.toSet

  /** Gets a context of remote issue by provided twin trace
    * @param twinTrace
    * @return
    *   RemoteIssueContext
    */
  private def getRemoteIssueUrlContext(twinTrace: ITwinTrace): Future[RemoteIssueContext] =
    if (Option(twinTrace.getConnection.getRemoteInstance.getNodeInfo).exists(!_.isPollOnly)) {
      (Option(twinTrace.getRemoteReplica), Option(twinTrace.getRemoteTwinTraceId)) match {
        case (Some(remoteReplica), Some(remoteTwinTraceId)) =>
          val remoteIssueId = Option(remoteReplica.getIssueKey)
            .flatMap(key => Option(key.getIdStr))
            .getOrElse("NOT AVAILABLE")
          val remoteIssueUrn = Option(remoteReplica.getIssueKey)
            .flatMap(key => Option(key.getURN))
            .getOrElse("NOT AVAILABLE")
          val remoteSummary =
            Option(remoteReplica.getSummary).flatMap(summary => Option(summary.toExternalForm))
          val trimmedSummary =
            remoteSummary.map(s => if (s.length > 38) s.slice(0, 35) + "..." else s).getOrElse("")
          val connection = twinTrace.getConnection

          ((Json.parse(remoteReplica.getPayload) \ "issueUrl").asOpt[String] match {
            case a @ Some(_) => Future.successful(a)
            case None        =>
              Future
                .fromTry(transportServiceFactory.get(twinTrace.getConnection))
                .flatMap(_.getRemoteIssueUrl(twinTrace.getLocalReplica.getIssueKey, connection))
          })
            .map {
              case Some(issueUrl) =>
                Public(
                  Some(
                    new RemoteIssueUrlContext(
                      issueUrl,
                      trimmedSummary,
                      remoteIssueUrn,
                      remoteIssueId
                    )
                  )
                )
              case None           => Public(None)
            }
            .recoverWith {
              case e: Exception => Future.successful(Public(None))
            }

        case _ => Future.successful(Public(None))
      }
    } else {
      Future.successful(Private)
    }

  /** Gets a sync status of an issue by the issue key
    * @param issueKey
    * @param connection
    * @return
    */
  private def getSyncStatusByIssueKey(
      issueKey: IIssueKey,
      connection: IConnection
  ): Future[SyncStatus] =
    for {
      syncEventCount <- syncPanelRepository.countSyncEventsForLocalIssueKey(issueKey, connection)
      syncEventsWaitingForRemote <- syncPanelRepository.countSyncEventsWaitingForRemote(
        issueKey,
        connection
      )
      syncRequestCount <- syncPanelRepository.countSyncRequestsForLocalIssueKey(issueKey, connection)
      syncRequestsWaitingForRemote <- syncPanelRepository.countSyncRequestsWaitingForRemote(
        issueKey,
        connection
      )
    } yield
      if (
        !connection.isLocal && (syncEventCount > 0 || syncRequestCount > 0) && (syncEventCount == syncEventsWaitingForRemote && syncRequestCount == syncRequestsWaitingForRemote)
      ) {
        SyncStatus.WAITING_FOR_REMOTE
      } else if (syncEventCount == 0 && syncRequestCount == 0) {
        SyncStatus.SYNCHRONIZED
      } else SyncStatus.IN_PROGRESS

  /** Gets a sync status for provided twin trace an error info
    * @param twinTrace
    * @param errorInfo
    * @return
    */
  private def getSyncStatus(twinTrace: ITwinTrace, errorInfo: IErrorInfo): Future[SyncStatus] = {
    val twinTraceStatus = twinTrace.getStatus
    val underCleanupOrUnexalate = twinTrace.getStatus == TwinTraceStatus.UNEXALATED
    if (underCleanupOrUnexalate) Future.successful(SyncStatus.UNDER_CLEANUP)
    else if (!errorInfo.isOk && !errorInfo.isLicenseOk)
      Future.successful(SyncStatus.LICENSE_ERROR)
    else if (!errorInfo.isOk)
      Future.successful(SyncStatus.ERROR)
    else if (twinTraceStatus == TwinTraceStatus.REMOTE_ISSUE_DELETED)
      Future.successful(SyncStatus.REMOTE_ISSUE_REMOVED)
    else
      Option(twinTrace.getLocalReplica)
        .map(_.getIssueKey)
        .map { issueKey =>
          getSyncStatusByIssueKey(issueKey, twinTrace.getConnection)
        }
        .getOrElse(Future.successful(SyncStatus.IN_PROGRESS))
  }

  /** Gets error info from DB by localIssueKey & remoteIssueKey from provided twin trace
    * @param twinTrace
    * @return
    */
  private def getErrorInfo(twinTrace: ITwinTrace): Future[ErrorInfo] = {
    val remoteIssueKeyOpt = Option(twinTrace.getRemoteReplica).flatMap(x => Option(x.getIssueKey))
    val localIssueKeyOpt = Option(twinTrace.getLocalReplica).flatMap(x => Option(x.getIssueKey))
    val instance = twinTrace.getConnection.getRemoteInstance
    LOG.debug(
      s"Getting error info for twin trace ${twinTrace.getId}, remoteIssueKey = $remoteIssueKeyOpt, localIssueKeyOpt = $localIssueKeyOpt, remote instance URL = ${instance.getUrl}"
    )
    errorRepository
      .hasBlockers(
        None,
        Some(twinTrace.getConnection),
        Some(instance),
        localIssueKeyOpt,
        remoteIssueKeyOpt
      )
      .flatMap { hasLocalBlockers =>
        if (twinTrace.getConnection.isLocal && !hasLocalBlockers)
          errorRepository
            .hasBlockers(
              None,
              Some(twinTrace.getConnection),
              Some(instance),
              remoteIssueKeyOpt,
              localIssueKeyOpt
            )
            .flatMap { hasRemoteBlockers =>
              errorRepository
                .hasLicenseErrors(twinTrace.getConnection.getID, remoteIssueKeyOpt, localIssueKeyOpt)
                .map(le => new ErrorInfo(!hasRemoteBlockers, !le))
            }
        else {
          errorRepository
            .hasLicenseErrors(twinTrace.getConnection.getID, localIssueKeyOpt, remoteIssueKeyOpt)
            .map(le => new ErrorInfo(!hasLocalBlockers, !le))
        }
      }
  }

  private def getErrorInfoByIssueId(issueKey: IIssueKey): Future[Seq[(ErrorInfo, IConnection)]] =
    // review after EXE-683 demo
    //        connectionService.findAll().flatMap { connections =>
    //          Future.sequence(
    //            connections.map(
    //              connection => for {
    //                localBlockers <- errorRepository.hasBlockers(None, Some(connection), Some(connection.getRemoteInstance), Some(issueKey), None)
    //                hasNoLocalBlockers = !localBlockers
    //                result <-
    //                  if (connection.isLocal && hasNoLocalBlockers) errorRepository.hasBlockers(None, Some(connection), Some(connection.getRemoteInstance), None, Some(issueKey))
    //                    .map(remoteBlockers => (new ErrorInfo(!remoteBlockers), connection))
    //                  else Future.successful((new ErrorInfo(hasNoLocalBlockers), connection))
    //              } yield result
    //            )
    //          )
    //            .map(_.filter(!_._1.isOk))
    //        }
    // FIXME: when there is no twin trace, we can still have a scheduling error.
    Future.successful(Nil)

}
