package com.exalate.replication.services.config

import com.exalate.api.exception.CategorizedException
import com.exalate.domain.exception.editor.EditorCategorizedException
import com.exalate.services.api.IMessagesService
import org.apache.commons.lang3.StringUtils

import java.util.Locale
import javax.inject.Inject

class ExalateErrorMessageService @Inject() (messages: IMessagesService) {

  /** Converts Throwable into Message With Doc Link
    * @param e
    *   Throwable error
    * @param localeOpt
    *   constant for language.
    * @return
    *   error message
    */
  def generateMessageWithDocLinkIfPresent(
      e: Throwable
  )(implicit localeOpt: Option[Locale]): Option[String] = {
    val msgOpt = Option(e.getMessage)
    e match {
      case ce: CategorizedException =>
        val docLinkOpt = if (StringUtils.isBlank(ce.getDocsLink)) None else Some(ce.getDocsLink)
        val message = (ce match {
          case ece: EditorCategorizedException =>
            val key = ece.editorError.errorValue.key
            val vals = ece.editorError.errorValue.value.toSeq.flatMap(_.values)
            messages.translate(key, vals)
          case _                               => msgOpt.map(m => s"$m ")
        })
          .getOrElse("")
        Some(s"""$message${docLinkOpt
            .map(link =>
              s"""Check the <a href="$link" target='_blank' rel='noopener noreferrer'>documentation</a> for more details."""
            )
            .getOrElse("")}""")
      case _                        => msgOpt
    }
  }

  /** Generates message using provided message and Throwable error into Message With Doc Link
    * @param initialMsg
    *   message
    * @param e
    *   Throwable error
    * @return
    *   error message
    */
  def generateMessageFromGivenAndWithDocLinkIfPresent(initialMsg: String, e: Throwable): String =
    e match {
      case ce: CategorizedException =>
        val docLinkOpt = if (StringUtils.isBlank(ce.getDocsLink)) None else Some(ce.getDocsLink)
        s"""$initialMsg${docLinkOpt
            .map(link =>
              s"""Check the <a href="$link" target='_blank' rel='noopener noreferrer'>documentation</a> for more details."""
            )
            .getOrElse("")}"""
      case _                        => initialMsg
    }

  /** Generates Root Cause Error Type Name from Throwable error
    * @param e
    * @return
    */
  def generateRootCauseErrorTypeNameIfPresent(e: Throwable): String =
    e match {
      case ce: CategorizedException => ce.getRootCauseErrorTypeName
      case _                        => e.getClass.getSimpleName
    }

}
