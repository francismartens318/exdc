package com.exalate.replication.services.config

import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.hubobject.IHubPayload
import com.exalate.generic.services.api.ITrackerHubObjectService
import com.exalate.replication.services.api.config.ICsvService
import com.exalate.replication.services.transport.value.{ConnectInfoValue, IssueKeyValue}
import com.exalate.services.utils.FutureUtils
import com.exalate.services.utils.pagination.{PaginationUtil, SimplePage}
import com.google.inject.Inject
import org.apache.commons.csv.{CSVFormat, CSVParser, CSVRecord}
import org.apache.commons.lang3.StringUtils
import play.api.Configuration

import java.io.{File, IOException}
import java.nio.charset.Charset
import scala.jdk.CollectionConverters._
import scala.concurrent.{ExecutionContext, Future}
import scala.util.{Failure, Success, Try}

class CsvService @Inject() (
    trackerHubObjectService: ITrackerHubObjectService,
    configuration: Configuration
)(implicit ec: ExecutionContext)
    extends ICsvService {

  val CONNECT_INFO_NUM_PER_PAGE: Int =
    configuration.getOptional[Int]("exalate.connect.info.number.per.page").getOrElse(10)

  /** Validates issue maps in file and returns seq of ConnectInfoValue
    *
    * @param issueMapCsv
    *   file with issue maps (Local - Remote)
    * @param relation
    *   connection
    * @return
    *   Try[Seq[ConnectInfoValue]]
    */
  override def validateAndGetIssueMap(
      issueMapCsv: File,
      relation: IConnection,
      entityType: Option[String]
  ): Stream[Future[SimplePage[ConnectInfoValue]]] =
    readCsvRecords(issueMapCsv) match {
      case Failure(exception) => Stream(Future.failed(exception))
      case Success(records)   => validateAndGetIssueMap(records, relation, entityType)
    }

  /** Validates issue maps and returns seq of ConnectInfoValue
    *
    * @param issueMapCsv
    *   text with issue maps (Local - Remote)
    * @param relation
    *   connection
    * @return
    *   Try[Seq[ConnectInfoValue]]
    */
  def validateAndGetIssueMap(
      issueMapCsv: String,
      relation: IConnection,
      entityType: Option[String]
  ): Stream[Future[SimplePage[ConnectInfoValue]]] =
    readCsvRecords(issueMapCsv) match {
      case Failure(exception) => Stream(Future.failed(exception))
      case Success(records)   => validateAndGetIssueMap(records, relation, entityType)
    }

  /** Reads provided file and returns `Seq[CSVRecord]`
    *
    * @param issueMapCsv
    *   file to read
    * @return
    *   Try[Seq[CSVRecord]]
    */
  private def readCsvRecords(issueMapCsv: File): Try[Seq[CSVRecord]] =
    Try(CSVParser.parse(issueMapCsv, Charset.defaultCharset(), CSVFormat.DEFAULT))
      .map(_.getRecords.asScala.toSeq)
      .recoverWith {
        case failure: IOException => Failure(CsvValidationException(ReadingError))
      }

  /** Parse provided string value and returns `Seq[CSVRecord]`
    *
    * @param issueMapCsv
    *   text to read
    * @return
    *   Try[Seq[CSVRecord]]
    */
  private def readCsvRecords(issueMapCsv: String): Try[Seq[CSVRecord]] =
    Try(CSVParser.parse(issueMapCsv, CSVFormat.DEFAULT))
      .map(_.getRecords.asScala.toSeq)
      .recoverWith {
        case failure: IOException => Failure(CsvValidationException(ReadingError))
      }

  /** Validates seq of CSVRecord And Gets Issue Map as ConnectInfoValue
    *
    * @param records
    * @param relation
    * @return
    *   Try[Seq[ConnectInfoValue]]
    */
  private def validateAndGetIssueMap(
      records: Seq[CSVRecord],
      relation: IConnection,
      entityTypeOpt: Option[String]
  ): Stream[Future[SimplePage[ConnectInfoValue]]] = {
    val total = records.size
    PaginationUtil.paginationSimplePageInfStream(
      CONNECT_INFO_NUM_PER_PAGE,
      { pageRequest =>
        val page = records
          .slice(pageRequest.offset.toInt, pageRequest.offset.toInt + pageRequest.limit)
          .foldLeft((Try(Seq.empty[ConnectInfoValue]), Seq.empty[CSVRecord])) { (result, r) =>
            result match {
              case (Success(values), visited) =>
                (
                  validateAndGetIssueUrnTuple(r, visited, relation, entityTypeOpt).map(x =>
                    values :+ x
                  ),
                  visited :+ r
                )

              case (Failure(error), visited) =>
                (Failure(error), visited)
            }
          }
          ._1

        Future.fromTry(page.map { p =>
          val isLast = pageRequest.offset + pageRequest.limit >= total
          SimplePage(p, isLast)
        })
      }
    )
  }

  /** Gets CSVRecord, validates values and return ConnectInfoValue
    *
    * @param record
    *   CSVRecord
    * @param visitedRecords
    *   Seq[CSVRecord]
    * @param relation
    *   connection
    * @return
    *   Try[ConnectInfoValue]
    */
  private def validateAndGetIssueUrnTuple(
      record: CSVRecord,
      visitedRecords: Seq[CSVRecord],
      relation: IConnection,
      entityTypeOpt: Option[String]
  ): Try[ConnectInfoValue] =
    for {
      validateHasNotEnoughMembers <- validateHasNotEnoughMembers(record)
      localIssueUrn = getLocalIssueUrn(record)
      validateHasEmptyLocalIssueUrn <- validateHasEmptyIssueUrn(
        record,
        localIssueUrn,
        MissedLocalUrn
      )
      remoteIssueUrn = getRemoteIssueUrn(record)
      validateHasEmptyRemoteIssueUrn <- validateHasEmptyIssueUrn(
        record,
        remoteIssueUrn,
        MissedRemoteUrn
      )
      validateHasDuplicateLocalIssueUrn <- validateHasDuplicateLocalIssueUrn(
        record,
        visitedRecords,
        localIssueUrn
      )
      (issueKeyValue, hubPayloadOpt) <- getLocalIssueKeyByUrn(
        record,
        localIssueUrn,
        relation,
        entityTypeOpt
      )
    } yield ConnectInfoValue(issueKeyValue, remoteIssueUrn, hubPayloadOpt)

  /** Checks whether provided CSVRecord has enough members
    *
    * @param record
    *   CSVRecord
    * @return
    *   Try[None.type] or Failure
    */
  private def validateHasNotEnoughMembers(record: CSVRecord): Try[None.type] =
    if (!hasEnoughMembers(record)) {
      val recordNumberStr = getRecordNumberString(record)
      val recordStr = getRecordString(record)
      Failure(CsvValidationException(MissedMember, Some(recordNumberStr), Some(recordStr)))
    } else {
      Success(None)
    }

  /** Checks whether provided CSVRecord has an Empty Issue Urn
    *
    * @param record
    *   CSVRecord
    * @param issueUrn
    *   issue Urn
    * @param error
    *   CsvValidationError for Failure
    * @return
    */
  private def validateHasEmptyIssueUrn(
      record: CSVRecord,
      issueUrn: String,
      error: CsvValidationError
  ): Try[None.type] =
    if (issueUrn.isEmpty) {
      val recordNumberStr = getRecordNumberString(record)
      val recordStr = getRecordString(record)
      Failure(CsvValidationException(error, Some(recordNumberStr), Some(recordStr)))
    } else {
      Success(None)
    }

  /** Checks whether provided CSVRecord has a Duplication of Local Issue Urn
    *
    * @param record
    *   CSVRecord
    * @param visitedRecords
    *   Seq[CSVRecord]
    * @param localIssueUrn
    *   urn of local issue
    * @return
    *   Try[None.type]
    */
  private def validateHasDuplicateLocalIssueUrn(
      record: CSVRecord,
      visitedRecords: Seq[CSVRecord],
      localIssueUrn: String
  ): Try[None.type] =
    visitedRecords.find { r =>
      hasEnoughMembers(r) && getLocalIssueUrn(r).equalsIgnoreCase(localIssueUrn)
    } match {
      case Some(x) =>
        val recordNumberStr = getRecordNumberString(record)
        val visitedRecordNumberStr = getRecordNumberString(x)
        val recordStr = getRecordString(record)
        val visitedRecordStr = getRecordString(x)
        Failure(
          CsvValidationException(
            DuplicateLocalIssueUrn,
            Some(recordNumberStr),
            Some(recordStr),
            Some(visitedRecordNumberStr),
            Some(visitedRecordStr)
          )
        )
      case None    =>
        Success(None)
    }

  /** Gets local issue key by provided urn
    *
    * @param record
    *   CSVRecord
    * @param localIssueUrn
    *   urn of local issue
    * @param relation
    *   connection
    * @return
    *   issue key value
    */
  private def getLocalIssueKeyByUrn(
      record: CSVRecord,
      localIssueUrn: String,
      relation: IConnection,
      entityTypeOpt: Option[String]
  ): Try[(IssueKeyValue, Option[IHubPayload])] = {
    val entityType = entityTypeOpt.getOrElse("issue")
    val issueKeyAndFieldValues =
      trackerHubObjectService.getIssueKeyAndFieldValuesForConnect(localIssueUrn)
    val inf = FutureUtils.resultInf(
      trackerHubObjectService.getLocalKeyAndHubPayloadFromTracker(
        issueKeyAndFieldValues._1,
        relation,
        entityType,
        issueKeyAndFieldValues._2
      )
    )

    inf match {
      case (Some(issueKey), hubPayloadOpt) =>
        Success((IssueKeyValue.convert(issueKey), hubPayloadOpt))
      case _                               =>
        val recordNumberStr = getRecordNumberString(record)
        val recordStr = getRecordString(record)
        Failure(CsvValidationException(LocalIssueNotFound, Some(recordNumberStr), Some(recordStr)))
    }
  }

  private def hasEnoughMembers(record: CSVRecord): Boolean =
    record.size() >= 2

  private def getRecordNumberString(record: CSVRecord): String =
    record.getRecordNumber.toString

  private def getRecordString(record: CSVRecord): String =
    StringUtils.join(record.iterator(), ",")

  private def getRemoteIssueUrn(record: CSVRecord): String =
    record.get(1).trim

  private def getLocalIssueUrn(record: CSVRecord): String =
    record.get(0).trim

}

sealed trait CsvValidationError

object ReadingError extends CsvValidationError

object DuplicateLocalIssueUrn extends CsvValidationError

object MissedMember extends CsvValidationError

object MissedLocalUrn extends CsvValidationError

object MissedRemoteUrn extends CsvValidationError

object LocalIssueNotFound extends CsvValidationError

case class CsvValidationException(
    error: CsvValidationError,
    recordNumberStr: Option[String] = None,
    recordStr: Option[String] = None,
    visitedRecordNumberStr: Option[String] = None,
    visitedRecordStr: Option[String] = None
) extends Exception {}
