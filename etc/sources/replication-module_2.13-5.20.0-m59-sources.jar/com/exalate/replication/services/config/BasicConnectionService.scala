package com.exalate.replication.services.config

import com.exalate.api.ILoggingService
import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.connection.fieldvalues.ConnectionMode
import com.exalate.api.domain.editor.scopes.{SyncCriteria, TriggerCriteria}
import com.exalate.domain.editor.mappings.{Arrow, FieldValue, MappingFieldTypeValue, MappingValue}
import com.exalate.domain.editor.scopes
import com.exalate.domain.editor.scopes.{
  ScopeValue,
  SingleSideScopeValue,
  SyncCriteriaValue,
  TriggerCriteriaValue
}
import com.exalate.domain.transport.trackeroptions.EditorFields
import com.exalate.domain.values.VisualFieldValue
import com.exalate.domain.values.connection.MainFieldInfoValue
import com.exalate.replication.services.api.config.IBasicConnectionService
import com.exalate.replication.services.api.editor.IEditorParamsService
import com.exalate.replication.services.api.issuetracker.IIssueTrackerBasicNonEditorValueService
import com.exalate.replication.services.transport.v1.rest.NodeInfoProvider
import com.google.inject.Inject
import play.api.libs.json.Json

import scala.concurrent.{ExecutionContext, Future}

class BasicConnectionService @Inject() (
    nodeInfoProvider: NodeInfoProvider,
    loggingService: ILoggingService,
    editorParamsService: IEditorParamsService,
    issueTrackerBasicNonEditorValueService: IIssueTrackerBasicNonEditorValueService
)(implicit ec: ExecutionContext)
    extends IBasicConnectionService {

  override def generateDefaultScopeRules(connection: IConnection): Future[Option[Seq[ScopeValue]]] = {
    loggingService.info(
      s"Generating default scope value for basic connection `${connection.getName}`"
    )
    val mainFieldInfoValueOpt =
      Option(connection.getSyncMainFieldInfo).flatMap(mainFieldInfoValue =>
        Json.parse(mainFieldInfoValue).asOpt[MainFieldInfoValue]
      )

    val localRemote = mainFieldInfoValueOpt match {
      case Some(mainFieldInfoValue) =>
        val local = mainFieldInfoValue.local
          .map(_.map { singleSide =>
            com.exalate.domain.editor.scopes.FieldValue(singleSide.key, None, Some(singleSide.value))
          })
          .getOrElse(Seq.empty[scopes.FieldValue])
        val remote = mainFieldInfoValue.remote
          .map(_.map { singleSide =>
            com.exalate.domain.editor.scopes.FieldValue(singleSide.key, None, Some(singleSide.value))
          })
          .getOrElse(Seq.empty[scopes.FieldValue])
        (local, remote)
      case _                        => (Seq.empty[scopes.FieldValue], Seq.empty[scopes.FieldValue])

    }

    val localScope = SingleSideScopeValue(
      scopeUid = None,
      mainFields = localRemote._1,
      syncCriteria = Some(SyncCriteriaValue(SyncCriteria.ALL, None)),
      triggerCriteria = Some(TriggerCriteriaValue(TriggerCriteria.MANUAL)),
      script = None
    )
    val remoteScope = SingleSideScopeValue(
      scopeUid = None,
      mainFields = localRemote._2,
      syncCriteria = Some(SyncCriteriaValue(SyncCriteria.ALL, None)),
      triggerCriteria = Some(TriggerCriteriaValue(TriggerCriteria.MANUAL)),
      script = None
    )
    Future.successful(Some(Seq(ScopeValue(localScope, remoteScope))))
  }

  override def generateDefaultMappingRules(
      connection: IConnection,
      scopeValueOptSeq: Option[Seq[ScopeValue]] = None
  ): Future[Option[Seq[MappingValue]]] = {
    loggingService.info(
      s"Generating default mapping value for basic connection `${connection.getName}`"
    )
    if (scopeValueOptSeq.isDefined) {
      editorParamsService.getMappingsValueForSuggestions(
        connection,
        scopeValueOptSeq.get,
        Some(ConnectionMode.BASIC.toString)
      )
    } else {
      nodeInfoProvider.get.flatMap { nodeInfoValue =>
        nodeInfoValue.editor match {
          case None              =>
            issueTrackerBasicNonEditorValueService.get().map {
              case Some(value) =>
                Option(formMappings(value))
              case None        =>
                loggingService.error(
                  s"Got a request to generate mapping rules, but there is no supported fields"
                )
                None
            }
          case Some(editorValue) =>
            val mappingEditorField = formMappings(editorValue)
            Future.successful(Option(mappingEditorField))
        }
      }
    }
  }

  private def formMappings(editorValue: VisualFieldValue): Seq[MappingValue] = {
    val fields = editorValue.editorFields
    val mappingEditorField = fields
      .filterNot(f => f.main.contains(true))
      .filter(f =>
        f.key.equals(EditorFields.ISSUE_TYPE.toString)
          || f.key.equals(EditorFields.SUMMARY.toString)
          || f.key.equals(EditorFields.DESCRIPTION.toString)
          || f.key.equals(EditorFields.COMMENTS.toString)
          || f.key.equals(EditorFields.ATTACHMENTS.toString)
      )
      .foldLeft(Seq.empty[MappingValue]) {
        case (accum, next) =>
          val key = next.key
          val (recoveryLocal, recoveryRemote) = (None, None)
          val (filterLocal, filterRemote) = (None, None)
          val fieldValue = FieldValue(key, "???")
          val local = MappingFieldTypeValue(fieldValue, recoveryLocal, filterLocal, None)
          val remote = MappingFieldTypeValue(fieldValue, recoveryRemote, filterRemote, None)
          val mappingValue =
            MappingValue(None, Some(local), Some(Arrow.LR.toString), None, Some(remote), None)
          accum :+ mappingValue
      }
    mappingEditorField
  }

}
