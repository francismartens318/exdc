package com.exalate.replication.services.config

import com.exalate.api.domain.connection.IConnection
import com.exalate.domain.editor.mappings.MappingValue
import com.exalate.domain.editor.scopes.ScopeValue
import com.exalate.replication.services.api.config.ITrackerExtraLogicService

import scala.concurrent.Future

class DefaultTrackerExtraLogicService extends ITrackerExtraLogicService {

  override def afterCreateConnection(
      connection: IConnection,
      fieldValues: Option[java.util.Map[String, String]] = None
  ): Future[None.type] =
    Future.successful(None)

  override def afterUpdateConnection(connection: IConnection): Future[None.type] =
    Future.successful(None)

  override def afterPublish(
      connection: IConnection,
      scopes: Seq[ScopeValue],
      mappings: Seq[MappingValue]
  ): Future[None.type] =
    Future.successful(None)

}
