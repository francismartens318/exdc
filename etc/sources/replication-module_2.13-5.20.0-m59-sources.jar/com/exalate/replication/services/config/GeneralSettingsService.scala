package com.exalate.replication.services.config

import com.exalate.api.persistence.issuetracker.IGeneralSettingsRepository
import com.exalate.domain.values.v4.GeneralSettingsJson
import com.exalate.domain.{GeneralSettings, InferredGeneralSettings}
import com.exalate.replication.services.api.config.IGeneralSettingsService
import com.exalate.util.Encryptor
import com.google.inject.Inject
import play.api.libs.json.{JsString, JsValue}

import scala.concurrent.Future

class GeneralSettingsService @Inject() (generalSettingsRepository: IGeneralSettingsRepository)
    extends IGeneralSettingsService {

  /** Gets general setting from DB - GeneralSettingsTable
    * @return
    *   Future[Option[InferredGeneralSettings]]
    */
  override def get: Future[Option[InferredGeneralSettings]] = generalSettingsRepository.get()

  override def upsert(generalSettingsVal: GeneralSettings): Future[GeneralSettings] =
    generalSettingsRepository.upsert(generalSettingsVal)

  override def delete: Future[None.type] = generalSettingsRepository.delete

  override def getExtraGSFieldsWithValues(
      allGsFieldValues: Map[String, String],
      generalSettingsJson: GeneralSettingsJson
  ): Map[String, Map[String, JsValue]] =
    generalSettingsJson.fieldValues.foldLeft(Map.empty[String, Map[String, JsValue]]) {
      (m, field) =>
        allGsFieldValues
          .get(field._1)
          .map { value =>
            val decryptedVal = if (field._2.get("decrypt").exists(_.as[Boolean])) null else value
            val allValues: Map[String, JsValue] = field._2 + ("value" -> JsString(decryptedVal))
            m + (field._1 -> allValues)
          }
          .getOrElse(m)
    }

}
