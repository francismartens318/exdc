package com.exalate.replication.services.api.replication.impersonation

import com.exalate.api.domain.auditlog.IAuditLog
import com.exalate.api.domain.webhook.{INonPersistentWebhookInfo, IWebhookInfo, WebhookEntityType}
import com.exalate.generic.services.{FullAuditInfo, PartialAuditInfo}
import com.exalate.replication.services.replication.impersonation.AuditLogService
import com.google.inject.ImplementedBy

import scala.concurrent.Future

@ImplementedBy(classOf[AuditLogService])
trait IAuditLogService {

  def createAuditLog(issueId: Option[String], webhookType: WebhookEntityType)(
      userKey: String
  ): IAuditLog

  /** Update the partial audit log with the entity id and the json so now is a full audit log.
    */
  def updateAuditLog(
      auditLogOpt: Option[IAuditLog],
      issueId: String,
      entityId: String,
      entityJsonStr: String
  ): Unit

  def delete(auditLogId: Int): Future[None.type]

  def getFor(webhookInfo: IWebhookInfo): Future[(Option[FullAuditInfo], Seq[PartialAuditInfo])]

  /** returns any kind of audit info related to the webhook info.
    * @return
    *   A future containing option of the full audit info and all partial audit info.
    */
  def getFor(
      webhookInfo: INonPersistentWebhookInfo
  ): Future[(Option[FullAuditInfo], Seq[PartialAuditInfo])]

  def deleteAllPartialAuditLogs(): Future[None.type]

}
