package com.exalate.replication.services.api.replication.in

import com.google.inject.ImplementedBy

import scala.concurrent.Future

@ImplementedBy(classOf[com.exalate.replication.services.replication.in.RequestProcessorService])
trait IRequestProcessorService {
  def processSyncRequests(): Future[Unit]
}
