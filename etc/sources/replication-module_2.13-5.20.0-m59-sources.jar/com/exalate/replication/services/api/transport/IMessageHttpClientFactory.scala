package com.exalate.replication.services.api.transport

import com.exalate.api.domain.instance.IInstance
import com.exalate.replication.services.transport.MessageHttpClientFactory
import com.exalate.replication.services.transport.v1.rest.IMessageHttpClient
import com.google.inject.ImplementedBy

import scala.util.Try

@ImplementedBy(classOf[MessageHttpClientFactory])
trait IMessageHttpClientFactory {

  def get(remoteInstance: IInstance): IMessageHttpClient
}
