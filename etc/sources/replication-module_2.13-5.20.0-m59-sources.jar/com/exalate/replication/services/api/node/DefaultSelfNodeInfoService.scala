package com.exalate.replication.services.api.node

import com.google.inject.Inject
import play.api.Configuration

class DefaultSelfNodeInfoService @Inject() (configuration: Configuration)
    extends ISelfNodeInfoService {

  def getMaxHubObjectVersion = configuration.get[String]("node.max.hub.version")
  def getMinHubObjectVersion = configuration.get[String]("node.min.hub.version")
  def getMaxRestVersion = configuration.get[String]("node.max.rest.version")
  def getMinRestVersion = configuration.get[String]("node.min.rest.version")
  def isPollOnly: Boolean = false
}
