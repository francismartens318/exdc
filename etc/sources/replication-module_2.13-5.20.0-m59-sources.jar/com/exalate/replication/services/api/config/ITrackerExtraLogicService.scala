package com.exalate.replication.services.api.config

import com.exalate.api.domain.connection.IConnection
import com.exalate.domain.editor.mappings.MappingValue
import com.exalate.domain.editor.scopes.ScopeValue
import com.exalate.replication.services.config.DefaultTrackerExtraLogicService
import com.google.inject.ImplementedBy

import scala.concurrent.Future

/** Trait used to do extra logic after connection created/published. For example, in Adnode webhooks
  * are created in the implementation.
  */
@ImplementedBy(classOf[DefaultTrackerExtraLogicService])
trait ITrackerExtraLogicService {

  /** Executes extra logic needed specifically for a node, after creating a new connection
    * @param connection
    * @return
    */
  def afterCreateConnection(
      connection: IConnection,
      fieldValues: Option[java.util.Map[String, String]] = None
  ): Future[None.type]

  def afterUpdateConnection(connection: IConnection): Future[None.type]

  /** Executes extra logic needed specifically for a node, after publishing connection draft.
    * Direction from scopes and mappings should already be swapped into the correct one.
    * @param connection
    * @param scopes
    * @param mappings
    * @return
    */
  def afterPublish(
      connection: IConnection,
      scopes: Seq[ScopeValue],
      mappings: Seq[MappingValue]
  ): Future[None.type]

}
