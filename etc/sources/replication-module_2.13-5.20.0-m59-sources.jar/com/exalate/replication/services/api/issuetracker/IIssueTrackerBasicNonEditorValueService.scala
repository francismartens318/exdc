package com.exalate.replication.services.api.issuetracker

import com.exalate.domain.values.{FeatureValue, VisualFieldValue}
import com.google.inject.ImplementedBy

import scala.concurrent.Future

/** Service that substitutes IIssueTrackerEditorValueService. It is needed for Basic connection
  * where node does not support Visual rules. Service generates a minimum list of fields to
  * visualize it on Basic connection.
  */
@ImplementedBy(
  classOf[com.exalate.replication.services.issuetracker.NopIssueTrackerBasicNonEditorValueService]
)
trait IIssueTrackerBasicNonEditorValueService {

  /** Provide Visual Field value, which consists of list of system field with corresponding
    * specification, namely: * key of field: EditorFields.PROJECT.toString; * label: "Project"; *
    * queryable: Some(false); * main: Some(true); * map of type: FieldDataType.OPTION.toString; *
    * seq of operators
    */
  def get(): Future[Option[VisualFieldValue]]
}
