package com.exalate.replication.services.api.issuetracker.script

import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.hubobject.IHubIssueReplica
import com.exalate.domain.editor.mappings.Mappings
import com.exalate.domain.exception.editor.RecoveryMappingEditorException
import com.google.inject.ImplementedBy

@ImplementedBy(classOf[com.exalate.replication.services.script.ExalateHelper])
trait IExalateHelper {
  def scheduleExalateOrUpdateEvent(connection: IConnection, issue: IHubIssueReplica): Unit

  def getRecoveryMappingEditorException(
      mappings: Mappings,
      swapSides: Boolean,
      recoveryValueAsString: String
  ): RecoveryMappingEditorException

}
