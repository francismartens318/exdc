package com.exalate.replication.services.api.transport

import akka.stream.scaladsl.Source
import akka.util.ByteString
import com.exalate.api.domain.IIssueKey
import com.exalate.api.domain.blob.event.IBlobEvent
import com.exalate.api.domain.blob.request.IBlobRequest
import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.event.ISyncEvent
import com.exalate.api.domain.license.ISubscriptionContext
import com.exalate.api.domain.request.ISyncRequest
import com.exalate.api.domain.twintrace.ITrace
import com.exalate.domain.replication.BasicSyncRequest

import scala.concurrent.Future

trait ITransportService {

  def sendSyncRequest(
      syncEvent: ISyncEvent,
      subscriptionContext: ISubscriptionContext
  ): Future[None.type]

  def publishBlob(blobEvent: IBlobEvent, source: Source[ByteString, _]): Future[None.type]

  /** Send a sync response.
    */
  def sendSyncResponse(
      basicSyncRequest: BasicSyncRequest,
      traces: Seq[ITrace],
      connection: IConnection,
      twinTraceIdOpt: Option[Int]
  ): Future[None.type]

  @deprecated(
    "Will be removed in favor of `sendErrorResponse(basicSyncRequest: BasicSyncRequest ...)`",
    "EXACOMP-1884"
  )
  def sendErrorResponse(syncRequest: ISyncRequest): Future[None.type]

  /** Send an error response.
    */
  def sendErrorResponse(
      basicSyncRequest: BasicSyncRequest,
      connection: IConnection
  ): Future[None.type]

  def sendBlobErrorResponse(blobRequest: IBlobRequest): Future[None.type]
  def sendBlobRequest(blobEvent: IBlobEvent): Future[None.type]
  def sendBlobResponse(blobRequest: IBlobRequest): Future[None.type]
  def receiveBlob(blobRequest: IBlobRequest): Future[Option[Source[ByteString, _]]]

  @deprecated(
    "Will be removed in favor of `postRequestReceived(basicSyncRequest: BasicSyncRequest ...)`",
    "EXACOMP-1884"
  )
  def postRequestReceived(syncRequest: ISyncRequest): Future[None.type]

  /** Send the request received notification.
    */
  def postRequestReceived(
      basicSyncRequest: BasicSyncRequest,
      connection: IConnection
  ): Future[None.type]

  def getRemoteIssueUrl(issueKey: IIssueKey, connection: IConnection): Future[Option[String]]
  def postResponseReceived(syncEvent: ISyncEvent): Future[None.type]
  def postBlobRequestReceived(blobRequest: IBlobRequest): Future[None.type]
  def postBlobResponseReceived(blobEvent: IBlobEvent): Future[None.type]
}
