package com.exalate.replication.services.api.node.storeblob

import akka.stream.scaladsl.Source
import akka.util.ByteString
import com.exalate.api.domain.IBlobMetadata
import com.exalate.domain.node.storeblob.{CloudStoredBlobMetaData, StoredBlobMetaData}

import scala.concurrent.Future

/** Is used to stream the blobs (attachments) from remote Exalate and into a storage (can be either
  * filesystem or S3-compatible API)
  */
trait IStoreBlobService {

  /** put the file into storage
    */
  def storeBlob(name: String, source: Source[ByteString, _]): Future[StoredBlobMetaData]

  /** get input stream of a stored blob
    */
  def retrieveBlob(storedBlobMetaData: StoredBlobMetaData): Future[Option[Source[ByteString, _]]]

  /** delete the blob from storage
    */
  def deleteBlob(storedBlobMetaData: StoredBlobMetaData): Future[Unit]

  /** calculate checksum of a file within storage
    */
  def getChecksum(storedBlobMetaData: StoredBlobMetaData): Future[ChecksumInfo]
}
