package com.exalate.replication.services.api.processor

import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.hubobject.IHubIssueReplica
import com.exalate.api.domain.request.ISyncRequest
import com.exalate.api.domain.twintrace.INonPersistentTrace
import com.exalate.api.domain.{IBlobMetadata, IIssueKey}
import com.exalate.basic.domain.hubobject.v1.BasicHubIssue
import com.exalate.domain.editor.mappings.Mappings
import com.google.inject.ImplementedBy

import java.util
import scala.concurrent.Future

/** Service which forms variables for script execution in Exalate. is used to form script context
  * before script execution and to re-create it after every store() closure call
  */
@ImplementedBy(classOf[com.exalate.replication.services.processor.ScriptVariableService])
trait IScriptVariableService {

  def createOutgoingSyncContext(
      connection: IConnection,
      issue: IHubIssueReplica,
      replica: BasicHubIssue,
      localIssueKey: IIssueKey,
      syncRequestOpt: Option[ISyncRequest],
      log: org.slf4j.Logger,
      isAIScript: Boolean = false
  ): util.HashMap[String, Object]

  def createIncomingSyncContext(
      replica: BasicHubIssue,
      firstSync: Boolean,
      connection: IConnection,
      syncRequest: ISyncRequest,
      prevOpt: Option[IHubIssueReplica],
      remoteEntityUrlOpt: Option[String],
      localIssueKey: Option[IIssueKey],
      blobMetadataSeq: Seq[IBlobMetadata],
      fieldTraces: Seq[INonPersistentTrace],
      log: org.slf4j.Logger,
      isAIScript: Boolean = false
  ): Future[java.util.Map[String, Object]]

  def updateIncomingSyncContext(
      context: java.util.Map[String, Object],
      connection: IConnection,
      issue: BasicHubIssue,
      replica: BasicHubIssue,
      mapping: Mappings,
      swapSides: Boolean,
      sendingInstanceName: String,
      receivingInstanceName: String
  ): java.util.Map[String, Object] = context

}
