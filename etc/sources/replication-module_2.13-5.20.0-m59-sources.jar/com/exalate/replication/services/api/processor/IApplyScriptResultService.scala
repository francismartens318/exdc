package com.exalate.replication.services.api.processor

import java.util

import com.exalate.api.domain.{IBlobMetadata, IIssueKey}
import com.exalate.api.domain.hubobject.IHubIssueReplica
import com.exalate.api.domain.request.ISyncRequest
import com.exalate.api.domain.twintrace.INonPersistentTrace
import com.google.inject.ImplementedBy

import scala.concurrent.Future
import scala.util.Try

/** Is used by the processor classes to apply the "issue / ticket / workItem / defect / entity"
  * variable to the issue tracker
  */
@ImplementedBy(classOf[com.exalate.replication.services.processor.ApplyScriptResultService])
trait IApplyScriptResultService {

  def createEntity(
      syncRequest: ISyncRequest,
      blobMetadataSeq: Seq[IBlobMetadata],
      issueBeforeUpdating: IHubIssueReplica,
      issue: IHubIssueReplica,
      customHttpHeaders: Seq[(String, String)] = Nil
  ): Future[(IIssueKey, Seq[INonPersistentTrace])]

  def updateEntity(
      syncRequest: ISyncRequest,
      context: util.HashMap[String, Object],
      localIssueKey: IIssueKey,
      traces: util.List[INonPersistentTrace],
      issue: IHubIssueReplica,
      issueBeforeUpdating: IHubIssueReplica,
      blobMetadataSeq: Seq[IBlobMetadata],
      customHttpHeaders: Seq[(String, String)] = Nil
  ): Future[Seq[INonPersistentTrace]]

  def getModifiedEntity(
      entitiesBefore: Seq[IHubIssueReplica],
      entitiesAfter: Seq[IHubIssueReplica]
  ): Try[Option[IHubIssueReplica]]

}
