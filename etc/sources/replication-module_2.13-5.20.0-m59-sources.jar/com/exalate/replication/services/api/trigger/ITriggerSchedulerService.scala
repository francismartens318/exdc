package com.exalate.replication.services.api.trigger

import com.exalate.replication.services.replication.worker.PairEventPollerWorkerActor
import com.exalate.replication.services.trigger.{TriggerNoScheduleService, TriggerSchedulerService}
import com.google.inject.ImplementedBy

import scala.util.Try

/** Service that on app startup schedules once to send the "SchedulePairEvents"-message to the
  * [[PairEventPollerWorkerActor]] Schedule may be also added when trigger created/updated.
  *
  * There are 2 implementations: [[TriggerNoScheduleService]] - for nodes that don't support
  * polling, but have webhooks [[TriggerSchedulerService]] - for nodes that support polling If node
  * supports polling, TriggerSchedulerService should be bind in DiModule, otherwise
  * TriggerNoScheduleService would be used.
  */
@ImplementedBy(classOf[TriggerNoScheduleService])
trait ITriggerSchedulerService {
  def removeSchedule(): Try[Unit]

  def addSchedule(): Try[Unit]
}
