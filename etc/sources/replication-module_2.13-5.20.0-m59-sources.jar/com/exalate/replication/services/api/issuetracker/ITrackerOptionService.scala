package com.exalate.replication.services.api.issuetracker

import com.exalate.domain.transport.trackeroptions.{IssueTrackerOption, IssueTrackerOptionDependency}
import com.exalate.domain.values.EditorFieldValue
import com.exalate.services.utils.pagination.Page
import com.google.inject.ImplementedBy

import scala.concurrent.Future

/** The service that handles issue tracker option extraction for different fields (like project,
  * issue type/entity type, status, priority, and different custom fields options) Each node should
  * implement this trait.
  */
@ImplementedBy(classOf[DefaultTrackerOptionService])
trait ITrackerOptionService {

  def fetchProjectOptionsStream(
      context: Option[Seq[IssueTrackerOptionDependency]] = None,
      userKey: Option[String] = None
  ): Stream[Future[Page[IssueTrackerOption]]]

  def fetchIssuetypeOptions(
      context: Option[Seq[IssueTrackerOptionDependency]] = None
  ): Stream[Future[Page[IssueTrackerOption]]]

  def fetchStatusOptions(
      context: Option[Seq[IssueTrackerOptionDependency]] = None
  ): Stream[Future[Page[IssueTrackerOption]]]

  def fetchPriorityOptions(
      context: Option[Seq[IssueTrackerOptionDependency]] = None
  ): Stream[Future[Page[IssueTrackerOption]]]

  def fetchCustomFieldOptions(
      editorFieldValue: EditorFieldValue,
      context: Option[Seq[IssueTrackerOptionDependency]] = None
  ): Stream[Future[Page[IssueTrackerOption]]]

  def fetchCustomFieldOptionsWithDependencies(
      editorFieldValue: EditorFieldValue
  ): Stream[Future[Page[IssueTrackerOption]]] =
    fetchCustomFieldOptions(editorFieldValue, None)

}
