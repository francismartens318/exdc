package com.exalate.replication.services.api.issuetracker

import com.exalate.replication.services.issuetracker.DefaultInstanceNameService
import com.google.inject.ImplementedBy

import scala.concurrent.Future

/** Service which extract name from the issue tracker url. For example: https://support.idalko.com/
  * -> the output will be "support" (Each node should implement this trait.)
  */
@ImplementedBy(classOf[DefaultInstanceNameService])
trait IInstanceNameService {
  def generateLocalInstanceName(): Future[String]
}
