package com.exalate.replication.services.api.error

import com.exalate.api.domain.IIssueKey
import com.exalate.api.domain.blob.event.IBlobEvent
import com.exalate.api.domain.blob.request.IBlobRequest
import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.event.ISyncEvent
import com.exalate.api.domain.request.ISyncRequest
import com.exalate.api.domain.trigger.ITrigger
import com.exalate.domain.replication.BasicSyncRequest

case class SyncContext(
    syncEventIdOpt: Option[Int] = None,
    syncEventNumberOpt: Option[Long] = None,
    connection: Option[IConnection] = None,
    triggerOpt: Option[ITrigger] = None,
    relationNameOpt: Option[String] = None,
    localIssueKeyOpt: Option[IIssueKey] = None,
    remoteIssueKeyOpt: Option[IIssueKey] = None,
    syncEventOpt: Option[ISyncEvent] = None,
    syncRequestOpt: Option[ISyncRequest] = None,
    basicSyncRequestOpt: Option[BasicSyncRequest] = None,
    blobEventOpt: Option[IBlobEvent] = None,
    blobRequestOpt: Option[IBlobRequest] = None
)

object SyncContext {

  def createWithSyncEvent(syncEvent: ISyncEvent): SyncContext = {
    val connection = syncEvent.getConnection
    val localIssueKeyOpt = Option(syncEvent.getLocalReplica).map(_.getIssueKey)
    val remoteIssueKeyOpt = Option(syncEvent.getRemoteReplica).map(_.getIssueKey)
    SyncContext(
      connection = Some(connection),
      syncEventOpt = Some(syncEvent),
      localIssueKeyOpt = localIssueKeyOpt,
      remoteIssueKeyOpt = remoteIssueKeyOpt
    )
  }

  def createWithSyncRequest(relation: IConnection, syncRequest: ISyncRequest): SyncContext = {
    val remoteIssueKeyOpt = Option(syncRequest.getReplica).map(_.getIssueKey)
    val localIssueKeyOpt = Option(syncRequest.getSyncedTo)
    SyncContext(
      connection = Some(relation),
      syncRequestOpt = Some(syncRequest),
      localIssueKeyOpt = localIssueKeyOpt,
      remoteIssueKeyOpt = remoteIssueKeyOpt
    )
  }

  def createWithBasicSyncRequest(
      connection: IConnection,
      basicSyncRequest: BasicSyncRequest
  ): SyncContext = {
    val remoteIssueKey = basicSyncRequest.replica.getIssueKey
    val localIssueKeyOpt = basicSyncRequest.syncedTo
    SyncContext(
      connection = Some(connection),
      basicSyncRequestOpt = Some(basicSyncRequest),
      localIssueKeyOpt = localIssueKeyOpt,
      remoteIssueKeyOpt = Some(remoteIssueKey)
    )
  }

  def createWithBlobEvent(blobEvent: IBlobEvent): SyncContext = {
    val syncEvent = blobEvent.getSyncEvent
    val connection = syncEvent.getConnection
    val localIssueKeyOpt = Option(syncEvent.getLocalReplica).map(_.getIssueKey)
    val remoteIssueKeyOpt = Option(syncEvent.getRemoteReplica).map(_.getIssueKey)
    SyncContext(
      connection = Some(connection),
      blobEventOpt = Some(blobEvent),
      localIssueKeyOpt = localIssueKeyOpt,
      remoteIssueKeyOpt = remoteIssueKeyOpt
    )
  }

  def createWithBlobRequest(relation: IConnection, blobRequest: IBlobRequest): SyncContext = {
    val syncRequest = blobRequest.getSyncRequest
    val remoteIssueKeyOpt = Option(syncRequest.getReplica).map(_.getIssueKey)
    val localIssueKeyOpt = Option(syncRequest.getSyncedTo)
    SyncContext(
      connection = Some(relation),
      blobRequestOpt = Some(blobRequest),
      localIssueKeyOpt = localIssueKeyOpt,
      remoteIssueKeyOpt = remoteIssueKeyOpt
    )
  }

}
