package com.exalate.replication.services.api.transport

import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.{INonPersistentReplica, IPersistentReplica}
import com.exalate.replication.services.transport.value.ReplicaValue
import com.exalate.replication.services.transport.value.helpers.ReplicaValueHelper
import com.google.inject.ImplementedBy

import scala.util.Try

@ImplementedBy(classOf[ReplicaValueHelper])
trait IReplicaValueHelper {
  def toReplica(replicaValue: ReplicaValue, relation: IConnection): Try[INonPersistentReplica]
  def toReplicaValue(replica: IPersistentReplica, relation: IConnection): Try[ReplicaValue]
}
