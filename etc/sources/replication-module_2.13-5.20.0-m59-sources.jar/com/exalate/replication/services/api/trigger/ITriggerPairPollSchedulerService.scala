package com.exalate.replication.services.api.trigger

import java.util.Date

import scala.concurrent.Future

/** Service that polls for Pair Exalate Events. It runs per trigger, preparing trigger query if
  * needed. (for example snow appends to the query date when the trigger was created, to ensure only
  * entities that were created after the trigger creation would be included).
  */
trait ITriggerPairPollSchedulerService {

  def pollAndSchedule(triggerId: Int, lastPairPollingDateOrCreation: Date): Future[None.type]

}
