package com.exalate.replication.services.api.issuetracker

import com.exalate.api.domain.instance.IInstance
import com.exalate.basic.domain.instance.Instance
import com.exalate.domain.values.{EditorFieldValue, NodeInfoValue}

import scala.concurrent.Future

/** Service responsible of providing local or remote Editor Field values
  */
trait IInstanceEditorFieldService {

  def getRemoteEditorFieldValues(instance: IInstance): Seq[EditorFieldValue]

  def getLocalEditorFieldValues(): Future[Seq[EditorFieldValue]]

  def getLocalEditorMainFieldValues(): Future[Seq[EditorFieldValue]]

  /** Returns a list of Editor Field values that are defined in node's info, thus has public access
    * @return
    */
  def getLocalPublicEditorFieldValues(): Future[Seq[EditorFieldValue]]

  /** Returns a list of Editor Field values which are not defined in node's info. In general, this
    * are custom defined fields
    * @return
    */
  def getCustomLocalEditorFieldValues(): Future[Seq[EditorFieldValue]]
}
