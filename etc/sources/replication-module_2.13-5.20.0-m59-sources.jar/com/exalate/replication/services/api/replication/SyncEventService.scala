package com.exalate.replication.services.api.replication

import com.exalate.api.domain.IIssueKey
import com.exalate.api.domain.event.ISyncEvent
import com.exalate.api.domain.connection.IConnection
import com.exalate.api.persistence.twintrace.ITwinTraceRepository
import com.google.inject.Inject

import scala.concurrent.ExecutionContext
import scala.concurrent.Future

class SyncEventService @Inject() (twinTraceRepository: ITwinTraceRepository)(implicit
    ec: ExecutionContext
) extends ISyncEventService {

  private def getRemoteIssueKeyByTwinTrace(syncEvent: ISyncEvent): Future[Option[IIssueKey]] =
    twinTraceRepository.getTwinTraceById(syncEvent.getTwinTraceId).map {
      _.flatMap(t => Option(t.getRemoteReplica)).map(_.getIssueKey)
    }

  override def getRemoteIssueKey(syncEvent: ISyncEvent): Future[Option[IIssueKey]] =
    Option(syncEvent.getRemoteReplica).map(_.getIssueKey) match {
      case Some(remoteIssueKey) => Future.successful(Some(remoteIssueKey))
      case None                 => getRemoteIssueKeyByTwinTrace(syncEvent)
    }

}
