package com.exalate.replication.services.api.transport.mapper

import java.net.URL

import com.exalate.replication.services.transport.mapper.v1.MapperExalateUrlsClient
import com.google.inject.ImplementedBy

import scala.concurrent.Future

@ImplementedBy(classOf[MapperExalateUrlsClient])
trait IMapperExalateUrlsClient {
  def getExalateUrl(issueTrackerUrl: URL): Future[URL]
}
