package com.exalate.replication.services.api.replication.scope

import com.exalate.api.domain.hubobject.IHubIssueReplica
import com.exalate.api.domain.hubobject.v1_2.{
  IHubIssueType,
  IHubPriority,
  IHubProject,
  IHubStatus,
  IHubUser
}
import com.exalate.basic.domain.hubobject.v1.BasicHubOption
import com.google.inject.ImplementedBy

import scala.concurrent.Future

@ImplementedBy(classOf[DefaultTrackerScopeAndMappingHelper])
trait ITrackerScopeAndMappingHelper {

  /** Gets object IHubProject by project id or key.
    * @param projectIdOrKey
    * @return
    *   IHubProject object or None
    */
  def getProject(projectIdOrKey: String): Future[Option[IHubProject]]

  /** Gets IHubIssueType by name that belongs to the provided project with id
    * @param name
    *   of the issue/entity type
    * @param projectId
    *   id of the project where entity type should be found
    * @return
    *   IHubIssueType object or None
    */
  def getIssueType(name: String, projectId: Option[String]): Future[Option[IHubIssueType]]

  /** Gets IHubPriority by name that belongs to the provided project with id
    * @param name
    *   of the priority
    * @param projectId
    *   id of the project where priority should be found
    * @return
    *   IHubPriority object or None
    */
  def getPriority(name: String, projectId: Option[String]): Future[Option[IHubPriority]]

  // TODO EXE-683 replace with getStatuses(name: String, projectId: Option[String]): Future[Seq[(IHubStatus, IssueTrackerOptionContext)]]
  /** Gets IHubStatus by name that belongs to the provided project with id
    * @param name
    *   of the status
    * @param projectId
    *   id of the project where status should be found
    * @param issueTypeId
    *   id of the issue/entity type where status should be found
    * @return
    *   IHubStatus object or none
    */
  def getStatus(
      name: String,
      projectId: Option[String],
      issueTypeId: Option[String]
  ): Future[Option[IHubStatus]]

  /** Gets BasicHubOption by name for the provided CF
    * @param cfId
    *   id of the required CF, if it is known
    * @param cfName
    *   name of the required CF
    * @param name
    *   of the searchable option
    * @param contextEntity
    *   holds entity id, type and other info where whr CF should be found or belongs to
    * @return
    *   BasicHubOption object if option with provided name exists in provided CF
    */
  def getCfOption(
      cfId: Option[String],
      cfName: String,
      name: String,
      contextEntity: IHubIssueReplica
  ): Future[Option[BasicHubOption]]

  /** Gets IHubUser by user key that belongs to the provided project and issue type
    * @param key
    *   of the required user
    * @param projectId
    *   id of the project where user should be found
    * @param issueTypeId
    *   id of the issue type where user should be found
    * @return
    */
  def getUser(
      key: String,
      projectId: Option[String],
      issueTypeId: Option[String]
  ): Future[Option[IHubUser]]

  /** Checks whether the provided basicHubUser exists under the project and issue type.
    * @param basicHubUser
    * @param projectId
    * @param issueTypeId
    * @return
    *   IHubUser or None
    */
  def getUser(
      basicHubUser: IHubUser,
      projectId: Option[String],
      issueTypeId: Option[String]
  ): Future[Option[IHubUser]]

  /** The output depends on the node or our requirements. It could be user email, user key etc
    * @param user
    * @return
    */
  def getUserAsString(user: IHubUser): String

  /** Checks whether provided issue/entity type value is available for particular entity and update
    * it with provided type
    * @param entity
    *   that should be updated with issue type
    * @param value
    *   issue/entity type that should be set to the entity
    * @return
    */
  def setIssueType(entity: IHubIssueReplica, value: String): Future[IHubIssueReplica]

  /** Checks whether provided priority is available for particular entity and update it whist
    * provided value
    * @param entity
    *   that should be updated with issue type
    * @param value
    *   priority name
    * @return
    */
  def setPriority(entity: IHubIssueReplica, value: String): Future[IHubIssueReplica]
}
