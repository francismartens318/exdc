package com.exalate.replication.services.api.replication.in

import com.exalate.api.domain.connection.IConnection
import com.exalate.replication.services.replication.in.PollerService
import com.google.inject.ImplementedBy

import scala.concurrent.Future

@ImplementedBy(classOf[PollerService])
trait IPollerService {

  def pollAllMessages(connection: IConnection): Future[None.type]

  def shouldPollRemoteSideAware(connections: Seq[IConnection]): Future[Seq[IConnection]]

}
