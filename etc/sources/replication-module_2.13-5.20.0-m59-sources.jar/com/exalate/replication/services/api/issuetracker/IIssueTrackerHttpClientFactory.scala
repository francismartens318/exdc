package com.exalate.replication.services.api.issuetracker

import com.google.inject.ImplementedBy

@ImplementedBy(
  classOf[com.exalate.replication.services.issuetracker.DefaultIssueTrackerHttpClientFactory]
)
trait IIssueTrackerHttpClientFactory {
  def getGroovyHttpClient(): IHttpClient
  def getHttpClient(): IHttpClient
  def getGroovyHttpClientReadOnly(): IHttpClient
  def getHttpClientReadOnly(): IHttpClient
  def getHttpClientAIReadOnly(): IHttpClient
}
