package com.exalate.replication.services.api.config

import com.exalate.api.domain.instance.INonPersistentInstance
import com.exalate.api.domain.nodeinfo.INonPersistentNodeInfo
import com.exalate.domain.values.NodeInfoValue
import com.exalate.replication.services.config.UrlInferringService
import com.google.inject.ImplementedBy

import scala.concurrent.Future

@ImplementedBy(classOf[UrlInferringService])
trait IUrlInferringService {

  def setNodeInfoAndUrls(
      nonPersistentInstance: INonPersistentInstance
  ): Future[INonPersistentInstance]

  def getAndSetNodeInfoWithExalateUrl(
      nonPersistentInstance: INonPersistentInstance
  ): Future[INonPersistentInstance]

  def getAndSetNodeInfoWithTrackerUrl(
      nonPersistentInstance: INonPersistentInstance
  ): Future[INonPersistentInstance]

  def getNodeInfoViaDifferentUrls(
      url: String,
      remoteUsername: Option[String],
      remotePassword: Option[String]
  ): Future[NodeInfoValue]

}
