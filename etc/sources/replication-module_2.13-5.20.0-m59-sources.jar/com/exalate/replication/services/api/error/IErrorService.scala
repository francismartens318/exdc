package com.exalate.replication.services.api.error

import com.exalate.api.domain._
import com.exalate.api.domain.blob.event.IBlobEvent
import com.exalate.api.domain.blob.request.IBlobRequest
import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.event.ISyncEvent
import com.exalate.api.domain.request.ISyncRequest
import com.exalate.api.domain.trigger.ITrigger
import com.exalate.api.exception.CategorizedException
import com.exalate.basic.domain.error.NonPersistentError
import com.exalate.domain.editor.error.EditorError
import com.exalate.domain.exception.trigger.ExalateTriggerException
import com.exalate.domain.replication.BasicSyncRequest
import com.exalate.replication.services.error.ErrorService
import com.google.inject.ImplementedBy

import scala.concurrent.Future

@ImplementedBy(classOf[ErrorService])
trait IErrorService {

  def findAll: Future[Seq[IError]]

  def getErrorForTrigger(trigger: ITrigger): Future[Option[IError]]

  def updateError(id: Int, params: NonPersistentError): Future[None.type]

  def resolveAllErrors: Future[None.type]

  def resolveForConnection(connectionId: Int): Future[None.type]

  def createError(
      errorEntityType: ErrorEntityType,
      t: Throwable,
      context: SyncContext,
      errorKey: Option[String]
  ): Future[Option[Int]]

  def createError(
      e: CategorizedException,
      context: SyncContext,
      errorKey: Option[String]
  ): Future[Option[Int]]

  def createError(
      errorEntityType: ErrorEntityType,
      t: Throwable,
      connection: IConnection,
      localIssueKey: Option[IIssueKey],
      remoteIssueKey: Option[IIssueKey],
      errorActTypeOpt: Option[ErrorActType],
      errorKey: Option[String] = None
  ): Future[Option[Int]]

  def createError(
      ce: CategorizedException,
      connection: IConnection,
      localIssueKey: Option[IIssueKey],
      remoteIssueKey: Option[IIssueKey],
      errorActTypeOpt: Option[ErrorActType]
  ): Future[Option[Int]]

  def createTransportError(e: CategorizedException, context: SyncContext): Future[Option[Int]]

  def createPollingTransportError(exception: Exception, connection: IConnection): Future[Option[Int]]

  def hasErrorReferencingSyncEvent(syncEventId: Int): Future[Boolean]

  def hasErrorReferencingSyncRequest(syncRequestId: Int): Future[Boolean]

  def createTriggerError(
      entityType: Option[String],
      te: ExalateTriggerException,
      connection: IConnection,
      localIssueKey: Option[IIssueKey],
      failedExalateIssue: String,
      errorKey: Option[String] = None
  ): Future[Option[Int]]

  def isOk(syncEvent: ISyncEvent): Future[Boolean]

  def isOk(syncRequest: ISyncRequest): Future[Boolean]

  def isOk(syncRequest: BasicSyncRequest, connection: IConnection): Future[Boolean]

  def isOkForTriggerPoll(trigger: ITrigger): Future[Boolean]

  def isOk(connection: IConnection): Future[Boolean]
  def isOk(): Future[Boolean]

  def isOk(blobEvent: IBlobEvent): Future[Boolean]

  def isOk(blobRequest: IBlobRequest): Future[Boolean]

  def resolveErrorAndRescheduleSync(errorId: Int): Future[None.type]

  def ensureExpiredError(): Future[None.type]

  def changeEntityTypeToIssue(errorId: Int): Future[Unit]

  def deletePollingTransportErrors(connection: IConnection): Future[Int]

  def deleteTransportErrorsForSyncEvent(syncEvent: ISyncEvent): Future[Int]

  def deleteTransportErrorsForSyncRequest(syncRequest: ISyncRequest): Future[Int]

  def deleteTransportErrorsForSyncRequest(basicSyncRequest: BasicSyncRequest): Future[Int]

  def deleteSchedulingErrors(
      connection: IConnection,
      localIssueKeyOpt: Option[IIssueKey]
  ): Future[Int]

  def findEditorErrorsForConnection(connectionId: Int): Future[Seq[EditorError]]
}
