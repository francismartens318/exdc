package com.exalate.replication.services.api.node.lifecycle

import com.exalate.domain.values.lifecycle.LifecycleValue
import com.exalate.replication.services.node.lifecycle.LifecycleInfoService
import com.google.inject.ImplementedBy

import java.sql.Timestamp
import java.time.Instant
import java.util.Date
import scala.concurrent.Future

@ImplementedBy(classOf[LifecycleInfoService])
trait ILifecycleInfoService {

  def get: Future[LifecycleValue]

  def isEulaAccepted: Boolean

  def acceptEula: Future[None.type]

  def updateLastEmailSentDate(timestamp: Timestamp): Future[None.type]
  def updateLastLicenseEmailSentDate(timestamp: Timestamp): Future[None.type]
  def updateLastArchiveWarningEmailSentDate(timestamp: Timestamp): Future[None.type]

  def getEvaluationModeExpirationDate: Instant

  def ensureLifecycle(): Unit

  def setVerified(): Future[None.type]

  def markFirstVisit(): Future[None.type]
  def markConnectionIntroShown(admin: String): Future[None.type]

  def isExpired: Boolean

  def isWarningPeriod: Boolean

  def getExpiryDate: Instant

  def updateInstanceUid(instanceUid: String): Future[None.type]

  def getInstanceUid: Future[Option[String]]
  def getInstanceUidUnsafe: Future[String]

  def isVerified: Future[Boolean]

  def getRegistrationDate: Date
}
