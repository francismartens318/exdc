package com.exalate.replication.services.api.editor

import com.exalate.api.domain.connection.IConnection
import com.exalate.domain.editor.mappings.MappingValue
import com.exalate.domain.editor.scopes.ScopeValue
import com.exalate.domain.values.{MappingsParamsValue, MappingsSuggestionValue, ScopeParamsValue}
import com.exalate.replication.services.editor.EditorParamsService
import com.google.inject.ImplementedBy
import play.api.libs.json.{JsBoolean, JsValue}

import scala.concurrent.Future

@ImplementedBy(classOf[EditorParamsService])
trait IEditorParamsService {

  /** Build supported scope params for visual editor
    * @param connection
    *   \- the connnection
    * @return
    *   JsValue which looks like: { JsValue obtained from {@link buildLocalScopeParamsJson()} , //
    *   "local": {....} JsValue obtained from {@link buildRemoteScopeParamsJson()} , // "remote":
    *   {....} }
    */
  def getScopeParamsValue(connection: IConnection): Future[Option[ScopeParamsValue]]

  /** Build supported mapping params for visual editor
    *
    * @param connection
    *   \- the connection
    * @return
    *   JsValue which looks like: { JsValue obtained from {@link buildLocalMappingParamsJson( )} ,
    *   // "local": {....} JsValue obtained from {@link buildRemoteMappingParamsJson( )} , //
    *   "remote": {....} }
    */
  def getMappingsParamsValue(connection: IConnection): Future[Option[MappingsParamsValue]]

  /** Builds suggestion for mapping rules which user can seen just after Scopes are selected and
    * navigated to the rules tab. Suggestion is build based on the list of fields obtained from
    * nodeInfoValue.editor and options for each of the fields is choosed based on scope
    *
    * @param connection
    *   \- the connection
    * @param scopeValueOptSeq
    *   \- seq of scopes that were selected on UI by user
    * @return
    *   JsValue which looks like: { "mappings":[ { "local" : { }, "arrow":"LR", "remote": { },
    *   "type":"MAPPING" },// {@link com.exalate.domain.editor.mappings.MappingValue} {
    *   {@link com.exalate.domain.editor.mappings.MappingValue} }, {
    *   {@link com.exalate.domain.editor.mappings.MappingValue} } ] }
    */
  def getMappingsSuggestions(
      connection: IConnection,
      scopeValueOptSeq: Seq[ScopeValue],
      previousConnectionMode: Option[String] = None
  ): Future[Option[MappingsSuggestionValue]]

  /** Checks whether the visual rules for provided connection is ready. Checking is performed by
    * Invitation Status of the connection (should be ACCEPTED) and by monitor whether Main Field
    * Options have been saved to IssueTrackerOptionTable (table where we hold all system fields and
    * their options from the remote side)
    * @param connection
    * @return
    */
  def isVisualReady(connection: IConnection): Future[Option[JsBoolean]]

  def getMappingsValueForSuggestions(
      connection: IConnection,
      scopeValueOptSeq: Seq[ScopeValue],
      previousConnectionMode: Option[String]
  ): Future[Option[Seq[MappingValue]]]

}
