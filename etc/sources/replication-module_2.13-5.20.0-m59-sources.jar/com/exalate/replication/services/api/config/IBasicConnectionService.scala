package com.exalate.replication.services.api.config

import com.exalate.api.domain.connection.IConnection
import com.exalate.domain.editor.mappings.MappingValue
import com.exalate.domain.editor.scopes.ScopeValue
import com.exalate.replication.services.config.BasicConnectionService
import com.google.inject.ImplementedBy

import scala.concurrent.Future

@ImplementedBy(classOf[BasicConnectionService])
trait IBasicConnectionService {

  /** Generates default scope rules for BASIC connection.
    * @param connection
    * @return
    */
  def generateDefaultScopeRules(connection: IConnection): Future[Option[Seq[ScopeValue]]]

  /** Generates default mapping rules for BASIC connection. which has only ISSUE_TYPE, SUMMARY,
    * DESCRIPTION, COMMENTS, ATTACHMENTS
    *
    * @param connection
    * @param scopeValueOptSeq
    *   \- scope values for default mapping rules
    * @return
    */
  def generateDefaultMappingRules(
      connection: IConnection,
      scopeValueOptSeq: Option[Seq[ScopeValue]] = None
  ): Future[Option[Seq[MappingValue]]]

}
