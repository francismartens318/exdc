package com.exalate.replication.services.api.processor

import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.request.ISyncRequest
import com.exalate.api.domain.twintrace.{INonPersistentTrace, ITrace, TraceType}
import com.exalate.api.domain.{IBlobMetadata, IIssueKey, INonPersistentReplica}
import com.google.inject.{ImplementedBy, Singleton}

import scala.concurrent.Future

@ImplementedBy(classOf[com.exalate.replication.services.processor.ChangeIssueProcessor])
trait IChangeIssueProcessor {

  def changeIssue(
      connection: IConnection,
      syncRequest: ISyncRequest,
      prevReplica: INonPersistentReplica,
      receivedReplica: INonPersistentReplica,
      localIssueKey: IIssueKey,
      blobMetadataSeq: Seq[IBlobMetadata],
      fieldTraces: Map[TraceType, Seq[ITrace]]
  ): Future[Option[Seq[INonPersistentTrace]]]

}
