package com.exalate.replication.services.api.error

import com.exalate.api.domain.ErrorEntityType
import com.exalate.api.exception.CategorizedException

case class CategorizedExceptionWithContext(context: SyncContext, e: CategorizedException)
    extends CategorizedException(e) {

  override def getErrorEntityType: ErrorEntityType = e.getErrorEntityType

  override def getDocsLink: String = e.getDocsLink

  override def getRootCauseErrorTypeName: String = e.getRootCauseErrorTypeName

}
