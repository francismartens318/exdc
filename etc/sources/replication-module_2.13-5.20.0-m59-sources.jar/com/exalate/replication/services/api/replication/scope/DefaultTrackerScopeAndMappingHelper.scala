package com.exalate.replication.services.api.replication.scope

import com.exalate.api.domain.hubobject.IHubIssueReplica
import com.exalate.api.domain.hubobject.v1_2.{
  IHubIssueType,
  IHubPriority,
  IHubProject,
  IHubStatus,
  IHubUser
}
import com.exalate.basic.domain.hubobject.v1.BasicHubOption

import scala.concurrent.Future

class DefaultTrackerScopeAndMappingHelper extends ITrackerScopeAndMappingHelper {

  override def getProject(projectIdOrKey: String): Future[Option[IHubProject]] =
    Future.successful(None)

  override def getIssueType(
      name: String,
      projectId: Option[String]
  ): Future[Option[IHubIssueType]] = Future.successful(None)

  override def getPriority(name: String, projectId: Option[String]): Future[Option[IHubPriority]] =
    Future.successful(None)

  override def getStatus(
      name: String,
      projectId: Option[String],
      issueTypeId: Option[String]
  ): Future[Option[IHubStatus]] = Future.successful(None)

  override def getCfOption(
      cfId: Option[String],
      cfName: String,
      name: String,
      contextEntity: IHubIssueReplica
  ): Future[Option[BasicHubOption]] = Future.successful(None)

  override def getUser(
      key: String,
      projectId: Option[String],
      issueTypeId: Option[String]
  ): scala.concurrent.Future[Option[com.exalate.api.domain.hubobject.v1_2.IHubUser]] =
    Future.successful(None)

  override def getUserAsString(user: com.exalate.api.domain.hubobject.v1_2.IHubUser): String =
    Option(user.getEmail).getOrElse(user.getKey)

  override def getUser(
      basicHubUser: IHubUser,
      projectId: Option[String],
      issueTypeId: Option[String]
  ): Future[Option[IHubUser]] = Future.successful(None)

  override def setIssueType(entity: IHubIssueReplica, value: String): Future[IHubIssueReplica] =
    Future.successful(entity)

  override def setPriority(entity: IHubIssueReplica, value: String): Future[IHubIssueReplica] =
    Future.successful(entity)

}
