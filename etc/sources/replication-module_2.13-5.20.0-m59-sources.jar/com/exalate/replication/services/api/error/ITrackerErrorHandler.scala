package com.exalate.replication.services.api.error

import com.exalate.api.domain.ErrorActType

import scala.concurrent.Future

trait ITrackerErrorHandler {

  def handleScheduleError(
      e: Exception,
      ec: SyncContext,
      actTypeOpt: Option[ErrorActType]
  ): Future[None.type] = Future.failed(e)

  def handleError(e: Exception, ec: SyncContext): Future[None.type] = Future.failed(e)
}
