package com.exalate.replication.services.api.replication.mapping

import com.exalate.replication.services.replication.mapping.DefaultTrackerMatchHelper
import com.google.inject.ImplementedBy

@ImplementedBy(classOf[DefaultTrackerMatchHelper])
trait ITrackerMatchHelper {
  def applyUserMatch(currentValue: Any)(expectedValue: String): Boolean
}
