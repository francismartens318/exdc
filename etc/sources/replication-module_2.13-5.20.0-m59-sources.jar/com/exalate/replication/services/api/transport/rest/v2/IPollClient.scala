package com.exalate.replication.services.api.transport.rest.v2

import com.exalate.api.domain.connection.IConnection
import com.exalate.replication.services.transport.v2_4.PollClient
import com.exalate.replication.services.transport.value._
import com.google.inject.ImplementedBy

import scala.concurrent.Future

@ImplementedBy(classOf[PollClient])
trait IPollClient {

  def pollSyncRequests(connection: IConnection): Future[Seq[RequestValue]]

  def pollBlobRequests(connection: IConnection): Future[Seq[BlobRequestValue]]

  def pollSyncResponses(connection: IConnection): Future[Seq[SyncResponseValue]]

  def pollSyncErrorResponses(connection: IConnection): Future[Seq[ErrorResponseValue]]

  def pollBlobResponses(connection: IConnection): Future[Seq[BlobResponseValue]]

  def pollBlobErrorResponses(connection: IConnection): Future[Seq[BlobErrorResponseValue]]

}
