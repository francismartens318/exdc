package com.exalate.replication.services.api.transport.rest.v2

import com.exalate.api.domain.connection.IConnection
import com.exalate.replication.services.transport.v4_1.ConnectionPollClient
import com.exalate.replication.services.transport.value._
import com.google.inject.ImplementedBy

import scala.concurrent.Future

@ImplementedBy(classOf[ConnectionPollClient])
trait IConnectionPollClient {

  def pollSyncRequests(
      connection: IConnection,
      syncRequestValues: Set[Int]
  ): Future[ResponseValue[RequestValue]]

  def pollBlobRequests(
      connection: IConnection,
      blobRequestsValues: Set[Int]
  ): Future[ResponseValue[BlobRequestValue]]

  def pollSyncResponses(
      connection: IConnection,
      syncResponseValues: Set[Int]
  ): Future[ResponseValue[SyncResponseValue]]

  def pollSyncErrorResponses(
      connection: IConnection,
      syncErrorResponseValues: Set[Int]
  ): Future[ResponseValue[ErrorResponseValue]]

  def pollBlobResponses(
      connection: IConnection,
      blobResponseValues: Set[Int]
  ): Future[ResponseValue[BlobResponseValue]]

  def pollBlobErrorResponses(
      connection: IConnection,
      blobErrorResponseValues: Set[Int]
  ): Future[ResponseValue[BlobErrorResponseValue]]

}
