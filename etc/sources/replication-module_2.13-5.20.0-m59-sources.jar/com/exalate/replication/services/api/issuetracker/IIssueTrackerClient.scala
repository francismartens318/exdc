package com.exalate.replication.services.api.issuetracker

import com.exalate.replication.services.issuetracker.NopIssueTrackerClient
import com.google.inject.ImplementedBy
import play.api.libs.ws.WSResponse

import scala.concurrent.Future

@ImplementedBy(classOf[NopIssueTrackerClient])
trait IIssueTrackerClient {

  def http(
      method: String,
      path: String,
      bodyOpt: Option[String] = None,
      qParamOpt: Option[Map[String, Seq[String]]] = None,
      headersOpt: Option[Map[String, Seq[String]]] = None
  ): Future[WSResponse]

}
