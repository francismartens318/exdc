package com.exalate.replication.services.api.error

import com.exalate.api.domain.ErrorActType
import com.exalate.api.exception.CategorizedException
import com.exalate.replication.services.error.ErrorHandler
import com.google.inject.ImplementedBy

import scala.concurrent.Future

@ImplementedBy(classOf[ErrorHandler])
trait IErrorHandler {
  def handleError(ex: Exception, ec: SyncContext): Future[None.type]

  def handleScheduleError(
      e: Exception,
      ec: SyncContext,
      actTypeOpt: Option[ErrorActType]
  ): Future[None.type]

}
