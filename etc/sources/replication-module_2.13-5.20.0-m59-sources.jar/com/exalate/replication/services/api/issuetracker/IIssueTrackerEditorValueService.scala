package com.exalate.replication.services.api.issuetracker

import com.exalate.domain.values.{FeatureValue, VisualFieldValue}
import com.google.inject.ImplementedBy

import scala.concurrent.Future

@ImplementedBy(
  classOf[com.exalate.replication.services.issuetracker.NopIssueTrackerEditorValueService]
)
trait IIssueTrackerEditorValueService {

  /** Provide Visual Field Value, which consists of list of system field with corresponding
    * specification, namely: * key of field: EditorFields.PROJECT.toString; * label: "Project"; *
    * queryable: Some(false); * main: Some(true); * map of type: FieldDataType.OPTION.toString; *
    * seq of operators
    */
  def get(editorFeatures: Option[Seq[FeatureValue]] = None): Future[Option[VisualFieldValue]]
}
