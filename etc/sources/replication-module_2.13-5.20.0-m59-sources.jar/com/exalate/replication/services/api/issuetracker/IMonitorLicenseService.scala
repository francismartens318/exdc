package com.exalate.replication.services.api.issuetracker

import com.exalate.domain.values.monitor.MonitorNodeLicenseInfo
import com.google.inject.ImplementedBy
import play.api.Logger

import scala.concurrent.{ExecutionContext, Future}

/** Trait with default implementation for Monitoring
  */
@ImplementedBy(classOf[DefaultMonitorLicenseService])
trait IMonitorLicenseService {

  val LOG: Logger = Logger(classOf[IMonitorLicenseService])
  implicit val ec: ExecutionContext

  def client: ITrackerMonitorLicenseClient = DefaultTrackerMonitorLicenseClient

  def getMonitorLicenseInfo: Future[MonitorNodeLicenseInfo] =
    Future.successful(MonitorNodeLicenseInfo.Empty)

  /** Should return the number of active users on the instance. The class which extends
    * IMonitorLicenseService trait should rewrite `client: ITrackerMonitorLicenseClient`
    * @return
    */
  def getNumberOfUsers: Future[Int] = client.getNumberOfUsers
    .recover {
      case e: Exception =>
        LOG.error(s"An error occurred while trying to get a number of users", e)
        None
    }
    .map(_.getOrElse(NumberOfUsersUnavailable))

}
