package com.exalate.replication.services.api.transport.mapper

import com.exalate.replication.services.transport.mapper.v1.MapperNodeUrlClient
import com.google.inject.ImplementedBy

import scala.concurrent.Future

@ImplementedBy(classOf[MapperNodeUrlClient])
trait IMapperNodeUrlClient {

  def registerIssueTrackerUrl(exalateUrl: String, issueTrackerUrl: String): Future[String]
}
