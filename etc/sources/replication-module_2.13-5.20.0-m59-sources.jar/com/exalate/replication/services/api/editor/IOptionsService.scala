package com.exalate.replication.services.api.editor

import com.exalate.api.domain.connection.IConnection
import com.exalate.domain.transport.trackeroptions.{
  IssueTrackerOptionDependency,
  IssueTrackerOptionsForAutocomplete
}
import com.exalate.domain.values.{EditorFieldValue, NodeInfoValue}
import com.exalate.replication.services.editor.OptionsService
import com.google.inject.ImplementedBy

import scala.concurrent.Future

/** The service, which extract remote and local option for the provided field, and helps with
  * autocomplete on UI
  */

@ImplementedBy(classOf[OptionsService])
trait IOptionsService {

  /** In order to extract a seq of local options for required field, Firstly extracts context for
    * provided queryParams from node info and then calls
    * {@link getLocalOptionsForAutocompleteWithContext()}
    * @param key
    * @param query
    * @param limit
    * @param offset
    * @param queryParams
    * @return
    *   IssueTrackerOptionsForAutocomplete which contains `results` - a seq of
    *   IssueTrackerOptionValue
    */
  def getLocalOptionsForAutocomplete(
      key: String,
      query: Option[String],
      limit: Option[Int],
      offset: Option[Int],
      queryParams: Map[String, Seq[String]],
      userKey: Option[String] = None
  ): Future[IssueTrackerOptionsForAutocomplete]

  /** Searches for options on the local instance for the requested field (key) by calling
    * {@link com.exalate.replication.services.api.issuetracker.ITrackerOptionService} }. The field
    * could be one of the following: PROJECT, ISSUE_TYPE, PRIORITY, STATUS and CF
    *
    * @param key
    * @param query
    * @param limit
    * @param offset
    * @param context
    * @return
    *   IssueTrackerOptionsForAutocomplete which contains `results` - a seq of
    *   IssueTrackerOptionValue
    */
  def getLocalOptionsForAutocompleteWithContext(
      key: String,
      query: Option[String],
      limit: Option[Int],
      offset: Option[Int],
      context: Option[Seq[IssueTrackerOptionDependency]],
      userKey: Option[String] = None
  ): Future[IssueTrackerOptionsForAutocomplete]

  /** Depending on the connection type (local or not) extracts context for provided queryParams from
    * node info and then calls {@link getLocalOptionsForAutocompleteWithContext( )} or
    * {@link getRemoteOptionsForAutocompleteWithContext( )}
    *
    * @param key
    * @param connection
    * @param query
    * @param limit
    * @param offset
    * @param queryParams
    * @return
    *   IssueTrackerOptionsForAutocomplete which contains `results` - a seq of
    *   IssueTrackerOptionValue
    */
  def getRemoteOptionsForAutocomplete(
      key: String,
      connection: IConnection,
      query: Option[String],
      limit: Option[Int],
      offset: Option[Int],
      queryParams: Map[String, Seq[String]]
  ): Future[IssueTrackerOptionsForAutocomplete]

  /** Based on key of target field, instanceUid extracted from connection and provided query
    * searches for options in DB namely IssueTrackerOptionTable
    *
    * @param key
    * @param connection
    * @param query
    * @param limit
    * @param offset
    * @param context
    * @return
    *   IssueTrackerOptionsForAutocomplete which contains `results` - a seq of
    *   IssueTrackerOptionValue
    */
  def getRemoteOptionsForAutocompleteWithContext(
      key: String,
      connection: IConnection,
      query: Option[String],
      limit: Option[Int],
      offset: Option[Int],
      context: Option[Seq[IssueTrackerOptionDependency]]
  ): Future[IssueTrackerOptionsForAutocomplete]

  /** Based on provided queryParams and editor Fields extracted from NodeInfoValue, forms seq of
    * IssueTrackerOptionDependency
    * @param queryParams
    * @param nodeInfo
    * @param customFields
    * @return
    */
  def getIssueTrackerOptionContext(
      queryParams: Map[String, Seq[String]],
      nodeInfo: NodeInfoValue,
      customFields: Seq[EditorFieldValue]
  ): Option[Seq[IssueTrackerOptionDependency]]

}
