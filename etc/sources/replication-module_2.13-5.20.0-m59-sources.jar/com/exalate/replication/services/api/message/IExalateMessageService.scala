package com.exalate.replication.services.api.message

import com.exalate.domain.transport.message.ExalateMessage
import com.exalate.replication.services.message.ExalateMessageService
import com.google.inject.ImplementedBy

import scala.concurrent.Future

@ImplementedBy(classOf[ExalateMessageService])
trait IExalateMessageService {

  /** `send` puts the message into the queue the future of the message id is returned at some later
    * point in time the remote side is guaranteed to call receive with this message (if they still
    * have connection)
    */
  def send(m: ExalateMessage): Future[Int]
  def receive(ms: Seq[ExalateMessage], instanceId: Int): Seq[Future[ExalateMessage]]
}
