package com.exalate.replication.services.api.replication

import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.event.ISyncEvent
import com.exalate.api.domain.hubobject.IHubIssueReplica
import com.exalate.api.domain.twintrace.ITwinTrace
import com.exalate.api.domain.{IIssueKey, INonPersistentConnectContext}
import com.exalate.basic.domain.hubobject.v1.UpdateBasicHubIssue
import com.google.inject.ImplementedBy

import scala.concurrent.Future

@ImplementedBy(
  classOf[com.exalate.replication.services.replication.EventSchedulerFromTrackerService]
)
trait IEventSchedulerFromTrackerService {

  def scheduleExalateEvent(
      issueKey: IIssueKey,
      connection: IConnection,
      updateHubIssueOption: Option[UpdateBasicHubIssue] = None,
      issueOption: Option[IHubIssueReplica] = None
  ): Future[Option[ISyncEvent]]

  def scheduleExalateOrUpdateEvent(
      issueKey: IIssueKey,
      connection: IConnection,
      updateHubIssueOption: Option[UpdateBasicHubIssue] = None,
      issueOption: Option[IHubIssueReplica] = None
  ): Future[Option[ISyncEvent]]

  def scheduleUpdateEvent(
      issueKey: IIssueKey,
      connection: IConnection,
      issue: Option[UpdateBasicHubIssue] = None
  ): Future[Option[ISyncEvent]]

  def scheduleUpdateEventForTwinTrace(
      issueKey: IIssueKey,
      twinTrace: ITwinTrace,
      issue: Option[UpdateBasicHubIssue] = None
  ): Future[Option[ISyncEvent]]

  def scheduleSyncEventNoChangeCheck(
      issueKey: IIssueKey,
      connection: IConnection
  ): Future[Option[ISyncEvent]]

  def scheduleDeleteEvent(issueKey: IIssueKey, connection: IConnection): Future[Option[ISyncEvent]]
  def scheduleUnexalateEvent(issueKey: IIssueKey, connection: IConnection): Future[Option[ISyncEvent]]
  def scheduleCleanupEvent(issueKey: IIssueKey, connection: IConnection): Future[Option[ISyncEvent]]

  def scheduleCleanupEventForRemoteIssue(
      remoteIssueUrn: String,
      connection: IConnection,
      entityType: String
  ): Future[Option[ISyncEvent]]

  def scheduleCleanupEventForConnection(connectionId: Int, entityType: String): Future[None.type]

  def scheduleConnectEvent(
      issueKey: IIssueKey,
      connection: IConnection,
      remoteIssueUrn: String,
      connectContext: Option[INonPersistentConnectContext],
      issueOption: Option[UpdateBasicHubIssue] = None
  ): Future[Option[ISyncEvent]]

}
