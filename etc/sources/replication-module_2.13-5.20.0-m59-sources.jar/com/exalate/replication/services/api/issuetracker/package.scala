package com.exalate.replication.services.api

package object issuetracker {

  /** In order to not fail when we cannot get the amount of user, there were decision to use `-1`
    * (in order to identify when something is wrong)
    */
  val NumberOfUsersUnavailable: Int = -1
}
