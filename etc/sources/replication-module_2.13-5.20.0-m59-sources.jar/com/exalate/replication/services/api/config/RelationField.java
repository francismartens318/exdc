package com.exalate.replication.services.api.config;

import javax.annotation.Nonnull;

public enum RelationField {
    NAME("name"),
    DESCRIPTION("description"),
    DATA_FILTER("dataFilter"),
    CHANGE_PROCESSOR("changeProcessor"),
    CREATE_PROCESSOR("createProcessor"),
    REMOTE_INSTANCE_NAME_OR_URL("remoteInstance"),
    STATUS("status"),
    CREATE_REMOTE_ISSUE_LINK("createRemoteIssueLink"),
    SYNC_PANEL_LINK("syncPanelIssueLink"),
    PROXY_USERNAME("proxyUsername"),
    PROXY_PASSWORD("proxyPassword"),
    AUTHENTICATION_REQUIRED("authRequiredBoolean");

    RelationField(String jsonName) {
        this.jsonName = jsonName;
    }

    private final String jsonName;

    @Nonnull
    public String getJsonName() {
        return jsonName;
    }
}
