package com.exalate.replication.services.api.replication.worker

import javax.annotation.{Nonnull, Nullable}
import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.{ErrorActType, IIssueKey, INonPersistentConnectContext}
import com.exalate.domain.transport.message.ExalateMessage
import com.exalate.generic.services.FullAuditInfo
import com.google.inject.ImplementedBy
import com.exalate.replication.services.replication.worker.{
  ConnectionAccepted,
  ConnectionInitiated,
  ConnectionUpdated
}

@ImplementedBy(
  classOf[com.exalate.replication.services.replication.worker.WorkerNotificationService]
)
trait IWorkerNotificationService {

  def sendProcessWebhookQueue(fullaudit: FullAuditInfo): Unit
  def sendPartialAuditLogRemoved(): Unit
  def sendProcessEventsNotification(): Unit
  def sendProcessEventsNotification(timeInSeconds: Int): Unit
  def sendProcessBlobEventsNotification(): Unit
  def sendProcessBlobEventsNotification(timeInSeconds: Int): Unit
  def sendProcessBlobRequestsNotification(): Unit
  def sendProcessBlobRequestsNotification(timeInSeconds: Int): Unit
  def sendProcessRequestsNotification(): Unit
  def sendProcessRequestsNotification(timeInSeconds: Int): Unit
  def fireAllWorkerNotifications(): Unit

  def fireRescheduleEvent(
      @Nonnull issueKey: IIssueKey,
      @Nonnull actType: ErrorActType,
      @Nonnull connection: IConnection,
      @Nullable connectRemoteIssueUrn: String,
      connectContext: INonPersistentConnectContext
  ): Unit

  def fireTriggerExalateEvent(@Nonnull issueKey: IIssueKey): Unit

  def fireConnectionInitiatedEvent(connectionCreated: ConnectionInitiated): Unit
  def fireConnectionAcceptedEvent(connectionCreated: ConnectionAccepted): Unit
  def fireConnectionUpdatedEvent(connectionUpdated: ConnectionUpdated): Unit
  def fireStartMessageBatching(): Unit
  def fireSendMessage(m: ExalateMessage): Unit
}
