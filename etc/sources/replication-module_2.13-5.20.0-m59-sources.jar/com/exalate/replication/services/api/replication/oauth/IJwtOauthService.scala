package com.exalate.replication.services.api.replication.oauth

import com.exalate.api.domain.oauth.IOAuthData
import com.exalate.domain.oauth.OAuthClient
import com.exalate.domain.values.connection.ConnectionValue
import com.exalate.replication.services.replication.oauth.JwtOauthService
import com.google.inject.ImplementedBy
import play.api.libs.json.JsValue

import java.util.UUID
import scala.concurrent.Future
import scala.util.Try

@ImplementedBy(classOf[JwtOauthService])
trait IJwtOauthService {

  def decodeAccessTokenAndReturnInstanceUid(accessToken: String): Option[String]

  def validateToken(token: String, oauthData: IOAuthData): Try[Unit]

  def generateState(
      clientId: String,
      redirectUri: String,
      exaUserId: String,
      stateUuid: UUID,
      instanceUid: String,
      connectionJsValue: JsValue,
      scope: String
  ): String

  def generateState(
      clientId: String,
      redirectUri: String,
      clientSecret: String,
      instanceUid: String,
      exalateUrl: String
  ): String

  def generateAuthorizationCode(
      clientId: String,
      redirectUri: String,
      authServerExaUserId: String,
      authCodeUuid: UUID,
      instanceUid: String,
      scope: String
  ): String

  def generateToken(
      instanceUid: String,
      clientExaUserId: String,
      serverExaUserId: String,
      secret: String,
      scope: String,
      expiresIn: Long,
      localUrl: String,
      clientId: String
  ): String

  def generateClientJwt(clientId: String, clientSecret: String, redirectUri: String): String

  def validateStateJwt(
      stateJwt: String,
      isLocal: Boolean = false,
      withSignature: Boolean = false
  ): Future[None.type]

  def validateClientJwt(clientJwtOpt: Option[String], isLocal: Boolean = false): Future[OAuthClient]

  def getClientIdFromToken(token: String): Option[String]

  def getRedirectUriFromToken(token: String): Option[String]

  def getAuthServerUriFromToken(token: String): Option[String]

  def getUserIdFromToken(token: String): Option[String]

  def getExalateUrlFromToken(token: String): Option[String]

  def getConnectionValueFromToken(
      token: String,
      withSignature: Boolean = false
  ): Option[ConnectionValue]

  def getScopeFromToken(token: String): Option[String]

  def getAuthServerExaUserIdFromToken(token: String): Option[String]
}
