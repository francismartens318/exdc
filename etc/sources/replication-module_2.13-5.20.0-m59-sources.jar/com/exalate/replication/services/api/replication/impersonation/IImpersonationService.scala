package com.exalate.replication.services.api.replication.impersonation

import com.exalate.api.domain.webhook.INonPersistentWebhookInfo
import com.exalate.basic.domain.hubobject.v1.UpdateBasicHubIssue
import com.exalate.generic.services.{EntityContext, FullAuditInfo}
import com.exalate.replication.services.replication.impersonation.ImpersonationService
import com.google.inject.ImplementedBy

import scala.concurrent.Future

@ImplementedBy(classOf[ImpersonationService])
trait IImpersonationService {

  /** Decide if a webhook needs to be processed or not. This is decided by checking for: * A full
    * audit log for that entity. If there is one, the change was performed by exalate so full audit
    * log gets cleaned up * A partial audit log for that issue is found. We persist the webhook info
    * and wait to get a full audit log * No auditlog is found. We assume that change was not
    * performed by exalate
    */
  def handleWebhookAction[T <: EntityContext](
      webhookInfo: INonPersistentWebhookInfo,
      updateHubIssueOption: Option[UpdateBasicHubIssue] = None,
      issueProjectKey: Option[String] = None,
      entityContext: Option[T]
  ): Future[None.type]

  /** After getting a full audit info. This method will be called to ensure that any persisted
    * webhook for the full audit info is processed.
    */
  def handleWorkerAction(fullAuditInfo: FullAuditInfo): Future[None.type]
  def handlePartialAuditLogRemoved(): Future[None.type]
}
