package com.exalate.replication.services.api.config

import com.exalate.api.domain.IIssueKey
import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.twintrace.SyncStatus
import com.exalate.api.domain.IIssueKey
import com.exalate.replication.services.config.SyncStatusService
import com.google.inject.ImplementedBy

import scala.concurrent.Future

@ImplementedBy(classOf[SyncStatusService])
trait ISyncStatusService {

  def getSyncStatusesByIssueId(
      issueKey: IIssueKey,
      belongsToProject: Boolean = true
  ): Future[Option[SyncStatusesBean]]

  def getSyncStatusesByIssueUrn(
      fieldValues: Map[String, String],
      issueUrn: String,
      entityType: String
  ): Future[Option[SyncStatusesBean]]

  def getSyncStatusesByIssueUrnAndProjId(
      projectId: String,
      issueUrn: String,
      entityType: String
  ): Future[Option[SyncStatusesBean]]

}
