package com.exalate.replication.services.api.processor

import java.util

import com.exalate.basic.domain.hubobject.v1.BasicHubIssue
import groovy.lang.Closure

class RemoteInstanceAggregate(var issue: BasicHubIssue)
    extends Closure[Object]({
      val container = new util.HashMap[String, Object](); container.put("issue", issue); container
    }) {

  def getIssue(): BasicHubIssue = issue

  def setIssue(issue: BasicHubIssue): Unit = {
    this.issue = issue
    getOwner.asInstanceOf[util.Map[String, Object]].put("issue", issue)
  }

  override def call(args: Object*): Object =
    // we don't execute anything here - specifically, because it's supposed to be executed on the remote instance
    return null

}
