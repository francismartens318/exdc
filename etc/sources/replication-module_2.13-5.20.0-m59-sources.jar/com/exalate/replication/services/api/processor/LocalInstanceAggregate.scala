package com.exalate.replication.services.api.processor

import java.util

import com.exalate.basic.domain.hubobject.v1.BasicHubIssue
import groovy.lang.Closure

class LocalInstanceAggregate(var issue: BasicHubIssue)
    extends Closure[Object]({
      val container = new util.HashMap[String, Object](); container.put("issue", issue); container
    }) {

  def getIssue(): BasicHubIssue = issue

  def setIssue(issue: BasicHubIssue): Unit = {
    this.issue = issue
    getOwner.asInstanceOf[util.Map[String, Object]].put("issue", issue)
  }

  override def call(args: Object*): Object =
    if (args.length == 1 && args.head.isInstanceOf[Closure[Object]])
      args.head.asInstanceOf[Closure[Object]].call()
    else super.call(args)

}
