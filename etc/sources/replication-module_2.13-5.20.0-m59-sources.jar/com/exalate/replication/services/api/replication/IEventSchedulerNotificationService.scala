package com.exalate.replication.services.api.replication

import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.hubobject.IHubIssueReplica
import com.exalate.api.domain.twintrace.ITwinTrace
import com.exalate.api.domain.{IIssueKey, INonPersistentConnectContext}
import com.exalate.basic.domain.hubobject.v1.UpdateBasicHubIssue
import com.google.inject.ImplementedBy

@ImplementedBy(
  classOf[com.exalate.replication.services.replication.EventSchedulerNotificationService]
)
trait IEventSchedulerNotificationService {

  def scheduleExalateEvent(
      connection: IConnection,
      issueKey: IIssueKey,
      updateHubIssueOption: Option[UpdateBasicHubIssue] = None,
      issueOption: Option[IHubIssueReplica] = None
  ): Unit

  def scheduleExalateOrUpdateEvent(
      connection: IConnection,
      issueKey: IIssueKey,
      updateHubIssueOption: Option[UpdateBasicHubIssue] = None,
      issueOption: Option[IHubIssueReplica] = None
  ): Unit

  def scheduleUpdateEvent(
      connection: IConnection,
      issueKey: IIssueKey,
      basicHubIssue: Option[UpdateBasicHubIssue] = None
  ): Unit

  def scheduleUpdateEventForTwinTrace(
      twinTrace: ITwinTrace,
      issueKey: IIssueKey,
      basicHubIssue: Option[UpdateBasicHubIssue] = None
  ): Unit

  def scheduleConnectEvent(
      connection: IConnection,
      issueKey: IIssueKey,
      connectRemoteIssueUrn: String,
      connectContextOpt: Option[INonPersistentConnectContext],
      basicHubIssue: Option[UpdateBasicHubIssue] = None
  ): Unit

  def scheduleSyncEventNoChangeCheck(connection: IConnection, issueKey: IIssueKey): Unit
  def scheduleUnexalateEvent(connection: IConnection, issueKey: IIssueKey): Unit
  def scheduleCleanupEvent(connection: IConnection, issueKey: IIssueKey): Unit

  def scheduleCleanupEventForRemoteIssue(
      connection: IConnection,
      remoteIssueUrn: String,
      entityType: String
  ): Unit

  def scheduleCleanupEventForConnection(connectionId: Int, entityType: String): Unit
  def scheduleDeleteEvent(connection: IConnection, issueKey: IIssueKey): Unit

  def scheduleUpdateEvents(
      issueKey: IIssueKey,
      basicHubIssue: Option[UpdateBasicHubIssue] = None
  ): Unit

}
