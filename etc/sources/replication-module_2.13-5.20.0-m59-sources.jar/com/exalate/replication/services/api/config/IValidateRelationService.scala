package com.exalate.replication.services.api.config

import com.exalate.api.domain.connection.INonPersistentConnection
import com.exalate.replication.services.config.ValidateRelationService
import com.google.inject.ImplementedBy

import scala.concurrent.Future
import scala.util.Try

@ImplementedBy(classOf[ValidateRelationService])
trait IValidateRelationService {
  def validate(relation: INonPersistentConnection): Future[None.type]
  def validateCode(code: String, field: String): Try[None.type]
}
