package com.exalate.replication.services.api.error.retry

import com.exalate.api.domain.blob.event.IBlobEvent
import com.exalate.api.domain.blob.request.IBlobRequest
import com.exalate.api.domain.event.ISyncEvent
import com.exalate.api.domain.request.ISyncRequest
import com.exalate.api.exception.RetriableException
import com.exalate.replication.services.api.error.SyncContext
import com.exalate.replication.services.error.retry.RetryContextService
import com.google.inject.ImplementedBy

import scala.concurrent.Future

@ImplementedBy(classOf[RetryContextService])
trait IRetryContextService {
  def shouldRetry(syncRequestId: Int): Future[Boolean]
  def shouldRetry(syncEvent: ISyncEvent): Future[Boolean]
  def shouldRetry(blobEvent: IBlobEvent): Future[Boolean]
  def shouldRetry(blobRequest: IBlobRequest): Future[Boolean]
  def handle(exception: RetriableException, context: SyncContext): Future[None.type]
}
