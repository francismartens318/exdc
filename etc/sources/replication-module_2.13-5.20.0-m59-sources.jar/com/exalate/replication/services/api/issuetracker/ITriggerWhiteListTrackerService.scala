package com.exalate.replication.services.api.issuetracker

import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.hubobject.IHubIssueReplica
import com.google.inject.ImplementedBy

@ImplementedBy(classOf[DefaultTriggerWhiteListTrackerService])
trait ITriggerWhiteListTrackerService {

  def getProjectWhiteList(
      connection: IConnection,
      queryFilter: Option[String] = None
  ): Option[Seq[String]]

  def extractProject(connection: IConnection, replica: IHubIssueReplica): Option[String]
}
