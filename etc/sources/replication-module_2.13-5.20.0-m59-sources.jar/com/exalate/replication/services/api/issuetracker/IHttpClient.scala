package com.exalate.replication.services.api.issuetracker

trait IHttpClient {}
