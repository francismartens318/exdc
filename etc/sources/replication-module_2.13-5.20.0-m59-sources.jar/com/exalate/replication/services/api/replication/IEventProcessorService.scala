package com.exalate.replication.services.api.replication

import com.exalate.api.domain.event.ISyncEvent
import com.google.inject.ImplementedBy

import scala.concurrent.Future

@ImplementedBy(classOf[com.exalate.replication.services.replication.EventProcessorService])
trait IEventProcessorService {
  def processSyncEvents(): Future[Unit]
}
