package com.exalate.replication.services.api.node.lifecycle

import com.exalate.replication.services.node.lifecycle.MigrationService
import com.google.inject.ImplementedBy

/** Trait that would be injected to important services to ensure that implementations are
  * instantiated and executed before starting the whole application.
  */
@ImplementedBy(classOf[MigrationService])
trait IMigrationService
