package com.exalate.replication.services.api.transport.v3_6

import com.exalate.api.domain.connection.IConnection
import com.exalate.domain.values.NodeInfoValue
import com.exalate.domain.values.connection.{
  BasicConnectionRedirectUrlRequestValue,
  BasicConnectionRedirectUrlValue
}
import com.exalate.domain.values.v3_6.UpgradeBasicConnectionResponseValue
import com.exalate.replication.services.transport.v3_6.ExternalBasicConnectionClient
import com.google.inject.ImplementedBy

import scala.concurrent.Future

@ImplementedBy(classOf[ExternalBasicConnectionClient])
trait IExternalBasicConnectionClient {

  /** Makes a request to the remote side for upgrading connection from BASIC to either
    * CONFIGURE_BOTH_SIDES or SCRIPT POST /rest/issuehub/3.6/connections/:name/upgrade
    * @param connection
    * @param connectionMode
    *   \- CONFIGURE_BOTH_SIDES or SCRIPT
    * @param accessTokenOpt
    * @param nodeInfo
    * @return
    *   UpgradeBasicConnectionResponseValue
    */
  def upgradeRemoteSide(
      connection: IConnection,
      connectionMode: String,
      accessTokenOpt: Option[String],
      nodeInfo: NodeInfoValue
  ): Future[Option[UpgradeBasicConnectionResponseValue]]

  /** POST /rest/issuehub/3.6/urls/acceptbasicconnection/generate
    */
  def getRedirectForInvitation(
      basicConnectionRedirectUrlRequestValue: BasicConnectionRedirectUrlRequestValue
  ): Future[Option[BasicConnectionRedirectUrlValue]]

}
