package com.exalate.replication.services.api.transport.rest.v2

import com.exalate.api.domain.blob.event.IBlobEvent
import com.exalate.api.domain.blob.request.IBlobRequest
import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.event.ISyncEvent
import com.exalate.api.domain.request.ISyncRequest
import com.exalate.domain.replication.BasicSyncRequest
import com.exalate.replication.services.transport.v2_4.NotifyReceivedClient
import com.exalate.replication.services.transport.value.{BlobRequestValue, RequestValue}
import com.google.inject.ImplementedBy

import scala.concurrent.Future

@ImplementedBy(classOf[NotifyReceivedClient])
trait INotifyReceivedClient {

  @deprecated(
    "Will be removed in favor of `postRequestReceived(basicSyncRequest: BasicSyncRequest ...)`",
    "EXACOMP-1884"
  )
  def postRequestReceived(syncRequest: ISyncRequest): Future[None.type]

  def postRequestReceived(
      basicSyncRequest: BasicSyncRequest,
      connection: IConnection
  ): Future[None.type]

  def postRequestReceived(requestValue: RequestValue, connection: IConnection): Future[None.type]

  def postResponseReceived(syncEvent: ISyncEvent): Future[None.type]

  def postBlobRequestReceived(blobRequest: IBlobRequest): Future[None.type]

  def postBlobRequestReceived(
      blobRequestValue: BlobRequestValue,
      connection: IConnection
  ): Future[None.type]

  def postBlobResponseReceived(blobEvent: IBlobEvent): Future[None.type]

}
