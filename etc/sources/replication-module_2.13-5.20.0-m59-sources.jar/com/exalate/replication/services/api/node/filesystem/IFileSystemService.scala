package com.exalate.replication.services.api.node.filesystem

import com.google.inject.ImplementedBy

import java.io.File
import java.nio.file.Path
import scala.concurrent.Future
import scala.util.Try

@ImplementedBy(classOf[com.exalate.replication.services.node.filesystem.FileSystemService])
trait IFileSystemService {

  def deleteLocalFile(syncEventId: Int, getBlobId: String): Future[Boolean]

  def deleteFile(filePath: String): Future[Boolean]

  def deleteFile(file: File): Future[Boolean]

  def deleteLocalBlobForEvent(eventId: Int): Future[None.type]

  def findLocalBlob(filePath: String): Future[Option[File]]

  def getExalateScriptsPath(): Try[Path]

  def getSupportZipDataDir: Try[Path]

  def getLogPath: Try[Path]

  def createSupportZipDirectory: Try[Unit]

  def createSupportZipCsvFile(tableName: String): Try[File]

  def getExternalScripts: Try[Seq[Path]]

  def zipFiles(destinationPath: String, filePaths: Seq[Path]): Try[Unit]

  def removeExistingSupportZipDataIfExists(paths: Seq[Path]): Try[Unit]
}
