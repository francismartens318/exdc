package com.exalate.replication.services.api.supportzip

import com.exalate.replication.services.replication.supportzip.SupportZipTaskExecutor
import com.google.inject.ImplementedBy

import scala.concurrent.Future

@ImplementedBy(classOf[SupportZipTaskExecutor])
trait ISupportZipTaskExecutor {

  /** Executes Support Zip Generation Task
    * @return
    *   id of the task
    */
  def executeSupportZipGenerationTask(): Future[Int]

}
