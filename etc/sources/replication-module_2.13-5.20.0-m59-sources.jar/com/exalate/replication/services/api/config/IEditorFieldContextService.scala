package com.exalate.replication.services.api.config

import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.connection.fieldvalues.ConnectionMode
import com.exalate.api.domain.nodeinfo.INonPersistentNodeInfo

import scala.concurrent.Future

/** Send information about all fields and all options for these fields from side A and pushes it to
  * there remote side B. Then remote side B can use this information (to pick projects, issue types
  * etc. from side A) to configure visual connection and synchronize.
  */
trait IEditorFieldContextService {

  def pushEditorContext(
      mode: Option[ConnectionMode],
      isLocalConnection: Boolean,
      connectionFuture: Future[IConnection],
      nodeInfoFuture: Future[Option[INonPersistentNodeInfo]]
  ): Future[None.type]

}
