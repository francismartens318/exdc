package com.exalate.replication.services.api.processor

import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.hubobject.IHubIssueReplica
import com.exalate.api.domain.request.ISyncRequest
import com.exalate.api.domain.twintrace.INonPersistentTrace
import com.exalate.api.domain.{IBlobMetadata, IIssueKey}
import com.exalate.api.util.BindingUtil
import com.exalate.basic.domain.hubobject.v1.BasicHubIssue
import com.exalate.domain.editor.mappings.Mappings
import com.exalate.processor.ExalateProcessor
import com.exalate.replication.services.api.error.NotEnoughDataToCreateIssueProcessorException
import com.exalate.services.utils.FutureUtils
import groovy.lang.Closure

import java.util
import scala.util.Success

/** called from script like this: // one may also do store() store(issue)
  */
class StoreClosureAggregate(
    applyScriptResultService: IApplyScriptResultService,
    scriptVariableServiceFactory: IScriptVariableServiceFactory
) extends Closure[IHubIssueReplica](null) {

  override def call(args: Object*): IHubIssueReplica = {
    val scriptVariableService = scriptVariableServiceFactory.getScriptVariableService()
    val binding = ExalateProcessor.CURRENT_BINDINGS.get()
    val entities = binding.get("entities").asInstanceOf[Seq[IHubIssueReplica]]
    val entitiesBeforeUpdate =
      binding.get("entitiesBeforeUpdating").asInstanceOf[Seq[IHubIssueReplica]]
    val headObj = args.headOption.getOrElse {
      applyScriptResultService
        .getModifiedEntity(entitiesBeforeUpdate, entities) match {
        case Success(Some(e)) =>
          e
        case _                =>
          throw new NotEnoughDataToCreateIssueProcessorException(
            "The issue hub object has not been filled, can not create an issue!"
          )
      }
    }
    val entity = headObj.asInstanceOf[IHubIssueReplica]
    val entitiyBeforeUpdate = entitiesBeforeUpdate
      .find(_.getEntityName == entity.getEntityName)
      .get
    val entityIdOpt = Option(entity.getId)
    val entityKeyOpt = entity match {
      case issue: BasicHubIssue => Option(issue.getKey)
      case _                    => entityIdOpt
    }
    val syncRequest = binding.get("syncRequest").asInstanceOf[ISyncRequest]
    val traces = binding.get("traces").asInstanceOf[java.util.List[INonPersistentTrace]]
    val blobMetadataSeq = binding.get("blobMetadataSeq").asInstanceOf[Seq[IBlobMetadata]]

    val (localIssueKey, updatedTraces) = (entityIdOpt, entityKeyOpt) match {
      case (Some(_), Some(_)) =>
        val issueKeyOpt = Option(binding.get("issueKey"))
          .map(_.asInstanceOf[IIssueKey])
        val localIssueKey = issueKeyOpt.get
        val _updatedTraces = FutureUtils
          .toTry(
            applyScriptResultService.updateEntity(
              syncRequest,
              new util.HashMap[String, Object](binding),
              localIssueKey,
              traces,
              entity,
              entitiyBeforeUpdate,
              blobMetadataSeq
            )
          )
          .get
        (localIssueKey, _updatedTraces)
      case _                  =>
        FutureUtils
          .toTry(
            applyScriptResultService.createEntity(
              syncRequest,
              blobMetadataSeq,
              entitiyBeforeUpdate,
              entity
            )
          )
          .get
    }
    val replica = binding.get("replica").asInstanceOf[BasicHubIssue]
    val firstSync = binding.get("firstSync").asInstanceOf[java.lang.Boolean]
    val connection = binding.get("connection").asInstanceOf[IConnection]
    val previousOpt = Option(binding.get("previous")).map(_.asInstanceOf[IHubIssueReplica])
    val remoteIssueUrlOpt = Option(binding.get("remoteIssueUrl")).map(_.asInstanceOf[String])
    val log = binding.get("log").asInstanceOf[org.slf4j.Logger]
    val updatedContext = FutureUtils
      .toTry(
        scriptVariableService.createIncomingSyncContext(
          replica,
          firstSync,
          connection,
          syncRequest,
          previousOpt,
          remoteIssueUrlOpt,
          Option(localIssueKey),
          blobMetadataSeq,
          updatedTraces,
          log
        )
      )
      .get

    val mappingOpt = Option(updatedContext.get("mappings"))
      .map(_.asInstanceOf[Mappings])
    val swapSidesOpt = Option(updatedContext.get("swapSides"))
      .map(_.asInstanceOf[java.lang.Boolean])
    val sendingInstanceNameOpt = Option(updatedContext.get("sendingInstanceName"))
      .map(_.asInstanceOf[String])
    val executionInstanceNameOpt = Option(updatedContext.get("executionInstanceName"))
      .map(_.asInstanceOf[String])
    val contextWithEditor =
      (mappingOpt, swapSidesOpt, sendingInstanceNameOpt, executionInstanceNameOpt) match {
        case (Some(m), Some(swapSides), Some(sendingInstanceName), Some(executionInstanceName)) =>
          scriptVariableService
            .updateIncomingSyncContext(
              updatedContext,
              connection,
              entity.asInstanceOf[BasicHubIssue],
              replica,
              m,
              swapSides,
              sendingInstanceName,
              executionInstanceName
            )
        case _ => updatedContext
      }

    BindingUtil
      .putAllIntoBinding(contextWithEditor, binding)

    val updatedEntity = updatedContext
      .get("entities")
      .asInstanceOf[Seq[IHubIssueReplica]]
      .find(_.getEntityName == entity.getEntityName)
      .orNull

    updatedEntity
  }

}
