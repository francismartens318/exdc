package com.exalate.replication.services.api.issuetracker

import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.hubobject.IHubIssueReplica

class DefaultTriggerWhiteListTrackerService extends ITriggerWhiteListTrackerService {

  def getProjectWhiteList(
      connection: IConnection,
      queryFilter: Option[String] = None
  ): Option[Seq[String]] = None

  def extractProject(connection: IConnection, replica: IHubIssueReplica): Option[String] = None
}
