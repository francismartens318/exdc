package com.exalate.replication.services.api.replication.oauth

import com.exalate.api.domain.oauth.IOAuthData
import com.exalate.domain.oauth.OAuthClient
import com.exalate.replication.services.replication.oauth.OAuthService
import com.exalate.replication.services.transport.value.oauth._
import com.google.inject.ImplementedBy

import scala.concurrent.Future
import com.exalate.replication.services.transport.value.oauth.{
  AccessTokenStatusValue,
  OAuthAccessTokenValue,
  OAuthClientRegResponseValue,
  OAuthGenerateAccessTokenValue,
  OAuthGenerateAuthorizationCodeReqValue,
  OAuthGenerateAuthorizationCodeResValue,
  OAuthStartReqValue,
  OAuthUrlResValue,
  RegisterOAuthClientResValue
}

@ImplementedBy(classOf[OAuthService])
trait IOAuthService {

  /** caution only use this in background tasks, that are only scheduled if authorization was
    * checked
    */
  def getAccessToken(instanceUid: String): Future[Option[String]]

  /** Use this one instead of getAccessToken(instanceUid)
    * @param instanceUid
    * @return
    */
  def findFirstOAuthDataWithAccessToken(instanceUid: String): Future[Option[IOAuthData]]

  def findFirstValidOAuthDataWithAccessTokenAndRemoveIfRevoked(
      instanceUid: String
  ): Future[Option[IOAuthData]]

  def findFirstOAuthDataWithAccessToken(
      instanceUid: String,
      exaUser: String
  ): Future[Option[IOAuthData]]

  def validateToken(token: String): Future[None.type]

  def start(req: OAuthStartReqValue, userKey: String): Future[Option[OAuthClientRegResponseValue]]

  def oauthContinue(req: OAuthContinueValue): Future[None.type]

  def generate(
      req: OAuthGenerateAuthorizationCodeReqValue
  ): Future[Option[OAuthGenerateAuthorizationCodeResValue]]

  def register(
      clientName: String,
      clientUri: String,
      redirectUris: Seq[String],
      grantTypes: Seq[String],
      scope: String
  ): Future[RegisterOAuthClientResValue]

  def generateUrl(
      `type`: String,
      clientId: String,
      redirectUri: String,
      responseType: String,
      scope: String,
      state: String,
      code: Option[String],
      clientJwtOpt: Option[String]
  ): Future[OAuthUrlResValue]

  def generateAccessToken(
      oauthGenerateAccessTokenValue: OAuthGenerateAccessTokenValue,
      clientJwtOpt: Option[String]
  ): Future[OAuthAccessTokenValue]

  def getAccessTokenStatus(state: String): Future[AccessTokenStatusValue]

  def getTokens(connectionId: Int): Future[Seq[IOAuthData]]

  def deleteTokens(connectionId: Int): Future[None.type]

  def generateClientSecret(lengthOfSecret: Int): String

  def hasValidRemoteAccessToken(
      validateAccessTokenReqValue: ValidateAccessTokenReqValue
  ): Future[ValidateAccessTokenResValue]

  def checkExistingOAuthData(
      req: OAuthStartReqValue,
      userKey: String
  ): Future[ValidateAccessTokenResValue]

  def getClient(clientId: String): Future[Option[OAuthClient]]
}
