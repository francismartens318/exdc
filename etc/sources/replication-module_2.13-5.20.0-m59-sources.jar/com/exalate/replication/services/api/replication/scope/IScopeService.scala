package com.exalate.replication.services.api.replication.scope

import com.exalate.api.domain.IIssueKey
import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.editor.scopes.TriggerCriteria
import com.exalate.api.domain.hubobject.{EventTriggerContext, IHubIssueReplica}
import com.exalate.api.domain.request.ISyncRequest
import com.exalate.basic.domain.hubobject.v1.BasicHubIssue
import com.exalate.domain.editor.scopes.ScopeValue
import com.exalate.domain.values.connection.ConnectionValue
import com.exalate.replication.services.replication.scope.ScopeService
import com.google.inject.ImplementedBy

import scala.concurrent.Future

@ImplementedBy(classOf[ScopeService])
trait IScopeService {

  /** Checks if the issue matches either of the scopes if connection option is provided, then only
    * runs the scopes for that particular connection
    */
  def executeScopesForAutomatic(
      issueKey: IIssueKey,
      context: EventTriggerContext = EventTriggerContext.empty()
  ): Future[None.type]

  def executeScopesForManual(
      issueKey: IIssueKey,
      connection: IConnection,
      context: EventTriggerContext = EventTriggerContext.empty()
  ): Future[None.type]

  def receive(
      replica: IHubIssueReplica,
      issue: BasicHubIssue,
      connectionId: Int,
      syncRequest: ISyncRequest
  ): Future[BasicHubIssue]

  def processScopes(
      connection: IConnection,
      connectionValue: ConnectionValue
  ): Future[Seq[ScopeValue]]

}
