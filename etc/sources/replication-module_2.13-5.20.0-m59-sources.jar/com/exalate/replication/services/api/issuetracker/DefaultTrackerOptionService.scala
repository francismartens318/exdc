package com.exalate.replication.services.api.issuetracker

import com.exalate.domain.transport.trackeroptions.{IssueTrackerOption, IssueTrackerOptionDependency}
import com.exalate.domain.values.EditorFieldValue
import com.exalate.services.utils.pagination.Page

import scala.concurrent.Future

class DefaultTrackerOptionService extends ITrackerOptionService {

  override def fetchProjectOptionsStream(
      context: Option[Seq[IssueTrackerOptionDependency]],
      userKey: Option[String] = None
  ): Stream[Future[Page[IssueTrackerOption]]] = Stream.empty

  override def fetchIssuetypeOptions(
      context: Option[Seq[IssueTrackerOptionDependency]]
  ): Stream[Future[Page[IssueTrackerOption]]] = Stream.empty

  override def fetchStatusOptions(
      context: Option[Seq[IssueTrackerOptionDependency]]
  ): Stream[Future[Page[IssueTrackerOption]]] = Stream.empty

  override def fetchPriorityOptions(
      context: Option[Seq[IssueTrackerOptionDependency]]
  ): Stream[Future[Page[IssueTrackerOption]]] = Stream.empty

  override def fetchCustomFieldOptions(
      editorFieldValue: EditorFieldValue,
      context: Option[Seq[IssueTrackerOptionDependency]]
  ): Stream[Future[Page[IssueTrackerOption]]] = Stream.empty

}
