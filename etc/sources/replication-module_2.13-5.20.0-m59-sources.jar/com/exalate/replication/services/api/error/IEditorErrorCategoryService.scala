package com.exalate.replication.services.api.error

import com.exalate.api.domain.request.ISyncRequest
import com.exalate.api.exception.CategorizedException
import com.exalate.basic.domain.hubobject.v1.BasicHubIssue
import com.exalate.domain.values.{EditorFieldErrorValue, EditorFieldValue}
import com.exalate.replication.services.error.EditorErrorCategoryService
import com.google.inject.ImplementedBy

import scala.concurrent.Future

@ImplementedBy(classOf[EditorErrorCategoryService])
trait IEditorErrorCategoryService {

  def toEditorError(
      editorFieldErrorValue: Seq[EditorFieldErrorValue],
      syncRequest: ISyncRequest,
      hubIssue: BasicHubIssue
  ): Future[CategorizedException]

}
