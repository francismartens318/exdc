package com.exalate.replication.services.api.replication.metric

import com.exalate.domain.metrics.MetricsValue
import com.exalate.replication.services.replication.metric.MetricService
import com.google.inject.ImplementedBy

import scala.concurrent.Future

@ImplementedBy(classOf[MetricService])
trait IMetricService {

  /** Saves metricsValue obtained from front end to the DB and return `eventKey`
    * @param metricsValues
    * @return
    *   eventKey
    */
  def addEvent(metricsValues: Seq[MetricsValue]): Future[Option[String]]
}
