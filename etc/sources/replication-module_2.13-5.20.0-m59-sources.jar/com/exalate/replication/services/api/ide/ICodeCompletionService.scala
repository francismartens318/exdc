package com.exalate.replication.services.api.ide

import com.exalate.domain.values.ide.SuggestionValue
import com.exalate.replication.services.ide.DefaultCodeCompletionService
import com.google.inject.ImplementedBy

import scala.concurrent.Future

/** This trait will be implemented per tracker to provide list of suggestions to auto complete in
  * IDE. It can comprised of custom fields, helpers etc.
  */
@ImplementedBy(classOf[DefaultCodeCompletionService])
trait ICodeCompletionService {
  def suggestions: Future[Seq[SuggestionValue]]
}
