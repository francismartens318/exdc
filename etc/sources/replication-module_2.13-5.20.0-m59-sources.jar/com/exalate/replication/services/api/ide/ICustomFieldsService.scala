package com.exalate.replication.services.api.ide

import com.exalate.domain.values.ide.SuggestionValue

import scala.concurrent.Future

/** This trait will be implemented per tracker to provide suggestion for custom fields.
  */
trait ICustomFieldsService {
  def customFields: Future[Seq[SuggestionValue]]
}
