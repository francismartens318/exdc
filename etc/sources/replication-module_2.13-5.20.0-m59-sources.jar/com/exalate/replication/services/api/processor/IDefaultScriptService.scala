package com.exalate.replication.services.api.processor

import com.exalate.replication.services.transport.value.DefaultScriptValue
import com.google.inject.ImplementedBy

import scala.concurrent.Future

@ImplementedBy(classOf[com.exalate.replication.services.processor.DefaultScriptService])
trait IDefaultScriptService {
  def getDefaultScript(connectionId: Int): Future[DefaultScriptValue]
}
