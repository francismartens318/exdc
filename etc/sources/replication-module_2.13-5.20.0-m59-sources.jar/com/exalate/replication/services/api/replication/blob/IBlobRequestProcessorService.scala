package com.exalate.replication.services.api.replication.blob

import com.google.inject.ImplementedBy

import scala.concurrent.Future

@ImplementedBy(
  classOf[com.exalate.replication.services.replication.blob.in.BlobRequestProcessorService]
)
trait IBlobRequestProcessorService {

  /** Process blob requests, it is called from RequestWorkerActor Namely, it preprocess blobs by
    * calling {@link processPages} , updates Sync Request Status in DB, sends Process Requests
    * Notification and finally deletes BlobRequests from DB
    */
  def processBlobRequests(): Future[Unit]
}
