package com.exalate.replication.services.api.node

import com.exalate.api.exception.VerifyCodeErrors
import com.exalate.replication.services.node.lifecycle.NodeUrlHelper
import com.google.inject.ImplementedBy

@ImplementedBy(classOf[NodeUrlHelper])
trait INodeUrlHelper {

  /** @param exalateUrl
    *   allows to detect if node is registered in mapper
    * @param path
    *   part of url (/verifysuccess, /verifysupport) - used to show appropriate screen on UI
    * @param code
    *   used to show appropriate message on UI/flag
    * @return
    *   Full url to redirect to.
    */
  def getRedirectUrl(exalateUrl: String, path: String, code: VerifyCodeErrors): String
}
