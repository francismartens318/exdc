package com.exalate.replication.services.api.issuetracker

import com.exalate.basic.domain.hubobject.v1.BasicHubComment
import com.exalate.domain.issuetracker.IEntityUpdateContext
import play.api.libs.json.JsValue

import scala.concurrent.Future

class DefaultTrackerCommentService extends ITrackerCommentService {

  override def removeComment[C <: IEntityUpdateContext](
      commentId: String,
      context: C
  ): Future[None.type] = Future.successful(None)

  override def createComment[C <: IEntityUpdateContext](
      comment: BasicHubComment,
      userBehalfOnOpt: Option[String],
      context: C
  ): Future[(String, JsValue)] = ???

  override def updateComment[C <: IEntityUpdateContext](
      comment: BasicHubComment,
      userBehalfOnOpt: Option[String],
      context: C
  ): Future[Option[(String, JsValue)]] = Future.successful(None)

  override def getUserKey(u: String): Option[String] = None
}
