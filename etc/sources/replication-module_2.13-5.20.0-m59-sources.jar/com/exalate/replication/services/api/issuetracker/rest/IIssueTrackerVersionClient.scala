package com.exalate.replication.services.api.issuetracker.rest

import com.exalate.domain.InferredGeneralSettings
import com.exalate.replication.services.issuetracker.IssueTrackerVersionClient
import com.google.inject.ImplementedBy

import scala.concurrent.Future

@ImplementedBy(classOf[IssueTrackerVersionClient])
trait IIssueTrackerVersionClient {
  def getSiteVersionsJsonString(sett: InferredGeneralSettings): Future[String]
}
