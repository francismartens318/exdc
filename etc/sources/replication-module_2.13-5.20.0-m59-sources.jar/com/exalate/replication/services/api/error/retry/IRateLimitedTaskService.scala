package com.exalate.replication.services.api.error.retry

import scala.concurrent.Future

/** Implemented to ensure that Exalate can work with Issue Trackers that have rate limits on their
  * API Allows to submit a task (fn), that could fail with a
  * `com.exalate.domain.exception.network.RateLimitException` In which case, this task would be
  * postponed until `com.exalate.domain.exception.network.RateLimitException#nextRetry` or
  * Exponential back-off
  */
trait IRateLimitedTaskService {
  def doRateLimitedTask[R](task: () => Future[R]): Future[R]
}
