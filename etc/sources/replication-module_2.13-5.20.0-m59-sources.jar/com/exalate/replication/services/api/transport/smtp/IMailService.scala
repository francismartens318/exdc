package com.exalate.replication.services.api.transport.smtp

import com.exalate.api.domain.IError
import com.exalate.api.exception.CategorizedException
import com.google.inject.ImplementedBy

import java.sql.Timestamp
import java.util
import javax.annotation.{Nonnull, Nullable}
import scala.concurrent.Future

@ImplementedBy(classOf[com.exalate.replication.services.transport.smtp.MailService])
trait IMailService {

  /** Send error notification email to all the registered exalate administrators This method
    * performs persistence operation to get the email of the administrators
    * @param error
    *   the error which the administrator will be notified about
    */
  def sendErrorMail(error: IError): Future[None.type]

  def sendLicenseMail(startOfCurrentPeriod: Timestamp): Future[None.type]

  def sendArchiveWarningMail(archiveWarningDays: Int): Future[None.type]

  /** Jiranode
    */
  /** Send an email to the specified recipient @to with the @subject and @body
    */
  @throws(classOf[CategorizedException])
  def sendEmail(
      @Nonnull to: String,
      @Nullable subject: String,
      @Nullable body: String,
      @Nullable cc: String
  ): Unit = ???

  /** Based on the {@code error} information passed by parameter, send an error email to all the
    * administrators
    */
  @throws(classOf[CategorizedException])
  def sendErrorEmail(@Nonnull adminAddresses: util.Collection[String], @Nonnull error: IError): Unit =
    ???

}
