package com.exalate.replication.services.api.replication

import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.event.ISyncEvent
import com.exalate.api.domain.hubobject.IHubPayload
import com.exalate.api.domain.twintrace.ITwinTrace
import com.exalate.api.domain.{IIssueKey, INonPersistentConnectContext}
import com.google.inject.ImplementedBy

import scala.concurrent.Future

@ImplementedBy(classOf[com.exalate.replication.services.replication.EventSchedulerService])
trait IEventSchedulerService {

  def scheduleExalateEvent(
      connection: IConnection,
      issueKey: IIssueKey,
      payload: IHubPayload,
      twinTraceOpt: Option[ITwinTrace]
  ): Future[Option[ISyncEvent]]

  def schedulePairOrSyncEvent(
      connection: IConnection,
      issueKey: IIssueKey,
      payload: IHubPayload,
      twinTraceOpt: Option[ITwinTrace]
  ): Future[Option[ISyncEvent]]

  def scheduleUpdateEvent(
      connection: IConnection,
      issueKey: IIssueKey,
      payload: IHubPayload,
      twinTraceOpt: Option[ITwinTrace]
  ): Future[Option[ISyncEvent]]

  def scheduleConnectEvent(
      connection: IConnection,
      issueKey: IIssueKey,
      payload: IHubPayload,
      connectRemoteIssueUrn: String,
      connectContextOpt: Option[INonPersistentConnectContext]
  ): Future[Option[ISyncEvent]]

  def scheduleSyncEventNoChangeCheck(
      connection: IConnection,
      issueKey: IIssueKey
  ): Future[Option[ISyncEvent]]

  def scheduleUnexalateEvent(connection: IConnection, issueKey: IIssueKey): Future[Option[ISyncEvent]]
  def scheduleCleanupEvent(connection: IConnection, issueKey: IIssueKey): Future[Option[ISyncEvent]]

  def scheduleCleanupEventForRemoteIssue(
      connection: IConnection,
      remoteIssueUrn: String,
      entityType: String
  ): Future[Option[ISyncEvent]]

  def scheduleCleanupEventForConnection(connectionId: Int, entityType: String): Future[None.type]
  def scheduleDeleteEvent(connection: IConnection, issueKey: IIssueKey): Future[Option[ISyncEvent]]
}
