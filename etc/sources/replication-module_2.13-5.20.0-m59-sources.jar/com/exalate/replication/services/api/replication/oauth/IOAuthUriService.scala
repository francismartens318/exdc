package com.exalate.replication.services.api.replication.oauth

import com.exalate.replication.services.replication.oauth.NotImplementedOAuthUriService
import com.google.inject.ImplementedBy

import scala.concurrent.Future

@ImplementedBy(classOf[NotImplementedOAuthUriService])
trait IOAuthUriService {

  /** Node provides URL to be redirected after authorization is accepted. It should be a registered
    * route to exalate, for example `/connections``
    * @return
    *   List of redirect URI's
    */
  def getRedirectUris(): Future[Seq[String]]

  /** Node provides Client URL. This will be exalate's URL
    * @return
    *   Client URL
    */
  def getClientUri(): Future[String]

  /** Node provides URL to authorization server. On most cases it will be the URL of the issue
    * tracker instance
    * @param clientId
    * @param responseType
    * @param scope
    * @param state
    * @param redirectUri
    * @return
    *   Authorization URL
    */
  def getAuthorizationUri(
      clientId: String,
      responseType: String,
      scope: String,
      state: String,
      redirectUri: String
  ): Future[String]

}
