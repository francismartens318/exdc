package com.exalate.replication.services.api.ide

import com.exalate.replication.services.ide.NotSupportedGroovyLspService
import com.google.inject.ImplementedBy
import play.api.mvc.WebSocket

@ImplementedBy(classOf[NotSupportedGroovyLspService])
trait IGroovyLspService {
  def webSocket: WebSocket
}
