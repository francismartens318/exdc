package com.exalate.replication.services.api.hubobject

import com.exalate.api.domain.{IIssueKey, INonPersistentReplica, IPersistentReplica}
import com.exalate.api.domain.hubobject.{IHubIssuePayload, IHubPayload}
import com.google.inject.ImplementedBy

import scala.util.Try

@ImplementedBy(classOf[com.exalate.replication.services.hubobject.ReplicaHelper])
trait IReplicaHelper {

  def createNonPersistentReplica(
      issueKey: IIssueKey,
      summary: Option[String],
      payload: IHubPayload
  ): INonPersistentReplica

  def hasChanges(prevReplica: IPersistentReplica, newReplica: INonPersistentReplica): Boolean
  def toNonPersistentReplica(replica: IPersistentReplica): INonPersistentReplica
  def toHubPayload(payloadStr: String): Try[IHubPayload]
  def toHubIssuePayload(payloadStr: String): Try[IHubIssuePayload]
}
