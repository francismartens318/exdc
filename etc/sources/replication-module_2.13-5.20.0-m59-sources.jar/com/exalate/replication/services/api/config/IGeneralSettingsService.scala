package com.exalate.replication.services.api.config

import com.exalate.domain.values.v4.GeneralSettingsJson
import com.exalate.domain.{GeneralSettings, InferredGeneralSettings}
import com.exalate.replication.services.config.GeneralSettingsService
import com.google.inject.ImplementedBy
import play.api.libs.json.JsValue

import scala.concurrent.Future

@ImplementedBy(classOf[GeneralSettingsService])
trait IGeneralSettingsService {
  def get: Future[Option[InferredGeneralSettings]]
  def upsert(generalSettingsVal: GeneralSettings): Future[GeneralSettings]
  def delete: Future[None.type]

  def getExtraGSFieldsWithValues(
      allGsFieldValues: Map[String, String],
      generalSettingsJson: GeneralSettingsJson
  ): Map[String, Map[String, JsValue]]

}
