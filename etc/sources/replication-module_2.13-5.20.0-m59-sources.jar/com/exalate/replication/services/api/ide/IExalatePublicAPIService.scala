package com.exalate.replication.services.api.ide

import com.exalate.domain.values.ide.SuggestionValue
import com.exalate.replication.services.ide.{
  DefaultAttachmentHelperPublicAPIService,
  DefaultEntityPublicAPIService,
  DefaultNodeHelperPublicAPIService,
  DefaultReplicaPublicAPIService,
  DefaultWorkFlowHelperPublicAPIService,
  DefaultWorkLogHelperPublicAPIService
}
import com.google.inject.ImplementedBy

import scala.concurrent.Future

/** this trait is not suppose to use directly.
  */
sealed trait IExalatePublicAPIService {
  def apis: Future[Seq[SuggestionValue]]
}

@ImplementedBy(classOf[DefaultEntityPublicAPIService])
trait IEntityPublicAPIService extends IExalatePublicAPIService

@ImplementedBy(classOf[DefaultReplicaPublicAPIService])
trait IReplicaPublicAPIService extends IExalatePublicAPIService

@ImplementedBy(classOf[DefaultNodeHelperPublicAPIService])
trait INodeHelperPublicAPIService extends IExalatePublicAPIService

@ImplementedBy(classOf[DefaultAttachmentHelperPublicAPIService])
trait IAttachmentHelperPublicAPIService extends IExalatePublicAPIService

@ImplementedBy(classOf[DefaultWorkFlowHelperPublicAPIService])
trait IWorkFlowHelperPublicAPIService extends IExalatePublicAPIService

@ImplementedBy(classOf[DefaultWorkLogHelperPublicAPIService])
trait IWorkLogHelperPublicAPIService extends IExalatePublicAPIService
