package com.exalate.replication.services.api.trigger

import com.exalate.replication.services.replication.worker.UpdateEventPollerWorkerActor
import com.exalate.replication.services.trigger.{
  TrackerUpdatePollNoScheduleService,
  TrackerUpdatePollSchedulerService
}
import com.google.inject.ImplementedBy

import scala.util.Try

/** Service that on app startup schedules once to send the "PollForUpdateEvents"-message to the
  * [[UpdateEventPollerWorkerActor]] There are 2 implementations:
  * [[TrackerUpdatePollNoScheduleService]] - for nodes that don't support polling, but have webhooks
  * [[TrackerUpdatePollSchedulerService]] - for nodes that support polling If node supports polling,
  * TrackerUpdatePollSchedulerService should be bind in DiModule, otherwise
  * TrackerUpdatePollNoScheduleService would be used.
  */
@ImplementedBy(classOf[TrackerUpdatePollNoScheduleService])
trait ITrackerUpdatePollSchedulerService {

  def addSchedule(): Try[None.type]

  def removeAllSchedules(): Try[None.type]

}
