package com.exalate.replication.services.api.processor

import com.google.inject.ImplementedBy

@ImplementedBy(classOf[com.exalate.replication.services.processor.StoreClosureFactory])
trait IStoreClosureFactory {
  def create(): StoreClosureAggregate
}
