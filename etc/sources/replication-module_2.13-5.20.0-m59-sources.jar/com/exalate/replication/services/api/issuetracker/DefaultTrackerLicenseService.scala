package com.exalate.replication.services.api.issuetracker

import com.exalate.domain.values.license.LicenseValue

import scala.concurrent.Future

class DefaultTrackerLicenseService extends ITrackerLicenseService {

  override def getTrackerProvidedLicense: Future[Option[LicenseValue]] = Future.successful(None)

  override def setTrackerLicense(licenseKey: String): Future[None.type] = Future.successful(None)

  override def removeTrackerLicense: Future[None.type] = Future.successful(None)

  override def isTrackerLicenseValid(licenseKey: String): Future[Boolean] = Future.successful(false)

  override def getVolumeLimitAndUsedFuture: Future[Option[(Int, Int)]] = Future.successful(None)

  override def getVolumeLimitAndUsed: (Int, Int) =
    (-1, 0) // returns (-1, 0) in case there is no limit

  override def hasTrackerLicense: Future[Boolean] = Future.successful(false)
}
