package com.exalate.replication.services.api.config

import com.exalate.api.domain.connection._
import com.exalate.api.domain.instance.INonPersistentInstance
import com.exalate.api.domain.nodeinfo.INonPersistentNodeInfo
import com.exalate.domain.editor.mappings.MappingValue
import com.exalate.domain.editor.scopes.ScopeValue
import com.exalate.domain.transport.message.ExalateMessage
import com.exalate.domain.values.connection._
import com.exalate.domain.values.v2_5.connection.AcceptInvitationValue
import com.exalate.domain.values.v4.{ConnectionInfoValue, ConnectionNameValue}
import com.exalate.domain.values.{ConnectionInfo, NodeInfoValue, PageRequest, PaginationValueWrite}
import com.exalate.replication.services.api.config.IConnectionService.ConnectionId
import com.exalate.replication.services.config.ConnectionService
import com.google.inject.ImplementedBy

import scala.concurrent.Future
import scala.util.Try

@ImplementedBy(classOf[ConnectionService])
trait IConnectionService {

  def get(connectionName: String): Future[Option[IConnection]]

  def get(connectionId: Int): Future[Option[IConnection]]

  def findAllIds(projectId: Option[String] = None): Future[Seq[ConnectionId]]

  def findAllSimplified(
      fieldValues: Map[String, String] = Map.empty,
      connectionNameOpt: Option[String] = None,
      projectId: Option[String] = None,
      pageRequest: PageRequest = PageRequest.ALL
  ): Future[(Seq[IConnection], Int)]

  def validateAndPrepareInvitation(invitationValue: InvitationValue): Future[InvitationValue]

  def deleteConnectionAndUsage(connection: IConnection): Future[None.type]

  def getConnectionContext(relationId: Int): Future[Option[ConnectionInfoValue]]

  def initiate(
      nonPersistentConnection: INonPersistentConnection,
      adminUserKeyOpt: Option[String]
  ): Future[(String, IConnection)]

  def accept(
      connection: INonPersistentConnection,
      iv: InvitationValue,
      adminUserKey: Option[String]
  ): Future[(String, IConnection)]

  def update(
      connectionId: Int,
      nonPersConnection: INonPersistentConnection,
      scopes: Seq[ScopeValue],
      mappings: Seq[MappingValue],
      accessToken: Option[String]
  ): Future[IConnection]

  def prepareConnectionDraftValueRequestJsonStr(
      connection: IConnection,
      connectionDraftOpt: Option[ConnectionDraft],
      scopes: Seq[ScopeValue],
      mappings: Seq[MappingValue],
      accessToken: Option[String]
  ): Future[Option[ConnectionDraftRequestValue]]

  def updateFromConnectionDraftRequestMessageAndPrepareResponse(
      exaMsg: ExalateMessage
  ): Future[ConnectionDraftResponseValue]

  def updateConnectionDraftFromResponseMessage(exaMsg: ExalateMessage): Future[None.type]

  def applyAcceptedInvitationMessage(
      connectionName: String,
      acceptInvitationValue: AcceptInvitationValue
  ): Future[None.type]

  def updateInvitationStatus(
      connectionName: String,
      invitationStatus: InvitationStatus
  ): Future[IConnection]

  def getInvitationAcceptedMessage(connection: IConnection): Future[Option[AcceptInvitationValue]]

  def acceptInvitation(connection: IConnection): Future[IConnection]

  def validateScripts(script: String, field: String): Try[None.type]

  def getInvitationMessageForInviting(connection: IConnection): Future[InvitationGenerateResultValue]
  def getInvitationForAccepting(connection: IConnection): Future[InvitationValue]

  def resendInvitationAcceptedMessage(): Future[None.type]

  def pollForAcceptedMessage(): Future[None.type]

  def reviewInvitationStatus(): Future[None.type]

  def test(nonPersistentInstance: INonPersistentInstance): Future[INonPersistentNodeInfo]

  /** Generates invitation code for BASIC connection.
    * @param connection
    */
  def getInvitationForBasicConnection(connection: IConnection): Future[InvitationGenerateResultValue]

  /** Performs upgrade of the connection, when request is coming from UI
    * @param connection
    * @param connectionMode
    *   \- new mode: CONFIGURE_BOTH_SIDES or SCRIPT
    * @return
    */
  def upgradeConnectionFromUI(connection: IConnection, connectionMode: String): Future[IConnection]

  /** Performs upgrade of the connection, when request is coming from the remote side.
    * @param connection
    * @param connectionMode
    *   \- new mode: CONFIGURE_BOTH_SIDES or SCRIPT
    * @return
    */
  def upgradeConnectionFromRemote(
      connection: IConnection,
      connectionMode: String,
      accessTokenOpt: Option[String],
      nodeInfo: NodeInfoValue
  ): Future[None.type]

  /** Generates visual rules, when upgrade of the connection is performed from BASIC to
    * CONFIGURE_BOTH_SIDES (visual)
    * @param connection
    * @param accessToken
    * @return
    */
  def generateVisualRulesFromBasic(
      connection: IConnection,
      accessToken: Option[String]
  ): Future[IConnection]

  /** Changes mode of the connection from BASIC to one of the following : CONFIGURE_BOTH_SIDES or
    * SCRIPT
    * @param connection
    * @param connectionMode
    * @return
    */
  def changeMode(connection: IConnection, connectionMode: String): Future[IConnection]

  def generateConnectionName(remoteBaseUrl: String): Future[ConnectionNameValue]

  /** Collect connection info for monitoring
    *
    * @return
    *   result similar to this one: [{ "name":"dmytrodev_to_denyskozak3", "mode":"BASIC",
    *   "wasUpgraded":false, "lastSuccessfulSyncDate":"18/Mar/2021 09:56:10",
    *   "numberOfIssuesUnderSync":1, "numberOfNodeLevelErrors":0, "numberOfConnectionLevelErrors":0,
    *   "numberOfTriggerLevelErrors":0, "numberOfIssueLevelErrors":0,
    *   "numberOfWarningLevelErrors":0, "remoteIssueTrackerUrl":"https://denyskozak3.atlassian.net",
    *   "remoteExalateUrl":"https://denys-kozak.exalate.st", "connectionType":"public",
    *   "isSyncedFirstIssue":false, "establishingMetrics":[
    *
    * ] }]
    */
  def getConnectionInfo(): Future[Seq[ConnectionInfo]]

  def getConnectionsPaginated(
      offset: Option[Int],
      limit: Option[Int],
      sorting: List[String],
      projectId: Option[String],
      connectionName: Option[String],
      relationIssueTrackerSettingsFieldValuesKeys: Set[String]
  ): Future[PaginationValueWrite[ConnectionValueForList]]

  def deactivateAllConnections(): Future[None.type]
}

object IConnectionService {
  type ConnectionId = Int
}
