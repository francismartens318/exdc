package com.exalate.replication.services.api.config

import com.exalate.api.domain.error.IErrorInfo
import com.exalate.api.domain.twintrace.SyncStatus
import com.exalate.basic.domain.syncstatus.RemoteIssueUrlContext

sealed trait RemoteIssueContext
object Private extends RemoteIssueContext
case class Public(remoteIssueContext: Option[RemoteIssueUrlContext]) extends RemoteIssueContext

case class SyncStatusBean(
    status: SyncStatus,
    errorInfo: IErrorInfo,
    twinTraceId: Int,
    relationName: String,
    showLink: Boolean,
    remoteIssueContext: RemoteIssueContext,
    connectionId: Int,
    localEntitySummary: Option[String]
)

case class SyncStatusesBean(syncStatuses: Set[SyncStatusBean], belongsToProject: Boolean = true)
