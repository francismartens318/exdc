package com.exalate.replication.services.api.issuetracker

import com.exalate.domain.values.license.LicenseValue
import com.google.inject.ImplementedBy

import scala.concurrent.Future

@ImplementedBy(classOf[DefaultTrackerLicenseService])
trait ITrackerLicenseService {

  def getTrackerProvidedLicense: Future[Option[LicenseValue]] = Future.successful(None)

  // TODO: extract to Jiranode
  def setTrackerLicense(licenseKey: String): Future[None.type] = Future.successful(None)

  // TODO: extract to Jiranode
  def removeTrackerLicense: Future[None.type] = Future.successful(None)

  // TODO not used
  def isTrackerLicenseValid(licenseKey: String): Future[Boolean] = Future.successful(false)

  def getVolumeLimitAndUsedFuture: Future[Option[(Int, Int)]] = Future.successful(None)

  // TODO: extract to Jiranode
  def getVolumeLimitAndUsed: (Int, Int) = (-1, 0) // returns (-1, 0) in case there is no limit

  def hasTrackerLicense: Future[Boolean]
}
