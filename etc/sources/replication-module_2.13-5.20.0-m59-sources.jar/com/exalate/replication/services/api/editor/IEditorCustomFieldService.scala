package com.exalate.replication.services.api.editor

import com.exalate.domain.values.EditorFieldValue
import com.exalate.replication.services.editor.DefaultEditorCustomFieldService
import com.google.inject.ImplementedBy

import scala.concurrent.Future

@ImplementedBy(classOf[DefaultEditorCustomFieldService])
trait IEditorCustomFieldService {

  /** Depending on the node type (JcloudNode, JiraNode, AzureNode, ZendeskNode etc), the method
    * calls corresponding client for getting seq of custom fields from the node. Then each custom
    * field type converts from specific cf node type to our common
    * {@link com.exalate.domain.values.EditorFieldTypeValue} and then form
    * {@link com.exalate.domain.values.EditorFieldValue} . Where we fill the following info:
    *   - key: String,
    *   - label: String,
    *   - placeholder: Option[String] = None,
    *   - queryable: Option[Boolean] = Some(true),
    *   - main: Option[Boolean] = Some(false),
    *   - `type`: EditorFieldTypeValue,
    *   - operators: Option[Seq[OperatorValue]
    *
    * @return
    *   Future[Seq[EditorFieldValue]]
    */
  def getCustomFieldValues(): Future[Seq[EditorFieldValue]] = Future.successful(Nil)
}
