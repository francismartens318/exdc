package com.exalate.replication.services.api.error

class GettingNodeInfoFailedException(message: String) extends Exception(message)
