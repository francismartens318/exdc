package com.exalate.replication.services.api.processor

import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.hubobject.IHubPayload
import com.exalate.api.domain.request.ISyncRequest
import com.exalate.api.domain.{IIssueKey, INonPersistentReplica}
import com.google.inject.ImplementedBy

import scala.concurrent.Future

@ImplementedBy(classOf[com.exalate.replication.services.processor.CreateReplicaProcessor])
trait ICreateReplicaProcessor {

  def createHubReplica(
      connection: IConnection,
      hp: IHubPayload,
      issueKey: IIssueKey,
      syncRequestOpt: Option[ISyncRequest]
  ): Future[INonPersistentReplica]

  def createHubReplicaForDeletedIssue(issueKey: IIssueKey, connectionId: Int): INonPersistentReplica
}
