package com.exalate.replication.services.api.i18n

import com.google.inject.ImplementedBy

@ImplementedBy(classOf[com.exalate.replication.services.i18n.PlayI18nService])
trait Ii18nService {

  def translate(key: String, values: String*)(implicit
      localeOpt: Option[java.util.Locale]
  ): Option[String]

}
