package com.exalate.replication.services.api.trigger

import com.exalate.api.domain.IIssueKey
import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.trigger.ITrigger
import com.exalate.basic.domain.hubobject.v1.UpdateBasicHubIssue
import com.exalate.generic.services.EntityContext
import com.exalate.replication.services.trigger.TriggerService
import com.google.inject.ImplementedBy

import scala.concurrent.Future

@ImplementedBy(classOf[TriggerService])
trait ITriggerService {

  /** @param issueKey
    *   issue key for which the triggers will be executed
    * @param issueProject
    *   project related to the issue, this is used by the trigger project white list to avoid
    *   executing the search if issue is not on whitelist
    * @param ignoreConnection
    *   In some scenarios, you want to avoid executing the script for specific connections
    * @param updateHubIssueOption
    *   Used to use data coming from the webhook payload into the scheduling of the issue
    * @param entityContext
    *   Extra entity context which nodes can use to decide if they want to perform the search or not
    * @return
    */

  def executeTriggers[T <: EntityContext](
      issueKey: IIssueKey,
      issueProject: Option[String],
      ignoreConnection: Option[IConnection] = None,
      updateHubIssueOption: Option[UpdateBasicHubIssue] = None,
      entityContext: Option[T] = None
  ): Future[Int]

  def getIssueKeysUnderTrigger(trigger: ITrigger): Future[Seq[IIssueKey]]

  def getIssueCountUnderTrigger(trigger: ITrigger): Future[Long]

  def executeTriggerForIssueKeys(trigger: ITrigger, issueKeys: Seq[IIssueKey]): Unit

  def executeUnexalateForIssueKeys(trigger: ITrigger, issueKeys: Seq[IIssueKey]): Unit

  def deleteTriggerAndContext(triggerId: Int): Future[None.type]
}
