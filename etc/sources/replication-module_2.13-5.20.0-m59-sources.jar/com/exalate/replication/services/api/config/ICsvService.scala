package com.exalate.replication.services.api.config

import java.io.File
import com.exalate.api.domain.connection.IConnection
import com.exalate.domain.transport.message.ExalateMessage
import com.exalate.replication.services.config.CsvService
import com.exalate.replication.services.transport.value.ConnectInfoValue
import com.exalate.services.utils.pagination.SimplePage
import com.google.inject.ImplementedBy

import scala.concurrent.Future
import scala.util.Try

@ImplementedBy(classOf[CsvService])
trait ICsvService {

  def validateAndGetIssueMap(
      issueMapCsv: File,
      relation: IConnection,
      entityType: Option[String]
  ): Stream[Future[SimplePage[ConnectInfoValue]]]

  def validateAndGetIssueMap(
      issueMapCsv: String,
      relation: IConnection,
      entityType: Option[String]
  ): Stream[Future[SimplePage[ConnectInfoValue]]]

}
