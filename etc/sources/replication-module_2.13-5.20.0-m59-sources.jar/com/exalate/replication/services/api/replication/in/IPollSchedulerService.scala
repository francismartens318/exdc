package com.exalate.replication.services.api.replication.in

import com.exalate.api.domain.connection.IConnection
import com.exalate.replication.services.replication.in.PollSchedulerService
import com.google.inject.ImplementedBy

import scala.concurrent.Future

@ImplementedBy(classOf[PollSchedulerService])
trait IPollSchedulerService {

  def handlePollScheduleOnUpdate(connection: IConnection): Unit

  def removePollScheduleIfExists(connectionId: Int): Unit

  def shouldPoll(connection: IConnection): Boolean

  def isScheduleExists(connectionId: Int): Boolean

  def addSchedule(connection: IConnection): Unit

  def removeSchedule(connectionId: Int): Unit

  def removeAllSchedules(): Unit

}
