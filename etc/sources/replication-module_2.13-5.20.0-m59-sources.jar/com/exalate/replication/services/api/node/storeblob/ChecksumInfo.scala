package com.exalate.replication.services.api.node.storeblob

case class ChecksumInfo(checksum: String, fileSize: Long)
