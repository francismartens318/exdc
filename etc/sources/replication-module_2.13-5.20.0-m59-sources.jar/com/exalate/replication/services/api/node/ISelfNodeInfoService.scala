package com.exalate.replication.services.api.node

import com.google.inject.ImplementedBy

@ImplementedBy(classOf[DefaultSelfNodeInfoService])
trait ISelfNodeInfoService {

  def getMaxHubObjectVersion: String
  def getMinHubObjectVersion: String
  def getMaxRestVersion: String
  def getMinRestVersion: String
  def isPollOnly: Boolean
}
