package com.exalate.replication.services.api.issuetracker.script

import com.exalate.api.domain.hubobject.IHubIssueReplica
import com.exalate.domain.script.Params

/** Call Example:
  * ```
  * def map = ["x":1]
  * map.x //1
  * map["x"] //1
  *
  * issue = ["customFields":["Foo":"bar"]\];
  * issue.customFields["Foo"] // "bar"
  *
  * //Tuple3[Option[BasicHubOption], Option[String], Option[BasicHubUser]\]
  * sealed trait Params
  *
  *
  * object OptionParams {
  * def apply(v: BasicHubOption): OptionParams =
  * def apply(v: String): OptionParams =
  * }
  * sealed trait OptionParams extends Params
  * case class HubOptionOptionParams(v: BasicHubOption) extends OptionParams
  * case class StringOptionParams(v: String) extends OptionParams
  * case class UserOptionParams(v: BasicHubUser) extends OptionParams
  *
  * ExalateAPI["OPTION"].getValueFromField(...) // returns BasicHubOption
  * ExalateAPI["OPTION"].setValueToField(..., BasicHubOption | String | BasicHubUser) // returns Unit // throws EditorCategorizedException
  * ExalateAPI["OPTION"].getCurrentSideValue(..., BasicHubOption | String | BasicHubUser, ...) // returns BasicHubOption // throws EditorCategorizedException
  *
  * OptionExalateAPI extends IExalateAPI[BasicHubOption, OptionParams] = {
  * ...
  * }
  *
  * scriptContext: Map[String, Object]
  *
  * scriptContext.put("ExalateAPI", Map(
  * "OPTION" -> OptionExalateAPI(),
  * "TEXT" -> TextExalateAPI(),
  *
  *
  * (localField.`type`, remoteField.`type`) match {
  * case (OPTION, OPTION) =>
  * mappingValue.script = """
  * def aValue = ExalateAPI["OPTION"].getValueFromField(replica, ...)
  *
  * OptionParams bParams = applyMaps(...)
  *
  * // VALIDATION
  * //this can throw EditorCategorizedException
  * BasicHubOption bValue = ExalateAPI["OPTION"].getValueFromIssueTracker(..., bParams, issue)
  * if (bValue == null) {
  * bParams = applyRecovery(...)
  * bValue = ExalateAPI["OPTION"].getValueFromIssueTracker(..., bParams, issue)
  * if (bValue == null) {
  * throw new EditorCategorizedException(point to recovery default value)
  * }
  * }
  * // END: VALIDATION
  *
  * ExalateAPI["OPTION"].setValueToField(
  * issue,
  * bParams,
  * ...
  * )
  * """
  *
  * ...
  * )
  * ```
  */

trait IExalateAPI[T, P <: Params] {

  /** makes a request to Issue Tracker to get an object by `value`, does not take the value from
    * context entity. Context Entity is used to get project / issue type / other context
    *
    * @example
    *   val issueType: BasicHubOption = ExalateAPI.getValueFromIssueTracker( fieldName =
    *   "ISSUE_TYPE", value = StringOptionParams("Task"), contextEntity = issue ) // makes a request
    *   to the issue tracker checking if there actually is an issue type "Task" for the given
    *   project (taken from `contextEntity`)
    * @example
    *   val status: BasicHubStatus = ExalateAPI.getValueFromIssueTracker(fieldName = "STATUS", value
    *   \= StringOptionParams("To Do"), contextEntity = issue)
    */
  def getValueFromIssueTracker(fieldName: String, value: P, contextEntity: IHubIssueReplica): T
  // entity = replica
  /** gets value for the field from the `entity`
    */
  def getValueFromField(entity: IHubIssueReplica, fieldName: String): T
  // entity = issue
  def setValueToField(entity: IHubIssueReplica, fieldName: String, value: P): IHubIssueReplica

}
