package com.exalate.replication.services.api.transport.security

import com.exalate.domain.values.AuthenticationFailureValue
import com.exalate.replication.services.transport.security.BasicAuthorizationService
import com.google.inject.ImplementedBy
import play.api.mvc.Request

import scala.concurrent.Future

@ImplementedBy(classOf[BasicAuthorizationService])
trait IBasicAuthorizationService {

  def isUserAuthorized(
      username: String,
      password: String,
      authorizationPath: String
  ): Future[Boolean]

  def isRequestByValidUser[T](request: Request[T]): Future[Boolean]

  def isRequestByAdmin[T](request: Request[T]): Future[Boolean]

  def isRequestBy[T](
      checkIfAdminFn: (String, String) => Future[Option[AuthenticationFailureValue]]
  )(request: Request[T]): Future[Boolean]

  def nodeAuth(conf_user: String, conf_password: String)(
      username: String,
      password: String
  ): Future[Option[AuthenticationFailureValue]]

}
