package com.exalate.replication.services.api.issuetracker.script

import com.exalate.domain.values.v4.{GenerateScriptRequestValue, SyncScriptsValue}
import com.google.inject.ImplementedBy

import scala.concurrent.Future

/** Interface which should be implemented by each node - it generates script rules for basic and
  * scripted connection types
  */
@ImplementedBy(classOf[com.exalate.replication.services.script.DefaultScriptGeneratorService])
trait IIssueTrackerScriptGeneratorService {

  /** Generate rules for scripted connection
    * @param params
    * @return
    *   SyncScriptsValue
    */
  def generateScriptRules(params: GenerateScriptRequestValue): Future[SyncScriptsValue]

}
