package com.exalate.replication.services.api.error

import com.exalate.api.exception.script.CreateProcessorException

class NotEnoughDataToCreateIssueProcessorException(message: String)
    extends CreateProcessorException(message)

// TODO EXE-683 create new subclass with i18n for visual: VisualNotEnoughDataToCreateIssueProcessorException
//  The remote issue `$remoteIssueUrn` attempted to be synced is not matching either of the defined scopes: $scopesStr
class VisualNotEnoughDataToCreateIssueProcessorException(remoteIssueUrn: String, scopesStr: String)
    extends NotEnoughDataToCreateIssueProcessorException(
      s"The remote issue `$remoteIssueUrn` attempted to be synced is not matching either of the defined scopes: $scopesStr"
    )
