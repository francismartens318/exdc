package com.exalate.replication.services.api.node

import com.exalate.replication.services.node.NodeUidService
import com.google.inject.ImplementedBy

import scala.concurrent.Future

@ImplementedBy(classOf[NodeUidService])
trait INodeUidService {

  def ensureUidExists(): Future[None.type]

}
