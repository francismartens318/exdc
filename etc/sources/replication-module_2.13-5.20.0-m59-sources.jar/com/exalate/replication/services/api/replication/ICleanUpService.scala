package com.exalate.replication.services.api.replication

import java.util
import com.exalate.api.CleanUpResult
import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.event.ISyncEvent
import com.exalate.api.domain.request.ISyncRequest
import com.exalate.domain.replication.BasicSyncRequest
import com.exalate.domain.values.{CleanUpResponse, RemoteSupportsCleanUpResult}
import com.exalate.replication.services.replication.CleanUpService
import com.google.inject.ImplementedBy

import scala.collection.mutable
import scala.concurrent.Future

/** Clean-up methods use on the clean-up service which keep twin trace on CLEANED status
  */
@ImplementedBy(classOf[CleanUpService])
trait ICleanUpService {

  def handleProcessedEvent(syncEvent: ISyncEvent): Future[None.type]

  @deprecated(
    "Will be removed in favor of `handleProcessedRequest(basicSyncRequest: BasicSyncRequest)`",
    "EXACOMP-1884"
  )
  def handleProcessedRequest(syncRequest: ISyncRequest): Future[None.type]

  /** Perform post-processing clean-up actions on the provided sync request.
    * @param basicSyncRequest
    *   BasicSyncRequest to be cleaned up.
    * @return
    */
  def handleProcessedRequest(basicSyncRequest: BasicSyncRequest): Future[None.type]

  def getActiveTwinTraceCountForIssue(
      connection: IConnection,
      issueUrn: String,
      entityType: String,
      fieldValuesJson: Option[String]
  ): Future[Int]

  def getActiveTwinTraceCountForRemoteIssue(
      connection: IConnection,
      remoteIssueUrn: String,
      entityType: String
  ): Future[Int]

  def getActiveTwinTraceCountForConnection(connection: IConnection, entityType: String): Future[Int]

  def getActiveTwinTraceCount: Future[Int]

  def getSyncEventsCountForConnection(connection: IConnection, entityType: String): Future[Int]
  def getSyncRequestsCountForConnection(connection: IConnection, entityType: String): Future[Int]

  // OLD Clean up methods which remove twin trace

  def cleanUpSyncInfoForIssue(
      connectionId: Int,
      issueUrn: String,
      entityType: String,
      fieldValues: Map[String, String]
  ): Future[Option[CleanUpResult]]

  def cleanUpForRemoteIssue(
      connection: IConnection,
      remoteIssueUrn: String,
      entityType: String
  ): Future[Option[CleanUpResult]]

  def cleanUpSyncInfoForConnection(
      connection: IConnection,
      entityType: String
  ): Future[Option[CleanUpResult]]

  def cleanUpAllSyncInfo(): Future[Option[CleanUpResult]]

  // New clean up methods which keep twin trace and change its state

  def cleanUpSyncInfoForIssueKeepTwinTrace(
      issueUrn: String,
      entityType: String,
      fieldValues: util.Map[String, String]
  ): Future[Seq[CleanUpResult]]

  def cleanUpSyncInfoForIssueKeepTwinTrace(
      connectionId: Int,
      issueUrn: String,
      entityType: String,
      fieldValues: util.Map[String, String]
  ): Future[Option[CleanUpResult]]

  def cleanUpForRemoteIssueKeepTwinTrace(
      connection: IConnection,
      remoteIssueUrn: String,
      entityType: String
  ): Future[Option[CleanUpResult]]

  def cleanUpSyncInfoForConnectionKeepTwinTrace(
      connection: IConnection,
      entityType: String
  ): Future[Option[CleanUpResult]]

  def cleanUpScheduleErrorForConnection(
      connection: IConnection,
      entityType: String
  ): Future[None.type]

  def cleanUpConnection(
      connectionId: Int,
      entityTypeOpt: Option[String]
  ): Future[List[CleanUpResponse]]

  def cleanUpIssue(
      connectionId: Int,
      issueUrn: String,
      entityTypeOpt: Option[String],
      fieldValuesFromQuery: mutable.Map[String, String]
  ): Future[List[CleanUpResponse]]

  def cleanUpByRemoteIssue(
      connectionId: Int,
      remoteIssueUrn: String,
      entityTypeOpt: Option[String]
  ): Future[List[CleanUpResponse]]

  def doesRemoteSupportCleanup(connectionId: Int): Future[RemoteSupportsCleanUpResult]

  def deleteRelatedBlobs(paths: Seq[String]): Future[None.type]
}
