package com.exalate.replication.services.api.replication

import com.exalate.replication.services.replication.CleanServiceWrapper
import com.google.inject.ImplementedBy

import scala.concurrent.Future

/** We need this service in order to be compatible with Jira on-premise.
  * com.exalate.replication.services.config.ConnectionService should call Clean up service, but on
  * Jira on-prem we have it's own clean up service even with trait/interface. This trait is kind of
  * wrapper which will be implemented separately on Jira on-prem, and it will call it's own Clean-up
  * service
  */
@ImplementedBy(classOf[CleanServiceWrapper])
trait ICleanServiceWrapper {
  def deleteRelatedBlobs(paths: Seq[String]): Future[None.type]
}
