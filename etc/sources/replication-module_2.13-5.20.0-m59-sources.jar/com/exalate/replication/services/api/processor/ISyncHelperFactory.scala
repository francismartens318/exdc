package com.exalate.replication.services.api.processor

import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.request.ISyncRequest
import com.exalate.replication.services.processor.SyncHelperFactory
import com.google.inject.ImplementedBy

@ImplementedBy(classOf[SyncHelperFactory])
trait ISyncHelperFactory {

  def getSyncHelper(connection: IConnection, syncRequest: ISyncRequest): Object
  def getSyncHelperReadOnly(connection: IConnection, syncRequest: ISyncRequest): Object
}
