package com.exalate.replication.services.api.hubobject

import com.exalate.api.domain.twintrace.ITrace
import com.exalate.api.domain.{IBlobMetadata, INonPersistentReplica}
import com.google.inject.ImplementedBy

@ImplementedBy(classOf[com.exalate.replication.services.hubobject.BlobMetadataService])
trait IBlobMetadataService {

  def getAddedBlobIds(
      replica: INonPersistentReplica,
      traces: Seq[ITrace],
      existingMetadata: Seq[IBlobMetadata]
  ): Seq[String]

}
