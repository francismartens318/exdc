package com.exalate.replication.services.api.replication.mapping

import com.exalate.api.domain.IIssueKey
import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.hubobject.IHubIssueReplica
import com.exalate.basic.domain.hubobject.v1.BasicHubIssue
import com.exalate.domain.editor.mappings.MappingValue
import com.exalate.domain.values.connection.ConnectionValue
import com.exalate.replication.services.processor.{OutRuleExecutionParams, VisualRuleExecutionParams}
import com.exalate.replication.services.replication.mapping.MappingService
import com.google.inject.ImplementedBy

import scala.concurrent.Future

@ImplementedBy(classOf[MappingService])
trait IMappingService {
  def send(ruleExecutionParams: OutRuleExecutionParams): Future[BasicHubIssue]
  def receive(visualRuleExecutionParams: VisualRuleExecutionParams): Future[BasicHubIssue]

  def processMappings(
      connection: IConnection,
      connectionValue: ConnectionValue
  ): Future[Seq[MappingValue]]

}
