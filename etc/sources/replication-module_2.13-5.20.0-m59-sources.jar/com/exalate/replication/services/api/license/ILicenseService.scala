package com.exalate.replication.services.api.license

import com.exalate.api.domain.connection.{IConnection, INonPersistentConnection}
import com.exalate.api.domain.connection.fieldvalues.ConnectionMode
import com.exalate.api.domain.event.ISyncEvent
import com.exalate.domain.replication.BasicSyncRequest
import com.exalate.domain.values.license.{ExalateLicensesValue, LicenseUsageValue, LicenseValue}
import com.exalate.replication.services.license.SubscriptionValidationResult

import scala.concurrent.Future

trait ILicenseService {

  type ErrorMessages = Seq[String]

  def validatePayed(
      basicSyncRequest: BasicSyncRequest,
      connection: IConnection
  ): Future[ErrorMessages]

  def isSyncPayed(syncEvent: ISyncEvent): Future[Boolean]

  def validateSubscription(event: ISyncEvent): Future[SubscriptionValidationResult]

  def isConnectionValid(connectionMode: ConnectionMode): Future[Boolean]

  def updateLicenseUsages(usages: Seq[LicenseUsageValue]): Future[None.type]

  def updateLicenseUsages(remoteInstanceId: Int, payed: Boolean): Future[None.type]

  def getUsages: Future[Seq[(Seq[IConnection], Boolean)]]

  def isInstanceForConnectionPayed(connection: IConnection): Future[Boolean]

  def isInstanceForConnectionPayed(connection: INonPersistentConnection): Future[Boolean]

  def getMaxPaidInstances: Future[Int]

  def getLicenses(
      hasTrackerLicense: Boolean,
      getLicensePayload: Boolean
  ): Future[ExalateLicensesValue]

  def isTrackerVolumeBasedUnderControl(license: LicenseValue): Future[Boolean]

  def getVolumeLimitAndUsedFuture: Future[Option[(Int, Int)]]

  def deleteLicense(): Future[None.type]

  def save(payload: String): Future[Unit]

  def validatePayload(payload: String): Future[Boolean]

  def renewSubscriptionIfNecessaryFuture(): Future[None.type]

}
