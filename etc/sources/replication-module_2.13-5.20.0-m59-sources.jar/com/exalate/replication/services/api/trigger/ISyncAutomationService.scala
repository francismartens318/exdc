package com.exalate.replication.services.api.trigger

import com.exalate.basic.domain.BasicIssueKey
import com.exalate.basic.domain.hubobject.v1.UpdateBasicHubIssue
import com.exalate.generic.services.EntityContext
import com.exalate.replication.services.trigger.SyncAutomationService
import com.google.inject.ImplementedBy

import scala.concurrent.Future

/** Service used for impersonation.
  */
@ImplementedBy(classOf[SyncAutomationService])
trait ISyncAutomationService {

  /** Checks if the issue matches either of the scopes if connection option is provided, then only
    * runs the scopes for that particular connection and then executes triggers
    * @param issueKey
    * @param issueProject
    * @param updateHubIssueOption
    * @param entityContext
    * @tparam T
    * @return
    *   None
    */
  def checkCriteriaAndExalate[T <: EntityContext](
      issueKey: BasicIssueKey,
      issueProject: Option[String],
      updateHubIssueOption: Option[UpdateBasicHubIssue] = None,
      entityContext: Option[T]
  ): Future[None.type]

}
