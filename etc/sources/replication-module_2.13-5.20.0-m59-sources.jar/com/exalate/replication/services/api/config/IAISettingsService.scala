package com.exalate.replication.services.api.config

import com.exalate.domain.ai.{AISettingsValue, AISettingsValueExtended}
import com.exalate.replication.services.config.AISettingsService
import com.google.inject.ImplementedBy

import scala.concurrent.Future

@ImplementedBy(classOf[AISettingsService])
trait IAISettingsService {
  def get: Future[Option[AISettingsValueExtended]]
  def upsert(aiSettingsVal: AISettingsValue): Future[AISettingsValue]
}
