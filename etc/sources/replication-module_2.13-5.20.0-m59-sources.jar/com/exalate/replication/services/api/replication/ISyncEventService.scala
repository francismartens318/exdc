package com.exalate.replication.services.api.replication

import com.exalate.api.domain.IIssueKey
import com.exalate.api.domain.event.ISyncEvent
import com.exalate.api.domain.connection.IConnection
import com.google.inject.ImplementedBy

import scala.concurrent.Future

/** The service is responsible for providing a context information for a Sync Event
  */
@ImplementedBy(classOf[com.exalate.replication.services.api.replication.SyncEventService])
trait ISyncEventService {

  /** Uses persistence to get the remote issue key if there is no issue key present on the remote
    * replica.
    */
  def getRemoteIssueKey(syncEvent: ISyncEvent): Future[Option[IIssueKey]]
}
