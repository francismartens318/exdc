package com.exalate.replication.services.api.transport.v3_6

import com.exalate.replication.services.transport.value.oauth.{
  OAuthAccessTokenValue,
  OAuthGenerateAccessTokenValue,
  OAuthGenerateUrlReqValue,
  OAuthUrlResValue,
  RegisterOAuthClientReqValue,
  RegisterOAuthClientResValue,
  ValidateAccessTokenReqValue,
  ValidateAccessTokenResValue
}
import com.google.inject.ImplementedBy

import scala.concurrent.Future

@ImplementedBy(classOf[com.exalate.replication.services.transport.v3_6.ExternalOAuthResourceClient])
trait IExternalOAuthResourceClient {

  /** POST /rest/issuehub/3.6/oauthserver/clients
    */
  def register(
      authServerUri: String,
      registerOAuthClientReqValue: RegisterOAuthClientReqValue
  ): Future[RegisterOAuthClientResValue]

  /** POST /rest/issuehub/3.6/oauthserver/uris/generate
    */
  def generateUrl(
      authServerUri: String,
      oauthGenerateUrlReqValue: OAuthGenerateUrlReqValue,
      clientJwt: String
  ): Future[OAuthUrlResValue]

  /** POST /rest/issuehub/3.6/oauthserver/accesstokens/generate
    */
  def generateAccessToken(
      authServerUri: String,
      oauthGenerateAccessTokenValue: OAuthGenerateAccessTokenValue,
      clientJwt: String
  ): Future[OAuthAccessTokenValue]

  /** POST /rest/issuehub/3.6/oauthserver/accessTokens/validate
    */
  def hasValidAccessToken(
      authServerUri: String,
      req: ValidateAccessTokenReqValue
  ): Future[ValidateAccessTokenResValue]

}
