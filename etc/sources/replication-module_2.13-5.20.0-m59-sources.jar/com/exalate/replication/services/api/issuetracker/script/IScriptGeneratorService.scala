package com.exalate.replication.services.api.issuetracker.script

import com.exalate.api.domain.editor.error.EditorErrorSide
import com.exalate.domain.editor.mappings.MappingValue
import com.exalate.domain.editor.scopes.SingleSideScope
import com.exalate.domain.values.EditorFieldValue
import com.exalate.domain.values.connection.ConnectionValue
import com.google.inject.ImplementedBy

import scala.util.Try

/** Service generates scrip rules for defined mapping and scopes (visual connection)
  */
@ImplementedBy(classOf[com.exalate.replication.services.script.ScriptGeneratorService])
trait IScriptGeneratorService {
  type IncomingScript = String
  type OutgoingScript = String

  def generateScriptRules(
      mappingValue: MappingValue,
      connectionValue: ConnectionValue,
      localFieldValues: Seq[EditorFieldValue],
      remoteFieldValues: Seq[EditorFieldValue]
  ): (Try[IncomingScript], Try[OutgoingScript])

  def generateScriptScopes(
      singleSideScope: SingleSideScope,
      side: EditorErrorSide,
      connectionValue: ConnectionValue,
      fieldValues: Seq[EditorFieldValue]
  ): String

}
