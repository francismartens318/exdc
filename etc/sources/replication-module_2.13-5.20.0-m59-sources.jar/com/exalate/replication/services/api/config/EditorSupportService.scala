package com.exalate.replication.services.api.config

import com.exalate.api.domain.nodeinfo.{INodeInfo, INonPersistentNodeInfo}
import com.exalate.basic.domain.util.SemanticVersionService

import scala.util.Try

object EditorSupportService {

  def isEditorSupported(nodeInfo: INodeInfo): Boolean =
    isEditorSupported(
      Option(nodeInfo.getEditorValue),
      Option(nodeInfo.getExaCompVersion)
    )

  def isEditorSupported(nodeInfo: INonPersistentNodeInfo): Boolean =
    isEditorSupported(
      Option(nodeInfo.getEditorValue),
      Option(nodeInfo.getExaCompVersion)
    )

  private def isEditorSupported(
      editorValue: Option[String],
      exacompVersionStr: Option[String]
  ): Boolean =
    editorValue.isDefined &&
      exacompVersionStr
        .flatMap(v => Try(SemanticVersionService.get(v)).toOption)
        .exists(_.getMajor >= 5)

}
