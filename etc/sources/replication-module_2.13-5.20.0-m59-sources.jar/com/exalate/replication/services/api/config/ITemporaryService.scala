package com.exalate.replication.services.api.config

import com.exalate.domain.TemporaryData
import com.exalate.replication.services.config.TemporaryService
import com.google.inject.ImplementedBy

import scala.concurrent.Future

@ImplementedBy(classOf[TemporaryService])
trait ITemporaryService {

  def get(invitationId: String): Future[Option[TemporaryData]]

  def store(invitation: TemporaryData): Future[Int]

  def delete(invitationId: String): Future[Int]

  def deleteInvitationDetails(
      invitedInstanceUid: Option[String] = None,
      connectionName: Option[String] = None
  ): Future[Int]

}
