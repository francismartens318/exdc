package com.exalate.replication.services.api.processor

import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.request.ISyncRequest
import com.exalate.api.domain.twintrace.INonPersistentTrace
import com.exalate.api.domain.{IBlobMetadata, IIssueKey, INonPersistentReplica}
import com.google.inject.ImplementedBy

import scala.concurrent.Future

@ImplementedBy(classOf[com.exalate.replication.services.processor.CreateIssueProcessor])
trait ICreateIssueProcessor {

  def createIssue(
      connection: IConnection,
      syncRequest: ISyncRequest,
      receivedReplica: INonPersistentReplica,
      blobMetadataSeq: Seq[IBlobMetadata]
  ): Future[(IIssueKey, Seq[INonPersistentTrace])]

}
