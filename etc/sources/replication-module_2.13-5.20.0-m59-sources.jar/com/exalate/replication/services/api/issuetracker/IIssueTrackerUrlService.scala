package com.exalate.replication.services.api.issuetracker

import com.exalate.replication.services.issuetracker.DefaultIssueTrackerUrlService
import com.google.inject.ImplementedBy

import scala.concurrent.Future

/** Service generates different urls based on the provided input params or node type. (Each node
  * should implement this trait.)
  */
@ImplementedBy(classOf[DefaultIssueTrackerUrlService])
trait IIssueTrackerUrlService {

  /** Returns the base url which points stores the favicon.icoIInstanceNameService. If base url is
    * same as issue tracker url, should return None. This is implemented due to some issue trackers
    * having a unique endpoint for getting favicon.ico file, such as Azure Devops.
    * @return
    */
  def iconUrl: Option[String]

  /** Generates redirect URL for basic connection invitation
    * @param issueTrackerUrl
    * @param invitationId
    * @param remoteExalateUrl
    * @return
    */
  def getRedirectUrl(
      issueTrackerUrl: String,
      invitationId: String,
      remoteExalateUrl: Option[String] = None
  ): Option[String]

  /** Returns success url used on Stripe portal
    * @return
    */
  def getSuccessUrl(): Future[Option[String]]
}
