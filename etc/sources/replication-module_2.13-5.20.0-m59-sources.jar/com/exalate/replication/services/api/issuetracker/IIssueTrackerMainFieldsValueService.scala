package com.exalate.replication.services.api.issuetracker

import com.exalate.domain.values.BasicConnectionValue
import com.google.inject.ImplementedBy

import scala.concurrent.Future

/** Service which returns a fields of the scope for the connection - PROJECT, REPO etc (should be
  * implemented by each node)
  *
  * This trait has 2 default implementations: *
  * {@link com.exalate.replication.services.issuetracker.NopIssueTrackerMainFieldsValueService} -
  * should be used when node does not support basic connection *
  * {@link com.exalate.replication.services.issuetracker.EmptyIssueTrackerMainFieldsValueService} -
  * should be used when node supports basic connection but has NO main fields, like PROJECT, REPO
  * etc Otherwise node should implement this trait by providing a list of supported main fields.
  */
@ImplementedBy(
  classOf[com.exalate.replication.services.issuetracker.NopIssueTrackerMainFieldsValueService]
)
trait IIssueTrackerMainFieldsValueService {
  def get(): Future[Option[BasicConnectionValue]]
}
