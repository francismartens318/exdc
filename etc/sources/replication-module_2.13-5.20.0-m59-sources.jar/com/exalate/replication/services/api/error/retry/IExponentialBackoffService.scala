package com.exalate.replication.services.api.error.retry

import com.google.inject.ImplementedBy

import scala.concurrent.duration.Duration

@ImplementedBy(classOf[com.exalate.replication.services.error.retry.ExponentialBackoffService])
trait IExponentialBackoffService {
  def next(prev: Duration): Duration
}
