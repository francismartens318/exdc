package com.exalate.replication.services.api.replication.scope

import com.exalate.api.domain.editor.error.EditorErrorSide
import com.exalate.basic.domain.hubobject.v1.BasicHubIssue
import com.exalate.domain.editor.scopes.{FieldValue, QueryValue, SingleSideScope}
import com.exalate.domain.exception.editor.EditorCategorizedException
import com.exalate.replication.services.replication.scope.ScopeQueryService
import com.google.inject.ImplementedBy

import scala.concurrent.Future

@ImplementedBy(classOf[ScopeQueryService])
trait IScopeQueryService {

  def validate(
      singleSideScope: SingleSideScope,
      side: EditorErrorSide
  ): Future[Seq[EditorCategorizedException]]

  def matches(hubIssue: BasicHubIssue, singleSideScope: SingleSideScope): Boolean
  def overrideMainFields(hubIssue: BasicHubIssue, scope: SingleSideScope): Future[BasicHubIssue]
}
