package com.exalate.replication.services.api.transport

import com.exalate.api.domain.connection._
import com.exalate.domain.editor.EditorContextProgress.EditorContextProgress
import com.exalate.domain.editor.error.EditorError
import com.exalate.domain.editor.mappings.MappingValue
import com.exalate.domain.editor.scopes.ScopeValue
import com.exalate.domain.values.connection.{
  ConnectionDraft,
  ConnectionDraftRequestValue,
  ConnectionValue,
  ConnectionValueForList
}
import com.exalate.replication.services.transport.utils.ConnectionValueHelper
import com.google.inject.ImplementedBy

import scala.concurrent.Future

@ImplementedBy(classOf[ConnectionValueHelper])
trait IConnectionValueHelper {

  def toInstanceAndRelationOnConnection(rcv: ConnectionValue): INonPersistentConnection

  def toNonPersistentConnection(c: IConnection): INonPersistentConnection

  def toConnectionValue(connection: IConnection): Future[ConnectionValue]

  def toConnectionValue(
      connection: IConnection,
      editorErrors: Seq[EditorError],
      editorContextProgress: Option[EditorContextProgress] = None
  ): Future[ConnectionValue]

  def toConnectionValue(
      connection: IConnection,
      editorContextProgress: EditorContextProgress
  ): Future[ConnectionValue]

  def toConnectionValueForList(connection: IConnection): Future[ConnectionValueForList]

  def getDefaultWithCredentials(
      remoteUsername: String,
      remotePassword: String,
      authenticationRequired: Boolean
  ): INonPersistentConnection

  def toConnectionDraftValueRequest(
      connectionDraft: ConnectionDraft,
      scopes: Seq[ScopeValue],
      mappings: Seq[MappingValue],
      accessToken: Option[String]
  ): Option[ConnectionDraftRequestValue]

}
