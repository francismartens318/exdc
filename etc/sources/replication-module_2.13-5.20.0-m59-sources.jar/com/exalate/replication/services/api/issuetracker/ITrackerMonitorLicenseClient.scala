package com.exalate.replication.services.api.issuetracker

import scala.concurrent.Future

trait ITrackerMonitorLicenseClient {
  def getNumberOfUsers: Future[Option[Int]]
}

/** The default implementation for ITrackerMonitorLicenseClient for thus instance where it is not
  * needed.
  */
object DefaultTrackerMonitorLicenseClient extends ITrackerMonitorLicenseClient {

  override def getNumberOfUsers: Future[Option[Int]] =
    Future.successful(Option(NumberOfUsersUnavailable))

}
