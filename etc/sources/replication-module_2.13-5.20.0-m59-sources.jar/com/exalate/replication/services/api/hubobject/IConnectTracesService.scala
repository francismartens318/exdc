package com.exalate.replication.services.api.hubobject

import javax.annotation.Nonnull

import com.exalate.api.domain.INonPersistentConnectContext
import com.exalate.api.domain.hubobject.IHubIssueReplica
import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.twintrace.INonPersistentTrace
import com.google.inject.ImplementedBy

/** Connect. Why do we do connect?
  *   - To migrate from previous synchronization solution to Exalate For instance, if there were two
  *     issues: A1 (on JIRA A) and B1 (on JIRA B), and the users synchronized them manually
  *     (whenever a comment is added on A1, a user adds a similar comment on B1) Then, Exalate can
  *     be used to "Connect" issues A1 with B1, such that after that connect, all the changes on A1
  *     would trigger synchronization to B1
  *
  * Trace-able. A general term for comments, attachments and worklogs.
  *
  * Traces. Exalate synchronizes trace-ables (comments, attachments, worklogs), by tracking, which
  * trace-able (comment, attachment, worklog) was created from which in Traces. Basically a trace
  * contains:
  *   - local trace-able (comment or attachment or worklog) id
  *   - remote trace-able (comment or attachment or worklog) id
  *   - trace-able type (COMMENT or ATTACHMENT or WORKLOG)
  *   - additional fields, needed to know the context of the synchronization of these trace-ables
  *     Whenever Exalate synchronizes a trace-able, Exalate creates a trace to track, from which
  *     trace-able on the remote side was this trace-able created. If a comment was changed on A1,
  *     Exalate can easily find, which comment should be updated on B1 with the help of traces.
  *     Traces help to avoid deleting and re-creating the trace-ables.
  *
  * Connect Traces. Whenever a connect operation is performed, the issues, which are going to be
  * connected might already have comments (attachments, worklogs), Since these comments
  * (attachments, worklogs) were not created by Exalate, Exalate does not try figure out, which
  * comments (attachments, worklogs) on B1 are related to which comments (attachments, worklogs) on
  * A1. Instead, Exalate ensures, that all the comments (attachments, worklogs) which existed before
  * connect, are untouched. This is achieved by creating the "Connect Traces" (traces which have the
  * field toSynchonize=false).
  */
@ImplementedBy(classOf[com.exalate.replication.services.hubobject.ConnectTracesService])
trait IConnectTracesService {

  /** Return the local connect traces. We use this to avoid the situation with duplicating comments
    * (attachments, worklogs) when we have the comments (attachments, worklogs) on both sides. if
    * the `connectContextOpt` is None, that means, that this is not a connect event / request which
    * means, that no connect traces should be generated. if `connectContextOpt` is Some, and
    * `connectContextOpt.get.isSynchronizeComments` is true, then we don't create pre-connect traces
    * for comments if `connectContextOpt` is Some, and
    * `connectContextOpt.get.isSynchronizeAttachments` is true, then we don't create pre-connect
    * traces for attachments if `connectContextOpt` is Some, and
    * `connectContextOpt.get.isSynchronizeWorklogs` is true, then we don't create pre-connect traces
    * for worklogs
    */
  def getConnectTraces(
      @Nonnull localReplica: IHubIssueReplica,
      @Nonnull connectContextOpt: Option[INonPersistentConnectContext],
      @Nonnull relation: IConnection
  ): Seq[INonPersistentTrace]

}
