package com.exalate.replication.services.api.replication.in

import com.exalate.api.domain.license.ISubscriptionContext
import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.request.ISyncRequest
import com.exalate.api.domain.twintrace.INonPersistentTrace
import com.exalate.api.domain.{
  IIssueKey,
  INonPersistentBlobMetadata,
  INonPersistentConnectContext,
  INonPersistentReplica
}
import com.google.inject.ImplementedBy

import scala.concurrent.Future

@ImplementedBy(classOf[com.exalate.replication.services.replication.in.RequestSchedulerService])
trait IRequestSchedulerService {

  def scheduleSyncRequest(
      relation: IConnection,
      remoteReplica: INonPersistentReplica,
      syncedTo: Option[IIssueKey],
      blobMetadataList: Seq[INonPersistentBlobMetadata],
      remoteTraces: Seq[INonPersistentTrace],
      syncEventId: Int,
      syncEventNumber: Long,
      connectIssueUrnOpt: Option[String],
      unexalateRemoteIssueUrn: Option[String],
      connectContext: Option[INonPersistentConnectContext],
      deletedRemoteIssueUrnOpt: Option[String],
      twinTraceId: Option[Int],
      isPayed: Boolean,
      subscriptionContext: ISubscriptionContext,
      syncType: String
  ): Future[Option[ISyncRequest]]

}
