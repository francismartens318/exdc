package com.exalate.replication.services.api.replication.blob

import com.google.inject.ImplementedBy

import scala.concurrent.Future

@ImplementedBy(
  classOf[com.exalate.replication.services.replication.blob.out.BlobEventProcessorService]
)
trait IBlobEventProcessorService {
  def processBlobEvents(): Future[Unit]
}
