package com.exalate.replication.services.api.issuetracker

case class NodeLicenseValue(isPresent: Boolean, isValid: Boolean)
