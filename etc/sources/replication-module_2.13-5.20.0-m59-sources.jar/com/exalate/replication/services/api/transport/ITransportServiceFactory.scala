package com.exalate.replication.services.api.transport

import com.exalate.api.domain.connection.IConnection
import com.google.inject.ImplementedBy

import scala.util.Try

@ImplementedBy(classOf[com.exalate.replication.services.transport.TransportServiceFactory])
trait ITransportServiceFactory {
  def get(connection: IConnection): Try[ITransportService]
}
