package com.exalate.replication.services.api.processor

import com.exalate.replication.services.processor.ScriptVariableServiceFactory
import com.google.inject.ImplementedBy

@ImplementedBy(classOf[ScriptVariableServiceFactory])
trait IScriptVariableServiceFactory {
  def getScriptVariableService(): IScriptVariableService
  def getScriptVariableReadOnlyService(): IScriptVariableService
}
