package com.exalate.replication.services.api.issuetracker

import com.exalate.basic.domain.hubobject.v1.BasicHubComment
import com.exalate.domain.issuetracker.IEntityUpdateContext
import com.google.inject.ImplementedBy
import play.api.libs.json.JsValue

import scala.concurrent.Future

@ImplementedBy(classOf[DefaultTrackerCommentService])
trait ITrackerCommentService {
  def removeComment[C <: IEntityUpdateContext](commentId: String, context: C): Future[None.type]

  def createComment[C <: IEntityUpdateContext](
      comment: BasicHubComment,
      userBehalfOnOpt: Option[String],
      context: C
  ): Future[(String, JsValue)]

  def updateComment[C <: IEntityUpdateContext](
      comment: BasicHubComment,
      userBehalfOnOpt: Option[String],
      context: C
  ): Future[Option[(String, JsValue)]]

  def getUserKey(u: String): Option[String]
}
