package com.exalate.replication.services.api.issuetracker

import scala.concurrent.ExecutionContext

class DefaultMonitorLicenseService extends IMonitorLicenseService {
  implicit override val ec: ExecutionContext = scala.concurrent.ExecutionContext.Implicits.global
}
