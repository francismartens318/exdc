package com.exalate.replication.services.api.trigger.pollcontext

case class PagingResult(offset: Long, limit: Int, totalResults: Long)
