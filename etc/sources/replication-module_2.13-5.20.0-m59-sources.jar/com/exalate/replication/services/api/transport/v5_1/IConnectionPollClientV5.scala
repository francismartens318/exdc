package com.exalate.replication.services.api.transport.v5_1

import com.exalate.api.domain.connection.IConnection
import com.exalate.replication.services.transport.v5_1.ConnectionPollClient
import com.exalate.replication.services.transport.value.ShouldBePolledResponseValue
import com.google.inject.ImplementedBy

import scala.concurrent.Future

@ImplementedBy(classOf[ConnectionPollClient])
trait IConnectionPollClientV5 {

  def shouldBePolled(
      remoteUrl: String,
      connections: Seq[IConnection]
  ): Future[ShouldBePolledResponseValue]

}
