package com.exalate.replication.services.api.node.lifecycle

import com.google.inject.ImplementedBy

/** Allows to know whether the app is running in dev / staging or in prod Can be influenced by: *
  * either the way you run the app (either from SBT / IntelliJ - dev) * or a application.conf file
  */
@ImplementedBy(classOf[com.exalate.replication.services.node.lifecycle.ApplicationModeService])
trait IApplicationModeService {
  def isInDevMode: Boolean
}
