package com.exalate.replication.services.module

import javax.inject.{Inject, Provider}
import play.api.{Environment, Mode}
import play.api.db.DBApi
import play.api.db.evolutions._
import play.core.WebCommands

class ApplicationEvolutionsProvider @Inject() (
    config: EvolutionsConfig,
    reader: EvolutionsReader,
    evolutions: EvolutionsApi,
    dynamicEvolutions: DynamicEvolutions,
    dbApi: DBApi,
    environment: Environment,
    webCommands: WebCommands
) extends Provider[ApplicationEvolutions] {

  override def get(): ApplicationEvolutions = new ApplicationEvolutions(
    config,
    reader,
    evolutions,
    dynamicEvolutions,
    dbApi,
    environment.copy(mode = if (environment.mode == Mode.Dev) Mode.Prod else environment.mode),
    webCommands
  )

}
