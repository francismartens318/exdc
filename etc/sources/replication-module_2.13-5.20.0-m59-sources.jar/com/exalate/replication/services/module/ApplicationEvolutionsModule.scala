package com.exalate.replication.services.module

import play.api.db.evolutions.{
  ApplicationEvolutions,
  DefaultEvolutionsApi,
  DefaultEvolutionsConfigParser,
  EnvironmentEvolutionsReader,
  EvolutionsApi,
  EvolutionsConfig,
  EvolutionsReader
}
import play.api.inject.{bind, SimpleModule}

class ApplicationEvolutionsModule
    extends SimpleModule(
      bind[EvolutionsConfig].toProvider[DefaultEvolutionsConfigParser],
      bind[EvolutionsReader].to[EnvironmentEvolutionsReader],
      bind[EvolutionsApi].to[DefaultEvolutionsApi],
      bind[ApplicationEvolutions].toProvider[ApplicationEvolutionsProvider].eagerly
    )
