package com.exalate.replication.services.message.worker

import akka.actor.Actor
import com.exalate.api.ILoggingService
import com.exalate.api.persistence.message.IMessageQueueRepository
import com.exalate.api.persistence.relation.IRelationRepository
import com.exalate.domain.transport.message.ExalateMessage
import com.exalate.replication.services.api.message.IExalateMessageService
import com.exalate.replication.services.utils.ActorLoggingService
import com.exalate.services.utils.pagination.{PaginationUtil, SimplePage}
import com.google.inject.Inject

import scala.concurrent.ExecutionContext
import scala.concurrent.duration.Duration
import scala.concurrent.{Await, Future}

object InMessageActor {

  case object ProcessIncomingMessagesInReadyStatus

  private[worker] case object LastMessage
}

/** The Actor which every 5 sec checks whether we have data in MessageQueueTable with status
  * `Ready`. In case, we have data, this class calls {@link IExalateMessageService.receive()} in
  * order to process received messages.
  */
class InMessageActor @Inject() (
    messageQueueRepository: IMessageQueueRepository,
    exalateMessageService: IExalateMessageService,
    connectionRepository: IRelationRepository,
    loggingService: ILoggingService,
    actorLoggingService: ActorLoggingService
) extends Actor {

  import InMessageActor._
  implicit private val ec: ExecutionContext = context.dispatcher

  private val waiting: Receive = {
    case ProcessIncomingMessagesInReadyStatus =>
      actorLoggingService.tryWithLoggedBugs {
        loggingService.trace("InMessageActor:waiting: ProcessIncomingMessagesInReadyStatus")
        self ! LastMessage
        context.become(waitingForAfterTheLastMessage)
      }
    case _                                    =>
      actorLoggingService.tryWithLoggedBugs {
        loggingService.trace("InMessageActor:waiting: _ ")
      }
  }

  private def waitingForAfterTheLastMessage: Receive = {

    case LastMessage =>
      context.become(waiting)
      actorLoggingService.tryWithLoggedBugs {
        loggingService.trace(s"IncomingMessageActor: processing messages in ready status")

        Await
          .ready(
            processMessagesReadyStatus,
            Duration.Inf
          )
          .recoverWith {
            case f =>
              loggingService.error(
                "InMessageActor: error while processing messages in ready status",
                f
              )
              Future.successful(None)
          }
      }

    case _ =>
      actorLoggingService.tryWithLoggedBugs {
        loggingService.trace("InMessageActor:waitingForAfterTheLastMessage:_")
      }

  }

  def receive: Receive = waiting

  /** Extracts connection from db by id which is hold in ExalateMessage. Then extracts remote
    * instance id from this connection.
    * @param m
    * @return
    */
  private def toInstanceId(m: ExalateMessage): Future[Option[Int]] =
    connectionRepository
      .getConnectionFuture(m.connectionId)
      .map(
        _.flatMap(c => Option(c.getRemoteInstance))
          .map(i => i.getID)
      )

  private def groupMessagesByInstance(
      ms: Seq[ExalateMessage]
  ): Future[Map[Int, Seq[ExalateMessage]]] =
    ms
      .foldLeft(Future.successful(Map.empty[Int, Seq[ExalateMessage]])) { (f, m) =>
        f.flatMap { map =>
          toInstanceId(m)
            .map {
              case None      => map
              case Some(iId) => map.updated(iId, map.get(iId).toSeq.flatten :+ m)
            }
        }
      }

  private def processMessagesReadyStatus =
    PaginationUtil.foldLeftInfStream(
      messageQueueRepository.getStreamWithStatusReady(),
      { p: SimplePage[ExalateMessage] => p.isLast }
    )(Future.successful(None)) { (_: None.type, p: SimplePage[ExalateMessage]) =>
      receivingMessages(p)
    }

  /** The main methods, which takes as input SimplePage of ExalateMessage. Group messages by
    * instance id and calls {@link IExalateMessageService.receive()} to process message. Finally,
    * processed messages are deleted from db.
    * @param p
    *   \- SimplePage[ExalateMessage]
    * @return
    */
  private def receivingMessages(p: SimplePage[ExalateMessage]) =
    groupMessagesByInstance(p.results)
      .flatMap { instanceToMessagesMap =>
        instanceToMessagesMap.foldLeft(Future.successful(None)) {
          case (r, (instanceId, ms)) =>
            r.flatMap { _ =>
              exalateMessageService
                .receive(ms, instanceId)
                .foldLeft(Future.successful(None)) { (result, messageFuture) =>
                  result.flatMap { _ =>
                    messageFuture
                      .map(_.id.toSeq)
                      .recover {
                        case e =>
                          loggingService.error(s"#receivingMessages: ${e.getMessage}", e)
                          Nil
                      }
                      .flatMap { mIds =>
                        messageQueueRepository.delete(mIds)
                      }
                  }
                }
            }
        }
//        _.map(ms => exalateMessageService
//          .receive(ms._2, ms._1)
//          .map(_.map(m => messageQueueRepository.delete(m.id.toSeq))))
      }
      .map(_ => None)

}
