package com.exalate.replication.services.message

import com.exalate.api.ILoggingService
import com.exalate.api.exception.bug.BugException
import com.exalate.domain.transport.message._
import com.exalate.replication.services.replication.MessageUnbatchingResult
import javax.inject.Inject

import scala.util.{Failure, Success, Try}

class MessageUnbatcher @Inject() (loggingService: ILoggingService) extends IMessageUnbatcher {

  /** Unbatching process
    * @param allChunks
    * @return
    *   MessageUnbatchingResult
    */
  def unbatch(allChunks: Seq[ExalateMessageChunk]): MessageUnbatchingResult =
    allChunks
      .groupBy(_.messageId)
      .foldLeft(MessageUnbatchingResult(Map.empty)) {
        case (result, (messageId, chunksForMessage)) =>
          if (chunksForMessage.isEmpty) {
            loggingService.error(s"Chunks list for message with id $messageId is empty. Skipping..")
            result
          } else {
            val connectionId = chunksForMessage.head.connectionId
            val messageType = chunksForMessage.head.messageType
            val messageOpt: Option[MessageUnbatchingResult] =
              tryUnBatching(chunksForMessage, connectionId, messageType)
            MessageUnbatchingResult(
              result.messageToChunks ++ messageOpt.toSeq.flatMap(_.messageToChunks.toSeq)
            )
          }
      }

  private def tryUnBatching(
      chunksForMessage: Seq[ExalateMessageChunk],
      connectionId: Int,
      messageType: String
  ) = {
    val messageOpt = chunksForMessage
      .sortBy(_.startIndexInMessage)
      .foldLeft(firstUnbatchingIntermediateResult)(
        unbatch(chunksForMessage, connectionId)
      )
      .toOption
      .map(unbatchingResult =>
        MessageUnbatchingResult(
          Map(
            ExalateMessage(
              unbatchingResult.contentAcc,
              messageType,
              connectionId,
              direction = MessageDirection.IN.toString,
              status = MessageStatus.READY.toString
            )
              -> chunksForMessage
          )
        )
      )
    messageOpt
  }

  private def unbatch(
      chunksForMessage: Seq[ExalateMessageChunk],
      connectionId: Int
  )(contentAccTry: Try[UnbatchingIntermediateResult], chunk: ExalateMessageChunk) =
    if (chunk.totalChunksInMessage > chunksForMessage.size)
      lessChunksReceivedThanTotalInMessage(chunksForMessage, connectionId, chunk)
    else
      contentAccTry match {
        case _: Failure[UnbatchingIntermediateResult]                    => contentAccTry
        case Success(UnbatchingIntermediateResult(contentAcc, nextMidx)) =>
          if (nextMidx == chunk.startIndexInMessage)
            validChunk(connectionId, chunk, contentAcc, nextMidx)
          else if (nextMidx < chunk.startIndexInMessage) chunkGap(connectionId, chunk, nextMidx)
          else if (nextMidx > chunk.startIndexInMessage)
            duplicateChunk(connectionId, chunk, contentAcc, nextMidx)
          else chunkSeqBug(connectionId, chunk, nextMidx)
      }

  private def lessChunksReceivedThanTotalInMessage(
      chunksForMessage: Seq[ExalateMessageChunk],
      connectionId: Int,
      chunk: ExalateMessageChunk
  ) = {
    val errorMsg = s"#tryUnBatching: skipping the chunks for message `${chunk.messageId}`" +
      s" of type `${chunk.messageType}` for connection `$connectionId`: " +
      s" since there are less chunks received so far `${chunksForMessage.size}` than there should be in the message `${chunk.totalChunksInMessage}`"
    loggingService.trace(errorMsg)
    Failure(new NoSuchElementException(errorMsg))
  }

  private def chunkSeqBug(connectionId: Int, chunk: ExalateMessageChunk, nextMidx: Int) = {
    val errorMsg =
      s"#tryUnBatching: failed to find chunk `$nextMidx` for message `${chunk.messageId}`" +
        s" of type `${chunk.messageType}` for connection `$connectionId`: " +
        s"because it's neither `nextMidx == chunk.startIndexInMessage` nor `nextMidx < chunk.startIndexInMessage` nor `nextMidx > chunk.startIndexInMessage`"
    loggingService.error(errorMsg)
    Failure(new BugException(errorMsg))
  }

  private def duplicateChunk(
      connectionId: Int,
      chunk: ExalateMessageChunk,
      contentAcc: String,
      nextMidx: Int
  ) = {
    val errorMsg =
      s"#tryUnBatching: skipping the chunk `$nextMidx` for message `${chunk.messageId}`" +
        s" of type `${chunk.messageType}` for connection `$connectionId`: " +
        s" since it has already been appended to the message accumulator" +
        (
          if (chunk.totalChunksInMessage > nextMidx + 1)
            s", proceeding to the next one: `${nextMidx + 1}`"
          else "."
        )
    loggingService.trace(errorMsg)
    Success(UnbatchingIntermediateResult(contentAcc, nextMidx))
  }

  private def chunkGap(connectionId: Int, chunk: ExalateMessageChunk, nextMidx: Int) = {
    val errorMsg =
      s"#tryUnBatching: failed to find chunk `$nextMidx` for message `${chunk.messageId}`" +
        s" of type `${chunk.messageType}` for connection `$connectionId`: " +
        s"the next chunk received from remote is `${chunk.startIndexInMessage}`. Going to wait for the chunk `$nextMidx`"
    loggingService.trace(errorMsg)
    Failure(new NoSuchElementException(errorMsg))
  }

  private def validChunk(
      connectionId: Int,
      chunk: ExalateMessageChunk,
      contentAcc: String,
      nextMidx: Int
  ) = {
    loggingService.trace(
      s"#tryUnBatching: found next chunk for message `${chunk.messageId}`" +
        s" of type `${chunk.messageType}` for connection `$connectionId`: `${chunk.startIndexInMessage}`" +
        (
          if (chunk.totalChunksInMessage > nextMidx + 1)
            s", proceeding to the next one: `${nextMidx + 1}`"
          else "."
        )
    )
    Success(UnbatchingIntermediateResult(contentAcc + chunk.content, nextMidx + 1))
  }

  private val firstUnbatchingIntermediateResult: Try[UnbatchingIntermediateResult] = Success(
    EmptyUnbatchingIntermediateResult
  )

  private object EmptyUnbatchingIntermediateResult extends UnbatchingIntermediateResult("")

  private case class UnbatchingIntermediateResult(
      contentAcc: String,
      nextExpectedChunkMessageIdx: Int = 0
  )

}
