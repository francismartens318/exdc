package com.exalate.replication.services.message

import com.exalate.domain.transport.message.ExalateMessageChunk
import com.exalate.replication.services.replication.MessageUnbatchingResult
import com.google.inject.ImplementedBy

@ImplementedBy(classOf[MessageUnbatcher])
trait IMessageUnbatcher {
  def unbatch(chunks: Seq[ExalateMessageChunk]): MessageUnbatchingResult
}
