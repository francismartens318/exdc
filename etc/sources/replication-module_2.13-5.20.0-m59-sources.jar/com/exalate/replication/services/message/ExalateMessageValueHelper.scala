package com.exalate.replication.services.message

import java.nio.charset.StandardCharsets
import com.exalate.api.domain.instance.IInstance
import com.exalate.domain.transport.message.{ChunkStatus, ExalateMessageChunk}
import com.exalate.domain.values.{BatchValue, EncodedChunkValue, PlainChunkValue}
import com.exalate.replication.services.transport.utils.ExalateVersionCheckerUtils
import com.exalate.util.json.gson.GsonCaseClassValueJsonService
import org.apache.commons.codec.binary.Base64

import scala.util.Try

object ExalateMessageValueHelper {

  def toPlainChunkValue(c: ExalateMessageChunk): PlainChunkValue =
    PlainChunkValue(
      c.content.getBytes(StandardCharsets.UTF_8),
      c.messageId,
      c.startIndexInMessage,
      c.totalChunksInMessage,
      c.messageType
    )

  def toBatchWithPlainContent(cs: Seq[ExalateMessageChunk]): BatchValue[PlainChunkValue] =
    BatchValue(cs.map(toPlainChunkValue).toArray)

  def toEncodedChunkValue(c: ExalateMessageChunk): EncodedChunkValue = {
    val encodedContent = new String(Base64.encodeBase64(c.content.getBytes), StandardCharsets.UTF_8)
    EncodedChunkValue(
      encodedContent,
      c.messageId,
      c.startIndexInMessage,
      c.totalChunksInMessage,
      c.messageType
    )
  }

  def toBatchWithEncodedContent(cs: Seq[ExalateMessageChunk]): BatchValue[EncodedChunkValue] =
    BatchValue(cs.map(toEncodedChunkValue).toArray)

  def toJsonTryBatch(
      cs: Seq[ExalateMessageChunk],
      remoteInstance: IInstance
  ): Try[String] = {
    val remoteInstanceNodeInfo = remoteInstance.getNodeInfo
    if (
      ExalateVersionCheckerUtils.isExalateRestVersionEncodingCompatible(
        remoteInstanceNodeInfo.getMaxRestVersion
      )
    ) {
      val batchValue = toBatchWithEncodedContent(cs)
      GsonCaseClassValueJsonService.write(batchValue)
    } else {
      val batchValue = toBatchWithPlainContent(cs)
      GsonCaseClassValueJsonService.write(batchValue)
    }
  }

  def fromEncodedChunkValue(
      encodedChunkValue: EncodedChunkValue,
      batchUUID: String,
      connectionId: Int
  ): ExalateMessageChunk = {
    val decodedContent = Base64.decodeBase64(encodedChunkValue.c)
    ExalateMessageChunk(
      None,
      encodedChunkValue.id,
      batchUUID,
      new String(decodedContent, StandardCharsets.UTF_8),
      connectionId,
      encodedChunkValue.x,
      encodedChunkValue.t,
      ChunkStatus.UNBATCHING.toString,
      encodedChunkValue.m
    )
  }

  def fromPlainChunkValue(
      plainChunkValue: PlainChunkValue,
      batchUUID: String,
      connectionId: Int
  ): ExalateMessageChunk =
    ExalateMessageChunk(
      None,
      plainChunkValue.id,
      batchUUID,
      new String(plainChunkValue.c, StandardCharsets.UTF_8),
      connectionId,
      plainChunkValue.x,
      plainChunkValue.t,
      ChunkStatus.UNBATCHING.toString,
      plainChunkValue.m
    )

}
