package com.exalate.replication.services.message

import com.exalate.domain.transport.message.{ExalateMessage, ExalateMessageBatch}
import com.google.inject.ImplementedBy

import scala.util.Try

@ImplementedBy(classOf[MessageBatcher])
trait IMessageBatcher {

  /** Splits provided message into ExalateMessageBatch
    * @param messages
    *   seq of exalate messages
    * @param BATCH_SIZE_LIMIT_BYTE
    *   size of the batch in bytes (2MB)
    * @return
    *   Try[Seq[ExalateMessageBatch]]
    */
  def splitMessagesIntoBatches(
      messages: Seq[ExalateMessage],
      BATCH_SIZE_LIMIT_BYTE: Int = MessageBatcher.BATCH_SIZE_LIMIT_BYTE
  ): Try[Seq[ExalateMessageBatch]]

}
