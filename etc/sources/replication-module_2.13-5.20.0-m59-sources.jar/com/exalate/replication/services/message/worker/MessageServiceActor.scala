package com.exalate.replication.services.message.worker

import akka.actor.Actor
import com.exalate.api.ILoggingService
import com.exalate.domain.transport.message.{ExalateMessage, MessageType}
import com.exalate.replication.services.api.message.IExalateMessageService
import com.exalate.replication.services.utils.ActorLoggingService
import com.google.inject.Inject

object MessageServiceActor {
  case class Send(exalateMessage: ExalateMessage)
  object LastMessage
}

/** The actor which is triggered for sending messages. This actor is triggered from
  * {@link com.exalate.replication.services.config.EditorFieldContextService.pushEditorContext()}
  */
class MessageServiceActor @Inject() (
    exalateMessageService: IExalateMessageService,
    loggingService: ILoggingService,
    actorLoggingService: ActorLoggingService
) extends Actor {

  import MessageServiceActor._

  def receive: Receive = waiting

  private val waiting: Receive = {
    case Send(m) =>
      loggingService.info("MessageServiceActor:waiting:Send")
      actorLoggingService.tryWithLoggedBugs {
        MessageType.fromString(m.messageType) match {
          case None    =>
            loggingService.error(
              s"MessageServiceActor #waiting Send didn't find a message type constant for `${m.messageType}` skipping the message!"
            )
          case Some(_) =>
            exalateMessageService.send(m)
        }
      }
    case _       =>
      actorLoggingService.tryWithLoggedBugs {
        loggingService.trace("MessageServiceActor:waiting:_")
      }
  }

}
