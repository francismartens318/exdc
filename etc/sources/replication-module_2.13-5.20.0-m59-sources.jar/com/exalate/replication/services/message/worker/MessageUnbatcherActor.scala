package com.exalate.replication.services.message.worker

import akka.actor.{Actor, ActorRef}
import com.exalate.api.ILoggingService
import com.exalate.api.persistence.message.{IMessageChunkRepository, IMessageQueueRepository}
import com.exalate.domain.transport.message.ExalateMessageChunk
import com.exalate.replication.services.message.IMessageUnbatcher
import com.exalate.replication.services.utils.ActorLoggingService
import com.exalate.services.utils.FutureUtils
import com.exalate.services.utils.pagination.{PaginationUtil, SimplePage}
import com.google.inject.Inject
import com.google.inject.name.Named

import scala.concurrent.ExecutionContext
import scala.concurrent.duration.Duration
import scala.concurrent.{Await, Future}

object MessageUnbatcherActor {

  case object ProcessIncomingChunksIntoMessages

  private[worker] case object LastMessage

}

/** The actor which is in charge of unbatching messages. It checks MessageChunkTable whether there
  * is a data with status `Unbatching`. In case, there is data, this actor processes it and save to
  * MessageQueueTable.
  */
class MessageUnbatcherActor @Inject() (
    messageQueueRepository: IMessageQueueRepository,
    messageChunkRepository: IMessageChunkRepository,
    messageUnbatcher: IMessageUnbatcher,
    @Named("incoming-message-actor") incomingMessageActor: ActorRef,
    loggingService: ILoggingService,
    actorLoggingService: ActorLoggingService
) extends Actor {

  import InMessageActor._
  import MessageUnbatcherActor._

  implicit private val ec: ExecutionContext = context.dispatcher

  private val waiting: Receive = {
    case ProcessIncomingChunksIntoMessages =>
      actorLoggingService.tryWithLoggedBugs {
        loggingService.trace("MessageUnbatcherActor:waiting: ProcessIncomingChunksIntoMessages")
        self ! MessageUnbatcherActor.LastMessage
        context.become(waitingForAfterTheLastMessage)
      }
    case _                                 =>
      actorLoggingService.tryWithLoggedBugs {
        loggingService.trace("MessageBatcherActor:waiting:_")
      }
  }

  private def waitingForAfterTheLastMessage: Receive = {

    case MessageUnbatcherActor.LastMessage =>
      actorLoggingService.tryWithLoggedBugs {
        context.become(waiting)
        loggingService.trace(s"MessageUnbatcherActor: processing incoming chunks into messages")

        Await
          .ready(
            PaginationUtil.foldLeftInfStream(
              messageChunkRepository.getStreamWithStatusUnbatching(),
              { p: SimplePage[ExalateMessageChunk] => p.isLast }
            )(Future.successful(None)) { (_: None.type, p: SimplePage[ExalateMessageChunk]) =>
              processIncomingChunksIntoMessages(p.results)
            },
            Duration.Inf
          )
          .recoverWith {
            case f =>
              loggingService.error(
                "MessageUnbatcherActor: error while processing incoming chunks into messages",
                f
              )
              Future.successful(None)
          }

        incomingMessageActor ! ProcessIncomingMessagesInReadyStatus
      }
    case _                                 =>
      actorLoggingService.tryWithLoggedBugs {
        loggingService.trace("MessageBatcherActor:waitingForAfterTheLastMessage:_")
      }
  }

  def receive: Receive = waiting

  /** This method unbatches input chunks and save unbatched messages into MessageQueueTable, then
    * delete chunks from db
    * @param chunks
    *   \- extracted from DB, MessageChunkTable
    * @return
    */
  private def processIncomingChunksIntoMessages(
      chunks: Seq[ExalateMessageChunk]
  ): Future[None.type] = {
    val unbatchingResult = messageUnbatcher.unbatch(chunks)
    val unbatchedMessages = unbatchingResult.messageToChunks.keys.toSeq
    loggingService.trace(s"#processIncomingChunksIntoMessages unbatched `${unbatchedMessages
        .mkString("`,`")}` for connections `${unbatchedMessages.map(_.connectionId).mkString("`,`")}`")

    messageQueueRepository
      .create(unbatchedMessages)
      .flatMap { _ =>
        unbatchingResult.messageToChunks.values
          .foldLeft(Future.successful(None)) { (r, cs) =>
            r.flatMap(_ => deleteChunksFromDb(cs))
          }
      }
  }

  private def deleteChunksFromDb(chunks: Seq[ExalateMessageChunk]): Future[None.type] =
    FutureUtils
      .foldLeft(chunks.map(_.id)) {
        case None          => Future.successful(None)
        case Some(chunkId) => messageChunkRepository.delete(chunkId)
      }
      .map(_ => None)

}
