package com.exalate.replication.services.message

import com.exalate.api.ILoggingService
import com.exalate.api.domain.connection.IConnection
import com.exalate.api.exception.bug.BugException
import com.exalate.api.persistence.instance.IInstanceRepository
import com.exalate.api.persistence.issuetracker.IIssueTrackerOptionRepository
import com.exalate.api.persistence.message.IMessageQueueRepository
import com.exalate.api.persistence.relation.IRelationRepository
import com.exalate.domain.transport.message.MessageType.MessageType
import com.exalate.domain.transport.message.{ExalateMessage, MessageType}
import com.exalate.domain.transport.trackeroptions.OptionResponseStatus.OptionResponseStatus
import com.exalate.domain.transport.trackeroptions._
import com.exalate.domain.values.connection.ConnectionDraftResponseValue
import com.exalate.domain.values.{
  EditorContextStatsValue,
  EditorCustomFieldResponseValue,
  EditorFieldValue
}
import com.exalate.error.services.api.IBugExceptionCategoryService
import com.exalate.replication.services.api.config.IConnectionService
import com.exalate.replication.services.api.issuetracker.ITrackerOptionService
import com.exalate.replication.services.api.message.IExalateMessageService
import com.exalate.replication.services.transport.value.ExaCompFormatters._
import com.exalate.services.utils.pagination.{Page, PaginationUtil}
import com.exalate.util.json.gson.GsonCaseClassValueJsonService
import com.google.inject.Inject
import play.api.libs.json.{JsError, JsSuccess, Json}

import java.util.concurrent.ConcurrentHashMap
import scala.collection.JavaConverters._
import scala.concurrent.{ExecutionContext, Future}
import scala.util.{Failure, Success, Try}

/** Service which handle sending and receiving messages
  */

class ExalateMessageService @Inject() (
    messageQueueRepository: IMessageQueueRepository,
    connectionRepository: IRelationRepository,
    connectionService: IConnectionService,
    bugExceptionCategoryService: IBugExceptionCategoryService,
    loggingService: ILoggingService,
    trackerOptionService: ITrackerOptionService,
    trackerOptionRepository: IIssueTrackerOptionRepository,
    instancePersistance: IInstanceRepository
)(implicit ec: ExecutionContext)
    extends IExalateMessageService {
  val PROJECT_REQUEST: String = MessageType.PROJECT_REQUEST.toString
  val SYNC_REQUEST: String = MessageType.SYNC_REQUEST.toString
  val CONNECTION_DRAFT_REQUEST: String = MessageType.CONNECTION_DRAFT_REQUEST.toString
  val CONNECTION_DRAFT_RESPONSE: String = MessageType.CONNECTION_DRAFT_RESPONSE.toString
  val OPTION_REQUEST: String = MessageType.OPTION_REQUEST.toString
  val OPTION_RESPONSE: String = MessageType.OPTION_RESPONSE.toString
  val CUSTOM_FIELD_RESPONSE: String = MessageType.CUSTOM_FIELD_RESPONSE.toString
  val OPTION_RESPONSE_NUMBER: String = MessageType.OPTION_RESPONSE_NUMBER.toString
  val CUSTOM_FIELD_RESPONSE_NUMBER: String = MessageType.CUSTOM_FIELD_RESPONSE_NUMBER.toString

  /** The method which handles sending messages. It stores the exalate message into db
    * (MessageQueueTable) with status Ready for local connection and status Batching for non local
    * connection. Further this stored message will be handled by MessageBatcherActor for further
    * sending
    * @param m
    * @return
    *   index of saved message in db, if it has failed to save id will be -1
    */
  override def send(m: ExalateMessage): Future[Int] = m match {
    case ExalateMessage(content, messageType, connectionId, _, _, _) =>
      connectionRepository
        .getConnectionFuture(connectionId)
        .flatMap {
          case None             =>
            val errMsg = s"No connection found with ID `$connectionId`."
            val bugEx = bugExceptionCategoryService.generateBugException(None, Some(errMsg))
            loggingService.error(
              s"No connection was found with ID `$connectionId` while trying to create outgoing exalate message with content `$content` and message type `$messageType`."
            )
            Future.failed(bugEx)
          case Some(connection) =>
            loggingService.trace(
              "Start to prepare message Queue (with type " + messageType + ") for connection " + connection.getName
            )
            if (connection.isLocal)
              messageQueueRepository.createWithStatusReadyAndMessageDirectionIn(
                content,
                connectionId,
                messageType
              )
            else
              messageQueueRepository.createWithStatusBatchingAndMessageDirectionOut(
                content,
                connectionId,
                messageType
              )
        }
  }

  case class CustomFieldsBuildingResult(cfs: Seq[EditorFieldValue], succeeded: Seq[ExalateMessage])

  /** The method which handles receiving messages. It obtains a seq of messages with message types
    * and handles corresponding process depending on the type
    * @param ms
    *   seq of exalate messages
    * @param instanceId
    *   id of instance
    * @return
    *   seq of processed messages
    */
  override def receive(ms: Seq[ExalateMessage], instanceId: Int): Seq[Future[ExalateMessage]] = {
    ms
      .groupBy(_.messageType)
      .toSeq
      .foldLeft(Seq.empty[Future[ExalateMessage]]) {
        case (result, (CONNECTION_DRAFT_REQUEST, messages)) =>
          loggingService.trace(
            s"ExalateMessageService: processing connection_draft_request messages."
          )
          messages
            .foldLeft(result) { (r, exaMsg) =>
              val connectionID = exaMsg.connectionId
              val prevFuture = r.headOption
                .getOrElse(Future.successful(None))
              val nextFuture = prevFuture
                .flatMap { _ =>
                  connectionService
                    .updateFromConnectionDraftRequestMessageAndPrepareResponse(exaMsg)
                    .flatMap { draftResponseValue =>
                      val responseJsonStrFut =
                        GsonCaseClassValueJsonService.write[ConnectionDraftResponseValue](
                          draftResponseValue
                        ) match {
                          case Success(cdResponseStr) => Future.successful(cdResponseStr)
                          case Failure(e)             =>
                            val exception = bugExceptionCategoryService
                              .generateValueIntoJsonConvertingFailedBugException(
                                "ConnectionDraftValueResponse",
                                None,
                                Some(e)
                              )
                            val msg =
                              s"Failed to convert ConnectionDraftValueResponse `$draftResponseValue` into JSON."
                            loggingService.error(msg, exception)
                            Future.failed(exception)
                        }
                      responseJsonStrFut
                        .flatMap(responseJsonStr =>
                          send(
                            ExalateMessage(
                              responseJsonStr,
                              MessageType.CONNECTION_DRAFT_RESPONSE.toString,
                              connectionID
                            )
                          )
                        )
                    }
                    .map(_ => exaMsg)
                }
              nextFuture +: r
            }

        case (result, (CONNECTION_DRAFT_RESPONSE, messages)) =>
          loggingService.trace(
            s"ExalateMessageService: processing connection_draft_response messages."
          )
          messages.foldLeft(result) { (r, exalateMessage) =>
            val prevFuture = r.headOption.getOrElse(Future.successful(None))
            val nextFuture = prevFuture.flatMap { _ =>
              connectionService
                .updateConnectionDraftFromResponseMessage(exalateMessage)
                .map(_ => exalateMessage)
            }
            nextFuture +: r
          }

        case (result, (OPTION_RESPONSE, messages)) =>
          loggingService.trace(
            s"ExalateMessageService: going to process option_response_messages, $messages"
          )
          messages.foldLeft(result) { (r, exaMsg) =>
            // TODO EXAEDIT-956 validate access token?
            val content = exaMsg.content
            val connectionId = exaMsg.connectionId
            val optionResponseValueTry = GsonCaseClassValueJsonService
              .read[OptionResponseContentValue](content, classOf[OptionResponseContentValue])
            val prevFuture = r.headOption.getOrElse(Future.successful(None))
            val nextFuture = prevFuture
              .flatMap(_ => Future.fromTry(optionResponseValueTry))
              .recoverWith {
                case e =>
                  val exception =
                    bugExceptionCategoryService.generateJsonIntoValueConvertingFailedBugException(
                      content,
                      "OptionResponseContentValue",
                      Option(e.getMessage)
                    )
                  loggingService.error(
                    s"Failed to convert JSON `$content` into OptionResponseContentValue",
                    exception
                  )
                  Future.failed(exception)
              }
              .flatMap { optionResponseValue =>
                if (optionResponseValue.status == OptionResponseStatus.FAIL.toString) {
                  loggingService.warn(
                    s"Received unsuccessful response message on requesting remote options for `${optionResponseValue.field}` field. Received message: $exaMsg."
                  )
                  Future.successful(exaMsg)
                } else {
                  connectionRepository
                    .getConnectionFuture(connectionId)
                    .map {
                      case None             => None
                      case Some(connection) =>
                        Try(connection.getRemoteInstance.getNodeInfo).toOption.map(_.getInstanceUid)
                    }
                    .flatMap {
                      case None              =>
                        loggingService.warn(
                          s"Received a response message on requesting remote options for `${optionResponseValue.field}` field. Received message: $exaMsg. But could not find remote instance UID. Ignoring response message and removing request message."
                        )
                        Future.successful(exaMsg)
                      case Some(instanceUid) =>
                        val remoteTrackerOptions =
                          optionResponseValue.options
                            .map { optionValuesSeq =>
                              optionValuesSeq.map(o =>
                                EditorOptionsValueHelper.toIssueTrackerOption(o, instanceUid)
                              )
                            }
                            .getOrElse(Nil)
                        trackerOptionRepository.upsert(remoteTrackerOptions)

                        // after issue tracker options are saved to DB, we have to update EditorContextStatsValue in InstanceTable.fieldValues
                        // by increasing a number of `actualOptionsNumber`
                        instancePersistance.getFieldValues(instanceId).flatMap { fV =>
                          val fieldValues = fV.asScala
                            .get("editorContext")
                            .map(Json.parse)
                            .flatMap(_.asOpt[EditorContextStatsValue])
                          val ecsv = fieldValues match {
                            case Some(editorContextStatsValue) =>
                              editorContextStatsValue.copy(actualOptionsNumber =
                                editorContextStatsValue.actualOptionsNumber.map(_ + messages.size)
                              )
                            case None                          =>
                              EditorContextStatsValue(actualOptionsNumber = Option(messages.size))
                          }
                          instancePersistance
                            .upsertEditorContextStatsFieldValues(instanceId, ecsv)
                            .map(_ => exaMsg)
                        }
                    }
                }
              }
            nextFuture +: r
          }

        case (result, (OPTION_RESPONSE_NUMBER, messages)) =>
          loggingService.trace(
            s"ExalateMessageService: going to process OPTION_RESPONSE_NUMBER, $messages"
          )
          messages.foldLeft(result) { (r, exalateMessage) =>
            val prevFuture = r.headOption.getOrElse(Future.successful(None))
            val nextFuture = prevFuture.flatMap { _ =>
              val numberOfOptions = exalateMessage.content.toInt
              instancePersistance.getFieldValues(instanceId).flatMap { fV =>
                val fieldValues = fV.asScala
                  .get("editorContext")
                  .map(Json.parse)
                  .flatMap(_.asOpt[EditorContextStatsValue])
                val ecsv = fieldValues match {
                  case Some(editorContextStatsValue) =>
                    editorContextStatsValue.copy(expectedOptionsNumber =
                      editorContextStatsValue.expectedOptionsNumber.map(_ + numberOfOptions)
                    )
                  case None                          =>
                    EditorContextStatsValue(expectedOptionsNumber = Option(numberOfOptions))
                }
                instancePersistance
                  .upsertEditorContextStatsFieldValues(instanceId, ecsv)
                  .map(_ => exalateMessage)
              }
            }
            nextFuture +: r
          }

        case (r, (CUSTOM_FIELD_RESPONSE, messages)) =>
          loggingService.trace(
            s"ExalateMessageService: going to process custom_field_response_messages, $messages"
          )

          // TODO EXAEDIT-956 validate access token?
          val result = messages.foldLeft(CustomFieldsBuildingResult(Nil, Nil)) {
            case (result, ms) =>
              val content = ms.content
              Json.parse(content).validate[EditorCustomFieldResponseValue] match {
                case JsSuccess(customFieldResponseValue, _) =>
                  CustomFieldsBuildingResult(
                    result.cfs :+ customFieldResponseValue.customFieldValue,
                    result.succeeded :+ ms
                  )
                case e: JsError => CustomFieldsBuildingResult(result.cfs, result.succeeded)
              }

          }
          val upsertResult = instancePersistance.upsertCustomFields(instanceId, result.cfs)
          // after custom fields are saved to DB, we have to update EditorContextStatsValue in InstanceTable.fieldValues
          // by increasing a number of `actualCustomFieldsNumber`
          instancePersistance.getFieldValues(instanceId).flatMap { fV =>
            val fieldValues = fV.asScala
              .get("editorContext")
              .map(Json.parse)
              .flatMap(_.asOpt[EditorContextStatsValue])
            val ecsv = fieldValues match {
              case Some(editorContextStatsValue) =>
                editorContextStatsValue.copy(actualCustomFieldsNumber =
                  editorContextStatsValue.actualCustomFieldsNumber.map(_ + messages.size)
                )
              case None => EditorContextStatsValue(actualOptionsNumber = Option(messages.size))
            }
            instancePersistance.upsertEditorContextStatsFieldValues(instanceId, ecsv)
          }

          val msgProcessedFutures = result.succeeded.map(r => upsertResult.map(_ => r))
          r ++ msgProcessedFutures

        case (result, (CUSTOM_FIELD_RESPONSE_NUMBER, messages)) =>
          loggingService.trace(
            s"ExalateMessageService: going to process CUSTOM_FIELD_RESPONSE_NUMBER, $messages"
          )
          messages.foldLeft(result) { (r, exalateMessage) =>
            val prevFuture = r.headOption.getOrElse(Future.successful(None))
            val nextFuture = prevFuture.flatMap { _ =>
              val numberOfOptions = exalateMessage.content.toInt
              instancePersistance.getFieldValues(instanceId).flatMap { fV =>
                val fieldValues = fV.asScala
                  .get("editorContext")
                  .map(Json.parse)
                  .flatMap(_.asOpt[EditorContextStatsValue])
                val ecsv = fieldValues match {
                  case Some(editorContextStatsValue) =>
                    editorContextStatsValue.copy(expectedCustomFieldsNumber = Option(numberOfOptions))
                  case None                          =>
                    EditorContextStatsValue(expectedCustomFieldsNumber = Option(numberOfOptions))
                }
                instancePersistance
                  .upsertEditorContextStatsFieldValues(instanceId, ecsv)
                  .map(_ => exalateMessage)
              }
            }
            nextFuture +: r
          }

        case (result, (unexpectedMessageType, _)) =>
          loggingService.error(
            s"Unexpected message type $unexpectedMessageType. Skipping the process for it."
          )
          result ++ Seq(
            Future.failed[ExalateMessage](
              new BugException(
                s"Unexpected message type $unexpectedMessageType. Skipping the process for it."
              )
            )
          )
      }
  }

  private def sendFailureOptionsResponse(
      optionRequestValue: OptionRequestContentValue,
      connectionID: Int,
      msgId: Option[Int]
  ): Future[None.type] =
    prepareOptionsResponseContentStr(optionRequestValue, None, OptionResponseStatus.FAIL, None)
      .flatMap(c => sendResponse(c, MessageType.OPTION_RESPONSE, connectionID, msgId.toSeq))

  private def sendResponse(
      responseContent: String,
      msgType: MessageType,
      connectionID: Int,
      messageIDs: Seq[Int]
  ): Future[None.type] =
    send(ExalateMessage(responseContent, msgType.toString, connectionID)).map(_ => None)

  private def prepareOptionsResponseContentStr(
      optionRequestValue: OptionRequestContentValue,
      adminProofTokenOpt: Option[String],
      optionResponseStatus: OptionResponseStatus,
      options: Option[Seq[IssueTrackerOptionValue]]
  ): Future[String] = {
    val optionResponseContentValue = OptionResponseContentValue(
      adminProofTokenOpt,
      optionResponseStatus.toString,
      optionRequestValue.field,
      options
    )
    GsonCaseClassValueJsonService.write[OptionResponseContentValue](
      optionResponseContentValue
    ) match {
      case Success(oRespStr) => Future.successful(oRespStr)
      case Failure(e)        =>
        val exception =
          bugExceptionCategoryService.generateValueIntoJsonConvertingFailedBugException(
            "OptionResponseContentValue",
            None,
            Some(e)
          )
        val msg =
          s"Failed to convert OptionResponseContentValue `$optionResponseContentValue` into JSON."
        loggingService.error(msg, exception)
        Future.failed(exception)
    }
  }

  private def processIssueTrackerOptionRequest(
      optionRequestValue: OptionRequestContentValue,
      encodedResponseToken: String,
      connectionID: Int,
      msgId: Option[Int]
  ): Future[None.type] =
    optionRequestValue.field match {
      case f if f == EditorFields.PROJECT.toString    =>
        processTrackerOptionRequestForProjects(
          optionRequestValue,
          encodedResponseToken,
          connectionID,
          msgId
        )
      case f if f == EditorFields.ISSUE_TYPE.toString =>
        processTrackerOptionRequestForIssuetypes(
          optionRequestValue,
          encodedResponseToken,
          connectionID,
          msgId
        )
      case f if f == EditorFields.STATUS.toString     =>
        processTrackerOptionRequestForStatuses(
          optionRequestValue,
          encodedResponseToken,
          connectionID,
          msgId
        )
      case f if f == EditorFields.PRIORITY.toString   =>
        processTrackerOptionRequestForPriorities(
          optionRequestValue,
          encodedResponseToken,
          connectionID,
          msgId
        )
    }

  private def processTrackerOptionRequestForProjects(
      optionRequestValue: OptionRequestContentValue,
      encodedResponseToken: String,
      connectionID: Int,
      msgId: Option[Int]
  ): Future[None.type] =
    respondWithOptions(
      trackerOptionService.fetchProjectOptionsStream(),
      optionRequestValue,
      encodedResponseToken,
      connectionID,
      msgId
    )

  private def processTrackerOptionRequestForIssuetypes(
      optionRequestValue: OptionRequestContentValue,
      encodedResponseToken: String,
      connectionID: Int,
      msgId: Option[Int]
  ): Future[None.type] =
    respondWithOptions(
      trackerOptionService.fetchIssuetypeOptions(),
      optionRequestValue,
      encodedResponseToken,
      connectionID,
      msgId
    )

  private def processTrackerOptionRequestForStatuses(
      optionRequestValue: OptionRequestContentValue,
      encodedResponseToken: String,
      connectionID: Int,
      msgId: Option[Int]
  ): Future[None.type] =
    respondWithOptions(
      trackerOptionService.fetchStatusOptions(),
      optionRequestValue,
      encodedResponseToken,
      connectionID,
      msgId
    )

  private def processTrackerOptionRequestForPriorities(
      optionRequestValue: OptionRequestContentValue,
      encodedResponseToken: String,
      connectionID: Int,
      msgId: Option[Int]
  ): Future[None.type] =
    respondWithOptions(
      trackerOptionService.fetchPriorityOptions(),
      optionRequestValue,
      encodedResponseToken,
      connectionID,
      msgId
    )

  private def respondWithOptions(
      optStream: Stream[Future[Page[IssueTrackerOption]]],
      optionRequestValue: OptionRequestContentValue,
      encodedResponseToken: String,
      connectionID: Int,
      msgId: Option[Int]
  ): Future[None.type] = PaginationUtil
    .consumeInfPageStream[IssueTrackerOption, Page[IssueTrackerOption]](optStream) {
      trackerOptionsSeq: Seq[IssueTrackerOption] =>
        processTrackerOptionSeqAndSendResponseFut(
          trackerOptionsSeq,
          optionRequestValue,
          encodedResponseToken,
          connectionID,
          msgId
        )
    }

  private def processTrackerOptionSeqAndSendResponseFut(
      trackerOptionsSeq: Seq[IssueTrackerOption],
      optionRequestValue: OptionRequestContentValue,
      encodedResponseToken: String,
      connectionID: Int,
      msgId: Option[Int]
  ): Future[None.type] = {
    val trackerOptionValues =
      trackerOptionsSeq.map(EditorOptionsValueHelper.toIssueTrackerOptionValue)
    prepareOptionsResponseContentStr(
      optionRequestValue,
      Some(encodedResponseToken),
      OptionResponseStatus.SUCCESS,
      Some(trackerOptionValues)
    )
      .flatMap(c => sendResponse(c, MessageType.OPTION_RESPONSE, connectionID, msgId.toSeq))
  }

}

object ExalateMessageService {
  // connection to messages
  val datasetMap = new ConcurrentHashMap[Int, Seq[ExalateMessage]]()
}

case class CustomFieldMessageProcessingResult(connection: IConnection, json: String)
