package com.exalate.replication.services.message.worker

import akka.actor.Actor
import com.exalate.api.ILoggingService
import com.exalate.api.persistence.message.{IMessageChunkRepository, IMessageQueueRepository}
import com.exalate.domain.transport.message.{ExalateMessage, ExalateMessageBatch}
import com.exalate.replication.services.message.IMessageBatcher
import com.exalate.replication.services.utils.ActorLoggingService
import com.exalate.services.utils.FutureUtils
import com.exalate.services.utils.pagination.{PaginationUtil, SimplePage}
import com.google.inject.Inject

import scala.concurrent.duration.Duration
import scala.concurrent.{Await, ExecutionContext, Future}
import scala.util.{Failure, Success}

object MessageBatcherActor {

  case object ProcessMessages

  private[worker] case object LastMessage
}

/** An actor which check whether we have recording is MessageQueueTable, then takes information from
  * db, split it to chunks and saves to MessageChunkTable. After chunks are saved, corresponding
  * info from MessageQueueTable is deleted.
  */

class MessageBatcherActor @Inject() (
    messageQueueRepository: IMessageQueueRepository,
    messageChunkRepository: IMessageChunkRepository,
    messageBatcher: IMessageBatcher,
    loggingService: ILoggingService,
    actorLoggingService: ActorLoggingService
) extends Actor {

  import MessageBatcherActor._
  import MessageSenderActor._

  implicit private val ec: ExecutionContext = context.dispatcher

  private val waiting: Receive = {
    case ProcessMessages =>
      actorLoggingService.tryWithLoggedBugs {
        loggingService.trace("MessageBatcherActor:waiting: ProcessMessages")
        self ! MessageBatcherActor.LastMessage
        context.become(waitingForAfterTheLastMessage)
      }
    case _               =>
      actorLoggingService.tryWithLoggedBugs {
        loggingService.trace("MessageBatcherActor:waiting:_ ")
      }
  }

  private def waitingForAfterTheLastMessage: Receive = {

    case MessageBatcherActor.LastMessage =>
      context.become(waiting)
      actorLoggingService.tryWithLoggedBugs {
        loggingService.trace(s"MessageBatcherActor: processing messages in ready status")
        Await
          .ready(
            messageQueueRepository
              .getStreamWithStatusBatchingPerConnectionId()
              .flatMap(_.foldLeft(Future.successful(None)) { (r, messagesPerConnection) =>
                r.flatMap { _ =>
                  PaginationUtil.foldLeftInfStream(
                    messagesPerConnection,
                    { p: SimplePage[ExalateMessage] => p.isLast }
                  )(Future.successful(None)) { (_: None.type, p: SimplePage[ExalateMessage]) =>
                    processMessages(p.results)
                  }
                }
              }),
            Duration.Inf
          )
          .recoverWith {
            case f =>
              loggingService.error(
                "MessageBatcherActor Error while processing messages in ready status",
                f
              )
              Future.successful(None)
          }
      }

    case _ =>
      actorLoggingService.tryWithLoggedBugs {
        loggingService.trace("MessageBatcherActor:waitingForAfterTheLastMessage:_ ")
      }
  }

  def receive: Receive = waiting

  /** The method takes a seq with messages, split them into chunks, saves chinks into
    * MessageChunkTable and delete processed message from MessageQueueTable
    * @param messages
    * @return
    */
  private def processMessages(messages: Seq[ExalateMessage]): Future[None.type] = {
    loggingService.trace(s"#MessageBatcherActor: processMessages with size ${messages.size}")
    messageBatcher.splitMessagesIntoBatches(messages) match {
      case Failure(e)       =>
        loggingService.error(
          "#MessageBatcherActor failed to batch a message. Please Contact Exalate Support!",
          e
        )
        Future.successful(None)
      case Success(batches) =>
        val batchUids =
          FutureUtils.foldLeft(batches)(batch => processBatch(batch).map(_ => batch.uuid))
        val result = batchUids
          .flatMap(messageChunkRepository.moveToStatusSendingByBatch)
          .flatMap(_ => deleteMessageFromDb(messages))
        result.foreach(_ => context.system.actorSelection("/user/*") ! SendMessages)
        result
    }
  }

  /** Saves processed chunks from input batch into MessageChunkTable
    * @param batch
    * @return
    *   a seq of id of the saved chunks
    */
  private def processBatch(batch: ExalateMessageBatch): Future[Seq[Int]] =
    FutureUtils.foldLeft(batch.chunks)(messageChunkRepository.create)

  private def deleteMessageFromDb(messages: Seq[ExalateMessage]): Future[None.type] = {
    val messageIdsToDelete = messages.map(_.id).collect {
      case Some(m) => m
    }
    messageQueueRepository.delete(messageIdsToDelete)
  }

}
