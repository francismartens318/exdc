package com.exalate.replication.services.message

import java.nio.charset.StandardCharsets
import java.util.UUID

import com.exalate.api.ILoggingService
import com.exalate.api.domain.connection.ConnectionStatus
import com.exalate.api.domain.instance.IInstance
import com.exalate.api.exception.bug.BugException
import com.exalate.api.persistence.relation.IRelationRepository
import com.exalate.domain.transport.message.{
  ChunkStatus,
  ExalateMessage,
  ExalateMessageBatch,
  ExalateMessageChunk
}
import com.exalate.services.utils.FutureUtils
import com.exalate.util.DateUtil
import javax.inject.Inject

import scala.annotation.tailrec
import scala.util.{Failure, Success, Try}

object MessageBatcher {
  // 1 megabyte in bytes
  final val BATCH_SIZE_LIMIT_BYTE = 1048576
}

class MessageBatcher @Inject() (
    relationRepository: IRelationRepository,
    loggingService: ILoggingService
) extends IMessageBatcher {

  def len(str: String): Int =
    toBytes(str).length

  private def toBytes(str: String) =
    str
      .getBytes(StandardCharsets.UTF_8)

  case class BatchingResult(allBatches: Seq[ExalateMessageBatch])

  /** Splits provided message into ExalateMessageBatch
    * @param messages
    *   seq of exalate messages
    * @param BATCH_SIZE_LIMIT_BYTE
    *   size of the batch in bytes (2MB)
    * @return
    *   Try[Seq[ExalateMessageBatch]]
    */
  def splitMessagesIntoBatches(
      messages: Seq[ExalateMessage],
      BATCH_SIZE_LIMIT_BYTE: Int = MessageBatcher.BATCH_SIZE_LIMIT_BYTE
  ): Try[Seq[ExalateMessageBatch]] = {

    val seqWithAnEmptyBatch =
      Seq[ExalateMessageBatch](ExalateMessageBatch(UUID.randomUUID().toString, Seq()))

    val initialResultTry =
      Success(BatchingResult(seqWithAnEmptyBatch)).asInstanceOf[Try[BatchingResult]]
    messages
      .foldLeft(initialResultTry) {
        case (Success(BatchingResult(bs)), m) =>
          val connectionOpt =
            FutureUtils.resultInf(relationRepository.getConnectionFuture(m.connectionId))
          connectionOpt match {
            case Some(c) if !ConnectionStatus.DEACTIVATED.equals(c.getStatus) =>
              splitMessageIntoBatches(BATCH_SIZE_LIMIT_BYTE)(c.getRemoteInstance, bs, m)
            case _ => Try(BatchingResult(bs))
          }
        case (r @ Failure(_), _)              => r
      }
      .map { batchingResult =>
        val batches = batchingResult.allBatches

        if (batches.last.chunks.isEmpty) {
          // remove last batchUUID if it's empty
          batches.init
        } else {
          batches
        }
      }
  }

  /** a naive approach to optimize search of an approximation: we divide the optimized argument in 2
    * and check
    * @param f
    *   \- function that calculates batch size given some content length
    */
  @tailrec
  final def firstSufficientViaBiSection[Y](
      x: Int,
      f: Int => Try[Y],
      isSufficientPredicate: Y => Boolean
  ): Try[Option[Int]] =
    if (x == 0) Success(None)
    else {
      f(x) match {
        case Failure(e)                             => Failure(e)
        case Success(y) if isSufficientPredicate(y) => Success(Some(x))
        case Success(_) => firstSufficientViaBiSection(x / 2, f, isSufficientPredicate)
      }
    }

  def calculateBatchSize(b: ExalateMessageBatch, remoteInstance: IInstance): Try[Int] =
    ExalateMessageValueHelper
      .toJsonTryBatch(b.chunks, remoteInstance)
      .recoverWith {
        case e =>
          loggingService.error(
            s"#MessageBatcher #splitMessageIntoBatches #calculateBatchSize failed to write testBatch. Please Contact Exalate Support!"
          )
          Failure[String](e)
      }
      .map(len)

  /** Split one message into batches and chunks
    *
    * @return
    *   a pair (batches, freeSpaceInLastBatch)
    */
  @scala.annotation.tailrec
  private def splitMessageIntoBatches(maxBatchSize: Int)(
      remoteInstance: IInstance,
      batches: Seq[ExalateMessageBatch],
      m: ExalateMessage,
      startIndexInMessage: Int = 0,
      totalChunksInMessage: Int = 1
  ): Try[BatchingResult] = {
    loggingService.info(
      s"#splitMessageIntoBatches batching message of type `${m.messageType}` for connection ${m.connectionId} at `${DateUtil.dateNowStr()}`"
    )

    def batchLength(contentLength: Int): Try[Int] = {
      val trimmedChunkContent = m.content.take(contentLength)
      val chunkContentString = trimmedChunkContent
      val curBatch = batches.last
      val batchUUID = batches.last.uuid
      val chunkOpt =
        createChunk(m, chunkContentString, startIndexInMessage, totalChunksInMessage, batchUUID)
      val testBatch = curBatch.copy(chunks = curBatch.chunks ++ chunkOpt)
      val testBatchSizeTry = calculateBatchSize(testBatch, remoteInstance)
      testBatchSizeTry
    }

    val curBatch = batches.last
    val chunkContentString = m.content
    val batchUUID = batches.last.uuid
    val chunkOpt =
      createChunk(m, chunkContentString, startIndexInMessage, totalChunksInMessage, batchUUID)
    val testBatch = curBatch.copy(chunks = curBatch.chunks ++ chunkOpt)
    val testBatchSizeTry = calculateBatchSize(testBatch, remoteInstance)
    val messageContent = toBytes(m.content)
    // noinspection ScalaUnusedSymbol
    testBatchSizeTry match {
      case Failure(e) =>
        Failure[BatchingResult](e)

      case tooBig @ Success(testBatchSize) if testBatchSize > maxBatchSize =>
        val isCurrentBatchEmpty = curBatch.chunks.isEmpty
        val smallestMessageSizeTry =
          if (!isCurrentBatchEmpty) batchLength(1)
          else Success(1)
        val fitsFn: Int => Boolean = s => s <= maxBatchSize
        val curChunkSizeOptTry = smallestMessageSizeTry
          .recoverWith {
            case e =>
              loggingService.error(
                s"#splitMessageIntoBatches failed to write even the shortest message into `$curBatch`. Please notify Exalate Support!"
              )
              Failure(e)
          }
          // !important if we split the content in two we'd eventually get to the smallest message possible
          // TODO 2609f5b6-c7b5-410f-b6be-f8d4ee3c159c: ideally, we could come up with an analytic formula, that calculates the max size of content given maxBatchSize, messageType, index, total, constantPrevContent and content: `| maxBatchSize - size(content, constantPrevContent, messageType, index, total) | -> 0`
          .flatMap { batchSizeWithSmallestMessage =>
            if (batchSizeWithSmallestMessage > maxBatchSize) Success(None)
            else firstSufficientViaBiSection[Int](m.content.length, batchLength, fitsFn)
          }
        curChunkSizeOptTry match {
          case Failure(e)                  => Failure[BatchingResult](e)
          case Success(None)               =>
            if (isCurrentBatchEmpty)
              Failure(
                new BugException(
                  "#MessageBatcher #splitMessageIntoBatches BUG - the message content size is too close to the maxBatchSize for the message to be chunked!"
                )
              )
            else {
              loggingService.debug(
                s"#MessageBatcher #splitMessageIntoBatches received a chunk with overflow bigger than the chunk content itself: " +
                  s"maxBatchSize=$maxBatchSize testBatchSize=$testBatchSize messageContent.length=${messageContent.length}" +
                  s"starting a new batch"
              )
              splitMessageIntoBatches(maxBatchSize)(
                remoteInstance,
                batches :+ ExalateMessageBatch(UUID.randomUUID().toString, Seq()),
                m,
                startIndexInMessage,
                totalChunksInMessage
              )
            }
          case Success(Some(curChunkSize)) =>
            loggingService.debug(
              s"#MessageBatcher #splitMessageIntoBatches taking $curChunkSize out of the messageContent: " +
                s"maxBatchSize=$maxBatchSize testBatchSize=$testBatchSize messageContent.length=${messageContent.length}" +
                s"starting a new batch"
            )
            val maxChunkContentForBatch = toBytes(m.content.take(curChunkSize))
            val batchesWithNewChunk = updateBatchesWithNewChunk(
              batches,
              maxChunkContentForBatch,
              m,
              startIndexInMessage,
              totalChunksInMessage
            )
            val remainContent = toBytes(m.content.drop(curChunkSize))
            val remainContentString = new String(remainContent, StandardCharsets.UTF_8)
            // update content of message to content without part that in the chunk and reset free space to batchUUID limit
            val newTotal = totalChunksInMessage + 1
            val withNewTotal = updateChunksWithNewTotal(m.id.get, newTotal, batchesWithNewChunk)
            splitMessageIntoBatches(maxBatchSize)(
              remoteInstance,
              withNewTotal :+ ExalateMessageBatch(UUID.randomUUID().toString, Seq()),
              m.copy(content = remainContentString),
              startIndexInMessage + 1,
              newTotal
            )
        }

      case fits @ Success(testBatchSize) if testBatchSize <= maxBatchSize =>
        val batchesWithNewChunk = updateBatchesWithNewChunk(
          batches,
          messageContent,
          m,
          startIndexInMessage,
          totalChunksInMessage
        )
        if (testBatchSize == maxBatchSize) {
          // no available space in batchUUID -> create a new batchUUID and reset free space to batchUUID limit
          Success(
            BatchingResult(
              batchesWithNewChunk :+ ExalateMessageBatch(UUID.randomUUID().toString, Seq())
            )
          )
        } else {
          Success(BatchingResult(batchesWithNewChunk))
        }
    }
  }

  private def updateChunksWithNewTotal(
      messageId: Int,
      totalChunksInMessage: Int,
      batches: Seq[ExalateMessageBatch]
  ): Seq[ExalateMessageBatch] =
    batches.map { b =>
      b.copy(chunks = b.chunks.map { c =>
        if (c.messageId == messageId) c.copy(totalChunksInMessage = totalChunksInMessage)
        else c
      })
    }

  private def updateBatchesWithNewChunk(
      batches: Seq[ExalateMessageBatch],
      chunkContent: Array[Byte],
      mes: ExalateMessage,
      startIndexInMessage: Int,
      totalChunksInMessage: Int
  ): Seq[ExalateMessageBatch] = {
    val chunkContentString = new String(chunkContent, StandardCharsets.UTF_8)
    val batchUUID = batches.last.uuid
    val chunkOpt =
      createChunk(mes, chunkContentString, startIndexInMessage, totalChunksInMessage, batchUUID)
    val lastBatchChunksWithNewChunk =
      chunkOpt.map(chunk => Seq(batches.last.chunks: _*) :+ chunk).getOrElse(Seq(batches.last.chunks: _*))
    batches.init :+ ExalateMessageBatch(batchUUID, lastBatchChunksWithNewChunk)
  }

  /** Form provided values into ExalateMessageChunk
    * @param mes
    *   ExalateMessage
    * @param chunkContent
    *   content of the chunk
    * @param startIndexInMessage
    * @param totalChunksInMessage
    * @param batchUUID
    * @return
    *   ExalateMessageChunk
    */
  private def createChunk(
      mes: ExalateMessage,
      chunkContent: String,
      startIndexInMessage: Int,
      totalChunksInMessage: Int,
      batchUUID: String
  ): Option[ExalateMessageChunk] = {

    if (mes.id.isEmpty) {
      loggingService.error(s"Exalate message $mes does not have an id. Skipping..")
      return None
    }

    Some(
      ExalateMessageChunk(
        None,
        mes.id.get,
        batchUUID,
        chunkContent,
        mes.connectionId,
        startIndexInMessage,
        totalChunksInMessage,
        ChunkStatus.BATCHING.toString,
        mes.messageType
      )
    )
  }

}
