package com.exalate.replication.services.message.worker

import akka.actor.Actor
import com.exalate.api.ILoggingService
import com.exalate.api.domain.connection.IConnection
import com.exalate.api.persistence.message.IMessageChunkRepository
import com.exalate.api.persistence.relation.IRelationRepository
import com.exalate.domain.exception.config.ConnectionOnRemoteSideNotFoundExalateConfigException
import com.exalate.domain.transport.message.ExalateMessageChunk
import com.exalate.replication.services.api.transport.IMessageHttpClientFactory
import com.exalate.replication.services.utils.ActorLoggingService
import com.exalate.services.utils.pagination.{PaginationUtil, SimplePage}
import com.google.inject.Inject

import scala.concurrent.duration.Duration
import scala.concurrent.{Await, ExecutionContext, Future}

object MessageSenderActor {

  case object SendMessages

  private[worker] case object LastMessage
}

/** An actor which check whether we have recording is MessageChunkTable, then takes information from
  * db and send to the remote side using messageHttpClient.
  */

class MessageSenderActor @Inject() (
    messageChunkRepository: IMessageChunkRepository,
    messsageHttpClientFactory: IMessageHttpClientFactory,
    relationRepository: IRelationRepository,
    loggingService: ILoggingService,
    actorLoggingService: ActorLoggingService
) extends Actor {

  import MessageSenderActor._

  implicit private val ec: ExecutionContext = context.dispatcher

  def receive: Receive = waiting

  private val waiting: Receive = {
    case SendMessages =>
      actorLoggingService.tryWithLoggedBugs {
        loggingService.trace("MessageSenderActor:waiting: SendMessages")
        self ! LastMessage
        context.become(waitingForAfterTheLastMessage)
      }
    case _            =>
      actorLoggingService.tryWithLoggedBugs {
        loggingService.trace("MessageSenderActor:waiting:_")
      }
  }

  val BATCHES_PER_PAGE = 1

  /** Extracts chunks from db and sends them to the remote side
    * @return
    */
  private def waitingForAfterTheLastMessage: Receive = {
    case LastMessage =>
      context.become(waiting)
      actorLoggingService.tryWithLoggedBugs {
        loggingService.trace(s"MessageSenderActor: sending messages")

        Await
          .ready(
            PaginationUtil.foldLeftInfStream(
              messageChunkRepository.getStreamWithStatusSending(),
              { p: SimplePage[ExalateMessageChunk] => p.isLast }
            )(Future.successful(None)) { (_: None.type, p: SimplePage[ExalateMessageChunk]) =>
              // Getting batch uuid from first chunk
              val firstChunkOpt = p.results.headOption
              firstChunkOpt match {
                case Some(firstChunk) =>
                  loggingService.trace(
                    "MessageSenderActor Going to send " + p.results.size + " message chunks"
                  )
                  relationRepository
                    .getConnectionFuture(firstChunk.connectionId)
                    .flatMap {
                      case Some(c) =>
                        sendChunks(firstChunk.batchUUID, c)(p.results)
                          .map(_ => deleteChunksFromDb(p.results))
                          .recoverWith {
                            case e: ConnectionOnRemoteSideNotFoundExalateConfigException =>
                              loggingService.warn(e.getMessage)
                              relationRepository.deActivateConnection(firstChunk.connectionId)
                              deleteChunksFromDb(p.results)
                              Future.successful(None)
                            case _                                                       =>
                              Future.successful(None)
                          }
                          .map(_ => None)
                      case _       =>
                        Future.successful(None)
                    }
                    .recoverWith {
                      case f =>
                        loggingService
                          .error("MessageSenderActor Error while getting connection from db", f)
                        Future.failed(f)
                    }
                case None             =>
                  loggingService.trace(
                    "MessageSenderActor There are no message chunks with status SENDING"
                  )
                  Future.successful(None)
              }

            },
            Duration.Inf
          )
          .recoverWith {
            case f =>
              loggingService.error("MessageSenderActor: error while sending messages", f)
              Future.successful(None)
          }
      }

    case _ =>
      actorLoggingService.tryWithLoggedBugs {
        loggingService.trace("MessageSenderActor:waitingForAfterTheLastMessage:_")
      }
  }

  private def sendChunks(batchUid: String, connection: IConnection)(
      chunks: Seq[ExalateMessageChunk]
  ): Future[None.type] =
    if (chunks.isEmpty) {
      loggingService.warn(
        s"MessageSenderActor: Batch with UUID $batchUid has zero chunks. Skipping.."
      )
      Future.successful(None)
    } else {
      messsageHttpClientFactory
        .get(connection.getRemoteInstance)
        .sendBatchValue(connection, chunks)
        .map(_ => None)
    }

  private def deleteChunksFromDb(chunks: Seq[ExalateMessageChunk]): Unit = {
    val connectionIds = chunks.map(_.connectionId).distinct
    loggingService.trace(
      s"#deleteChunksFromDb removing ${chunks.size} message chunks from queue for connections $connectionIds"
    )
    chunks.map(_.id).foreach(_.map(messageChunkRepository.delete))
  }

}
