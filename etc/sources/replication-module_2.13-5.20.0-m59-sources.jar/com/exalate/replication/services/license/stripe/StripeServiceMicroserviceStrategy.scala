package com.exalate.replication.services.license.stripe

import com.exalate.clients.GrpcClient
import com.exalate.domain.GeneralSettings
import com.exalate.domain.exception.issuetracker.InternalServerErrorTrackerRestException
import com.exalate.domain.values.license.stripe._
import com.exalate.proto.licensing.{
  Customer => ProtoCustomer,
  EmptyRequest,
  GenerateBillingPortalSessionRequest,
  GenerateStripeCustomerRequest,
  GenerateStripeSessionRequest,
  GenerateStripeSubscriptionRequest,
  GetStripeSubscriptionByCustomerRequest,
  GetStripeSubscriptionRequest,
  GetStripeSubscriptionResponse,
  PayInvoiceRequest,
  StripeAddressValue => ProtoStripeAddressValue,
  StripeCustomerResponse,
  StripeExpandedSubscriptionResponse,
  StripeInvoice,
  StripeShippingValue => ProtoStripeShippingValue,
  StripeVATValue => ProtoStripeVATValue,
  UnsubscribeRequest,
  UpdateStripeCustomerRequest
}
import com.exalate.replication.services.api.config.IGeneralSettingsService
import com.exalate.replication.services.api.issuetracker.IIssueTrackerUrlService
import com.exalate.replication.services.license.stripe.StripeServiceMicroserviceStrategy._
import com.exalate.replication.services.transport.value.ExaCompFormatters.stripeCustomerValueFormat
import play.api.Logger
import play.api.cache.AsyncCacheApi
import play.api.libs.json.Json

import javax.inject.Inject
import scala.concurrent.{ExecutionContext, Future}

class StripeServiceMicroserviceStrategy @Inject() (
    val generalSettingsService: IGeneralSettingsService,
    grpcClient: GrpcClient,
    issueTrackerUrlService: IIssueTrackerUrlService,
    cache: AsyncCacheApi
)(implicit val ec: ExecutionContext)
    extends IStripeServiceStrategy {

  private val LOG = Logger(classOf[StripeServiceMicroserviceStrategy])

  override def generateSession(): Future[String] =
    for {
      settings <- generalSettingsService.get.map(_.map(_.asInstanceOf[GeneralSettings]))
      stripeRedirectUrlOpt <- issueTrackerUrlService.getSuccessUrl()
      stripeRedirectUrl <- stripeRedirectUrlOpt match {
        case Some(stripeRedirectUrl) => Future.successful(stripeRedirectUrl)
        case None                    =>
          val details = "Stripe redirect url not found. Please contact support"
          LOG.error(details)
          Future.failed(new InternalServerErrorTrackerRestException(details))
      }
      result <- grpcClient.licenseService
        .generateStripeSession(
          GenerateStripeSessionRequest(
            stripeRedirectUrl,
            settings.flatMap(_.getExalateUrl),
            settings.flatMap(
              _.fieldValues.get("customer")
            )
          )
        )
    } yield result.sessionId

  override def unsubscribe(subscriptionId: String): Future[Unit] =
    grpcClient.licenseService
      .unsubscribe(UnsubscribeRequest(subscriptionId))
      .map(_ => cache.remove("licenseInfo"))

  override def getSubscription(subscriptionId: String): Future[Option[StripeSubscriptionValue]] =
    for {
      stripeSubscriptionResponse <- grpcClient.licenseService.getStripeSubscription(
        GetStripeSubscriptionRequest(subscriptionId)
      )
      subscriptionValue = Option(convertToStripeSubscriptionValue(stripeSubscriptionResponse))
    } yield subscriptionValue

  override def generateBillingPortalSession(): Future[String] =
    for {
      settings <- generalSettingsService.get.map(_.map(_.asInstanceOf[GeneralSettings]))
      customerId = settings.flatMap(_.fieldValues.get("customer"))
      successUrl <- issueTrackerUrlService.getSuccessUrl()
      request = GenerateBillingPortalSessionRequest(customerId, successUrl)
      billingPortalSession <- grpcClient.licenseService.generateBillingPortalSession(request)
    } yield billingPortalSession.billingPortalSessionUrl

  override def getExpandedSubscription(
      subscriptionId: String
  ): Future[Option[StripeExpandedSubscriptionValue]] =
    for {
      stripeSubscriptionResponse <- grpcClient.licenseService.getStripeExpandedSubscription(
        GetStripeSubscriptionRequest(subscriptionId)
      )
      expandedSubscriptionValue = Option(
        convertToStripeExpandedSubscriptionValue(stripeSubscriptionResponse)
      )
    } yield expandedSubscriptionValue

  override def generateCustomer(
      customerValue: StripeCustomerValue
  ): Future[Option[StripeCustomerValue]] =
    for {
      stripeCustomerResponse <- grpcClient.licenseService.generateStripeCustomer(
        customerValueToGenerateCustomerRequest(customerValue)
      )
      customerValue = convertToCustomerValue(stripeCustomerResponse)
    } yield customerValue

  override def updateCustomer(
      customerValue: StripeCustomerValue,
      customerId: String
  ): Future[Option[StripeCustomerValue]] =
    for {
      updateStripeCustomerResponse <- grpcClient.licenseService.updateStripeCustomer(
        customerValueToUpdateCustomerRequest(customerId, customerValue)
      )
      customerValue = convertToCustomerValue(updateStripeCustomerResponse)
    } yield customerValue

  override def getSubscriptionByCustomer(
      customerId: String
  ): Future[Option[StripeExpandedSubscriptionValue]] =
    for {
      stripeSubscriptionResponse <- grpcClient.licenseService.getStripeSubscriptionByCustomer(
        GetStripeSubscriptionByCustomerRequest(customerId)
      )
      expandedSubscriptionValue = Option(
        convertToStripeExpandedSubscriptionValue(stripeSubscriptionResponse)
      )
    } yield expandedSubscriptionValue

  override def generateSubscription(
      customerId: String
  ): Future[Option[StripeExpandedSubscriptionValue]] =
    for {
      generalSettings <- generalSettingsService.get
      request = GenerateStripeSubscriptionRequest(
        customerId,
        generalSettings.flatMap(_.getExalateUrl)
      )
      stripeSubscriptionResponse <- grpcClient.licenseService.generateStripeSubscription(request)
    } yield Option(convertToStripeExpandedSubscriptionValue(stripeSubscriptionResponse))

  override def payInvoice(invoiceId: String): Future[Option[StripeInvoiceValue]] =
    for {
      stripeInvoice <- grpcClient.licenseService.payInvoice(PayInvoiceRequest(invoiceId))
      stripeInvoiceValue = Option(toStripeInvoiceValue(stripeInvoice))
    } yield stripeInvoiceValue

  override def getPublishableKey(): Future[String] = for {
    stripePublishableKey <- grpcClient.licenseService.getPublishableKey(EmptyRequest())
    publishableKey = stripePublishableKey.publishableKey
  } yield publishableKey

}

object StripeServiceMicroserviceStrategy {

  private def convertToCustomerValue(
      stripeCustomerResponse: StripeCustomerResponse
  ): Option[StripeCustomerValue] =
    Option(Json.parse(stripeCustomerResponse.response).as[StripeCustomerValue])

  private def customerValueToGenerateCustomerRequest(
      customerValue: StripeCustomerValue
  ): GenerateStripeCustomerRequest =
    GenerateStripeCustomerRequest(
      customerValueToCustomerRequest(customerValue)
    )

  private def customerValueToUpdateCustomerRequest(
      customerId: String,
      customerValue: StripeCustomerValue
  ): UpdateStripeCustomerRequest =
    UpdateStripeCustomerRequest(
      customerId,
      customerValueToCustomerRequest(customerValue)
    )

  private def customerValueToCustomerRequest(
      customerValue: StripeCustomerValue
  ): Option[ProtoCustomer] = {

    val address: ProtoStripeAddressValue =
      ProtoStripeAddressValue(
        customerValue.address.city,
        customerValue.address.country,
        customerValue.address.line1,
        customerValue.address.line2,
        customerValue.address.postal_code,
        customerValue.address.state
      )
    val shippingValue: Option[ProtoStripeShippingValue] = customerValue.shipping.map { shipping =>
      ProtoStripeShippingValue(
        Option(address),
        shipping.name
      )
    }

    Option(
      ProtoCustomer(
        customerValue.id,
        Option(address),
        shippingValue,
        customerValue.email,
        customerValue.name,
        customerValue.source,
        customerValue.tax_id_data.map(taxId => ProtoStripeVATValue(taxId.`type`, taxId.value))
      )
    )

  }

  private def convertToStripeSubscriptionValue(
      stripeSubscriptionProto: GetStripeSubscriptionResponse
  ): StripeSubscriptionValue =
    StripeSubscriptionValue(
      stripeSubscriptionProto.subscriptionId,
      stripeSubscriptionProto.currentPeriodStart,
      stripeSubscriptionProto.currentPeriodEnd,
      stripeSubscriptionProto.metadata,
      stripeSubscriptionProto.status,
      stripeSubscriptionProto.trialEnd,
      stripeSubscriptionProto.customer
    )

  private def toStripeInvoiceValue(latestInvoice: StripeInvoice): StripeInvoiceValue = {
    val paymentIntent = latestInvoice.paymentIntent.get
    val stripePaymentIntentValue = StripePaymentIntentValue(
      paymentIntent.status,
      paymentIntent.clientSecret
    )
    val stripeInvoiceValue = StripeInvoiceValue(
      latestInvoice.id,
      stripePaymentIntentValue
    )
    stripeInvoiceValue
  }

  private def convertToStripeExpandedSubscriptionValue(
      stripeSubscriptionProto: StripeExpandedSubscriptionResponse
  ): StripeExpandedSubscriptionValue = {

    val stripeInvoiceValue: StripeInvoiceValue = stripeSubscriptionProto.latestInvoice
      .map(invoice => toStripeInvoiceValue(invoice))
      .getOrElse(
        throw new IllegalStateException("Latest invoice is not present")
      )
    StripeExpandedSubscriptionValue(
      stripeSubscriptionProto.subscriptionId,
      stripeSubscriptionProto.currentPeriodStart,
      stripeSubscriptionProto.currentPeriodEnd,
      stripeSubscriptionProto.metadata,
      stripeSubscriptionProto.status,
      stripeSubscriptionProto.trialEnd,
      stripeSubscriptionProto.customer,
      stripeInvoiceValue
    )
  }

}
