package com.exalate.replication.services.license

import com.exalate.generic.services.api.INodeTypeProvider
import com.exalate.replication.services.api.config.IGeneralSettingsService
import com.exalate.replication.services.api.node.lifecycle.ILifecycleInfoService
import com.exalate.replication.services.transport.v1.rest.IEvaluationClient
import play.api.libs.json.JsValue

import javax.inject.{Inject, Singleton}
import scala.concurrent.{ExecutionContext, Future}

@Singleton
class EvaluationDetailsService @Inject() (
    lifecycleInfoService: ILifecycleInfoService,
    generalSettingsService: IGeneralSettingsService,
    evaluationClient: IEvaluationClient,
    nodeTypeProvider: INodeTypeProvider
)(implicit ec: ExecutionContext) {

  def postEvaluationDetails(email: String): Future[JsValue] =
    // Proxy user should be added to EvaluationValue from generalSettings.fieldValues once there is node that have proxyUser
    for {
      instanceUid <- lifecycleInfoService.getInstanceUid
      generalSettings <- generalSettingsService.get
      evaluationValue = com.exalate.domain.values.license.EvaluationValue(
        nodeTypeProvider.getNodeType,
        generalSettings.get.getIssueTrackerUrl,
        instanceUid,
        email,
        generalSettings.get.getExalateUrl,
        "",
        "4.0"
      )
      postEvaluationDetails <- evaluationClient.postEvaluationDetails(evaluationValue)
    } yield postEvaluationDetails

}
