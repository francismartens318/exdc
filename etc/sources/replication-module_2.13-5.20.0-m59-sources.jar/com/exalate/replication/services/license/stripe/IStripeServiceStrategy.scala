package com.exalate.replication.services.license.stripe

import com.exalate.domain.values.license.stripe.{
  StripeCustomerValue,
  StripeExpandedSubscriptionValue,
  StripeInvoiceValue,
  StripeSubscriptionValue
}

import scala.concurrent.Future

@deprecated
trait IStripeServiceStrategy {
  def generateSession(): Future[String]
  def unsubscribe(subscriptionId: String): Future[Unit]
  def getSubscription(subscriptionId: String): Future[Option[StripeSubscriptionValue]]
  def generateBillingPortalSession(): Future[String]

  def getExpandedSubscription(
      subscriptionId: String
  ): Future[Option[StripeExpandedSubscriptionValue]]

  def generateCustomer(customerValue: StripeCustomerValue): Future[Option[StripeCustomerValue]]

  def updateCustomer(
      customerValue: StripeCustomerValue,
      customerId: String
  ): Future[Option[StripeCustomerValue]]

  def getSubscriptionByCustomer(customerId: String): Future[Option[StripeExpandedSubscriptionValue]]
  def generateSubscription(customerId: String): Future[Option[StripeExpandedSubscriptionValue]]
  def payInvoice(invoiceId: String): Future[Option[StripeInvoiceValue]]
  def getPublishableKey(): Future[String]
}
