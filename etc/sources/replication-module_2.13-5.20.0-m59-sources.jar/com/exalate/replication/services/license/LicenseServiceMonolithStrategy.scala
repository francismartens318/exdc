package com.exalate.replication.services.license

import cats.implicits._
import com.exalate.api.IConfigurationService
import com.exalate.api.domain.connection.{IConnection, INonPersistentConnection}
import com.exalate.api.domain.connection.fieldvalues.ConnectionMode
import com.exalate.api.domain.event.ISyncEvent
import com.exalate.api.domain.license._
import com.exalate.api.license.{ILicenseEncoderService, ILicenseValidationService}
import com.exalate.api.persistence.license.ILicenseRepository
import com.exalate.api.persistence.relation.IRelationRepository
import com.exalate.api.persistence.twintrace.ITwinTraceRepository
import com.exalate.basic.domain.license.{License, NonPersistentLicense}
import com.exalate.basic.domain.util.SemanticVersionService
import com.exalate.domain.replication.{BasicSyncEvent, BasicSyncRequest}
import com.exalate.domain.values.license.{ExalateLicensesValue, LicenseUsageValue, LicenseValue}
import com.exalate.replication.services.api.config.IGeneralSettingsService
import com.exalate.replication.services.api.issuetracker.ITrackerLicenseService
import com.exalate.replication.services.api.license.ILicenseService
import com.exalate.replication.services.api.node.lifecycle.ILifecycleInfoService
import com.exalate.replication.services.api.transport.smtp.IMailService
import com.exalate.replication.services.config.ConnectionGroupUtils
import com.exalate.replication.services.license.LicenseServiceMonolithStrategyHelper.DEFAULT_DATE
import com.exalate.replication.services.license.SubscriptionValidationResult.{
  ExalateSubscriptionValidation,
  TrackerSubscriptionValidation
}
import com.exalate.replication.services.license.stripe.{IStripeServiceStrategy, StripeHelper}
import com.exalate.services.api.IMessagesService
import com.google.inject.Inject
import org.slf4j.{Logger, LoggerFactory}

import java.sql.Timestamp
import java.text.SimpleDateFormat
import java.time.temporal.ChronoUnit
import java.util.{Calendar, Date}
import scala.concurrent.{ExecutionContext, Future}

/** This is the old implementation of the LicenseService. It is deprecated and should not be used.
  * The new implementation is in the LicenseServiceMicroserviceStrategy class.
  *
  * This class was merged with LicenseReplicationService. That is also deprecated and reworked in
  * LicenseServiceMicroserviceStrategy.
  */
@deprecated
class LicenseServiceMonolithStrategy @Inject() (
    licenseRepository: ILicenseRepository,
    relationRepository: IRelationRepository,
    twinTraceRepository: ITwinTraceRepository,
    licenseEncoderService: ILicenseEncoderService,
    mailService: IMailService,
    stripeServiceStrategy: IStripeServiceStrategy,
    licenseValidationService: ILicenseValidationService,
    lifecycleInfoService: ILifecycleInfoService,
    configurationService: IConfigurationService,
    stripeHelper: StripeHelper,
    val generalSettingsService: IGeneralSettingsService,
    nodeLicenseService: ITrackerLicenseService,
    messages: IMessagesService
)(implicit ec: ExecutionContext)
    extends ILicenseService {

  private val WARN_PERIOD = 0.8 // 80% of pairs used

  private val DEFAULT_PAIR_NUMBER =
    configurationService.getOptionalLong("exalate.license.limit").map(_.toLong).getOrElse(1000L)

  private val DEFAULT_CALENDAR_UNIT = configurationService
    .getOptionalString("exalate.license.calendar.unit")
    .getOrElse(ChronoUnit.MONTHS.name)

  val LOG: Logger = LoggerFactory.getLogger(classOf[LicenseServiceMonolithStrategy])

  private lazy val EXALATE_SUBSCRIPTION_NOT_PAYING_INSTANCE = messages
    .translate("com.exalate.subscription.exalate.notPayingInstance", Nil)
    .getOrElse("Only our side has an Exalate subscription. Please notify our administrator. ")

  private lazy val EXALATE_SUBSCRIPTION_INVALID = messages
    .translate("com.exalate.subscription.exalate.invalid", Nil)
    .getOrElse("Our Exalate subscription is not valid. Please notify our administrator. ")

  private lazy val VOLUME_BASED_NOT_UNDER_CONTROL = messages
    .translate("com.exalate.subscription.exalate.volume.notUnderControl", Nil)
    .getOrElse("We reached out the limit of pair events. Please notify our administrator. ")

  private lazy val SYNC_IS_NOT_AVAILABLE_FOR_LICENSE = messages
    .translate("com.exalate.subscription.exalate.sync.notAvailable.1", Nil)
    .getOrElse(
      "The destination instance license doesn't support Visual and Script connections. To resolve the error you can use one of the following options:</br>- Create a Basic connection.</br>- Contact the destination instance administrator so you can agree on who will have a valid license for this connection.</br>"
    )

  private lazy val SYNC_IS_NOT_AVAILABLE_FOR_LICENSE_AND_REMOTE_NOT_SUPPORT_BASIC = messages
    .translate("com.exalate.subscription.exalate.sync.notAvailable.2", Nil)
    .getOrElse(
      "The destination instance license doesn't support Visual and Script connections. To resolve the error you can use one of the following options:</br>- Upgrade your Exalate to the version that supports Basic connections and create a Basic connection.</br>- Contact the destination instance administrator so you can agree on who will have a valid license for this connection.</br>"
    )

  private lazy val TRACKER_SUBSCRIPTION_INVALID = messages
    .translate("com.exalate.tracker.license.found", Nil)
    .getOrElse(
      "The destination instance doesn't have a valid license. To resolve this, try one of the following options:</br>- Ask the destination instance admin to switch to a Freemium license. Check out our <a href='https://docs.exalate.com/docs/free-plan-license-errors'>documentation</a> for more details.</br>- Add the destination instance to your Network license.</br>- Ask the destination instance admin to buy an instance license."
    )

  private def EXALATE_SUBSCRIPTION_NOT_UNDER_CONTROL(
      countConnectionBasedAssigned: Int,
      connections: Long
  ) =
    messages
      .translate(
        "com.exalate.subscription.exalate.notUnderControl",
        Seq(countConnectionBasedAssigned.toString, connections.toString)
      )
      .getOrElse(
        s"We have too many connections ($countConnectionBasedAssigned) under payment model `We Pay`, while our subscription allows only ($connections) connections. Please notify our administrator. "
      )

  override def validatePayed(
      basicSyncRequest: BasicSyncRequest,
      connection: IConnection
  ): Future[ErrorMessages] =
    if (basicSyncRequest.isPayed) Future.successful(Nil)
    else {
      // Checking Network license
      LOG.debug(s"#validatePayed for basicSyncRequest ${basicSyncRequest.id}")
      val remoteExacompVersion =
        SemanticVersionService.get(connection.getRemoteInstance.getNodeInfo.getExaCompVersion)
      val supportsBasicConnection =
        remoteExacompVersion.getMajor >= 5L && remoteExacompVersion.getMinor >= 1L

      for {
        _ <- renewSubscriptionIfNecessaryFuture()
        isUpdateRequest = BasicSyncRequest.isUpdateRequest(basicSyncRequest)
        eventAndConnectionParameters = EventAndConnectionParameters(
          isUpdateRequest,
          connection.isBasic,
          supportsBasicConnection
        )
        isLocalLicenseValid <- validateLocalLicenseValid(eventAndConnectionParameters)
        isRemoteLicenseValid =
          basicSyncRequest.subscriptionContext.isRemoteWithNodeSubscription || basicSyncRequest.subscriptionContext.isRemoteWithExalateSubscription
        isSyncPayedByLocalInstance <- isSyncPayedByLocalLicenseFuture(connection)
      } yield
        if (
          isLocalLicenseValid.isEmpty && (isRemoteLicenseValid || isSyncPayedByLocalInstance.isEmpty)
        )
          Nil
        else if (isLocalLicenseValid.nonEmpty)
          isLocalLicenseValid
        else
          isSyncPayedByLocalInstance
    }

  private def isSyncPayedByLocalLicenseFuture(connection: IConnection): Future[ErrorMessages] =
    isInstanceForConnectionPayed(connection)
      .flatMap { isPayed =>
        getExalateLicenseFuture.flatMap(licenseOpt =>
          licenseOpt match {
            case Some(license: License) =>
              if (isPayed) {
                for {
                  isConnectionBasedUnderControl <- isConnectionBasedUnderControl
                  isVolumeBasedUnderControl <- isVolumeBasedUnderControl(license)
                  result <-
                    if (isConnectionBasedUnderControl && isVolumeBasedUnderControl)
                      Future.successful(Nil)
                    else
                      countConnectionBasedAssigned.map(size =>
                        Seq(EXALATE_SUBSCRIPTION_NOT_UNDER_CONTROL(size, license.getConnections))
                      )
                } yield result
              } else Future.successful(Seq(EXALATE_SUBSCRIPTION_NOT_PAYING_INSTANCE))
            case _                      =>
              Future.successful(Seq(EXALATE_SUBSCRIPTION_NOT_PAYING_INSTANCE))
          }
        )
      }

  override def isSyncPayed(syncEvent: ISyncEvent): Future[Boolean] =
    for {
      twinTraceOpt <- twinTraceRepository.getTwinTraceById(syncEvent.getTwinTraceId)

      isLocalConnection = syncEvent.getConnection.isLocal
      isUpdateEvent = BasicSyncEvent.isUpdateEvent(syncEvent, twinTraceOpt)
      isBasicConnection = syncEvent.getConnection.isBasic
      eventAndConnectionParameters =
        EventAndConnectionParameters(isUpdateEvent, isBasicConnection, true)

      result <-
        if (BasicSyncEvent.isCleanupOrUnexalateOrDeleteEvent(syncEvent)) Future.successful(true)
        else if (!isLocalConnection) {
          (
            validateLocalLicenseValid(eventAndConnectionParameters).map(_.isEmpty),
            isInstanceForConnectionPayed(syncEvent.getConnection)
          ).mapN((localLicenseValid, isPayed) => localLicenseValid && isPayed)
        } else {
          validateLocalLicenseValid(eventAndConnectionParameters).map(_.isEmpty)
        }
    } yield result

  // A - B different license situations
  // Goal is to report what kind of licensing problem there is and suggest
  // Limitation -> from the sending side, we only know if the sync is payed or not, but we don't know if there is a exalate license and state
  // Event side don't pay
  // Event side don't have node(atlassian)/expired license
  // Request side: No Exalate Licenses without atlassian license
  // Request side: Expired Exalate License
  // Request side: Valid License but not paying for instance
  // Request side: No Exalate License but atlassian license
  // Event side have node license
  // Request side: No Exalate Licenses and no atlassian license -> Remote side has the node subscription and our side does not.
  // Request side: No Exalate Licenses and expired atlassian license
  // Request side: Expired Exalate License and no atlassian license ->
  // Request side: Valid License but not paying for instance

  /** Is under valid Exalate subscription if: * Valid network license * Valid instance license *
    * Valid evaluation license and is update event * Valid evaluation license, is pair/connect event
    * and volume is under control * If current license has expired (Freemium): * * Connection is
    * Basic and is update event * * Connection is Basic, is pair/connect event and volume is under
    * control * Has no license: * * Connection is Basic and is update event * * Connection is Basic,
    * is pair/connect event and volume is under control
    * @param isPairOrConnectEvent
    * @param isBasicConnection
    * @return
    */
  def isUnderValidExalateSubscriptionFuture(
      isPairOrConnectEvent: Boolean,
      isBasicConnection: Boolean
  ): Future[Boolean] =
    getExalateLicenseFuture flatMap { licenseOpt =>
      licenseOpt match {
        case Some(license) =>
          for {
            isVolumeBasedUnderControl <- isVolumeBasedUnderControl(license)
            isExpired <- isExpired(license)
          } yield ((!isExpired && isValid(
            license
          )) || isBasicConnection) && (!isPairOrConnectEvent || (isPairOrConnectEvent && isVolumeBasedUnderControl))

        case _ =>
          isVolumeBasedUnderControl.map { isVolumeUnderControl =>
            isBasicConnection && (!isPairOrConnectEvent || (isPairOrConnectEvent && isVolumeUnderControl))
          }
      }
    }

  private def isUnderValidTrackerSubscriptionFuture(
      isPairOrConnectEvent: Boolean
  ): Future[TrackerSubscriptionValidation] =
    nodeLicenseService.getTrackerProvidedLicense.flatMap {
      _.traverse(license => isUnderValidTrackerSubscription(license, isPairOrConnectEvent))
        .map(result => TrackerSubscriptionValidation(result.getOrElse(false)))
    }

  private def isUnderValidTrackerSubscription(
      license: LicenseValue,
      isPairOrConnectEvent: Boolean
  ): Future[Boolean] =
    isTrackerVolumeBasedUnderControl(license).map { isTrackerVolumeBasedUnderControl =>
      if (license.isEvaluation)
        license.isActive && (!isPairOrConnectEvent || (isPairOrConnectEvent && isTrackerVolumeBasedUnderControl))
      else license.isActive
    }

  /** Method is used to validate local license. ** If subscriptionId empty - we check if license
    * isExpired, isValid If it's expired - we treat it as Freemium license and check if volume is
    * under control ** If not expired and valid - we check volumeBase for pair events
    *
    * @param eventAndConnectionParameters
    *   \- case class which has multiple parameters that will help validate local license
    * @return
    *   Future[ErrorMessages] or Future(Nil)
    */
  private def validateLocalLicenseValid(
      eventAndConnectionParameters: EventAndConnectionParameters
  ): Future[ErrorMessages] = {
    val isUpdateEventRequest = eventAndConnectionParameters.isUpdateEventRequest
    val isBasicConnection = eventAndConnectionParameters.isBasicConnection
    val supportsBasicConnection = eventAndConnectionParameters.supportsBasicConnection
    for {
      licenseOpt <- getExalateLicenseFuture
      shouldNotEnforceFreemium <- shouldNotEnforceFreemium(!isUpdateEventRequest)
      isUnderValidTrackerLicense <- isUnderValidTrackerSubscriptionFuture(
        !isUpdateEventRequest
      ) // isUnderValidTrackerSubscriptionFuture accepts isPairOrConnectEvent, but in this case we may rely on !isUpdateEventRequest, cleanup/delete/unexalate were checked before
      isVolumeBasedUnderControl <-
        if (licenseOpt.isDefined) isVolumeBasedUnderControl(licenseOpt.get)
        else isVolumeBasedUnderControl
      isExpired <- licenseOpt.traverse(isExpired).map(_.getOrElse(false))
      _ = LOG.debug(
        s"shouldNotEnforceFreemium = $shouldNotEnforceFreemium, isUnderValidTrackerLicense= ${isUnderValidTrackerLicense.isValid}, isVolumeBasedUnderControl= $isVolumeBasedUnderControl, isExpired= $isExpired"
      )
      errorMessages = getErrorMessages(
        isUpdateEventRequest,
        isBasicConnection,
        supportsBasicConnection,
        licenseOpt,
        shouldNotEnforceFreemium,
        isUnderValidTrackerLicense.isValid,
        isVolumeBasedUnderControl,
        isExpired
      )
    } yield errorMessages
  }

  private def getErrorMessages(
      isUpdateEventRequest: Boolean,
      isBasicConnection: Boolean,
      supportsBasicConnection: Boolean,
      licenseOpt: Option[ILicense],
      shouldNotEnforceFreemium: Boolean,
      isUnderValidTrackerLicense: Boolean,
      isVolumeBasedUnderControl: Boolean,
      isExpired: Boolean
  ): Seq[String] =
    if (isUnderValidTrackerLicense)
      Nil
    else
      licenseOpt match {
        case Some(license) =>
          if (isExpired && shouldNotEnforceFreemium)
            Seq(TRACKER_SUBSCRIPTION_INVALID)
          else if (!isValid(license))
            Seq(EXALATE_SUBSCRIPTION_INVALID)
          else if (!isUpdateEventRequest && !isVolumeBasedUnderControl) {
            LOG.debug("!isUpdateEventRequest && !isVolumeBasedUnderControl")
            Seq(VOLUME_BASED_NOT_UNDER_CONTROL)
          } else if (isExpired && !isBasicConnection) {
            if (supportsBasicConnection) Seq(SYNC_IS_NOT_AVAILABLE_FOR_LICENSE)
            else Seq(SYNC_IS_NOT_AVAILABLE_FOR_LICENSE_AND_REMOTE_NOT_SUPPORT_BASIC)
          } else Nil
        case None          =>
          if (shouldNotEnforceFreemium)
            Seq(TRACKER_SUBSCRIPTION_INVALID)
          else if (
            !isUnderValidTrackerLicense && !isUpdateEventRequest && !isVolumeBasedUnderControl
          ) {
            LOG.debug(
              "!isUnderValidTrackerLicense && !isUpdateEventRequest && !isVolumeBasedUnderControl"
            )
            Seq(VOLUME_BASED_NOT_UNDER_CONTROL)
          } else if (!isBasicConnection) {
            if (supportsBasicConnection) Seq(SYNC_IS_NOT_AVAILABLE_FOR_LICENSE)
            else Seq(SYNC_IS_NOT_AVAILABLE_FOR_LICENSE_AND_REMOTE_NOT_SUPPORT_BASIC)
          } else Nil
      }

  private def shouldNotEnforceFreemium(isPairOrConnectEvent: Boolean): Future[Boolean] =
    for {
      license <- nodeLicenseService.getTrackerProvidedLicense
      isValidOpt <- license.traverse(isUnderValidTrackerSubscription(_, isPairOrConnectEvent))
      isValid = isValidOpt.getOrElse(false)
    } yield isValid

  override def validateSubscription(event: ISyncEvent): Future[SubscriptionValidationResult] =
    for {
      twinTraceOpt <- twinTraceRepository.getTwinTraceById(event.getTwinTraceId)
      isPairOrConnectEvent = BasicSyncEvent.isPairOrConnectEvent(event, twinTraceOpt)
      isBasicConnection = event.getConnection.isBasic
      exalateResult <- isUnderValidExalateSubscriptionFuture(
        isPairOrConnectEvent,
        isBasicConnection
      )
      exalateSubscription = ExalateSubscriptionValidation(exalateResult)
      trackerSubscription <- isUnderValidTrackerSubscriptionFuture(isPairOrConnectEvent)
    } yield SubscriptionValidationResult(exalateSubscription, Option(trackerSubscription))

  /** Checks if connection is valid based on current license. This is used to validate if connection
    * should be created/upgraded or not *If instance has paid/evaluation license then connection is
    * valid *If instance current license has expired, hence has Freemium license, only Basic
    * connection is valid *If instance does not have a license, hence has Freemium license, only
    * Basic connection is valid
    * @param connectionMode
    *   can be BASIC, SCRIPT OR BOTH_SIDES (Visual)
    * @return
    */
  override def isConnectionValid(connectionMode: ConnectionMode): Future[Boolean] =
    for {
      exalateLicense <- getExalateLicenseFuture
      trackerLicense <- nodeLicenseService.getTrackerProvidedLicense
      isExpired <- exalateLicense.traverse(isExpired).map(_.getOrElse(false))
      validResult = (exalateLicense, trackerLicense) match {
        case (Some(exalateLicense), _) =>
          connectionMode == ConnectionMode.BASIC || (!isExpired && isValid(
            exalateLicense
          ))
        case (_, Some(trackerLicense)) =>
          connectionMode == ConnectionMode.BASIC || trackerLicense.isActive
        case (_, _)                    =>
          connectionMode == ConnectionMode.BASIC

      }
    } yield validResult

  def updateLicenseUsage(connectionName: String, payed: Boolean): Future[None.type] =
    relationRepository
      .getConnectionFuture(connectionName)
      .map(_.get)
      .flatMap(con => licenseRepository.setConnectionUsage(con, payed))

  override def updateLicenseUsages(usages: Seq[LicenseUsageValue]): Future[None.type] =
    Future
      .sequence(
        usages
          .flatMap(s => s.connections.map(c => (c.name, s.payed)))
          .map {
            case (connectionName, payed) =>
              updateLicenseUsage(connectionName, payed)
          }
      )
      .map(_ => None)

  override def updateLicenseUsages(remoteInstanceId: Int, payed: Boolean): Future[None.type] =
    licenseRepository.setConnectionUsage(remoteInstanceId, payed)

  def isConsideredExpired(license: ILicense): Boolean =
    "EASE-8221" == license.getOpportunity ||
      "$2a$12$i4ZmkVp8NO7jD.CXkSt7/ut.9XGywmmT4TztResD14HIKvlt33lfG" == license.getSignature

  /** Check the end date to know if it's expired Also we check if stripe status is active
    */
  private def isExpired(license: ILicense): Future[Boolean] =
    isStripeStatusActive(license.getStripeSubscriptionId).map { isStripeActive =>
      new Date().after(license.getEndDate) ||
      isConsideredExpired(license) ||
      !isStripeActive
    }

  /** if it's stripe subscription - check status. If it's not stripe subscription - forall returns
    * true
    */
  def isStripeStatusActive(subscriptionId: String): Future[Boolean] =
    Option(subscriptionId) match {
      case Some(id) =>
        stripeServiceStrategy.getSubscription(id).map(_.forall(sub => "active".equals(sub.status)))
      case None     => Future.successful(true)
    }

  /*
    Returns connections grouped by instance and a boolean indicating if the grouped connections are payed or not
   */
  override def getUsages: Future[Seq[(Seq[IConnection], Boolean)]] =
    relationRepository.findConnectionsFuture
      .map(ConnectionGroupUtils.getGroupedByInstance)
      .flatMap(group =>
        Future.sequence(group.map { c =>
          Future
            .sequence(c.map(c => licenseRepository.isConnectionPayed(c).map(ip => (c, ip))))
            .map(bucket => (bucket.map(_._1), bucket.exists(_._2)))
        })
      )

  private def getUsedPairs(license: ILicense): Future[Option[Long]] =
    if (
      license.getCalendarUnit != null && license.getStartDate != null && license.getPairNumber != null
    )
      LicenseServiceMonolithStrategyHelper.getUsedPairs(
        license.getCalendarUnit,
        license.getStartDate,
        license.getPairNumber,
        twinTraceRepository
      )
    else Future.successful(None)

  private def getExalateLicenseInfo(getLicensePayload: Boolean): Future[Option[LicenseValue]] =
    (getExalateLicenseFuture, countConnectionBasedAssigned)
      .flatMapN((licenseOpt, connectionsBasedAssigned) =>
        licenseOpt.traverse { license =>
          (isExpired(license), getUsedPairs(license), getStartOfNextPeriod(license)).mapN {
            (expired, usedPairEvents, volumeBasedRenewDate) =>
              val valid = isValid(license) && !expired
              LicenseValue(
                valid,
                isValid(license) && license.getIsEvaluation,
                isValid(license) && license.getIsFreemium,
                isTrackerLicense = false,
                Option(license.getStartDate),
                Option(license.getEndDate),
                expired,
                if (getLicensePayload) Option(this.getLicensePayload(license)) else None,
                Option(license.getConnections).map(_.toInt),
                Option(connectionsBasedAssigned),
                Option(license.getStripeSubscriptionId),
                if (license.getPairNumber == null) None else Option(license.getPairNumber),
                usedPairEvents,
                volumeBasedRenewDate,
                Option(license.getCalendarUnit).map(_.toString),
                Option(license.getOpportunity),
                None,
                None
              )
          }
        }
      )

  /** Calculates and returns Freemium license if * If Exalate does not have a tracker license * If
    * has an expired evaluation/paid license. Calculates Freemium from the existing license * If
    * does not have any Exalate license
    */
  private def getExalateFreemiumLicenseInfo(
      hasTrackerLicense: Boolean
  ): Future[Option[LicenseValue]] =
    if (hasTrackerLicense) Future.successful(None)
    else {
      val calendarUnit = ChronoUnit.valueOf(DEFAULT_CALENDAR_UNIT)
      (getExalateLicenseFuture, countConnectionBasedAssigned)
        .flatMapN((licenseOpt, connectionsBasedAssigned) =>
          licenseOpt match {
            case Some(existingLicense) =>
              val startDate = existingLicense.getEndDate
              for {
                volumeBasedRenewDate <- LicenseServiceMonolithStrategyHelper.getStartOfNextPeriod(
                  Calendar.getInstance(),
                  calendarUnit,
                  startDate
                )
                usedPairEvents <- LicenseServiceMonolithStrategyHelper.getUsedPairs(
                  calendarUnit,
                  startDate,
                  DEFAULT_PAIR_NUMBER,
                  twinTraceRepository
                )
                licenseValue = LicenseValue(
                  isActive = false,
                  isEvaluation = false,
                  isFreemium = true,
                  isTrackerLicense = false,
                  Option(startDate),
                  None,
                  isExpired = false,
                  None,
                  None,
                  Option(connectionsBasedAssigned),
                  None,
                  Option(DEFAULT_PAIR_NUMBER),
                  usedPairEvents,
                  volumeBasedRenewDate,
                  Option(DEFAULT_CALENDAR_UNIT),
                  None,
                  None,
                  None
                )
              } yield Option(licenseValue)

            case _ =>
              val startDate = lifecycleInfoService.getRegistrationDate
              for {
                volumeBasedRenewDate <- LicenseServiceMonolithStrategyHelper.getStartOfNextPeriod(
                  Calendar.getInstance(),
                  calendarUnit,
                  startDate
                )
                usedPairEvents <- LicenseServiceMonolithStrategyHelper.getUsedPairs(
                  calendarUnit,
                  startDate,
                  DEFAULT_PAIR_NUMBER,
                  twinTraceRepository
                )
                licenseValue = LicenseValue(
                  isActive = true,
                  isEvaluation = false,
                  isFreemium = true,
                  isTrackerLicense = false,
                  Option(startDate),
                  None,
                  isExpired = false,
                  None,
                  None,
                  Option(connectionsBasedAssigned),
                  None,
                  Option(DEFAULT_PAIR_NUMBER),
                  usedPairEvents,
                  volumeBasedRenewDate,
                  Option(DEFAULT_CALENDAR_UNIT),
                  None,
                  None,
                  None
                )
              } yield Option(licenseValue)
          }
        )
    }

  override def isInstanceForConnectionPayed(connection: IConnection): Future[Boolean] =
    getUsages.map(
      _.find { usage =>
        usage._1.exists(ConnectionGroupUtils.areConnectionsForSameInstance(connection))
      }
        .exists(_._2)
    )

  override def isInstanceForConnectionPayed(connection: INonPersistentConnection): Future[Boolean] =
    getUsages.map(
      _.find { usage =>
        usage._1.exists(ConnectionGroupUtils.areConnectionsForSameInstance(connection))
      }
        .exists(_._2)
    )

  private def countConnectionBasedAssigned: Future[Int] =
    for {
      connections <- relationRepository.findConnectionsFuture
      groups = ConnectionGroupUtils.getGroupedByInstance(connections)
      payedConnections <- groups.toList.filterA(_.toList.existsM(licenseRepository.isConnectionPayed))
    } yield payedConnections.length

  override def getMaxPaidInstances: Future[Int] =
    getExalateLicenseFuture
      .map(
        _.map(_.getConnections.toInt).getOrElse(0)
      )

  private def getExalateLicenseFuture: Future[Option[ILicense]] =
    licenseRepository.getLicense().map(_.map(licenseEncoderService.decodeLicense))

  /** Returns Exalate license from db if it exists Returns Freemium in case we don't have any
    * license in DB. So the cases in which we enforce Freemium are: * Node neither has an Exalate
    * nor a Tracker license * Node has an expired Exalate license but not a tracker license (returns
    * expired license) In the case were node has a tracker license, we will not enforce Freemium
    * even if this license has expired
    */
  override def getLicenses(
      hasTrackerLicense: Boolean,
      getLicensePayload: Boolean
  ): Future[ExalateLicensesValue] =
    for {
      currentExalateLicenseOpt <- getExalateLicenseInfo(getLicensePayload)
      exalateLicenseOpt <- currentExalateLicenseOpt match {
        case l @ Some(license) if !license.isExpired => Future.successful(l)
        case _                                       =>
          getExalateFreemiumLicenseInfo(hasTrackerLicense)

      }
    } yield ExalateLicensesValue(exalateLicenseOpt, currentExalateLicenseOpt.filter(_.isExpired))

  private def getLicensePayload(license: ILicense): String =
    licenseEncoderService.encodeLicense(new NonPersistentLicense(license))

  private def isConnectionBasedUnderControl: Future[Boolean] =
    (getExalateLicenseFuture, countConnectionBasedAssigned)
      .mapN((licenseOpt, connectionsBasedAssigned) =>
        licenseOpt match {
          case Some(license) =>
            license.getConnections >= connectionsBasedAssigned
          case None          =>
            true
        }
      )

  private def isVolumeBasedUnderControl(license: ILicense): Future[Boolean] =
    for {
      pairNumber <- getPairNumber(license)
      startOfCurrentPeriodOpt <- getStartOfCurrentPeriod(license)
      isVolumeUnderControl <- startOfCurrentPeriodOpt.traverse(startOfCurrentPeriod =>
        isVolumeBasedUnderControl(pairNumber, startOfCurrentPeriod)
      )
    } yield pairNumber == -1 || isVolumeUnderControl.getOrElse(false)

  private def isVolumeBasedUnderControl(): Future[Boolean] = {
    val registrationDate = lifecycleInfoService.getRegistrationDate
    LicenseServiceMonolithStrategyHelper
      .getStartOfPeriodFrom(Calendar.getInstance(), ChronoUnit.MONTHS, registrationDate)
      .flatMap {
        case Some(startOfCurrentPeriod) =>
          isVolumeBasedUnderControl(DEFAULT_PAIR_NUMBER, startOfCurrentPeriod)
        case _                          => Future.successful(false)
      }
  }

  private def isVolumeBasedUnderControl(
      pairNumber: Long,
      startOfCurrentPeriod: Timestamp
  ): Future[Boolean] =
    twinTraceRepository.getTwinTraceCountSinceDate(startOfCurrentPeriod).map { count =>
      if (pairNumber != -1 && count.toDouble / pairNumber >= WARN_PERIOD)
        mailService.sendLicenseMail(startOfCurrentPeriod)
      count < pairNumber
    }

  private def getPairNumber(license: ILicense): Future[Long] =
    isExpired(license)
      .map { isE =>
        if (isE)
          DEFAULT_PAIR_NUMBER
        else
        // In scala Long can't be null so we return -1 if license.getPairNumber is null
        if (license.getPairNumber == null) -1L
        else license.getPairNumber
      }

  def isTrackerVolumeBasedUnderControl(license: LicenseValue): Future[Boolean] =
    LicenseServiceMonolithStrategyHelper
      .getStartOfPeriodFrom(
        Calendar.getInstance(),
        license.calendarUnit.map(r => ChronoUnit.valueOf(r)).getOrElse(ChronoUnit.MONTHS),
        license.startDate.getOrElse(DEFAULT_DATE)
      )
      .flatMap(
        _.existsM(startOfCurrentPeriod =>
          twinTraceRepository.getTwinTraceCountSinceDate(startOfCurrentPeriod).map { count =>
            if (license.numberOfPair.exists(n => n != -1 && count.toDouble / n >= WARN_PERIOD))
              mailService.sendLicenseMail(startOfCurrentPeriod)
            count < license.numberOfPair.getOrElse(-1L)
          }
        ).map(boolResult =>
          license.numberOfPair.isEmpty || license.numberOfPair.get == -1 || boolResult
        )
      )

  private def getStartOfCurrentPeriod(license: ILicense): Future[Option[Timestamp]] = {
    val calendarUnit =
      if (license.getCalendarUnit == null) ChronoUnit.valueOf(DEFAULT_CALENDAR_UNIT)
      else license.getCalendarUnit
    isExpired(license)
      .map { isE =>
        if (isE)
          license.getEndDate
        else
          license.getStartDate
      }
      .flatMap(date =>
        LicenseServiceMonolithStrategyHelper
          .getStartOfPeriodFrom(Calendar.getInstance(), calendarUnit, date)
      )
  }

  private def getStartOfNextPeriod(license: ILicense): Future[Option[Date]] =
    LicenseServiceMonolithStrategyHelper.getStartOfNextPeriod(
      Calendar.getInstance(),
      license.getCalendarUnit,
      license.getStartDate
    )

  /** Check Exalate license to get the limit
    *
    * @return
    *   Future[Option[limitNumber, used pairs] limitNumber is -1 if license is not volume-based
    */
  def getVolumeLimitAndUsedFuture: Future[Option[(Int, Int)]] =
    getExalateLicenseInfo(false)
      .flatMap {
        case Some(license) =>
          if (license.isExpired)
            getExalateFreemiumLicenseInfo(false)
          else Future.successful(Option(license))
        case _             => getExalateFreemiumLicenseInfo(false)
      }
      .map(
        _.map(exalateLicense => (exalateLicense.numberOfPair, exalateLicense.usedPairEvents))
          .map(pairNumbers =>
            (pairNumbers._1.map(_.toInt).getOrElse(-1), pairNumbers._2.map(_.toInt).getOrElse(0))
          )
      )

  override def deleteLicense(): Future[None.type] = licenseRepository.deleteLicense()

  override def save(payload: String): Future[Unit] =
    licenseRepository
      .getLicense()
      .flatMap(
        _.flatMap(l => Option(licenseEncoderService.decodeLicense(l).getConnections)) match {
          case Some(connections)
              if connections > licenseEncoderService.decodeLicense(payload).getConnections =>
            licenseRepository.cleanAllAssignedLicense
          case _ =>
            Future.successful(())
        }
      )
      .flatMap(_ => licenseRepository.saveLicense(payload))
      .map(_ => ())

  private def isValid(license: ILicense): Boolean = licenseValidationService.isValid(license)

  override def validatePayload(payload: String): Future[Boolean] =
    Future.successful(licenseValidationService.isValid(payload))

  /** Helps update license when a stripe subscription is renewed We only update license when the
    * stripe subscription has not expired and is active.
    *
    * @return
    */
  override def renewSubscriptionIfNecessaryFuture(): Future[None.type] =
    getExalateLicenseFuture.flatMap {
      case Some(license) =>
        val subscriptionId = Option(license.getStripeSubscriptionId)
        subscriptionId match {
          case Some(sid) =>
            stripeServiceStrategy.getSubscription(sid).map {
              case Some(sub) =>
                val isExpired = java.time.Instant
                  .now()
                  .isAfter(
                    java.time.Instant
                      .ofEpochSecond(stripeHelper.toStripeWithExtraDate(sub.current_period_end))
                  )
                if (!isExpired && "active".equals(sub.status)) {
                  save(stripeHelper.getPayload(sub))
                }
                None
            }
          case _         => Future.successful(None)
        }
      case _             => Future.successful(None)
    }

  case class EventAndConnectionParameters(
      isUpdateEventRequest: Boolean,
      isBasicConnection: Boolean,
      supportsBasicConnection: Boolean
  )

}

object LicenseServiceMonolithStrategyHelper {

  val stringDate = "01-01-2022"
  val simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy")

  val DEFAULT_DATE: Date =
    simpleDateFormat.parse(stringDate) // If REGISTRATION_DATE is null from LIFECYCLE_INFO table

  /** @return
    *   start of a next period of time, taking into account license's start date and calendarUnit.
    *   Ex. License start date is 12th April, today is 6 June, `getStartOfNextPeriod` should return
    *   12th June. If today 18 June - returns 12th July. License started 30 Jan 2020, today 12 Feb
    *   2020, method should return 29 Feb 2020
    */
  def getStartOfNextPeriod(
      currentCalendar: Calendar,
      calendarUnit: ChronoUnit,
      startDate: Date
  ): Future[Option[Date]] = {
    val date = calendarUnit match {
      case ChronoUnit.MONTHS =>
        val dayOfCurrentMonth = currentCalendar.get(Calendar.DAY_OF_MONTH)
        val currentMonth = currentCalendar.get(Calendar.MONTH)

        val licenseCalendar = Calendar.getInstance()
        licenseCalendar.setTime(Option(startDate).getOrElse(DEFAULT_DATE))
        val dayOfStartLicense = licenseCalendar.get(Calendar.DAY_OF_MONTH)

        val resultCalendar = Calendar.getInstance()
        resultCalendar.set(Calendar.HOUR_OF_DAY, 0)
        resultCalendar.set(
          Calendar.DAY_OF_MONTH,
          1
        ) // This fix the following situation: if today is 30 Jan, the when we do set `currentMonth + 1` it would be 30 Feb, that is not possible.

        if (dayOfCurrentMonth < dayOfStartLicense) {
          resultCalendar.set(Calendar.MONTH, currentMonth)
        } else {
          resultCalendar.set(Calendar.MONTH, currentMonth + 1) // setting month to next
        }

        val nextMonthMaxDays = resultCalendar.getActualMaximum(Calendar.DAY_OF_MONTH)
        if (dayOfStartLicense > nextMonthMaxDays)
          resultCalendar.set(Calendar.DAY_OF_MONTH, nextMonthMaxDays)
        else resultCalendar.set(Calendar.DAY_OF_MONTH, dayOfStartLicense)

        Option(resultCalendar.getTime)
      case _                 => None
    }
    Future.successful(date)
  }

  def getUsedPairs(
      calendarUnit: ChronoUnit,
      startDate: Date,
      pairNumber: Long,
      twinTraceRepository: ITwinTraceRepository
  )(implicit ec: ExecutionContext): Future[Option[Long]] =
    getStartOfPeriodFrom(Calendar.getInstance(), calendarUnit, startDate)
      .flatMap(_.traverse(start => twinTraceRepository.getTwinTraceCountSinceDate(start)))
      .map { usedPairEvents =>
        if (usedPairEvents.isDefined && usedPairEvents.get > pairNumber)
          Option(pairNumber)
        else
          usedPairEvents
      }

  /** @return
    *   start of a period of time, taking into account license's start date and calendarUnit. Used
    *   to validate from what period we should count twin traces. Ex. License start date is 12th
    *   April, today is 6 June, `getStartOfPeriodFrom` should return 12th May. If today 18 June -
    *   returns 12th June. License started 30 Jan 2020, today 12 Mar 2020, method should return 29
    *   Feb 2020
    */
  def getStartOfPeriodFrom(
      currentCalendar: Calendar,
      calendarUnit: ChronoUnit,
      startDate: Date
  ): Future[Option[Timestamp]] = {
    val timeStamp = calendarUnit match {
      case ChronoUnit.MONTHS =>
        val dayOfCurrentMonth = currentCalendar.get(Calendar.DAY_OF_MONTH)
        val currentMonth = currentCalendar.get(Calendar.MONTH)

        val licenseCalendar = Calendar.getInstance()
        licenseCalendar.setTime(Option(startDate).getOrElse(DEFAULT_DATE))
        val dayOfStartLicense = licenseCalendar.get(Calendar.DAY_OF_MONTH)

        val resultCalendar = Calendar.getInstance()
        resultCalendar.set(Calendar.HOUR_OF_DAY, 0)
        resultCalendar.set(
          Calendar.DAY_OF_MONTH,
          1
        ) // This fix the following situation: if today is 30 March, the when we do set `currentMonth - 1` it would be 30 Feb, that is not possible.

        if (dayOfCurrentMonth < dayOfStartLicense) {
          resultCalendar.set(Calendar.MONTH, currentMonth - 1)
          val previousMonthMaxDays = resultCalendar.getActualMaximum(Calendar.DAY_OF_MONTH)
          if (dayOfStartLicense > previousMonthMaxDays)
            resultCalendar.set(Calendar.DAY_OF_MONTH, previousMonthMaxDays)
          else resultCalendar.set(Calendar.DAY_OF_MONTH, dayOfStartLicense)
        } else {
          resultCalendar.set(Calendar.MONTH, currentMonth)
          resultCalendar.set(java.util.Calendar.DAY_OF_MONTH, dayOfStartLicense)
        }

        Option(new Timestamp(resultCalendar.getTime.getTime))
      case _                 => None
    }

    Future.successful(timeStamp)
  }

}
