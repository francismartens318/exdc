package com.exalate.replication.services.license

import cats.data._
import cats.implicits._
import com.exalate.api.domain.connection.fieldvalues.ConnectionMode
import com.exalate.api.domain.connection.{IConnection, INonPersistentConnection}
import com.exalate.api.domain.event.ISyncEvent
import com.exalate.api.exception.bug.NoGeneralSettingsBugException
import com.exalate.api.exception.license.LicenseException
import com.exalate.api.license.ILicenseValidationService
import com.exalate.api.persistence.instance.IInstanceRepository
import com.exalate.api.persistence.relation.IRelationRepository
import com.exalate.api.persistence.twintrace.ITwinTraceRepository
import com.exalate.clients.GrpcClient
import com.exalate.converters.licensing.GeneralProtoConvertersDefault.fromProto
import com.exalate.domain.RemoteInstanceUId
import com.exalate.domain.replication.{BasicSyncEvent, BasicSyncRequest}
import com.exalate.domain.values.license._
import com.exalate.proto.licensing._
import com.exalate.replication.services.api.config.IGeneralSettingsService
import com.exalate.replication.services.api.issuetracker.ITrackerLicenseService
import com.exalate.replication.services.api.license.ILicenseService
import com.exalate.replication.services.api.transport.smtp.IMailService
import com.exalate.replication.services.config.ConnectionGroupUtils
import com.exalate.replication.services.license.SubscriptionValidationResult.{
  ExalateSubscriptionValidation,
  TrackerSubscriptionValidation
}
import com.exalate.replication.services.license.stripe.{IStripeServiceStrategy, StripeHelper}
import com.exalate.replication.services.node.lifecycle.LifecycleInfoService
import com.exalate.result.{FutureResult, Result}
import com.exalate.result.FutureResult.FutureResultOpts
import com.exalate.domain.utils.DateConverter.localDateToLong
import com.exalate.services.utils.TwoTierCache
import play.api.{Configuration, Logger}

import java.sql.Timestamp
import java.text.SimpleDateFormat
import java.time.temporal.ChronoUnit
import java.time.{LocalDate, ZoneOffset}
import java.util.Date
import javax.inject.Inject
import scala.concurrent.duration.FiniteDuration
import scala.concurrent.{ExecutionContext, Future}
import scala.util.{Failure, Success, Try}

class LicenseServiceMicroserviceStrategy @Inject() (
    lifecycleInfoService: LifecycleInfoService,
    generalSettingsService: IGeneralSettingsService,
    configuration: Configuration,
    grpcClient: GrpcClient,
    relationRepository: IRelationRepository,
    instanceRepository: IInstanceRepository,
    twinTraceRepository: ITwinTraceRepository,
    mailService: IMailService,
    licenseValidationService: ILicenseValidationService,
    stripeClient: IStripeServiceStrategy,
    stripeHelper: StripeHelper,
    twoTierCache: TwoTierCache,
    nodeLicenseService: ITrackerLicenseService
)(implicit val ec: ExecutionContext)
    extends ILicenseService {

  private val licenseInfoCache = "licenseInfo"
  private val startOfPeriodCache = "startOfPeriod"
  private val LOG = Logger(classOf[LicenseServiceMicroserviceStrategy])

  private val WARN_PERIOD = 0.8 // 80% of pairs used

  private lazy val LICENSE_CACHE_EXPIRY_DURATION: FiniteDuration =
    configuration.get[FiniteDuration]("com.exalate.cache.expiry.licensing.duration")

  private type ValidationResult[T] = EitherT[Future, SubscriptionValidationError, T]

  override def validatePayed(
      basicSyncRequest: BasicSyncRequest,
      connection: IConnection
  ): Future[ErrorMessages] =
    if (basicSyncRequest.isPayed) {
      Future.successful(Nil)
    } else if (basicSyncRequest.subscriptionContext.hasRemoteValidSubscription) {
      val isUpdateRequest = BasicSyncRequest.isUpdateRequest(basicSyncRequest)
      validateSubscription(!isUpdateRequest, connection.isBasic).map(
        _.errorMessages.map(_.errorCode)
      )
    } else {
      isInstanceForConnectionPayed(connection).map {
        case true  => Nil
        case false => Seq(NotPayingInstance.errorCode)
      }
    }

  override def isSyncPayed(syncEvent: ISyncEvent): Future[Boolean] =
    if (BasicSyncEvent.isCleanupOrUnexalateOrDeleteEvent(syncEvent)) {
      Future.successful(true)
    } else if (syncEvent.getConnection.isLocal) {
      validateSubscription(syncEvent).map(_.hasValidSubscription)
    } else {
      Tuple2(
        validateSubscription(syncEvent).map(_.hasValidSubscription),
        isInstanceForConnectionPayed(syncEvent.getConnection)
      ).mapN((hasValidSubscription, isInstancePayed) => hasValidSubscription && isInstancePayed)
    }

  override def validateSubscription(event: ISyncEvent): Future[SubscriptionValidationResult] =
    for {
      _ <- renewSubscriptionIfNecessaryFuture()
      twinTraceOpt <- twinTraceRepository.getTwinTraceById(event.getTwinTraceId)
      isPairOrConnectEvent = BasicSyncEvent.isPairOrConnectEvent(event, twinTraceOpt)
      isBasicConnection = event.getConnection.isBasic
      result <- validateSubscription(isPairOrConnectEvent, isBasicConnection)
    } yield result

  private def validateSubscription(
      isPairOrConnectEvent: Boolean,
      isBasicConnection: Boolean
  ): Future[SubscriptionValidationResult] =
    Tuple2(
      validateExalateSubscriptionFuture(isPairOrConnectEvent, isBasicConnection),
      validateTrackerSubscription(isPairOrConnectEvent)
    ).mapN(SubscriptionValidationResult(_, _))

  // A - B different license situations
  // Goal is to report what kind of licensing problem there is and suggest
  // Limitation -> from the sending side, we only know if the sync is payed or not, but we don't know if there is a exalate license and state
  // Event side don't pay
  // Event side don't have node(atlassian)/expired license
  // Request side: No Exalate Licenses without atlassian license
  // Request side: Expired Exalate License
  // Request side: Valid License but not paying for instance
  // Request side: No Exalate License but atlassian license
  // Event side have node license
  // Request side: No Exalate Licenses and no atlassian license -> Remote side has the node subscription and our side does not.
  // Request side: No Exalate Licenses and expired atlassian license
  // Request side: Expired Exalate License and no atlassian license ->
  // Request side: Valid License but not paying for instance

  /** Is under valid Exalate subscription if: * Valid network license * Valid instance license *
    * Valid evaluation license and is update event * Valid evaluation license, is pair/connect event
    * and volume is under control * If current license has expired (Freemium): * * Connection is
    * Basic and is update event * * Connection is Basic, is pair/connect event and volume is under
    * control * Has no license: * * Connection is Basic and is update event * * Connection is Basic,
    * is pair/connect event and volume is under control
    * @param isPairOrConnectEvent
    * @param isBasicConnection
    * @return
    */
  private def validateExalateSubscriptionFuture(
      isPairOrConnectEvent: Boolean,
      isBasicConnection: Boolean
  ): Future[ExalateSubscriptionValidation] = {

    def validateVolumeBasedUnderControl(
        isPairOrConnectEvent: Boolean,
        volumeBased: VolumeBased
    ): ValidationResult[Unit] =
      EitherT(
        isVolumeBasedUnderControl(volumeBased)
          .map(isVolumeUnderControl =>
            Either.cond(
              !isPairOrConnectEvent || (isPairOrConnectEvent && isVolumeUnderControl),
              (),
              VolumeNotUnderControl
            )
          ): Future[Either[SubscriptionValidationError, Unit]]
      )

    def validateSyncIsAvailable(
        isBasicConnection: Boolean,
        freemiumLicenseInfo: FreemiumLicenseInfo
    ): ValidationResult[FreemiumLicenseInfo] =
      EitherT.cond[Future](
        isBasicConnection,
        freemiumLicenseInfo,
        SyncIsNotAvailable
      )

    (for {
      licenseInfo <- EitherT.liftF(getActiveLicenseInfo)
      _ <- licenseInfo match {
        case freemiumLicense: FreemiumLicenseInfo     =>
          for {
            validFreemium <- validateSyncIsAvailable(isBasicConnection, freemiumLicense)
            result <- validateVolumeBasedUnderControl(isPairOrConnectEvent, validFreemium)
          } yield result
        case evaluationLicense: EvaluationLicenseInfo =>
          validateVolumeBasedUnderControl(isPairOrConnectEvent, evaluationLicense)
        case _                                        =>
          EitherT.rightT[Future, SubscriptionValidationError](())
      }
    } yield ()).value.map {
      case Right(_)              =>
        ExalateSubscriptionValidation(isValid = true)
      case Left(validationError) =>
        ExalateSubscriptionValidation(isValid = false, Some(validationError))
    }
  }

  private def validateTrackerSubscription(
      isPairOrConnectEvent: Boolean
  ): Future[Option[TrackerSubscriptionValidation]] = {

    def validateActiveLicense(license: LicenseValue): ValidationResult[Unit] =
      EitherT.cond[Future](
        license.isActive,
        (),
        TrackerLicenseIsNotActive
      )

    def validateVolumeBasedUnderControl(license: LicenseValue): ValidationResult[Unit] =
      if (license.isEvaluation)
        EitherT(
          isTrackerVolumeBasedUnderControl(license)
            .map(isVolumeUnderControl =>
              Either.cond(
                license.isActive && (!isPairOrConnectEvent || (isPairOrConnectEvent && isVolumeUnderControl)),
                (),
                VolumeNotUnderControl
              )
            ): Future[Either[SubscriptionValidationError, Unit]]
        )
      else EitherT.rightT(())

    nodeLicenseService.getTrackerProvidedLicense.flatMap {
      case Some(license) =>
        (for {
          _ <- validateActiveLicense(license)
          _ <- validateVolumeBasedUnderControl(license)
        } yield ()).value.map {
          case Right(_)              =>
            Some(TrackerSubscriptionValidation(isValid = true))
          case Left(validationError) =>
            Some(TrackerSubscriptionValidation(isValid = false, Some(validationError)))
        }
      case None          => Future.successful(None)
    }
  }

  /** Checks if connection is valid based on current license. This is used to validate if connection
    * should be created/upgraded or not *If instance has paid/evaluation license then connection is
    * valid *If instance current license has expired, hence has Freemium license, only Basic
    * connection is valid *If instance does not have a license, hence has Freemium license, only
    * Basic connection is valid
    * @param connectionMode
    *   can be BASIC, SCRIPT OR BOTH_SIDES (Visual)
    * @return
    */
  override def isConnectionValid(connectionMode: ConnectionMode): Future[Boolean] =
    (getActiveLicenseInfo, nodeLicenseService.getTrackerProvidedLicense).mapN {
      case (exalateLicense, trackerLicenseOpt) =>
        trackerLicenseOpt match {
          case Some(trackerLicense) =>
            connectionMode == ConnectionMode.BASIC || trackerLicense.isActive
          case None                 =>
            exalateLicense match {
              case _: FreemiumLicenseInfo => connectionMode == ConnectionMode.BASIC
              case _                      => true
            }
        }
    }

  private def getRemoteInstanceUId(remoteInstanceId: Int): Future[Option[String]] =
    instanceRepository.getRemoteInstanceUId(remoteInstanceId)

  // TODO: we should rework it later in scope of AR-29
  // TODO: should we check if there is still a space to add new usage??
  override def updateLicenseUsages(usages: Seq[LicenseUsageValue]): Future[None.type] =
    Future
      .sequence(
        usages
          .flatMap(licenseUsageValue =>
            licenseUsageValue.connections.map(c =>
              c.id
                .map { connectionId =>
                  val remoteInstanceUid: Future[Option[String]] =
                    relationRepository.getRemoteInstanceUId(connectionId)
                  remoteInstanceUid.flatMap(_ match {
                    case Some(remoteInstanceUid) =>
                      updateLicenseUsageForRemoteInstanceUid(
                        remoteInstanceUid,
                        licenseUsageValue.payed
                      )
                  })
                }
                .getOrElse(Future.successful())
            )
          )
      )
      .map(_ => None)

  override def updateLicenseUsages(remoteInstanceId: Int, payed: Boolean): Future[None.type] =
    (for {
      remoteInstanceUid <- OptionT(getRemoteInstanceUId(remoteInstanceId))
      _ <- OptionT.liftF(updateLicenseUsageForRemoteInstanceUid(remoteInstanceUid, payed))
    } yield ()).value.map(_ => None)

  private def updateLicenseUsageForRemoteInstanceUid(
      remoteInstanceUId: String,
      payed: Boolean
  ): Future[Unit] =
    for {
      _ <- grpcClient.licenseService.setPaidConnection(
        SetPaidConnectionRequest(
          remoteInstanceUId = remoteInstanceUId,
          isPayed = payed
        )
      )
      _ <- clearCache()
    } yield ()

  private def getUsages(licenseInfo: NetworkLicenseInfo): Future[Seq[(Seq[IConnection], Boolean)]] =
    for {
      connections <- relationRepository.findConnectionsFuture
      groups = ConnectionGroupUtils.getGroupedByInstance(connections)
      usages <- groups.toList.traverse { group =>
        for {
          isPayed <- group.toList.existsM { connection =>
            getRemoteInstanceUId(connection.getRemoteInstance.getID)
              .map {
                case Some(id) => checkPaidInstance(licenseInfo, RemoteInstanceUId(id))
                case None     => false
              }
          }
        } yield (group, isPayed)
      }
    } yield usages

  override def getUsages: Future[Seq[(Seq[IConnection], Boolean)]] =
    for {
      licenseInfo <- getActiveLicenseInfo
      usages <- licenseInfo match {
        case network: NetworkLicenseInfo => getUsages(network)
        case _                           => Future.successful(Nil)
      }
    } yield usages

  private def checkPaidInstance(
      licenseInfo: LicenseInfo,
      remoteInstanceUId: RemoteInstanceUId
  ): Boolean =
    licenseInfo match {
      case network: NetworkLicenseInfo => network.paidInstances.contains(remoteInstanceUId)
      case _                           => false
    }

  override def isInstanceForConnectionPayed(connection: IConnection): Future[Boolean] =
    Option(connection.getRemoteInstance.getID) match {
      case Some(remoteInstanceId) =>
        for {
          licenseInfo <- getActiveLicenseInfo
          isConnectionPayed <- licenseInfo match {
            case network: NetworkLicenseInfo if !connection.isLocal =>
              getRemoteInstanceUId(remoteInstanceId)
                .map(
                  _.exists(id => network.paidInstances.contains(RemoteInstanceUId(id)))
                )
            case _                                                  =>
              Future.successful(false)
          }
        } yield isConnectionPayed
      case None                   => Future.successful(false)
    }

  override def isInstanceForConnectionPayed(connection: INonPersistentConnection): Future[Boolean] =
    if (connection.isLocal) {
      Future.successful(false)
    } else {
      Option(connection.getRemoteInstance.getNodeInfo) match {
        case Some(nodeInfo) =>
          for {
            licenseInfo <- getActiveLicenseInfo
            remoteInstanceUId = RemoteInstanceUId(nodeInfo.getInstanceUid)
          } yield checkPaidInstance(licenseInfo, remoteInstanceUId)
        case None           => Future.successful(false)
      }
    }

  override def getMaxPaidInstances: Future[Int] =
    for {
      licenseInfo <- getActiveLicenseInfo
      count = licenseInfo match {
        case network: NetworkLicenseInfo => network.maxPaidInstances.toInt
        case _                           => 0
      }
    } yield count

  override def getLicenses(
      hasTrackerLicense: Boolean,
      getLicensePayload: Boolean
  ): Future[ExalateLicensesValue] =
    for {
      allLicenseInfo <- getAllLicenseInfo
      activeLicenseValue = Option(LicenseValue.convert(allLicenseInfo.activeLicense))
      activeLicenseFull <- allLicenseInfo.activeLicense match {
        case volumeBased: VolumeBased =>
          getVolumeLimitAndUsed(volumeBased).map(_.flatMap {
            case (_, used) =>
              activeLicenseValue.map(_.copy(usedPairEvents = Option(used)))
          })
        case _                        => Future.successful(activeLicenseValue)
      }
      expiredLicense = allLicenseInfo.expiredLicense.map(LicenseValue.convert)
    } yield ExalateLicensesValue(activeLicenseFull, expiredLicense)

  private def isVolumeBasedUnderControl(
      volumeBased: VolumeBased
  ): Future[Boolean] = {
    val previousVolumeRenewalTimestamp = new Timestamp(
      localDateToLong(volumeBased.previousVolumeRenewalDate)
    )
    twinTraceRepository.getTwinTraceCountSinceDate(previousVolumeRenewalTimestamp).map { count =>
      if (
        volumeBased.volumeLimit != -1 && count.toDouble / volumeBased.volumeLimit >= WARN_PERIOD
      ) {
        LOG.warn(
          s"Pair number ${volumeBased.volumeLimit} is exceeded by $count. " +
            s"Start of current period is $previousVolumeRenewalTimestamp"
        )
        mailService.sendLicenseMail(previousVolumeRenewalTimestamp)
      }
      count < volumeBased.volumeLimit
    }
  }

  override def isTrackerVolumeBasedUnderControl(license: LicenseValue): Future[Boolean] = {
    val simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy")
    val stringDate = "01-01-2022"
    val defaultDate = simpleDateFormat.parse(stringDate)

    getStartOfPeriodFrom(
      license.calendarUnit.map(r => ChronoUnit.valueOf(r)).getOrElse(ChronoUnit.MONTHS),
      license.startDate.getOrElse(defaultDate)
    ).flatMap(
      _.existsM(startOfCurrentPeriod =>
        twinTraceRepository.getTwinTraceCountSinceDate(startOfCurrentPeriod).map { count =>
          if (license.numberOfPair.exists(n => n != -1 && count.toDouble / n >= WARN_PERIOD))
            mailService.sendLicenseMail(startOfCurrentPeriod)
          count < license.numberOfPair.getOrElse(-1L)
        }
      ).map(boolResult =>
        license.numberOfPair.isEmpty || license.numberOfPair.get == -1 || boolResult
      )
    )
  }

  override def getVolumeLimitAndUsedFuture: Future[Option[(Int, Int)]] =
    for {
      licenseInfo <- getActiveLicenseInfo
      volumeLimitAndUsed <- licenseInfo match {
        case volumeBased: VolumeBased =>
          getVolumeLimitAndUsed(volumeBased)
        case _                        => Future.successful(None)
      }
    } yield volumeLimitAndUsed

  private def getVolumeLimitAndUsed(volumeBased: VolumeBased): Future[Option[(Int, Int)]] = {
    val previousVolumeRenewalTimestamp = new Timestamp(
      localDateToLong(volumeBased.previousVolumeRenewalDate)
    )
    twinTraceRepository
      .getTwinTraceCountSinceDate(previousVolumeRenewalTimestamp)
      .map { count =>
        val volumeLimit = volumeBased.volumeLimit.toInt
        Option((volumeLimit, volumeLimit.min(count.toInt)))
      }
  }

  override def deleteLicense(): Future[None.type] =
    for {
      _ <- grpcClient.licenseService.delete(EmptyRequest())
      _ <- clearCache()
    } yield None

  override def save(payload: String): Future[Unit] =
    for {
      gs <- generalSettingsService.get
      trackerUrl = gs
        .map(_.getIssueTrackerUrl)
        .getOrElse(throw new NoGeneralSettingsBugException("Tracker url is not set"))
      _ <- grpcClient.licenseService
        .save()
        .invoke(SaveLicenseRequest(None, payload, trackerUrl))
      _ <- clearCache()
    } yield ()

  override def validatePayload(payload: String): Future[Boolean] =
    Future.successful(licenseValidationService.isValid(payload))

  // TODO remove after migration from stripe to chargebee
  override def renewSubscriptionIfNecessaryFuture(): Future[None.type] =
    for {
      licenseInfo <- getActiveLicenseInfo
      _ <- licenseInfo match {
        case stripeLicense: StripeLicenseInfo =>
          stripeClient.getSubscription(stripeLicense.subscriptionId).map {
            case Some(sub) =>
              val isExpired = java.time.Instant
                .now()
                .isAfter(
                  java.time.Instant
                    .ofEpochSecond(stripeHelper.toStripeWithExtraDate(sub.current_period_end))
                )
              if (!isExpired && "active".equals(sub.status)) {
                save(stripeHelper.getPayload(sub))
              }
              None
            case _         => None
          }
        case _                                => Future.successful(None)
      }
    } yield None

  /** @return
    *   start of a period of time, taking into account license's start date and calendarUnit. Used
    *   to validate from what period we should count twin traces. Ex. License start date is 12th
    *   April, today is 6 June, `getStartOfPeriodFrom` should return 12th May. If today 18 June -
    *   returns 12th June. License started 30 Jan 2020, today 12 Mar 2020, method should return 29
    *   Feb 2020
    */
  private def getStartOfPeriodFrom(
      calendarUnit: ChronoUnit,
      startDate: Date
  ): Future[Option[Timestamp]] = {
    val nowInMillis = LocalDate.now().atStartOfDay(ZoneOffset.UTC).toEpochSecond * 1000
    LOG.debug(
      s"Invoking #getPreviousRenewalDate with startDate: ${startDate.getTime}, now= $nowInMillis"
    )
    twoTierCache
      .getOrUpdate[Timestamp](
        startOfPeriodCache,
        LICENSE_CACHE_EXPIRY_DURATION,
        LICENSE_CACHE_EXPIRY_DURATION
      ) {
        (for {
          result <- grpcClient.licenseService.getPreviousRenewalDate(
            RenewalDateRequest(
              startDate.getTime,
              nowInMillis,
              calendarUnit.name()
            )
          )
          date = result.date.map(new Timestamp(_))
        } yield date).attempt
      }
      .toFuture
  }

  def getActiveLicenseInfo: Future[LicenseInfo] =
    getAllLicenseInfo.map(_.activeLicense)

  private def getAllLicenseInfo: Future[AllLicenseInfo] =
    for {
      licenseInfoOpt <- twoTierCache
        .getOrUpdate[AllLicenseInfo](
          licenseInfoCache,
          LICENSE_CACHE_EXPIRY_DURATION,
          LICENSE_CACHE_EXPIRY_DURATION
        )(
          getAllLicenseInfoFromSource,
          licenseInfo => shouldRemoveLicenseCache(licenseInfo.activeLicense)
        )
        .toFuture
      licenseInfo = licenseInfoOpt.getOrElse(throw new Exception("License info is not available"))
    } yield licenseInfo

  private def getAllLicenseInfoFromSource: FutureResult[Option[AllLicenseInfo]] = {
    LOG.debug("Fetching license info from Licensing Service")
    Try {
      grpcClient.licenseService
        .getAllLicenseInfo(
          GetLicenseInfoRequest(
            registrationDate = lifecycleInfoService.getRegistrationDate.getTime
          )
        )
        .map(licenseInfoResponse => fromProto.toLicenseInfo(licenseInfoResponse).map(Option(_)))
        .recover(ex =>
          Result.failure(new LicenseException(s"LS service could be down!, ex ${ex.getMessage}"))
        )
    } match {
      case Success(value)     => value
      case Failure(exception) => Future.successful(Result.failure(exception))
    }
  }

  private def clearCache(): Future[Unit] =
    for {
      _ <- twoTierCache.removeFull(licenseInfoCache)
      _ <- twoTierCache.removeFull(startOfPeriodCache)
    } yield ()

  /** Check if license is expired and should be removed from cache. Example: today is the last day
    * of the license, it should get expired tomorrow. As cache is updated every
    * ${{LICENSE_CACHE_EXPIRY_DURATION}}, if it gets cached today evening, user will be using cache
    * tomorrow as well. But the license is expired, so it should be removed from cache.
    * @param licenseInfo
    * @return
    */
  private def shouldRemoveLicenseCache(licenseInfo: LicenseInfo): Boolean =
    licenseInfo match {
      case temporalLicense: TemporalLicense =>
        val endDate = temporalLicense.endDate.value
        val today = LocalDate.now()
        endDate.isBefore(today)
      case _                                =>
        false
    }

}
