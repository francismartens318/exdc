package com.exalate.replication.services.license

import cats.data.OptionT
import cats.implicits._
import com.exalate.api.IConfigurationService
import com.exalate.api.exception.bug.NoGeneralSettingsBugException
import com.exalate.replication.services.api.node.lifecycle.ILifecycleInfoService
import com.exalate.services.MicroserviceAuthService

import scala.concurrent.{ExecutionContext, Future}

trait MicroserviceAuth {
  def lifecycleInfoService: ILifecycleInfoService
  @deprecated def configurationService: IConfigurationService
  implicit def ec: ExecutionContext

  protected val authSecret: Option[String] =
    configurationService.getOptionalString("exalate.license.auth.secret")

  protected def getToken(instanceUIdOpt: Option[String] = None): Future[String] = {
    val instanceUId: Future[String] = OptionT
      .fromOption[Future](instanceUIdOpt)
      .orElse(OptionT(lifecycleInfoService.getInstanceUid))
      .getOrElseF(Future.failed(throw new NoGeneralSettingsBugException(s"InstanceUId is not set")))

    instanceUId.map(MicroserviceAuthService.generateMicroserviceToken(_, authSecret))
  }

}
