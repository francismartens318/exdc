package com.exalate.replication.services.license.chargebee

import com.exalate.api.IConfigurationService
import com.exalate.clients.GrpcClient
import com.exalate.domain.values.license.ChargeBeeSubscription
import com.exalate.proto.licensing.EmptyRequest
import com.exalate.replication.services.api.config.IGeneralSettingsService
import com.exalate.replication.services.license.MicroserviceAuth
import com.exalate.replication.services.node.lifecycle.LifecycleInfoService
import play.api.Logger

import javax.inject.Inject
import scala.concurrent.{ExecutionContext, Future}

class ChargeBeeServiceMicroserviceStrategy @Inject() (
    val lifecycleInfoService: LifecycleInfoService,
    val generalSettingsService: IGeneralSettingsService,
    @deprecated val configurationService: IConfigurationService,
    grpcClient: GrpcClient
)(implicit val ec: ExecutionContext)
    extends MicroserviceAuth {

  private val LOG = Logger(classOf[ChargeBeeServiceMicroserviceStrategy])

  def getSubscription(): Future[ChargeBeeSubscription] = {
    LOG.info(s"Trying to get ChargeBee subscription details")
    val chargeBeeSubscriptionValueProto = grpcClient.licenseService
      .getChargeBeeSubscription(EmptyRequest())
    chargeBeeSubscriptionValueProto
      .map { proto =>
        LOG.debug(s"ChargeBee subscription details for ${proto.subscriptionId}: $proto")
        val status = proto.status match {
          case Some(value) => value
          case None        =>
            LOG.error(
              s"ChargeBee subscription status is not defined for subscription ${proto.subscriptionId}"
            )
            throw new RuntimeException("ChargeBee subscription status is not defined")
        }
        ChargeBeeSubscription(
          subscriptionId = proto.subscriptionId,
          customerId = proto.customerId,
          currentTermStart = proto.currentTermStart,
          currentTermEnd = proto.currentTermEnd,
          issueTrackerUrl = proto.issueTrackerUrl,
          status = status.name
        )
      }
      .recoverWith {
        case e: Exception =>
          LOG.error(s"Couldn't get ChargeBee subscription details", e)
          Future.failed(e)
      }

  }

}
