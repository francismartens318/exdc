package com.exalate.replication.services.license.stripe

import com.exalate.api.license.ILicenseEncoderService
import com.exalate.basic.domain.license.NonPersistentLicense
import com.exalate.domain.values.license.stripe.StripeSubscriptionValue
import com.exalate.license.HelperFor3_0v

import java.util.Date
import javax.inject.Inject

@deprecated
class StripeHelper @Inject() (
    HelperFor3_0v: HelperFor3_0v,
    licenseEncoderService: ILicenseEncoderService
) {

  def toNonPersistentLicense(subscriptionValue: StripeSubscriptionValue): NonPersistentLicense = {
    val license = new NonPersistentLicense(
      "3.0",
      new Date(subscriptionValue.current_period_start * 1000),
      toStripeEndDate(subscriptionValue.current_period_end),
      false,
      subscriptionValue.metadata.getOrElse("instanceUid", ""),
      subscriptionValue.id
    )

    license.setSignature(HelperFor3_0v.generateSignature(license))
    license
  }

  def getPayload(subscriptionValue: StripeSubscriptionValue): String =
    licenseEncoderService.encodeLicense(
      toNonPersistentLicense(subscriptionValue)
    )

  /*
    These methods are used on saving license & validating expiration date.
    If there was a problem of charging customer there are still 5 extra days for stripe subscription being valid in Exalate.
   */
  def toStripeWithExtraDate(current_period_end: Long): Long = current_period_end + 432000

  def toStripeEndDate(current_period_end: Long): Date = new Date(
    toStripeWithExtraDate(current_period_end) * 1000
  )

}
