package com.exalate.replication.services.license

import com.exalate.basic.domain.license.SubscriptionContext
import com.exalate.replication.services.license.SubscriptionValidationResult.{
  ExalateSubscriptionValidation,
  TrackerSubscriptionValidation
}

case class SubscriptionValidationResult(
    exalateSubscriptionValidation: ExalateSubscriptionValidation,
    trackerSubscriptionValidation: Option[TrackerSubscriptionValidation]
) {

  def hasValidSubscription: Boolean =
    trackerSubscriptionValidation.exists(_.isValid) || exalateSubscriptionValidation.isValid

  def toSubscriptionContext: SubscriptionContext =
    new SubscriptionContext(
      trackerSubscriptionValidation.exists(_.isValid),
      exalateSubscriptionValidation.isValid
    )

  def errorMessages: Seq[SubscriptionValidationError] =
    trackerSubscriptionValidation match {
      case Some(trackerValidation) if trackerValidation.isValid => Nil
      case _                                                    =>
        Seq(
          trackerSubscriptionValidation.flatMap(_.validationError),
          exalateSubscriptionValidation.validationError
        ).flatten
    }

}

sealed trait SubscriptionValidationError {
  def errorCode: String
}

case object VolumeNotUnderControl extends SubscriptionValidationError {

  // TODO change to code and rephrase the message
  def errorCode: String =
    "We reached out the limit of pair events. Please notify our administrator."

}

case object SyncIsNotAvailable extends SubscriptionValidationError {

  // TODO change to code and rephrase the message
  def errorCode: String =
    "The destination instance license doesn't support Visual and Script connections. To resolve the error you can use one of the following options:</br>- Create a Basic connection.</br>- Contact the destination instance administrator so you can agree on who will have a valid license for this connection.</br>"

}

case object TrackerLicenseIsNotActive extends SubscriptionValidationError {

  // TODO change to code and rephrase the message
  def errorCode: String =
    "Tracker License is not active, you are downgraded to the free version."

}

case object NotPayingInstance extends SubscriptionValidationError {

  // TODO change to code and rephrase the message
  def errorCode: String =
    "Only our side has an Exalate subscription. Please notify our administrator."

}

object SubscriptionValidationResult {

  case class TrackerSubscriptionValidation(
      isValid: Boolean,
      validationError: Option[SubscriptionValidationError] = None
  )

  case class ExalateSubscriptionValidation(
      isValid: Boolean,
      validationError: Option[SubscriptionValidationError] = None
  )

}
