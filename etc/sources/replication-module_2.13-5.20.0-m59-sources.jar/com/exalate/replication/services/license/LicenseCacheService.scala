package com.exalate.replication.services.license

import com.exalate.api.persistence.license.ILicenseCacheRepository
import com.exalate.basic.domain.license.LicenseCache
import com.exalate.services.api.IPersistenceCacheService

import javax.inject.{Inject, Singleton}
import scala.concurrent.Future

@Singleton
class LicenseCacheService @Inject() (licenseCacheRepository: ILicenseCacheRepository)
    extends IPersistenceCacheService[LicenseCache] {

  def getCache(key: String): Future[Option[LicenseCache]] = licenseCacheRepository.get(key)

  def upsertCache(cacheValue: LicenseCache): Future[LicenseCache] =
    licenseCacheRepository.upsert(cacheValue)

  def deleteCache(key: String): Future[Int] = licenseCacheRepository.delete(key)

}
