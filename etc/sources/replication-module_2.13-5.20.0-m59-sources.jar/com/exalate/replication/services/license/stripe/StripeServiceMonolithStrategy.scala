package com.exalate.replication.services.license.stripe

import com.exalate.api.exception.IssueTrackerException
import com.exalate.domain.exception.issuetracker.{
  BadRequestTrackerRestException,
  ForbiddenTrackerRestException,
  InternalServerErrorTrackerRestException
}
import com.exalate.domain.values.license.stripe.{
  StripeCustomerValue,
  StripeExpandedSubscriptionValue,
  StripeInvoiceValue,
  StripeSubscriptionValue
}
import com.exalate.domain.{GeneralSettings, InferredGeneralSettings}
import com.exalate.replication.services.api.config.IGeneralSettingsService
import com.exalate.replication.services.api.issuetracker.IIssueTrackerUrlService
import com.exalate.replication.services.api.node.lifecycle.{
  IApplicationModeService,
  ILifecycleInfoService
}
import com.exalate.replication.services.transport.value.ExaCompFormatters._
import com.exalate.services.utils.FutureUtils
import com.exalate.util.UrlUtils
import play.api.libs.json.{JsString, Json}
import play.api.libs.ws.{WSAuthScheme, WSClient, WSResponse}
import play.api.{Configuration, Logger}

import javax.inject.Inject
import scala.concurrent.{ExecutionContext, Future}

@deprecated
class StripeServiceMonolithStrategy @Inject() (
    wsClient: WSClient,
    val generalSettingsService: IGeneralSettingsService,
    val lifecycleInfoService: ILifecycleInfoService,
    configuration: Configuration,
    appModeService: IApplicationModeService,
    issueTrackerUrlService: IIssueTrackerUrlService
)(implicit ec: ExecutionContext)
    extends IStripeServiceStrategy {

  private val LOG = Logger("com.exalate.replication.controllers.internal.stripe.StripeClient")

  def generalSettings: InferredGeneralSettings =
    FutureUtils.resultInf(generalSettingsService.get).get.asInstanceOf[GeneralSettings]

  /** test data for stripe private final val SK_LIVE = "sk_test_GUOzyIxZ2mKrWJS30tyCYcIn00cb2fOHZF"
    * private final val PLAN: String = "plan_FMxw23YgrjUZ5n" private final val PK_LIVE =
    * "pk_test_eblReq69JwZEWufdbfZO5RzW00vfw0vnX6" //should be changed in {@StripeClient.jsx}
    */
  final private val SK_LIVE =
    if (appModeService.isInDevMode)
      configuration.getOptional[String]("exalate.license.stripe.sktest")
    else configuration.getOptional[String]("exalate.license.stripe.sklive")

  final private val PK_LIVE =
    if (appModeService.isInDevMode)
      configuration
        .getOptional[String]("exalate.license.stripe.pktest")
        .getOrElse("pk_test_8eTxHy2Y5n8ihTnQvAxc3871")
    else
      configuration
        .getOptional[String]("exalate.license.stripe.pklive")
        .getOrElse("pk_live_v8iPUiapmRJtGQxI7t33j7Od")

  private val STRIPE_BASE_URL: String =
    configuration.getOptional[String]("stripe.base.url").getOrElse("https://api.stripe.com")

  private val CHECKOUT_URL = "/v1/checkout/sessions"
  private val SUBSCRIPTIONS_URL = "/v1/subscriptions"
  private val CUSTOMERS_URL = "/v1/customers"
  private val INVOICES_URL = "/v1/invoices"
  private val PORTAL_SESSION_URL = "/v1/billing_portal/sessions"

  final private val PLAN =
    if (appModeService.isInDevMode)
      configuration.getOptional[String]("exalate.license.stripe.dev.plan")
    else configuration.getOptional[String]("exalate.license.stripe.prod.plan")

  final private val TAX_RATE =
    if (appModeService.isInDevMode)
      configuration.getOptional[String]("exalate.license.stripe.dev.tax")
    else configuration.getOptional[String]("exalate.license.stripe.prod.tax")

  override def generateSession(): Future[String] =
    lifecycleInfoService.getInstanceUid.flatMap { instanceUid =>
      issueTrackerUrlService
        .getSuccessUrl()
        .flatMap {
          case Some(licenseUrl) =>
            val body =
              Map(
                "success_url" -> Seq(
                  licenseUrl
                ), // TODO: change to gettingStartedUrl once success flag added on UI
                "cancel_url" -> Seq(licenseUrl),
                "payment_method_types[]" -> Seq("card"),
                "customer" -> generalSettings.fieldValues
                  .get("customer")
                  .map(r => Seq(r))
                  .getOrElse(Seq()),
                "line_items[][price]" -> Seq(PLAN.get),
                "line_items[][quantity]" -> Seq("1"),
                "line_items[][dynamic_tax_rates][]" -> Seq(TAX_RATE.get),
                "billing_address_collection" -> Seq("required"),
                "mode" -> Seq("subscription"),
                "subscription_data[metadata][instanceUid]" -> Seq(
                  instanceUid.getOrElse("")
                ),
                "subscription_data[metadata][exalateurl]" -> Seq(
                  generalSettings.getExalateUrl.getOrElse("")
                )
              )

            wsClient
              .url(UrlUtils.concat(STRIPE_BASE_URL, CHECKOUT_URL))
              .withAuth(SK_LIVE.get, "", WSAuthScheme.BASIC)
              .post(body)
              .flatMap(filterResponse(s"generating session"))
              .map(r => (Json.parse(r.body) \ "id").as[String])
          case _                =>
            val details = "Success url not found. Please contact support"
            LOG.error(details)
            Future.failed(new InternalServerErrorTrackerRestException(details))
        }
    }

  override def unsubscribe(subscriptionId: String): Future[Unit] =
    wsClient
      .url(UrlUtils.concat(STRIPE_BASE_URL, SUBSCRIPTIONS_URL, subscriptionId))
      .withAuth(SK_LIVE.get, "", WSAuthScheme.BASIC)
      .delete()
      .flatMap(filterResponse(s"unsubscribe"))
      .map(_ => ())

  override def getSubscription(subscriptionId: String): Future[Option[StripeSubscriptionValue]] =
    wsClient
      .url(UrlUtils.concat(STRIPE_BASE_URL, SUBSCRIPTIONS_URL, subscriptionId))
      .withAuth(SK_LIVE.get, "", WSAuthScheme.BASIC)
      .get()
      .map { r =>
        LOG.debug(s"Getting subscription $subscriptionId. Result: ${r.status} - ${r.body}")
        if (r.status == 404) {
          LOG.warn(s"Exalate checked for subscription with id $subscriptionId, but it's not found.")
          None
        } else Some(Json.parse(r.body).as[StripeSubscriptionValue])
      }

  override def getExpandedSubscription(
      subscriptionId: String
  ): Future[Option[StripeExpandedSubscriptionValue]] =
    wsClient
      .url(UrlUtils.concat(STRIPE_BASE_URL, SUBSCRIPTIONS_URL, subscriptionId))
      .withAuth(SK_LIVE.get, "", WSAuthScheme.BASIC)
      .withQueryStringParameters("expand[]" -> "latest_invoice.payment_intent")
      .get()
      .map { r =>
        if (r.status == 404) {
          LOG.warn(
            s"Exalate checked for expanded subscription with id $subscriptionId, but it's not found."
          )
          None
        } else Some(Json.parse(r.body).as[StripeExpandedSubscriptionValue])
      }

  override def getSubscriptionByCustomer(
      customerId: String
  ): Future[Option[StripeExpandedSubscriptionValue]] =
    wsClient
      .url(UrlUtils.concat(STRIPE_BASE_URL, SUBSCRIPTIONS_URL))
      .withAuth(SK_LIVE.get, "", WSAuthScheme.BASIC)
      .withQueryStringParameters(
        "customer" -> customerId,
        "limit" -> "1",
        "expand[]" -> "data.latest_invoice.payment_intent"
      )
      .get()
      .flatMap(filterResponse(s"get subscription by customer"))
      .map(r => (Json.parse(r.body) \ "data").asOpt[Seq[StripeExpandedSubscriptionValue]])
      .flatMap {
        case Some(subscriptionValues) if subscriptionValues.nonEmpty =>
          Future.successful(Option(subscriptionValues.head))
        case _                                                       => Future.successful(None)
      }

  override def generateCustomer(
      customerValue: StripeCustomerValue
  ): Future[Option[StripeCustomerValue]] = {
    val customerBody = customerValueToRequestBody(customerValue, None)

    wsClient
      .url(UrlUtils.concat(STRIPE_BASE_URL, CUSTOMERS_URL))
      .withAuth(SK_LIVE.get, "", WSAuthScheme.BASIC)
      .post(customerBody)
      .flatMap(filterResponse(s"generating customer"))
      .map(r => Option(Json.parse(r.body).as[StripeCustomerValue]))
  }

  override def updateCustomer(
      customerValue: StripeCustomerValue,
      customerId: String
  ): Future[Option[StripeCustomerValue]] = {
    val customerBody = customerValueToRequestBody(customerValue, Some(customerId))

    wsClient
      .url(UrlUtils.concat(STRIPE_BASE_URL, CUSTOMERS_URL, customerId))
      .withAuth(SK_LIVE.get, "", WSAuthScheme.BASIC)
      .post(customerBody)
      .flatMap(filterResponse(s"updating Customer"))
      .map(r => Option(Json.parse(r.body).as[StripeCustomerValue]))
  }

  private def customerValueToRequestBody(
      customerValue: StripeCustomerValue,
      customerId: Option[String]
  ): Map[String, Seq[String]] = {
    val body = Map(
      "address[city]" -> Seq(customerValue.address.city),
      "address[country]" -> Seq(customerValue.address.country),
      "address[line1]" -> Seq(customerValue.address.line1),
      "address[line2]" -> Seq(customerValue.address.line2.getOrElse("")),
      "address[postal_code]" -> Seq(customerValue.address.postal_code),
      "address[state]" -> Seq(customerValue.address.state),
      "name" -> Seq(customerValue.name),
      "email" -> Seq(customerValue.email)
    )

    val bodyWithSource = customerValue.source match {
      case Some(source) => body ++ Map("source" -> Seq(source))
      case _            => body
    }

    val bodyWithShipping = customerValue.shipping match {
      case Some(shippingValue) =>
        bodyWithSource ++ Map(
          "shipping[name]" -> Seq(shippingValue.name),
          "shipping[address][city]" -> Seq(shippingValue.address.city),
          "shipping[address][country]" -> Seq(shippingValue.address.country),
          "shipping[address][line1]" -> Seq(shippingValue.address.line1),
          "shipping[address][line2]" -> Seq(shippingValue.address.line2.getOrElse("")),
          "shipping[address][postal_code]" -> Seq(shippingValue.address.postal_code),
          "shipping[address][state]" -> Seq(shippingValue.address.state)
        )
      case _                   => bodyWithSource
    }

    // Only send tax data if we're creating a customer
    val requestBodyForStripe = if (customerId.isEmpty) {
      customerValue.tax_id_data match {
        case Some(taxId) if taxId.value.nonEmpty && taxId.`type`.nonEmpty =>
          bodyWithShipping ++ Map(
            "tax_id_data[][type]" -> Seq(taxId.`type`),
            "tax_id_data[][value]" -> Seq(taxId.value)
          )
        case _                                                            => bodyWithShipping
      }
    } else bodyWithShipping

    requestBodyForStripe
  }

  override def generateSubscription(
      customerId: String
  ): Future[Option[StripeExpandedSubscriptionValue]] =
    lifecycleInfoService.getInstanceUid.flatMap { instanceUid =>
      val body =
        Map(
          "customer" -> Seq(customerId),
          "items[][plan]" -> Seq(PLAN.get),
          "metadata[instanceUid]" -> Seq(instanceUid.getOrElse("")),
          "metadata[exalateurl]" -> Seq(generalSettings.getExalateUrl.getOrElse("")),
          "expand[]" -> Seq("latest_invoice.payment_intent")
        )
      wsClient
        .url(UrlUtils.concat(STRIPE_BASE_URL, SUBSCRIPTIONS_URL))
        .withAuth(SK_LIVE.get, "", WSAuthScheme.BASIC)
        .post(body)
        .flatMap(filterResponse(s"generating subscription"))
        .map(r => Option(Json.parse(r.body).as[StripeExpandedSubscriptionValue]))
    }

  override def generateBillingPortalSession(): Future[String] =
    issueTrackerUrlService
      .getSuccessUrl()
      .flatMap {
        case Some(licenseUrl) =>
          val body =
            Map(
              "customer" -> generalSettings.fieldValues
                .get("customer")
                .map(r => Seq(r))
                .getOrElse(Seq()),
              "return_url" -> Seq(licenseUrl)
            )

          wsClient
            .url(UrlUtils.concat(STRIPE_BASE_URL, PORTAL_SESSION_URL))
            .withAuth(SK_LIVE.get, "", WSAuthScheme.BASIC)
            .post(body)
            .flatMap(filterResponse("generating Stripe billing portal session"))
            .map(r => (Json.parse(r.body) \ "url").as[String])
        case _                =>
          val details = "Success url not found. Please contact support"
          LOG.error(details)
          Future.failed(new InternalServerErrorTrackerRestException(details))
      }

  override def payInvoice(invoiceId: String): Future[Option[StripeInvoiceValue]] =
    wsClient
      .url(UrlUtils.concat(STRIPE_BASE_URL, INVOICES_URL, s"/$invoiceId/pay"))
      .withAuth(SK_LIVE.get, "", WSAuthScheme.BASIC)
      .withQueryStringParameters("expand[]" -> "payment_intent")
      .execute("POST")
      .flatMap(filterResponse(s"paying invoice"))
      .map(r => Option(Json.parse(r.body).as[StripeInvoiceValue]))

  private def filterResponse(actionMsj: String)(r: WSResponse): Future[WSResponse] =
    r.status match {
      case s if s == 401 || s == 403 =>
        LOG.error(
          s"Request to Stripe failed when $actionMsj with status code ${r.status} and body ${r.body}"
        )
        Future.failed(new ForbiddenTrackerRestException(s"Authentication error when $actionMsj"))
      case s if s == 400 || s == 402 =>
        val message = (Json.parse(r.body) \ "error" \ "message").asOpt[JsString]
        LOG.error(
          s"Request to Stripe failed when $actionMsj with status code ${r.status} and body $message"
        )
        message match {
          case Some(m) => Future.failed(new BadRequestTrackerRestException(m.value))
          case None    =>
            Future.failed(
              new BadRequestTrackerRestException("There was a problem while paying for your license")
            )
        }
      case s if s >= 400             =>
        LOG.error(
          s"Request to Stripe failed when $actionMsj with status code ${r.status} and body ${r.body}"
        )
        Future.failed(
          new IssueTrackerException(s"There was a problem during communication with Stripe")
        )
      case _                         => Future.successful(r)
    }

  override def getPublishableKey(): Future[String] = Future.successful(PK_LIVE)
}
