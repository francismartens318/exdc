package com.exalate.replication.services.persistence

import com.exalate.api.persistence.oauth.IOAuthDataRepository
import com.exalate.persistence.oauth.OAuthDataRepository
import com.google.inject.Provider
import javax.inject.Inject
import play.api.db.slick.DatabaseConfigProvider
import slick.jdbc.{JdbcBackend, JdbcProfile}

import scala.concurrent.ExecutionContext

class OAuthDataRespositoryProvider @Inject() (dbConfigProvider: DatabaseConfigProvider)(implicit
    val executionContext: ExecutionContext
) extends Provider[IOAuthDataRepository] {
  private val db: JdbcBackend#DatabaseDef = dbConfigProvider.get[JdbcProfile].db

  override def get(): IOAuthDataRepository =
    new OAuthDataRepository(db)

}
