package com.exalate.replication.services.persistence

import com.exalate.api.persistence.replication.request.ICreateOrUpdateTwinTraceSyncRequestStateRepository
import com.exalate.persistence.replication.request.state.CreateOrUpdateTwinTraceSyncRequestStateRepository
import com.google.inject.{Inject, Provider, Singleton}
import play.api.db.slick.DatabaseConfigProvider
import slick.jdbc.JdbcProfile
import slick.jdbc.JdbcBackend

import scala.concurrent.ExecutionContext

@Singleton
class RequestCreateOrUpdateTTRepositoryProvider @Inject() (
    dbConfigProvider: DatabaseConfigProvider
)(implicit ec: ExecutionContext)
    extends Provider[ICreateOrUpdateTwinTraceSyncRequestStateRepository] {
  private val db: JdbcBackend#DatabaseDef = dbConfigProvider.get[JdbcProfile].db

  override def get(): ICreateOrUpdateTwinTraceSyncRequestStateRepository =
    new CreateOrUpdateTwinTraceSyncRequestStateRepository(db)

}
