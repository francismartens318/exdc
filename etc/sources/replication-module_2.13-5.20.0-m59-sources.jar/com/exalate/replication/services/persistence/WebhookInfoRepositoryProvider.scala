package com.exalate.replication.services.persistence

import com.exalate.api.persistence.webhook.IWebhookInfoRepository
import com.exalate.persistence.webhook.WebhookInfoRepository
import com.google.inject.Provider
import javax.inject.Inject
import play.api.db.slick.DatabaseConfigProvider
import slick.jdbc.{JdbcBackend, JdbcProfile}

import scala.concurrent.ExecutionContext

class WebhookInfoRepositoryProvider @Inject() (dbConfigProvider: DatabaseConfigProvider)(implicit
    ec: ExecutionContext
) extends Provider[IWebhookInfoRepository] {
  private val db: JdbcBackend#DatabaseDef = dbConfigProvider.get[JdbcProfile].db

  override def get(): IWebhookInfoRepository =
    new WebhookInfoRepository(db)

}
