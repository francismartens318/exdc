package com.exalate.replication.services.persistence

import com.exalate.api.persistence.replication.request.ICompleteSyncRequestStateRepository
import com.exalate.persistence.replication.request.state.CompleteSyncRequestStateRepository
import com.google.inject.{Inject, Provider, Singleton}
import play.api.db.slick.DatabaseConfigProvider
import slick.jdbc.JdbcProfile
import slick.jdbc.JdbcBackend

import scala.concurrent.ExecutionContext

@Singleton
class RequestCompleteRepositoryProvider @Inject() (dbConfigProvider: DatabaseConfigProvider)(
    implicit ec: ExecutionContext
) extends Provider[ICompleteSyncRequestStateRepository] {
  private val db: JdbcBackend#DatabaseDef = dbConfigProvider.get[JdbcProfile].db

  override def get(): ICompleteSyncRequestStateRepository =
    new CompleteSyncRequestStateRepository(db)

}
