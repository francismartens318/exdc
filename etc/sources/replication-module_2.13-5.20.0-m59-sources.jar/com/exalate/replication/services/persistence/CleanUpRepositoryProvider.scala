package com.exalate.replication.services.persistence

import javax.inject.Inject
import com.exalate.api.persistence.ICleanUpRepository
import com.exalate.persistence.CleanUpRepository
import com.exalate.services.api.ITrackerFieldValuesService
import com.google.inject.Provider
import play.api.db.slick.DatabaseConfigProvider
import slick.jdbc.JdbcProfile
import slick.jdbc.JdbcBackend

import scala.concurrent.ExecutionContext

class CleanUpRepositoryProvider @Inject() (
    dbConfigProvider: DatabaseConfigProvider,
    trackerFieldValuesService: ITrackerFieldValuesService
)(implicit ec: ExecutionContext)
    extends Provider[ICleanUpRepository] {
  private val db: JdbcBackend#DatabaseDef = dbConfigProvider.get[JdbcProfile].db

  override def get(): ICleanUpRepository =
    new CleanUpRepository(db, trackerFieldValuesService)

}
