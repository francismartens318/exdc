package com.exalate.replication.services.persistence

import com.exalate.api.persistence.replication.request.IUpdateBlobSyncRequestRepository
import com.exalate.persistence.replication.request.state.UpdateBlobSyncRequestRepository
import com.google.inject.{Inject, Provider, Singleton}
import play.api.db.slick.DatabaseConfigProvider
import slick.jdbc.JdbcProfile
import slick.jdbc.JdbcBackend

import scala.concurrent.ExecutionContext

@Singleton
class RequestUpdateBlobRepositoryProvider @Inject() (dbConfigProvider: DatabaseConfigProvider)(
    implicit ec: ExecutionContext
) extends Provider[IUpdateBlobSyncRequestRepository] {
  private val db: JdbcBackend#DatabaseDef = dbConfigProvider.get[JdbcProfile].db

  override def get(): IUpdateBlobSyncRequestRepository =
    new UpdateBlobSyncRequestRepository(db)

}
