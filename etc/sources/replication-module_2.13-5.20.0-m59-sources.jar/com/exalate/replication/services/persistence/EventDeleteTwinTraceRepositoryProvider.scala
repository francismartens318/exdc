package com.exalate.replication.services.persistence

import com.exalate.api.persistence.replication.event.IEventDeleteTwinTraceRepository
import com.exalate.persistence.replication.event.state.DeleteTwinTraceSyncEventStateRepository
import com.google.inject.{Inject, Provider, Singleton}
import play.api.db.slick.DatabaseConfigProvider
import slick.jdbc.JdbcProfile
import slick.jdbc.JdbcBackend

import scala.concurrent.ExecutionContext

@Singleton
class EventDeleteTwinTraceRepositoryProvider @Inject() (dbConfigProvider: DatabaseConfigProvider)(
    implicit ec: ExecutionContext
) extends Provider[IEventDeleteTwinTraceRepository] {
  private val db: JdbcBackend#DatabaseDef = dbConfigProvider.get[JdbcProfile].db

  override def get(): IEventDeleteTwinTraceRepository =
    new DeleteTwinTraceSyncEventStateRepository(db)

}
