package com.exalate.replication.services.persistence

import com.exalate.api.persistence.replication.request.{
  IRequestReplicationRepository,
  IUpdateIssueSyncRequestStateRepository
}
import com.exalate.persistence.replication.request.state.UpdateIssueSyncRequestStateRepository
import com.google.inject.{Inject, Provider, Singleton}
import play.api.db.slick.DatabaseConfigProvider
import slick.jdbc.JdbcProfile
import slick.jdbc.JdbcBackend

import scala.concurrent.ExecutionContext

@Singleton
class RequestUpdateIssueRepositoryProvider @Inject() (
    dbConfigProvider: DatabaseConfigProvider,
    requestReplicationRepository: IRequestReplicationRepository
)(implicit ec: ExecutionContext)
    extends Provider[IUpdateIssueSyncRequestStateRepository] {
  private val db: JdbcBackend#DatabaseDef = dbConfigProvider.get[JdbcProfile].db

  override def get(): IUpdateIssueSyncRequestStateRepository =
    new UpdateIssueSyncRequestStateRepository(db, requestReplicationRepository)

}
