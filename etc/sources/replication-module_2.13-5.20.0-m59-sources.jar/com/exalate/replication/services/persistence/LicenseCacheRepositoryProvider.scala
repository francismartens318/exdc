package com.exalate.replication.services.persistence

import com.exalate.api.persistence.license.ILicenseCacheRepository
import com.exalate.persistence.license.LicenseCacheRepository
import com.google.inject.{Inject, Provider, Singleton}
import play.api.db.slick.DatabaseConfigProvider
import slick.jdbc.{JdbcBackend, JdbcProfile}

import scala.concurrent.ExecutionContext

@Singleton
class LicenseCacheRepositoryProvider @Inject() (dbConfigProvider: DatabaseConfigProvider)(implicit
    ec: ExecutionContext
) extends Provider[ILicenseCacheRepository] {
  private val db: JdbcBackend#DatabaseDef = dbConfigProvider.get[JdbcProfile].db

  override def get(): ILicenseCacheRepository =
    new LicenseCacheRepository(db)

}
