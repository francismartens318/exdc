package com.exalate.replication.services.persistence

import com.exalate.api.persistence.mappings.IMappingsRepository
import com.exalate.persistence.mappings.MappingsRepository
import com.google.inject.{Provider, Singleton}
import javax.inject.Inject
import play.api.db.slick.DatabaseConfigProvider
import slick.jdbc.{JdbcBackend, JdbcProfile}

import scala.concurrent.ExecutionContext

@Singleton
class MappingsRepositoryProvider @Inject() (dbConfigProvider: DatabaseConfigProvider)(implicit
    ec: ExecutionContext
) extends Provider[IMappingsRepository] {
  private val db: JdbcBackend#DatabaseDef = dbConfigProvider.get[JdbcProfile].db

  override def get(): IMappingsRepository =
    new MappingsRepository(db)

}
