package com.exalate.replication.services.persistence

import com.exalate.api.persistence.exalateadmin.IExalateAdminRepository
import com.exalate.persistence.exalateadmin.ExalateAdminRepository
import com.google.inject.{Provider, Singleton}
import javax.inject.Inject
import play.api.db.slick.DatabaseConfigProvider
import slick.jdbc.{JdbcBackend, JdbcProfile}

import scala.concurrent.ExecutionContext

@Singleton
class ExalateAdminRepositoryProvider @Inject() (dbConfigProvider: DatabaseConfigProvider)(implicit
    ec: ExecutionContext
) extends Provider[IExalateAdminRepository] {
  private val db: JdbcBackend#DatabaseDef = dbConfigProvider.get[JdbcProfile].db

  override def get(): IExalateAdminRepository =
    new ExalateAdminRepository(db)

}
