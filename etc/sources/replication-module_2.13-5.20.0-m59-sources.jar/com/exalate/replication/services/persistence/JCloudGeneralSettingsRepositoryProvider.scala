package com.exalate.replication.services.persistence

import javax.inject.Inject
import com.exalate.api.persistence.issuetracker.jcloud.IJCloudGeneralSettingsRepository
import com.exalate.persistence.cache.{
  CachedJCloudGeneralSettingsRepository,
  GeneralSettingsRepositoryCacheConfigProvider
}
import com.exalate.persistence.issuetracker.jcloud.{
  CloudInstallationRepository,
  JCloudGeneralSettingsRepository
}
import com.google.inject.{Provider, Singleton}
import play.api.db.slick.DatabaseConfigProvider
import slick.jdbc.JdbcProfile
import slick.jdbc.JdbcBackend

import scala.concurrent.ExecutionContext

@Singleton
class JCloudGeneralSettingsRepositoryProvider @Inject() (
    dbConfigProvider: DatabaseConfigProvider,
    cacheConfigProvider: GeneralSettingsRepositoryCacheConfigProvider
)(implicit ec: ExecutionContext)
    extends Provider[IJCloudGeneralSettingsRepository] {
  val db: JdbcBackend#DatabaseDef = dbConfigProvider.get[JdbcProfile].db

  val cloudInstallationRepository = new CloudInstallationRepository(db)

  val jcloudGeneralSettingsRepository =
    new JCloudGeneralSettingsRepository(db, cloudInstallationRepository)

  val cacheConfig = cacheConfigProvider.get()

  def cachedJCloudGeneralSettings = new CachedJCloudGeneralSettingsRepository(
    jcloudGeneralSettingsRepository,
    cacheConfig
  )

  override val get: IJCloudGeneralSettingsRepository = cachedJCloudGeneralSettings
}
