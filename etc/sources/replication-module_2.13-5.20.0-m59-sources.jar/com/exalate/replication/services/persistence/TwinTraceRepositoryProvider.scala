package com.exalate.replication.services.persistence

import javax.inject.Inject
import com.exalate.api.persistence.twintrace.ITwinTraceRepository
import com.exalate.persistence.twintrace.TwinTraceRepository
import com.exalate.services.api.ITrackerFieldValuesService
import com.google.inject.Provider
import play.api.db.slick.DatabaseConfigProvider
import slick.jdbc.JdbcProfile
import slick.jdbc.JdbcBackend

import scala.concurrent.ExecutionContext

class TwinTraceRepositoryProvider @Inject() (
    dbConfigProvider: DatabaseConfigProvider,
    trackerFieldValuesService: ITrackerFieldValuesService
)(implicit ec: ExecutionContext)
    extends Provider[ITwinTraceRepository] {
  private val db: JdbcBackend#DatabaseDef = dbConfigProvider.get[JdbcProfile].db

  override def get(): ITwinTraceRepository =
    new TwinTraceRepository(db, trackerFieldValuesService)

}
