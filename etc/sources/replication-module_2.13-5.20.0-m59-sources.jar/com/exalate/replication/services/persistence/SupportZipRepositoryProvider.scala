package com.exalate.replication.services.persistence

import javax.inject.Inject
import com.exalate.persistence.supportzip.SupportZipRepository
import com.exalate.replication.services.node.filesystem.FileSystemService
import play.api.db.slick.DatabaseConfigProvider
import com.google.inject.Provider
import play.api.Configuration
import slick.jdbc.{JdbcBackend, JdbcProfile}

import scala.concurrent.ExecutionContext

class SupportZipRepositoryProvider @Inject() (
    dbConfigProvider: DatabaseConfigProvider,
    fileSystemService: FileSystemService,
    configuration: Configuration
)(implicit ec: ExecutionContext)
    extends Provider[SupportZipRepository] {

  private val db: JdbcBackend#DatabaseDef = dbConfigProvider.get[JdbcProfile].db

  override def get(): SupportZipRepository = new SupportZipRepository(db, configuration)

}
