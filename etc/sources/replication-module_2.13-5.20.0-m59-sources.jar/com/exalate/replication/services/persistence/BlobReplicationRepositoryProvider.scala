package com.exalate.replication.services.persistence

import com.exalate.api.persistence.replication.blob.IBlobReplicationRepository
import com.exalate.persistence.replication.blob.BlobReplicationRepository
import com.google.inject.{Inject, Provider, Singleton}
import play.api.db.slick.DatabaseConfigProvider
import slick.jdbc.JdbcProfile
import slick.jdbc.JdbcBackend

import scala.concurrent.ExecutionContext

@Singleton
class BlobReplicationRepositoryProvider @Inject() (dbConfigProvider: DatabaseConfigProvider)(
    implicit ec: ExecutionContext
) extends Provider[IBlobReplicationRepository] {
  private val db: JdbcBackend#DatabaseDef = dbConfigProvider.get[JdbcProfile].db

  override def get(): IBlobReplicationRepository =
    new BlobReplicationRepository(db)

}
