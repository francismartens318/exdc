package com.exalate.replication.services.persistence

import com.exalate.api.persistence.replication.event.IEventReadyRepository
import com.exalate.persistence.replication.event.state.ReadySyncEventStateRepository
import com.google.inject.{Inject, Provider, Singleton}
import play.api.db.slick.DatabaseConfigProvider
import slick.jdbc.JdbcProfile
import slick.jdbc.JdbcBackend

import scala.concurrent.ExecutionContext

@Singleton
class EventReadyRepositoryProvider @Inject() (dbConfigProvider: DatabaseConfigProvider)(implicit
    ec: ExecutionContext
) extends Provider[IEventReadyRepository] {
  private val db: JdbcBackend#DatabaseDef = dbConfigProvider.get[JdbcProfile].db

  override def get(): IEventReadyRepository =
    new ReadySyncEventStateRepository(db)

}
