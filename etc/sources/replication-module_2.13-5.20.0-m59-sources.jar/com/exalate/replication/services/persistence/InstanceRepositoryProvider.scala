package com.exalate.replication.services.persistence

import com.exalate.api.persistence.instance.IInstanceRepository
import com.exalate.persistence.CleanUpRepository
import com.exalate.persistence.instance.InstanceRepository
import com.google.inject.{Provider, Singleton}
import javax.inject.Inject
import play.api.db.slick.DatabaseConfigProvider
import slick.jdbc.{JdbcBackend, JdbcProfile}

import scala.concurrent.ExecutionContext

@Singleton
class InstanceRepositoryProvider @Inject() (dbConfigProvider: DatabaseConfigProvider)(implicit
    ec: ExecutionContext
) extends Provider[IInstanceRepository] {
  private val db: JdbcBackend#DatabaseDef = dbConfigProvider.get[JdbcProfile].db

  override def get(): IInstanceRepository =
    new InstanceRepository(db)

}
