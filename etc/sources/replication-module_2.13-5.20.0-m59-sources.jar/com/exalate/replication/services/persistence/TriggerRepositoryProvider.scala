package com.exalate.replication.services.persistence

import javax.inject.Inject
import com.exalate.api.persistence.trigger.ITriggerRepository
import com.exalate.persistence.trigger.TriggerRepository
import com.google.inject.Provider
import play.api.db.slick.DatabaseConfigProvider
import slick.jdbc.JdbcProfile
import slick.jdbc.JdbcBackend

import scala.concurrent.ExecutionContext

class TriggerRepositoryProvider @Inject() (dbConfigProvider: DatabaseConfigProvider)(implicit
    ec: ExecutionContext
) extends Provider[ITriggerRepository] {
  private val db: JdbcBackend#DatabaseDef = dbConfigProvider.get[JdbcProfile].db

  override def get(): ITriggerRepository =
    new TriggerRepository(db)

}
