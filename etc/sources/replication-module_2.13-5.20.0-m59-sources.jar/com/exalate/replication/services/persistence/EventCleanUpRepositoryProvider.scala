package com.exalate.replication.services.persistence

import com.exalate.api.persistence.replication.event.IEventCleanUpRepository
import com.exalate.persistence.replication.event.EventCleanUpRepository
import com.google.inject.{Inject, Provider, Singleton}
import play.api.db.slick.DatabaseConfigProvider
import slick.jdbc.JdbcProfile
import slick.jdbc.JdbcBackend

import scala.concurrent.ExecutionContext

@Singleton
class EventCleanUpRepositoryProvider @Inject() (dbConfigProvider: DatabaseConfigProvider)(implicit
    ec: ExecutionContext
) extends Provider[IEventCleanUpRepository] {
  private val db: JdbcBackend#DatabaseDef = dbConfigProvider.get[JdbcProfile].db

  override def get(): IEventCleanUpRepository =
    new EventCleanUpRepository(db)

}
