package com.exalate.replication.services.persistence

import com.exalate.api.persistence.message.IMessageChunkRepository
import com.exalate.persistence.message.MessageChunkRepository
import com.google.inject.{Provider, Singleton}
import javax.inject.Inject
import play.api.db.slick.DatabaseConfigProvider
import slick.jdbc.{JdbcBackend, JdbcProfile}

import scala.concurrent.ExecutionContext

@Singleton
class MessageChunkRepositoryProvider @Inject() (dbConfigProvider: DatabaseConfigProvider)(implicit
    ec: ExecutionContext
) extends Provider[IMessageChunkRepository] {
  private val db: JdbcBackend#DatabaseDef = dbConfigProvider.get[JdbcProfile].db

  override def get(): IMessageChunkRepository =
    new MessageChunkRepository(db)

}
