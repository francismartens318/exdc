package com.exalate.replication.services.persistence.jcloud

import javax.inject.Inject
import com.exalate.api.persistence.jcloud.ICloudInstallationRepository
import com.exalate.persistence.issuetracker.jcloud.CloudInstallationRepository
import com.google.inject.Provider
import play.api.db.slick.DatabaseConfigProvider
import slick.jdbc.JdbcProfile
import slick.jdbc.JdbcBackend

import scala.concurrent.ExecutionContext

class CloudInstallationRepositoryProvider @Inject() (dbConfigProvider: DatabaseConfigProvider)(
    implicit ec: ExecutionContext
) extends Provider[ICloudInstallationRepository] {
  private val db: JdbcBackend#DatabaseDef = dbConfigProvider.get[JdbcProfile].db

  override def get(): ICloudInstallationRepository =
    new CloudInstallationRepository(db)

}
