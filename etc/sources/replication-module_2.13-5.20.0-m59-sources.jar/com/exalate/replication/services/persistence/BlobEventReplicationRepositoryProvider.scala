package com.exalate.replication.services.persistence

import com.exalate.api.persistence.replication.blobevent.IBlobEventReplicationRepository
import com.exalate.persistence.replication.blobevent.BlobEventReplicationRepository
import com.google.inject.{Inject, Provider, Singleton}
import play.api.db.slick.DatabaseConfigProvider
import slick.driver.JdbcProfile
import slick.jdbc.JdbcBackend

import scala.concurrent.ExecutionContext

@Singleton
class BlobEventReplicationRepositoryProvider @Inject() (dbConfigProvider: DatabaseConfigProvider)(
    implicit ec: ExecutionContext
) extends Provider[IBlobEventReplicationRepository] {
  private val db: JdbcBackend#DatabaseDef = dbConfigProvider.get[JdbcProfile].db

  override def get(): IBlobEventReplicationRepository =
    new BlobEventReplicationRepository(db)

}
