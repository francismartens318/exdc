package com.exalate.replication.services.persistence

import com.exalate.api.persistence.issuetracker.IIssueTrackerOptionRepository
import com.exalate.persistence.issuetracker.IssueTrackerOptionRepository
import com.google.inject.{Provider, Singleton}
import javax.inject.Inject
import play.api.db.slick.DatabaseConfigProvider
import slick.jdbc.{JdbcBackend, JdbcProfile}

import scala.concurrent.ExecutionContext

@Singleton
class TrackerOptionRepositoryProvider @Inject() (dbConfigProvider: DatabaseConfigProvider)(implicit
    ec: ExecutionContext
) extends Provider[IIssueTrackerOptionRepository] {
  private val db: JdbcBackend#DatabaseDef = dbConfigProvider.get[JdbcProfile].db

  override def get(): IIssueTrackerOptionRepository =
    new IssueTrackerOptionRepository(db)

}
