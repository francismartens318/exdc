package com.exalate.replication.services.persistence

import com.exalate.api.persistence.scopes.IScopesRepository
import com.exalate.persistence.scopes.ScopesRepository
import com.google.inject.{Provider, Singleton}
import javax.inject.Inject
import play.api.db.slick.DatabaseConfigProvider
import slick.jdbc.{JdbcBackend, JdbcProfile}

import scala.concurrent.ExecutionContext

@Singleton
class ScopesRepositoryProvider @Inject() (dbConfigProvider: DatabaseConfigProvider)(implicit
    ec: ExecutionContext
) extends Provider[IScopesRepository] {
  private val db: JdbcBackend#DatabaseDef = dbConfigProvider.get[JdbcProfile].db

  override def get(): IScopesRepository =
    new ScopesRepository(db)

}
