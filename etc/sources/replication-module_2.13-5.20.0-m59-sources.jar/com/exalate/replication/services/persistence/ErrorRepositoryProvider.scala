package com.exalate.replication.services.persistence

import javax.inject.Inject
import com.exalate.api.persistence.error.IErrorRepository
import com.exalate.persistence.error.ErrorRepository
import com.exalate.services.api.ITrackerFieldValuesService
import com.google.inject.Provider
import play.api.db.slick.DatabaseConfigProvider
import slick.jdbc.JdbcProfile
import slick.jdbc.JdbcBackend

import scala.concurrent.ExecutionContext

class ErrorRepositoryProvider @Inject() (
    dbConfigProvider: DatabaseConfigProvider,
    trackerFieldValuesService: ITrackerFieldValuesService
)(implicit ec: ExecutionContext)
    extends Provider[IErrorRepository] {
  private val db: JdbcBackend#DatabaseDef = dbConfigProvider.get[JdbcProfile].db

  override def get(): IErrorRepository =
    new ErrorRepository(db, trackerFieldValuesService)

}
