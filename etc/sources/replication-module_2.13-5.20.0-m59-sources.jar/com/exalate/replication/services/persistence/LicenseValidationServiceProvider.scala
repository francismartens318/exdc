package com.exalate.replication.services.persistence

import com.exalate.api.license.{ILicenseSignatureHelperFactory, ILicenseValidationService}
import com.exalate.license.LicenseValidationService
import com.google.inject.{Inject, Provider}

import scala.concurrent.ExecutionContext

class LicenseValidationServiceProvider @Inject() (
    licenseSignatureHelperFactory: ILicenseSignatureHelperFactory
)(implicit ec: ExecutionContext)
    extends Provider[ILicenseValidationService] {

  override def get(): ILicenseValidationService =
    new LicenseValidationService(licenseSignatureHelperFactory)

}
