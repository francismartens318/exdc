package com.exalate.replication.services.persistence

import com.exalate.api.persistence.metrics.IMetricsRepository
import com.exalate.persistence.metrics.MetricsRepository
import com.google.inject.{Provider, Singleton}
import javax.inject.Inject
import play.api.db.slick.DatabaseConfigProvider
import slick.jdbc.{JdbcBackend, JdbcProfile}

import scala.concurrent.ExecutionContext

@Singleton
class MetricsRepositoryProvider @Inject() (dbConfigProvider: DatabaseConfigProvider)(implicit
    ec: ExecutionContext
) extends Provider[IMetricsRepository] {
  private val db: JdbcBackend#DatabaseDef = dbConfigProvider.get[JdbcProfile].db

  override def get(): IMetricsRepository =
    new MetricsRepository(db)

}
