package com.exalate.replication.services.persistence

import com.exalate.api.persistence.replication.request.ICreateReplicaSyncRequestStateRepository
import com.exalate.persistence.replication.request.state.CreateReplicaSyncRequestStateRepository
import com.google.inject.{Inject, Provider, Singleton}
import play.api.db.slick.DatabaseConfigProvider
import slick.jdbc.JdbcProfile
import slick.jdbc.JdbcBackend

import scala.concurrent.ExecutionContext

@Singleton
class RequestCreateReplicaRepositoryProvider @Inject() (dbConfigProvider: DatabaseConfigProvider)(
    implicit ec: ExecutionContext
) extends Provider[ICreateReplicaSyncRequestStateRepository] {
  private val db: JdbcBackend#DatabaseDef = dbConfigProvider.get[JdbcProfile].db

  override def get(): ICreateReplicaSyncRequestStateRepository =
    new CreateReplicaSyncRequestStateRepository(db)

}
