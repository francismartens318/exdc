package com.exalate.replication.services.persistence

import com.exalate.api.persistence.replication.request.IRequestReplicationRepository
import com.exalate.persistence.replication.request.RequestReplicationRepository
import com.google.inject.{Inject, Provider, Singleton}
import play.api.db.slick.DatabaseConfigProvider
import slick.jdbc.JdbcProfile
import slick.jdbc.JdbcBackend

import scala.concurrent.ExecutionContext

@Singleton
class RequestReplicationRepositoryProvider @Inject() (dbConfigProvider: DatabaseConfigProvider)(
    implicit ec: ExecutionContext
) extends Provider[IRequestReplicationRepository] {
  private val db: JdbcBackend#DatabaseDef = dbConfigProvider.get[JdbcProfile].db

  override def get(): IRequestReplicationRepository =
    new RequestReplicationRepository(db)

}
