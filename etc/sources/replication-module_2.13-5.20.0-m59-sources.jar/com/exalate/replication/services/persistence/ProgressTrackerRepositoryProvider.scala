package com.exalate.replication.services.persistence

import com.exalate.api.persistence.progresstracker.IProgressTrackerRepository
import com.exalate.persistence.progresstracker.ProgressTrackerRepository
import com.google.inject.{Inject, Provider, Singleton}
import play.api.db.slick.DatabaseConfigProvider
import slick.jdbc.{JdbcBackend, JdbcProfile}

import scala.concurrent.ExecutionContext

@Singleton
class ProgressTrackerRepositoryProvider @Inject() (dbConfigProvider: DatabaseConfigProvider)(
    implicit ec: ExecutionContext
) extends Provider[IProgressTrackerRepository] {
  private val db: JdbcBackend#DatabaseDef = dbConfigProvider.get[JdbcProfile].db
  override def get(): IProgressTrackerRepository = new ProgressTrackerRepository(db)
}
