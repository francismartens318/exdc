package com.exalate.replication.services.persistence

import com.exalate.api.persistence.replication.request.ICreateIssueSyncRequestStateRepository
import com.exalate.persistence.replication.request.state.CreateIssueSyncRequestStateRepository
import com.google.inject.{Inject, Provider, Singleton}
import play.api.db.slick.DatabaseConfigProvider
import slick.jdbc.JdbcProfile
import slick.jdbc.JdbcBackend

import scala.concurrent.ExecutionContext

@Singleton
class RequestCreateIssueRepositoryProvider @Inject() (dbConfigProvider: DatabaseConfigProvider)(
    implicit ec: ExecutionContext
) extends Provider[ICreateIssueSyncRequestStateRepository] {
  private val db: JdbcBackend#DatabaseDef = dbConfigProvider.get[JdbcProfile].db

  override def get(): ICreateIssueSyncRequestStateRepository =
    new CreateIssueSyncRequestStateRepository(db)

}
