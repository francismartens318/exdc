package com.exalate.replication.services.persistence

import com.exalate.api.persistence.replication.event.IEventReplicationRepository
import com.exalate.persistence.replication.event.EventReplicationRepository
import com.google.inject.{Inject, Provider, Singleton}
import play.api.db.slick.DatabaseConfigProvider
import slick.jdbc.JdbcProfile
import slick.jdbc.JdbcBackend

import scala.concurrent.ExecutionContext

@Singleton
class EventReplicationRepositoryProvider @Inject() (dbConfigProvider: DatabaseConfigProvider)(
    implicit ec: ExecutionContext
) extends Provider[IEventReplicationRepository] {
  private val db: JdbcBackend#DatabaseDef = dbConfigProvider.get[JdbcProfile].db

  override def get(): IEventReplicationRepository =
    new EventReplicationRepository(db)

}
