package com.exalate.replication.services.persistence

import com.exalate.api.persistence.replication.event.IEventWaitingForResponseRepository
import com.exalate.persistence.replication.event.state.WaitingForResponseSyncEventStateRepository
import com.google.inject.{Inject, Provider, Singleton}
import play.api.db.slick.DatabaseConfigProvider
import slick.jdbc.JdbcProfile
import slick.jdbc.JdbcBackend

import scala.concurrent.ExecutionContext

@Singleton
class EventWaitingForResponseRepositoryProvider @Inject() (
    dbConfigProvider: DatabaseConfigProvider
)(implicit ec: ExecutionContext)
    extends Provider[IEventWaitingForResponseRepository] {
  private val db: JdbcBackend#DatabaseDef = dbConfigProvider.get[JdbcProfile].db

  override def get(): IEventWaitingForResponseRepository =
    new WaitingForResponseSyncEventStateRepository(db)

}
