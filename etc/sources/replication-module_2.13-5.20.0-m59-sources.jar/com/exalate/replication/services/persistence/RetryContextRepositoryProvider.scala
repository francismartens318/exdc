package com.exalate.replication.services.persistence

import javax.inject.Inject
import com.exalate.api.persistence.retrycontext.IRetryContextRepository
import com.exalate.persistence.retrycontext.RetryContextRepository
import com.google.inject.{Provider, Singleton}
import play.api.db.slick.DatabaseConfigProvider
import slick.jdbc.JdbcProfile
import slick.jdbc.JdbcBackend

import scala.concurrent.ExecutionContext

@Singleton
class RetryContextRepositoryProvider @Inject() (dbConfigProvider: DatabaseConfigProvider)(implicit
    ec: ExecutionContext
) extends Provider[IRetryContextRepository] {
  private val db: JdbcBackend#DatabaseDef = dbConfigProvider.get[JdbcProfile].db

  override def get(): IRetryContextRepository =
    new RetryContextRepository(db)

}
