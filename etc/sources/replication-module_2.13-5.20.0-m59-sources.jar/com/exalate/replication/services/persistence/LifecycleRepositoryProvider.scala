package com.exalate.replication.services.persistence

import com.exalate.api.persistence.lifecycle.ILifecycleRepository
import com.exalate.persistence.lifecycle.LifecycleRepository
import com.google.inject.{Inject, Provider}
import play.api.db.slick.DatabaseConfigProvider
import slick.jdbc.{JdbcBackend, JdbcProfile}

import scala.concurrent.ExecutionContext

class LifecycleRepositoryProvider @Inject() (dbConfigProvider: DatabaseConfigProvider)(implicit
    ec: ExecutionContext
) extends Provider[ILifecycleRepository] {
  private val db: JdbcBackend#DatabaseDef = dbConfigProvider.get[JdbcProfile].db

  override def get(): ILifecycleRepository =
    new LifecycleRepository(db)

}
