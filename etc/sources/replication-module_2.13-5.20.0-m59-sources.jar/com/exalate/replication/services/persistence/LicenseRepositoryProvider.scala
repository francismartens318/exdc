package com.exalate.replication.services.persistence

import com.exalate.api.persistence.license.ILicenseRepository
import com.exalate.persistence.license.LicenseRepository
import com.google.inject.{Inject, Provider}
import play.api.db.slick.DatabaseConfigProvider
import slick.jdbc.{JdbcBackend, JdbcProfile}

import scala.concurrent.ExecutionContext

class LicenseRepositoryProvider @Inject() (dbConfigProvider: DatabaseConfigProvider)(implicit
    ec: ExecutionContext
) extends Provider[ILicenseRepository] {
  private val db: JdbcBackend#DatabaseDef = dbConfigProvider.get[JdbcProfile].db

  override def get(): ILicenseRepository =
    new LicenseRepository(db)

}
