package com.exalate.replication.services.persistence

import com.exalate.persistence.userproperties.UserPropertiesRepository
import com.google.inject.{Inject, Provider, Singleton}
import play.api.db.slick.DatabaseConfigProvider
import slick.jdbc.{JdbcBackend, JdbcProfile}

import scala.concurrent.ExecutionContext

@Singleton
class UserPropertiesRepositoryProvider @Inject() (dbConfigProvider: DatabaseConfigProvider)(implicit
    ec: ExecutionContext
) extends Provider[UserPropertiesRepository] {
  private val db: JdbcBackend#DatabaseDef = dbConfigProvider.get[JdbcProfile].db
  override def get(): UserPropertiesRepository = new UserPropertiesRepository(db)
}
