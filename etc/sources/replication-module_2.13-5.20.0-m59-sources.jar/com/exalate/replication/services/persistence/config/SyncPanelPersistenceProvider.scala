package com.exalate.replication.services.persistence.config

import com.exalate.api.persistence.config.ISyncPanelRepository
import com.exalate.persistence.config.SyncPanelRepository
import com.google.inject.{Inject, Provider}
import play.api.db.slick.DatabaseConfigProvider
import slick.jdbc.JdbcProfile
import slick.jdbc.JdbcBackend

import scala.concurrent.ExecutionContext

class SyncPanelRepositoryProvider @Inject() (dbConfigProvider: DatabaseConfigProvider)(implicit
    ec: ExecutionContext
) extends Provider[ISyncPanelRepository] {
  private val db: JdbcBackend#DatabaseDef = dbConfigProvider.get[JdbcProfile].db

  override def get(): ISyncPanelRepository =
    new SyncPanelRepository(db)

}
