package com.exalate.replication.services.persistence

import javax.inject.Inject
import com.exalate.api.persistence.relation.IRelationRepository
import com.exalate.persistence.CleanUpRepository
import com.exalate.persistence.connectiondraft.ConnectionDraftRepository
import com.exalate.persistence.issuetracker.IssueTrackerOptionRepository
import com.exalate.persistence.relation.RelationRepository
import com.exalate.services.api.ITrackerFieldValuesService
import com.google.inject.{Provider, Singleton}
import play.api.db.slick.DatabaseConfigProvider
import slick.jdbc.JdbcProfile
import slick.jdbc.JdbcBackend

import scala.concurrent.ExecutionContext

@Singleton
class RelationRepositoryProvider @Inject() (
    dbConfigProvider: DatabaseConfigProvider,
    trackerFieldValuesService: ITrackerFieldValuesService
)(implicit ec: ExecutionContext)
    extends Provider[IRelationRepository] {
  private val db: JdbcBackend#DatabaseDef = dbConfigProvider.get[JdbcProfile].db

  private val cleanUpRepository: CleanUpRepository =
    new CleanUpRepository(db, trackerFieldValuesService)

  private val connectionDraftRepository: ConnectionDraftRepository = new ConnectionDraftRepository(
    db
  )

  private val issueTrackerOptionRepository: IssueTrackerOptionRepository =
    new IssueTrackerOptionRepository(db)

  override def get(): IRelationRepository =
    new RelationRepository(
      db,
      cleanUpRepository,
      connectionDraftRepository,
      issueTrackerOptionRepository
    )

}
