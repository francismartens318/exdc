package com.exalate.replication.services.persistence

import com.exalate.api.persistence.replication.event.IEventScheduleRepository
import com.exalate.persistence.replication.event.EventScheduleRepository
import com.google.inject.{Inject, Provider, Singleton}
import play.api.db.slick.DatabaseConfigProvider
import slick.jdbc.JdbcProfile
import slick.jdbc.JdbcBackend

import scala.concurrent.ExecutionContext

@Singleton
class EventScheduleRepositoryProvider @Inject() (dbConfigProvider: DatabaseConfigProvider)(implicit
    ec: ExecutionContext
) extends Provider[IEventScheduleRepository] {
  private val db: JdbcBackend#DatabaseDef = dbConfigProvider.get[JdbcProfile].db

  override def get(): IEventScheduleRepository =
    new EventScheduleRepository(db)

}
