package com.exalate.replication.services.persistence

import com.exalate.api.persistence.auditlog.IAuditLogRepository
import com.exalate.persistence.auditlog.AuditLogRepository
import com.google.inject.Provider
import javax.inject.Inject
import play.api.db.slick.DatabaseConfigProvider
import slick.jdbc.{JdbcBackend, JdbcProfile}

import scala.concurrent.ExecutionContext

class AuditLogRepositoryProvider @Inject() (dbConfigProvider: DatabaseConfigProvider)(implicit
    ec: ExecutionContext
) extends Provider[IAuditLogRepository] {
  private val db: JdbcBackend#DatabaseDef = dbConfigProvider.get[JdbcProfile].db

  override def get(): IAuditLogRepository =
    new AuditLogRepository(db)

}
