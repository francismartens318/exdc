package com.exalate.replication.services.persistence

import com.exalate.api.persistence.replication.request.ICreateBlobSyncRequestStateRepository
import com.exalate.persistence.replication.request.state.CreateBlobSyncRequestStateRepository
import com.google.inject.{Inject, Provider, Singleton}
import play.api.db.slick.DatabaseConfigProvider
import slick.jdbc.JdbcProfile
import slick.jdbc.JdbcBackend

import scala.concurrent.ExecutionContext

@Singleton
class RequestCreateBlobRepositoryProvider @Inject() (dbConfigProvider: DatabaseConfigProvider)(
    implicit ec: ExecutionContext
) extends Provider[ICreateBlobSyncRequestStateRepository] {
  private val db: JdbcBackend#DatabaseDef = dbConfigProvider.get[JdbcProfile].db

  override def get(): ICreateBlobSyncRequestStateRepository =
    new CreateBlobSyncRequestStateRepository(db)

}
