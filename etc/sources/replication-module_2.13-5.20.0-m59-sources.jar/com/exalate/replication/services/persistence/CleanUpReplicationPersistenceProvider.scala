package com.exalate.replication.services.persistence

import com.exalate.api.persistence.replication.cleanup.ICleanUpReplicationRepository
import com.exalate.persistence.replication.cleanup.CleanUpReplicationRepository
import com.google.inject.Provider
import javax.inject.Inject
import play.api.db.slick.DatabaseConfigProvider
import slick.jdbc.{JdbcBackend, JdbcProfile}

import scala.concurrent.ExecutionContext

class CleanUpReplicationRepositoryProvider @Inject() (dbConfigProvider: DatabaseConfigProvider)(
    implicit ec: ExecutionContext
) extends Provider[ICleanUpReplicationRepository] {
  private val db: JdbcBackend#DatabaseDef = dbConfigProvider.get[JdbcProfile].db

  override def get(): ICleanUpReplicationRepository =
    new CleanUpReplicationRepository(db)

}
