package com.exalate.replication.services.persistence

import com.exalate.api.persistence.oauth.IOAuthClientRepository
import com.exalate.persistence.oauth.OAuthClientRepository
import com.google.inject.Provider
import javax.inject.Inject
import play.api.db.slick.DatabaseConfigProvider
import slick.jdbc.{JdbcBackend, JdbcProfile}

import scala.concurrent.ExecutionContext

class OAuthClientRepositoryProvider @Inject() (dbConfigProvider: DatabaseConfigProvider)(implicit
    val executionContext: ExecutionContext
) extends Provider[IOAuthClientRepository] {
  private val db: JdbcBackend#DatabaseDef = dbConfigProvider.get[JdbcProfile].db

  override def get(): IOAuthClientRepository =
    new OAuthClientRepository(db)

}
