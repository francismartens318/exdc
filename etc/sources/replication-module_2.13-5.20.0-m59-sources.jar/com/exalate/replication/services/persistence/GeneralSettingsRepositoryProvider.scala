package com.exalate.replication.services.persistence

import com.exalate.api.persistence.issuetracker.IGeneralSettingsRepository
import com.exalate.persistence.cache.{
  CachedGeneralSettingsRepository,
  GeneralSettingsRepositoryCacheConfigProvider
}
import com.exalate.persistence.issuetracker.GeneralSettingsRepository
import com.google.inject.Provider

import javax.inject.Inject
import play.api.db.slick.DatabaseConfigProvider
import slick.jdbc.{JdbcBackend, JdbcProfile}

import scala.concurrent.ExecutionContext

class GeneralSettingsRepositoryProvider @Inject() (
    dbConfigProvider: DatabaseConfigProvider,
    cacheConfigProvider: GeneralSettingsRepositoryCacheConfigProvider
)(implicit ec: ExecutionContext)
    extends Provider[IGeneralSettingsRepository] {
  private val db: JdbcBackend#DatabaseDef = dbConfigProvider.get[JdbcProfile].db

  override def get(): IGeneralSettingsRepository = {
    val cacheConfig = cacheConfigProvider.get()
    val generalSettingsRepository = new GeneralSettingsRepository(db)
    new CachedGeneralSettingsRepository(generalSettingsRepository, cacheConfig)
  }

}
