package com.exalate.replication.services.persistence

import com.exalate.api.persistence.message.IMessageQueueRepository
import com.exalate.persistence.message.MessageQueueRepository
import com.google.inject.{Provider, Singleton}
import javax.inject.Inject
import play.api.db.slick.DatabaseConfigProvider
import slick.jdbc.{JdbcBackend, JdbcProfile}

import scala.concurrent.ExecutionContext

@Singleton
class MessageQueueRepositoryProvider @Inject() (dbConfigProvider: DatabaseConfigProvider)(implicit
    ec: ExecutionContext
) extends Provider[IMessageQueueRepository] {
  private val db: JdbcBackend#DatabaseDef = dbConfigProvider.get[JdbcProfile].db

  override def get(): IMessageQueueRepository =
    new MessageQueueRepository(db)

}
