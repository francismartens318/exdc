package com.exalate.replication.services.persistence

import com.exalate.api.persistence.connectiondraft.IConnectionDraftRepository
import com.exalate.persistence.connectiondraft.ConnectionDraftRepository
import com.google.inject.{Inject, Provider, Singleton}
import play.api.db.slick.DatabaseConfigProvider
import slick.jdbc.{JdbcBackend, JdbcProfile}

import scala.concurrent.ExecutionContext

@Singleton
class ConnectionDraftRepositoryProvider @Inject() (dbConfigProvider: DatabaseConfigProvider)(
    implicit ec: ExecutionContext
) extends Provider[IConnectionDraftRepository] {
  private val db: JdbcBackend#DatabaseDef = dbConfigProvider.get[JdbcProfile].db
  override def get(): IConnectionDraftRepository = new ConnectionDraftRepository(db)
}
