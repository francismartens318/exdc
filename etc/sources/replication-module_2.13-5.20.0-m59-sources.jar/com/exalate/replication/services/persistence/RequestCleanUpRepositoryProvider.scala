package com.exalate.replication.services.persistence

import com.exalate.api.persistence.replication.request.IRequestCleanUpRepository
import com.exalate.persistence.replication.request.RequestCleanUpRepository
import com.google.inject.{Inject, Provider, Singleton}
import play.api.db.slick.DatabaseConfigProvider
import slick.jdbc.JdbcProfile
import slick.jdbc.JdbcBackend

import scala.concurrent.ExecutionContext

@Singleton
class RequestCleanUpRepositoryProvider @Inject() (dbConfigProvider: DatabaseConfigProvider)(implicit
    ec: ExecutionContext
) extends Provider[IRequestCleanUpRepository] {
  private val db: JdbcBackend#DatabaseDef = dbConfigProvider.get[JdbcProfile].db

  override def get(): IRequestCleanUpRepository =
    new RequestCleanUpRepository(db)

}
