package com.exalate.replication.services.persistence

import com.exalate.api.persistence.ai.IAISettingsRepository
import com.exalate.persistence.ai.AISettingsRepository
import com.google.inject.{Provider, Singleton}
import play.api.db.slick.DatabaseConfigProvider
import slick.jdbc.{JdbcBackend, JdbcProfile}

import javax.inject.Inject
import scala.concurrent.ExecutionContext

@Singleton
class AISettingsRepositoryProvider @Inject() (dbConfigProvider: DatabaseConfigProvider)(implicit
    ec: ExecutionContext
) extends Provider[IAISettingsRepository] {
  private val db: JdbcBackend#DatabaseDef = dbConfigProvider.get[JdbcProfile].db

  override def get(): IAISettingsRepository =
    new AISettingsRepository(db)

}
