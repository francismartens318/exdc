package com.exalate.replication.services.persistence.jcloud

import javax.inject.Inject
import com.exalate.api.persistence.jcloud.IMigrationRepository
import com.exalate.persistence.lifecycle.migration.gdpr.IMigrationHelper
import com.exalate.persistence.migration.CloudMigrationRepository
import com.google.inject.Provider
import play.api.db.evolutions.ApplicationEvolutions
import play.api.db.slick.DatabaseConfigProvider
import slick.jdbc.JdbcProfile
import slick.jdbc.JdbcBackend

import scala.concurrent.ExecutionContext

// Parameter "applicationEvolutions" was intentionally added to constructor to ensure the ApplicationEvolutions is initialized before the IMigrationRepository
// to avoid errors caused by incorrect initialization order, like this one:
// [Guice/ErrorInjectingConstructor]: PersistenceBugException: Unexpected error occurred. ERROR: relation "lifecycle_info" does not exist
class CloudMigrationRepositoryProvider @Inject() (
    dbConfigProvider: DatabaseConfigProvider,
    migrationHelper: IMigrationHelper,
    applicationEvolutions: ApplicationEvolutions
)(implicit ec: ExecutionContext)
    extends Provider[IMigrationRepository] {
  private val db: JdbcBackend#DatabaseDef = dbConfigProvider.get[JdbcProfile].db

  override def get(): IMigrationRepository =
    new CloudMigrationRepository(db, migrationHelper)

}
