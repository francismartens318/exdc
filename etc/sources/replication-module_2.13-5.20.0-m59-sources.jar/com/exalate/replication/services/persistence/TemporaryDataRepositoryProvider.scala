package com.exalate.replication.services.persistence

import com.exalate.api.persistence.invitation.ITemporaryDataRepository
import com.exalate.persistence.temporarydata.TemporaryDataRepository
import com.google.inject.{Provider, Singleton}
import play.api.db.slick.DatabaseConfigProvider
import slick.jdbc.{JdbcBackend, JdbcProfile}

import scala.concurrent.ExecutionContext
import javax.inject.Inject

@Singleton
class TemporaryDataRepositoryProvider @Inject() (dbConfigProvider: DatabaseConfigProvider)(implicit
    ec: ExecutionContext
) extends Provider[ITemporaryDataRepository] {
  private val db: JdbcBackend#DatabaseDef = dbConfigProvider.get[JdbcProfile].db

  override def get(): ITemporaryDataRepository =
    new TemporaryDataRepository(db)

}
