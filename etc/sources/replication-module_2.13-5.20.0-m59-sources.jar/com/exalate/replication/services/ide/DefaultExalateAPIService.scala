package com.exalate.replication.services.ide

import com.exalate.api.domain.{IBlobMetadata, IIssueKey}
import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.hubobject.IHubIssueReplica
import com.exalate.api.domain.request.ISyncRequest
import com.exalate.api.domain.twintrace.INonPersistentTrace
import com.exalate.api.hubobject.jira._
import com.exalate.domain.values.ide.SuggestionValue
import com.exalate.replication.services.api.ide._
import com.exalate.replication.services.ide.DefaultExalateAPIService.{
  appendVariableEntityBeforeScript,
  appendVariablePrevious,
  suggestions
}
import com.exalate.replication.services.processor.SyncHelper
import org.slf4j.Logger

import java.util
import javax.inject.Inject
import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

/** Builds list of suggestions for Exalate APIs
  *
  * @param entityPublicAPIService
  *   per tracker implementation to provide suggestion for `entity`
  * @param replicaPublicAPIService
  *   per tracker implementation to provide suggestion for `replica`
  * @param nodeHelperPublicAPIService
  *   per tracker implementation to provide suggestion for `nodeHelper`
  * @param attachmentHelperPublicAPIService
  *   per tracker implementation to provide suggestion for `attachmentHelper`
  * @param workFlowHelperPublicAPIService
  *   per tracker implementation to provide suggestion for `workFlow`
  * @param workLogHelperPublicAPIService
  *   per tracker implementation to provide suggestion for `workLog`
  */
class DefaultExalateAPIService @Inject() (
    entityPublicAPIService: IEntityPublicAPIService,
    replicaPublicAPIService: IReplicaPublicAPIService,
    nodeHelperPublicAPIService: INodeHelperPublicAPIService,
    attachmentHelperPublicAPIService: IAttachmentHelperPublicAPIService,
    workFlowHelperPublicAPIService: IWorkFlowHelperPublicAPIService,
    workLogHelperPublicAPIService: IWorkLogHelperPublicAPIService
) extends IExalateAPIService {

  override lazy val apis: Future[Seq[SuggestionValue]] =
    for {
      entitySuggestions <- entityPublicAPIService.apis
      replicaSuggestions <- replicaPublicAPIService.apis
      nodeHelperSuggestions <- nodeHelperPublicAPIService.apis
      attachmentHelperSuggestions <- attachmentHelperPublicAPIService.apis
      workFlowHelperSuggestions <- workFlowHelperPublicAPIService.apis
      workLogHelperSuggestions <- workLogHelperPublicAPIService.apis
    } yield
    //      val updatedEntitySuggestions = appendVariableEntityBeforeScript(entitySuggestions)
//      val updatedReplicaSuggestions = appendVariablePrevious(replicaSuggestions)

    entitySuggestions ++
      replicaSuggestions ++
      nodeHelperSuggestions ++
      attachmentHelperSuggestions ++
      workFlowHelperSuggestions ++
      workLogHelperSuggestions ++
      suggestions

}

object DefaultExalateAPIService {
  import IExalateAPIService._

  lazy val suggestions: Seq[SuggestionValue] = List(
    debugHelperSuggestion,
    commentHelperSuggestion,
    syncHelperSuggestion,
    logSuggestion,
    tracesSuggestion,
    firstSyncSuggestion,
    connectionSuggestion,
    syncRequestSuggestion,
    issueToBeCreatedSuggestion,
    stringSuggestion,
    seqHubIssueReplicaSuggestion,
    seqBlobMetadataSuggestion,
    issueKeySuggestion
  )

  private lazy val debugHelperSuggestion: SuggestionValue =
    SuggestionValue.renderSimple(
      variables = List("debug"),
      accessor = None,
      items = publicMethods[IDebugHelper]
    )

  private lazy val commentHelperSuggestion: SuggestionValue =
    SuggestionValue.renderSimple(
      variables = List("commentHelper"),
      accessor = None,
      items = publicMethods[ICommentHelper]
    )

  private lazy val syncHelperSuggestion: SuggestionValue =
    SuggestionValue.renderSimple(
      variables = List("syncHelper"),
      accessor = None,
      items = publicMethods[SyncHelper]
    )

  private lazy val logSuggestion: SuggestionValue =
    SuggestionValue.renderSimple(
      variables = List("log"),
      accessor = None,
      items = publicMethods[Logger]
    )

  private lazy val tracesSuggestion: SuggestionValue =
    SuggestionValue.renderSimple(
      variables = List("traces"),
      accessor = None,
      items = publicMethods[util.ArrayList[INonPersistentTrace]]
    )

  private lazy val firstSyncSuggestion: SuggestionValue =
    SuggestionValue.renderSimple(
      variables = List("firstSync"),
      accessor = None,
      items = Nil
    )

  private lazy val connectionSuggestion: SuggestionValue =
    SuggestionValue.renderSimple(
      variables = List("connection", "relation"),
      accessor = None,
      items = publicMethods[IConnection]
    )

  private lazy val syncRequestSuggestion: SuggestionValue =
    SuggestionValue.renderSimple(
      variables = List("syncRequest"),
      accessor = None,
      items = publicMethods[ISyncRequest]
    )

  private lazy val issueToBeCreatedSuggestion: SuggestionValue =
    SuggestionValue.renderSimple(
      variables = List("issueToBeCreated"),
      accessor = None,
      items = Nil
    )

  private lazy val stringSuggestion: SuggestionValue =
    SuggestionValue.renderSimple(
      variables = List("entityType", "remoteEntityType", "remoteIssueUrl", "issueUrl"),
      accessor = None,
      items = publicMethods[String]
    )

  private lazy val seqHubIssueReplicaSuggestion: SuggestionValue =
    SuggestionValue.renderSimple(
      variables = List("entities", "entitiesBeforeUpdating"),
      accessor = None,
      items = publicMethods[Seq[IHubIssueReplica]]
    )

  private lazy val seqBlobMetadataSuggestion: SuggestionValue =
    SuggestionValue.renderSimple(
      variables = List("blobMetadataSeq"),
      accessor = None,
      items = publicMethods[Seq[IBlobMetadata]]
    )

  private lazy val issueKeySuggestion: SuggestionValue =
    SuggestionValue.renderSimple(
      variables = List("issueKey"),
      accessor = None,
      items = publicMethods[IIssueKey]
    )

  private val appendVariableEntityBeforeScript = appendVariable("entityBeforeScript") _
  private val appendVariablePrevious = appendVariable("previous") _

  def appendVariable(variable: String)(
      suggestions: Seq[SuggestionValue]
  ): Seq[SuggestionValue] =
    suggestions.map(s => s.copy(variables = s.variables.appended(variable)))

}
