package com.exalate.replication.services.ide

import com.exalate.domain.values.ide.SuggestionValue
import com.exalate.replication.services.api.ide.IWorkFlowHelperPublicAPIService

import scala.concurrent.Future

/** workflow helper is only available for jcloud
  */
class DefaultWorkFlowHelperPublicAPIService extends IWorkFlowHelperPublicAPIService {

  override def apis: Future[Seq[SuggestionValue]] = Future.successful(Nil)

}
