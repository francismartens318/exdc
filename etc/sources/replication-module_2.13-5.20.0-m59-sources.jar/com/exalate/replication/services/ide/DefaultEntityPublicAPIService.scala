package com.exalate.replication.services.ide

import com.exalate.domain.values.ide.{SuggestionItem, SuggestionValue}
import com.exalate.replication.services.api.ide.IEntityPublicAPIService
import com.exalate.replication.services.ide.DefaultEntityPublicAPIService.publicFields

import scala.concurrent.Future

class DefaultEntityPublicAPIService extends IEntityPublicAPIService {

  override def apis: Future[Seq[SuggestionValue]] = Future.successful(
    List(
      SuggestionValue.renderSimple(
        variables = List("entity", "entityBeforeScript"),
        accessor = None,
        items = publicFields
      )
    )
  )

}

object DefaultEntityPublicAPIService {

  lazy val publicFields: Seq[SuggestionItem] = List(
    SuggestionItem("assignee"),
    SuggestionItem("attachments"),
    SuggestionItem("comments"),
    SuggestionItem("customFields"),
    SuggestionItem("description"),
    SuggestionItem("key"),
    SuggestionItem("project"),
    SuggestionItem("projectKey"),
    SuggestionItem("reporter"),
    SuggestionItem("resolution"),
    SuggestionItem("status"),
    SuggestionItem("summary"),
    SuggestionItem("typeName")
  )

}
