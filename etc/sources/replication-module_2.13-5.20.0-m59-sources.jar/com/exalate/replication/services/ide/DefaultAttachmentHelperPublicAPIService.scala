package com.exalate.replication.services.ide

import com.exalate.api.hubobject.jira.IAttachmentHelper
import com.exalate.domain.values.ide.SuggestionValue
import com.exalate.replication.services.api.ide.IAttachmentHelperPublicAPIService
import com.exalate.replication.services.api.ide.IExalateAPIService.publicMethods

import scala.concurrent.Future

class DefaultAttachmentHelperPublicAPIService extends IAttachmentHelperPublicAPIService {

  override def apis: Future[Seq[SuggestionValue]] = Future.successful(
    List(
      SuggestionValue.renderSimple(
        variables = List("attachmentHelper"),
        accessor = None,
        items = publicMethods[IAttachmentHelper]
      )
    )
  )

}
