package com.exalate.replication.services.ide

import com.exalate.domain.values.ide.{SuggestionItem, SuggestionValue}
import com.exalate.replication.services.api.ide.IReplicaPublicAPIService
import com.exalate.replication.services.ide.DefaultReplicaPublicAPIService.publicFields

import scala.concurrent.Future

class DefaultReplicaPublicAPIService extends IReplicaPublicAPIService {

  override def apis: Future[Seq[SuggestionValue]] = Future.successful(
    List(SuggestionValue.renderSimple(List("replica", "previous"), None, publicFields))
  )

}

object DefaultReplicaPublicAPIService {

  lazy val publicFields: Seq[SuggestionItem] = List(
    SuggestionItem("assignee"),
    SuggestionItem("attachments"),
    SuggestionItem("comments"),
    SuggestionItem("customFields"),
    SuggestionItem("description"),
    SuggestionItem("key"),
    SuggestionItem("labels"),
    SuggestionItem("parentId"),
    SuggestionItem("priority"),
    SuggestionItem("project"),
    SuggestionItem("reporter"),
    SuggestionItem("resolution"),
    SuggestionItem("status"),
    SuggestionItem("summary"),
    SuggestionItem("type")
  )

}
