package com.exalate.replication.services.ide

import com.exalate.replication.services.api.ide.IGroovyLspService
import play.api.mvc.{Results, WebSocket}

import javax.inject.Inject
import scala.concurrent.Future

class NotSupportedGroovyLspService @Inject() extends IGroovyLspService {

  override def webSocket: WebSocket = WebSocket { _ =>
    Future.successful(Left(Results.NotImplemented))
  }

}
