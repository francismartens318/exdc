package com.exalate.replication.services.ide

import com.exalate.domain.values.ide.SuggestionValue
import com.exalate.replication.services.api.ide.INodeHelperPublicAPIService

import scala.concurrent.Future

class DefaultNodeHelperPublicAPIService extends INodeHelperPublicAPIService {

  // a class in question will have methods annotated with `ExalatePublicAPi` to be included in the suggestions.
  // since all cloud nodes have their own implementation, we are returning empty suggestion in this default
  // implementation as to not expose any method accidentally.
  override def apis: Future[Seq[SuggestionValue]] = Future.successful(Nil)

}
