package com.exalate.replication.services.ide

import com.exalate.domain.values.ide.SuggestionValue
import com.exalate.replication.services.api.ide.{ICodeCompletionService, IExalateAPIService}

import javax.inject.Inject
import scala.concurrent.Future

class DefaultCodeCompletionService @Inject() (exalateApiService: IExalateAPIService)
    extends ICodeCompletionService {

  override def suggestions: Future[Seq[SuggestionValue]] =
    exalateApiService.apis

}
