package com.exalate.replication.services.ide

import com.exalate.domain.values.ide.SuggestionValue
import com.exalate.replication.services.api.ide.IWorkLogHelperPublicAPIService

import scala.concurrent.Future

/** worklog helper is only available for jcloud
  */
class DefaultWorkLogHelperPublicAPIService extends IWorkLogHelperPublicAPIService {

  override def apis: Future[Seq[SuggestionValue]] = Future.successful(Nil)

}
