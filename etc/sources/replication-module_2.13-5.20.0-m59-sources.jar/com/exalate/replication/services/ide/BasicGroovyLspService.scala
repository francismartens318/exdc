package com.exalate.replication.services.ide

import akka.actor.ActorSystem
import akka.stream.Materializer
import com.exalate.replication.services.api.ide.IGroovyLspService
import play.api.Configuration
import play.api.mvc.{Results, WebSocket}

import javax.inject.Inject
import scala.concurrent.duration.FiniteDuration
import scala.concurrent.Future

class BasicGroovyLspService @Inject() (configuration: Configuration)(implicit
    system: ActorSystem,
    mat: Materializer
) extends IGroovyLspService {

  private val interval: FiniteDuration =
    configuration.get[FiniteDuration]("com.exalate.websocket.ping-interval")

  // TODO: add request authentication?
  // TODO
  //  We are not using IDE/LSP on this release so we are going to mute it to
  //  avoid having different groovy versions as dependencies.
  override def webSocket: WebSocket = WebSocket { _ =>
    Future.successful(Left(Results.NotImplemented))
  }
  /*WebSocket.accept { _ =>
    ActorFlow.actorRef { out =>
      Props(new GroovyLanguageServerWebSocket(out, interval))
    }
  }*/

}
