package com.exalate.replication.services.syncroom

import cats.implicits._
import com.exalate.api.domain.IIssueKey
import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.trigger.{ITrigger, TriggerStatus}
import com.exalate.api.persistence.error.IErrorRepository
import com.exalate.api.persistence.relation.IRelationRepository
import com.exalate.api.persistence.replication.blobevent.IBlobEventReplicationRepository
import com.exalate.api.persistence.replication.event.IEventReplicationRepository
import com.exalate.api.persistence.replication.request.IRequestReplicationRepository
import com.exalate.api.persistence.trigger.ITriggerRepository
import com.exalate.api.persistence.twintrace.ITwinTraceRepository
import com.exalate.basic.domain.NonPersistentConnectContext
import com.exalate.basic.domain.hubobject.v1.{BasicHubIssue, UpdateBasicHubIssue}
import com.exalate.basic.domain.trigger.NonPersistentTrigger
import com.exalate.domain.exception.issuetracker.{
  InternalServerErrorTrackerRestException,
  NotFoundTrackerRestException
}
import com.exalate.domain.values.syncroom._
import com.exalate.domain.values.{EntityTypeValue, PageRequest}
import com.exalate.generic.services.api.{IIssueTrackerSearchService, ITrackerHubObjectService}
import com.exalate.persistence.domain.v1.relation.SyncRoomData
import com.exalate.replication.controllers.services.NodeInfoControllerService
import com.exalate.replication.services.api.config.{IConnectionService, ISyncStatusService, Public}
import com.exalate.replication.services.api.replication.IEventSchedulerNotificationService
import com.exalate.replication.services.api.trigger.ITriggerService
import com.exalate.replication.services.syncroom.SyncRoomService.toNonPersistenceTrigger
import com.exalate.replication.services.utils.{DomainToValueUtils, EntityError}
import com.exalate.util.UrlUtils
import com.google.inject.Inject
import play.api.Logger
import play.api.libs.json.Json

import java.util.Collections
import scala.concurrent.{ExecutionContext, Future}
import scala.util.Try

//noinspection AccessorLikeMethodIsEmptyParen
class SyncRoomService @Inject() (
    connectionService: IConnectionService,
    nodeInfoControllerService: NodeInfoControllerService,
    connectionRepository: IRelationRepository,
    triggerRepository: ITriggerRepository,
    errorRepository: IErrorRepository,
    triggerService: ITriggerService,
    trackerHubObjectService: ITrackerHubObjectService,
    testRunScript: TestRunScript,
    trackerSearchService: IIssueTrackerSearchService,
    eventReplicationRepository: IEventReplicationRepository,
    requestReplicationRepository: IRequestReplicationRepository,
    blobEventReplicationRepository: IBlobEventReplicationRepository,
    syncStatusService: ISyncStatusService,
    twinTraceRepository: ITwinTraceRepository,
    schedulerService: IEventSchedulerNotificationService
)(implicit
    val ec: ExecutionContext
) {
  private val LOG = Logger(classOf[SyncRoomService])

  def getEntitySyncStatus(entityUrn: String, entityType: String): Future[EntitySyncStatusData] =
    (
      trackerHubObjectService.getEntityUrl(entityUrn, None, Some(entityType)),
      syncStatusService.getSyncStatusesByIssueUrn(Map.empty, entityUrn, entityType)
    ).mapN {
      case (issueTrackerUrlOpt, syncStatusesBeanOpt) =>
        syncStatusesBeanOpt.fold(EntitySyncStatusData(entityExists = false)) { syncStatusesBean =>
          EntitySyncStatusData(
            entityExists = true,
            localEntitySyncStatus = Option(
              EntitySyncStatus(
                issueUrn = entityUrn,
                url = issueTrackerUrlOpt.getOrElse("No Url"),
                summary = syncStatusesBean.syncStatuses
                  .flatMap(_.localEntitySummary)
                  .headOption
                  .getOrElse("No Summary")
              )
            ),
            statuses = Option(syncStatusesBean.syncStatuses.map { syncStatus =>
              StatusData(
                connectionId = syncStatus.connectionId,
                status = syncStatus.status.name(),
                twinTraceId = syncStatus.twinTraceId,
                remoteEntitySyncStatus = syncStatus.remoteIssueContext match {
                  case Public(Some(urlContext)) =>
                    Some(
                      EntitySyncStatus(
                        issueUrn = urlContext.getIssueUrn,
                        url = urlContext.getRemoteIssueUrl,
                        summary = urlContext.getTrimmedSummary
                      )
                    )
                  case _                        => None
                }
              )
            }.toSeq)
          )
        }
    }

  def getEntitySyncStatusReplicas(twinTraceId: Int): Future[Replicas] =
    twinTraceRepository
      .getTwinTraceById(twinTraceId)
      .map(getOrNotFoundError(_, s"Couldn't find a twin trace with id `$twinTraceId`"))
      .map { twinTrace =>
        val localReplicaJson =
          (Json.parse(twinTrace.getLocalReplica.getPayload) \ "hubIssue").get.toString
        val remoteReplicaJson = Option(twinTrace.getRemoteReplica)
          .map(replica => (Json.parse(replica.getPayload) \ "hubIssue").get.toString)
        Replicas(localReplicaJson, remoteReplicaJson)
      }

  def getNodeInfo: Future[NodeInfoForSyncRoom] =
    nodeInfoControllerService.getSelfNodeInfo
      .map { nodeInfo =>
        val nodeType = nodeInfo.nodeType
        val exalateUrl = nodeInfo.baseUrl.getOrElse("No base url")
        val issueTrackerUrl = nodeInfo.issueTrackerUrl.getOrElse("No issueTrackerUrl")
        NodeInfoForSyncRoom(
          nodeInfo.instanceUid.getOrElse("No instanceUid"),
          exalateUrl,
          nodeInfo.name,
          issueTrackerUrl,
          getAdminUrl(nodeType, issueTrackerUrl, exalateUrl),
          nodeType,
          nodeInfo.nodeVersion,
          nodeInfo.rawExaCompVersion.getOrElse("No info about raw node version")
        )
      }
      .recoverWith {
        case e: Exception =>
          LOG.error("Exception while getting node info for Sync Room", e)
          Future.failed(new InternalServerErrorTrackerRestException(ErrorKey.UNKNOWN.toString))
      }

  def getConnections(): Future[Seq[Connection]] =
    connectionService
      .findAllSimplified()
      .map(_._1.map(Connection.apply))
      .recoverWith {
        case e =>
          LOG.error("Exception while getting connections", e)
          Future.failed(new InternalServerErrorTrackerRestException(ErrorKey.UNKNOWN.toString))
      }

  def getTriggersByConnectionId(connectionId: Int): Future[Seq[Trigger]] =
    getConnectionOrFail(connectionId, Some(ErrorKey.ENTITY_NOT_FOUND.toString))
      .flatMap { _ =>
        triggerRepository
          .getTriggerByRelationId(connectionId)
          .map(_.map(Trigger(_)))
      }
      .recoverWith {
        case e: NotFoundTrackerRestException =>
          Future.failed(e)
        case e: Exception                    =>
          LOG.error(
            f"Exception while getting triggers for connection $connectionId for Sync Room",
            e
          )
          Future.failed(new InternalServerErrorTrackerRestException(ErrorKey.UNKNOWN.toString))
      }

  def createTrigger(connectionId: Int, trigger: TriggerRequest): Future[Trigger] =
    getConnectionOrFail(connectionId)
      .flatMap { connection =>
        val nonPersistentTrigger = toNonPersistenceTrigger(connection, trigger)

        triggerRepository
          .create(nonPersistentTrigger)
          .map(Trigger(_))
      }

  def updateTrigger(
      connectionId: Int,
      triggerId: Int,
      trigger: TriggerRequest
  ): Future[Trigger] = {

    def updateTrigger(connection: IConnection): Future[Trigger] =
      triggerRepository
        .update(triggerId, toNonPersistenceTrigger(connection, trigger))
        .map(getOrNotFoundError(_, s"Couldn't find a trigger with id `$triggerId`"))
        .map(Trigger(_))

    getConnectionOrFail(connectionId).flatMap(updateTrigger)
  }

  def validateTrigger(connectionId: Int, trigger: TriggerRequest): Future[TriggerValidationResult] =
    getConnectionOrFail(connectionId)
      .flatMap(connection =>
        trackerSearchService
          .getEntityCountUnderSearchQuery(trigger.query, connection, trigger.entityType, Map.empty)
          .map(result =>
            TriggerValidationResult(
              isValid = true,
              result,
              None
            )
          )
          .recover {
            case e =>
              TriggerValidationResult(
                isValid = false,
                0,
                Option(s"Provided query is invalid, error: ${e.getMessage}")
              )
          }
      )

  private def getAdminUrl(nodeType: String, instanceUrl: String, exalateUrl: String): String =
    nodeType match {
      case "JIRA_CLOUD" =>
        UrlUtils.concat(instanceUrl, "/plugins/servlet/ac/com.exalate.jiranode/general-item")
      case "ZENDESK"    =>
        UrlUtils.concat(instanceUrl, "/agent/apps/exalate/generalsettings")
      case "SALESFORCE" =>
        UrlUtils.concat(instanceUrl, "/lightning/n/exalate2__Console")
      case _            =>
        UrlUtils.concat(exalateUrl, "/generalsettings")
    }

  def getScriptsForConnectionId(connectionId: Int): Future[Seq[Script]] =
    getConnectionOrFail(
      connectionId,
      Some(s"Script no available for connection Id $connectionId")
    )
      .flatMap { connection =>
        Future.successful(
          Seq(
            Script(connection.getDataFilter, ScriptsDirection.OUTGOING),
            Script(connection.getIncomingProcessor, ScriptsDirection.INCOMING)
          )
        )
      }

  def updateScriptsForConnection(connectionId: Int, scripts: Seq[Script]): Future[Seq[Script]] =
    getConnectionOrFail(connectionId)
      .flatMap(_ => connectionRepository.updateConnectionScripts(connectionId, scripts))

  def getErrors(offset: Option[Int], limit: Option[Int]): Future[PaginatedResult[NodeError]] =
    errorRepository
      .findAllPaginated(pageRequest = PageRequest(offset = offset, limit = limit))
      .map { pageResult =>
        val nodeErrors: Seq[NodeError] = pageResult.results.map(NodeError(_))
        PaginatedResult(
          total = pageResult.total,
          results = nodeErrors,
          offset = offset,
          limit = limit
        )
      }
      .recoverWith {
        case e: Exception =>
          LOG.error("Exception while getting Errors for Sync Room", e)
          Future.failed(new InternalServerErrorTrackerRestException(ErrorKey.UNKNOWN.toString))
      }

  def updateConnection(connectionId: Int, connectionData: ConnectionRequest): Future[Connection] =
    getConnectionOrFail(connectionId) flatMap { _ =>
      connectionRepository.updateConnectionData(connectionId, connectionData).map(Connection.apply)
    }

  def updateManageConnection(
      connectionId: Int,
      syncRoomData: SyncRoomData,
      syncRoomId: Option[String]
  ): Future[Boolean] =
    connectionRepository.updateManageConnection(
      connectionId,
      syncRoomData.managedRemotely,
      syncRoomData.managedBy,
      syncRoomId
    )

  def deleteTrigger(triggerId: Int, connectionId: Int): Future[None.type] =
    getConnectionOrFail(connectionId)
      .flatMap(_ => triggerRepository.delete(triggerId))

  def bulkExalate(triggerId: Int, connectionId: Int): Future[None.type] = {
    val message =
      s"Received a message to perform bulk exalate with trigger `$triggerId` for connection with id `$connectionId`."
    triggerBulkAction(triggerId, connectionId, message, triggerService.executeTriggerForIssueKeys)
  }

  def bulkUnexalate(triggerId: Int, connectionId: Int): Future[None.type] = {
    val message =
      s"Received a message to perform bulk unexalate with trigger `$triggerId` for connection with id `$connectionId`."
    triggerBulkAction(triggerId, connectionId, message, triggerService.executeUnexalateForIssueKeys)
  }

  def getIssuesUnderTrigger(triggerId: Int): Future[Seq[String]] =
    triggerRepository
      .get(triggerId)
      .map(getOrNotFoundError(_, s"Couldn't find a trigger with id `$triggerId`"))
      .flatMap { trigger =>
        triggerService
          .getIssueKeysUnderTrigger(trigger)
          .map(_.map(issueKey => issueKey.getURN))
          .recoverWith {
            case e: Exception =>
              val message = s"Exception while getting issue under the trigger `$triggerId`."
              LOG.error(message, e)
              Future.failed(new InternalServerErrorTrackerRestException(message))
          }
      }

  def getSupportedEntityTypes(): Future[Seq[EntityTypeValue]] =
    trackerHubObjectService
      .getSupportedEntityTypes()
      .map(
        _.map(e =>
          EntityTypeValue(e.name, e.queryLanguageSupported, Some(e.label), e.allowEmptyQuery)
        )
      )

  private def triggerBulkAction(
      triggerId: Int,
      connectionId: Int,
      message: String,
      bulkAction: (ITrigger, Seq[IIssueKey]) => Unit
  ): Future[None.type] = {
    val connectionF = getConnectionOrFail(connectionId)
    val triggerF = triggerRepository
      .get(triggerId)
      .map(getOrNotFoundError(_, s"Couldn't find a trigger with id `$triggerId`", Some(message)))
    (connectionF, triggerF).flatMapN {
      case (_, trigger) =>
        triggerService
          .getIssueKeysUnderTrigger(trigger)
          .map { issueKeys =>
            bulkAction(trigger, issueKeys)
          }
          .map(_ => None)
    }
  }

  def validateScript(script: Script): Try[None.type] =
    connectionService.validateScripts(script.script, "SyncRoomScript")

  def searchEntities(
      connectionId: Int,
      entityType: String,
      search: String,
      triggerQuery: Option[String],
      limit: Int
  ): Future[Seq[Issue]] =
    getConnectionOrFail(connectionId).flatMap { connection =>
      trackerSearchService
        .searchEntities(connection, entityType, search, triggerQuery, limit)
        .map(
          _.map(i =>
            Issue(
              id = i.id,
              entityType = entityType,
              issueUrn = i.urn,
              `type` = i.issueType,
              summary = i.title
            )
          )
        )
        .recoverWith { e =>
          LOG.error(s"Failed to fetch issues. Connection `$connectionId`, search: `$search`", e)
          Future.failed(
            new InternalServerErrorTrackerRestException("An exception while fetching issues")
          )
        }
    }

  def testRunOutgoing(
      connectionId: Int,
      testRunOutgoingData: TestRunOutgoingData
  ): Future[Seq[TestRunOutgoingResponse]] =
    testRunScript.createOutgoingReplica(connectionId, testRunOutgoingData)

  private def getConnectionOrFail(
      connectionId: Int,
      message: Option[String] = None
  ): Future[IConnection] = connectionService
    .get(connectionId)
    .map(getOrNotFoundError(_, message.getOrElse(s"Couldn't find a connection with id `$connectionId`")))

  private def getOrNotFoundError[T](
      o: Option[T],
      notFoundMessage: String,
      context: Option[String] = None
  ): T = o.getOrElse {
    LOG.info(context.foldLeft(notFoundMessage)((nf, c) => s"$c $nf"))
    throw new NotFoundTrackerRestException(notFoundMessage)
  }

  def testRunIncoming(
      connectionId: Int,
      testRunIncomingData: TestRunIncomingData
  ): Future[List[TestRunIncomingResponse]] =
    testRunScript.createIncomingReplica(connectionId, testRunIncomingData)

  def getSyncQueueStatistics(connectionIdOpt: Option[Int]): Future[SyncQueueStatisticsData] = {
    val pageRequest = PageRequest(Option(1), Option(0))
    (for {
      outgoing <- eventReplicationRepository.findSyncEvents(
        connectionIdOpt,
        None,
        None,
        pageRequest
      )
      incoming <- requestReplicationRepository.findSyncRequests(
        connectionIdOpt,
        None,
        None,
        pageRequest
      )
      outgoingAttachments <- blobEventReplicationRepository.findPendingBlobEvents(
        connectionIdOpt,
        None,
        None,
        pageRequest
      )
      incomingAttachments <- requestReplicationRepository.findPendingBlobRequests(
        connectionIdOpt,
        None,
        None,
        pageRequest
      )

    } yield SyncQueueStatisticsData(
      incoming.total,
      incomingAttachments.total,
      outgoing.total,
      outgoingAttachments.total
    )).recoverWith {
      case e =>
        LOG.error("An exception while getting sync queue statistics", e)
        Future.failed(
          new InternalServerErrorTrackerRestException(
            "Cannot get sync queue statistics"
          )
        )
    }

  }

  def getSyncQueueItemOutgoing(syncEventId: Int): Future[SyncQueueItemOutgoing] = {
    val eventF = eventReplicationRepository
      .getSyncEvent(syncEventId)
      .map(getOrNotFoundError(_, s"Couldn't find a sync event with id `$syncEventId`"))
    val errorsF = errorRepository.findSyncEventErrors(syncEventId)
    (eventF, errorsF).mapN { (event, errors) =>
      SyncQueueItemOutgoing(event.getId, event, errors)
    }
  }

  def getSyncQueueItemIncoming(syncRequestId: Int): Future[SyncQueueItemIncoming] = {
    val requestF = requestReplicationRepository
      .getSyncRequestById(syncRequestId)
      .map(getOrNotFoundError(_, s"Couldn't find a sync request with id `$syncRequestId`"))
    val errorsF = errorRepository.findSyncRequestErrors(syncRequestId)
    (requestF, errorsF).mapN((request, errors) =>
      SyncQueueItemIncoming(request.getId, request, errors)
    )
  }

  def getOutgoingAttachmentDetails(blobEventId: Int): Future[SyncQueueItemOutgoing] =
    for {
      blobEvent <- blobEventReplicationRepository
        .getBlobEventById(blobEventId)
        .map(getOrNotFoundError(_, s"Couldn't find a blob event with id `$blobEventId`"))
      syncEvent = blobEvent.getSyncEvent
      errors <- errorRepository.findSyncEventErrors(syncEvent.getId)
    } yield SyncQueueItemOutgoing(blobEvent.getId, syncEvent, errors)

  def getIncomingAttachmentDetails(blobRequestId: Int): Future[SyncQueueItemIncoming] =
    for {
      blobRequest <- requestReplicationRepository
        .getBlobRequestById(blobRequestId)
        .map(getOrNotFoundError(_, s"Couldn't find a blob request with id `$blobRequestId`"))
      syncRequest = blobRequest.getSyncRequest
      errors <- errorRepository.findSyncRequestErrors(syncRequest.getId)
    } yield SyncQueueItemIncoming(blobRequest.getId, syncRequest, errors)

  def getSyncQueueItemsOutgoing(
      limit: Option[Int],
      offset: Option[Int],
      connectionId: Option[Int]
  ): Future[PaginatedResult[SyncQueueItemsData]] =
    eventReplicationRepository
      .findSyncEvents(connectIdOpt = connectionId, pageRequest = PageRequest(limit, offset))
      .flatMap { pageResult =>
        errorRepository.getErrorsForLocalEntities(pageResult.results.flatMap(EntityError.key)).map {
          errors =>
            PaginatedResult(pageResult).map { syncEvent =>
              SyncQueueItemsData(
                id = syncEvent.getId,
                localIssueUrn = Option(syncEvent.getLocalReplica).map(_.getIssueKey.getURN),
                remoteIssueUrn = Option(syncEvent.getRemoteReplica).map(_.getIssueKey.getURN),
                connectionId = syncEvent.getConnection.getID,
                status = syncEvent.getStatus.name(),
                errorId = EntityError.key(syncEvent).flatMap(errors.get)
              )
            }
        }
      }
      .recoverWith {
        case e =>
          LOG.error("An exception while getting outgoing (events) sync queue items", e)
          Future.failed(
            new InternalServerErrorTrackerRestException(
              "Cannot get outgoing sync queue items"
            )
          )
      }

  def getSyncQueueItemsIncoming(
      limit: Option[Int],
      offset: Option[Int],
      connectionId: Option[Int]
  ): Future[PaginatedResult[SyncQueueItemsData]] =
    requestReplicationRepository
      .findSyncRequests(connectIdOpt = connectionId, pageRequest = PageRequest(limit, offset))
      .flatMap { pageResult =>
        errorRepository
          .getErrorsForRemoteEntities(pageResult.results.flatMap(EntityError.key))
          .map { errors =>
            PaginatedResult(pageResult).map { syncRequest =>
              SyncQueueItemsData(
                id = syncRequest.getId,
                localIssueUrn = Option(syncRequest.getSyncedTo).map(_.getURN),
                remoteIssueUrn = Option(syncRequest.getReplica).map(_.getIssueKey.getURN),
                connectionId = syncRequest.getConnection.getID,
                status = syncRequest.getStatus.name(),
                errorId = EntityError.key(syncRequest).flatMap(errors.get)
              )
            }
          }
      }
      .recoverWith {
        case e =>
          LOG.error("An exception while getting incoming (requests) sync queue items", e)
          Future.failed(
            new InternalServerErrorTrackerRestException(
              "Cannot get incoming sync queue items"
            )
          )
      }

  def getSyncQueueItemsOutgoingAttachments(
      limit: Option[Int],
      offset: Option[Int],
      connectionId: Option[Int]
  ): Future[PaginatedResult[SyncQueueItemsData]] =
    blobEventReplicationRepository
      .findPendingBlobEvents(connectIdOpt = connectionId, pageRequest = PageRequest(limit, offset))
      .flatMap { pageResult =>
        errorRepository.getErrorsForLocalEntities(pageResult.results.flatMap(EntityError.key)).map {
          errors =>
            PaginatedResult(pageResult).map { blobEvent =>
              val syncEvent = blobEvent.getSyncEvent
              val localReplica = Option(syncEvent.getLocalReplica)
              val attachmentMetadata = DomainToValueUtils.attachmentMetadataForBlob(
                localReplica.map(_.getPayload),
                blobEvent.getBlobMetadata.getBlobId
              )
              SyncQueueItemsData(
                id = blobEvent.getId,
                localIssueUrn = localReplica.map(_.getIssueKey.getURN),
                remoteIssueUrn = Option(syncEvent.getRemoteReplica).map(_.getIssueKey.getURN),
                connectionId = syncEvent.getConnection.getID,
                status = blobEvent.getStatus.name(),
                errorId = EntityError.key(blobEvent).flatMap(errors.get),
                fileName = attachmentMetadata.map(_.fileName),
                fileSize = attachmentMetadata.map(_.fileSizeKb)
              )
            }
        }
      }
      .recoverWith {
        case e =>
          LOG.error("An exception while getting all items from the outgoing attachment queue", e)
          Future.failed(
            new InternalServerErrorTrackerRestException(
              "Cannot get outgoing attachment sync queue items"
            )
          )
      }

  def getSyncQueueItemsIncomingAttachments(
      limit: Option[Int],
      offset: Option[Int],
      connectionId: Option[Int]
  ): Future[PaginatedResult[SyncQueueItemsData]] =
    requestReplicationRepository
      .findPendingBlobRequests(connectIdOpt = connectionId, pageRequest = PageRequest(limit, offset))
      .flatMap { pageResult =>
        errorRepository
          .getErrorsForRemoteEntities(pageResult.results.flatMap(EntityError.key))
          .map { errors =>
            PaginatedResult(pageResult).map { blobRequest =>
              val syncRequest = blobRequest.getSyncRequest
              val remoteReplica = Option(syncRequest.getReplica)
              val attachmentMetadata = DomainToValueUtils.attachmentMetadataForBlob(
                remoteReplica.map(_.getPayload),
                blobRequest.getBlobMetadata.getBlobId
              )
              SyncQueueItemsData(
                id = blobRequest.getId,
                localIssueUrn = Option(syncRequest.getSyncedTo).map(_.getURN),
                remoteIssueUrn = remoteReplica.map(_.getIssueKey.getURN),
                connectionId = syncRequest.getConnection.getID,
                status = blobRequest.getStatus.name(),
                errorId = EntityError.key(blobRequest).flatMap(errors.get),
                fileName = attachmentMetadata.map(_.fileName),
                fileSize = attachmentMetadata.map(_.fileSizeKb)
              )
            }
          }
      }
      .recoverWith {
        case e =>
          LOG.error("An exception while getting all items from the incoming attachment queue", e)
          Future.failed(
            new InternalServerErrorTrackerRestException(
              "Cannot get incoming attachment sync queue items"
            )
          )
      }

  def exalate(connectionId: Int, entityUrn: String, entityType: String): Future[Unit] =
    prepareDataForScheduleEvent(connectionId, entityUrn, entityType).map {
      case (connection, entityKey) =>
        schedulerService.scheduleExalateOrUpdateEvent(connection, entityKey)
    }

  def unexalate(connectionId: Int, entityUrn: String, entityType: String): Future[Unit] =
    prepareDataForScheduleEvent(connectionId, entityUrn, entityType).map {
      case (connection, entityKey) =>
        schedulerService.scheduleCleanupEvent(connection, entityKey)
    }

  def connect(entityUrn: String, connectReqeustValue: ConnectRequestValue): Future[Unit] = {
    val nonPersConC =
      new NonPersistentConnectContext(
        connectReqeustValue.synchronizeComments,
        connectReqeustValue.synchronizeAttachments,
        connectReqeustValue.synchronizeWorklogs,
        connectReqeustValue.triggerSyncEvent,
        connectReqeustValue.triggerUpdate,
        false
      )

    (for {
      connection <- getConnectionOrFail(connectReqeustValue.connection)
      localKeyAndHubPayloadTuple <- trackerHubObjectService
        .getLocalKeyAndHubPayloadFromTracker(
          entityUrn,
          connection,
          connectReqeustValue.entityType,
          Map.empty
        )
      _ = localKeyAndHubPayloadTuple match {
        case (Some(entityKey), hubPayloadOpt) =>
          val issueContextOpt = hubPayloadOpt
            .map(p => new UpdateBasicHubIssue(p.getHubIssue.asInstanceOf[BasicHubIssue]))
          schedulerService.scheduleConnectEvent(
            connection,
            entityKey,
            connectReqeustValue.remoteIssueUrn,
            Some(nonPersConC),
            issueContextOpt
          )
        case _                                =>
          val notFoundMessage = s"Local ${connectReqeustValue.entityType} $entityUrn is not found"
          throw new NotFoundTrackerRestException(notFoundMessage)
      }
    } yield ())
      .recoverWith {
        case e: NotFoundTrackerRestException => Future.failed(e)
        case e                               =>
          LOG.error(
            s"An exception while getting connection with id " +
              s"${connectReqeustValue.connection} or while getting payload for ${connectReqeustValue.entityType} $entityUrn.",
            e
          )
          Future.failed(
            new InternalServerErrorTrackerRestException(
              s"Cannot get connection with id ${connectReqeustValue.connection} or payload for ${connectReqeustValue.entityType} $entityUrn"
            )
          )
      }
  }

  private def prepareDataForScheduleEvent(
      connectionId: Int,
      entityUrn: String,
      entityType: String
  ): Future[(IConnection, IIssueKey)] =
    (for {
      connection <- getConnectionOrFail(connectionId)
      localEntityKey <- trackerHubObjectService
        .getLocalKeyForFieldValues(
          entityUrn,
          Map.empty,
          entityType
        )
        .map(getOrNotFoundError(_, s"Local $entityType $entityUrn is not found"))
    } yield (connection, localEntityKey))
      .recoverWith {
        case e: NotFoundTrackerRestException => Future.failed(e)
        case e                               =>
          LOG.error(
            s"An exception while getting connection with id $connectionId or while getting entity $entityUrn with type $entityType",
            e
          )
          Future.failed(
            new InternalServerErrorTrackerRestException(
              s"Cannot get connection with id $connectionId or entity $entityUrn with type $entityType"
            )
          )
      }

}

object SyncRoomService {

  def toNonPersistenceTrigger(
      connection: IConnection,
      trigger: TriggerRequest
  ): NonPersistentTrigger =
    new NonPersistentTrigger(
      trigger.query.getOrElse(""),
      trigger.entityType,
      connection,
      trigger.notes.getOrElse(""),
      TriggerStatus.valueOf(trigger.status),
      Collections.emptyMap()
    )

}
