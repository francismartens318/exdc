package com.exalate.replication.services.syncroom

import cats.implicits._
import com.exalate.api.domain.IIssueKey
import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.hubobject.{IHubIssuePayload, IHubIssueReplica, IHubPayload}
import com.exalate.api.domain.twintrace.INonPersistentTrace
import com.exalate.api.exception.script.{ScriptException, ScriptProcessors}
import com.exalate.api.hubobject.IHubObjectValidator
import com.exalate.api.hubobject.v1.IHubIssueProcessorPreparationService
import com.exalate.api.persistence.twintrace.ITwinTraceRepository
import com.exalate.api.processor.IExalateProcessor
import com.exalate.basic.domain.BasicHubPayload
import com.exalate.basic.domain.hubobject.v1.BasicHubIssue
import com.exalate.basic.domain.util.SemanticVersionService
import com.exalate.domain.editor.mappings.Mappings
import com.exalate.domain.exception.issuetracker.{
  InternalServerErrorTrackerRestException,
  NotFoundTrackerRestException
}
import com.exalate.domain.values.syncroom.{
  Error,
  IssueFields,
  SourceReplica,
  TestRunIncomingData,
  TestRunIncomingResponse,
  TestRunOutgoingData,
  TestRunOutgoingResponse
}
import com.exalate.generic.services.api.ITrackerHubObjectService
import com.exalate.replication.services.api.config.IConnectionService
import com.exalate.replication.services.api.hubobject.IReplicaHelper
import com.exalate.replication.services.api.node.ISelfNodeInfoService
import com.exalate.replication.services.api.processor.IScriptVariableService
import com.exalate.replication.services.processor.ScriptVariableServiceFactory
import com.exalate.replication.services.utils.ScriptProcessorExceptionHandling
import com.google.inject.Inject
import org.slf4j
import org.slf4j.LoggerFactory
import play.api.libs.json.Json

import java.util
import scala.concurrent.{ExecutionContext, Future}
import scala.util.{Failure, Success, Try}

class TestRunScript @Inject() (
    trackerHubObjectService: ITrackerHubObjectService,
    processor: IExalateProcessor,
    hubObjectValidator: IHubObjectValidator,
    replicaHelper: IReplicaHelper,
    selfNodeInfoService: ISelfNodeInfoService,
    scriptVariableServiceFactory: ScriptVariableServiceFactory,
    preparationService: IHubIssueProcessorPreparationService,
    twinTraceRepository: ITwinTraceRepository,
    connectionService: IConnectionService
)(implicit
    val ec: ExecutionContext
) {
  private val LOG: slf4j.Logger = LoggerFactory.getLogger(classOf[TestRunScript])

  private lazy val scriptVariableServiceReadOnly: IScriptVariableService =
    scriptVariableServiceFactory.getScriptVariableReadOnlyService()

  private def getConnectionOrFail(
      connectionId: Int,
      message: Option[String] = None
  ): Future[IConnection] = connectionService
    .get(connectionId)
    .map(getOrNotFoundError(_, message.getOrElse(s"Couldn't find a connection with id `$connectionId`")))

  private def getOrNotFoundError[T](
      o: Option[T],
      notFoundMessage: String,
      context: Option[String] = None
  ): T = o.getOrElse {
    LOG.info(context.foldLeft(notFoundMessage)((nf, c) => s"$c $nf"))
    throw new NotFoundTrackerRestException(notFoundMessage)
  }

  def createOutgoingReplica(
      connectionId: Int,
      testRunOutgoingData: TestRunOutgoingData,
      isAIScript: Boolean = false
  ): Future[Seq[TestRunOutgoingResponse]] =
    getConnectionOrFail(connectionId)
      .flatMap { connection =>
        val script = testRunOutgoingData.script.script
        val urns = testRunOutgoingData.issueUrns
        val fieldValues = Map.empty[String, String]
        urns.traverse { issue =>
          trackerHubObjectService
            .getLocalKeyForFieldValues(issue.urn.orNull, fieldValues, issue.entityType.orNull)
            .flatMap {
              case Some(issueKey: IIssueKey) =>
                trackerHubObjectService
                  .getHubPayloadFromTracker(issueKey, connection)
                  .flatMap {
                    case Some(hubPayload) =>
                      scriptTestRunForOutgoingReplica(
                        issueKey,
                        hubPayload,
                        connection,
                        script,
                        isAIScript
                      )
                        .map { replicaStr =>
                          TestRunOutgoingResponse(
                            IssueFields(
                              issue.urn,
                              Some(issueKey.getIdStr),
                              Some(issueKey.getEntityType)
                            ),
                            Option(replicaStr)
                          )
                        }
                        .recover { e =>
                          val message = e.getMessage
                          TestRunOutgoingResponse(
                            IssueFields(
                              issue.urn,
                              Some(issueKey.getIdStr),
                              Some(issueKey.getEntityType)
                            ),
                            None,
                            Some(Seq(Error(message)))
                          )
                        }
                    case None             =>
                      Future.successful(
                        TestRunOutgoingResponse(
                          IssueFields(
                            issue.urn,
                            Some(issueKey.getIdStr),
                            Some(issueKey.getEntityType)
                          ),
                          None,
                          Some(
                            Seq(
                              Error(
                                s"Cannot get entity `${issue.entityType.orNull} ${issue.urn.orNull}` info"
                              )
                            )
                          )
                        )
                      )
                  }

              case None =>
                Future.successful(
                  TestRunOutgoingResponse(
                    IssueFields(issue.urn, None, None),
                    None,
                    Some(
                      Seq(Error(s"Entity `${issue.entityType.orNull}` with urn `${issue.urn.orNull}` was not found"))
                    )
                  )
                )
            }
        }
      }
      .recoverWith {
        case e: Exception =>
          LOG.error(
            s"An exception while creating test Outgoing Replica for connection $connectionId, input data: $testRunOutgoingData",
            e
          )
          Future.failed(
            new InternalServerErrorTrackerRestException(
              "An exception while creating test Outgoing Replica"
            )
          )
      }

  def createIncomingReplica(
      connectionId: Int,
      testRunIncomingData: TestRunIncomingData,
      isAIScript: Boolean = false
  ): Future[List[TestRunIncomingResponse]] = {
    getConnectionOrFail(connectionId)
      .flatMap { connection =>
        testRunIncomingData.sourceReplicas.map { sourceReplica =>
          val hubPayLoad: IHubIssuePayload =
            replicaHelper.toHubIssuePayload(sourceReplica.sourceReplica) match {
              case Success(hubPayLoad) => hubPayLoad
              case Failure(exception)  =>
                throw new Exception(s"Couldn't initiate HubPayload, ex: ${exception.getMessage}")
            }
          val receivedHubIssue = hubPayLoad.getHubIssue
          val replica = preparationService.prepareRemoteHubIssue(
            receivedHubIssue.asInstanceOf[BasicHubIssue],
            util.Collections.emptyMap()
          )

          scriptVariableServiceReadOnly
            .createIncomingSyncContext(
              replica.asInstanceOf[BasicHubIssue],
              true,
              connection,
              null,
              None,
              None,
              None,
              Seq.empty,
              Seq.empty[INonPersistentTrace],
              LOG,
              isAIScript
            )
            .flatMap { incomingSyncContext =>
              twinTraceRepository
                .findTwinTracesByIssueIdSimplified(
                  sourceReplica.sourceIssue.key.orNull,
                  sourceReplica.sourceIssue.entityType.orNull,
                  new util.HashMap[String, String]
                )
                .flatMap { twinTraces =>
                  val context: util.HashMap[String, Object] = if (twinTraces.isEmpty) {
                    new util.HashMap(incomingSyncContext)
                  } else {
                    val mappingOpt = Option(incomingSyncContext.get("mappings"))
                      .map(_.asInstanceOf[Mappings])
                    val swapSidesOpt = Option(incomingSyncContext.get("swapSides"))
                      .map(_.asInstanceOf[java.lang.Boolean])
                    val sendingInstanceNameOpt =
                      Option(incomingSyncContext.get("sendingInstanceName"))
                        .map(_.asInstanceOf[String])
                    val executionInstanceNameOpt =
                      Option(incomingSyncContext.get("executionInstanceName"))
                        .map(_.asInstanceOf[String])
                    val replica = Option(incomingSyncContext.get("replica"))
                      .map(_.asInstanceOf[BasicHubIssue])
                    val updatedIncomingSyncContext =
                      scriptVariableServiceReadOnly.updateIncomingSyncContext(
                        incomingSyncContext,
                        connection,
                        issue = receivedHubIssue.asInstanceOf[BasicHubIssue],
                        replica.orNull,
                        mapping = mappingOpt.orNull,
                        swapSides = swapSidesOpt.orNull,
                        sendingInstanceName = sendingInstanceNameOpt.orNull,
                        receivingInstanceName = executionInstanceNameOpt.orNull
                      )
                    new util.HashMap(updatedIncomingSyncContext)
                  }
                  val result =
                    executeScriptRules(
                      testRunIncomingData.script.script,
                      context,
                      ScriptProcessors.INCOMING
                    )
                      .map { context =>
                        val entities = context.get("entities").asInstanceOf[Seq[IHubIssueReplica]]
                        val targetReplicas = entities
                          .flatMap {
                            case basicHubIssue: BasicHubIssue => Some(basicHubIssue)
                            case _                            => None
                          }
                          .map { entitiesAfterScript =>
                            val hubObjectVersion =
                              SemanticVersionService.get(selfNodeInfoService.getMaxHubObjectVersion)
                            hubObjectValidator.validateIssueReplica(entitiesAfterScript)
                            val res = replicaHelper.createNonPersistentReplica(
                              null,
                              Option(entitiesAfterScript.getSummary),
                              new BasicHubPayload(hubObjectVersion, entitiesAfterScript, null)
                            )
                            val targetReplica =
                              (Json.parse(res.getPayloadAsString) \ "hubIssue").get
                            Json.obj("hubIssue" -> targetReplica)
                          }
                        twinTraces.headOption match {
                          case Some(twinTrace) =>
                            val issueKey = twinTrace.getLocalReplica.getIssueKey
                            val issueFields = IssueFields(
                              urn = Some(issueKey.getURN),
                              key = Some(issueKey.getIdStr),
                              entityType = Some(issueKey.getEntityType)
                            )

                            TestRunIncomingResponse(
                              sourceReplica.sourceIssue,
                              issueFields,
                              Some(Json.toJson(targetReplicas).toString),
                              None
                            )
                          case None            =>
                            TestRunIncomingResponse(
                              sourceReplica.sourceIssue,
                              IssueFields(None, None, None),
                              Some(Json.toJson(targetReplicas).toString),
                              None
                            )
                        }
                      }
                      .recover { e =>
                        val message = e.getMessage
                        TestRunIncomingResponse(
                          sourceReplica.sourceIssue,
                          IssueFields(None, None, None),
                          None,
                          Some(Seq(Error(message)))
                        )
                      }
                  LOG.debug(s"Incoming script executed")
                  result
                }
            }
        }.sequence
      }
      .recoverWith {
        case e: Exception =>
          LOG.error(
            s"An exception while creating test Incoming Replica for connection $connectionId, input data: $testRunIncomingData",
            e
          )
          Future.failed(
            new InternalServerErrorTrackerRestException(
              "An exception while creating test Incoming Replica"
            )
          )
      }
  }

  private def scriptTestRunForOutgoingReplica(
      issueKey: IIssueKey,
      hubPayload: IHubPayload,
      connection: IConnection,
      script: String,
      isAIScript: Boolean = false
  ): Future[String] = {
    val issue = hubPayload.getHubIssue
    val replica = new BasicHubIssue()

    Future
      .fromTry(
        Try(
          scriptVariableServiceReadOnly
            .createOutgoingSyncContext(connection, issue, replica, issueKey, None, LOG, isAIScript)
        )
      )
      .flatMap(context => executeScriptRules(script, context, ScriptProcessors.OUTGOING))
      .map { context =>
        val replicaAfterScripts = context.get("replica").asInstanceOf[BasicHubIssue]
        hubObjectValidator.validateIssueReplica(replicaAfterScripts)
        val hubObjectVersion = SemanticVersionService.get(selfNodeInfoService.getMaxHubObjectVersion)
        val res = replicaHelper.createNonPersistentReplica(
          issueKey,
          Option(replicaAfterScripts.getSummary),
          new BasicHubPayload(hubObjectVersion, replicaAfterScripts, null)
        )
        val hubIssueJson = (Json.parse(res.getPayloadAsString) \ "hubIssue").get
        Json.obj("hubIssue" -> hubIssueJson).toString()
      }
  }

  private def executeScriptRules(
      script: String,
      context: util.HashMap[String, Object],
      scriptProcessors: ScriptProcessors
  ): Future[util.HashMap[String, Object]] =
    Future.fromTry(
      Try {
        processor.executeProcessor(script, context, scriptProcessors)
        LOG.debug(
          s"The script `$script` was executed successfully"
        )
        context
      }
        .recoverWith {
          case e: ScriptException =>
            ScriptProcessorExceptionHandling.handleException(e)
        }
    )

}
