package com.exalate.replication.services.transport.v1.rest

import com.exalate.api.domain.blob.event.IBlobEvent
import com.google.inject.ImplementedBy
import com.exalate.replication.services.transport.value.BlobRequestValue

import scala.concurrent.Future

@ImplementedBy(classOf[com.exalate.replication.services.transport.v1.rest.BlobRequestClient])
trait IBlobRequestClient {

  /** POST /rest/issuehub/1.0/blobrequests
    */
  def postBlobRequest(
      blobRequest: BlobRequestValue,
      remoteInstanceUrl: String,
      blobEvent: IBlobEvent
  ): Future[None.type]

}
