package com.exalate.replication.services.transport

import com.exalate.api.domain.connection.IConnection
import com.exalate.api.exception.network.AvailabilityNetworkException
import com.exalate.domain.exception.rest.{
  ExalateAuthenticationRestResponseException,
  ExalateErrorValueRestResponseException,
  ExalateRestResponseException
}
import com.exalate.replication.services.transport.utils.ExalateVersionCheckerUtils
import com.exalate.replication.services.transport.value.ErrorValue
import play.api.Logger
import play.api.libs.json.{JsError, Json}
import play.api.libs.ws.WSResponse

import scala.concurrent.{ExecutionContext, Future}
import scala.util.{Failure, Success, Try}

class ResponseHandler(implicit ec: ExecutionContext) {
  val LOG = Logger("application.services.transport.ResponseHandler")

  /** Response handler: handles ExalateResponse and non ExalateResponse
    * @param connection
    * @param response
    * @param exalateVersionCheckerUtils
    * @return
    */
  def handleResponses(
      connection: IConnection,
      response: WSResponse
  ): Future[None.type] =
    if (ExalateVersionCheckerUtils.remoteSupportsHeaderInRequest(connection)) {
      Future.fromTry((new ResponseHandler).handleExalateResponse(response)).map(_ => None)
    } else {
      Future.fromTry((new ResponseHandler).handleResponse(response)).map(_ => None)
    }

  /** Splits responses to successful and unsuccessful
    * @param response
    * @return
    */
  def handleResponse(response: WSResponse): Try[WSResponse] = {
    if (response.status >= 400) {
      return handleUnsuccessfulResponse(response)
    }
    Success(response)
  }

  /** Handles Exalate responses: check whether they are successfull and unsuccessful (status >= 400,
    * >200 ** <300 without header)
    * @param response
    * @return
    */
  def handleExalateResponse(response: WSResponse): Try[WSResponse] = {
    if (response.status >= 400) {
      return handleUnsuccessfulResponse(response)
    }
    if (
      response.status >= 200 && response.status < 300 && response
        .header("X-exalate-response")
        .isEmpty
    ) {
      // response is not from Exalate
      return handleUnsuccessfulResponse(response)
    }
    Success(response)
  }

  /** Handles Unsuccessful Responses: generates corresponding Exception with message
    * @param response
    * @return
    */
  private def handleUnsuccessfulResponse(response: WSResponse): Try[WSResponse] = {

    import com.exalate.replication.services.transport.v1.rest.SyncRestUtils.Implicits.errorValueReads
    val errorValueJsResult = Try(Json.parse(response.body))
      .map(_.validate[ErrorValue])
      .getOrElse(new JsError(Nil))

    if (errorValueJsResult.isSuccess) {
      val errVal: ErrorValue = errorValueJsResult.get
      val errorValueException: ExalateErrorValueRestResponseException =
        ExalateErrorValueRestResponseException(errVal.className, errVal.message)
      Failure(errorValueException)
    } else {
      LOG.error(
        s"Handling unsuccessful response with status: ${Option(response.status).orNull}. Message is: ${response.body}"
      )
      if (response.status == 502 | response.status == 503) {
        Failure(
          new AvailabilityNetworkException(
            s"Communication with the remote side failed with status code: ${response.status}."
          )
        )
      } else if (response.status == 404) {
        Failure(
          new ExalateRestResponseException(
            s"Received a response `${response.statusText}(${response.status})`: `${response.body}`"
          )
        )
      } else if (response.status == 403 || response.status == 401) {
        Failure(
          ExalateAuthenticationRestResponseException(
            "Authentication problem, please make sure that provided credentials are correct",
            response.status
          )
        )
      } else if (response.status == 400) {
        Failure(
          new ExalateRestResponseException(
            s"Received a response `${response.statusText}(${response.status})`: `${response.body}`"
          )
        )
      } else if (
        response.status >= 200 && response.status < 300 && response
          .header("X-exalate-response")
          .isEmpty
      ) {
        Failure(
          new ExalateRestResponseException(
            s"Received response is not from Exalate. Message: `${response.body}`"
          )
        )
      } else {
        Failure(
          new ExalateRestResponseException(
            s"unhandled response status `${response.statusText} (${response.status})` with body `${response.body}`"
          )
        )
      }
    }
  }

}
