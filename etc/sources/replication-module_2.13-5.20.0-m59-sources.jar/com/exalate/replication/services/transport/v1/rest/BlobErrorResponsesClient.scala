package com.exalate.replication.services.transport.v1.rest

import com.exalate.api.domain.blob.request.IBlobRequest
import com.exalate.error.services.api.IExalateRestErrorResponseCategoryService
import com.exalate.replication.services.transport.{ExaToExaRequestFilterFactory, ResponseHandler}
import com.exalate.replication.services.transport.value.BlobErrorResponseValue
import com.exalate.replication.services.transport.wrapper.{ILoggingWsClientFactory, LoggingFnUtils}
import com.exalate.util.UrlUtils

import javax.inject.Inject
import play.api.Logger
import play.api.libs.json.Json
import play.api.libs.ws.{WSClient, WSRequest}

import scala.concurrent.ExecutionContext
import scala.concurrent.Future

class BlobErrorResponsesClient @Inject() (
    wsClient: WSClient,
    loggingWsClientFactory: ILoggingWsClientFactory,
    exaToExaRequestFilterFactory: ExaToExaRequestFilterFactory,
    errorRestResponseCategoryService: IExalateRestErrorResponseCategoryService
)(implicit ec: ExecutionContext)
    extends IBlobErrorResponsesClient {
  val SYNC_RESPONSE_URL = "/rest/issuehub/1.0/bloberrorresponses"

  val ws = loggingWsClientFactory.create(
    wsClient,
    LoggingFnUtils.logRequestWithBody,
    LoggingFnUtils.logResponseWithBody
  )

  val LOG = Logger("application.services.transport.rest.BlobErrorResponsesClient")

  /** POST /rest/issuehub/1.0/bloberrorresponses
    * @param blobErrorResponseValue
    * @param remoteInstanceUrl
    * @param blobRequest
    * @return
    *   None
    */
  override def postBlobErrorResponse(
      blobErrorResponseValue: BlobErrorResponseValue,
      remoteInstanceUrl: String,
      blobRequest: IBlobRequest
  ): Future[None.type] = {
    LOG.info(
      s"Posting blob error response from sync event: ${blobErrorResponseValue.syncEventId} to: $remoteInstanceUrl"
    )
    val syncRequest = blobRequest.getSyncRequest
    val connection = blobRequest.getSyncRequest.getConnection
    val requestFilter = exaToExaRequestFilterFactory.create(connection)

    val url = UrlUtils.concat(remoteInstanceUrl, SYNC_RESPONSE_URL)
    val request: WSRequest = ws
      .url(url)
      .withHeaders("Content-Type" -> "application/json")
      .withRequestFilter(requestFilter)
    exaToExaRequestFilterFactory
      .processWithShortSecretRetry(
        connection,
        request
          .post(Json.toJson(blobErrorResponseValue))
      )
      .flatMap { r =>
        Future.fromTry((new ResponseHandler).handleResponse(r)).map(_ => None)
      }
      .recoverWith {
        case e: Exception =>
          val details =
            s"Exception while posting blob error response from sync request `${syncRequest.getId}` for sync event ${blobErrorResponseValue.syncEventId} to `$remoteInstanceUrl`"
          LOG.error(details, e)
          val exception = errorRestResponseCategoryService.categorizeNetworkAndRestResponseException(
            e,
            Some(details)
          )
          Future.failed(exception)
      }

  }

}
