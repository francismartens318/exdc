package com.exalate.replication.services.transport.v1.rest

import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.request.ISyncRequest
import com.exalate.domain.replication.BasicSyncRequest
import com.google.inject.ImplementedBy
import com.exalate.replication.services.transport.value.ErrorResponseValue

import scala.concurrent.Future

@ImplementedBy(classOf[com.exalate.replication.services.transport.v1.rest.ErrorResponsesClient])
trait IErrorResponsesClient {

  /** POST /rest/issuehub/1.0/errorresponses
    */
  @deprecated(
    "Will be removed in favor of `postErrorResponse(errorResponseValue, remoteInstanceUrl, basicSyncRequest, connection)`",
    "EXACOMP-1884"
  )
  def postErrorResponse(
      errorResponseValue: ErrorResponseValue,
      remoteInstanceUrl: String,
      syncRequest: ISyncRequest
  ): Future[None.type]

  /** POST /rest/issuehub/1.0/errorresponses
    */
  def postErrorResponse(
      errorResponseValue: ErrorResponseValue,
      remoteInstanceUrl: String,
      basicSyncRequest: BasicSyncRequest,
      connection: IConnection
  ): Future[None.type]

}
