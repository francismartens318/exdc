package com.exalate.replication.services.transport.utils

import com.exalate.api.domain.instance.{IInstance, INonPersistentInstance}
import com.exalate.basic.domain.instance.NonPersistentInstance
import com.exalate.domain.values.SimplifiedInstanceValue
import com.exalate.replication.services.transport.value.helpers.NodeInfoValueHelper

object InstanceConverter {

  /** Converts IInstance to SimplifiedInstanceValue
    * @param instance
    * @return
    *   SimplifiedInstanceValue
    */
  def toSimplifiedInstanceValue(instance: IInstance): SimplifiedInstanceValue = {
    val url = Option(instance.getUrl).map(_.toExternalForm)
    SimplifiedInstanceValue(instance.getID, instance.getName, Option(instance.getStatus.name()), url)
  }

  def toNonPersistentInstance(instance: IInstance): INonPersistentInstance =
    new NonPersistentInstance(
      instance.getName,
      instance.getDescription,
      instance.getUrl,
      instance.getIssueTrackerUrl,
      instance.getStatus,
      NodeInfoValueHelper.toNonPersistentNodeInfo(instance.getNodeInfo),
      instance.getIssueTrackerSettings,
      instance.getRemoteUsername,
      instance.getRemoteUserPassword,
      instance.isAuthenticationRequired,
      instance.getCustomFieldValues,
      instance.getFieldValues
    )

}
