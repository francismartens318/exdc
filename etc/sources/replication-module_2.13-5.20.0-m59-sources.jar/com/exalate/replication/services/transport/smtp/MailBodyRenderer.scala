package com.exalate.replication.services.transport.smtp

import com.exalate.api.domain.{ErrorEntityType, IError}
import com.exalate.replication.services.api.config.IGeneralSettingsService
import com.exalate.replication.services.config.ErrorTypeNameUtil
import com.google.inject.Inject
import play.api.Logger

import scala.concurrent.{ExecutionContext, Future}

class MailBodyRenderer @Inject() (ggs: IGeneralSettingsService)(implicit ec: ExecutionContext) {

  val LOG = Logger("application.services.transport.smtp.MailBodyRenderer")

  def renderMailBody(error: IError): Future[(String, String)] =
    ggs.get.map { gs =>
      var entityType = error.getErrorEntityType.name.toLowerCase
      val connection = Option(error.getConnection)
        .map(_.getName)
        .map(n => s"<p><b>Connection: </b> $n</p>")
        .getOrElse("")
      val rootCauseErrorTypeName =
        ErrorTypeNameUtil.getHumanReadableErrorTypeName(error.getRootCauseErrorTypeName)
      val rootCauseDetails = error.getRootCauseDetails
      val subject = getLevelBlockedMessage(error, gs.map(_.getIssueTrackerUrl))
      if (ErrorEntityType.RELATION.name().equals(entityType)) {
        entityType = "connection"
      }

      val body =
        s"""<h3>$subject</h3>
           |<p><b>Exalate url: </b> ${gs.flatMap(_.getExalateUrl).getOrElse("")}</p>
           |$connection
           |<p><b>Error impact: </b> ${entityType.capitalize}</p>
           |<p><b>Error type: </b> $rootCauseErrorTypeName</p>
           |<div>
           |<p>$rootCauseDetails</p>
           |</div>
       """.stripMargin
      (s"$subject", body)
    }

  def renderLicenseMailBody(): Future[(String, String)] =
    ggs.get.map { gs =>
      val url = gs.map(_.getIssueTrackerUrl).getOrElse("your instance")
      val body =
        s"""
          |<p>Hey,</p>
          |
          |<p>We see you've been making the most of your Exalate trial at <a href='$url' rel='noopener noreferrer' target='_blank'>$url</a>. That's great!</p>
          |
          |<p>However, this is a warning that you've reached 80% of your limit of new synchronizations.</p>
          |
          |<p>Once you've reached your limit, you will not be able to create New syncs. Data already under sync will continue to be synchronized.</p>
          |
          |<p>To experience an unlimited amount of new syncs, you can purchase your Exalate license as described <a href='https://docs.exalate.com/docs/how-to-get-an-exalate-instance-license' rel='noopener noreferrer' target='_blank'>here.</a></p>
          |
          |<p>Let us know if you have any questions! Just reply to this email.</p>
        """.stripMargin

      (s"80% limit reached for Exalate", body)
    }

  def renderArchiveWarningMailBody(archiveWarningDays: Int): Future[(String, String)] =
    ggs.get.map { gs =>
      val issueTrackerUrl = gs.map(_.getIssueTrackerUrl).getOrElse("your instance")
      val exalateUrl = gs.flatMap(_.getExalateUrl).orNull
      val body =
        views.html.archivewarningmail(archiveWarningDays, issueTrackerUrl, exalateUrl).body
      (s"You won’t be able to use Exalate in $archiveWarningDays days!", body)
    }

  private def getLevelBlockedMessage(error: IError, issueTrackerUrl: Option[String]): String = {
    val issueTrackerMsg = issueTrackerUrl.map(u => s" on issue tracker $u").getOrElse("")
    error.getErrorEntityType match {
      case ErrorEntityType.ISSUE    =>
        Option(error.getIssueKey)
          .map(iK => s"Exalate synchronization of the issue ${iK.getURN} is blocked$issueTrackerMsg")
          .orElse(
            Option(error.getRemoteIssueKey)
              .map(iK =>
                s"Exalate synchronization of the remote issue ${iK.getURN} is blocked$issueTrackerMsg"
              )
          )
          .getOrElse(s"Exalate synchronization of an issue is blocked$issueTrackerMsg")
      case ErrorEntityType.RELATION =>
        LOG.error(
          s"Exalate synchronization of the connection ${error.getConnection.getName} is blocked$issueTrackerMsg"
        )
        s"Exalate synchronization of the connection ${error.getConnection.getName} is blocked$issueTrackerMsg"
      case ErrorEntityType.NODE     =>
        s"Exalate synchronization of all issues is blocked$issueTrackerMsg"

      case _ =>
        s"Exalate synchronization is being blocked by an error$issueTrackerMsg"

    }
  }

}
