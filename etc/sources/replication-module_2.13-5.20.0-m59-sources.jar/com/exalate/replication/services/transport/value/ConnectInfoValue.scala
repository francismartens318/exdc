package com.exalate.replication.services.transport.value

import com.exalate.api.domain.hubobject.IHubPayload

case class ConnectInfoValue(
    localIssueKey: IssueKeyValue,
    remoteIssueUrn: String,
    hubPayload: Option[IHubPayload]
)
