package com.exalate.replication.services.transport.mapper.v1

import com.exalate.api.exception.IssueTrackerException
import com.exalate.domain.exception.issuetracker.ForbiddenTrackerRestException
import com.exalate.replication.services.api.transport.mapper.IMapperNodeUrlClient
import com.exalate.util.UrlUtils
import com.google.inject.Inject
import play.api.Configuration
import play.api.http.HeaderNames.CONTENT_TYPE
import play.api.http.MimeTypes._
import play.api.http.Status._
import play.api.libs.json.{JsObject, JsString}
import play.api.libs.ws.{WSAuthScheme, WSClient}

import scala.concurrent.{ExecutionContext, Future}

class MapperNodeUrlClient @Inject() (wsClient: WSClient, config: Configuration)(implicit
    ec: ExecutionContext
) extends IMapperNodeUrlClient {

  val PROD_EXALATE_MAPPER_URL =
    config.getOptional[String]("exalate.mapper.url").getOrElse("https://connect.exalate.net")

  val MAPPER_CREDENTIALS = config
    .get[String]("exalate.exalate-mapper.credentials")

  val REGISTER_URL = "/rest/exalate-mapper/1.5/register-issue-tracker-url"

  case class ExalateUrlValue(exalateUrl: String, issueTrackerUrl: String)

  /** Makes a request POST
    * https://connect.exalate.net/rest/exalate-mapper/1.5/register-issue-tracker-url
    * @param exalateUrl
    * @param issueTrackerUrl
    * @return
    *   issue tracker url
    */
  override def registerIssueTrackerUrl(
      exalateUrl: String,
      issueTrackerUrl: String
  ): Future[String] = {
    val url = UrlUtils.concat(PROD_EXALATE_MAPPER_URL, REGISTER_URL)
    val body = JsObject(
      Seq("exalateUrl" -> JsString(exalateUrl), "issueTrackerUrl" -> JsString(issueTrackerUrl))
    )

    wsClient
      .url(url)
      .withHeaders(CONTENT_TYPE -> JSON)
      .withAuth(MAPPER_CREDENTIALS, "", WSAuthScheme.BASIC)
      .post(body)
      .flatMap {
        case response if response.status == FORBIDDEN =>
          Future.failed(
            new ForbiddenTrackerRestException(s"Couldn't update issue tracker url on Mapper")
          )
        case response if response.status >= 400       =>
          Future.failed(
            new IssueTrackerException(
              s"The status code: ${response.status}, the response body: ${response.body}"
            )
          )
        case response                                 => Future.successful(response.body)
      }
  }

}
