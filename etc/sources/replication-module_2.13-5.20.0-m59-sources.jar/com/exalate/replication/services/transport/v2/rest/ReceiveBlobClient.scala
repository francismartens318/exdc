package com.exalate.replication.services.transport.v2.rest

import akka.stream.scaladsl.Source
import akka.util.ByteString
import com.exalate.api.domain.blob.request.IBlobRequest
import com.exalate.error.services.api.{
  IBugExceptionCategoryService,
  IExalateRestErrorResponseCategoryService
}
import com.exalate.replication.services.api.error.SyncContext
import com.exalate.replication.services.transport.ExaToExaRequestFilterFactory
import com.exalate.replication.services.transport.wrapper.{ILoggingWsClientFactory, LoggingFnUtils}
import com.exalate.util.UrlUtils

import javax.inject.Inject
import play.api.Logger
import play.api.libs.ws.{WSClient, WSRequest}

import scala.concurrent.ExecutionContext
import scala.concurrent.Future

class ReceiveBlobClient @Inject() (
    wsClient: WSClient,
    loggingWsClientFactory: ILoggingWsClientFactory,
    exaToExaRequestFilterFactory: ExaToExaRequestFilterFactory,
    errorRestResponseCategoryService: IExalateRestErrorResponseCategoryService,
    bugExceptionCategoryService: IBugExceptionCategoryService
)(implicit ec: ExecutionContext)
    extends IReceiveBlobClient {
  val BLOBS_RESOURCE_URL_PART: String = "/plugins/servlet/exalate/2.0/blobevents/"
  val BLOBS_RESOURCE_URL_PART_2: String = "/blob"

  val ws = loggingWsClientFactory.create(
    wsClient,
    LoggingFnUtils.logRequestWithBody,
    LoggingFnUtils.logResponseWithoutBody
  )

  val LOG = Logger("application.services.transport.rest.ReceiveBlobClient")

  /** /plugins/servlet/exalate/2.0/blobevents/
    * @param blobEventId
    * @param remoteInstanceUrl
    * @param blobRequest
    * @return
    */
  override def downloadBlob(
      blobEventId: Int,
      remoteInstanceUrl: String,
      blobRequest: IBlobRequest
  ): Future[Option[Source[ByteString, _]]] = {
    val syncRequest = blobRequest.getSyncRequest
    val context = SyncContext(
      syncEventIdOpt = Some(syncRequest.getRemoteSyncEventId),
      syncEventNumberOpt = Some(syncRequest.getRemoteSyncEventNumber),
      connection = Some(syncRequest.getConnection),
      localIssueKeyOpt = Option(syncRequest.getCreatedIssueKey),
      remoteIssueKeyOpt = Some(syncRequest.getReplica.getIssueKey),
      syncRequestOpt = Some(syncRequest),
      blobRequestOpt = Some(blobRequest)
    )

    val connection = blobRequest.getSyncRequest.getConnection
    val requestFilter = exaToExaRequestFilterFactory.create(connection)
    val url = UrlUtils.concat(
      remoteInstanceUrl,
      BLOBS_RESOURCE_URL_PART,
      blobEventId.toString,
      BLOBS_RESOURCE_URL_PART_2
    )
    val request: WSRequest = ws
      .url(url)
      .withRequestFilter(requestFilter)
    exaToExaRequestFilterFactory
      .processWithShortSecretRetry(
        connection,
        request
          .stream()
      )
      .flatMap { streamedResponse =>
        val status: Int = streamedResponse.status
        status match {
          case s if s == 404 =>
            val details =
              s"Blob for remote blob event `$blobEventId` could not be found on destination instance $remoteInstanceUrl"
            LOG.error(details)
            Future.successful(None)

          case s if s >= 400 =>
            val details =
              s"Response with status code $s when attempting to receive blob for blob event $blobEventId on destination instance $remoteInstanceUrl"
            val exception = bugExceptionCategoryService.generateRestExalateTransportBugException(
              None,
              Some(details)
            )
            LOG.error(details, exception)
            Future.failed(exception)

          case _ => Future.successful(Some(streamedResponse.bodyAsSource))
        }
      }
      .recoverWith {
        case e: Exception =>
          val details =
            s"Exception when attempting to receive blob for blob event $blobEventId on destination instance $remoteInstanceUrl"
          LOG.error(details, e)
          val exception = errorRestResponseCategoryService.categorizeNetworkAndRestResponseException(
            e,
            Some(details)
          )
          Future.failed(exception)
      }

  }

}
