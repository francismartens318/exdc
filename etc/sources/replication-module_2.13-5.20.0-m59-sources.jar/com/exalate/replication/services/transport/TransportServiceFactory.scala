package com.exalate.replication.services.transport

import com.exalate.api.domain.connection.{IConnection, SendProtocol}
import com.exalate.api.domain.instance.IInstance
import com.exalate.api.domain.nodeinfo.INodeInfo
import com.exalate.basic.domain.util.SemanticVersionService
import com.exalate.error.services.api.IBugExceptionCategoryService
import com.exalate.replication.services.api.node.ISelfNodeInfoService
import com.exalate.replication.services.api.transport.{ITransportService, ITransportServiceFactory}
import com.exalate.replication.services.transport.v1.rest.local.LocalTransportService
import com.exalate.replication.services.transport.v2_4.RemotePrivateTransportService
import javax.inject.Inject
import play.api.Logger

import scala.util.{Failure, Success, Try}

class TransportServiceFactory @Inject() (
    transportServiceV1: com.exalate.replication.services.transport.v1.TransportService,
    transportServiceV2: com.exalate.replication.services.transport.v2.TransportService,
    localTransportService: LocalTransportService,
    remotePrivateTransportService: RemotePrivateTransportService,
    selfNodeInfoService: ISelfNodeInfoService,
    bugExceptionCategoryService: IBugExceptionCategoryService
) extends ITransportServiceFactory {

  val LOG = Logger("application.services.transport.TransportServiceFactory")

  /** Gets transport service: could be v1.TransportService, v2.TransportService or
    * LocalTransportService, RemotePrivateTransportService
    * @param connection
    * @return
    */
  override def get(connection: IConnection): Try[ITransportService] = {
    val remoteInstance: IInstance = connection.getRemoteInstance
    val remoteInstanceNodeInfo: INodeInfo = remoteInstance.getNodeInfo
    val sendProtocol = connection.getSendProtocol

    if (connection.isLocal) {
      Success(localTransportService)
    } else if (
      remoteInstanceNodeInfo.isPollOnly || Option(sendProtocol).contains(SendProtocol.WAIT_FOR_POLL)
    ) {
      Success(remotePrivateTransportService)
    } else {
      Try {
        val localMinRestVersion = SemanticVersionService.get(selfNodeInfoService.getMinRestVersion)
        val localMaxRestVersion = SemanticVersionService.get(selfNodeInfoService.getMaxRestVersion)
        val remoteMinRestVersion =
          SemanticVersionService.get(remoteInstanceNodeInfo.getMinRestVersion)
        val remoteMaxRestVersion =
          SemanticVersionService.get(remoteInstanceNodeInfo.getMaxRestVersion)
        Option(
          SemanticVersionService.getMaxOverlapVersion(
            localMinRestVersion,
            localMaxRestVersion,
            remoteMinRestVersion,
            remoteMaxRestVersion
          )
        )
      } match {
        case Success(Some(v1)) if v1.getMajor == 1       =>
          Success(transportServiceV1)
        case Success(Some(v2)) if v2.getMajor > 1        =>
          Success(transportServiceV2)
        case Success(Some(unsupportedVersion))           =>
          LOG.error(
            s"Unsupported REST version `$unsupportedVersion` of the destination instance `${remoteInstance.getName}` - can not send sync messages to it"
          )
          val message: String =
            s"Unsupported REST version `$unsupportedVersion` of the remote connection `${connection.getName}` - can not send sync messages to it"
          Failure(bugExceptionCategoryService.generateVersionBugException(message, None))
        case Success(None)                               =>
          LOG.error(
            s"Could not get an intersect REST version for localInstance (rest versions min=`${selfNodeInfoService.getMinRestVersion}` max=`${selfNodeInfoService.getMaxRestVersion}`) and remoteInstance `${remoteInstance.getName}` (rest versions min=`${remoteInstanceNodeInfo.getMinRestVersion}` max=`${remoteInstanceNodeInfo.getMaxRestVersion}`) - can not send sync messages to it"
          )
          val message: String =
            s"Could not get an intersect REST version (rest versions min=`${selfNodeInfoService.getMinRestVersion}` max=`${selfNodeInfoService.getMaxRestVersion}`) and remote connection `${connection.getName}` (rest versions min=`${remoteInstanceNodeInfo.getMinRestVersion}` max=`${remoteInstanceNodeInfo.getMaxRestVersion}`) - can not send sync messages to it"
          Failure(bugExceptionCategoryService.generateVersionBugException(message, None))
        case Failure(noIntersectVersionError: Exception) =>
          LOG.error(
            s"Could not get an intersect REST version for the destination instance `${noIntersectVersionError.getMessage}` - can not send sync messages to it"
          )
          val message: String =
            s"Could not get an intersect REST version for the remote connection `${connection.getName}` - can not send sync messages to it"
          Failure(
            bugExceptionCategoryService.generateVersionBugException(
              message,
              Some(noIntersectVersionError)
            )
          )
      }
    }

  }

}
