package com.exalate.replication.services.transport.v5_1

import java.time.Instant
import com.exalate.api.domain.ExalateErrorReason
import com.exalate.api.domain.connection.IConnection
import com.exalate.api.persistence.relation.IRelationRepository
import com.exalate.error.services.api.{
  IBugExceptionCategoryService,
  IExalateRestErrorResponseCategoryService
}
import com.exalate.replication.controllers.auth.ExalateExternalJwtConstants.{
  JWT_CONNECTION_KEY_PROP,
  MAX_AGE
}
import com.exalate.replication.services.api.transport.v5_1.IConnectionPollClientV5
import com.exalate.replication.services.transport.{ExaToExaRequestFilterFactory, ResponseHandler}
import com.exalate.replication.services.transport.value.{
  ErrorValue,
  ShouldBePolledRequestInfoValue,
  ShouldBePolledRequestValue,
  ShouldBePolledResponseValue
}
import com.exalate.replication.services.transport.wrapper.{ILoggingWsClientFactory, LoggingFnUtils}
import com.exalate.services.api.IMessagesService
import com.exalate.util.UrlUtils
import pdi.jwt.{JwtAlgorithm, JwtJson}
import play.api.Logger
import play.api.libs.json.{JsError, JsSuccess, Json}
import play.api.libs.ws.WSClient

import scala.concurrent.{ExecutionContext, Future}
import scala.util.{Failure, Success}
import com.exalate.replication.services.transport.value.ExaCompFormatters.errorValueFormat
import com.google.inject.Inject

class ConnectionPollClient @Inject() (
    wsClient: WSClient,
    loggingWsClientFactory: ILoggingWsClientFactory,
    bugExceptionCategoryService: IBugExceptionCategoryService,
    connectionRepository: IRelationRepository,
    exaToExaRequestFilterFactory: ExaToExaRequestFilterFactory,
    errorRestResponseCategoryService: IExalateRestErrorResponseCategoryService,
    messagesService: IMessagesService
)(implicit ec: ExecutionContext)
    extends IConnectionPollClientV5 {

  private val SHOULD_POLL_REST_URL = "/rest/issuehub/5.1/poll"

  private val ws = loggingWsClientFactory.create(
    wsClient,
    LoggingFnUtils.logRequestWithBody,
    LoggingFnUtils.logResponseWithBody
  )

  val LOG: Logger = Logger("application.services.transport.rest.v5_1.ConnectionPollClient")

  private def NO_CONNECTION(connectionName: String): String = messagesService
    .translate("com.exalate.connection.notfound", Seq(connectionName))
    .getOrElse(
      s"Connection `$connectionName` not found. Seems like it was removed on the Destination side."
    )

  // POST          /rest/issuehub/5.1/poll/shouldbepolled/connections/search
  override def shouldBePolled(
      remoteUrl: String,
      connections: Seq[IConnection]
  ): Future[ShouldBePolledResponseValue] = {
    val remoteInstanceUrl = remoteUrl
    val finalUrl: String = UrlUtils.concat(
      remoteInstanceUrl,
      SHOULD_POLL_REST_URL,
      "shouldbepolled",
      "connections",
      "search"
    )
    val requestValue = ShouldBePolledRequestValue(
      connections.map { c =>
        val jwtOpt = Option(c.getInvitationSecret)
          .map { invitationSecret =>
            val claim = Json.obj(
              (JWT_CONNECTION_KEY_PROP, c.getName),
              ("exp", Instant.now().plusSeconds(MAX_AGE).toEpochMilli)
            )
            val algo = JwtAlgorithm.HS256
            JwtJson.encode(claim, invitationSecret, algo)
          }
        ShouldBePolledRequestInfoValue(c.getName, jwtOpt)
      }
    )

    LOG.trace(
      s"Checking whether the connections `$requestValue` should be polled on the remote side $remoteInstanceUrl"
    )
    val connection = connections.head
    val requestFilter = exaToExaRequestFilterFactory.createForAnonResource
    val request = ws
      .url(finalUrl)
      .withMethod("POST")
      .addHttpHeaders("Content-Type" -> "application/json")
      .withBody(Json.toJson(requestValue))
      .withRequestFilter(requestFilter)

    request
      .execute()
      .flatMap { response =>
        (new ResponseHandler).handleResponse(response) match {
          case Success(r)            =>
            val jsValue = Json.parse(r.body)
            jsValue.validate[ShouldBePolledResponseValue] match {
              case JsSuccess(result, _) => Future.successful(result)
              case JsError(es)          =>
                val exception =
                  bugExceptionCategoryService.generateJsonIntoValueConvertingFailedBugException(
                    jsValue.toString,
                    "ShouldBePolledResponseValue",
                    Some(JsError.toJson(es).toString())
                  )
                LOG.error(
                  s"Failed to convert JSON `$jsValue` into ShouldBePolledResponseValue",
                  exception
                )
                Future.failed(exception)
            }
          case Failure(e: Exception)
              if response.status == 404 && checkIfNoConnection(response.body) =>
            LOG.error(
              s"Got response ${response.status} from $remoteInstanceUrl while polling list of connections. ${NO_CONNECTION(connection.getName)} - deactivating it."
            )
            connectionRepository.deActivateConnection(connection.getID)
            Future.failed(e)
          case Failure(e: Exception) =>
            Future.failed(e)
        }
      }
      .recoverWith {
        case e: Exception =>
          val details =
            s"Exception while Checking whether the connections `$requestValue` should be polled on the remote side $remoteInstanceUrl"
          LOG.error(details, e)
          val exception = errorRestResponseCategoryService.categorizeNetworkAndRestResponseException(
            e,
            Some(details)
          )
          Future.failed(exception)
      }

  }

  def checkIfNoConnection(body: String): Boolean =
    Json.parse(body).validate[ErrorValue] match {
      case JsSuccess(b, _) => ExalateErrorReason.CONNECTION_NOT_FOUND.name().equals(b.className)
      case _               => false
    }

}
