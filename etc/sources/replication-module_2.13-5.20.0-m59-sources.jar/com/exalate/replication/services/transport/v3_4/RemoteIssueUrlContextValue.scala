package com.exalate.replication.services.transport.v3_4

case class RemoteIssueUrlContextValue(
    remoteIssueUrl: String,
    trimmedSummary: String,
    issueUrn: String,
    issueId: Long
)
