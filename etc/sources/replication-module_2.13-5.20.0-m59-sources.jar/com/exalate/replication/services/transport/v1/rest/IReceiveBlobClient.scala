package com.exalate.replication.services.transport.v1.rest

import akka.stream.scaladsl.Source
import akka.util.ByteString
import com.exalate.api.domain.blob.request.IBlobRequest
import com.google.inject.ImplementedBy

import scala.concurrent.Future

@ImplementedBy(classOf[com.exalate.replication.services.transport.v1.rest.ReceiveBlobClient])
trait IReceiveBlobClient {

  /** /plugins/servlet/exalate/1.0/attachment/:blobid
    */
  def downloadBlob(
      blobId: Long,
      remoteInstanceUrl: String,
      blobRequest: IBlobRequest
  ): Future[Option[Source[ByteString, _]]]

}
