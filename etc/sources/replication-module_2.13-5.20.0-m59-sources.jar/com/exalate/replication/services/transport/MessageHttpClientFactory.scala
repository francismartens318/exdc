package com.exalate.replication.services.transport

import com.exalate.api.domain.instance.IInstance
import com.exalate.replication.services.api.transport.IMessageHttpClientFactory
import com.exalate.replication.services.transport.utils.ExalateVersionCheckerUtils
import com.exalate.replication.services.transport.v1.rest.IMessageHttpClient
import com.exalate.replication.services.transport.v3_4.{MessageHttpClient => MessageHttpClientV3_4}
import com.exalate.replication.services.transport.v5_0.{MessageHttpClient => MessageHttpClientV5_0}
import com.google.inject.Inject

class MessageHttpClientFactory @Inject() (
    messageHttpClientV3_4: MessageHttpClientV3_4,
    messageHttpClientV5_0: MessageHttpClientV5_0
) extends IMessageHttpClientFactory {

  override def get(remoteInstance: IInstance): IMessageHttpClient = {
    val remoteInstanceNodeInfo = remoteInstance.getNodeInfo
    if (
      ExalateVersionCheckerUtils.isExalateRestVersionEncodingCompatible(
        remoteInstanceNodeInfo.getMaxRestVersion
      )
    ) {
      messageHttpClientV5_0
    } else {
      messageHttpClientV3_4
    }
  }

}
