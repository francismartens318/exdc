package com.exalate.replication.services.transport.v1.rest

import com.exalate.domain.values.license.{EvaluationValue, GetLicenseResult}
import com.exalate.error.services.api.IExalateRestErrorResponseCategoryService
import com.exalate.replication.services.transport.ResponseHandler
import com.exalate.replication.services.transport.value.ExaCompFormatters.getLicenseValueFormat
import play.api.libs.json.{JsError, JsSuccess, JsValue, Json}
import play.api.libs.ws.WSClient
import play.api.{Configuration, Logger}

import javax.inject.Inject
import scala.concurrent.{ExecutionContext, Future}

@deprecated
class EvaluationClient @Inject() (
    val ws: WSClient,
    val configuration: Configuration,
    errorRestResponseCategoryService: IExalateRestErrorResponseCategoryService
)(implicit ec: ExecutionContext)
    extends IEvaluationClient {

  val LOG = Logger("application.services.transport.v1.rest.EvaluationClient")

  private val EVALUATION_PATH: String = configuration
    .getOptional[String]("exalate.license.evaluation.url")
    .getOrElse(
      "https://licensegen.exalate.com/rest/scriptrunner/latest/custom/GenerateEvaluationKey"
    )

  private val GET_LICENSE_PATH: String = configuration
    .getOptional[String]("exalate.license.getlicense.url")
    .getOrElse(
      "https://licensegen.exalate.com/rest/scriptrunner/latest/custom/fetchLatestLicenseKey"
    )

  /** POST https://licensegen.exalate.com/rest/scriptrunner/latest/custom/GenerateEvaluationKey
    * @param evaluationValue
    * @return
    */
  @Override
  def postEvaluationDetails(evaluationValue: EvaluationValue): Future[JsValue] = {
    val jsValue = Json.toJson(evaluationValue)
    LOG.debug(s"Posting evaluation details: $jsValue to $EVALUATION_PATH")
    ws.url(EVALUATION_PATH)
      .addHttpHeaders("Content-Type" -> "application/json")
      .post(jsValue)
      .flatMap { r =>
        LOG.debug(s"Got response for postEvaluationDetails: ${r.status} with body: ${r.body}")
        Future.fromTry((new ResponseHandler).handleResponse(r)).map(r => Json.parse(r.body))
      }
      .recoverWith {
        case e: Exception =>
          val details =
            s"""Exception when trying to post details for evaluation license. Error message: ${e.getMessage}"""
          LOG.error(details, e)
          val exception = errorRestResponseCategoryService.categorizeNetworkAndRestResponseException(
            e,
            Some(details)
          )
          Future.failed(exception)
      }
  }

  /** GET https://licensegen.exalate.com/rest/scriptrunner/latest/custom/fetchLatestLicenseKey
    * @param instanceUid
    * @return
    */
  def getLicense(instanceUid: String): Future[Option[GetLicenseResult]] = {
    LOG.debug(s"Getting license key from $GET_LICENSE_PATH with instanceUID $instanceUid")

    ws.url(GET_LICENSE_PATH)
      .withQueryStringParameters("instanceUID" -> instanceUid)
      .withHttpHeaders("Content-Type" -> "application/json")
      .get()
      .map { r =>
        LOG.debug(s"Got response from getLicense: ${r.status}, ${r.body}")
        Json.parse(r.body).validate[GetLicenseResult] match {
          case JsSuccess(getLicenseResult: GetLicenseResult, _) => Some(getLicenseResult)
          case e: JsError                                       =>
            LOG.error("Exception when trying to validate GetLicenseResult.")
            None
        }
      }
      .recoverWith {
        case e: Exception =>
          val details =
            s"""Exception when trying to get license key for instanceUID $instanceUid. Error message: ${e.getMessage}"""
          LOG.error(details, e)
          val exception = errorRestResponseCategoryService.categorizeNetworkAndRestResponseException(
            e,
            Some(details)
          )
          Future.failed(exception)
      }
  }

}
