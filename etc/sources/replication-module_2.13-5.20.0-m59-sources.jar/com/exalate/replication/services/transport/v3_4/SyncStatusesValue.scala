package com.exalate.replication.services.transport.v3_4

case class SyncStatusesValue(syncStatuses: Seq[SyncStatusValue])
