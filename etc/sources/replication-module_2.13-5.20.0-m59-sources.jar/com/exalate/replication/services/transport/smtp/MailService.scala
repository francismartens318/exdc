package com.exalate.replication.services.transport.smtp

import com.exalate.api.domain.IError
import com.exalate.api.persistence.exalateadmin.IExalateAdminRepository
import com.exalate.replication.services.api.node.lifecycle.ILifecycleInfoService
import com.exalate.replication.services.api.transport.smtp.IMailService
import play.api.{Configuration, Logger}

import java.sql.Timestamp
import java.time.Instant
import java.time.temporal.ChronoUnit
import javax.inject.{Inject, Singleton}
import scala.concurrent.{ExecutionContext, Future}

@Singleton
class MailService @Inject() (
    rendererService: MailBodyRenderer,
    lifecycleInfoService: ILifecycleInfoService,
    exalateAdminRepository: IExalateAdminRepository,
    smtpConfigService: SmtpConfigService,
    configuration: Configuration
)(implicit ec: ExecutionContext)
    extends IMailService {

  private val LOG = Logger("application.services.transport.smtp.MailService")

  lazy val N_DAYS: Int = configuration.getOptional[Int]("exalatemapper.archive.days").getOrElse(30)

  lazy val N_WARNING_DAYS: Int =
    configuration.getOptional[Int]("exalatemapper.inactivity.warning.days").getOrElse(20)

  override def sendErrorMail(error: IError): Future[None.type] = {
    LOG.info(
      s"preparing to send error notification email for error with id `${error.getId}`${Option(error.getIssueKey)
          .map(issueKey => s" for local issue `$issueKey`")
          .getOrElse("")}${Option(error.getRemoteIssueKey).map(issueKey => s" for remote issue `$issueKey`").getOrElse("")}"
    )
    val now = Instant.now()
    val shouldSendEmailFuture =
      lifecycleInfoService.get.map(lv => (lv.lastErrorEmailDate, lv.uninstallDate)).map {
        case (_, Some(_))                => false
        case (Some(lastErrorDate), None) =>
          LOG.trace(
            s"Checking if error email should be sent for error ${error.getId}. Last error date is $lastErrorDate. SMTP_BACKOFF is set to: ${smtpConfigService.getSmtpBackOff()} minutes."
          )
          val timeAfterErrorEmail =
            lastErrorDate.toInstant.plusSeconds(smtpConfigService.getSmtpBackOff() * 60)
          timeAfterErrorEmail.compareTo(now) < 0
        case _                           => true
      }
    shouldSendEmailFuture.flatMap { should =>
      if (should) {
        (for {
          params <- Future.fromTry(smtpConfigService.getConfigurationParameters)
          emailAddresses <- getEmailAddressesToNotify
          (subject, htmlBody) <- rendererService.renderMailBody(error)
        } yield {
          LOG.info(
            s"SMTP parameters for error with id `${error.getId}`${Option(error.getIssueKey)
                .map(issueKey => s" for local issue `$issueKey`")
                .getOrElse("")}${Option(error.getRemoteIssueKey)
                .map(issueKey => s" for remote issue `$issueKey`")
                .getOrElse("")} obtained successfully. host: ${params.hostName}, port: ${params.portOpt}, tls: ${params.tls}, from: ${params.from} : params: `$params`"
          )

          LOG.info(
            s"preparing to send error notification email for error with id `${error.getId}`${Option(
                error.getIssueKey
              ).map(issueKey => s" for local issue `$issueKey`").getOrElse("")}${Option(error.getRemoteIssueKey)
                .map(issueKey => s" for remote issue `$issueKey`")
                .getOrElse("")}: emailAddresses: `$emailAddresses`"
          )
          emailAddresses.foreach { address =>
            val email = smtpConfigService.getEmailTemplate(params, subject, htmlBody)
            email.addTo(address)
            email.send()
          }
        })
          .flatMap(_ => lifecycleInfoService.updateLastEmailSentDate(Timestamp.from(now)))
          .recover {
            case e: Exception =>
              val localIssueMsg =
                Option(error.getIssueKey).map(i => s" local issue urn ${i.getURN}").getOrElse("")
              val remoteIssueMsg = Option(error.getRemoteIssueKey)
                .map(i => s" remote issue urn ${i.getURN}")
                .getOrElse("")
              LOG.error(
                s"Email for error with id `${error.getId}`$localIssueMsg$remoteIssueMsg, could not been sent. ${e.getMessage}",
                e
              )
              None
          }
      } else {
        Future.successful(None)
      }
    }
  }

  override def sendLicenseMail(startOfCurrentPeriod: Timestamp): Future[None.type] = {
    val now = Instant.now()

    lifecycleInfoService.get
      .map(x =>
        x.lastLicenseEmailDate.isEmpty || x.lastLicenseEmailDate.exists(lastEmailDate =>
          // comparing lastEmailDate with startOfCurrentPeriod to send only 1 mail per period
          new Timestamp(lastEmailDate.getTime).before(startOfCurrentPeriod)
        )
      )
      .flatMap(shouldSendEmail =>
        if (shouldSendEmail) {
          (for {
            params <- Future.fromTry(smtpConfigService.getConfigurationParameters)
            emailAddresses <- getEmailAddressesToNotify
            (subject, htmlBody) <- rendererService.renderLicenseMailBody()
          } yield {
            LOG.info(
              s"preparing to send license notification email: emailAddresses: `$emailAddresses`"
            )
            emailAddresses.foreach { address =>
              val email = smtpConfigService.getEmailTemplate(params, subject, htmlBody)
              email.addTo(address)
              email.send()
            }
          })
            .flatMap(_ => lifecycleInfoService.updateLastLicenseEmailSentDate(Timestamp.from(now)))
            .recover {
              case e: Exception =>
                LOG.error(s"Email for license email, could not been sent. ${e.getMessage}", e)
                None
            }
        } else {
          Future.successful(None)
        }
      )
  }

  override def sendArchiveWarningMail(archiveWarningDays: Int): Future[None.type] = {
    val now = Instant.now()

    lifecycleInfoService.get
      .map(x =>
        x.lastArchiveWarningEmailDate.isEmpty || x.lastArchiveWarningEmailDate.exists(
          lastArchiveWarningEmailDate =>
            // comparing lastArchiveWarningEmailDate with start of the last Warning Period to send only 1 email per the period
            lastArchiveWarningEmailDate.toInstant
              .isBefore(
                now
                  .minus(N_DAYS - N_WARNING_DAYS - archiveWarningDays, ChronoUnit.DAYS)
                  .truncatedTo(ChronoUnit.DAYS)
              )
        )
      )
      .flatMap(shouldSendEmail =>
        if (shouldSendEmail) {
          (for {
            params <- Future.fromTry(smtpConfigService.getConfigurationParameters)
            emailAddresses <- getEmailAddressesToNotify
            (subject, htmlBody) <- rendererService.renderArchiveWarningMailBody(archiveWarningDays)
          } yield {
            LOG.info(
              s"preparing to send archive warning email: emailAddresses: `$emailAddresses`"
            )
            emailAddresses.foreach { address =>
              val email = smtpConfigService.getEmailTemplate(params, subject, htmlBody)
              email.addTo(address)
              email.send()
            }
          })
            .flatMap(_ =>
              lifecycleInfoService.updateLastArchiveWarningEmailSentDate(Timestamp.from(now))
            )
            .recover {
              case e: Exception =>
                LOG.error(s"Email for archive warning could not been sent. ${e.getMessage}", e)
                None
            }
        } else {
          Future.successful(None)
        }
      )
  }

  def getEmailAddressesToNotify: Future[Seq[String]] =
    exalateAdminRepository.findAdmins().map(_.map(_.getEmailAddress))

}
