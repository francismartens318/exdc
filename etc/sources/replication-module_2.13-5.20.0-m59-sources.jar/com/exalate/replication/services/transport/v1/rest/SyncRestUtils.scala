package com.exalate.replication.services.transport.v1.rest

import com.exalate.api.domain.ErrorReason
import com.exalate.api.domain.blob.BlobErrorReason
import com.exalate.api.domain.twintrace.{TraceAction, TraceType}
import com.exalate.replication.services.transport.value.ExaCompFormatters._
import com.exalate.replication.services.transport.value._
import play.api.libs.functional.syntax._
import play.api.libs.json._

object SyncRestUtils {

  @deprecated("use formats from companion objects")
  object Implicits {

    implicit val issueKeyValueWrites: Writes[IssueKeyValue] = (o: IssueKeyValue) => {
      var seq = Seq(("id", Json.toJson(o.id)))
      seq = o.idStr match {
        case Some(idStr) => seq :+ ("idStr", Json.toJson(idStr))
        case _           => seq
      }
      seq = seq :+ ("urn", Json.toJson(o.urn))
      seq = o.entityType match {
        case Some(entityType) => seq :+ ("entityType", Json.toJson(entityType))
        case _                => seq
      }
      seq = o.fieldValues match {
        case Some(fieldValues) => seq :+ ("fieldValues", Json.toJson(fieldValues))
        case _                 => seq
      }
      JsObject(seq)
    }

    implicit val replicaValueWrites: Writes[ReplicaValue] = (o: ReplicaValue) =>
      Json.obj(
        "summary" -> o.summary,
        "encodedPayload" -> o.encodedPayload,
        "issueKey" -> o.issueKey
      )

    implicit val BlobMetadataValueWrites: Writes[BlobMetadataValue] = (o: BlobMetadataValue) =>
      Json.obj(
        "blobId" -> o.blobId,
        "blobIdStr" -> o.blobIdStr,
        "checksum" -> o.checksum
      )

    implicit val TraceValueWrites: Writes[TraceValue] = (t: TraceValue) =>
      Json.obj(
        "type" -> t.`type`.name(),
        "localId" -> Option(t.localId),
        "remoteId" -> Option(t.remoteId),
        "action" -> t.action.name(),
        "toSynchronize" -> t.toSynchronize
      )

    implicit val requestValueWrites: Writes[RequestValue] = (o: RequestValue) => {
      val connectContextOpt = o.connectContext.map { cc =>
        Json.obj(
          "synchronizeComments" -> JsBoolean(cc.synchronizeComments),
          "synchronizeAttachments" -> JsBoolean(cc.synchronizeAttachments),
          "synchronizeWorklogs" -> JsBoolean(cc.synchronizeWorklogs),
          "triggerSyncEvent" -> JsBoolean(cc.triggerSyncEvent),
          "triggerUpdate" -> JsBoolean(cc.triggerUpdate.getOrElse(false)),
          "triggerUnexalate" -> JsBoolean(cc.triggerUnexalate.getOrElse(false))
        )
      }

      val subscriptionContextValueOpt = o.subscriptionContext.map { s =>
        Json.obj(
          "withNodeSubscription" -> JsBoolean(s.withNodeSubscription),
          "withExalateSubscription" -> JsBoolean(s.withExalateSubscription)
        )
      }

      Json.obj(
        "syncEventId" -> o.syncEventId,
        "syncEventNumber" -> o.syncEventNumber,
        "relationKey" -> o.relationKey,
        "replica" -> o.replica,
        "connectIssueUrn" -> o.connectIssueUrn,
        "unexalateRemoteIssueUrn" -> o.unexalateRemoteIssueUrn,
        // TODO refactor to use format + add connectContextOpt
        "deletedRemoteIssueUrn" -> o.deletedRemoteIssueUrn,
        "syncedTo" -> o.syncedTo,
        "blobMetadataList" -> o.blobMetadataList,
        "twinTraceId" -> o.twinTraceId,
        "payed" -> o.payed,
        "subscriptionContext" -> subscriptionContextValueOpt,
        "connectContext" -> connectContextOpt,
        "traces" -> o.traces,
        "syncType" -> o.syncType
      )
    }

    implicit val blobResponseValueWrites: Writes[BlobResponseValue] = (b: BlobResponseValue) =>
      Json.obj(
        "syncEventId" -> b.syncEventId,
        "blobEventId" -> b.blobEventId,
        "relationKey" -> b.relationKey,
        "blobMetadata" -> b.blobMetadata
      )

    implicit val responseValueWrites: Writes[SyncResponseValue] = (r: SyncResponseValue) =>
      Json.obj(
        "syncEventId" -> r.syncEventId,
        "relationKey" -> r.relationKey,
        "sourceIssueKey" -> r.sourceIssueKey,
        "replica" -> r.replica,
        "traces" -> r.traces,
        "twinTraceId" -> r.twinTraceId,
        "syncType" -> r.syncType
      )

    implicit val errorResponseValueWrites: Writes[ErrorResponseValue] = (e: ErrorResponseValue) =>
      Json.obj(
        "syncEventId" -> e.syncEventId,
        "relationKey" -> e.relationKey,
        "sourceIssueKey" -> e.sourceIssueKey,
        "message" -> e.message,
        "errorReason" -> e.errorReason
      )

    implicit val blobErrorResponseValueWrites: Writes[BlobErrorResponseValue] =
      (b: BlobErrorResponseValue) =>
        Json.obj(
          "syncEventId" -> b.syncEventId,
          "blobEventId" -> b.blobEventId,
          "blobId" -> b.blobId,
          "blobIdStr" -> b.blobIdStr,
          "relationKey" -> b.relationKey,
          "sourceIssueKey" -> b.sourceIssueKey,
          "errorMessage" -> b.errorMessage,
          "blobErrorReason" -> b.blobErrorReason.name
        )

    implicit val ErrorValueWrites: Writes[ErrorValue] = (e: ErrorValue) =>
      Json.obj(
        "className" -> e.className,
        "message" -> e.message
      )

    implicit val BlobRequestValueWrites: Writes[BlobRequestValue] = (o: BlobRequestValue) =>
      Json.obj(
        "relationKey" -> o.relationKey,
        "blobEventId" -> o.blobEventId,
        "syncEventId" -> o.syncEventId,
        "blobMetadata" -> o.blobMetadata
      )

    implicit val errorValueReads: Reads[ErrorValue] = (
      (JsPath \ "className").read[String] and
        (JsPath \ "message").read[String]
    )(ErrorValue.apply _)

    implicit val issueKeyValueRead: Reads[IssueKeyValue] = (
      (JsPath \ "id").readNullable[Long] and
        (JsPath \ "idStr").readNullable[String] and
        (JsPath \ "urn").read[String] and
        (JsPath \ "entityType").readNullable[String] and
        (JsPath \ "fieldValues").readNullable[String]
    )(IssueKeyValue.apply _)

    implicit val replicaValueRead: Reads[ReplicaValue] = (
      (JsPath \ "summary").readNullable[String] and
        (JsPath \ "encodedPayload").read[String] and
        (JsPath \ "issueKey").read[IssueKeyValue]
    )(ReplicaValue.apply _)

    implicit val traceTypeRead: Reads[TraceType] = {
      case JsString(traceTypeString) =>
        Some(traceTypeString)
          .map(tString => TraceType.valueOf(tString))
          .map(t => JsSuccess[TraceType](t))
          .getOrElse(JsError(s"Can not find the trace type for $traceTypeString "))
      case _                         => JsError("Can not read a trace type from a non-string thing")
    }

    implicit val traceTypeWrites: Writes[TraceType] = (t: TraceType) => JsString(t.name())

    implicit val traceActionRead: Reads[TraceAction] = {
      case JsString(traceActionString) =>
        Some(traceActionString)
          .map(tString => TraceAction.valueOf(tString))
          .map(t => JsSuccess[TraceAction](t))
          .getOrElse(JsError(s"Can not find the trace action for $traceActionString "))
      case _ => JsError("Can not read a trace action from a non-string thing")
    }

    implicit val traceActionWrites: Writes[TraceAction] = (t: TraceAction) => JsString(t.name())

    implicit val traceValueRead: Reads[TraceValue] = (
      (JsPath \ "type").read[TraceType] and
        (JsPath \ "localId").readNullable[String] and
        (JsPath \ "remoteId").readNullable[String] and
        (JsPath \ "action").read[TraceAction] and
        (JsPath \ "toSynchronize").read[Boolean]
    )(TraceValue.apply _)

    implicit val SyncResponseValueRead: Reads[SyncResponseValue] = (
      (JsPath \ "syncEventId").read[Int] and
        (JsPath \ "relationKey").read[String] and
        (JsPath \ "sourceIssueKey").read[IssueKeyValue] and
        (JsPath \ "replica").readNullable[ReplicaValue] and
        (JsPath \ "traces").read[Seq[TraceValue]] and
        (JsPath \ "twinTraceId").readNullable[Int] and
        (JsPath \ "syncType").readNullable[String]
    )(SyncResponseValue.apply _)

    implicit val blobMetadataValueRead: Reads[BlobMetadataValue] =
      (
        (JsPath \ "blobId").readNullable[Long] and
          (JsPath \ "blobIdStr").readNullable[String] and
          (JsPath \ "checksum").read[String]
      )(BlobMetadataValue.apply _)

    implicit val blobResponseValueRead: Reads[BlobResponseValue] = (
      (JsPath \ "relationKey").read[String] and
        (JsPath \ "syncEventId").read[Int] and
        (JsPath \ "blobEventId").readNullable[Int] and
        (JsPath \ "blobMetadata").read[BlobMetadataValue]
    )(BlobResponseValue.apply _)

    implicit val connectContextValueRead: Reads[ConnectContextValue] = (
      (JsPath \ "synchronizeComments").read[Boolean] and
        (JsPath \ "synchronizeAttachments").read[Boolean] and
        (JsPath \ "synchronizeWorklogs").read[Boolean] and
        (JsPath \ "triggerSyncEvent").read[Boolean] and
        (JsPath \ "triggerUpdate").readNullable[Boolean] and
        (JsPath \ "triggerUnexalate").readNullable[Boolean]
    )(ConnectContextValue.apply _)

    implicit val subscriptionContextValueRead: Reads[SubscriptionContextValue] = (
      (JsPath \ "withNodeSubscription").read[Boolean] and
        (JsPath \ "withExalateSubscription").read[Boolean]
    )(SubscriptionContextValue.apply _)

    implicit val requestValueRead: Reads[RequestValue] = (
      (JsPath \ "syncEventId").read[Int] and
        (JsPath \ "syncEventNumber").read[Long] and
        (JsPath \ "relationKey").read[String] and
        (JsPath \ "replica").read[ReplicaValue] and
        (JsPath \ "syncedTo").readNullable[IssueKeyValue] and
        (JsPath \ "blobMetadataList").read[Seq[BlobMetadataValue]] and
        (JsPath \ "connectIssueUrn").readNullable[String] and
        (JsPath \ "unexalateRemoteIssueUrn").readNullable[String] and
        (JsPath \ "connectContext").readNullable[ConnectContextValue] and
        (JsPath \ "deletedRemoteIssueUrn").readNullable[String] and
        (JsPath \ "traces").read[Seq[TraceValue]] and
        (JsPath \ "twinTraceId").readNullable[Int] and
        (JsPath \ "payed").read[Boolean] and
        (JsPath \ "subscriptionContext").readNullable[SubscriptionContextValue] and
        (JsPath \ "syncType").readNullable[String]
    )(RequestValue.apply _)

    implicit val blobRequestValueRead: Reads[BlobRequestValue] = (
      (JsPath \ "relationKey").read[String] and
        (JsPath \ "syncEventId").read[Int] and
        (JsPath \ "blobEventId").readNullable[Int] and
        (JsPath \ "blobMetadata").read[BlobMetadataValue]
    )(BlobRequestValue.apply _)

    implicit object BlobErrorReasonReads extends Reads[BlobErrorReason] {

      def reads(json: JsValue): JsResult[BlobErrorReason] = json match {
        case JsString(s) =>
          Option(BlobErrorReason.valueOf(json.as[String]))
            .map(JsSuccess(_))
            .getOrElse(JsError(s"Could not find a blob error reason for $s"))

        case _ => JsError(Seq(JsPath() -> Seq(JsonValidationError("error.expected.jsstring"))))
      }

    }

    implicit object BlobErrorReasonWrites extends Writes[BlobErrorReason] {
      def writes(o: BlobErrorReason): JsValue = JsString(o.name)
    }

    implicit val BlobErrorResponseValueRead: Reads[BlobErrorResponseValue] = (
      (JsPath \ "syncEventId").read[Int] and
        (JsPath \ "blobEventId").readNullable[Int] and
        (JsPath \ "relationKey").read[String] and
        (JsPath \ "blobId").readNullable[Long] and
        (JsPath \ "blobIdStr").readNullable[String] and
        (JsPath \ "sourceIssueKey").read[IssueKeyValue] and
        (JsPath \ "errorMessage").read[String] and
        (JsPath \ "blobErrorReason").read[BlobErrorReason]
    )(BlobErrorResponseValue.apply _)

    implicit object ErrorReasonReads extends Reads[ErrorReason] {

      def reads(json: JsValue): JsResult[ErrorReason] = json match {
        case JsString(s) =>
          Option(ErrorReason.valueOf(json.as[String]))
            .map(JsSuccess(_))
            .getOrElse(JsError(s"Could not find an error reason for $s"))

        case _ => JsError(Seq(JsPath() -> Seq(JsonValidationError("error.expected.jsstring"))))
      }

    }

    implicit val ErrorResponseValueRead: Reads[ErrorResponseValue] = (
      (JsPath \ "syncEventId").read[Int] and
        (JsPath \ "relationKey").read[String] and
        (JsPath \ "sourceIssueKey").read[IssueKeyValue] and
        (JsPath \ "message").read[String] and
        (JsPath \ "errorReason").read[String]
    )(ErrorResponseValue.apply _)

  }

}
