package com.exalate.replication.services.transport.utils

import com.exalate.api.domain.connection._
import com.exalate.api.domain.editor.error.{EditorErrorSide, ErrorLocationType}
import com.exalate.api.domain.node.NodeType
import com.exalate.api.persistence.mappings.IMappingsRepository
import com.exalate.api.persistence.scopes.IScopesRepository
import com.exalate.api.persistence.twintrace.ITwinTraceRepository
import com.exalate.basic.domain.connection.{ConnectionIssueTrackerSettings, NonPersistentConnection}
import com.exalate.domain.editor.EditorContextProgress.EditorContextProgress
import com.exalate.domain.editor.error._
import com.exalate.domain.editor.mappings.{MapValue, MappingFieldTypeValue, MappingValue}
import com.exalate.domain.editor.scopes.{FieldValue, QueryValue, ScopeValue, SingleSideScopeValue}
import com.exalate.domain.values.connection._
import com.exalate.generic.services.api.INodeTypeProvider
import com.exalate.replication.services.api.config.IBasicConnectionService
import com.exalate.replication.services.api.transport.IConnectionValueHelper
import com.exalate.replication.services.replication.oauth.OAuthService
import com.exalate.replication.services.transport.v1.rest.NodeInfoProvider
import com.exalate.replication.services.transport.value.helpers.NodeInfoValueHelper
import com.google.inject.Inject
import play.api.libs.json.Json

import java.util
import scala.collection.JavaConverters
import scala.concurrent.{ExecutionContext, Future}

class ConnectionValueHelper @Inject() (
    nodeInfoProvider: NodeInfoProvider,
    nodeTypeProvider: INodeTypeProvider,
    scopesRepository: IScopesRepository,
    mappingsRepository: IMappingsRepository,
    twinTraceRepository: ITwinTraceRepository,
    basicConnectionService: IBasicConnectionService,
    oAuthService: OAuthService
)(implicit ec: ExecutionContext)
    extends IConnectionValueHelper {
  private lazy val nodeType = nodeTypeProvider.getNodeType

  private val DEFAULT_DATA_FILTER: String =
    "replica.key            = issue.key\n" + "replica.assignee       = issue.assignee \n" + "replica.reporter       = issue.reporter\n" + "replica.summary        = issue.summary\n" + "replica.description    = issue.description\n" + "replica.comments       = issue.comments\n" + "replica.resolution     = issue.resolution\n" + "replica.status         = issue.status\n" + "replica.attachments    = issue.attachments\n" + "replica.project        = issue.project"

  private val DEFAULT_CREATE_PROCESSOR: String =
    "   //Set project key from source issue, if not found set a default\n" +
      "issue.projectKey   = nodeHelper.getProject(replica.project?.key)?.key ?: \"TEST\"\n" +
      "//Set type name from source issue, if not found set a default\n" +
      "issue.typeName     = nodeHelper.getIssueType(replica.type?.name, issue.projectKey)?.name ?: \"Task\"\n" +
      "issue.summary      = replica.summary\n" +
      "issue.description  = replica.description\n" +
      "issue.comments     = commentHelper.mergeComments(issue, replica)\n" +
      "issue.attachments  = attachmentHelper.mergeAttachments(issue, replica)";

  private val DEFAULT_CHANGE_PROCESSOR: String =
    "issue.summary          = replica.summary\n" + "issue.description  = replica.description\n" + "issue.comments     = commentHelper.mergeComments(issue, replica)\n" + "issue.attachments  = attachmentHelper.mergeAttachments(issue, replica)"

  private val DEFAULT_INCOMING_PROCESSOR: String = "if(firstSync){\n" +
    "   //Set project key from source issue, if not found set a default\n" +
    "   issue.projectKey   = nodeHelper.getProject(replica.project?.key)?.key ?: \"TEST\"\n" +
    "   //Set type name from source issue, if not found set a default\n" +
    "   issue.typeName     = nodeHelper.getIssueType(replica.type?.name, issue.projectKey)?.name ?: \"Task\"\n" +
    "}\n" +
    "issue.summary      = replica.summary\n" +
    "issue.description  = replica.description\n" +
    "issue.comments     = commentHelper.mergeComments(issue, replica)\n" +
    "issue.attachments  = attachmentHelper.mergeAttachments(issue, replica)";

  override def toInstanceAndRelationOnConnection(rcv: ConnectionValue): INonPersistentConnection =
    toInstanceAndRelationWithoutSecret(rcv)

  /** Converts ConnectionValue to INonPersistentConnection
    * @param rcv
    *   ConnectionValue
    * @return
    */
  private def toInstanceAndRelationWithoutSecret(rcv: ConnectionValue): INonPersistentConnection = {

    val syncRules = rcv.syncRules
    val communication = rcv.communication

    val connection: INonPersistentConnection = getDefaultWithCredentials(
      communication.proxyUsername.orNull,
      communication.proxyPassword.orNull,
      authenticationRequired = false
    )
    connection.setName(rcv.name)
    rcv.status.foreach(s => connection.setStatus(ConnectionStatus.valueOf(s)))
    connection.setDescription(rcv.description.orNull)
    connection.setIsLocal(rcv.isLocal.getOrElse(false))
    connection.setSendProtocol(SendProtocol.valueOf(communication.sendProtocol))
    connection.setReceiveProtocol(communication.receiveProtocol.map(ReceiveProtocol.valueOf).orNull)
    connection.setLocalUrl(communication.localUrl.orNull)
    connection.setDataFilter(syncRules.flatMap(_.dataFilter).getOrElse(DEFAULT_DATA_FILTER))
    connection.setPostExalateProcessor(syncRules.flatMap(_.postExalateProcessor).getOrElse(""))
    connection.setChangeProcessor(
      syncRules.flatMap(_.changeProcessor).getOrElse(DEFAULT_CHANGE_PROCESSOR)
    )
    connection.setCreateProcessor(
      syncRules.flatMap(_.createProcessor).getOrElse(DEFAULT_CREATE_PROCESSOR)
    )
    connection.setIncomingProcessor(
      syncRules.flatMap(_.incomingProcessor).getOrElse(DEFAULT_INCOMING_PROCESSOR)
    )
    connection.setInvitationStatus(
      rcv.invitationStatus.map(InvitationStatus.valueOf).getOrElse(InvitationStatus.PENDING)
    )

    val createSyncPanelLink = syncRules
      .flatMap(_.linkType)
      .forall(a => if (a.equals("SYNC_PANEL") || a.equals("BOTH")) true else false)
    val createLinks = syncRules
      .flatMap(_.linkType)
      .forall(a => if (a.equals("REMOTE_ISSUE_LINK") || a.equals("BOTH")) true else false)

    val relationTrackerSettings: IConnectionIssueTrackerSettings =
      new ConnectionIssueTrackerSettings(
        -1,
        nodeType,
        createLinks.asInstanceOf[java.lang.Boolean],
        createSyncPanelLink.asInstanceOf[java.lang.Boolean],
        null,
        syncRules.flatMap(_.hpqcProject).orNull,
        syncRules.flatMap(_.hpqcDomain).orNull,
        syncRules.flatMap(_.hpqcLinkField).orNull,
        syncRules.flatMap(_.fieldValues).map(s => JavaConverters.mapAsJavaMap(s)).orNull
      )

    connection.setTrackerSettings(relationTrackerSettings)

    val nonPersistentInstance = ConnectionValue.toNonPersistentInstance(rcv)
    connection.setRemoteInstance(nonPersistentInstance)

    rcv.mode.foreach(connection.setMode)

    connection.setLocalInstanceName(rcv.localInstanceName.getOrElse(rcv.name))
    syncRules
      .flatMap(_.mainFieldInfo)
      .map(Json.toJson(_).toString())
      .foreach(mainFileInfoStr => connection.setSyncMainFieldInfo(mainFileInfoStr))

    connection

  }

  /** Converts IConnection to ConnectionValue
    * @param connection
    * @return
    *   ConnectionValue
    */
  override def toConnectionValue(connection: IConnection): Future[ConnectionValue] =
    toConnectionValue(connection, Nil)

  /** Converts IConnection with provided editor errors to ConnectionValue
    * @param connection
    * @param editorErrors
    *   seq of editor errors: Scopes & Mappings
    * @param editorContextProgress
    * @return
    *   ConnectionValue
    */
  // TODO: remove trackerSettings.getFieldValues
  override def toConnectionValue(
      connection: IConnection,
      editorErrors: Seq[EditorError],
      editorContextProgress: Option[EditorContextProgress]
  ): Future[ConnectionValue] = {

    val linkType = Option(connection.getTrackerSettings).map(a =>
      (
        Option(a.getCreateLinks).exists(_.asInstanceOf[Boolean]),
        Option(a.getCreateSyncPanelLinks).exists(_.asInstanceOf[Boolean])
      )
    ) match {
      case None                 => "NONE"
      case Some((true, true))   => "BOTH"
      case Some((false, true))  => "SYNC_PANEL"
      case Some((true, false))  => "REMOTE_ISSUE_LINK"
      case Some((false, false)) => "NONE"
    }
    val mainFieldInfoValue: Option[MainFieldInfoValue] =
      Option(connection.getSyncMainFieldInfo).flatMap(Json.parse(_).asOpt[MainFieldInfoValue])
    val syncRulesValue = SyncRulesValue(
      Option(connection.getDataFilter),
      Option(connection.getCreateProcessor),
      Option(connection.getChangeProcessor),
      connection.getVersion,
      Option(connection.getIncomingProcessor),
      Option(connection.getPostExalateProcessor),
      Option(connection.getTrackerSettings).flatMap(t => Option(t.getHpqcDomain)),
      Option(connection.getTrackerSettings).flatMap(t => Option(t.getHpqcProject)),
      Option(connection.getTrackerSettings).flatMap(t => Option(t.getIssueLinkFieldName)),
      Option(linkType),
      Option(JavaConverters.mapAsScalaMap(connection.getTrackerSettings.getFieldValues).toMap),
      mainFieldInfoValue
    )

    val remoteInstanceOpt = Option(connection.getRemoteInstance)
    for {
      localNodeInfoValue <- nodeInfoProvider.get
      stats <- twinTraceRepository.getStats(connection)
      // creating default visual rules for Basic Connection
      scopes <-
        if (connection.isBasic)
          basicConnectionService.generateDefaultScopeRules(connection)
        else
          getScopeValueByConnectionId(Option(connection.getID), editorErrors)
      mappings <-
        if (connection.isBasic)
          basicConnectionService.generateDefaultMappingRules(connection)
        else
          getMappingsByConnectionId(Option(connection.getID), editorErrors)
    } yield {
      val communication = CommunicationValue(
        connection.getSendProtocol.name,
        Option(connection.getReceiveProtocol).map(_.name),
        Option(connection.getLocalUrl),
        remoteInstanceOpt.flatMap(i => Option(i.getUrl)).map(_.toExternalForm),
        remoteInstanceOpt.flatMap(i => Option(i.getIssueTrackerUrl)).map(_.toExternalForm),
        Option(localNodeInfoValue),
        remoteInstanceOpt
          .flatMap(i => Option(i.getNodeInfo))
          .flatMap(ni => Option(NodeInfoValueHelper.toNodeInfoValue(ni))),
        Option(connection.getRemoteUsername),
        Option(connection.getRemotePassword)
      )
      ConnectionValue(
        Option(connection.getID),
        connection.getName,
        Option(connection.getMode),
        Option(connection.getStatus.name),
        Option(connection.getInvitationStatus.name),
        Option(connection.getDescription),
        Some(syncRulesValue),
        communication,
        Option(connection.isLocal),
        Option(connection.getLocalInstanceName),
        Option(connection.getRemoteInstance.getName),
        scopes,
        mappings,
        Some(stats),
        getMissingMappingEditorErrors(editorErrors),
        editorContextProgress.map(_.toString),
        Option(connection.isManagedRemotely)
      )
    }

  }

  /** Converts IConnection with EditorContextProgress to ConnectionValue
    * @param connection
    * @param editorContextProgress
    * @return
    */
  override def toConnectionValue(
      connection: IConnection,
      editorContextProgress: EditorContextProgress
  ): Future[ConnectionValue] = toConnectionValue(connection, Nil, Some(editorContextProgress))

  /** Converts IConnection to ConnectionValueForList
    * @param connection
    * @return
    *   ConnectionValueForList
    */
  override def toConnectionValueForList(connection: IConnection): Future[ConnectionValueForList] = {
    val remoteInstanceOpt = Option(connection.getRemoteInstance)
    val communication = CommunicationValue(
      connection.getSendProtocol.name,
      None,
      None,
      remoteInstanceOpt.flatMap(i => Option(i.getUrl)).map(_.toExternalForm),
      remoteInstanceOpt.flatMap(i => Option(i.getIssueTrackerUrl)).map(_.toExternalForm),
      None,
      None,
      None,
      None
    )

    for {
      stats <- twinTraceRepository.getStats(connection)
      tokens <- oAuthService.getTokens(connection.getID)
    } yield ConnectionValueForList(
      Option(connection.getID),
      connection.getName,
      Option(connection.getStatus.name),
      Option(connection.getInvitationStatus.name),
      Option(connection.getDescription),
      Option(connection.isLocal),
      communication,
      Some(stats),
      Option(connection.getMode),
      Some(!tokens.isEmpty),
      Option(connection.isManagedRemotely)
    )

  }

  /** Overrides main field, namely add errors to scope value
    * @param scopeUid
    * @param errorsSeq
    *   seq of editor errors
    * @param side
    *   editor side: LOCAL or REMOTE
    * @param mf
    *   FieldValue
    * @return
    *   updated main field value
    */
  private def overrideMainField(scopeUid: String, errorsSeq: Seq[EditorError], side: EditorErrorSide)(
      mf: FieldValue
  ): FieldValue =
    errorsSeq.foldLeft(mf) { (result, editorError) =>
      editorError match {
        case ScopeMainFieldEditorError(errorScopeUid, mainField, errorSide, errorValue)
            if scopeUid == errorScopeUid && side == errorSide && mf.key == mainField =>
          result.copy(error = Some(errorValue))
        case _ => result
      }
    }

  /** Overrides scope query (adds error value)
    * @param scopeUid
    * @param errorsSeq
    *   seq of editor errors
    * @param side
    *   editor side: LOCAL or REMOTE
    * @param query
    * @return
    *   updated scope query value
    */
  private def overrideQuery(
      scopeUid: String,
      errorsSeq: Seq[EditorError],
      side: EditorErrorSide,
      query: Option[Seq[QueryValue]]
  ): Option[Seq[QueryValue]] =
    errorsSeq.foldLeft(query) { (result, editorError) =>
      editorError match {
        case ScopeQueryEditorError(errorScopeUid, queryField, errorSide, errorValue) =>
          result.map {
            _.map { queryValue =>
              if (
                scopeUid == errorScopeUid && side == errorSide && queryValue.field.key == queryField
              ) {
                queryValue.copy(error = Some(errorValue))
              } else queryValue
            }
          }
        case _                                                                       => result
      }
    }

  /** Gets a seq of Scope values from DB by connection id and adds error values to obtained scopes
    * @param connectionIdOpt
    * @param errorsSeq
    *   seq of editor errors
    * @return
    *   a seq of scope values with errors
    */
  private def getScopeValueByConnectionId(
      connectionIdOpt: Option[Int],
      errorsSeq: Seq[EditorError] = Nil
  ): Future[Option[Seq[ScopeValue]]] = {

    val mainFieldErrors = errorsSeq.filter(_.`type` == ErrorLocationType.SCOPE_MAIN_FIELD)
    val queryErrors = errorsSeq.filter(_.`type` == ErrorLocationType.SCOPE_QUERY)
    connectionIdOpt.map(scopesRepository.getByConnectionId) match {
      case Some(scopesFuture) =>
        scopesFuture
          .map(
            _.map(_.toScopeValue)
              .map {
                case s @ ScopeValue(
                      l @ SingleSideScopeValue(lScopeUid, lMFs, lSyncCriteria, _, _),
                      r @ SingleSideScopeValue(rScopeUid, rMFs, rSyncCriteria, _, _)
                    ) =>
                  s.copy(
                    l.copy(
                      mainFields = lMFs.map(
                        overrideMainField(
                          lScopeUid.getOrElse(""),
                          mainFieldErrors,
                          EditorErrorSide.LOCAL
                        )
                      ),
                      syncCriteria = lSyncCriteria.map(
                        _.copy(query =
                          overrideQuery(
                            lScopeUid.getOrElse(""),
                            queryErrors,
                            EditorErrorSide.LOCAL,
                            lSyncCriteria.flatMap(_.query)
                          )
                        )
                      )
                    ),
                    r.copy(
                      mainFields = rMFs.map(
                        overrideMainField(
                          rScopeUid.getOrElse(""),
                          mainFieldErrors,
                          EditorErrorSide.REMOTE
                        )
                      ),
                      syncCriteria = rSyncCriteria.map(
                        _.copy(query =
                          overrideQuery(
                            rScopeUid.getOrElse(""),
                            queryErrors,
                            EditorErrorSide.REMOTE,
                            rSyncCriteria.flatMap(_.query)
                          )
                        )
                      )
                    )
                  )
              }
          )
          .map(Some.apply)
      case None               => Future.successful(None)
    }
  }

  /** Overrides mapping maps (adds error value)
    * @param mappingId
    * @param errorsSeq
    *   seq of editor errors
    * @param mapsValue
    *   maps values that should be updated
    * @return
    *   seq of map values with error values
    */
  private def overrideMappingMaps(
      mappingId: Int,
      errorsSeq: Seq[EditorError],
      mapsValue: Option[Seq[MapValue]]
  ): Option[Seq[MapValue]] =
    errorsSeq.foldLeft(mapsValue) { (result, editorError) =>
      editorError match {
        case MappingMapsEditorError(id, localMapValue, remoteMapValue, side, errorValue) =>
          result.map {
            _.map { mappingMaps =>
              if (id == mappingId)
                if (side == EditorErrorSide.LOCAL && mappingMaps.local == localMapValue) {
                  mappingMaps.copy(localError = Some(errorValue))
                } else if (side == EditorErrorSide.REMOTE && mappingMaps.remote == remoteMapValue) {
                  mappingMaps.copy(remoteError = Some(errorValue))
                } else mappingMaps
              else mappingMaps

            }
          }
        case _                                                                           => result
      }
    }

  /** Gets a seq of Mapping values from DB by connection id and adds error values to obtained
    * mapping
    * @param connectionIdOpt
    * @param editorErrors
    *   seq of editor errors
    * @return
    *   seq of map values with error values
    */
  private def getMappingsByConnectionId(
      connectionIdOpt: Option[Int],
      editorErrors: Seq[EditorError] = Nil
  ): Future[Option[Seq[MappingValue]]] = {
    val mappingMapsErrors = editorErrors.filter(_.`type` == ErrorLocationType.MAPPING_MAPS)
    val mappingErrors = editorErrors.filter(_.`type` == ErrorLocationType.OVERALL_MAPPING)
    val scriptErrors = editorErrors.filter(_.`type` == ErrorLocationType.SCRIPT)
    val recoveryDefaultErrors =
      editorErrors.filter(_.`type` == ErrorLocationType.RECOVERY_DEFAULT_VALUE)
    connectionIdOpt.map(mappingsRepository.getByConnectionId) match {

      case Some(mappingsFuture) =>
        mappingsFuture
          .map(
            _.map(_.toMappingValue)
              .map {
                case m @ MappingValue(Some(id), l, _, ms, r, _, _, _, e, le, re) =>
                  m.copy(
                    local = overrideRecovery(id, l, recoveryDefaultErrors, EditorErrorSide.LOCAL),
                    remote = overrideRecovery(id, r, recoveryDefaultErrors, EditorErrorSide.REMOTE),
                    maps = overrideMappingMaps(id, mappingMapsErrors, ms),
                    errors = Some(scriptErrors.collect {
                      case ScriptMappingEditorError(_id, errorValue) if _id.contains(id) =>
                        errorValue
                    }),
                    localErrors = Some(mappingErrors.collect {
                      case MappingEditorError(_id, EditorErrorSide.LOCAL, errorValue)
                          if id == _id =>
                        errorValue
                    }),
                    remoteErrors = Some(mappingErrors.collect {
                      case MappingEditorError(_id, EditorErrorSide.REMOTE, errorValue)
                          if id == _id =>
                        errorValue
                    })
                  )
                case m                                                           => m
              }
          )
          .map(Some.apply)
      case None                 => Future.successful(None)
    }
  }

  /** Overrides recovery values, namely add errors to recovery value
    * @param id
    * @param mftv
    *   MappingFieldTypeValue
    * @param recoveryDefaultErrors
    *   seq of editor errors
    * @param targetSide
    *   editor side: LOCAL or REMOTE
    * @return
    *   seq of recovery values with error values
    */
  private def overrideRecovery(
      id: Int,
      mftv: Option[MappingFieldTypeValue],
      recoveryDefaultErrors: Seq[EditorError],
      targetSide: EditorErrorSide
  ) =
    mftv.map(mftv =>
      mftv.copy(recovery =
        mftv.recovery.map(rV =>
          rV.copy(
            errors = Some(recoveryDefaultErrors.collect {
              case RecoveryDefaultEditorError(_id, side, errorValue)
                  if id == _id && side == targetSide =>
                errorValue
            })
          )
        )
      )
    )

  /** Filters provided seq of editor errors, extracts only Missing Mapping Editor Errors where
    * ErrorLocationType is `MAPPING_BUTTON`
    * @param editorErrors
    *   seq of editor errors
    * @return
    *   seq of Missing Mapping Editor Errors
    */
  private def getMissingMappingEditorErrors(
      editorErrors: Seq[EditorError] = Nil
  ): Option[Seq[EditorErrorValue]] =
    Some(editorErrors.filter(_.`type` == ErrorLocationType.MAPPING_BUTTON).map(_.errorValue))

  /** Generates default INonPersistentConnection with credentials
    * @param remoteUsername
    * @param remotePassword
    * @param authenticationRequired
    * @return
    *   INonPersistentConnection
    */
  override def getDefaultWithCredentials(
      remoteUsername: String,
      remotePassword: String,
      authenticationRequired: Boolean
  ): INonPersistentConnection =
    new NonPersistentConnection(
      "defaultconnection",
      "Default connection with default processors",
      ConnectionStatus.ACTIVE,
      InvitationStatus.PENDING,
      DEFAULT_DATA_FILTER,
      DEFAULT_CHANGE_PROCESSOR,
      DEFAULT_CREATE_PROCESSOR,
      null,
      new ConnectionIssueTrackerSettings(
        -1,
        NodeType.JIRA_CLOUD.name,
        false,
        true,
        null,
        null,
        null,
        null,
        null
      ),
      remoteUsername,
      remotePassword,
      authenticationRequired,
      false,
      SendProtocol.DIRECT_HTTP,
      ReceiveProtocol.DIRECT_HTTP,
      null,
      DEFAULT_CREATE_PROCESSOR,
      "2",
      new util.HashMap[String, String]()
    )

  /** Combines provided data ({@code connectionDraft}, {@code scopes} , {@code mappings} and
    * {@code accessToken} ) into ConnectionDraftRequestValue
    * @param connectionDraft
    * @param scopes
    * @param mappings
    * @param accessToken
    * @return
    */
  override def toConnectionDraftValueRequest(
      connectionDraft: ConnectionDraft,
      scopes: Seq[ScopeValue],
      mappings: Seq[MappingValue],
      accessToken: Option[String]
  ): Option[ConnectionDraftRequestValue] =
    connectionDraft.id.map { draftId =>
      ConnectionDraftRequestValue(
        draftId,
        connectionDraft.createdOn.getTime,
        connectionDraft.status.toString,
        connectionDraft.connectionId,
        connectionDraft.operation.toString,
        scopes,
        mappings,
        accessToken
      )
    }

  /** Converts IConnection to INonPersistentConnection
    * @param c
    *   connection
    * @return
    *   INonPersistentConnection
    */
  override def toNonPersistentConnection(c: IConnection): INonPersistentConnection =
    new NonPersistentConnection(
      c.getName,
      c.getDescription,
      c.getStatus,
      c.getInvitationStatus,
      c.getDataFilter,
      c.getChangeProcessor,
      c.getCreateProcessor,
      InstanceConverter.toNonPersistentInstance(c.getRemoteInstance),
      c.getTrackerSettings,
      c.getRemoteUsername,
      c.getRemotePassword,
      c.isAuthenticationRequired,
      c.isLocal,
      c.getSendProtocol,
      c.getReceiveProtocol,
      c.getLocalUrl,
      c.getIncomingProcessor,
      c.getVersion,
      c.getFieldValues
    )

}
