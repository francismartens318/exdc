package com.exalate.replication.services.transport.v1.rest

import com.exalate.api.domain.blob.request.IBlobRequest
import com.google.inject.ImplementedBy
import com.exalate.replication.services.transport.value.BlobResponseValue

import scala.concurrent.Future

@ImplementedBy(classOf[com.exalate.replication.services.transport.v1.rest.BlobResponsesClient])
trait IBlobResponsesClient {

  /** POST /rest/issuehub/1.0/blobresponses
    */
  def postBlobResponse(
      blobResponseValue: BlobResponseValue,
      remoteInstanceUrl: String,
      blobRequest: IBlobRequest
  ): Future[None.type]

}
