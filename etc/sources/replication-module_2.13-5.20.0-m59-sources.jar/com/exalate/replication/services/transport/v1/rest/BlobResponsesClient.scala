package com.exalate.replication.services.transport.v1.rest

import com.exalate.api.domain.blob.request.IBlobRequest
import com.exalate.error.services.api.IExalateRestErrorResponseCategoryService
import com.exalate.replication.services.api.error.SyncContext
import com.exalate.replication.services.transport.{ExaToExaRequestFilterFactory, ResponseHandler}
import com.exalate.replication.services.transport.value.BlobResponseValue
import com.exalate.replication.services.transport.wrapper.{ILoggingWsClientFactory, LoggingFnUtils}
import com.exalate.util.UrlUtils

import javax.inject.Inject
import play.api.Logger
import play.api.libs.json.Json
import play.api.libs.ws.WSClient

import scala.concurrent.ExecutionContext
import scala.concurrent.Future

class BlobResponsesClient @Inject() (
    wsClient: WSClient,
    loggingWsClientFactory: ILoggingWsClientFactory,
    exaToExaRequestFilterFactory: ExaToExaRequestFilterFactory,
    errorRestResponseCategoryService: IExalateRestErrorResponseCategoryService
)(implicit ec: ExecutionContext)
    extends IBlobResponsesClient {
  val SYNC_RESPONSE_URL = "/rest/issuehub/1.0/blobresponses"
  val LOG: Logger = Logger("services.transport.rest.BlobResponsesClient")

  val ws = loggingWsClientFactory.create(
    wsClient,
    LoggingFnUtils.logRequestWithBody,
    LoggingFnUtils.logResponseWithBody
  )

  /** POST /rest/issuehub/1.0/blobresponses
    * @param blobResponseValue
    * @param remoteInstanceUrl
    * @param blobRequest
    * @return
    *   None
    */
  override def postBlobResponse(
      blobResponseValue: BlobResponseValue,
      remoteInstanceUrl: String,
      blobRequest: IBlobRequest
  ): Future[None.type] = {
    LOG.info(
      s"Posting blob response from sync event: ${blobResponseValue.syncEventId} to: $remoteInstanceUrl"
    )
    val syncRequest = blobRequest.getSyncRequest
    val connection = blobRequest.getSyncRequest.getConnection
    val requestFilter = exaToExaRequestFilterFactory.create(connection)
    val context = SyncContext.createWithBlobRequest(connection, blobRequest)

    val url = UrlUtils.concat(remoteInstanceUrl, SYNC_RESPONSE_URL)
    val reques = ws.url(url)
    val request = reques
      .withHeaders("Content-Type" -> "application/json")
      .withRequestFilter(requestFilter)
    exaToExaRequestFilterFactory
      .processWithShortSecretRetry(
        connection,
        request
          .post(Json.toJson(blobResponseValue))
      )
      .flatMap { r =>
        (new ResponseHandler).handleResponses(connection, r)
      }
      .recoverWith {
        case e: Exception =>
          val details =
            s"Exception while posting blob response from sync request `${syncRequest.getId}` for sync event: ${blobResponseValue.syncEventId} to `$remoteInstanceUrl`"
          LOG.error(details, e)
          val exception = errorRestResponseCategoryService.categorizeNetworkAndRestResponseException(
            e,
            Some(details)
          )
          Future.failed(exception)
      }

  }

}
