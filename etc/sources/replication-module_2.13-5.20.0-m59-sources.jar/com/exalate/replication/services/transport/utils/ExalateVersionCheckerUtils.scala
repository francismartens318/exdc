package com.exalate.replication.services.transport.utils

import com.exalate.api.domain.connection.IConnection
import com.exalate.basic.domain.util.SemanticVersionService

object ExalateVersionCheckerUtils {

  /** Check whether remote exalate supports specific headers in request. It is done, in order to
    * distinguish a responses, when we obtain only 200 (or 204) without body we want to know whether
    * the response from exalate or not. So we do it by headers.
    * @param connection
    * @return
    */
  def remoteSupportsHeaderInRequest(connection: IConnection): Boolean =
    isRemoteMaxRestVersionNewerThan(connection)(4, 1, 0)

  def remoteSupportsCheckingConnectionsPolling(connection: IConnection): Boolean =
    isRemoteMaxRestVersionNewerThan(connection)(5, 1, 0)

  private def isRemoteMaxRestVersionNewerThan(
      connection: IConnection
  )(major: Int, minor: Int, patch: Int): Boolean = {
    val featureMinV = SemanticVersionService.create(major, minor, patch);

    val remoteMaxRestVersionOpt = Option(connection.getRemoteInstance.getNodeInfo)
      .flatMap(remoteNodeInfo => Option(remoteNodeInfo.getMaxRestVersion))

    remoteMaxRestVersionOpt.exists { remoteMaxRestVersion =>
      val remoteVersion = SemanticVersionService.get(remoteMaxRestVersion)
      !SemanticVersionService.isLeftOlderThanRight(remoteVersion, featureMinV)
    }
  }

  /** If remote is configured with max REST 5.2.0 and up, it means, we don't have to send an extra
    * confirmation request
    */
  def remoteSupportsNoExtraConfirmation(connection: IConnection): Boolean =
    isRemoteMaxRestVersionNewerThan(connection)(5, 2, 0)

  def isExalateRestVersionEncodingCompatible(remoteMaxRestVersion: String): Boolean =
    try {
      val requiredRestMinVersion = SemanticVersionService.create(5, 0, 0)
      val remoteRestVersion = SemanticVersionService.get(remoteMaxRestVersion)

      SemanticVersionService.isLeftEqualOrOlderThanRight(requiredRestMinVersion, remoteRestVersion)
    } catch {
      case _: Exception => false
    }

}
