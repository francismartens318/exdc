package com.exalate.replication.services.transport.security

import cats.data.OptionT
import com.exalate.domain.values.AuthenticationFailureValue
import com.exalate.generic.services.api.IAuthenticationTrackerService
import com.exalate.replication.services.api.config.IGeneralSettingsService
import com.exalate.replication.services.api.transport.security.IBasicAuthorizationService
import com.exalate.util.UrlUtils
import com.google.inject.Inject
import play.api.Configuration
import play.api.http.Status.OK
import play.api.libs.ws.{WSAuthScheme, WSClient}
import play.api.mvc.Request

import java.util.Base64
import scala.concurrent.{ExecutionContext, Future}

class BasicAuthorizationService @Inject() (
    ws: WSClient,
    generalSettingsService: IGeneralSettingsService,
    authTrackerService: IAuthenticationTrackerService,
    configuration: Configuration
)(implicit ec: ExecutionContext)
    extends IBasicAuthorizationService {

  /** Makes a request to check if a user if authorized
    * @param username
    * @param password
    * @param authorizationPath
    * @return
    */
  override def isUserAuthorized(
      username: String,
      password: String,
      authorizationPath: String
  ): Future[Boolean] =
    (for {
      generalSettings <- OptionT(generalSettingsService.get)
      issueTrackerUrl = generalSettings.getIssueTrackerUrl
      response <- OptionT.liftF(
        ws.url(UrlUtils.concat(issueTrackerUrl, authorizationPath))
          .withMethod("GET")
          .withAuth(username, password, WSAuthScheme.BASIC)
          .execute()
      )
    } yield response.status == OK).value.map(_.getOrElse(false))

  override def isRequestByValidUser[T](request: Request[T]): Future[Boolean] =
    request.headers.get("Authorization") match {
      case Some(header) if header.startsWith("Basic") =>
        val encodedCredentials = header.substring("Basic ".length())
        val decodedCredentials = new String(Base64.getDecoder.decode(encodedCredentials))
        val credentials = decodedCredentials.split(":")
        if (credentials.size == 2) {
          authTrackerService
            .checkIfValidUser(credentials(0), credentials(1))
            .map(_ => true)
            .recover {
              case e: Exception => false
            }
        } else {
          Future.successful(false)
        }
      case _                                          => Future.successful(false)
    }

  override def isRequestByAdmin[T](request: Request[T]): Future[Boolean] =
    isRequestBy(authTrackerService.checkIfAdmin)(request)

  override def isRequestBy[T](
      checkIfAdminFn: (String, String) => Future[Option[AuthenticationFailureValue]]
  )(request: Request[T]): Future[Boolean] =
    request.headers.get("Authorization") match {
      case Some(header) if header.startsWith("Basic") =>
        val encodedCredentials = header.substring("Basic ".length())
        val decodedCredentials = new String(Base64.getDecoder.decode(encodedCredentials))
        val credentials = decodedCredentials.split(":")
        if (credentials.size == 2) {
          checkIfAdminFn(credentials(0), credentials(1))
            .map(_.isEmpty)
            .recover {
              case e: Exception => false
            }
        } else {
          Future.successful(false)
        }
      case _                                          => Future.successful(false)
    }

  /** credentials checker
    *
    * @param username
    * @param password
    * @return
    */
  override def nodeAuth(
      conf_user: String,
      conf_password: String
  )(username: String, password: String): Future[Option[AuthenticationFailureValue]] = {
    val usernameOpt = configuration.getOptional[String](conf_user)
    val passwordOpt = configuration.getOptional[String](conf_password)

    val credentialsTuple = usernameOpt.flatMap(username => passwordOpt.map(pwd => (username, pwd)))

    credentialsTuple match {
      case Some((u, p)) if u == username && p == password => Future.successful(None)
      case None                                           =>
        Future.successful(
          Some(
            AuthenticationFailureValue(
              "Could not authenticate",
              "Credentials are not configured in node.conf file.",
              None
            )
          )
        )
      case _                                              =>
        Future.successful(
          Some(
            AuthenticationFailureValue("Could not authenticate", "Wrong credentials provided.", None)
          )
        )
    }
  }

}

object BasicAuthorizationService {
  val ADMIN_LEVEL_USER = "exalate.admin.auth.username"
  val ADMIN_LEVEL_PWD = "exalate.admin.auth.password"
  val EXA_MICROSERVICE_MIGRATION_USERNAME = "exalate.microservice.migration.username"
  val EXA_MICROSERVICE_MIGRATION_PASSWORD = "exalate.microservice.migration.password"
}
