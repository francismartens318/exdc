package com.exalate.replication.services.transport.v2_4

import com.exalate.api.domain.blob.event.IBlobEvent
import com.exalate.api.domain.blob.request.IBlobRequest
import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.event.ISyncEvent
import com.exalate.api.domain.request.ISyncRequest
import com.exalate.domain.replication.BasicSyncRequest
import com.exalate.error.services.api.IExalateRestErrorResponseCategoryService
import com.exalate.replication.services.api.transport.rest.v2.INotifyReceivedClient
import com.exalate.replication.services.transport.{ExaToExaRequestFilterFactory, ResponseHandler}
import com.exalate.replication.services.transport.value.{BlobRequestValue, RequestValue}
import com.exalate.replication.services.transport.wrapper.{ILoggingWsClientFactory, LoggingFnUtils}
import com.exalate.util.{UrlUtils, Utf8UrlEncoder}
import com.google.inject.Inject
import play.api.Logger
import play.api.libs.ws.WSClient

import scala.concurrent.ExecutionContext
import scala.concurrent.Future

/*
 * POST          /rest/issuehub/2.4/syncevents/:eventId/syncrequest/received
 * POST          /rest/issuehub/2.4/blobevents/:blobEventId/blobrequest/received
 * POST          /rest/issuehub/2.4/syncrequests/relations/:relationName/syncevents/:eventId/syncresponse/received
 * POST          /rest/issuehub/2.4/blobrequests/relations/:relationName/blobevents/:blobEventId/blobresponse/received
 * */

class NotifyReceivedClient @Inject() (
    wsClient: WSClient,
    loggingWsClientFactory: ILoggingWsClientFactory,
    exaToExaRequestFilterFactory: ExaToExaRequestFilterFactory,
    errorRestResponseCategoryService: IExalateRestErrorResponseCategoryService
)(implicit ec: ExecutionContext)
    extends INotifyReceivedClient {

  private val NOTIFY_REST_URL = "/rest/issuehub/2.4/"

  private val ws = loggingWsClientFactory.create(
    wsClient,
    LoggingFnUtils.logRequestWithBody,
    LoggingFnUtils.logResponseWithBody
  )

  val LOG = Logger("application.services.transport.NotifyReceivedClient")

  /** POST /rest/issuehub/2.4/syncevents/:eventId/syncrequest/received
    * @param syncRequest
    * @return
    *   None
    */
  override def postRequestReceived(syncRequest: ISyncRequest): Future[None.type] = {
    LOG.trace(
      s"Notifying the sync request `${syncRequest.getId}` received for the remote sync event `${syncRequest.getRemoteSyncEventId}`"
    )
    val connection = syncRequest.getConnection
    val requestFilter = exaToExaRequestFilterFactory.create(connection)
    val remoteInstanceUrl = connection.getRemoteInstance.getUrl.toExternalForm
    val finalUrl: String = getRequestReceivedUrl(syncRequest)

    val request = ws
      .url(finalUrl)
      .addHttpHeaders("Content-Type" -> "application/json")
      .withRequestFilter(requestFilter)
      .withMethod("POST")

    exaToExaRequestFilterFactory
      .processWithShortSecretRetry(connection, request.execute())
      .flatMap { response =>
        (new ResponseHandler).handleResponses(connection, response)
      }
      .recoverWith {
        case e: Exception =>
          val details =
            s"Exception while trying to post to `$remoteInstanceUrl` that sync request `${syncRequest.getId}` received for remote sync event `${syncRequest.getRemoteSyncEventId}`"
          LOG.error(details, e)
          val exception = errorRestResponseCategoryService.categorizeNetworkAndRestResponseException(
            e,
            Some(details)
          )
          Future.failed(exception)
      }
  }

  override def postRequestReceived(
      basicSyncRequest: BasicSyncRequest,
      connection: IConnection
  ): Future[None.type] = {
    LOG.trace(
      s"Notifying the sync request `${basicSyncRequest.id}` received for the remote sync event `${basicSyncRequest.remoteSyncEventId}`"
    )
    val requestFilter = exaToExaRequestFilterFactory.create(connection)
    val remoteInstanceUrl = connection.getRemoteInstance.getUrl.toExternalForm
    val finalUrl: String = getRequestReceivedUrl(basicSyncRequest, connection)

    val request = ws
      .url(finalUrl)
      .addHttpHeaders("Content-Type" -> "application/json")
      .withRequestFilter(requestFilter)
      .withMethod("POST")

    exaToExaRequestFilterFactory
      .processWithShortSecretRetry(connection, request.execute())
      .flatMap { response =>
        (new ResponseHandler).handleResponses(connection, response)
      }
      .recoverWith {
        case e: Exception =>
          val details =
            s"Exception while trying to post to `$remoteInstanceUrl` that sync request `${basicSyncRequest.id}` received for remote sync event `${basicSyncRequest.remoteSyncEventId}`"
          LOG.error(details, e)
          val exception = errorRestResponseCategoryService.categorizeNetworkAndRestResponseException(
            e,
            Some(details)
          )
          Future.failed(exception)
      }
  }

  /** POST /rest/issuehub/2.4/syncevents/:eventId/syncrequest/received
    *
    * @param requestValue
    * @param connection
    * @return
    *   None
    */
  override def postRequestReceived(
      requestValue: RequestValue,
      connection: IConnection
  ): Future[None.type] =
    postRequestReceived(None, connection, requestValue.syncEventId)

  private def postRequestReceived(
      requestIdOpt: Option[Int],
      connection: IConnection,
      remoteSyncEventId: Int
  ): Future[None.type] = {
    val requestIdStr = requestIdOpt match {
      case None            => ""
      case Some(requestId) => s"`$requestId`"
    }
    LOG.trace(
      s"Notifying the sync request$requestIdStr received for the remote sync event `$remoteSyncEventId`"
    )
    val remoteInstanceUrl = connection.getRemoteInstance.getUrl.toExternalForm
    val finalUrl: String = getRequestReceivedUrl(connection, remoteSyncEventId)

    val request = ws
      .url(finalUrl)
      .withHeaders("Content-Type" -> "application/json")
      .withBasicAuth(connection)
      .withExternalJwt(connection)
      .withMethod("POST")

    exaToExaRequestFilterFactory
      .processWithShortSecretRetry(connection, request.execute())
      .flatMap { response =>
        (new ResponseHandler).handleResponses(connection, response)

      }
      .recoverWith {
        case e: Exception =>
          val details =
            s"Exception while trying to post to `$remoteInstanceUrl` that sync request$requestIdStr was received for remote sync event `$remoteSyncEventId`"
          LOG.error(details, e)
          val exception = errorRestResponseCategoryService.categorizeNetworkAndRestResponseException(
            e,
            Some(details)
          )
          Future.failed(exception)
      }
  }

  /** POST
    * /rest/issuehub/2.4/syncrequests/relations/:relationName/syncevents/:eventId/syncresponse/received
    * @param syncEvent
    * @return
    */
  override def postResponseReceived(syncEvent: ISyncEvent): Future[None.type] = {
    LOG.trace(s"Notifying the sync response received for the sync event `${syncEvent.getId}`")
    val connection = syncEvent.getConnection
    val remoteInstanceUrl = connection.getRemoteInstance.getUrl.toExternalForm
    val finalUrl: String = getResponseReceivedUrl(syncEvent)

    val request = ws
      .url(finalUrl)
      .withHeaders("Content-Type" -> "application/json")
      .withBasicAuth(connection)
      .withExternalJwt(connection)
      .withMethod("POST")

    exaToExaRequestFilterFactory
      .processWithShortSecretRetry(connection, request.execute())
      .flatMap { response =>
        (new ResponseHandler).handleResponses(connection, response)
      }
      .recoverWith {
        case e: Exception =>
          val details =
            s"Exception while trying to post to `$remoteInstanceUrl` that sync response for sync event `${syncEvent.getId}` received"
          LOG.error(details, e)
          val exception = errorRestResponseCategoryService.categorizeNetworkAndRestResponseException(
            e,
            Some(details)
          )
          Future.failed(exception)
      }
  }

  /** POST /rest/issuehub/2.4/blobevents/:blobEventId/blobrequest/received
    * @param blobRequest
    * @return
    */
  override def postBlobRequestReceived(blobRequest: IBlobRequest): Future[None.type] =
    postBlobRequestReceived(
      Option(blobRequest.getId),
      blobRequest.getSyncRequest.getConnection,
      blobRequest.getRemoteBlobEventId
    )

  /** POST /rest/issuehub/2.4/blobevents/:blobEventId/blobrequest/received
    * @param blobRequest
    * @return
    */
  override def postBlobRequestReceived(
      blobRequestValue: BlobRequestValue,
      connection: IConnection
  ): Future[None.type] =
    blobRequestValue.blobEventId match {
      case None              => Future.successful(None)
      case Some(blobEventId) =>
        postBlobRequestReceived(None, connection, blobEventId)
    }

  private def postBlobRequestReceived(
      blobRequestIdOpt: Option[Int],
      connection: IConnection,
      remoteBlobEventId: Int
  ): Future[None.type] = {
    val blobRequestStr = blobRequestIdOpt match {
      case None                => ""
      case Some(blobRequestId) => s" `$blobRequestId`"
    }
    LOG.trace(
      s"Notifying the blob request$blobRequestStr received for the remote blob event `$remoteBlobEventId`"
    )
    val remoteInstanceUrl = connection.getRemoteInstance.getUrl.toExternalForm
    val finalUrl: String = getBlobRequestReceivedUrl(connection, remoteBlobEventId)

    val request = ws
      .url(finalUrl)
      .withHeaders("Content-Type" -> "application/json")
      .withBasicAuth(connection)
      .withExternalJwt(connection)
      .withMethod("POST")

    exaToExaRequestFilterFactory
      .processWithShortSecretRetry(connection, request.execute())
      .flatMap { response =>
        (new ResponseHandler).handleResponses(connection, response)
      }
      .recoverWith {
        case e: Exception =>
          val details =
            s"Exception while trying to post to `$remoteInstanceUrl` that blob request$blobRequestStr received for remote blob event `$remoteBlobEventId`"
          LOG.error(details, e)
          val exception = errorRestResponseCategoryService.categorizeNetworkAndRestResponseException(
            e,
            Some(details)
          )
          Future.failed(exception)
      }
  }

  /** POST
    * /rest/issuehub/2.4/blobrequests/relations/:relationName/blobevents/:blobEventId/blobresponse/received
    * @param blobEvent
    * @return
    */
  override def postBlobResponseReceived(blobEvent: IBlobEvent): Future[None.type] = {
    LOG.trace(s"Notifying the blob response received for the blob event `${blobEvent.getId}`")
    val connection = blobEvent.getSyncEvent.getConnection
    val remoteInstanceUrl = connection.getRemoteInstance.getUrl.toExternalForm
    val finalUrl: String = getBlobResponseReceivedUrl(blobEvent)

    val request = ws
      .url(finalUrl)
      .withHeaders("Content-Type" -> "application/json")
      .withBasicAuth(connection)
      .withExternalJwt(connection)
      .withMethod("POST")

    exaToExaRequestFilterFactory
      .processWithShortSecretRetry(connection, request.execute())
      .flatMap { response =>
        (new ResponseHandler).handleResponses(connection, response)
      }
      .recoverWith {
        case e: Exception =>
          val details =
            s"Exception while trying to post to `$remoteInstanceUrl` that blob response for blob event `${blobEvent.getId}` received"
          LOG.error(details, e)
          val exception = errorRestResponseCategoryService.categorizeNetworkAndRestResponseException(
            e,
            Some(details)
          )
          Future.failed(exception)
      }
  }

  private def getRequestReceivedUrl(syncRequest: ISyncRequest): String = {
    val remoteInstanceUrl = syncRequest.getConnection.getRemoteInstance.getUrl.toExternalForm
    val remoteSyncEventId = syncRequest.getRemoteSyncEventId.toString
    UrlUtils.concat(
      remoteInstanceUrl,
      NOTIFY_REST_URL,
      "syncevents",
      remoteSyncEventId,
      "syncrequest",
      "received"
    )
  }

  private def getRequestReceivedUrl(connection: IConnection, remoteSyncEventId: Int): String = {
    val remoteInstanceUrl = connection.getRemoteInstance.getUrl.toExternalForm
    val remoteSyncEventIdStr = remoteSyncEventId.toString
    UrlUtils.concat(
      remoteInstanceUrl,
      NOTIFY_REST_URL,
      "syncevents",
      remoteSyncEventIdStr,
      "syncrequest",
      "received"
    )
  }

  private def getRequestReceivedUrl(
      basicSyncRequest: BasicSyncRequest,
      connection: IConnection
  ): String = {
    val remoteInstanceUrl = connection.getRemoteInstance.getUrl.toExternalForm
    val remoteSyncEventId = basicSyncRequest.remoteSyncEventId.toString
    UrlUtils.concat(
      remoteInstanceUrl,
      NOTIFY_REST_URL,
      "syncevents",
      remoteSyncEventId,
      "syncrequest",
      "received"
    )
  }

  private def getResponseReceivedUrl(syncEvent: ISyncEvent): String = {
    val connection = syncEvent.getConnection
    val remoteInstanceUrl = connection.getRemoteInstance.getUrl.toExternalForm
    val encodedConnectionName = Utf8UrlEncoder.encode(connection.getName)
    val eventId = syncEvent.getId.toString
    UrlUtils.concat(
      remoteInstanceUrl,
      NOTIFY_REST_URL,
      "syncrequests",
      "relations",
      encodedConnectionName,
      "syncevents",
      eventId,
      "syncresponse",
      "received"
    )
  }

  private def getBlobRequestReceivedUrl(blobRequest: IBlobRequest): String =
    getBlobRequestReceivedUrl(
      blobRequest.getSyncRequest.getConnection,
      blobRequest.getRemoteBlobEventId
    )

  private def getBlobRequestReceivedUrl(connection: IConnection, blobEventId: Int): String = {
    val remoteInstanceUrl = connection.getRemoteInstance.getUrl.toExternalForm
    val remoteBlobEventId = blobEventId.toString
    UrlUtils.concat(
      remoteInstanceUrl,
      NOTIFY_REST_URL,
      "blobevents",
      remoteBlobEventId,
      "blobrequest",
      "received"
    )
  }

  private def getBlobResponseReceivedUrl(blobEvent: IBlobEvent): String = {
    val connection = blobEvent.getSyncEvent.getConnection
    val remoteInstanceUrl = connection.getRemoteInstance.getUrl.toExternalForm
    val encodedConnectionName = Utf8UrlEncoder.encode(connection.getName)
    val blobEventId = blobEvent.getId.toString
    UrlUtils.concat(
      remoteInstanceUrl,
      NOTIFY_REST_URL,
      "blobrequests",
      "relations",
      encodedConnectionName,
      "blobevents",
      blobEventId,
      "blobresponse",
      "received"
    )
  }

}
