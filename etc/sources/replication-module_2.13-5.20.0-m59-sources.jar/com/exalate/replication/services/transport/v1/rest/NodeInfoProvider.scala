package com.exalate.replication.services.transport.v1.rest

import com.exalate.api.ILoggingService
import com.exalate.api.exception.{CategorizedException, RetriableException}
import com.exalate.domain.values.NodeInfoValue
import com.exalate.error.services.api.IBugExceptionCategoryService
import com.exalate.generic.services.api.INodeTypeProvider
import com.exalate.replication.services.api.config.IGeneralSettingsService
import com.exalate.replication.services.api.issuetracker.rest.IIssueTrackerVersionClient
import com.exalate.replication.services.api.issuetracker.{
  IInstanceNameService,
  IIssueTrackerEditorValueService,
  IIssueTrackerMainFieldsValueService,
  IIssueTrackerUrlService
}
import com.exalate.replication.services.api.node.ISelfNodeInfoService
import com.exalate.replication.services.api.node.lifecycle.ILifecycleInfoService
import com.exalate.replication.services.config.EditorFeaturesProvider
import com.exalate.services.utils.IBuildInfoService
import com.google.inject.Inject

import javax.inject.Singleton
import scala.concurrent.{ExecutionContext, Future}

@Singleton
class NodeInfoProvider @Inject() (
    generalSettingsService: IGeneralSettingsService,
    lifecycleInfoService: ILifecycleInfoService,
    issueTrackerVersionClient: IIssueTrackerVersionClient,
    buildInfoService: IBuildInfoService,
    selfNodeInfoService: ISelfNodeInfoService,
    nodeTypeProvider: INodeTypeProvider,
    bugExceptionCategoryService: IBugExceptionCategoryService,
    loggingService: ILoggingService,
    issueTrackerEditorValueProvider: IIssueTrackerEditorValueService,
    issueTrackerIconUrlService: IIssueTrackerUrlService,
    issueTrackerBasicConnectionValueService: IIssueTrackerMainFieldsValueService,
    instanceNameService: IInstanceNameService
)(implicit ec: ExecutionContext) {

  val NAME = "self"

  lazy val nodeType = nodeTypeProvider.getNodeType
  var nodeInfoValueOpt: Option[NodeInfoValue] = None

  /** Gets a local instance node info
    * @return
    *   NodeInfoValue
    */
  def get: Future[NodeInfoValue] = nodeInfoValueOpt match {
    case Some(v) => Future.successful(v)
    case None    =>
      val nodeVersion: String = buildInfoService.getNodeVersion
      val f = (for {
        settingsOpt <- generalSettingsService.get
        settings <- settingsOpt match {
          case None           =>
            loggingService.error(s"No general settings configured.")
            Future.failed(bugExceptionCategoryService.generateNoGeneralSettingsBugException())
          case Some(settings) =>
            Future.successful(settings)
        }
        trackerVersion <- issueTrackerVersionClient.getSiteVersionsJsonString(settings)
        editorFeatures = EditorFeaturesProvider.get()
        editorValueOpt <- issueTrackerEditorValueProvider.get(editorFeatures)
        instanceName <- instanceNameService.generateLocalInstanceName()
        basicConnectionValueOpt <- issueTrackerBasicConnectionValueService.get()
        instanceUid <- lifecycleInfoService.getInstanceUid
        value = NodeInfoValue(
          None,
          instanceName,
          settings.getExalateUrl,
          Option(settings.getIssueTrackerUrl),
          nodeType,
          trackerVersion,
          trackerVersion,
          nodeVersion,
          nodeVersion,
          selfNodeInfoService.getMinHubObjectVersion,
          selfNodeInfoService.getMaxHubObjectVersion,
          selfNodeInfoService.getMinRestVersion,
          selfNodeInfoService.getMaxRestVersion,
          Some(selfNodeInfoService.isPollOnly),
          Some(buildInfoService.getExaCompVersion),
          Some(buildInfoService.getRawExaCompVersion),
          instanceUid,
          editorValueOpt,
          issueTrackerIconUrlService.iconUrl,
          basicConnectionValueOpt
        )
      } yield value)
        .recoverWith {
          case e: RetriableException   => Future.failed(e)
          case e: CategorizedException =>
            Future.failed(e)

          case e: Exception =>
            val exception =
              bugExceptionCategoryService.generateGettingLocalNodeInfoFailedBugException(e)
            loggingService.error(s"Exception while getting local node info.", exception)
            Future.failed(exception)
        }
      f.foreach(v => nodeInfoValueOpt = Option(v))
      f

  }

}
