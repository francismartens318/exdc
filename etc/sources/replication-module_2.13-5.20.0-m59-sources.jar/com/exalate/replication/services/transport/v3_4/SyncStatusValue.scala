package com.exalate.replication.services.transport.v3_4

case class SyncStatusValue(
    syncStatus: String,
    twinTraceId: Int,
    relationName: String,
    remoteIssueUrlContext: Option[RemoteIssueUrlContextValue]
)
