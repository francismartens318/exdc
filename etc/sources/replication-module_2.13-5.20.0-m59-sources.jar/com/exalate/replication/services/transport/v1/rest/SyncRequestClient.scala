package com.exalate.replication.services.transport.v1.rest

import com.exalate.api.domain.event.ISyncEvent
import com.exalate.error.services.api.IExalateRestErrorResponseCategoryService
import com.exalate.replication.services.transport.value._
import com.exalate.replication.services.transport.value.RequestValue._
import com.exalate.replication.services.transport.wrapper.{ILoggingWsClientFactory, LoggingFnUtils}
import com.exalate.replication.services.transport.{ExaToExaRequestFilterFactory, ResponseHandler}
import com.exalate.util.UrlUtils
import play.api.Logger
import play.api.libs.json.{Json, OFormat}
import play.api.libs.ws.WSClient

import javax.inject.Inject
import scala.concurrent.{ExecutionContext, Future}

class SyncRequestClient @Inject() (
    wsClient: WSClient,
    loggingWsClientFactory: ILoggingWsClientFactory,
    exaToExaRequestFilterFactory: ExaToExaRequestFilterFactory,
    errorRestResponseCategoryService: IExalateRestErrorResponseCategoryService
)(implicit ec: ExecutionContext)
    extends ISyncRequestClient {

  val SYNC_REQUEST_URL = "/rest/issuehub/1.0/syncrequests"
  val LOG: Logger = Logger("com.exalate.replication.services.transport.v1.rest.SyncRequestClient")

  private val ws = loggingWsClientFactory.create(
    wsClient,
    LoggingFnUtils.logRequestWithBody,
    LoggingFnUtils.logResponseWithBody
  )

  /** POST /rest/issuehub/1.0/syncrequests
    *
    * @param requestValue
    * @param remoteInstanceUrl
    * @param syncEvent
    * @return
    */
  def postSyncRequest(
      requestValue: RequestValue,
      remoteInstanceUrl: String,
      syncEvent: ISyncEvent
  ): Future[None.type] = {
    LOG.info(
      s"Posting sync request from sync event: ${requestValue.syncEventId} (isPayed = ${syncEvent.isPayed}) to: $remoteInstanceUrl"
    )
    val connection = syncEvent.getConnection
    val requestFilter = exaToExaRequestFilterFactory.create(connection)
    val request = ws
      .url(UrlUtils.concat(remoteInstanceUrl, SYNC_REQUEST_URL))
      .withHeaders("Content-Type" -> "application/json")
      .withRequestFilter(requestFilter)
    val requestValueJson = Json.toJson(requestValue)

    LOG.trace(
      s"Posting sync request from sync event: ${requestValue.syncEventId} to: $remoteInstanceUrl with json: $requestValueJson."
    )

    exaToExaRequestFilterFactory
      .processWithShortSecretRetry(connection, request.post(requestValueJson))
      .flatMap { r =>
        (new ResponseHandler).handleResponses(connection, r)
      }
      .recoverWith {
        case e: Exception =>
          val details =
            s"Error when posting sync request from sync event `${requestValue.syncEventId}` to `$remoteInstanceUrl`. ${e.getMessage}"
          LOG.error(details, e)
          val exception = errorRestResponseCategoryService.categorizeNetworkAndRestResponseException(
            e,
            Some(details)
          )
          Future.failed(exception)
      }
  }

}
