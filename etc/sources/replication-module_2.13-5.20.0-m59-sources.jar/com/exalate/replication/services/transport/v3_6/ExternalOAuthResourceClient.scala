package com.exalate.replication.services.transport.v3_6

import com.exalate.api.exception.bug.BugException
import com.exalate.replication.services.api.transport.v3_6.IExternalOAuthResourceClient
import com.exalate.replication.services.transport.ExaToExaRequestFilterFactory
import com.exalate.replication.services.transport.value.oauth.{
  OAuthAccessTokenValue,
  OAuthGenerateAccessTokenValue,
  OAuthGenerateUrlReqValue,
  OAuthUrlResValue,
  RegisterOAuthClientReqValue,
  RegisterOAuthClientResValue,
  ValidateAccessTokenReqValue,
  ValidateAccessTokenResValue
}
import com.exalate.util.UrlUtils

import javax.inject.Inject
import play.api.libs.json.{JsError, JsSuccess, Json}
import play.api.libs.ws.WSClient
import play.api.{Configuration, Logger}
import com.exalate.replication.services.transport.value.ExaCompFormatters._

import scala.concurrent.{ExecutionContext, Future}

class ExternalOAuthResourceClient @Inject() (
    val ws: WSClient,
    val configuration: Configuration,
    exaToExaRequestFilterFactory: ExaToExaRequestFilterFactory
)(implicit val ec: ExecutionContext)
    extends IExternalOAuthResourceClient {

  private val REGISTER_OAUTH_CLIENT_URL = "/rest/issuehub/3.6/oauthserver/clients"
  private val GENERATE_AUTHORIZE_URL = "/rest/issuehub/3.6/oauthserver/uris/generate"
  private val GENERATE_ACCESS_TOKENS = "/rest/issuehub/3.6/oauthserver/accesstokens/generate"
  private val VALID_ACCESS_TOKENS = "/rest/issuehub/3.6/oauthserver/accessTokens/validate"
  private val LOG = Logger("application.controllers.transport.rest.v3_6.ExternalOAuthResourceClient")

  /** POST /rest/issuehub/3.6/oauthserver/clients
    *
    * @param authServerUri
    * @param registerOAuthClientReqValue
    * @return
    */
  def register(
      authServerUri: String,
      registerOAuthClientReqValue: RegisterOAuthClientReqValue
  ): Future[RegisterOAuthClientResValue] = {

    val requestFilter = exaToExaRequestFilterFactory.createForAnonResource
    val jsValue = Json.toJson(registerOAuthClientReqValue)(Json.format[RegisterOAuthClientReqValue])
    LOG.info(s"#register sending a POST $authServerUri/rest/issuehub/3.6/oauthserver/clients")
    val url = UrlUtils.concat(authServerUri, REGISTER_OAUTH_CLIENT_URL)
    ws.url(url)
      .withMethod("POST")
      .withBody(jsValue)
      .withRequestFilter(requestFilter)
      .execute()
      .flatMap {
        case badRequest @ res if res.status >= 400 && res.status < 500 =>
          Future.failed(
            new BugException(
              s"#register: POST $authServerUri/rest/issuehub/3.6/oauthserver/clients failed: ${res.status}\n${res.body}"
            )
          )
        case serverError @ res if res.status >= 500                    =>
          Future.failed(
            new BugException(
              s"#register: POST $authServerUri/rest/issuehub/3.6/oauthserver/clients failed: ${res.status}\n${res.body}"
            )
          )
        case created @ res if res.status >= 200 && res.status < 300    =>
          Json
            .parse(created.body)
            .validate[RegisterOAuthClientResValue] match {
            case JsError(es)     =>
              Future.failed(
                new BugException(
                  s"#register: POST $authServerUri/rest/issuehub/3.6/oauthserver/clients returned unrecognized json: ${res.status}\n${res.body}",
                  new BugException(s"JSON parsing error: $es")
                )
              )
            case JsSuccess(v, _) => Future.successful(v)
          }
      }
  }

  /** POST /rest/issuehub/3.6/oauthserver/uris/generate
    * @param authServerUri
    * @param oauthGenerateUrlReqValue
    * @param clientJwt
    * @return
    */
  def generateUrl(
      authServerUri: String,
      oauthGenerateUrlReqValue: OAuthGenerateUrlReqValue,
      clientJwt: String
  ): Future[OAuthUrlResValue] = {
    val jsValue = Json.toJson(oauthGenerateUrlReqValue)
    LOG.info(s"#generateUrl sending a POST $authServerUri$GENERATE_AUTHORIZE_URL")
    val url = UrlUtils.concat(authServerUri, GENERATE_AUTHORIZE_URL)
    val requestFilter = exaToExaRequestFilterFactory.createForAnonResource
    ws.url(url)
      .withMethod("POST")
      .addQueryStringParameters("clientJwt" -> clientJwt)
      .withBody(jsValue)
      .withRequestFilter(requestFilter)
      .execute()
      .flatMap {
        case badRequest @ res if res.status >= 400 && res.status < 500 =>
          Future.failed(
            new BugException(
              s"#generateUrl: POST $authServerUri$GENERATE_AUTHORIZE_URL failed: ${res.status}\n${res.body}"
            )
          )
        case serverError @ res if res.status >= 500                    =>
          Future.failed(
            new BugException(
              s"#generateUrl: POST $authServerUri$GENERATE_AUTHORIZE_URL failed: ${res.status}\n${res.body}"
            )
          )
        case created @ res if res.status >= 200 && res.status < 300    =>
          Json
            .parse(created.body)
            .validate[OAuthUrlResValue] match {
            case JsError(es)     =>
              Future.failed(
                new BugException(
                  s"#generateUrl: POST $authServerUri$GENERATE_AUTHORIZE_URL returned unrecognized json: ${res.status}\n${res.body}",
                  new BugException(s"JSON parsing error: $es")
                )
              )
            case JsSuccess(v, _) => Future.successful(v)
          }
      }
  }

  /** POST /rest/issuehub/3.6/oauthserver/accesstokens/generate
    * @param authServerUri
    * @param oauthGenerateAccessTokenValue
    * @param clientJwt
    * @return
    */
  def generateAccessToken(
      authServerUri: String,
      oauthGenerateAccessTokenValue: OAuthGenerateAccessTokenValue,
      clientJwt: String
  ): Future[OAuthAccessTokenValue] = {
    val jsValue = Json.toJson(oauthGenerateAccessTokenValue)
    LOG.info(s"#generateAccessToken sending a POST $authServerUri$GENERATE_ACCESS_TOKENS")
    val url = UrlUtils.concat(authServerUri, GENERATE_ACCESS_TOKENS)
    val requestFilter = exaToExaRequestFilterFactory.createForAnonResource
    ws.url(url)
      .withMethod("POST")
      .addQueryStringParameters("clientJwt" -> clientJwt)
      .withBody(jsValue)
      .withRequestFilter(requestFilter)
      .execute()
      .flatMap {
        case badRequest @ res if res.status >= 400 && res.status < 500 =>
          Future.failed(
            new BugException(
              s"#generateAccessToken: POST $authServerUri$GENERATE_ACCESS_TOKENS failed: ${res.status}\n${res.body}"
            )
          )
        case serverError @ res if res.status >= 500                    =>
          Future.failed(
            new BugException(
              s"#generateAccessToken: POST $authServerUri$GENERATE_ACCESS_TOKENS failed: ${res.status}\n${res.body}"
            )
          )
        case created @ res if res.status >= 200 && res.status < 300    =>
          Json
            .parse(created.body)
            .validate[OAuthAccessTokenValue] match {
            case JsError(es)     =>
              Future.failed(
                new BugException(
                  s"#generateAccessToken: POST $authServerUri$GENERATE_ACCESS_TOKENS returned unrecognized json: ${res.status}\n${res.body}",
                  new BugException(s"JSON parsing error: $es")
                )
              )
            case JsSuccess(v, _) => Future.successful(v)
          }
      }
  }

  /** POST /rest/issuehub/3.6/oauthserver/accessTokens/validate
    * @param authServerUri
    * @param req
    * @return
    */
  def hasValidAccessToken(
      authServerUri: String,
      req: ValidateAccessTokenReqValue
  ): Future[ValidateAccessTokenResValue] = {
    val jsValue = Json.toJson(req)
    LOG.info(s"#hasValidAccessToken sending a POST $authServerUri$VALID_ACCESS_TOKENS")
    val url = UrlUtils.concat(authServerUri, VALID_ACCESS_TOKENS)
    val requestFilter = exaToExaRequestFilterFactory.createForAnonResource
    ws.url(url)
      .withMethod("POST")
      .withBody(jsValue)
      .withRequestFilter(requestFilter)
      .execute()
      .flatMap {
        case badRequest @ res if res.status >= 400 && res.status < 500 =>
          Future.failed(
            new BugException(
              s"#hasValidAccessToken: POST $authServerUri$VALID_ACCESS_TOKENS failed: ${res.status}\n${res.body}"
            )
          )
        case serverError @ res if res.status >= 500                    =>
          Future.failed(
            new BugException(
              s"#hasValidAccessToken: POST $authServerUri$VALID_ACCESS_TOKENS failed: ${res.status}\n${res.body}"
            )
          )
        case created @ res if res.status >= 200 && res.status < 300    =>
          Json
            .parse(created.body)
            .validate[ValidateAccessTokenResValue] match {
            case JsError(es)     =>
              Future.failed(
                new BugException(
                  s"#hasValidAccessToken: POST $authServerUri$VALID_ACCESS_TOKENS returned unrecognized json: ${res.status}\n${res.body}",
                  new BugException(s"JSON parsing error: $es")
                )
              )
            case JsSuccess(v, _) => Future.successful(v)
          }
      }
  }

}
