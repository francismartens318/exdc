package com.exalate.replication.services.transport.v1.rest.local

import akka.stream.scaladsl.Source
import akka.util.ByteString
import com.exalate.api.domain.IIssueKey
import com.exalate.api.domain.blob.event.IBlobEvent
import com.exalate.api.domain.blob.request.IBlobRequest
import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.event.ISyncEvent
import com.exalate.api.domain.license.ISubscriptionContext
import com.exalate.api.domain.request.ISyncRequest
import com.exalate.api.domain.twintrace.ITrace
import com.exalate.api.persistence.replication.blobevent.IBlobEventReplicationRepository
import com.exalate.domain.node.storeblob.StoredBlobMetaData
import com.exalate.domain.replication.BasicSyncRequest
import com.exalate.error.services.api.IBugExceptionCategoryService
import com.exalate.generic.services.api.ITrackerHubObjectService
import com.exalate.persistence.RepositoryUtils.toIntOpt
import com.exalate.replication.controllers.handlers._
import com.exalate.replication.services.api.node.storeblob.IStoreBlobService
import com.exalate.replication.services.api.transport.ITransportService
import com.exalate.replication.services.transport.value._
import com.exalate.replication.services.transport.value.helpers.{
  RequestValueHelper,
  ResponseValueHelper
}
import play.api.Logger

import javax.inject.Inject
import scala.concurrent.{ExecutionContext, Future}
import scala.util.Try

class LocalTransportService @Inject() (
    requestHandler: SyncRequestHandler,
    requestValueHelper: RequestValueHelper,
    syncResponseHandler: SyncResponseHandler,
    responseValueHelper: ResponseValueHelper,
    errorResponseHandler: ErrorResponseHandler,
    blobRequestHandler: BlobRequestHandler,
    blobResponseHandler: BlobResponseHandler,
    blobErrorResponseHandler: BlobErrorResponseHandler,
    blobEventReplicationRepository: IBlobEventReplicationRepository,
    storeBlobService: IStoreBlobService,
    trackerHubObjectService: ITrackerHubObjectService,
    bugExceptionCategoryService: IBugExceptionCategoryService
)(implicit ec: ExecutionContext)
    extends ITransportService {

  private val LOG = Logger("application.services.transport.LocalTransportService")

  /** Sends Sync Request for local connection
    *
    * @param syncEvent
    * @param subscriptionContext
    * @return
    */
  override def sendSyncRequest(
      syncEvent: ISyncEvent,
      subscriptionContext: ISubscriptionContext
  ): Future[None.type] = {
    LOG.info(
      s"Trying to create a sync request for a local sync event `${syncEvent.getId}` number `${syncEvent.getEventNumber}` on state '${syncEvent.getStatus}' for local issue `${syncEvent.getLocalReplica.getIssueKey.getURN}` and local connection `${syncEvent.getConnection.getName}`"
    )
    requestValueHelper
      .getRequestValue(syncEvent, subscriptionContext)
      .flatMap(requestHandler.handleSyncRequest)
      .map(_ => None)
  }

  /** Publish blob for local connection
    *
    * @param blobEvent
    * @param source
    * @return
    */
  override def publishBlob(
      blobEvent: IBlobEvent,
      source: Source[ByteString, _]
  ): Future[None.type] =
    blobRequestHandler.handleReceiveBlob(
      source,
      blobEvent.getSyncEvent.getConnection.getName,
      blobEvent.getId
    )

  /** Sends sync response for local connection
    *
    * @return
    */
  override def sendSyncResponse(
      basicSyncRequest: BasicSyncRequest,
      traces: Seq[ITrace],
      connection: IConnection,
      twinTraceIdOpt: Option[Int]
  ): Future[None.type] =
    Future
      .fromTry(
        responseValueHelper.getResponseValue(basicSyncRequest, traces, connection, twinTraceIdOpt)
      )
      .flatMap(syncResponseHandler.handleSyncResponse)
      .map(_ => None)

  /** Sends error response for local connection
    *
    * @param syncRequest
    * @return
    */
  override def sendErrorResponse(syncRequest: ISyncRequest): Future[None.type] = {
    val relation: IConnection = syncRequest.getConnection
    val remoteIssueKey = syncRequest.getReplica.getIssueKey
    val sourceIssueKeyValue = IssueKeyValue.convert(remoteIssueKey)

    val errorResponse = ErrorResponseValue(
      syncRequest.getRemoteSyncEventId,
      relation.getName,
      sourceIssueKeyValue,
      syncRequest.getErrorResponseMessage,
      syncRequest.getErrorReason.name
    )
    errorResponseHandler.handleErrorResponse(errorResponse).map(_ => None)
  }

  override def sendErrorResponse(
      basicSyncRequest: BasicSyncRequest,
      connection: IConnection
  ): Future[None.type] = {
    val remoteIssueKey = basicSyncRequest.replica.getIssueKey
    val sourceIssueKeyValue = IssueKeyValue.convert(remoteIssueKey)

    basicSyncRequest.errorReason match {
      case Some(errorReason) =>
        val errorResponse = ErrorResponseValue(
          basicSyncRequest.remoteSyncEventId,
          connection.getName,
          sourceIssueKeyValue,
          basicSyncRequest.errorResponseMessage.getOrElse(""),
          errorReason.name()
        )
        errorResponseHandler.handleErrorResponse(errorResponse).map(_ => None)
      case _                 =>
        val errMsg =
          s"An error reason is missed in the sync request with id=${basicSyncRequest.id} though it is expected to be present."
        val ex = bugExceptionCategoryService.generateBugException(None, Some(errMsg))
        LOG.error(errMsg, ex)
        Future.failed(ex)
    }
  }

  /** Sends blob Error response for local connection
    *
    * @param blobRequest
    * @return
    */
  override def sendBlobErrorResponse(blobRequest: IBlobRequest): Future[None.type] = {
    val syncRequest: ISyncRequest = blobRequest.getSyncRequest
    val relation = syncRequest.getConnection
    val remoteIssueKey = syncRequest.getReplica.getIssueKey
    val sourceIssueKeyValue = IssueKeyValue.convert(remoteIssueKey)

    val blobId = blobRequest.getBlobMetadata.getBlobId
    val blobErrorResponse = BlobErrorResponseValue(
      syncRequest.getRemoteSyncEventId,
      Option(blobRequest.getRemoteBlobEventId),
      relation.getName,
      Try(blobId.toLong).toOption,
      Option(blobId),
      sourceIssueKeyValue,
      blobRequest.getErrorResponseMessage,
      blobRequest.getBlobErrorReason
    )

    blobErrorResponseHandler.handleBlobErrorResponse(blobErrorResponse)
  }

  /** Sends blob request for local connection
    *
    * @param blobEvent
    * @return
    */
  override def sendBlobRequest(blobEvent: IBlobEvent): Future[None.type] =
    blobRequestHandler
      .handleBlobRequest(BlobRequestValue.convert(blobEvent))
      .map(_ => None)

  /** Sends blob response for local connection
    *
    * @param blobRequest
    * @return
    */
  override def sendBlobResponse(blobRequest: IBlobRequest): Future[None.type] = {
    val syncRequest: ISyncRequest = blobRequest.getSyncRequest
    val blobResponseValue = BlobResponseValue(
      syncRequest.getConnection.getName,
      syncRequest.getRemoteSyncEventId,
      toIntOpt(Option[Integer](blobRequest.getRemoteBlobEventId)),
      BlobMetadataValue.convert(blobRequest.getBlobMetadata)
    )
    blobResponseHandler
      .handleBlobResponse(blobResponseValue)
      .map(_ => None)
  }

  /** Handles receive blob for local connection
    *
    * @param blobRequest
    * @return
    */
  override def receiveBlob(blobRequest: IBlobRequest): Future[Option[Source[ByteString, _]]] =
    blobEventReplicationRepository.getBlobEventById(blobRequest.getRemoteBlobEventId).flatMap {
      case Some(blobEvent) =>
        val filePath = blobEvent.getBlobMetadata.getBlobFilePath
        StoredBlobMetaData.get(blobEvent.getBlobMetadata) match {
          case Some(f) =>
            storeBlobService.retrieveBlob(f)
          case None    =>
            val exception = bugExceptionCategoryService.generateNoBlobInFilePathBugException(
              filePath,
              blobEvent.getBlobMetadata.getId,
              blobEvent.getId,
              Some(blobRequest.getId)
            )
            val msg =
              s"File not detected in filepath `$filePath` for blob metadata ID `${blobEvent.getBlobMetadata.getId}` for blob event ID `${blobEvent.getId}`," +
                s" but it had to be stored there during the Store Blob Event State."
            LOG.error(msg, exception)
            Future.failed(exception)
        }

      case None =>
        val connectionName =
          Some(blobRequest).map(_.getSyncRequest).map(_.getConnection).map(_.getName).getOrElse("")
        val msg =
          s"Blob event for blob request ${blobRequest.getId} could not be found, connection name is `${blobRequest.getSyncRequest.getConnection.getName}."
        val exception = bugExceptionCategoryService
          .generateNoBlobEventBugException(connectionName, blobRequest.getId)
        LOG.error(msg, exception)
        Future.failed(exception)
    }

  override def getRemoteIssueUrl(issueKey: IIssueKey, connection: IConnection): Future[Option[String]] =
    trackerHubObjectService.getEntityUrl(issueKey, connection)

  // Not used, since next 4 methods for private to puvlic connection
  override def postRequestReceived(syncRequest: ISyncRequest): Future[None.type] =
    Future.successful(None)

  override def postRequestReceived(
      basicSyncRequest: BasicSyncRequest,
      connection: IConnection
  ): Future[None.type] =
    Future.successful(None)

  override def postResponseReceived(syncEvent: ISyncEvent): Future[None.type] =
    Future.successful(None)

  override def postBlobRequestReceived(blobRequest: IBlobRequest): Future[None.type] =
    Future.successful(None)

  override def postBlobResponseReceived(blobEvent: IBlobEvent): Future[None.type] =
    Future.successful(None)

}
