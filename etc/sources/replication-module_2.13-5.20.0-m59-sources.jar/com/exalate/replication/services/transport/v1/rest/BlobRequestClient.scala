package com.exalate.replication.services.transport.v1.rest

import com.exalate.api.domain.blob.event.IBlobEvent
import com.exalate.error.services.api.IExalateRestErrorResponseCategoryService
import com.exalate.replication.services.transport.value.BlobRequestValue
import com.exalate.replication.services.transport.wrapper.{ILoggingWsClientFactory, LoggingFnUtils}
import com.exalate.replication.services.transport.{ExaToExaRequestFilterFactory, ResponseHandler}
import com.exalate.util.UrlUtils
import play.api.Logger
import play.api.libs.json.Json
import play.api.libs.ws.WSClient

import javax.inject.Inject
import scala.concurrent.{ExecutionContext, Future}

class BlobRequestClient @Inject() (
    wsClient: WSClient,
    loggingWsClientFactory: ILoggingWsClientFactory,
    exaToExaRequestFilterFactory: ExaToExaRequestFilterFactory,
    errorRestResponseCategoryService: IExalateRestErrorResponseCategoryService
)(implicit ec: ExecutionContext)
    extends IBlobRequestClient {
  val BLOB_REQUEST_URL = "/rest/issuehub/1.0/blobrequests"

  private val ws = loggingWsClientFactory.create(
    wsClient,
    LoggingFnUtils.logRequestWithBody,
    LoggingFnUtils.logResponseWithBody
  )

  private val LOG = Logger("application.services.transport.rest.BlobRequestClient")

  /** POST /rest/issuehub/1.0/blobrequests
    * @param blobRequest
    * @param remoteInstanceUrl
    * @param blobEvent
    * @return
    */
  override def postBlobRequest(
      blobRequest: BlobRequestValue,
      remoteInstanceUrl: String,
      blobEvent: IBlobEvent
  ): Future[None.type] = {
    val syncEvent = blobEvent.getSyncEvent
    val connection = syncEvent.getConnection
    val requestFilter = exaToExaRequestFilterFactory.create(connection)
    val url = UrlUtils.concat(remoteInstanceUrl, BLOB_REQUEST_URL)
    val request = ws
      .url(url)
      .withHeaders("Content-Type" -> "application/json")
      .withRequestFilter(requestFilter)
    exaToExaRequestFilterFactory
      .processWithShortSecretRetry(
        connection,
        request
          .post(Json.toJson(blobRequest))
      )
      .flatMap { r =>
        (new ResponseHandler).handleResponses(connection, r)
      }
      .recoverWith {
        case e: Exception =>
          val details =
            s"Exception while posting blob request from sync event `${blobRequest.syncEventId}` to `$remoteInstanceUrl`"
          LOG.error(details, e)
          val exception = errorRestResponseCategoryService.categorizeNetworkAndRestResponseException(
            e,
            Some(details)
          )
          Future.failed(exception)
      }

  }

}
