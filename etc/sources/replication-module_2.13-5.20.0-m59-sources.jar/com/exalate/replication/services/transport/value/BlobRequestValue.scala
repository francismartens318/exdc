package com.exalate.replication.services.transport.value

import com.exalate.api.domain.blob.event.IBlobEvent
import play.api.libs.json.{Json, OFormat}

case class BlobRequestValue(
    relationKey: String,
    syncEventId: Int,
    blobEventId: Option[Int],
    blobMetadata: BlobMetadataValue
)

object BlobRequestValue {

  def convert(blobEvent: IBlobEvent): BlobRequestValue =
    BlobRequestValue(
      blobEvent.getSyncEvent.getConnection.getName,
      blobEvent.getSyncEvent.getId,
      Option(blobEvent.getId),
      BlobMetadataValue.convert(blobEvent.getBlobMetadata)
    )

  implicit val format: OFormat[BlobRequestValue] = Json.format
}
