package com.exalate.replication.services.transport.v1.rest

import com.exalate.api.domain.instance.{IInstance, INonPersistentInstance}
import com.exalate.domain.exception.rest.ExalateAuthenticationRestResponseException
import com.exalate.domain.values.NodeInfoValue
import com.exalate.error.services.api.IBugExceptionCategoryService
import com.exalate.replication.services.transport.security.addBasicAuthHeaders
import com.exalate.replication.services.transport.ExaToExaRequestFilterFactory
import com.exalate.replication.services.transport.value.ExaCompFormatters
import com.exalate.util.UrlUtils
import com.google.inject.Inject
import play.api.Logger
import play.api.libs.json.{JsError, JsSuccess, Json}
import play.api.libs.ws.WSClient

import scala.concurrent.{ExecutionContext, Future}
import scala.util.{Failure, Success, Try}

/** Should never be used for private instances
  */
class NodeInfoClient @Inject() (
    ws: WSClient,
    exaToExaRequestFilterFactory: ExaToExaRequestFilterFactory,
    bugExceptionCategoryService: IBugExceptionCategoryService
)(implicit ec: ExecutionContext)
    extends INodeInfoClient {

  val LOG: Logger = Logger(
    "application.com.exalate.replication.services.transport.v1.rest.NodeInfoClient"
  )

  /** Makes a request to get node info (1.0/nodeinfo/self)
    * @param instance
    * @return
    */
  override def getNodeInfo(instance: IInstance): Future[NodeInfoValue] =
    getNodeInfo(
      instance.getUrl.toExternalForm,
      Option(instance.getRemoteUsername),
      Option(instance.getRemoteUserPassword)
    )

  /** Makes a request to get node info (1.0/nodeinfo/self)
    * @param instance
    * @return
    */
  override def getNodeInfo(instance: INonPersistentInstance): Future[NodeInfoValue] =
    getNodeInfo(
      instance.getUrl.toExternalForm,
      Option(instance.getRemoteUsername),
      Option(instance.getRemoteUserPassword)
    )

  /** GET /rest/issuehub/1.0/nodeinfo/self
    * @param remoteUrl
    * @param remoteUsername
    * @param remotePassword
    * @return
    */
  override def getNodeInfo(
      remoteUrl: String,
      remoteUsername: Option[String],
      remotePassword: Option[String]
  ): Future[NodeInfoValue] = {
    LOG.info(s"Getting node info from node: $remoteUrl")
    val requestFilter = exaToExaRequestFilterFactory.createForAnonResource
    val request = ws.url(UrlUtils.concat(remoteUrl, "/rest/issuehub/1.0/nodeinfo/self"))
    addBasicAuthHeaders(request, remoteUsername, remotePassword)
      .addHttpHeaders("Content-Type" -> "application/json")
      .withRequestFilter(requestFilter)
      .get()
      .flatMap(response =>
        response.status match {
          case status if status >= 200 && status < 400 =>
            Future.fromTry(getNodeInfoInternal(response.body))
          case 404                                     =>
            val message =
              s"Either there is no exalate on the url $remoteUrl or exalate is not accessible"
            Future.failed(new NoSuchElementException(message))
          case 403 | 401                               =>
            val message =
              s"Received status code ${response.status} meaning that access to $remoteUrl has been denied. Please ensure that the provided credentials are valid."
            LOG.error(message)
            Future.failed(ExalateAuthenticationRestResponseException(message, response.status))
          case status if status >= 500                 =>
            val details =
              s"Failed to communicate to '$remoteUrl'. Please contact a destination administrator and ask to take a look in applications logs"
            val exception = bugExceptionCategoryService
              .generateRestExalateTransportBugException(None, Some(details))
            LOG.error(details, exception)
            Future.failed(exception)
          case _                                       =>
            val details = s"The status code: ${response.status}, the response body: ${response.body}"
            val exception = bugExceptionCategoryService
              .generateRestExalateTransportBugException(None, Some(details))
            LOG.error(details, exception)
            Future.failed(exception)
        }
      )
  }

  private def getNodeInfoInternal(nodeInfoJsonAsString: String): Try[NodeInfoValue] =
    Try(Json.parse(nodeInfoJsonAsString))
      .flatMap {
        _.validate[NodeInfoValue] match {
          case JsSuccess(n, _) =>
            Success(n)
          case JsError(e)      =>
            val exception =
              bugExceptionCategoryService.generateJsonIntoValueConvertingFailedBugException(
                nodeInfoJsonAsString,
                "NodeInfoValue",
                Some(JsError.toJson(e).toString())
              )
            LOG.error(
              s"Failed to convert JSON `$nodeInfoJsonAsString` into NodeInfoValue",
              exception
            )
            Failure(exception)
        }
      }

}
