package com.exalate.replication.services.transport.v1.rest

import com.exalate.domain.values.VerificationResponse
import com.exalate.replication.services.transport.value.ExaCompFormatters.verificationValueFormat
import javax.inject.Inject
import play.api.libs.json.JsError.toJson
import play.api.libs.json.{JsError, JsSuccess, JsValue, Json}
import play.api.libs.ws.WSClient
import play.api.{Configuration, Logger}

import scala.concurrent.{ExecutionContext, Future}

class LifecycleClient @Inject() (val ws: WSClient, val configuration: Configuration)(implicit
    ec: ExecutionContext
) {

  private val LOG = Logger("application.services.transport.v1.rest.LifecycleClient")

  private val REGISTRATION_PATH: String = configuration
    .getOptional[String]("exalate.registration.url")
    .getOrElse(
      "https://licensegen.exalate.com/rest/scriptrunner/latest/custom/sendVerificationEmail"
    )

  /** POST https://licensegen.exalate.com/rest/scriptrunner/latest/custom/sendVerificationEmail
    * @param jsValue
    * @return
    */
  def validateData(jsValue: JsValue): Future[Option[VerificationResponse]] = {
    LOG.debug(s"Posting evaluation details: $jsValue to $REGISTRATION_PATH")

    ws.url(REGISTRATION_PATH)
      .addHttpHeaders("Content-Type" -> "application/json")
      .post(jsValue)
      .map { r =>
        LOG.debug(s"Got response from validateData: ${r.status}, with body ${r.body}")
        Json.parse(r.body).validate[VerificationResponse] match {
          case JsSuccess(verificationResponse: VerificationResponse, _) =>
            Some(verificationResponse)
          case e: JsError                                               =>
            LOG.error(
              s"JsError when trying to post details for registration: $jsValue. Error: ${toJson(e).toString()}"
            )
            None
        }
      }
      .recover {
        case e: Exception =>
          LOG.error(
            s"""Exception when trying to post details `$jsValue` for registration. Error message: ${e.getMessage}""",
            e
          )
          None
      }
  }

}
