package com.exalate.replication.services.transport.v1.rest

import com.exalate.domain.values.license.{EvaluationValue, GetLicenseResult}
import play.api.libs.json.JsValue

import scala.concurrent.Future

@deprecated
trait IEvaluationClient {

  def postEvaluationDetails(evaluationValue: EvaluationValue): Future[JsValue]

  def getLicense(instanceUid: String): Future[Option[GetLicenseResult]]

}
