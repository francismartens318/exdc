package com.exalate.replication.services.transport.v2.rest

import akka.stream.scaladsl.Source
import akka.util.ByteString
import com.exalate.api.domain.blob.request.IBlobRequest
import com.google.inject.ImplementedBy

import scala.concurrent.Future

@ImplementedBy(classOf[com.exalate.replication.services.transport.v2.rest.ReceiveBlobClient])
trait IReceiveBlobClient {

  def downloadBlob(
      blobEventId: Int,
      remoteInstanceUrl: String,
      blobRequest: IBlobRequest
  ): Future[Option[Source[ByteString, _]]]

}
