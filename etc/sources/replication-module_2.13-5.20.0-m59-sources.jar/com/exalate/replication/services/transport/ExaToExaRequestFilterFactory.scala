package com.exalate.replication.services.transport

import com.exalate.api.domain.connection.IConnection
import com.exalate.replication.controllers.auth.ExalateExternalJwtAuthService
import com.exalate.replication.services.transport.wrapper.LoggingWsRequest
import play.api.Configuration
import play.api.libs.ws.{WSRequestExecutor, WSRequestFilter, WSResponse}

import java.util.concurrent.TimeUnit
import javax.inject.Inject
import scala.concurrent.duration.Duration
import scala.concurrent.{ExecutionContext, Future}

class ExaToExaRequestFilterFactory @Inject() (
    configuration: Configuration,
    externalJwtAuthService: ExalateExternalJwtAuthService
)(implicit val ec: ExecutionContext) {

  lazy val timeout: Duration = configuration
    .getOptional[Int]("exalate.issuehub.rest.timeout")
    .orElse(Option(300000))
    .map(v => Duration(v, TimeUnit.MILLISECONDS))
    .get

  def create(connection: IConnection): WSRequestFilter =
    WSRequestFilter((e: WSRequestExecutor) =>
      WSRequestExecutor {
        case r @ LoggingWsRequest(_, _, reqLog, resLog) =>
          e(
            LoggingWsRequest(
              externalJwtAuthService,
              externalJwtAuthService.addExternalJwt(r.withRequestTimeout(timeout), connection),
              reqLog,
              resLog
            )
          )
        case r                                          =>
          e(externalJwtAuthService.addExternalJwt(r.withRequestTimeout(timeout), connection))
      }
    )

  def processWithShortSecretRetry(
      connection: IConnection,
      doRequest: => Future[WSResponse]
  ): Future[WSResponse] =
    externalJwtAuthService.processWithShortSecretRetry(connection, doRequest)

  def createForAnonResource: WSRequestFilter =
    WSRequestFilter((e: WSRequestExecutor) =>
      WSRequestExecutor {
        case r @ LoggingWsRequest(_, _, reqLog, resLog) =>
          e(
            LoggingWsRequest(externalJwtAuthService, r.withRequestTimeout(timeout), reqLog, resLog)
          )
        case r                                          => e(r.withRequestTimeout(timeout))
      }
    )

}
