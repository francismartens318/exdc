package com.exalate.replication.services.transport.v4_1

import com.exalate.api.domain.ExalateErrorReason
import com.exalate.api.domain.connection.IConnection
import com.exalate.api.persistence.relation.IRelationRepository
import com.exalate.error.services.api.{
  IBugExceptionCategoryService,
  IExalateRestErrorResponseCategoryService
}
import com.exalate.replication.services.api.transport.rest.v2.IConnectionPollClient
import com.exalate.replication.services.transport.{ExaToExaRequestFilterFactory, ResponseHandler}
import com.exalate.replication.services.transport.v1.rest.SyncRestUtils.Implicits._
import com.exalate.replication.services.transport.value._
import com.exalate.replication.services.transport.wrapper.{ILoggingWsClientFactory, LoggingFnUtils}
import com.exalate.services.api.IMessagesService
import com.exalate.util.UrlUtils
import com.google.inject.Inject
import play.api.Logger
import play.api.libs.json.{JsError, JsSuccess, Json}
import play.api.libs.ws.WSClient

import scala.concurrent.{ExecutionContext, Future}
import scala.util.{Failure, Success}

/** This is a PollClient which is used in the Private side for polling sync messages on Public side
  * (Private-to-Public scenario) The client calls the following REST API: POST
  * /rest/issuehub/4.1/poll/syncevents/syncrequests/search POST
  * /rest/issuehub/4.1/poll/syncrequests/syncresponses/search POST
  * /rest/issuehub/4.1/poll/syncrequests/errorresponses/search POST
  * /rest/issuehub/4.1/poll/syncevents/blobrequests/search POST
  * /rest/issuehub/4.1/poll/syncrequests/blobresponses/search POST
  * /rest/issuehub/4.1/poll/syncrequests/bloberrorresponses/search
  */

class ConnectionPollClient @Inject() (
    wsClient: WSClient,
    loggingWsClientFactory: ILoggingWsClientFactory,
    bugExceptionCategoryService: IBugExceptionCategoryService,
    connectionRepository: IRelationRepository,
    exaToExaRequestFilterFactory: ExaToExaRequestFilterFactory,
    errorRestResponseCategoryService: IExalateRestErrorResponseCategoryService,
    messagesService: IMessagesService
)(implicit ec: ExecutionContext)
    extends IConnectionPollClient {
  private val POLL_REST_URL = "/rest/issuehub/4.1/poll"

  private val ws = loggingWsClientFactory.create(
    wsClient,
    LoggingFnUtils.logRequestWithBody,
    LoggingFnUtils.logResponseWithBody
  )

  private val LOG = Logger("application.services.transport.rest.ConnectionPollClient")

  private def NO_CONNECTION(connectionName: String): String = messagesService
    .translate("com.exalate.connection.notfound", Seq(connectionName))
    .getOrElse(
      s"Connection `$connectionName` not found. Seems like it was removed on the Destination side."
    )

  override def pollSyncRequests(
      connection: IConnection,
      syncRequestValues: Set[Int]
  ): Future[ResponseValue[RequestValue]] = {
    val remoteInstanceUrl = connection.getRemoteInstance.getUrl.toExternalForm
    val finalUrl: String = getPollSyncRequestsUrl(remoteInstanceUrl)
    val requestFilter = exaToExaRequestFilterFactory.create(connection)

    LOG.trace(
      "Polling `N` sync requests from remote instance " + remoteInstanceUrl + " for connection " + connection.getName
    )
    val pollSearchRequestValue = PollSearchRequestValue(syncRequestValues, connection.getName)
    val request = ws
      .url(finalUrl)
      .withHeaders("Content-Type" -> "application/json")
      .withRequestFilter(requestFilter)
      .withMethod("POST")
      .withBody(Json.toJson(pollSearchRequestValue))

    exaToExaRequestFilterFactory
      .processWithShortSecretRetry(connection, request.execute())
      .flatMap { response =>
        (new ResponseHandler).handleResponse(response) match {
          case Success(r)            =>
            val jsValue = Json.parse(r.body)
            jsValue.validate[ResponseValue[RequestValue]] match {
              case JsSuccess(result, _) => Future.successful(result)
              case JsError(es)          =>
                val exception =
                  bugExceptionCategoryService.generateJsonIntoValueConvertingFailedBugException(
                    jsValue.toString,
                    "ResponseValue[RequestValue]",
                    Some(JsError.toJson(es).toString())
                  )
                LOG.error(
                  s"Failed to convert JSON `$jsValue` into ResponseValue[RequestValue]",
                  exception
                )
                Future.failed(exception)
            }
          case Failure(e: Exception)
              if response.status == 404 && checkIfNoConnection(response.body) =>
            LOG.error(
              s"Got response ${response.status} from $remoteInstanceUrl while polling sync requests. ${NO_CONNECTION(connection.getName)} - deactivating it."
            )
            connectionRepository.deActivateConnection(connection.getID)
            Future.failed(e)
          case Failure(e: Exception) =>
            Future.failed(e)
        }
      }
      .recoverWith {
        case e: Exception =>
          val details =
            s"Exception while polling bunch of 'N' sync requests for connection `${connection.getName}` from `$remoteInstanceUrl`"
          LOG.error(details, e)
          val exception = errorRestResponseCategoryService.categorizeNetworkAndRestResponseException(
            e,
            Some(details)
          )
          Future.failed(exception)
      }
  }

  override def pollBlobRequests(
      connection: IConnection,
      blobRequestsValues: Set[Int]
  ): Future[ResponseValue[BlobRequestValue]] = {
    val remoteInstanceUrl = connection.getRemoteInstance.getUrl.toExternalForm
    val finalUrl: String = getPollBlobRequestsUrl(remoteInstanceUrl)
    val requestFilter = exaToExaRequestFilterFactory.create(connection)

    LOG.trace(
      "Polling `N` blob requests from remote instance " + remoteInstanceUrl + " for connection " + connection.getName
    )
    val pollSearchRequestValue = PollSearchRequestValue(blobRequestsValues, connection.getName)
    val request = ws
      .url(finalUrl)
      .withHeaders("Content-Type" -> "application/json")
      .withRequestFilter(requestFilter)
      .withMethod("POST")
      .withBody(Json.toJson(pollSearchRequestValue))

    exaToExaRequestFilterFactory
      .processWithShortSecretRetry(connection, request.execute())
      .flatMap { response =>
        (new ResponseHandler).handleResponse(response) match {
          case Success(r)            =>
            val jsValue = Json.parse(r.body)
            jsValue.validate[ResponseValue[BlobRequestValue]] match {
              case JsSuccess(result, _) => Future.successful(result)
              case JsError(es)          =>
                val exception =
                  bugExceptionCategoryService.generateJsonIntoValueConvertingFailedBugException(
                    jsValue.toString,
                    "ResponseValue[BlobRequestValue]",
                    Some(JsError.toJson(es).toString())
                  )
                LOG.error(
                  s"Failed to convert JSON `$jsValue` into ResponseValue[BlobRequestValue]",
                  exception
                )
                Future.failed(exception)
            }
          case Failure(e: Exception)
              if response.status == 404 && checkIfNoConnection(response.body) =>
            LOG.error(
              s"Got response ${response.status} from $remoteInstanceUrl while polling blob requests. ${NO_CONNECTION(connection.getName)} - deactivating it."
            )
            connectionRepository.deActivateConnection(connection.getID)
            Future.failed(e)
          case Failure(e: Exception) =>
            Future.failed(e)
        }
      }
      .recoverWith {
        case e: Exception =>
          val details =
            s"Exception while polling bunch of 'N' blob requests for connection `${connection.getName}` from `$remoteInstanceUrl`"
          LOG.error(details, e)
          val exception = errorRestResponseCategoryService.categorizeNetworkAndRestResponseException(
            e,
            Some(details)
          )
          Future.failed(exception)
      }

  }

  override def pollSyncResponses(
      connection: IConnection,
      syncResponseValues: Set[Int]
  ): Future[ResponseValue[SyncResponseValue]] = {
    val remoteInstanceUrl = connection.getRemoteInstance.getUrl.toExternalForm
    val finalUrl: String = getPollSyncResponsesUrl(remoteInstanceUrl)
    val requestFilter = exaToExaRequestFilterFactory.create(connection)

    LOG.trace(
      "Polling `N` sync responses from remote instance " + remoteInstanceUrl + " for connection " + connection.getName
    )
    val pollSearchRequestValue = PollSearchRequestValue(syncResponseValues, connection.getName)
    val request = ws
      .url(finalUrl)
      .withHeaders("Content-Type" -> "application/json")
      .withRequestFilter(requestFilter)
      .withMethod("POST")
      .withBody(Json.toJson(pollSearchRequestValue))

    exaToExaRequestFilterFactory
      .processWithShortSecretRetry(connection, request.execute())
      .flatMap { response =>
        (new ResponseHandler).handleResponse(response) match {
          case Success(r)            =>
            val jsValue = Json.parse(r.body)
            jsValue.validate[ResponseValue[SyncResponseValue]] match {
              case JsSuccess(result, _) => Future.successful(result)
              case JsError(es)          =>
                val exception =
                  bugExceptionCategoryService.generateJsonIntoValueConvertingFailedBugException(
                    jsValue.toString,
                    "ResponseValue[SyncResponseValue]",
                    Some(JsError.toJson(es).toString())
                  )
                LOG.error(
                  s"Failed to convert JSON `$jsValue` into ResponseValue[SyncResponseValue]",
                  exception
                )
                Future.failed(exception)
            }
          case Failure(e: Exception)
              if response.status == 404 && checkIfNoConnection(response.body) =>
            LOG.error(
              s"Got response ${response.status} from $remoteInstanceUrl while polling sync responses. ${NO_CONNECTION(connection.getName)} - deactivating it."
            )
            connectionRepository.deActivateConnection(connection.getID)
            Future.failed(e)
          case Failure(e: Exception) =>
            Future.failed(e)
        }
      }
      .recoverWith {
        case e: Exception =>
          val details =
            s"Exception while polling bunch of 'N' sync responses for connection `${connection.getName}` from `$remoteInstanceUrl`"
          LOG.error(details, e)
          val exception = errorRestResponseCategoryService.categorizeNetworkAndRestResponseException(
            e,
            Some(details)
          )
          Future.failed(exception)
      }
  }

  override def pollSyncErrorResponses(
      connection: IConnection,
      syncErrorResponseValues: Set[Int]
  ): Future[ResponseValue[ErrorResponseValue]] = {
    val remoteInstanceUrl = connection.getRemoteInstance.getUrl.toExternalForm
    val finalUrl: String = getPollSyncErrorResponsesUrl(remoteInstanceUrl)
    val requestFilter = exaToExaRequestFilterFactory.create(connection)

    LOG.trace(
      "Polling `N` error responses from remote instance " + remoteInstanceUrl + " for connection " + connection.getName
    )
    val pollSearchRequestValue = PollSearchRequestValue(syncErrorResponseValues, connection.getName)
    val request = ws
      .url(finalUrl)
      .withHeaders("Content-Type" -> "application/json")
      .withRequestFilter(requestFilter)
      .withMethod("POST")
      .withBody(Json.toJson(pollSearchRequestValue))

    exaToExaRequestFilterFactory
      .processWithShortSecretRetry(connection, request.execute())
      .flatMap { response =>
        (new ResponseHandler).handleResponse(response) match {
          case Success(r)            =>
            val jsValue = Json.parse(r.body)
            jsValue.validate[ResponseValue[ErrorResponseValue]] match {
              case JsSuccess(result, _) => Future.successful(result)
              case JsError(es)          =>
                val exception =
                  bugExceptionCategoryService.generateJsonIntoValueConvertingFailedBugException(
                    jsValue.toString,
                    "ResponseValue[ErrorResponseValue]",
                    Some(JsError.toJson(es).toString())
                  )
                LOG.error(
                  s"Failed to convert JSON `$jsValue` into ResponseValue[ErrorResponseValue]",
                  exception
                )
                Future.failed(exception)
            }
          case Failure(e: Exception)
              if response.status == 404 && checkIfNoConnection(response.body) =>
            LOG.error(
              s"Got response ${response.status} from $remoteInstanceUrl while polling sync error responses. ${NO_CONNECTION(connection.getName)} - deactivating it."
            )
            connectionRepository.deActivateConnection(connection.getID)
            Future.failed(e)
          case Failure(e: Exception) =>
            Future.failed(e)
        }
      }
      .recoverWith {
        case e: Exception =>
          val details =
            s"Exception while polling bunch of 'N' error responses for connection `${connection.getName}` from `$remoteInstanceUrl`"
          LOG.error(details, e)
          val exception = errorRestResponseCategoryService.categorizeNetworkAndRestResponseException(
            e,
            Some(details)
          )
          Future.failed(exception)
      }
  }

  override def pollBlobResponses(
      connection: IConnection,
      blobResponseValues: Set[Int]
  ): Future[ResponseValue[BlobResponseValue]] = {
    val remoteInstanceUrl = connection.getRemoteInstance.getUrl.toExternalForm
    val finalUrl: String = getPollBlobResponsesUrl(remoteInstanceUrl)
    val requestFilter = exaToExaRequestFilterFactory.create(connection)

    LOG.trace(
      "Polling `N` blob responses from remote instance " + remoteInstanceUrl + " for connection " + connection.getName
    )
    val pollSearchRequestValue = PollSearchRequestValue(blobResponseValues, connection.getName)
    val request = ws
      .url(finalUrl)
      .withHeaders("Content-Type" -> "application/json")
      .withRequestFilter(requestFilter)
      .withMethod("POST")
      .withBody(Json.toJson(pollSearchRequestValue))

    exaToExaRequestFilterFactory
      .processWithShortSecretRetry(connection, request.execute())
      .flatMap { response =>
        (new ResponseHandler).handleResponse(response) match {
          case Success(r)            =>
            val jsValue = Json.parse(r.body)
            jsValue.validate[ResponseValue[BlobResponseValue]] match {
              case JsSuccess(result, _) => Future.successful(result)
              case JsError(es)          =>
                val exception =
                  bugExceptionCategoryService.generateJsonIntoValueConvertingFailedBugException(
                    jsValue.toString,
                    "ResponseValue[BlobResponseValue]",
                    Some(JsError.toJson(es).toString())
                  )
                LOG.error(
                  s"Failed to convert JSON `$jsValue` into ResponseValue[BlobResponseValue]",
                  exception
                )
                Future.failed(exception)
            }
          case Failure(e: Exception)
              if response.status == 404 && checkIfNoConnection(response.body) =>
            LOG.error(
              s"Got response ${response.status} from $remoteInstanceUrl while polling blob responses. ${NO_CONNECTION(connection.getName)} - deactivating it."
            )
            connectionRepository.deActivateConnection(connection.getID)
            Future.failed(e)
          case Failure(e: Exception) =>
            Future.failed(e)
        }
      }
      .recoverWith {
        case e: Exception =>
          val details =
            s"Exception while polling bunch of 'N' blob responses for connection `${connection.getName}` from `$remoteInstanceUrl`"
          LOG.error(details, e)
          val exception = errorRestResponseCategoryService.categorizeNetworkAndRestResponseException(
            e,
            Some(details)
          )
          Future.failed(exception)
      }
  }

  override def pollBlobErrorResponses(
      connection: IConnection,
      blobErrorResponseValues: Set[Int]
  ): Future[ResponseValue[BlobErrorResponseValue]] = {
    val remoteInstanceUrl = connection.getRemoteInstance.getUrl.toExternalForm
    val finalUrl: String = getPollBlobErrorResponsesUrl(remoteInstanceUrl)
    val requestFilter = exaToExaRequestFilterFactory.create(connection)

    LOG.trace(
      "Polling `N` blob error responses from remote instance " + remoteInstanceUrl + " for connection " + connection.getName
    )
    val pollSearchRequestValue = PollSearchRequestValue(blobErrorResponseValues, connection.getName)
    val request = ws
      .url(finalUrl)
      .withHeaders("Content-Type" -> "application/json")
      .withRequestFilter(requestFilter)
      .withMethod("POST")
      .withBody(Json.toJson(pollSearchRequestValue))

    exaToExaRequestFilterFactory
      .processWithShortSecretRetry(connection, request.execute())
      .flatMap { response =>
        (new ResponseHandler).handleResponse(response) match {
          case Success(r)            =>
            val jsValue = Json.parse(r.body)
            jsValue.validate[ResponseValue[BlobErrorResponseValue]] match {
              case JsSuccess(result, _) => Future.successful(result)
              case JsError(es)          =>
                val exception =
                  bugExceptionCategoryService.generateJsonIntoValueConvertingFailedBugException(
                    jsValue.toString,
                    "ResponseValue[BlobErrorResponseValue]",
                    Some(JsError.toJson(es).toString())
                  )
                LOG.error(
                  s"Failed to convert JSON `$jsValue` into ResponseValue[BlobErrorResponseValue]",
                  exception
                )
                Future.failed(exception)
            }
          case Failure(e: Exception)
              if response.status == 404 && checkIfNoConnection(response.body) =>
            LOG.error(
              s"Got response ${response.status} from $remoteInstanceUrl while polling blob error responses. ${NO_CONNECTION(connection.getName)} - deactivating it."
            )
            connectionRepository.deActivateConnection(connection.getID)
            Future.failed(e)
          case Failure(e: Exception) =>
            Future.failed(e)
        }
      }
      .recoverWith {
        case e: Exception =>
          val details =
            s"Exception while polling bunch of 'N' blob error responses for connection `${connection.getName}` from `$remoteInstanceUrl`"
          LOG.error(details, e)
          val exception = errorRestResponseCategoryService.categorizeNetworkAndRestResponseException(
            e,
            Some(details)
          )
          Future.failed(exception)
      }
  }

  private def getPollSyncRequestsUrl(remoteInstanceUrl: String): String =
    UrlUtils.concat(remoteInstanceUrl, POLL_REST_URL, "syncevents", "syncrequests", "search")

  private def getPollBlobRequestsUrl(remoteInstanceUrl: String): String =
    UrlUtils.concat(remoteInstanceUrl, POLL_REST_URL, "syncevents", "blobrequests", "search")

  private def getPollSyncResponsesUrl(remoteInstanceUrl: String): String =
    UrlUtils.concat(remoteInstanceUrl, POLL_REST_URL, "syncrequests", "syncresponses", "search")

  private def getPollSyncErrorResponsesUrl(remoteInstanceUrl: String): String =
    UrlUtils.concat(remoteInstanceUrl, POLL_REST_URL, "syncrequests", "errorresponses", "search")

  private def getPollBlobResponsesUrl(remoteInstanceUrl: String): String =
    UrlUtils.concat(remoteInstanceUrl, POLL_REST_URL, "syncrequests", "blobresponses", "search")

  private def getPollBlobErrorResponsesUrl(remoteInstanceUrl: String): String =
    UrlUtils.concat(remoteInstanceUrl, POLL_REST_URL, "syncrequests", "bloberrorresponses", "search")

  def checkIfNoConnection(body: String): Boolean =
    Json.parse(body).validate[ErrorValue] match {
      case JsSuccess(b, _) => ExalateErrorReason.CONNECTION_NOT_FOUND.name().equals(b.className)
      case _               => false
    }

}
