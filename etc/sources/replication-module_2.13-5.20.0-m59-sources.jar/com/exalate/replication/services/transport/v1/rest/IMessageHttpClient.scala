package com.exalate.replication.services.transport.v1.rest

import com.exalate.api.domain.connection.IConnection
import com.exalate.domain.transport.message.ExalateMessageChunk
import com.exalate.replication.services.transport.v3_4.MessageHttpClient
import com.google.inject.ImplementedBy

import scala.concurrent.Future

trait IMessageHttpClient {

  /** POST /rest/issuehub/:restVersion/messages
    */
  def sendBatchValue(
      connection: IConnection,
      batchValue: Seq[ExalateMessageChunk]
  ): Future[None.type]

}
