package com.exalate.replication.services.transport.v1.rest

import akka.stream.scaladsl.Source
import akka.util.ByteString
import com.exalate.api.domain.blob.request.IBlobRequest
import com.exalate.error.services.api.{
  IBugExceptionCategoryService,
  IExalateRestErrorResponseCategoryService
}
import com.exalate.replication.services.transport.ExaToExaRequestFilterFactory
import com.exalate.replication.services.transport.wrapper.{ILoggingWsClientFactory, LoggingFnUtils}
import com.exalate.util.UrlUtils

import javax.inject.Inject
import play.api.Logger
import play.api.libs.ws.{WSClient, WSRequest}

import scala.concurrent.{ExecutionContext, Future}

class ReceiveBlobClient @Inject() (
    wsClient: WSClient,
    loggingWsClientFactory: ILoggingWsClientFactory,
    exaToExaRequestFilterFactory: ExaToExaRequestFilterFactory,
    exalateRestErrorResponseCategoryService: IExalateRestErrorResponseCategoryService,
    bugExceptionCategoryService: IBugExceptionCategoryService
)(implicit ec: ExecutionContext)
    extends IReceiveBlobClient {
  val BLOBS_RESOURCE_URL_PART: String = "/plugins/servlet/exalate/1.0/attachment/"

  private val ws = loggingWsClientFactory.create(
    wsClient,
    LoggingFnUtils.logRequestWithBody,
    LoggingFnUtils.logResponseWithBody
  )

  private val LOG = Logger("application.services.transport.rest.ReceiveBlobClient")

  /** /plugins/servlet/exalate/1.0/attachment/:blobid
    * @param blobId
    * @param remoteInstanceUrl
    * @param blobRequest
    * @return
    */
  override def downloadBlob(
      blobId: Long,
      remoteInstanceUrl: String,
      blobRequest: IBlobRequest
  ): Future[Option[Source[ByteString, _]]] = {

    val connection = blobRequest.getSyncRequest.getConnection
    val requestFilter = exaToExaRequestFilterFactory.create(connection)
    val url = UrlUtils.concat(remoteInstanceUrl, BLOBS_RESOURCE_URL_PART, blobId.toString)
    val request: WSRequest = ws
      .url(url)
      .withRequestFilter(requestFilter)
    exaToExaRequestFilterFactory
      .processWithShortSecretRetry(
        connection,
        request
          .stream()
      )
      .flatMap { response =>
        val status: Int = response.status
        status match {
          case s if s == 404 =>
            val details =
              s"Blob for remote blob `$blobId` could not be found on destination instance $remoteInstanceUrl"
            LOG.error(details)
            Future.successful(None)

          case s if s >= 400 =>
            val details =
              s"Response with status code $s when attempting to receive remote blob `$blobId` on destination instance $remoteInstanceUrl"
            val exception = bugExceptionCategoryService.generateRestExalateTransportBugException(
              None,
              Some(details)
            )
            LOG.error(details, exception)
            Future.failed(exception)

          case _ => Future.successful(Some(response.bodyAsSource))
        }
      }
      .recoverWith {
        case e: Exception =>
          val details =
            s"Exception while downloading remote blob `$blobId` on destination instance `$remoteInstanceUrl`"
          LOG.error(details, e)
          val exception = exalateRestErrorResponseCategoryService
            .categorizeNetworkAndRestResponseException(e, Some(details))
          Future.failed(exception)
      }

  }

}
