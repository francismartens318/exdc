package com.exalate.replication.services.transport.v1.rest

import com.exalate.api.domain.event.ISyncEvent
import com.exalate.api.domain.request.ISyncRequest
import com.google.inject.ImplementedBy
import com.exalate.replication.services.transport.value.RequestValue

import scala.concurrent.Future

@ImplementedBy(classOf[SyncRequestClient])
trait ISyncRequestClient {

  /** POST /rest/issuehub/1.0/syncrequests
    */
  def postSyncRequest(
      requestValue: RequestValue,
      remoteInstanceUrl: String,
      syncEvent: ISyncEvent
  ): Future[None.type]

}
