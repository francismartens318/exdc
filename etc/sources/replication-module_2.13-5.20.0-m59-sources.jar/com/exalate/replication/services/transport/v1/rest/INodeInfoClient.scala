package com.exalate.replication.services.transport.v1.rest

import com.exalate.api.domain.instance.{IInstance, INonPersistentInstance}
import com.exalate.domain.values.NodeInfoValue
import com.google.inject.ImplementedBy

import scala.concurrent.Future

@ImplementedBy(classOf[NodeInfoClient])
trait INodeInfoClient {

  /** Makes a request to get node info (1.0/nodeinfo/self)
    * @param instance
    * @return
    */
  def getNodeInfo(instance: IInstance): Future[NodeInfoValue]

  /** Makes a request to get node info (1.0/nodeinfo/self)
    * @param instance
    * @return
    */
  def getNodeInfo(instance: INonPersistentInstance): Future[NodeInfoValue]

  /** GET /rest/issuehub/1.0/nodeinfo/self
    * @param remoteUrl
    * @param remoteUsername
    * @param remotePassword
    * @return
    */
  def getNodeInfo(
      remoteUrl: String,
      remoteUsername: Option[String],
      remotePassword: Option[String]
  ): Future[NodeInfoValue]

}
