package com.exalate.replication.services.transport.v1.rest

import akka.stream.scaladsl.Source
import akka.util.ByteString
import com.exalate.api.domain.blob.event.IBlobEvent
import com.exalate.error.services.api.IExalateRestErrorResponseCategoryService
import com.exalate.replication.services.transport.{ExaToExaRequestFilterFactory, ResponseHandler}
import com.exalate.replication.services.transport.wrapper.{ILoggingWsClientFactory, LoggingFnUtils}
import com.exalate.util.{UrlUtils, Utf8UrlEncoder}

import javax.inject.Inject
import play.api.Logger
import play.api.libs.ws.WSClient

import scala.concurrent.ExecutionContext
import scala.concurrent.Future

class PublishBlobClient @Inject() (
    wsClient: WSClient,
    loggingWsClientFactory: ILoggingWsClientFactory,
    exaToExaRequestFilterFactory: ExaToExaRequestFilterFactory,
    errorRestResponseCategoryService: IExalateRestErrorResponseCategoryService
)(implicit ec: ExecutionContext) {
  val BLOBS_URL = "rest/issuehub/2.4/blobrequests/relations/"

  private val ws = loggingWsClientFactory.create(
    wsClient,
    LoggingFnUtils.logRequestWithoutBody,
    LoggingFnUtils.logResponseWithBody
  )

  private val LOG = Logger("application.services.transport.rest.PublishBlobClient")

  /** POST /rest/issuehub/2.4/blobrequests/relations/:relationName/blobevents/:blobEventId/blob
    * @param blobEvent
    * @param source
    * @return
    *   None
    */
  def postAttachment(blobEvent: IBlobEvent, source: Source[ByteString, _]): Future[None.type] = {
    val blobId = blobEvent.getBlobMetadata.getBlobId
    val connection = blobEvent.getSyncEvent.getConnection
    val requestFilter = exaToExaRequestFilterFactory.create(connection)
    // We rely on the fact that instance url always present because we call this method only for public instance
    val finalUrl = getPublishBlobUrl(blobEvent)
    val remoteInstanceUrl = connection.getRemoteInstance.getUrl.toExternalForm
    // This method used the underlying client as currently ws does not provide a good way to post multi part requests
    // See: https://github.com/playframework/playframework/issues/902
    // TODO: improve posting multi part requests since Play provides a way to do that - https://www.playframework.com/documentation/2.6.x/ScalaWS
    // wsClient.url(finalUrl).post(Source(FilePart("hello", "hello.txt", Option("text/plain"), FileIO.fromPath(file.toPath)) :: DataPart("key", "value") :: List()))
    exaToExaRequestFilterFactory
      .processWithShortSecretRetry(
        connection,
        ws.url(finalUrl)
          .withRequestFilter(requestFilter)
          .post(source)
      )
      .flatMap { r =>
        (new ResponseHandler).handleResponses(connection, r)
      }
      .recoverWith {
        case e: Exception =>
          val details = s"Exception while publishing blob `$blobId` to `$remoteInstanceUrl`"
          LOG.error(details, e)
          val exception = errorRestResponseCategoryService.categorizeNetworkAndRestResponseException(
            e,
            Some(details)
          )
          Future.failed(exception)
      }
  }

  private def getPublishBlobUrl(blobEvent: IBlobEvent): String = {
    val connection = blobEvent.getSyncEvent.getConnection
    val remoteInstanceUrl = connection.getRemoteInstance.getUrl.toExternalForm
    val encodedConnectionName = Utf8UrlEncoder.encode(connection.getName)
    val blobEventId = blobEvent.getId.toString
    UrlUtils.concat(
      remoteInstanceUrl,
      BLOBS_URL,
      encodedConnectionName,
      "blobevents",
      blobEventId,
      "blob"
    )
  }

}
