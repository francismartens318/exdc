package com.exalate.replication.services.transport.value

case class AutoCompleteValue(
    code: String,
    line: Int,
    column: Int,
    allProperties: Option[scala.Boolean]
)
