package com.exalate.replication.services.transport.v2_4

import akka.stream.scaladsl.Source
import akka.util.ByteString
import com.exalate.api.domain.IIssueKey
import com.exalate.api.domain.blob.event.IBlobEvent
import com.exalate.api.domain.blob.request.IBlobRequest
import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.event.ISyncEvent
import com.exalate.api.domain.license.ISubscriptionContext
import com.exalate.api.domain.request.ISyncRequest
import com.exalate.api.domain.twintrace.ITrace
import com.exalate.domain.replication.BasicSyncRequest
import com.exalate.replication.services.api.transport.ITransportService

import scala.concurrent.Future

class RemotePrivateTransportService extends ITransportService {

  override def sendSyncRequest(
      syncEvent: ISyncEvent,
      subscriptionContext: ISubscriptionContext
  ): Future[None.type] = Future.successful(None)

  override def publishBlob(
      blobEvent: IBlobEvent,
      source: Source[ByteString, _]
  ): Future[None.type] = Future.successful(None)

  override def sendSyncResponse(
      basicSyncRequest: BasicSyncRequest,
      traces: Seq[ITrace],
      connection: IConnection,
      twinTraceIdOpt: Option[Int]
  ): Future[None.type] = Future.successful(None)

  override def sendErrorResponse(syncRequest: ISyncRequest): Future[None.type] =
    Future.successful(None)

  override def sendErrorResponse(
      basicSyncRequest: BasicSyncRequest,
      connection: IConnection
  ): Future[None.type] = Future.successful(None)

  override def sendBlobErrorResponse(blobRequest: IBlobRequest): Future[None.type] =
    Future.successful(None)

  override def sendBlobRequest(blobEvent: IBlobEvent): Future[None.type] = Future.successful(None)

  override def sendBlobResponse(blobRequest: IBlobRequest): Future[None.type] =
    Future.successful(None)

  override def receiveBlob(blobRequest: IBlobRequest): Future[Option[Source[ByteString, _]]] =
    Future.successful(None)

  override def getRemoteIssueUrl(issueKey: IIssueKey, relation: IConnection): Future[Option[String]] =
    Future.successful(None)

  override def postRequestReceived(syncRequest: ISyncRequest): Future[None.type] =
    Future.successful(None)

  override def postRequestReceived(
      basicSyncRequest: BasicSyncRequest,
      connection: IConnection
  ): Future[None.type] = Future.successful(None)

  override def postResponseReceived(syncEvent: ISyncEvent): Future[None.type] =
    Future.successful(None)

  override def postBlobRequestReceived(blobRequest: IBlobRequest): Future[None.type] =
    Future.successful(None)

  override def postBlobResponseReceived(blobEvent: IBlobEvent): Future[None.type] =
    Future.successful(None)

}
