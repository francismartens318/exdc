package com.exalate.replication.services.transport.value

case class ConnectEventValue(
    issueId: Long,
    issueUrn: String,
    remoteIssueUrnOpt: Option[String],
    relationIdOpt: Option[String]
)
