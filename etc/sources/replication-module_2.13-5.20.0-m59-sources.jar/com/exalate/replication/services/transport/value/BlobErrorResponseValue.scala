package com.exalate.replication.services.transport.value

import com.exalate.api.domain.blob.BlobErrorReason
import com.exalate.api.domain.blob.request.IBlobRequest
import com.exalate.api.domain.request.ISyncRequest
import play.api.libs.json.{Json, OFormat}

import scala.util.Try
import com.exalate.replication.services.transport.v1.rest.SyncRestUtils.Implicits._

case class BlobErrorResponseValue(
    syncEventId: Int,
    blobEventId: Option[Int],
    relationKey: String,
    blobId: Option[Long],
    blobIdStr: Option[String],
    sourceIssueKey: IssueKeyValue,
    errorMessage: String,
    blobErrorReason: BlobErrorReason
) {

  def getBlobId: String = blobIdStr.orElse(blobId.map(_.toString)).orNull

}

object BlobErrorResponseValue {

  def convert(blobRequest: IBlobRequest): BlobErrorResponseValue = {
    val syncRequest: ISyncRequest = blobRequest.getSyncRequest
    val relation = syncRequest.getConnection
    val remoteIssueKey = syncRequest.getReplica.getIssueKey
    val sourceIssueKeyValue = IssueKeyValue.convert(remoteIssueKey)

    val blobId = blobRequest.getBlobMetadata.getBlobId
    BlobErrorResponseValue(
      syncRequest.getRemoteSyncEventId,
      Option(blobRequest.getRemoteBlobEventId),
      relation.getName,
      Try(blobId.toLong).toOption,
      Option(blobId),
      sourceIssueKeyValue,
      blobRequest.getErrorResponseMessage,
      blobRequest.getBlobErrorReason
    )
  }

  implicit val format: OFormat[BlobErrorResponseValue] = Json.format

}
