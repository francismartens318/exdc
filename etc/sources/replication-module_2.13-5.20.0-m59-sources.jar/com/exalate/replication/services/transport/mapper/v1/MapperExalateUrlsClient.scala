package com.exalate.replication.services.transport.mapper.v1

import java.net.URL
import java.net.URLEncoder.encode

import com.exalate.error.services.api.IBugExceptionCategoryService
import com.exalate.replication.services.api.transport.mapper.IMapperExalateUrlsClient
import com.exalate.util.UrlUtils
import com.google.inject.Inject
import play.api.http.HeaderNames._
import play.api.http.MimeTypes._
import play.api.http.Status._
import play.api.libs.json.{JsError, JsSuccess, Json, OFormat}
import play.api.libs.ws.WSClient
import play.api.{Configuration, Logger}

import scala.concurrent.ExecutionContext
import scala.concurrent.Future
import scala.util.{Failure, Success, Try}

object MapperExalateUrlsClient {
  val EXALATE_URLS_PATH = "/rest/exalate-mapper/1.2/exalate-urls"
  implicit val exalateUrlValueFormat: OFormat[ExalateUrlValue] = Json.format[ExalateUrlValue]

  case class ExalateUrlValue(exalateNodeUrl: String, issueTrackerUrl: String, nodeStatus: String)
}

/** Should never be used for private instances
  */
class MapperExalateUrlsClient @Inject() (
    ws: WSClient,
    config: Configuration,
    bugExceptionCategoryServic: IBugExceptionCategoryService
)(implicit ec: ExecutionContext)
    extends IMapperExalateUrlsClient {

  val LOG: Logger = Logger(
    "application.services.replication.transport.mapper.v1.MapperExalateUrlsClient"
  )

  import MapperExalateUrlsClient._

  val PROD_EXALATE_MAPPER_URL =
    config.getOptional[String]("exalate.mapper.url").getOrElse("https://connect.exalate.net")

  val MAPPER_CREDENTIALS = config
    .get[String]("exalate.exalate-mapper.credentials")

  /** Makes a request to mapper GET
    * https://connect.exalate.net/rest/exalate-mapper/1.2/exalate-urls?issueTrackerUrl={issueTrackerUrl}
    * @param issueTrackerUrl
    * @return
    *   exalate url
    */
  override def getExalateUrl(issueTrackerUrl: URL): Future[URL] = {
    val remoteUrl = issueTrackerUrl.toExternalForm
    val issueTrackerUrlEncodedStr = encode(remoteUrl, "UTF-8")
    val requestUrl = getExalateUrlsUrl + "?issueTrackerUrl=" + issueTrackerUrlEncodedStr
    LOG.info(s"Getting exalate urls from mapper: $requestUrl")
    ws.url(requestUrl)
      .withHeaders(
        CONTENT_TYPE -> JSON,
        AUTHORIZATION -> s"Basic $MAPPER_CREDENTIALS"
      )
      .get()
      .flatMap {
        case response if response.status >= BAD_REQUEST =>
          LOG.info(
            s"#getExalateUrl $requestUrl failed: ${response.status}, the response body: ${response.body}"
          )
          Future.failed(
            new RuntimeException(
              s"The status code: ${response.status}, the response body: ${response.body}"
            )
          )
        case response                                   =>
          getExalateUrls(response.body).map(_.toList.filter(_.nodeStatus.toLowerCase == "active"))
      }
      .flatMap {
        case head :: tail if tail.isEmpty                =>
          LOG.info(s"Found exalate url ${head.exalateNodeUrl} for $remoteUrl")
          Future.successful(head.exalateNodeUrl)
        case exalateUrls @ head :: tail if tail.nonEmpty =>
          LOG.debug(
            "Exalate Mapper seems to know multiple nodes registered " + "for issueTrackerUrl " + remoteUrl + " . " + "The request to " + requestUrl + " returned: [" + exalateUrls
              .mkString(", ") + "]"
          )
          Future.successful(head.exalateNodeUrl)
        case Nil                                         =>
          LOG.debug(
            "Exalate Mapper does not seem to recognize or nodes are archived " + remoteUrl + " . The request to " + requestUrl + " returned 0 results."
          )
          Future.failed(
            new NoSuchElementException(
              "Exalate Mapper does not seem to recognize or nodes are archived " + remoteUrl + " . The request to " + requestUrl + " returned 0 results."
            )
          )
      }
      .flatMap(urlStr => Future.fromTry(Try(new URL(urlStr))))
  }

  private def getExalateUrlsUrl =
    UrlUtils.concat(PROD_EXALATE_MAPPER_URL, EXALATE_URLS_PATH)

  private def getExalateUrls(exalateUrlsJsonAsString: String): Future[Seq[ExalateUrlValue]] =
    Future.fromTry(
      Try(Json.parse(exalateUrlsJsonAsString))
        .flatMap {
          _.validate[Seq[ExalateUrlValue]] match {
            case JsSuccess(n, _) =>
              Success(n)
            case JsError(e)      =>
              val exception =
                bugExceptionCategoryServic.generateJsonIntoValueConvertingFailedBugException(
                  exalateUrlsJsonAsString,
                  "ExalateUrlValue",
                  Some(JsError.toJson(e).toString())
                )
              LOG.error(
                s"Failed to convert JSON `$exalateUrlsJsonAsString` into ExalateUrlValue",
                exception
              )
              Failure(exception)
          }
        }
    )

}
