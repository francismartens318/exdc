package com.exalate.replication.services.transport.v1.rest

import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.request.ISyncRequest
import com.exalate.domain.replication.BasicSyncRequest
import com.exalate.error.services.api.IExalateRestErrorResponseCategoryService
import com.exalate.replication.services.api.error.SyncContext
import com.exalate.replication.services.transport.{ExaToExaRequestFilterFactory, ResponseHandler}
import com.exalate.replication.services.transport.value.ErrorResponseValue
import com.exalate.replication.services.transport.wrapper.{ILoggingWsClientFactory, LoggingFnUtils}
import com.exalate.util.UrlUtils

import javax.inject.Inject
import play.api.Logger
import play.api.libs.json.Json
import play.api.libs.ws.WSClient

import scala.concurrent.ExecutionContext
import scala.concurrent.Future

class ErrorResponsesClient @Inject() (
    wsClient: WSClient,
    loggingWsClientFactory: ILoggingWsClientFactory,
    exaToExaRequestFilterFactory: ExaToExaRequestFilterFactory,
    errorRestResponseCategoryService: IExalateRestErrorResponseCategoryService
)(implicit ec: ExecutionContext)
    extends IErrorResponsesClient {
  val SYNC_RESPONSE_URL = "/rest/issuehub/1.0/errorresponses"

  val ws = loggingWsClientFactory.create(
    wsClient,
    LoggingFnUtils.logRequestWithBody,
    LoggingFnUtils.logResponseWithBody
  )

  val LOG = Logger("application.services.transport.rest.ErrorResponsesClient")

  /** POST /rest/issuehub/1.0/errorresponses
    * @param errorResponseValue
    * @param remoteInstanceUrl
    * @param syncRequest
    * @return
    */
  override def postErrorResponse(
      errorResponseValue: ErrorResponseValue,
      remoteInstanceUrl: String,
      syncRequest: ISyncRequest
  ): Future[None.type] = {
    LOG.info(
      s"Posting error response from sync event: ${errorResponseValue.syncEventId} to: $remoteInstanceUrl"
    )
    val connection = syncRequest.getConnection
    val requestFilter = exaToExaRequestFilterFactory.create(connection)
    val context = SyncContext.createWithSyncRequest(connection, syncRequest)
    val url = UrlUtils.concat(remoteInstanceUrl, SYNC_RESPONSE_URL)
    val request = ws
      .url(url)
      .withHeaders("Content-Type" -> "application/json")
      .withRequestFilter(requestFilter)
    exaToExaRequestFilterFactory
      .processWithShortSecretRetry(
        connection,
        request
          .post(Json.toJson(errorResponseValue))
      )
      .flatMap { r =>
        (new ResponseHandler).handleResponses(connection, r)
      }
      .recoverWith {
        case e: Exception =>
          val details =
            s"Exception while posting error response from sync request `${syncRequest.getId}` for sync event: ${errorResponseValue.syncEventId} to `$remoteInstanceUrl`"
          LOG.error(details, e)
          val exception = errorRestResponseCategoryService.categorizeNetworkAndRestResponseException(
            e,
            Some(details)
          )
          Future.failed(exception)
      }

  }

  override def postErrorResponse(
      errorResponseValue: ErrorResponseValue,
      remoteInstanceUrl: String,
      basicSyncRequest: BasicSyncRequest,
      connection: IConnection
  ): Future[None.type] = {
    LOG.info(
      s"Posting error response from sync event: ${errorResponseValue.syncEventId} to: $remoteInstanceUrl"
    )
    val requestFilter = exaToExaRequestFilterFactory.create(connection)
    val url = UrlUtils.concat(remoteInstanceUrl, SYNC_RESPONSE_URL)
    val request = ws
      .url(url)
      .withHeaders("Content-Type" -> "application/json")
      .withRequestFilter(requestFilter)

    exaToExaRequestFilterFactory
      .processWithShortSecretRetry(
        connection,
        request
          .post(Json.toJson(errorResponseValue))
      )
      .flatMap { r =>
        (new ResponseHandler).handleResponses(connection, r)
      }
      .recoverWith {
        case e: Exception =>
          val details =
            s"Exception while posting error response from sync request `${basicSyncRequest.id}` for sync event: ${errorResponseValue.syncEventId} to `$remoteInstanceUrl`"
          LOG.error(details, e)
          val exception = errorRestResponseCategoryService.categorizeNetworkAndRestResponseException(
            e,
            Some(details)
          )
          Future.failed(exception)
      }
  }

}
