package com.exalate.replication.services.transport.value

import com.exalate.api.domain.{IBlobMetadata, INonPersistentBlobMetadata}
import com.exalate.basic.domain.NonPersistentBlobMetadata
import play.api.libs.json.{Json, OFormat}

import scala.util.Try

case class BlobMetadataValue(blobId: Option[Long], blobIdStr: Option[String], checksum: String) {

  def getBlobId: String = blobIdStr.orElse(blobId.map(_.toString)).orNull

}

object BlobMetadataValue {

  def toNonPersistentBlobMetadata(value: BlobMetadataValue): INonPersistentBlobMetadata =
    new NonPersistentBlobMetadata(value.getBlobId, value.checksum)

  def toNonPersistentBlobMetadataList(
      values: Seq[BlobMetadataValue]
  ): Seq[INonPersistentBlobMetadata] =
    values.map(BlobMetadataValue.toNonPersistentBlobMetadata)

  def convert(blobMetadata: IBlobMetadata): BlobMetadataValue = {
    val blobIdLong: Option[Long] = Try(blobMetadata.getBlobId.toLong).toOption

    BlobMetadataValue(blobIdLong, Option(blobMetadata.getBlobId), blobMetadata.getChecksum)
  }

  implicit val format: OFormat[BlobMetadataValue] = Json.format

}
