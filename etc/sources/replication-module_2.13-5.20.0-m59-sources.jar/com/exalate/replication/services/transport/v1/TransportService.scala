package com.exalate.replication.services.transport.v1

import akka.stream.scaladsl.Source
import akka.util.ByteString
import com.exalate.api.domain.IIssueKey
import com.exalate.api.domain.blob.event.IBlobEvent
import com.exalate.api.domain.blob.request.IBlobRequest
import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.event.ISyncEvent
import com.exalate.api.domain.license.ISubscriptionContext
import com.exalate.api.domain.request.ISyncRequest
import com.exalate.api.domain.twintrace.ITrace
import com.exalate.domain.replication.BasicSyncRequest
import com.exalate.error.services.api.IBugExceptionCategoryService
import com.exalate.generic.services.api.ITrackerHubObjectService
import com.exalate.persistence.RepositoryUtils.toIntOpt
import com.exalate.replication.services.api.transport.ITransportService
import com.exalate.replication.services.api.transport.rest.v2.INotifyReceivedClient
import com.exalate.replication.services.transport.v1.rest._
import com.exalate.replication.services.transport.value._
import com.exalate.replication.services.transport.value.helpers.{
  RequestValueHelper,
  ResponseValueHelper
}

import javax.inject.Inject
import scala.concurrent.{ExecutionContext, Future}
import scala.util.Try

class TransportService @Inject() (
    syncRequestClient: ISyncRequestClient,
    syncResponseClient: ISyncResponsesClient,
    errorResponsesClient: IErrorResponsesClient,
    blobErrorResponsesClient: IBlobErrorResponsesClient,
    blobRequestClient: IBlobRequestClient,
    publishBlobClient: PublishBlobClient,
    receiveBlobClient: IReceiveBlobClient,
    blobResponseClient: IBlobResponsesClient,
    requestValueHelper: RequestValueHelper,
    responseValueHelper: ResponseValueHelper,
    trackerHubObjectService: ITrackerHubObjectService,
    notifyReceivedClient: INotifyReceivedClient,
    bugExceptionCategoryService: IBugExceptionCategoryService
)(implicit ec: ExecutionContext)
    extends ITransportService {

  /** Creates a sync request value and sends it by calling
    * {@link ISyncRequestClient.postSyncRequest()}
    * @param syncEvent
    * @param subscriptionContext
    * @return
    *   None
    */
  override def sendSyncRequest(
      syncEvent: ISyncEvent,
      subscriptionContext: ISubscriptionContext
  ): Future[None.type] =
    // create a sync request value

    requestValueHelper.getRequestValue(syncEvent, subscriptionContext).flatMap { requestValue =>
      // send the sync request value
      // We rely on the fact that instance url always present because we call this method only for public instance
      val remoteInstanceUrl: String =
        syncEvent.getConnection.getRemoteInstance.getUrl.toExternalForm
      syncRequestClient.postSyncRequest(requestValue, remoteInstanceUrl, syncEvent)
    }

  /** Calls {@link PublishBlobClient.postAttachment()} to publish blob (attachment) to the remote
    * side
    * @param blobEvent
    * @param file
    * @return
    *   None
    */
  override def publishBlob(
      blobEvent: IBlobEvent,
      source: Source[ByteString, _]
  ): Future[None.type] =
    publishBlobClient.postAttachment(blobEvent, source)

  /** Creates a sync response value and sends it by calling
    * {@link ISyncResponsesClient.postSyncRequest()}
    * @param syncRequest
    * @param twinTrace
    * @return
    *   None
    */
  override def sendSyncResponse(
      basicSyncRequest: BasicSyncRequest,
      traces: Seq[ITrace],
      connection: IConnection,
      twinTraceIdOpt: Option[Int]
  ): Future[None.type] =
    Future
      .fromTry(
        responseValueHelper.getResponseValue(basicSyncRequest, traces, connection, twinTraceIdOpt)
      )
      .flatMap { responseValue =>
        // We rely on the fact that instance url always present because we call this method only for public instance
        val remoteInstanceUrl = connection.getRemoteInstance.getUrl.toExternalForm
        syncResponseClient.postSyncRequest(
          responseValue,
          remoteInstanceUrl,
          basicSyncRequest,
          connection
        )
      }

  /** Sends error response
    * @param syncRequest
    * @return
    *   None
    */
  override def sendErrorResponse(syncRequest: ISyncRequest): Future[None.type] = {
    val relation: IConnection = syncRequest.getConnection
    // We rely on the fact that instance url always present because we call this method only for public instance
    val remoteInstanceUrl: String = relation.getRemoteInstance.getUrl.toExternalForm
    val remoteIssueKey = syncRequest.getReplica.getIssueKey
    val sourceIssueKeyValue = IssueKeyValue.convert(remoteIssueKey)

    val errorResponse = ErrorResponseValue(
      syncRequest.getRemoteSyncEventId,
      relation.getName,
      sourceIssueKeyValue,
      syncRequest.getErrorResponseMessage,
      syncRequest.getErrorReason.name
    )

    errorResponsesClient.postErrorResponse(errorResponse, remoteInstanceUrl, syncRequest)
  }

  override def sendErrorResponse(
      basicSyncRequest: BasicSyncRequest,
      connection: IConnection
  ): Future[None.type] = {
    // We rely on the fact that instance url always present because we call this method only for public instance
    val remoteInstanceUrl = connection.getRemoteInstance.getUrl.toExternalForm
    val remoteIssueKey = basicSyncRequest.replica.getIssueKey
    val sourceIssueKeyValue = IssueKeyValue.convert(remoteIssueKey)

    basicSyncRequest.errorReason match {
      case Some(errorReason) =>
        val errorResponse = ErrorResponseValue(
          basicSyncRequest.remoteSyncEventId,
          connection.getName,
          sourceIssueKeyValue,
          basicSyncRequest.errorResponseMessage.getOrElse(""),
          errorReason.name()
        )
        errorResponsesClient.postErrorResponse(
          errorResponse,
          remoteInstanceUrl,
          basicSyncRequest,
          connection
        )

      case _ =>
        val errMsg =
          s"An error reason is missed in the sync request with id=${basicSyncRequest.id} though it is expected to be present."
        val ex = bugExceptionCategoryService.generateBugException(None, Some(errMsg))
        Future.failed(ex)
    }
  }

  /** Sends blob error response
    * @param blobRequest
    * @return
    *   None
    */
  override def sendBlobErrorResponse(blobRequest: IBlobRequest): Future[None.type] = {
    val syncRequest: ISyncRequest = blobRequest.getSyncRequest
    val relation = syncRequest.getConnection
    val remoteIssueKey = syncRequest.getReplica.getIssueKey
    val sourceIssueKeyValue = IssueKeyValue.convert(remoteIssueKey)

    val blobErrorResponse = BlobErrorResponseValue(
      syncRequest.getRemoteSyncEventId,
      Option(blobRequest.getRemoteBlobEventId),
      relation.getName,
      Try(blobRequest.getBlobMetadata.getBlobId.toLong).toOption,
      Option(blobRequest.getBlobMetadata.getBlobId),
      sourceIssueKeyValue,
      blobRequest.getErrorResponseMessage,
      blobRequest.getBlobErrorReason
    )

    // We rely on the fact that instance url always present because we call this method only for public instance
    val remoteInstanceUrl: String = relation.getRemoteInstance.getUrl.toExternalForm
    blobErrorResponsesClient.postBlobErrorResponse(blobErrorResponse, remoteInstanceUrl, blobRequest)
  }

  /** Sends blob request
    * @param blobEvent
    * @return
    *   None
    */
  override def sendBlobRequest(blobEvent: IBlobEvent): Future[None.type] =
    blobRequestClient.postBlobRequest(
      BlobRequestValue.convert(blobEvent),
      blobEvent.getSyncEvent.getConnection.getRemoteInstance.getUrl.toExternalForm,
      blobEvent
    )

  /** Sends blob response
    * @param blobRequest
    * @return
    *   None
    */
  override def sendBlobResponse(blobRequest: IBlobRequest): Future[None.type] = {
    val syncRequest: ISyncRequest = blobRequest.getSyncRequest
    val relation = syncRequest.getConnection
    // We rely on the fact that instance url always present because we call this method only for public instance
    val remoteInstanceUrl: String = relation.getRemoteInstance.getUrl.toExternalForm
    val blobResponseValue = BlobResponseValue(
      relation.getName,
      syncRequest.getRemoteSyncEventId,
      toIntOpt(Option[Integer](blobRequest.getRemoteBlobEventId)),
      BlobMetadataValue.convert(blobRequest.getBlobMetadata)
    )
    blobResponseClient.postBlobResponse(blobResponseValue, remoteInstanceUrl, blobRequest)
  }

  /** Downloads blob (attachment)
    * @param blobRequest
    * @return
    *   ByteString
    */
  override def receiveBlob(blobRequest: IBlobRequest): Future[Option[Source[ByteString, _]]] = {
    val syncRequest = blobRequest.getSyncRequest
    val blobId = blobRequest.getBlobMetadata.getBlobId.toLong
    // We rely on the fact that instance url always present because we call this method only for public instance
    receiveBlobClient.downloadBlob(
      blobId,
      syncRequest.getConnection.getRemoteInstance.getUrl.toExternalForm,
      blobRequest
    )
  }

  /** Makes a request to another side to get remote issue url
    * @param remoteTwinTraceId
    * @param relation
    * @return
    */
  override def getRemoteIssueUrl(issueKey: IIssueKey, connection: IConnection): Future[Option[String]] =
    trackerHubObjectService.getEntityUrl(issueKey, connection)

  /** Post Request Received for private to public connection
    * @param syncRequest
    * @return
    *   None
    */
  override def postRequestReceived(syncRequest: ISyncRequest): Future[None.type] =
    notifyReceivedClient.postRequestReceived(syncRequest)

  override def postRequestReceived(
      basicSyncRequest: BasicSyncRequest,
      connection: IConnection
  ): Future[None.type] =
    notifyReceivedClient.postRequestReceived(basicSyncRequest, connection)

  /** Post Response Received for private to public connection
    * @param syncEvent
    * @return
    *   None
    */
  override def postResponseReceived(syncEvent: ISyncEvent): Future[None.type] =
    notifyReceivedClient.postResponseReceived(syncEvent)

  /** Post Blob Request Received for private to public connection
    * @param blobRequest
    * @return
    *   None
    */
  override def postBlobRequestReceived(blobRequest: IBlobRequest): Future[None.type] =
    notifyReceivedClient.postBlobRequestReceived(blobRequest)

  /** Post Blob Response Received for private to public connection
    * @param blobEvent
    * @return
    *   None
    */
  override def postBlobResponseReceived(blobEvent: IBlobEvent): Future[None.type] =
    notifyReceivedClient.postBlobResponseReceived(blobEvent)

}
