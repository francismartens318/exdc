package com.exalate.replication.services.transport.v5_0

import com.exalate.api.domain.connection.IConnection
import com.exalate.domain.transport.message.ExalateMessageChunk
import com.exalate.error.services.api.IExalateRestErrorResponseCategoryService
import com.exalate.replication.services.message.ExalateMessageValueHelper
import com.exalate.replication.services.transport.value.ExaCompFormatters._
import com.exalate.replication.services.transport.{ExaToExaRequestFilterFactory, ResponseHandler}
import com.exalate.replication.services.transport.v1.rest.IMessageHttpClient
import com.exalate.replication.services.transport.wrapper.{ILoggingWsClientFactory, LoggingFnUtils}
import com.exalate.util.{DateUtil, UrlUtils}
import com.google.inject.Inject
import play.api.Logger
import play.api.libs.json.Json
import play.api.libs.ws.WSClient

import scala.concurrent.{ExecutionContext, Future}

class MessageHttpClient @Inject() (
    wsClient: WSClient,
    loggingWsClientFactory: ILoggingWsClientFactory,
    exaToExaRequestFilterFactory: ExaToExaRequestFilterFactory,
    errorRestResponseCategoryService: IExalateRestErrorResponseCategoryService
)(implicit ec: ExecutionContext)
    extends IMessageHttpClient {

  private val LOG: Logger = Logger("application.services.transport.rest.MessageHttpClient")

  val RECEIVE_BATCH_URL = "/rest/issuehub/5.0/messages"

  val ws = loggingWsClientFactory.create(
    wsClient,
    LoggingFnUtils.logRequestWithoutBody,
    LoggingFnUtils.logResponseWithBody
  )

  def sendBatchValue(connection: IConnection, chunks: Seq[ExalateMessageChunk]): Future[None.type] = {
    val batchValue = ExalateMessageValueHelper.toBatchWithEncodedContent(chunks)
    if (LOG.isDebugEnabled) {
      LOG.debug(
        s"#sendBatchValue sending batch `$batchValue` for connection `${connection.getName}` at ${DateUtil.dateNowStr()}"
      )
    } else {
      LOG.info(s"#sendBatchValue sending batch ${chunks.headOption
          .map(_.batchUUID)
          .getOrElse("Unknown")} for connection `${connection.getName}` at ${DateUtil.dateNowStr()}")
    }

    val requestFilter = exaToExaRequestFilterFactory.create(connection)
    val url = UrlUtils.concat(connection.getRemoteInstance.getUrl.toExternalForm, RECEIVE_BATCH_URL)

    exaToExaRequestFilterFactory
      .processWithShortSecretRetry(
        connection,
        ws.url(url)
          .withRequestFilter(requestFilter)
          .post(Json.toJson(batchValue))
      )
      .flatMap { r =>
        Future.fromTry((new ResponseHandler).handleResponse(r)).map(_ => None)
      }
      .recoverWith {
        case e: Exception =>
          val details = s"Exception while sending batchUid value `$batchValue` to `$url`"
          LOG.error(details, e)
          val exception = errorRestResponseCategoryService.categorizeNetworkAndRestResponseException(
            e,
            Some(details)
          )
          Future.failed(exception)
      }

  }

}
