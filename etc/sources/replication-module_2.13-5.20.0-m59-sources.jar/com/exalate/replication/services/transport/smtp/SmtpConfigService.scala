package com.exalate.replication.services.transport.smtp

import com.exalate.error.services.api.IExalateConfigExceptionCategoryService
import org.apache.commons.mail.{DefaultAuthenticator, HtmlEmail}
import play.api.Configuration

import javax.inject.Inject
import scala.util.{Failure, Success, Try}

class SmtpConfigService @Inject() (
    configuration: Configuration,
    exalateConfigExceptionCategoryService: IExalateConfigExceptionCategoryService
) {

  val SMTP_HOST = configuration.getOptional[String]("mail.smtp.host")
  val SMTP_FROM = configuration.getOptional[String]("mail.smtp.from")
  val SMTP_PORT = configuration.getOptional[Int]("mail.smtp.port")
  val SMTP_USER = configuration.getOptional[String]("mail.smtp.user")
  val SMTP_PASS = configuration.getOptional[String]("mail.smtp.pass")

  val SMTP_TLS =
    configuration.getOptional[String]("mail.smtp.tls").map("true".equalsIgnoreCase)

  def getSmtpBackOff(): Int =
    configuration.getOptional[Int]("mail.smtp.backoff").getOrElse(60)

  def getConfigurationParameters: Try[SmtpConfigurationParameters] =
    (SMTP_HOST, SMTP_FROM) match {
      case (Some(host), Some(from)) =>
        val authOpt = SMTP_USER.map((_, SMTP_PASS.getOrElse("")))
        Success(
          SmtpConfigurationParameters(host, SMTP_PORT, from, authOpt, SMTP_TLS.getOrElse(false))
        )
      case (None, _)                =>
        val exception =
          exalateConfigExceptionCategoryService.generateNoSmtpHostExalateConfigException()
        Failure(exception)
      case (Some(_), None)          =>
        val exception =
          exalateConfigExceptionCategoryService.generateNoFromEmailExalateConfigException()
        Failure(exception)
    }

  def getEmailTemplate(
      params: SmtpConfigurationParameters,
      subject: String,
      htmlBody: String
  ): HtmlEmail = {

    val email = new HtmlEmail()
    email.setHostName(params.hostName)
    params.portOpt.foreach(email.setSmtpPort)
    params.authenticationParams.foreach(a =>
      email.setAuthenticator(new DefaultAuthenticator(a._1, a._2))
    )
    email.setStartTLSEnabled(params.tls)
    email.setFrom(params.from)
    email.setSubject(subject)
    email.setHtmlMsg(htmlBody)
    email
  }

}

case class SmtpConfigurationParameters(
    hostName: String,
    portOpt: Option[Int],
    from: String,
    authenticationParams: Option[(String, String)],
    tls: Boolean
) {
  override def toString: String = s"SmtpConfigurationParameters(*****)"
}
