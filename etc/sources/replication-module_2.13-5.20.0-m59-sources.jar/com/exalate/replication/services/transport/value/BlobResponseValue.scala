package com.exalate.replication.services.transport.value

import com.exalate.api.domain.blob.request.IBlobRequest
import com.exalate.persistence.RepositoryUtils.toIntOpt
import play.api.libs.json.{Json, OFormat}

case class BlobResponseValue(
    relationKey: String,
    syncEventId: Int,
    blobEventId: Option[Int],
    blobMetadata: BlobMetadataValue
)

object BlobResponseValue {

  def convert(blobRequest: IBlobRequest): BlobResponseValue =
    BlobResponseValue(
      blobRequest.getSyncRequest.getConnection.getName,
      blobRequest.getSyncRequest.getRemoteSyncEventId,
      toIntOpt(Option[Integer](blobRequest.getRemoteBlobEventId)),
      BlobMetadataValue.convert(blobRequest.getBlobMetadata)
    )

  implicit val format: OFormat[BlobResponseValue] = Json.format

}
