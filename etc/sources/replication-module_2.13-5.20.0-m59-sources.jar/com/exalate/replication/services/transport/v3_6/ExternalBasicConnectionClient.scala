package com.exalate.replication.services.transport.v3_6

import com.exalate.api.domain.connection.IConnection
import com.exalate.domain.values.NodeInfoValue
import com.exalate.domain.values.connection.{
  BasicConnectionRedirectUrlRequestValue,
  BasicConnectionRedirectUrlValue
}
import com.exalate.domain.values.v3_6.{
  UpgradeBasicConnectionRequestValue,
  UpgradeBasicConnectionResponseValue
}
import com.exalate.replication.services.api.transport.v3_6.IExternalBasicConnectionClient
import com.exalate.replication.services.transport.ExaToExaRequestFilterFactory
import com.exalate.replication.services.transport.value.ExaCompFormatters._
import com.exalate.replication.services.transport.wrapper.{ILoggingWsClientFactory, LoggingFnUtils}
import com.exalate.util.UrlUtils

import javax.inject.Inject
import org.apache.commons.codec.binary.Base64
import play.api.Logger
import play.api.libs.json.Json
import play.api.libs.ws.WSClient

import scala.concurrent.{ExecutionContext, Future}

class ExternalBasicConnectionClient @Inject() (
    val wsClient: WSClient,
    exaToExaRequestFilterFactory: ExaToExaRequestFilterFactory,
    loggingWsClientFactory: ILoggingWsClientFactory
)(implicit val ec: ExecutionContext)
    extends IExternalBasicConnectionClient {
  private val POST_UPGRADE_REMOTE_SIDE = "/rest/issuehub/3.6/connections/%s/upgrade"
  private val POST_REDIRECT_URL = "/rest/issuehub/3.6/urls/acceptbasicconnection/generate"

  val LOG = Logger("application.controllers.transport.rest.v3_6.InstanceNameClient")

  val ws = loggingWsClientFactory.create(
    wsClient,
    LoggingFnUtils.logRequestWithBody,
    LoggingFnUtils.logResponseWithBody
  )

  /** Makes a request to the remote side for upgrading connection from BASIC to either
    * CONFIGURE_BOTH_SIDES or SCRIPT POST /rest/issuehub/3.6/connections/:name/upgrade
    * @param connection
    * @param connectionMode
    *   \- CONFIGURE_BOTH_SIDES or SCRIPT
    * @param accessTokenOpt
    * @param nodeInfo
    * @return
    *   UpgradeBasicConnectionResponseValue
    */
  override def upgradeRemoteSide(
      connection: IConnection,
      connectionMode: String,
      accessTokenOpt: Option[String],
      nodeInfo: NodeInfoValue
  ): Future[Option[UpgradeBasicConnectionResponseValue]] = {
    LOG.info(
      s"Sending request to upgrade connection `${connection.getName}` on the remote side ${connection.getRemoteInstance.getUrl.toExternalForm}"
    )
    val encodedConnectionName =
      Base64.encodeBase64URLSafeString(connection.getName.getBytes("UTF-8"))
    val url = UrlUtils.concat(
      connection.getRemoteInstance.getUrl.toExternalForm,
      POST_UPGRADE_REMOTE_SIDE.format(encodedConnectionName)
    )

    val requestValue = UpgradeBasicConnectionRequestValue(
      connection.getName,
      connectionMode,
      accessTokenOpt,
      nodeInfo
    )
    val jsValue = Json.toJson(requestValue)(Json.format[UpgradeBasicConnectionRequestValue])

    val requestFilter = exaToExaRequestFilterFactory.create(connection)
    exaToExaRequestFilterFactory
      .processWithShortSecretRetry(
        connection,
        ws.url(url)
          .withRequestFilter(requestFilter)
          .post(Json.toJson(jsValue))
      )
      .map(r =>
        r.status match {
          case status if status == 200 =>
            Json.parse(r.body).validate[UpgradeBasicConnectionResponseValue].asOpt
          case _                       =>
            LOG.warn(s"#upgradeRemoteSide the status is not 200 ${r.status}")
            None
        }
      )
      .recover {
        case e: Exception =>
          LOG.error(s"#upgradeRemoteSide: Error message: ${e.getMessage}")
          None
      }

  }

  override def getRedirectForInvitation(
      basicConnectionRedirectUrlRequestValue: BasicConnectionRedirectUrlRequestValue
  ): Future[Option[BasicConnectionRedirectUrlValue]] = {
    LOG.info(
      s"Sending request to generate redirect url to ${basicConnectionRedirectUrlRequestValue.issueTrackerUrl}"
    )
    val exalateUrl = basicConnectionRedirectUrlRequestValue.exalateUrl
    val jsValue = Json.toJson(basicConnectionRedirectUrlRequestValue)
    val url = UrlUtils.concat(exalateUrl, POST_REDIRECT_URL)

    ws.url(url)
      .post(jsValue)
      .map(r =>
        r.status match {
          case status if status == 200 =>
            Json.parse(r.body).validate[BasicConnectionRedirectUrlValue].asOpt
          case _                       =>
            LOG.warn(s"#getRedirectForInvitation the status is not 200 ${r.status}")
            None
        }
      )
      .recover {
        case e: Exception =>
          LOG.error(
            s"Remote side $exalateUrl could not generate redirect url for basic connection",
            e
          )
          None
      }
  }

}
