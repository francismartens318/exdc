package com.exalate.replication.services.transport.v1.rest

import com.exalate.api.domain.blob.request.IBlobRequest
import com.google.inject.ImplementedBy
import com.exalate.replication.services.transport.value.{BlobErrorResponseValue, ErrorResponseValue}

import scala.concurrent.Future

@ImplementedBy(classOf[com.exalate.replication.services.transport.v1.rest.BlobErrorResponsesClient])
trait IBlobErrorResponsesClient {

  /** POST /rest/issuehub/1.0/bloberrorresponses
    */
  def postBlobErrorResponse(
      blobErrorResponseValue: BlobErrorResponseValue,
      remoteInstanceUrl: String,
      blobRequest: IBlobRequest
  ): Future[None.type]

}
