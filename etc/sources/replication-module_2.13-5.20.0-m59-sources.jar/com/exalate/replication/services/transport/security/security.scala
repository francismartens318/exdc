package com.exalate.replication.services.transport

import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.instance.IInstance
import play.api.libs.ws.{WSAuthScheme, WSRequest}
import play.api.mvc.Request

package object security {

  def addBasicAuthHeaders(
      request: WSRequest,
      remoteUsername: Option[String],
      remotePassword: Option[String]
  ): WSRequest = {
    val usernameAndPasswordOpt = for {
      instanceRemoteUsername <- remoteUsername if instanceRemoteUsername != ""
      instanceRemotePassword <- remotePassword
    } yield (instanceRemoteUsername, instanceRemotePassword)

    addAuthHeaders(request, usernameAndPasswordOpt)
  }

  def addBasicAuthHeaders(request: WSRequest, connection: IConnection): WSRequest = {
    val usernameAndPasswordOpt = getRemoteCredentialsOpt(connection)
    addAuthHeaders(request, usernameAndPasswordOpt)
  }

  def isRequestAuthenticated[T](request: Request[T]): Boolean =
    request.headers.get("Authorization").isDefined

  private def addAuthHeaders(
      request: WSRequest,
      usernameAndPasswordOpt: Option[(String, String)]
  ): WSRequest =
    usernameAndPasswordOpt match {
      case Some((username, pass)) =>
        request.withAuth(username, pass, WSAuthScheme.BASIC)
      case None                   =>
        request
    }

  private def getRemoteCredentialsOpt(connection: IConnection): Option[(String, String)] =
    (
      for {
        connectionRemoteUsername <- Option(connection.getRemoteUsername)
        if connectionRemoteUsername != ""
        connectionRemotePassword <- Option(connection.getRemotePassword)
      } yield (connectionRemoteUsername, connectionRemotePassword)
    )
      .orElse {
        val remoteInstance: IInstance = connection.getRemoteInstance
        for {
          instanceRemoteUsername <- Option(remoteInstance.getRemoteUsername)
          if instanceRemoteUsername != ""
          instanceRemotePassword <- Option(remoteInstance.getRemoteUserPassword)
        } yield (instanceRemoteUsername, instanceRemotePassword)
      }

}
