package com.exalate.replication.services.transport.v1.rest

import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.request.ISyncRequest
import com.exalate.domain.replication.BasicSyncRequest
import com.exalate.replication.services.transport.value.SyncResponseValue
import com.google.inject.ImplementedBy

import scala.concurrent.Future

@ImplementedBy(classOf[com.exalate.replication.services.transport.v1.rest.SyncResponsesClient])
trait ISyncResponsesClient {

  /** POST /rest/issuehub/1.0/syncresponses
    */
  @deprecated(
    "Will be removed in favor of `postSyncRequest(requestValue, remoteInstanceUrl, basicSyncRequest, connection)`",
    "EXACOMP-1884"
  )
  def postSyncRequest(
      requestValue: SyncResponseValue,
      remoteInstanceUrl: String,
      syncRequest: ISyncRequest
  ): Future[None.type]

  /** POST /rest/issuehub/1.0/syncresponses.
    */
  def postSyncRequest(
      responseValue: SyncResponseValue,
      remoteInstanceUrl: String,
      basicSyncRequest: BasicSyncRequest,
      connection: IConnection
  ): Future[None.type]

}
