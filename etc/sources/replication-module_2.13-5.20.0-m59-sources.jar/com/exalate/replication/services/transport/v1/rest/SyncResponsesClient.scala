package com.exalate.replication.services.transport.v1.rest

import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.request.ISyncRequest
import com.exalate.domain.replication.BasicSyncRequest
import com.exalate.error.services.api.IExalateRestErrorResponseCategoryService
import com.exalate.replication.services.api.error.SyncContext
import com.exalate.replication.services.transport.{ExaToExaRequestFilterFactory, ResponseHandler}
import com.exalate.replication.services.transport.value.SyncResponseValue
import com.exalate.replication.services.transport.wrapper.{ILoggingWsClientFactory, LoggingFnUtils}
import com.exalate.util.UrlUtils

import javax.inject.Inject
import play.api.Logger
import play.api.libs.json.Json
import play.api.libs.ws.WSClient

import scala.concurrent.{ExecutionContext, Future}

class SyncResponsesClient @Inject() (
    wsClient: WSClient,
    loggingWsClientFactory: ILoggingWsClientFactory,
    exaToExaRequestFilterFactory: ExaToExaRequestFilterFactory,
    errorRestResponseCategoryService: IExalateRestErrorResponseCategoryService
)(implicit ec: ExecutionContext)
    extends ISyncResponsesClient {
  val SYNC_RESPONSE_URL = "/rest/issuehub/1.0/syncresponses"
  val LOG: Logger = Logger("services.transport.rest.SyncResponsesClient")

  val ws = loggingWsClientFactory.create(
    wsClient,
    LoggingFnUtils.logRequestWithBody,
    LoggingFnUtils.logResponseWithBody
  )

  /** POST /rest/issuehub/1.0/syncresponses
    * @param responseValue
    * @param remoteInstanceUrl
    * @param syncRequest
    * @return
    */
  override def postSyncRequest(
      responseValue: SyncResponseValue,
      remoteInstanceUrl: String,
      syncRequest: ISyncRequest
  ): Future[None.type] = {
    LOG.info(
      s"Posting sync response from sync event: ${responseValue.syncEventId} to: $remoteInstanceUrl"
    )
    val connection = syncRequest.getConnection
    val requestFilter = exaToExaRequestFilterFactory.create(connection)
    val context = SyncContext.createWithSyncRequest(connection, syncRequest)

    val request = ws
      .url(UrlUtils.concat(remoteInstanceUrl, SYNC_RESPONSE_URL))
      .withHeaders("Content-Type" -> "application/json")
      .withRequestFilter(requestFilter)
    exaToExaRequestFilterFactory
      .processWithShortSecretRetry(
        connection,
        request
          .post(Json.toJson(responseValue))
      )
      .flatMap { r =>
        (new ResponseHandler).handleResponses(connection, r)
      }
      .recoverWith {
        case e: Exception =>
          val details =
            s"Exception when posting sync response from sync request `${syncRequest.getId}` for sync event `${responseValue.syncEventId}` to `$remoteInstanceUrl`"
          LOG.error(details, e)
          val exception = errorRestResponseCategoryService.categorizeNetworkAndRestResponseException(
            e,
            Some(details)
          )
          Future.failed(exception)

      }

  }

  override def postSyncRequest(
      responseValue: SyncResponseValue,
      remoteInstanceUrl: String,
      basicSyncRequest: BasicSyncRequest,
      connection: IConnection
  ): Future[None.type] = {
    LOG.info(
      s"Posting sync response from sync event: ${responseValue.syncEventId} to: $remoteInstanceUrl"
    )
    val requestFilter = exaToExaRequestFilterFactory.create(connection)
    val request = ws
      .url(UrlUtils.concat(remoteInstanceUrl, SYNC_RESPONSE_URL))
      .withHeaders("Content-Type" -> "application/json")
      .withRequestFilter(requestFilter)

    exaToExaRequestFilterFactory
      .processWithShortSecretRetry(
        connection,
        request
          .post(Json.toJson(responseValue))
      )
      .flatMap { r =>
        (new ResponseHandler).handleResponses(connection, r)
      }
      .recoverWith {
        case e: Exception =>
          val details =
            s"Exception when posting sync response from sync request `${basicSyncRequest.id}` for sync event `${responseValue.syncEventId}` to `$remoteInstanceUrl`"
          LOG.error(details, e)
          val exception = errorRestResponseCategoryService.categorizeNetworkAndRestResponseException(
            e,
            Some(details)
          )
          Future.failed(exception)
      }
  }

}
