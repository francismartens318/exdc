package com.exalate.replication.services.transport.v2_4

import com.exalate.api.domain.ExalateErrorReason
import com.exalate.api.domain.connection.IConnection
import com.exalate.api.exception.network.AvailabilityNetworkException
import com.exalate.api.persistence.relation.IRelationRepository
import com.exalate.error.services.api.{
  IBugExceptionCategoryService,
  IExalateRestErrorResponseCategoryService
}
import com.exalate.replication.services.api.error.IErrorService
import com.exalate.replication.services.api.transport.rest.v2.IPollClient
import com.exalate.replication.services.transport.{ExaToExaRequestFilterFactory, ResponseHandler}
import com.exalate.replication.services.transport.v1.rest.SyncRestUtils.Implicits._
import com.exalate.replication.services.transport.value._
import com.exalate.replication.services.transport.wrapper.{ILoggingWsClientFactory, LoggingFnUtils}
import com.exalate.services.api.IMessagesService
import com.exalate.util.{UrlUtils, Utf8UrlEncoder}
import com.google.inject.Inject
import play.api.Logger
import play.api.libs.json.{JsError, JsSuccess, Json}
import play.api.libs.ws.WSClient

import scala.concurrent.ExecutionContext
import scala.concurrent.Future
import scala.util.{Failure, Success}

/** This is a PollClient which is used in the Private side for polling sync messages on Public side
  * (Private-to-Public scenario) The client calls the following REST API: GET
  * /rest/issuehub/2.4/relations/:relationName/syncevents/syncrequests GET
  * /rest/issuehub/2.4/relations/:relationName/syncevents/blobrequests GET
  * /rest/issuehub/2.4/relations/:relationName/syncrequests/syncresponses GET
  * /rest/issuehub/2.4/relations/:relationName/syncrequests/blobresponses GET
  * /rest/issuehub/2.4/relations/:relationName/syncrequests/errorresponses GET
  * /rest/issuehub/2.4/relations/:relationName/syncrequests/bloberrorresponses
  */

class PollClient @Inject() (
    wsClient: WSClient,
    loggingWsClientFactory: ILoggingWsClientFactory,
    connectionRepository: IRelationRepository,
    exaToExaRequestFilterFactory: ExaToExaRequestFilterFactory,
    bugExceptionCategoryService: IBugExceptionCategoryService,
    errorRestResponseCategoryService: IExalateRestErrorResponseCategoryService,
    messagesService: IMessagesService,
    errorService: IErrorService
)(implicit ec: ExecutionContext)
    extends IPollClient {

  private val POLL_REST_URL = "/rest/issuehub/2.4/relations"

  private val ws = loggingWsClientFactory.create(
    wsClient,
    LoggingFnUtils.logRequestWithBody,
    LoggingFnUtils.logResponseWithBody
  )

  val LOG = Logger("application.services.transport.rest.PollClient")

  private def NO_CONNECTION(connectionName: String): String = messagesService
    .translate("com.exalate.connection.notfound", Seq(connectionName))
    .getOrElse(
      s"Connection `$connectionName` not found. Seems like it was removed on the Destination side."
    )

  override def pollSyncRequests(connection: IConnection): Future[Seq[RequestValue]] = {
    val remoteInstanceUrl = connection.getRemoteInstance.getUrl.toExternalForm
    val finalUrl: String = getPollSyncRequestsUrl(connection)
    val requestFilter = exaToExaRequestFilterFactory.create(connection)

    val request = ws
      .url(finalUrl)
      .withHeaders("Content-Type" -> "application/json")
      .withRequestFilter(requestFilter)
      .withMethod("GET")

    exaToExaRequestFilterFactory
      .processWithShortSecretRetry(connection, request.execute())
      .flatMap { response =>
        (new ResponseHandler).handleResponse(response) match {
          case Success(r)            =>
            val jsValue = Json.parse(r.body)
            jsValue.validate[Seq[RequestValue]] match {
              case JsSuccess(result, _) => Future.successful(result)
              case JsError(es)          =>
                val exception =
                  bugExceptionCategoryService.generateJsonIntoValueConvertingFailedBugException(
                    jsValue.toString,
                    "Seq[RequestValue]",
                    Some(JsError.toJson(es).toString())
                  )
                LOG.error(s"Failed to convert JSON `$jsValue` into Seq[RequestValue]", exception)
                Future.failed(exception)
            }
          case Failure(e: Exception)
              if response.status == 404 && checkIfNoConnection(response.body) =>
            LOG.error(
              s"Got response ${response.status} from $remoteInstanceUrl while polling sync requests. ${NO_CONNECTION(connection.getName)} - deactivating it."
            )
            connectionRepository.deActivateConnection(connection.getID)
            Future.failed(e)
          case Failure(e: Exception) =>
            Future.failed(e)
        }
      }
      .recoverWith {
        case e: Exception =>
          val details =
            s"Exception while polling sync requests for connection `${connection.getName}` from `$remoteInstanceUrl`"
          LOG.error(details, e)
          val exception = errorRestResponseCategoryService.categorizeNetworkAndRestResponseException(
            e,
            Some(details)
          )
          handleTransportException(connection, exception)
          Future.failed(exception)
      }
  }

  override def pollBlobRequests(connection: IConnection): Future[Seq[BlobRequestValue]] = {
    val remoteInstanceUrl = connection.getRemoteInstance.getUrl.toExternalForm
    val finalUrl: String = getPollBlobRequestsUrl(connection)

    val request = ws
      .url(finalUrl)
      .withHeaders("Content-Type" -> "application/json")
      .withBasicAuth(connection)
      .withExternalJwt(connection)
      .withMethod("GET")

    exaToExaRequestFilterFactory
      .processWithShortSecretRetry(connection, request.execute())
      .flatMap { response =>
        (new ResponseHandler).handleResponse(response) match {
          case Success(r)            =>
            val jsValue = Json.parse(r.body)
            jsValue
              .validate[Seq[BlobRequestValue]] match {
              case JsSuccess(result, _) => Future.successful(result)
              case JsError(es)          =>
                val exception =
                  bugExceptionCategoryService.generateJsonIntoValueConvertingFailedBugException(
                    jsValue.toString,
                    "Seq[BlobRequestValue]",
                    Some(JsError.toJson(es).toString())
                  )
                LOG.error(s"Failed to convert JSON `$jsValue` into Seq[BlobRequestValue]", exception)
                Future.failed(exception)
            }
          case Failure(e: Exception)
              if response.status == 404 && checkIfNoConnection(response.body) =>
            LOG.error(
              s"Got response ${response.status} from $remoteInstanceUrl while polling blob requests. ${NO_CONNECTION(connection.getName)} - deactivating it."
            )
            connectionRepository.deActivateConnection(connection.getID)
            Future.failed(e)
          case Failure(e: Exception) =>
            Future.failed(e)
        }
      }
      .recoverWith {
        case e: Exception =>
          val details =
            s"Exception while polling blob requests for connection `${connection.getName}` from `$remoteInstanceUrl`"
          LOG.error(details, e)
          val exception = errorRestResponseCategoryService.categorizeNetworkAndRestResponseException(
            e,
            Some(details)
          )
          handleTransportException(connection, exception)
          Future.failed(exception)
      }
  }

  override def pollSyncResponses(connection: IConnection): Future[Seq[SyncResponseValue]] = {
    val remoteInstanceUrl = connection.getRemoteInstance.getUrl.toExternalForm
    val finalUrl: String = getPollSyncResponsesUrl(connection)

    val request = ws
      .url(finalUrl)
      .withHeaders("Content-Type" -> "application/json")
      .withBasicAuth(connection)
      .withExternalJwt(connection)
      .withMethod("GET")

    exaToExaRequestFilterFactory
      .processWithShortSecretRetry(connection, request.execute())
      .flatMap { response =>
        (new ResponseHandler).handleResponse(response) match {
          case Success(r)            =>
            val jsValue = Json.parse(r.body)
            jsValue.validate[Seq[SyncResponseValue]] match {
              case JsSuccess(result, _) => Future.successful(result)
              case JsError(es)          =>
                val exception =
                  bugExceptionCategoryService.generateJsonIntoValueConvertingFailedBugException(
                    jsValue.toString,
                    "Seq[SyncResponseValue]",
                    Some(JsError.toJson(es).toString())
                  )
                LOG.error(
                  s"Failed to convert JSON `$jsValue` into Seq[SyncResponseValue]",
                  exception
                )
                Future.failed(exception)
            }
          case Failure(e: Exception)
              if response.status == 404 && checkIfNoConnection(response.body) =>
            LOG.error(
              s"Got response ${response.status} from $remoteInstanceUrl while polling sync responses. ${NO_CONNECTION(connection.getName)} - deactivating it."
            )
            connectionRepository.deActivateConnection(connection.getID)
            Future.failed(e)
          case Failure(e: Exception) =>
            Future.failed(e)
        }
      }
      .recoverWith {
        case e: Exception =>
          val details =
            s"Exception while polling sync responses for connection `${connection.getName}` from `$remoteInstanceUrl`"
          LOG.error(details, e)
          val exception = errorRestResponseCategoryService.categorizeNetworkAndRestResponseException(
            e,
            Some(details)
          )
          handleTransportException(connection, exception)
          Future.failed(exception)
      }
  }

  override def pollSyncErrorResponses(connection: IConnection): Future[Seq[ErrorResponseValue]] = {
    val remoteInstanceUrl = connection.getRemoteInstance.getUrl.toExternalForm
    val finalUrl: String = getPollSyncErrorResponsesUrl(connection)

    val request = ws
      .url(finalUrl)
      .withHeaders("Content-Type" -> "application/json")
      .withBasicAuth(connection)
      .withExternalJwt(connection)
      .withMethod("GET")

    exaToExaRequestFilterFactory
      .processWithShortSecretRetry(connection, request.execute())
      .flatMap { response =>
        (new ResponseHandler).handleResponse(response) match {
          case Success(r)            =>
            val jsValue = Json.parse(r.body)
            jsValue.validate[Seq[ErrorResponseValue]] match {
              case JsSuccess(result, _) => Future.successful(result)
              case JsError(es)          =>
                val exception =
                  bugExceptionCategoryService.generateJsonIntoValueConvertingFailedBugException(
                    jsValue.toString,
                    "Seq[ErrorResponseValue]",
                    Some(JsError.toJson(es).toString())
                  )
                LOG.error(
                  s"Failed to convert JSON `$jsValue` into Seq[ErrorResponseValue]",
                  exception
                )
                Future.failed(exception)
            }
          case Failure(e: Exception)
              if response.status == 404 && checkIfNoConnection(response.body) =>
            LOG.error(
              s"Got response ${response.status} from $remoteInstanceUrl while polling sync error responses. ${NO_CONNECTION(connection.getName)} - deactivating it."
            )
            connectionRepository.deActivateConnection(connection.getID)
            Future.failed(e)
          case Failure(e: Exception) =>
            Future.failed(e)
        }
      }
      .recoverWith {
        case e: Exception =>
          val details =
            s"Exception while polling error responses for connection `${connection.getName}` from `$remoteInstanceUrl`"
          LOG.error(details, e)
          val exception = errorRestResponseCategoryService.categorizeNetworkAndRestResponseException(
            e,
            Some(details)
          )
          handleTransportException(connection, exception)
          Future.failed(exception)
      }
  }

  override def pollBlobResponses(connection: IConnection): Future[Seq[BlobResponseValue]] = {
    val remoteInstanceUrl = connection.getRemoteInstance.getUrl.toExternalForm
    val finalUrl: String = getPollBlobResponsesUrl(connection)

    val request = ws
      .url(finalUrl)
      .withHeaders("Content-Type" -> "application/json")
      .withBasicAuth(connection)
      .withExternalJwt(connection)
      .withMethod("GET")

    exaToExaRequestFilterFactory
      .processWithShortSecretRetry(connection, request.execute())
      .flatMap { response =>
        (new ResponseHandler).handleResponse(response) match {
          case Success(r)            =>
            val jsValue = Json.parse(r.body)
            jsValue.validate[Seq[BlobResponseValue]] match {
              case JsSuccess(result, _) => Future.successful(result)
              case JsError(es)          =>
                val exception =
                  bugExceptionCategoryService.generateJsonIntoValueConvertingFailedBugException(
                    jsValue.toString,
                    "Seq[BlobResponseValue]",
                    Some(JsError.toJson(es).toString())
                  )
                LOG.error(
                  s"Failed to convert JSON `$jsValue` into Seq[BlobResponseValue]",
                  exception
                )
                Future.failed(exception)
            }
          case Failure(e: Exception)
              if response.status == 404 && checkIfNoConnection(response.body) =>
            LOG.error(
              s"Got response ${response.status} from $remoteInstanceUrl while polling blob responses. ${NO_CONNECTION(connection.getName)} - deactivating it."
            )
            connectionRepository.deActivateConnection(connection.getID)
            Future.failed(e)
          case Failure(e: Exception) =>
            Future.failed(e)
        }
      }
      .recoverWith {
        case e: Exception =>
          val details =
            s"Exception while polling blob responses for connection `${connection.getName}` from `$remoteInstanceUrl`"
          LOG.error(details, e)
          val exception = errorRestResponseCategoryService.categorizeNetworkAndRestResponseException(
            e,
            Some(details)
          )
          handleTransportException(connection, exception)
          Future.failed(exception)
      }
  }

  override def pollBlobErrorResponses(
      connection: IConnection
  ): Future[Seq[BlobErrorResponseValue]] = {
    val remoteInstanceUrl = connection.getRemoteInstance.getUrl.toExternalForm
    val finalUrl: String = getPollBlobErrorResponsesUrl(connection)

    val request = ws
      .url(finalUrl)
      .withHeaders("Content-Type" -> "application/json")
      .withBasicAuth(connection)
      .withExternalJwt(connection)
      .withMethod("GET")

    exaToExaRequestFilterFactory
      .processWithShortSecretRetry(connection, request.execute())
      .flatMap { response =>
        (new ResponseHandler).handleResponse(response) match {
          case Success(r)            =>
            val jsValue = Json.parse(r.body)
            jsValue.validate[Seq[BlobErrorResponseValue]] match {
              case JsSuccess(result, _) => Future.successful(result)
              case JsError(es)          =>
                val exception =
                  bugExceptionCategoryService.generateJsonIntoValueConvertingFailedBugException(
                    jsValue.toString,
                    "Seq[BlobErrorResponseValue]",
                    Some(JsError.toJson(es).toString())
                  )
                LOG.error(
                  s"Failed to convert JSON `$jsValue` into Seq[BlobErrorResponseValue]",
                  exception
                )
                Future.failed(exception)
            }
          case Failure(e: Exception)
              if response.status == 404 && checkIfNoConnection(response.body) =>
            LOG.error(
              s"Got response ${response.status} from $remoteInstanceUrl while polling blob error responses. ${NO_CONNECTION(connection.getName)} - deactivating it."
            )
            connectionRepository.deActivateConnection(connection.getID)
            Future.failed(e)
          case Failure(e: Exception) =>
            Future.failed(e)
        }
      }
      .recoverWith {
        case e: Exception =>
          val details =
            s"Exception while polling blob error responses for connection `${connection.getName}` from `$remoteInstanceUrl`"
          LOG.error(details, e)
          val exception = errorRestResponseCategoryService.categorizeNetworkAndRestResponseException(
            e,
            Some(details)
          )
          handleTransportException(connection, exception)
          Future.failed(exception)
      }
  }

  private def getPollSyncRequestsUrl(connection: IConnection): String = {
    val remoteInstanceUrl = connection.getRemoteInstance.getUrl.toExternalForm
    val encodedConnectionName = Utf8UrlEncoder.encode(connection.getName)
    UrlUtils.concat(
      remoteInstanceUrl,
      POLL_REST_URL,
      encodedConnectionName,
      "syncevents",
      "syncrequests"
    )
  }

  private def getPollBlobRequestsUrl(connection: IConnection): String = {
    val remoteInstanceUrl = connection.getRemoteInstance.getUrl.toExternalForm
    val encodedConnectionName = Utf8UrlEncoder.encode(connection.getName)
    UrlUtils.concat(
      remoteInstanceUrl,
      POLL_REST_URL,
      encodedConnectionName,
      "syncevents",
      "blobrequests"
    )
  }

  private def getPollSyncResponsesUrl(connection: IConnection): String = {
    val remoteInstanceUrl = connection.getRemoteInstance.getUrl.toExternalForm
    val encodedConnectionName = Utf8UrlEncoder.encode(connection.getName)
    UrlUtils.concat(
      remoteInstanceUrl,
      POLL_REST_URL,
      encodedConnectionName,
      "syncrequests",
      "syncresponses"
    )
  }

  private def getPollSyncErrorResponsesUrl(connection: IConnection): String = {
    val remoteInstanceUrl = connection.getRemoteInstance.getUrl.toExternalForm
    val encodedConnectionName = Utf8UrlEncoder.encode(connection.getName)
    UrlUtils.concat(
      remoteInstanceUrl,
      POLL_REST_URL,
      encodedConnectionName,
      "syncrequests",
      "errorresponses"
    )
  }

  private def getPollBlobResponsesUrl(connection: IConnection): String = {
    val remoteInstanceUrl = connection.getRemoteInstance.getUrl.toExternalForm
    val encodedConnectionName = Utf8UrlEncoder.encode(connection.getName)
    UrlUtils.concat(
      remoteInstanceUrl,
      POLL_REST_URL,
      encodedConnectionName,
      "syncrequests",
      "blobresponses"
    )
  }

  private def getPollBlobErrorResponsesUrl(connection: IConnection): String = {
    val remoteInstanceUrl = connection.getRemoteInstance.getUrl.toExternalForm
    val encodedConnectionName = Utf8UrlEncoder.encode(connection.getName)
    UrlUtils.concat(
      remoteInstanceUrl,
      POLL_REST_URL,
      encodedConnectionName,
      "syncrequests",
      "bloberrorresponses"
    )
  }

  private def handleTransportException(connection: IConnection, e: Exception) =
    if (e.isInstanceOf[AvailabilityNetworkException]) {
      errorService.createPollingTransportError(e, connection)
    }

  def checkIfNoConnection(body: String): Boolean =
    Json.parse(body).validate[ErrorValue] match {
      case JsSuccess(b, _) => ExalateErrorReason.CONNECTION_NOT_FOUND.name().equals(b.className)
      case _               => false
    }

}
