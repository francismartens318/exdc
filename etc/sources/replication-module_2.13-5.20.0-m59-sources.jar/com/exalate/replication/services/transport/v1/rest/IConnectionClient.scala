package com.exalate.replication.services.transport.v1.rest

import com.exalate.api.domain.connection.IConnection
import com.exalate.domain.values.v2_5.connection.AcceptInvitationValue
import com.exalate.domain.values.v3_4.CreateInvitedConnectionValue
import com.exalate.replication.services.transport.v3_3.ConnectionClient
import com.google.inject.ImplementedBy

import scala.concurrent.Future

@ImplementedBy(classOf[ConnectionClient])
trait IConnectionClient {

  /** POST /rest/issuehub/3.4/connections/accept
    * @param connection
    * @param createInvitedConnectionValue
    * @return
    */
  def createInvitedConnectionExternalAuth(
      connection: IConnection,
      createInvitedConnectionValue: CreateInvitedConnectionValue
  ): Future[Boolean]

  /** POST /rest/issuehub/2.5/connections/:name/accepted
    * @param relation
    * @param invitationAcceptedValueFuture
    * @return
    */
  def notifyConnectionAccepted(
      relation: IConnection,
      invitationAcceptedValueFuture: Future[Option[AcceptInvitationValue]]
  ): Future[Boolean]

  /** GET /rest/issuehub/2.5/connections/:name/accepted
    * @param connection
    * @return
    */
  def getAcceptedMessage(connection: IConnection): Future[Option[AcceptInvitationValue]]

}
