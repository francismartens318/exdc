package com.exalate.replication.services.transport.v3_3

import com.exalate.api.ILoggingService
import com.exalate.api.domain.connection.IConnection
import com.exalate.domain.values.v2_5.connection.AcceptInvitationValue
import com.exalate.domain.values.v3_4.CreateInvitedConnectionValue
import com.exalate.replication.services.api.config.IGeneralSettingsService
import com.exalate.replication.services.transport.ExaToExaRequestFilterFactory
import com.exalate.replication.services.transport.v1.rest.{IConnectionClient, NodeInfoProvider}
import com.exalate.replication.services.transport.wrapper.{ILoggingWsClientFactory, LoggingFnUtils}
import com.exalate.util.UrlUtils
import com.google.inject.Inject
import org.apache.commons.codec.binary.Base64
import play.api.libs.json.Json
import play.api.libs.ws.WSClient
import com.exalate.replication.services.transport.value.ExaCompFormatters.createInvitedConnectionValueFormat
import play.api.Logger

import scala.concurrent.ExecutionContext
import scala.concurrent.Future

class ConnectionClient @Inject() (
    wsClient: WSClient,
    exaToExaRequestFilterFactory: ExaToExaRequestFilterFactory,
    loggingService: ILoggingService,
    loggingWsClientFactory: ILoggingWsClientFactory
)(implicit ec: ExecutionContext)
    extends IConnectionClient {

  val ACCEPT_CONNECTION = "/rest/issuehub/2.5/connections/%s/accepted"
  val CREATE_INVITED_CONNECTION = "/rest/issuehub/3.4/connections/accept"
  val LOG = Logger("application.services.transport.rest.ConnectionClient")

  val ws = loggingWsClientFactory.create(
    wsClient,
    LoggingFnUtils.logRequestWithBody,
    LoggingFnUtils.logResponseWithBody
  )

  /** POST /rest/issuehub/3.4/connections/accept
    * @param connection
    * @param createInvitedConnectionValue
    * @return
    */
  def createInvitedConnectionExternalAuth(
      connection: IConnection,
      createInvitedConnectionValue: CreateInvitedConnectionValue
  ): Future[Boolean] = {
    val url =
      UrlUtils.concat(connection.getRemoteInstance.getUrl.toExternalForm, CREATE_INVITED_CONNECTION)
    val requestFilter = exaToExaRequestFilterFactory.createForAnonResource
    ws.url(url)
      .withRequestFilter(requestFilter)
      .post(Json.toJson(createInvitedConnectionValue))
      .map(r =>
        r.status match {
          case status if status == 201 => true
          case _                       => false
        }
      )
      .recover {
        case e: Exception =>
          loggingService.error("Could not create invited connection", e)
          false
      }
  }

  /** POST /rest/issuehub/2.5/connections/:name/accepted
    * @param connection
    * @param invitationAcceptedValueFuture
    * @return
    */
  def notifyConnectionAccepted(
      connection: IConnection,
      invitationAcceptedValueFuture: Future[Option[AcceptInvitationValue]]
  ): Future[Boolean] = {

    val requestFilter = exaToExaRequestFilterFactory.create(connection)
    val encodedConnectionName =
      Base64.encodeBase64URLSafeString(connection.getName.getBytes("UTF-8"))
    val url = UrlUtils.concat(
      connection.getRemoteInstance.getUrl.toExternalForm,
      ACCEPT_CONNECTION.format(encodedConnectionName)
    )

    import com.exalate.replication.services.transport.value.ExaCompFormatters.v2_5_acceptInvitationValue
    invitationAcceptedValueFuture.flatMap {
      case Some(iv) =>
        exaToExaRequestFilterFactory
          .processWithShortSecretRetry(
            connection,
            ws.url(url)
              .withRequestFilter(requestFilter)
              .post(Json.toJson(iv))
          )
          .map(r =>
            r.status match {
              case status if status == 204 => true
              case _                       => false
            }
          )
          .recover {
            case e: Exception => false
          }
      case None     => Future.successful(false)

    }

  }

  /** GET /rest/issuehub/2.5/connections/:name/accepted
    * @param connection
    * @return
    */
  def getAcceptedMessage(connection: IConnection): Future[Option[AcceptInvitationValue]] = {

    val encodedConnectionName =
      Base64.encodeBase64URLSafeString(connection.getName.getBytes("UTF-8"))
    val url = UrlUtils.concat(
      connection.getRemoteInstance.getUrl.toExternalForm,
      ACCEPT_CONNECTION.format(encodedConnectionName)
    )

    import com.exalate.replication.services.transport.value.ExaCompFormatters.v2_5_acceptInvitationValue
    exaToExaRequestFilterFactory
      .processWithShortSecretRetry(
        connection,
        ws.url(url)
          .withExternalJwt(connection)
          .withBasicAuth(connection)
          .get()
      )
      .map(r =>
        r.status match {
          case status if status == 200 =>
            Json.parse(r.body).validate[AcceptInvitationValue].asOpt
          case _                       => None
        }
      )
      .recover {
        case _: Exception => None
      }

  }

}
