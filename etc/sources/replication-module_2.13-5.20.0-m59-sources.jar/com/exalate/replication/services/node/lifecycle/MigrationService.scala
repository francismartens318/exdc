package com.exalate.replication.services.node.lifecycle

import com.exalate.replication.services.api.node.lifecycle.IMigrationService

class MigrationService extends IMigrationService
