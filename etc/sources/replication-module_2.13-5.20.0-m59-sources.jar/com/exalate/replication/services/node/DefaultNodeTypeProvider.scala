package com.exalate.replication.services.node

import com.exalate.api.domain.node.NodeType
import com.exalate.generic.services.api.INodeTypeProvider
import javax.inject.Inject

/** this implementation of INodeTypeProvider (which relies on injecting NodeType) is provided for
  * simplicity of integration with EXACOMP, however it's preferable, that new nodes implement this
  * interface on their own implementation, since: a) in some nodes (JIRANODE) one can't inject
  * NodeType, b) one doesn't have to change NodeType enum in EXACOMP in order to implement a new
  * connector
  */
class DefaultNodeTypeProvider @Inject() (nodeType: NodeType) extends INodeTypeProvider {
  override def getNodeType: String = nodeType.toString
}
