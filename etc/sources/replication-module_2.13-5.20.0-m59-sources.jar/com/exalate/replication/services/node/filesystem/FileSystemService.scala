package com.exalate.replication.services.node.filesystem

import akka.stream.Materializer
import com.exalate.api.exception.CategorizedException
import com.exalate.error.services.api.IFileSystemExceptionCategoryService
import com.exalate.replication.services.api.node.filesystem.IFileSystemService
import com.exalate.replication.services.utils.ConfigPropertyService
import com.google.common.collect.Lists
import org.apache.commons.io.FileUtils
import org.slf4j.{Logger, LoggerFactory}

import java.io._
import java.nio.file.Paths._
import java.nio.file.{Files, InvalidPathException, Path, Paths}
import java.util.zip.{ZipEntry, ZipOutputStream}
import javax.inject.Inject

import scala.jdk.CollectionConverters._
import scala.concurrent.{ExecutionContext, Future}
import scala.util.{Failure, Success, Try}

class FileSystemService @Inject() (
    configuration: ConfigPropertyService,
    fileSystemExceptionCategoryService: IFileSystemExceptionCategoryService
)(implicit ec: ExecutionContext, val mat: Materializer)
    extends IFileSystemService {

  private val LOG: Logger =
    LoggerFactory.getLogger(classOf[FileSystemService])

  val SUPPORT_ZIP_DIRECTORY = "exalate.support-zip.dir"
  val SCRIPTS_DIRECTORY = "exalate.scripts.dir"
  val LOG_FILE = "exalate.log.path"
  val BLOB_TEMP_DIR = "exalate.sync.blob.tempDir"

  /** Deletes file
    * @param filePath
    *   path to the file that should be deleted
    * @return
    *   boolean, whether was deleted or not
    */
  override def deleteFile(filePath: String): Future[Boolean] = {
    val file: File = new File(filePath)
    deleteFile(file)
  }

  /** Deletes file
    * @param file
    * @return
    *   boolean, whether was deleted or not
    */
  override def deleteFile(file: File): Future[Boolean] =
    Future.fromTry(
      Try(deleteFileIfExists(file)).recoverWith {
        case exception: Exception =>
          LOG.error(s"Error deleting a file `${file.getAbsolutePath}`.", exception)
          Failure(
            fileSystemExceptionCategoryService.categorizeFileSystemExceptionOnFileRemoval(exception)
          )
      }
    )

  /** Deletes local file that corresponds to provided sync event id and blob id
    * @param syncEventId
    *   sync event id
    * @param blobId
    *   blob id
    * @return
    *   boolean, whether was deleted or not
    */
  override def deleteLocalFile(syncEventId: Int, blobId: String): Future[Boolean] =
    Future
      .fromTry(getBlobTempDirPath)
      .flatMap { blobTempDirStr =>
        Future.fromTry(
          Try(get(blobTempDirStr, s"event-$syncEventId-blob-$blobId"))
            .recoverWith {
              case exception: InvalidPathException =>
                LOG.error(s"Unable to resolve a path string into Path.", exception)
                Failure(
                  fileSystemExceptionCategoryService
                    .generateExalateInvalidPathException(exception, None)
                )
            }
        )
      }
      .flatMap(filePath => deleteFile(filePath.toAbsolutePath.toString))

  /** Deletes local file that corresponds to provided event id
    * @param eventId
    * @return
    *   None
    */
  override def deleteLocalBlobForEvent(eventId: Int): Future[None.type] =
    Future
      .fromTry(getBlobTempDirPath)
      .flatMap { blobTempDirStr =>
        val f = new File(blobTempDirStr)
        val matchingFiles = Option(f.listFiles(new FilenameFilter() {
          override def accept(dir: File, name: String): Boolean =
            name.matches(s"event-$eventId-blob-(.*)")
        }))
          .map(_.toSeq)
          .toSeq
          .flatten

        Future
          .sequence(
            matchingFiles.map(f => deleteFile(f))
          )
          .map(_ => None)
      }

  /** Checks whether the file exists and deletes it
    * @param file
    * @return
    *   boolean, whether was deleted or not
    */
  private def deleteFileIfExists(file: File): Boolean =
    file.exists && file.delete

  /** Finds file by filepath
    * @param filePath
    * @return
    *   `Future[Option[File\]\]`
    */
  override def findLocalBlob(filePath: String): Future[Option[File]] = {
    val f = new File(filePath)
    Future.fromTry(
      Try(if (f.exists() && f.isFile) Some(f) else None)
        .recoverWith {
          case exception: SecurityException =>
            LOG.error(s"Security exception while looking for a file `$filePath`.", exception)
            Failure(
              fileSystemExceptionCategoryService.generateDeniedAccessFileSystemException(exception)
            )
        }
    )
  }

  /** Gets a path of blob temp dir
    * @return
    *   path of blob temp dir
    */
  private def getBlobTempDirPath: Try[String] = configuration.getPropertyValue(BLOB_TEMP_DIR)

  /** Gets a path of exalate scripts
    * @return
    */
  override def getExalateScriptsPath(): Try[Path] = tryResolvePathStrFromConfiguration(
    SCRIPTS_DIRECTORY
  )

  /** Gets a dir of support zip
    * @return
    */
  override def getSupportZipDataDir: Try[Path] = tryResolvePathStrFromConfiguration(
    SUPPORT_ZIP_DIRECTORY
  )

  /** Gets a path from config file by provided key `pathStr`
    * @param pathStr
    * @return
    *   Path
    */
  private def tryResolvePathStrFromConfiguration(pathStr: String): Try[Path] =
    for {
      dir <- configuration.getPropertyValue(pathStr)
      path <- Try(Paths.get(dir))
        .recoverWith {
          case e: InvalidPathException =>
            LOG.error(s"Unable to resolve a path string `$dir` into Path.", e)
            Failure(
              fileSystemExceptionCategoryService.generateExalateInvalidPathException(e, Some(dir))
            )
        }
    } yield path

  /** Gets path of the log file
    * @return
    */
  def getLogPath: Try[Path] = tryResolvePathStrFromConfiguration(LOG_FILE)

  /** Creates Support Zip Directory
    * @return
    *   Unit or Failure
    */
  override def createSupportZipDirectory: Try[Unit] =
    configuration
      .getPropertyValue(SUPPORT_ZIP_DIRECTORY)
      .flatMap { supportZipDirectory =>
        val path = Paths.get(supportZipDirectory)
        if (!Files.exists(path)) Files.createDirectory(path)

        val pathExport = Paths.get(supportZipDirectory, "export")
        if (!Files.exists(pathExport)) Files.createDirectory(pathExport)
        Success(())
      }
      .recoverWith {
        case ce: CategorizedException => Failure(ce)
        case e: Exception             =>
          Failure(
            fileSystemExceptionCategoryService.categorizeFileSystemExceptionOnGeneratingSupportZip(e)
          )
      }

  /** Gets a seq of paths of the external scripts
    * @return
    *   the seq of paths
    */
  def getExternalScripts: Try[Seq[Path]] =
    tryResolvePathStrFromConfiguration(SCRIPTS_DIRECTORY).map { scriptsDir =>
      val fileScriptsDir = scriptsDir.toFile
      if (!fileScriptsDir.exists) Nil
      else {
        val files = Lists.newArrayList(FileUtils.listFiles(fileScriptsDir, null, true)).asScala
        files.map(_.toPath).toSeq
      }
    }

  /** Creates a support zip csv file
    * @param tableName
    *   name of the DB table
    * @return
    *   File
    */
  def createSupportZipCsvFile(tableName: String): Try[File] =
    configuration
      .getPropertyValue(SUPPORT_ZIP_DIRECTORY)
      .map { supportZipDirectory =>
        new File(Paths.get(supportZipDirectory, "export", s"$tableName.csv").toString)
      }
      .recoverWith {
        case e: InvalidPathException =>
          LOG.error(s"Unable to resolve a path string into Path.", e)
          Failure(fileSystemExceptionCategoryService.generateExalateInvalidPathException(e, None))
      }

  /** Zip files
    * @param zipFileName
    *   name of the zip file
    * @param filePaths
    *   seq of paths that should be zipped
    * @return
    *   Unit
    */
  def zipFiles(zipFileName: String, filePaths: Seq[Path]): Try[Unit] = {
    var fos: FileOutputStream = null
    var zos: ZipOutputStream = null
    val buffer = new Array[Byte](1024)

    try {
      val dataDir = getSupportZipDataDir.map(_.toString).get

      fos = new FileOutputStream(Paths.get(dataDir, zipFileName).toString)
      zos = new ZipOutputStream(fos)

      for (path <- filePaths) {
        val file = path.toFile
        if (file.isDirectory) {
          file.listFiles().foreach { childFile =>
            zipFile(zos, buffer, dataDir, childFile)
          }
        } else {
          zipFile(zos, buffer, dataDir, file)
        }
      }

      zos.closeEntry()
      Success(())
    } catch {
      case e: CategorizedException => Failure(e)
      case e: Exception            =>
        LOG.error(s"Error zipping a file", e)
        Failure(fileSystemExceptionCategoryService.categorizeFileSystemExceptionOnZippingFile(e))
    } finally
      if (zos != null)
        try
          zos.close()
        catch {
          case e: IOException => LOG.error("Cannot not close ZipOutputStream", e)
        }
  }

  private def zipFile(
      zos: ZipOutputStream,
      buffer: Array[Byte],
      dataDir: String,
      file: File
  ): Unit = {
    val ze = new ZipEntry(Paths.get(dataDir).relativize(file.toPath).toString)
    zos.putNextEntry(ze)
    try {
      val in = new FileInputStream(file)
      try {
        var len = in.read(buffer)
        while (len > 0) {
          zos.write(buffer, 0, len)
          len = in.read(buffer)
        }
      } finally if (in != null) in.close()
    } catch {
      case e: FileNotFoundException => LOG.error(e.getMessage, e)
    }
  }

  /** Removes Existing Support Zip Data
    * @param paths
    *   seq of zip files
    * @return
    *   Unit
    */
  def removeExistingSupportZipDataIfExists(paths: Seq[Path]): Try[Unit] =
    Try {
      for (path <- paths) Files.deleteIfExists(path)
      configuration
        .getPropertyValue(SUPPORT_ZIP_DIRECTORY)
        .flatMap { supportZipDirectory =>
          val pathExport = Paths.get(supportZipDirectory, "export")
          Files.deleteIfExists(pathExport)
          Success()
        }
    }.flatten
      .recoverWith {
        case e: CategorizedException =>
          LOG.error(s"Error cleaning existing support zip directory ", e)
          Failure(e)
        case e: Exception            =>
          LOG.error(s"Error cleaning existing support zip directory ", e)
          Failure(fileSystemExceptionCategoryService.categorizeFileSystemExceptionOnFileRemoval(e))
      }

}
