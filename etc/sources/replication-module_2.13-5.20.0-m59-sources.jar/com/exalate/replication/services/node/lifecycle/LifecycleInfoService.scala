package com.exalate.replication.services.node.lifecycle

import com.exalate.api.persistence.lifecycle.ILifecycleRepository
import com.exalate.domain.values.lifecycle.LifecycleValue
import com.exalate.replication.services.api.node.lifecycle.ILifecycleInfoService
import com.exalate.services.utils.{FutureUtils, IBuildInfoService}
import com.google.inject.Inject
import play.api.cache.AsyncCacheApi

import java.sql.Timestamp
import java.time.{Duration, Instant}
import java.util.Date
import scala.concurrent.{ExecutionContext, Future}

class LifecycleInfoService @Inject() (
    lifecycleRepository: ILifecycleRepository,
    buildInfoService: IBuildInfoService,
    cache: AsyncCacheApi
)(implicit ec: ExecutionContext)
    extends ILifecycleInfoService {

  import LifecycleInfoService.{EVALUATION_DURATION_DAYS, WARNING_PERIOD_IN_DAYS}

  override def get: Future[LifecycleValue] = lifecycleRepository
    .get()

  override def isEulaAccepted: Boolean =
    FutureUtils.resultInf(lifecycleRepository.getJava()).isEulaAccepted

  override def acceptEula: Future[None.type] =
    lifecycleRepository.acceptEula()

  override def updateLastEmailSentDate(timestamp: Timestamp): Future[None.type] =
    lifecycleRepository
      .updateLastEmailSentDate(timestamp)

  override def updateLastLicenseEmailSentDate(timestamp: Timestamp): Future[None.type] =
    lifecycleRepository
      .updateLastLicenseEmailSentDate(timestamp)

  override def updateLastArchiveWarningEmailSentDate(timestamp: Timestamp): Future[None.type] =
    lifecycleRepository
      .updateLastArchiveWarningEmailSentDate(timestamp)

  override def getEvaluationModeExpirationDate: Instant = {
    val registrationInstant =
      FutureUtils.resultInf(lifecycleRepository.getJava()).getRegistrationDate.toInstant
    registrationInstant.plus(Duration.ofDays(EVALUATION_DURATION_DAYS))
  }

  def calculateEvaluationModeExpirationDate(registrationDate: Date): Instant =
    registrationDate.toInstant
      .plus(Duration.ofDays(EVALUATION_DURATION_DAYS))

  override def ensureLifecycle(): Unit =
    FutureUtils.resultInf(lifecycleRepository.ensureLifecycle())

  override def isExpired: Boolean = {
    val now = Instant.now()
    val expDate = getExpiryDate
    now.isAfter(expDate)
  }

  override def isWarningPeriod: Boolean = {
    val expDate = getExpiryDate
    calculateWarningPeriod(expDate)
  }

  def calculateWarningPeriod(expDate: Instant): Boolean = {
    val now = Instant.now()

    val diff = Duration.between(now, expDate)

    !isExpired && (diff.toDays <= WARNING_PERIOD_IN_DAYS)
  }

  override def getExpiryDate: Instant =
    buildInfoService.getBuildDate.toInstant.plus(Duration.ofDays(730))

  override def markFirstVisit(): Future[None.type] = lifecycleRepository
    .markFirstVisit()

  override def markConnectionIntroShown(admin: String): Future[None.type] = lifecycleRepository
    .markConnectionIntroShown(admin)

  override def updateInstanceUid(instanceUid: String): Future[None.type] = lifecycleRepository
    .updateInstanceUid(instanceUid)

  override def setVerified(): Future[None.type] = lifecycleRepository
    .setVerified()

  override def getInstanceUid: Future[Option[String]] =
    cache.getOrElseUpdate("instanceUid") {
      lifecycleRepository.get().map(_.instanceUid)
    }

  override def getInstanceUidUnsafe: Future[String] = getInstanceUid.map(_.getOrElse(""))

  override def isVerified: Future[Boolean] =
    lifecycleRepository.get().map(_.verified)

  // TODO: ihor. change to future
  override def getRegistrationDate: Date =
    FutureUtils.resultInf(lifecycleRepository.getJava().map(_.getRegistrationDate))

}

object LifecycleInfoService {
  private val EVALUATION_DURATION_DAYS = 30
  private val WARNING_PERIOD_IN_DAYS = 90;
}
