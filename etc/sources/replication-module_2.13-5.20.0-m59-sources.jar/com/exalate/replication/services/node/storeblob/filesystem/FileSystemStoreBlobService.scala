package com.exalate.replication.services.node.storeblob.filesystem

import akka.stream.Materializer
import akka.stream.scaladsl.{FileIO, Source}
import akka.util.ByteString
import com.exalate.domain.node.storeblob.FileSystemStoredBlobMetaData
import com.exalate.error.services.api.IFileSystemExceptionCategoryService
import com.exalate.replication.services.api.node.storeblob.ChecksumInfo
import com.exalate.replication.services.utils.ConfigPropertyService
import org.apache.commons.codec.digest.DigestUtils
import org.slf4j.{Logger, LoggerFactory}

import java.io._
import java.nio.file.Paths._
import java.nio.file.{Files, InvalidPathException, Paths}
import scala.concurrent.{ExecutionContext, Future}
import scala.util.{Failure, Try}

trait FileSystemStoreBlobService {

  protected def configuration: ConfigPropertyService
  protected def fileSystemExceptionCategoryService: IFileSystemExceptionCategoryService
  implicit protected def materializer: Materializer
  implicit protected def ec: ExecutionContext

  private val LOG: Logger =
    LoggerFactory.getLogger(classOf[FileSystemStoreBlobService])

  private val BLOB_TEMP_DIR = "exalate.sync.blob.tempDir"

  private[storeblob] def storeFileSystemBlob(
      filename: String,
      source: Source[ByteString, _]
  ): Future[FileSystemStoredBlobMetaData] =
    Future
      .fromTry(
        configuration
          .getPropertyValue(BLOB_TEMP_DIR)
      )
      .flatMap { dirStr =>
        Future
          .fromTry(Try(get(dirStr, filename)))
          .flatMap { path =>
            source
              .runWith(FileIO.toPath(path))
              .flatMap(io =>
                if (io.status.isSuccess) Future.successful(path.toString)
                else {
                  LOG.error(s"An error occurred while storing blob `$filename`.", io.getError)
                  Future.failed(
                    fileSystemExceptionCategoryService.generateExceptionOnStoringBlob(io.getError)
                  )
                }
              )
          }
          .recoverWith {
            case e: InvalidPathException =>
              LOG.error(s"Unable to resolve a path string `$dirStr` into Path.", e)
              Future.failed(
                fileSystemExceptionCategoryService
                  .generateExalateInvalidPathException(e, Some(dirStr))
              )
            case e: IOException          =>
              LOG.error(s"#storeBlob - Unable to store blob with filename: $filename", e)
              Future.failed(
                fileSystemExceptionCategoryService.categorizeFileSystemExceptionOnFileRemoval(e)
              )
          }
      }
      .map(FileSystemStoredBlobMetaData)

  private[storeblob] def retrieveFileSystemBlob(
      storedBlobMetaData: FileSystemStoredBlobMetaData
  ): Future[Option[Source[ByteString, _]]] = Future.fromTry {
    Try {
      val path = Paths.get(storedBlobMetaData.filePath)
      if (!Files.exists(path)) {
        LOG.debug(s"#retrieveBlob $storedBlobMetaData file with path `$path` does not exist")
        None
      } else {
        LOG.info(s"#retrieveBlob $storedBlobMetaData file with path `$path` exists")
        Option(FileIO.fromPath(path))
      }
    }
      .recoverWith {
        case e =>
          LOG.error(s"#retrieveBlob failed to retrieve $storedBlobMetaData", e)
          Failure(e)
      }
  }

  private[storeblob] def deleteFileSystemBlob(
      storedBlobMetaData: FileSystemStoredBlobMetaData
  ): Future[Unit] =
    Future.fromTry {
      val path = Paths.get(storedBlobMetaData.filePath)
      val t = Try(Files.deleteIfExists(path))
        .map(_ => ())
      t
    }

  /** Gets checksum for file
    * @param tempFilePath
    *   path to the file
    * @return
    *   computed checksum
    */
  private[storeblob] def getFileSystemChecksum(
      storedBlobMetaData: FileSystemStoredBlobMetaData
  ): Future[ChecksumInfo] =
    for {
      checkSum <- calculateChecksum(storedBlobMetaData.filePath)
      fileSize = storedBlobMetaData.filePath.length()
    } yield ChecksumInfo(checkSum, fileSize)

  private def calculateChecksum(filePath: String) =
    Future
      .fromTry {
        Try(new FileInputStream(filePath))
          .flatMap { inputStream =>
            val checksumTry = Try(DigestUtils.md5Hex(inputStream))
            inputStream.close()
            checksumTry
          }
      }
      .recoverWith {
        case e: FileNotFoundException =>
          LOG.error(
            s"Checksum failed because file $filePath was not found in file system or Exalate has no permissions to read file. This can happen because of multiple reasons: file removed manually, migration of node from cluster, changes in folder's permission etc",
            e
          )
          Future.failed(
            fileSystemExceptionCategoryService
              .generateCouldNotFindReadableFileInPathFileSystemException(filePath)
          )
        case e: Exception             =>
          LOG.error(
            s"An error occurred while computing a checksum for a file `$filePath`.",
            e
          )
          Future.failed(
            fileSystemExceptionCategoryService
              .generateChecksumComputingException(e, filePath)
          )
      }

}
