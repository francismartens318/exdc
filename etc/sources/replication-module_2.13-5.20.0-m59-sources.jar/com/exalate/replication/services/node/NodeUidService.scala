package com.exalate.replication.services.node

import java.util.UUID
import com.exalate.replication.services.api.node.INodeUidService
import com.exalate.replication.services.api.node.lifecycle.ILifecycleInfoService

import javax.inject.{Inject, Singleton}

import scala.concurrent.{ExecutionContext, Future}

@Singleton
class NodeUidService @Inject() (lifecycleInfoService: ILifecycleInfoService)(implicit
    ec: ExecutionContext
) extends INodeUidService {

  override def ensureUidExists(): Future[None.type] =
    lifecycleInfoService.get.flatMap {
      case lifecycleValue if lifecycleValue.instanceUid.isEmpty =>
        lifecycleInfoService.updateInstanceUid(UUID.randomUUID.toString)
      case _                                                    => Future.successful(None)
    }

}
