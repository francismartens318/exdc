package com.exalate.replication.services.node.storeblob.s3

import akka.http.scaladsl.model.ContentTypes
import akka.stream.alpakka.s3.scaladsl.S3
import akka.stream.alpakka.s3.{MetaHeaders, S3Attributes, S3Settings}
import akka.stream.scaladsl.{Sink, Source}
import akka.stream.{Attributes, Materializer, OverflowStrategy}
import akka.util.ByteString
import com.exalate.domain.node.storeblob.{CloudObjectMetaDataValue, CloudStoredBlobMetaData}
import com.exalate.replication.services.api.node.storeblob.ChecksumInfo
import com.exalate.replication.services.utils.ConfigPropertyService
import org.slf4j.{Logger, LoggerFactory}
import software.amazon.awssdk.regions.Region
import software.amazon.awssdk.regions.providers.AwsRegionProvider

import scala.concurrent.{ExecutionContext, Future}
import scala.util.Try

trait S3StoreBlobService {

  protected def configuration: ConfigPropertyService
  implicit protected def materializer: Materializer
  implicit protected def ec: ExecutionContext

  private lazy val LOG: Logger = LoggerFactory.getLogger(classOf[S3StoreBlobService])

  private lazy val BASE_URL = configuration.config.get[String]("com.exalate.node.s3.baseurl")

  private lazy val REGION = configuration.config.get[String]("com.exalate.node.s3.region")

  private lazy val BUCKET = configuration.config.get[String]("com.exalate.node.s3.bucket")

  private lazy val DIR = configuration.config.get[String]("com.exalate.node.s3.objectprefix")

  private lazy val BUFFER_COUNT = configuration.config.get[Int]("com.exalate.node.s3.buffercount")

  private lazy val CHUNK_COUNT =
    configuration.config.getOptional[Int]("com.exalate.node.s3.chunkcount")

  private[storeblob] def storeS3Blob(
      name: String,
      source: Source[ByteString, _]
  ): Future[CloudStoredBlobMetaData] = {

    LOG.debug(s"Starting S3 Blob Store with name: $name, Region: $REGION, URL: $BASE_URL")
    LOG.debug(s"Stream config, BUFFER_COUNT: $BUFFER_COUNT CHUNK_COUNT: $CHUNK_COUNT")

    val newDir = DIR.stripSuffix("/")
    val objectKey = if (newDir.isEmpty) name else s"$newDir/$name"

    val sink = S3
      .multipartUpload(
        BUCKET,
        objectKey,
        ContentTypes.`application/octet-stream`,
        MetaHeaders(Map.empty),
        chunkingParallelism = CHUNK_COUNT.getOrElse(2)
      )
      .withAttributes(locationSettings(REGION, BASE_URL))

    source
      .buffer(BUFFER_COUNT, OverflowStrategy.backpressure)
      .runWith(sink)
      .flatMap { response =>
        S3.getObjectMetadata(response.bucket, response.key, response.versionId)
          .runReduce((objectMetadataOpt, _) => objectMetadataOpt)
          .map {
            case Some(objectMetadata) =>
              val md5 = objectMetadata.eTag.getOrElse(response.eTag)
              val contentLength = objectMetadata.contentLength
              LOG.debug(
                s"#storeBlob successfully stored the object `$objectKey` into bucket `$BUCKET` via client($BASE_URL, $REGION): $md5 , $contentLength"
              )
              CloudStoredBlobMetaData(
                objectKey,
                CloudObjectMetaDataValue(objectKey, BUCKET, REGION, BASE_URL, md5, contentLength)
              )
          }
      }
  }

  private[storeblob] def retrieveS3Blob(
      storedBlobMetaData: CloudStoredBlobMetaData
  ): Future[Option[Source[ByteString, _]]] = {
    LOG.info(
      s"#retrieveBlob getting the object `${storedBlobMetaData.objectKey}` from bucket `${storedBlobMetaData.objectJsonValue.bucket}` via client(${storedBlobMetaData.objectJsonValue})"
    )

    val storedBlob = Try(
      S3
        .getObject(BUCKET, storedBlobMetaData.objectKey)
        .buffer(BUFFER_COUNT, OverflowStrategy.backpressure)
        .withAttributes(locationSettings(storedBlobMetaData))
    )
    Future.fromTry(storedBlob).map(Option(_))
  }

  private[storeblob] def deleteS3Blob(storedBlobMetaData: CloudStoredBlobMetaData): Future[Unit] = {
    LOG.info(
      s"#deleteBlob deleting the object `${storedBlobMetaData.objectKey}` from bucket `${storedBlobMetaData.objectJsonValue.bucket}` via client(${storedBlobMetaData.objectJsonValue})"
    )
    S3.deleteObject(BUCKET, storedBlobMetaData.objectKey)
      .withAttributes(locationSettings(storedBlobMetaData))
      .runWith(Sink.ignore)
      .map { _ =>
        LOG.debug(
          s"#deleteBlob deleted the object `${storedBlobMetaData.objectKey}` from bucket `${storedBlobMetaData.objectJsonValue.bucket}` via client(${storedBlobMetaData.objectJsonValue})"
        )
        ()
      }
      .recoverWith {
        case e =>
          LOG.error(
            s"#deleteBlob could not delete the object `${storedBlobMetaData.objectKey}` from bucket `${storedBlobMetaData.objectJsonValue.bucket}` via client(${storedBlobMetaData.objectJsonValue})"
          )
          Future.failed(e)
      }
  }

  private def locationSettings(storedBlobMetaData: CloudStoredBlobMetaData): Attributes =
    locationSettings(
      storedBlobMetaData.objectJsonValue.region,
      storedBlobMetaData.objectJsonValue.storageBaseUrl
    )

  private def locationSettings(region: String, baseUrl: String): Attributes = S3Attributes
    .settings(
      S3Settings(materializer.system)
        .withS3RegionProvider(
          new AwsRegionProvider {
            lazy val getRegion: Region = Region.of(region)
          }
        )
        .withEndpointUrl(baseUrl)
    )

  protected def getS3Checksum(storedBlobMetaData: CloudStoredBlobMetaData): Future[ChecksumInfo] =
    Future.successful(
      ChecksumInfo(
        storedBlobMetaData.objectJsonValue.md5,
        storedBlobMetaData.objectJsonValue.contentLength
      )
    )

}
