package com.exalate.replication.services.node.storeblob

import akka.stream.Materializer
import akka.stream.scaladsl.Source
import akka.util.ByteString
import com.exalate.api.domain.node.storeblob.BlobStorageType
import com.exalate.domain.node.storeblob.{
  CloudStoredBlobMetaData,
  FileSystemStoredBlobMetaData,
  StoredBlobMetaData
}
import com.exalate.error.services.api.IFileSystemExceptionCategoryService
import com.exalate.replication.services.api.node.storeblob.{ChecksumInfo, IStoreBlobService}
import com.exalate.replication.services.node.storeblob.filesystem.FileSystemStoreBlobService
import com.exalate.replication.services.node.storeblob.googlecloudstorage.GoogleCloudStoreBlobService
import com.exalate.replication.services.node.storeblob.s3.S3StoreBlobService
import com.exalate.replication.services.utils.ConfigPropertyService
import org.slf4j.{Logger, LoggerFactory}

import javax.inject.Inject
import scala.concurrent.{ExecutionContext, Future}

class StoreBlobService @Inject() (
    val configuration: ConfigPropertyService,
    val fileSystemExceptionCategoryService: IFileSystemExceptionCategoryService
)(
    implicit val materializer: Materializer,
    implicit val ec: ExecutionContext
) extends IStoreBlobService
      with FileSystemStoreBlobService
      with S3StoreBlobService
      with GoogleCloudStoreBlobService {

  private lazy val LOG: Logger = LoggerFactory.getLogger(classOf[StoreBlobService])

  override def storeBlob(name: String, source: Source[ByteString, _]): Future[StoredBlobMetaData] =
    configuration.config.getOptional[String]("com.exalate.node.storeblob.type") match {
      case Some(value) if value equalsIgnoreCase BlobStorageType.GOOGLE_STORE.name() =>
        storeGoogleBlob(name, source)
      case Some(value) if value equalsIgnoreCase BlobStorageType.S3.name()           =>
        storeS3Blob(name, source)
      case Some(value) if value equalsIgnoreCase BlobStorageType.FILE_SYSTEM.name()  =>
        storeFileSystemBlob(name, source)
      case _                                                                         =>
        LOG.error(
          "#get didn't find com.exalate.node.storeblob.type property in the app config (backed bby env var BLOB_STORAGE_TYPE), defaulting to FILE_SYSTEM"
        )
        storeFileSystemBlob(name, source)
    }

  override def retrieveBlob(
      storedBlobMetaData: StoredBlobMetaData
  ): Future[Option[Source[ByteString, _]]] = storedBlobMetaData match {
    case cloud: CloudStoredBlobMetaData
        if cloud.objectJsonValue.storageType.exists(
          _.equals(BlobStorageType.GOOGLE_STORE.name())
        ) =>
      retrieveGoogleBlob(cloud)
    case cloud: CloudStoredBlobMetaData           => retrieveS3Blob(cloud)
    case fileSystem: FileSystemStoredBlobMetaData => retrieveFileSystemBlob(fileSystem)
  }

  override def deleteBlob(storedBlobMetaData: StoredBlobMetaData): Future[Unit] =
    storedBlobMetaData match {
      case cloud: CloudStoredBlobMetaData
          if cloud.objectJsonValue.storageType.exists(
            _.equals(BlobStorageType.GOOGLE_STORE.name())
          ) =>
        deleteGoogleBlob(cloud)
      case cloud: CloudStoredBlobMetaData           => deleteS3Blob(cloud)
      case filesystem: FileSystemStoredBlobMetaData => deleteFileSystemBlob(filesystem)
    }

  override def getChecksum(storedBlobMetaData: StoredBlobMetaData): Future[ChecksumInfo] =
    storedBlobMetaData match {
      case cloud: CloudStoredBlobMetaData
          if cloud.objectJsonValue.storageType.exists(
            _.equals(BlobStorageType.GOOGLE_STORE.name())
          ) =>
        getGoogleChecksum(cloud)
      case cloud: CloudStoredBlobMetaData           => getS3Checksum(cloud)
      case filesystem: FileSystemStoredBlobMetaData => getFileSystemChecksum(filesystem)
    }

}
