package com.exalate.replication.services.node

import akka.NotUsed
import akka.stream.Materializer
import akka.stream.scaladsl.{Concat, Source}
import akka.util.ByteString
import org.apache.commons.codec.binary.Base64
import play.api.libs.json.JsValue
import play.api.mvc.MultipartFormData.{DataPart, FilePart, Part}

import scala.concurrent.{ExecutionContext, Future}

package object storeblob {

  def convertToFilePart(
      storedBlobByteString: Source[ByteString, _],
      contentType: String,
      fileName: String,
      key: String = "file",
      fileSize: Long = -1
  ): Source[FilePart[Source[ByteString, _]], _] =
    Source.single(FilePart(key, fileName, Option(contentType), storedBlobByteString, fileSize))

  def convertToFilePart(
      json: JsValue,
      fileName: String,
      key: String
  ): Source[FilePart[Source[ByteString, _]], _] = convertToFilePart(
    Source.single(ByteString.apply(json.toString())),
    "application/json",
    fileName,
    key,
    ByteString.apply(json.toString()).length
  )

  def convertToDataPart(dataParts: (String, String)*): Source[DataPart, NotUsed] =
    Source(dataParts.map(keyValue => DataPart(keyValue._1, keyValue._2)))

  def concatParts(
      parts: Source[Part[Source[ByteString, _]], _]*
  ): Source[Part[Source[ByteString, _]], Seq[_]] =
    Source.combine(parts)(Concat(_))

  def convertToBase64Encoded(
      storedBlobByteString: Source[ByteString, _]
  )(implicit ec: ExecutionContext, materializer: Materializer): Future[String] =
    convertToByteArray(storedBlobByteString).map(Base64.encodeBase64String)

  def convertToByteArray(
      storedBlobByteString: Source[ByteString, _]
  )(implicit ec: ExecutionContext, materializer: Materializer): Future[Array[Byte]] =
    storedBlobByteString
      .runReduce(_ ++ _)
      .map(bs => bs.toArray)

}
