package com.exalate.replication.services.node.lifecycle

object NodeSettings {
  val EVENT_WORKER_ACTOR_NAME: String = "event-worker-actor"
  val REQUEST_WORKER_ACTOR_NAME: String = "request-worker-actor"
  val POLL_WORKER_ACTOR_NAME: String = "poll-worker-actor"
  val PAIR_EVENT_POLLER_WORKER_ACTOR: String = "pair-event-poller-worker-actor"
  val EVENT_SCHEDULER_WORKER_ACTOR_NAME: String = "event-scheduler-worker-actor"

  val CONNECTION_DRAFT_ACTOR: String = "connection-draft-actor"
  val ERROR_WORKER_ACTOR_NAME: String = "error-worker-actor"
  val STATUS_WORKER_ACTOR_NAME: String = "status-worker-actor"
  val SUPPORT_ZIP_WORKER_ACTOR_NAME: String = "support-zip-worker-actor"

  val MESSAGE_SERVICE_ACTOR: String = "message-service-actor"
  val INCOMING_MESSAGE_ACTOR: String = "incoming-message-actor"
  val MESSAGE_BATCHER_ACTOR: String = "message-batcher-actor"
  val MESSAGE_SENDER_ACTOR: String = "message-sender-actor"
  val MESSAGE_UNBATCHER_ACTOR: String = "message-unbatcher-actor"
  val RATE_LIMITED_TASK_PROCESSOR_ACTOR_NAME: String = "rate-limited-task-processor-actor"

  val REMOTE_PROOF_TOKEN_STATUSES_WORKER_ACTOR_NAME: String =
    "remote-proof-token-statuses-worker-actor"

}
