package com.exalate.replication.services.node.lifecycle

import com.exalate.api.exception.VerifyCodeErrors
import com.exalate.replication.services.api.node.INodeUrlHelper

class NodeUrlHelper extends INodeUrlHelper {

  /** Url to redirect to after registration, once user pressed 'Verify node' button from email.
    * exalate url is used in other nodes (Azure)
    */
  override def getRedirectUrl(exalateUrl: String, path: String, code: VerifyCodeErrors): String =
    s"/$path?code=${code.getName}"

}
