package com.exalate.replication.services.node.lifecycle

import com.exalate.replication.services.api.node.lifecycle.IApplicationModeService
import play.api.{Configuration, Environment, Mode}

import javax.inject.Inject

class ApplicationModeService @Inject() (environment: Environment, configuration: Configuration)
    extends IApplicationModeService {

  def isInDevMode: Boolean = {
    val playDevMode = environment.mode == Mode.Dev
    lazy val exalateMode = configuration.getOptional[String]("exalate.mode")
    lazy val exalateDevMode = exalateMode.contains("DEV")
    playDevMode || exalateDevMode
  }

}
