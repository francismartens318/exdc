package com.exalate.replication.services.node.storeblob.googlecloudstorage

import akka.http.scaladsl.model.ContentTypes
import akka.stream.Materializer
import akka.stream.alpakka.googlecloud.storage.StorageObject
import akka.stream.alpakka.googlecloud.storage.scaladsl.GCStorage
import akka.stream.scaladsl.{Sink, Source}
import akka.util.ByteString
import com.exalate.api.domain.node.storeblob.BlobStorageType
import com.exalate.domain.node.storeblob.{CloudObjectMetaDataValue, CloudStoredBlobMetaData}
import com.exalate.replication.services.api.node.storeblob.ChecksumInfo
import com.exalate.replication.services.utils.ConfigPropertyService
import org.slf4j.{Logger, LoggerFactory}

import scala.concurrent.{ExecutionContext, Future}
import scala.util.Try

trait GoogleCloudStoreBlobService {

  protected def configuration: ConfigPropertyService

  implicit protected def materializer: Materializer

  implicit protected def ec: ExecutionContext

  private lazy val LOG: Logger = LoggerFactory.getLogger(classOf[GoogleCloudStoreBlobService])

  private lazy val BUCKET_NAME = configuration.config.get[String]("com.exalate.node.google.bucket")

  private lazy val CHUNK_SIZE =
    configuration.config.get[Int]("com.exalate.node.google.chunk.size.bytes")

  private lazy val REGION = configuration.config.get[String]("com.exalate.node.s3.region")

  private[storeblob] def storeGoogleBlob(
      name: String,
      source: Source[ByteString, _]
  ): Future[CloudStoredBlobMetaData] = {
    LOG.debug(s"#storeGoogleBlob the file $name going to be stored in the bucket $BUCKET_NAME")
    val sink =
      GCStorage.resumableUpload(
        BUCKET_NAME,
        name,
        ContentTypes.`application/octet-stream`,
        CHUNK_SIZE
      )
    source.runWith(sink).map(toCloudStoredBlobMetaData)
  }

  private[storeblob] def retrieveGoogleBlob(
      storedBlobMetaData: CloudStoredBlobMetaData
  ): Future[Option[Source[ByteString, _]]] = {
    LOG.info(
      s"#retrieveGoogleBlob getting the object `${storedBlobMetaData.objectKey}` from bucket `${storedBlobMetaData.objectJsonValue.bucket}` via client(${storedBlobMetaData.objectJsonValue})"
    )
    val storedBlob = Try(
      GCStorage.download(BUCKET_NAME, storedBlobMetaData.objectKey).flatMapConcat {
        case Some(value) => value
        case None        =>
          LOG.error(
            s"#retrieveGoogleBlob: Could not retrieve the object `${storedBlobMetaData.objectKey}` from bucket `$BUCKET_NAME`)"
          )
          Source.failed(
            new Exception(
              s"Could not retrieve the object `${storedBlobMetaData.objectKey}` from bucket `$BUCKET_NAME`)"
            )
          )
      }
    )
    Future.fromTry(storedBlob).map(Option(_))
  }

  private[storeblob] def deleteGoogleBlob(
      storedBlobMetaData: CloudStoredBlobMetaData
  ): Future[Unit] = {
    LOG.info(
      s"#deleteGoogleBlob deleting the object `${storedBlobMetaData.objectKey}` from bucket `${storedBlobMetaData.objectJsonValue.bucket}` via client(${storedBlobMetaData.objectJsonValue})"
    )
    GCStorage
      .deleteObject(BUCKET_NAME, storedBlobMetaData.objectKey)
      .runWith(Sink.head)
      .map { result =>
        if (result) {
          LOG.info(s"The object `${storedBlobMetaData.objectKey}` was deleted successfully")
        } else {
          LOG.warn(
            s"The object `${storedBlobMetaData.objectKey}` was not deleted. Seems, the object does not exist"
          )
        }
        ()
      }
  }

  private[storeblob] def getGoogleChecksum(
      storedBlobMetaData: CloudStoredBlobMetaData
  ): Future[ChecksumInfo] =
    Future.successful(
      ChecksumInfo(
        storedBlobMetaData.objectJsonValue.md5,
        storedBlobMetaData.objectJsonValue.contentLength
      )
    )

  private def toCloudStoredBlobMetaData(storageObject: StorageObject) =
    CloudStoredBlobMetaData(
      storageObject.name,
      CloudObjectMetaDataValue(
        storageObject.name,
        storageObject.bucket,
        REGION,
        storageBaseUrl = storageObject.selfLink,
        storageObject.md5Hash,
        storageObject.size,
        Some(BlobStorageType.GOOGLE_STORE.name())
      )
    )

}
