package com.exalate.replication.services.node

import com.exalate.basic.domain.util.SemanticVersionService
import java.util.Date
import com.exalate.generic.services.api.INodeBuildInfoService
import com.exalate.services.utils.{IBuildInfoService, TargetType}
import javax.inject.Inject

class DefaultBuildInfoService @Inject() (
    nodeBuildInfoService: INodeBuildInfoService
) extends IBuildInfoService {

  override def getNodeVersion: String =
    SemanticVersionService.get(nodeBuildInfoService.getBuildInfo.version).toString

  override def getRawNodeVersion: String = nodeBuildInfoService.getBuildInfo.version
  override def getBuildDate: Date = new Date(nodeBuildInfoService.getBuildInfo.buildTime)
  override def getNodeName: String = nodeBuildInfoService.getBuildInfo.name

  override def getExaCompVersion: String =
    SemanticVersionService.get(nodeBuildInfoService.getBuildInfo.exaCompVersion).toString

  override def getRawExaCompVersion: String = nodeBuildInfoService.getBuildInfo.exaCompVersion
  override def getTargetType: TargetType = TargetType.PROD
}
