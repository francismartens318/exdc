package com.exalate.replication.services.script

import java.util

import com.exalate.api.domain.hubobject.IHubIssueReplica
import com.exalate.api.hubobject.jira.ICommentHelper
import com.exalate.basic.domain.hubobject.v1.{BasicHubComment, BasicHubIssue}
import com.exalate.domain.script.{CommentParams, HubCommentCommentParams, Params}
import com.exalate.domain.transport.trackeroptions.EditorFields
import com.exalate.domain.transport.trackeroptions.EditorFields.COMMENTS
import com.exalate.hubobject.jira.CommentHelper
import com.exalate.replication.services.api.issuetracker.script.IExalateAPI

class MultiCommentExalateAPI() extends IExalateAPI[java.util.List[BasicHubComment], CommentParams] {

  /** makes a request to Issue Tracker to get an object by `value`, does not take the value from
    * context entity. Context Entity is used to get project / issue type / other context
    *
    * @example
    *   val issueType: BasicHubOption = ExalateAPI.getValueFromIssueTracker( fieldName =
    *   "ISSUE_TYPE", value = StringOptionParams("Task"), contextEntity = issue ) // makes a request
    *   to the issue tracker checking if there actually is an issue type "Task" for the given
    *   project (taken from `contextEntity`)
    * @example
    *   val status: BasicHubStatus = ExalateAPI.getValueFromIssueTracker(fieldName = "STATUS", value
    *   \= StringOptionParams("To Do"), contextEntity = issue)
    */
  override def getValueFromIssueTracker(
      fieldName: String,
      value: CommentParams,
      contextEntity: IHubIssueReplica
  ): util.List[BasicHubComment] = value match {
    case HubCommentCommentParams(cs) => cs
  }

  /** gets value for the field from the `entity`
    */
  override def getValueFromField(
      entity: IHubIssueReplica,
      fieldName: String
  ): util.List[BasicHubComment] =
    entity.getEntityName match {
      case "issue" =>
        val issue = entity.asInstanceOf[BasicHubIssue]
        issue.getComments
    }

  override def setValueToField(
      entity: IHubIssueReplica,
      fieldName: String,
      value: CommentParams
  ): IHubIssueReplica =
    entity.getEntityName match {
      case "issue" =>
        val issue = entity.asInstanceOf[BasicHubIssue]
        EditorFields.withNameOpt(fieldName) match {
          case Some(COMMENTS) =>
            value match {
              case HubCommentCommentParams(v) =>
                issue.setComments(v)
                issue
            }
        }
    }

}
