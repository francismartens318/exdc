package com.exalate.replication.services.script

import java.util

import com.exalate.api.domain.hubobject.IHubIssueReplica
import com.exalate.api.domain.hubobject.v1_2.IHubLabel
import com.exalate.basic.domain.hubobject.v1.{BasicHubIssue, BasicHubLabel}
import com.exalate.domain.script._
import com.exalate.domain.transport.trackeroptions.EditorFields
import com.exalate.domain.transport.trackeroptions.EditorFields.LABELS
import com.exalate.replication.services.api.issuetracker.script.IExalateAPI
import scala.jdk.CollectionConverters._

class MultiTextExalateAPI extends IExalateAPI[java.util.Collection[String], MultiTextParams] {

  /** makes a request to Issue Tracker to get an object by `value`, does not take the value from
    * context entity. Context Entity is used to get project / issue type / other context
    *
    * @example
    *   val issueType: BasicHubOption = ExalateAPI.getValueFromIssueTracker( fieldName =
    *   "ISSUE_TYPE", value = StringOptionParams("Task"), contextEntity = issue ) // makes a request
    *   to the issue tracker checking if there actually is an issue type "Task" for the given
    *   project (taken from `contextEntity`)
    * @example
    *   val status: BasicHubStatus = ExalateAPI.getValueFromIssueTracker(fieldName = "STATUS", value
    *   \= StringOptionParams("To Do"), contextEntity = issue)
    */
  override def getValueFromIssueTracker(
      fieldName: String,
      value: MultiTextParams,
      contextEntity: IHubIssueReplica
  ): util.Collection[String] = value match {
    case StringsMultiTextParams(strs) => strs
  }

  /** gets value for the field from the `entity`
    */
  override def getValueFromField(
      entity: IHubIssueReplica,
      fieldName: String
  ): util.Collection[String] =
    entity.getEntityName match {
      case "issue" =>
        val issue = entity.asInstanceOf[BasicHubIssue]
        EditorFields.withNameOpt(fieldName) match {
          case Some(LABELS) =>
            issue.getLabels.asScala
              .map(_.getLabel)
              .asJava
        }
    }

  override def setValueToField(
      entity: IHubIssueReplica,
      fieldName: String,
      value: MultiTextParams
  ): IHubIssueReplica =
    entity.getEntityName match {
      case "issue" =>
        val issue = entity.asInstanceOf[BasicHubIssue]
        value match {
          case StringsMultiTextParams(v) =>
            EditorFields.withNameOpt(fieldName) match {
              case Some(LABELS) =>
                val labels = v.asScala.map { t =>
                  val label = new BasicHubLabel()
                  label.setLabel(t)
                  label.asInstanceOf[IHubLabel]
                }
                val labelSet = labels.toSet
                val labelJSet = labelSet.asJava
                issue.setLabels(labelJSet)
                issue
            }
        }
    }

}
