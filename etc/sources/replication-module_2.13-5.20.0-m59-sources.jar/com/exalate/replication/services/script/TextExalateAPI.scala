package com.exalate.replication.services.script

import java.text.SimpleDateFormat

import com.exalate.api.domain.hubobject.IHubIssueReplica
import com.exalate.api.domain.hubobject.v1_2.HubCustomFieldType
import com.exalate.api.domain.hubobject.v1_6.IHubCustomField
import com.exalate.basic.domain.hubobject.v1.{BasicHubCustomField, BasicHubIssue}
import com.exalate.domain.script._
import com.exalate.domain.transport.trackeroptions.EditorFields
import com.exalate.domain.transport.trackeroptions.EditorFields.{
  AREA_PATH,
  DESCRIPTION,
  ITERATION_PATH,
  SUMMARY
}
import com.exalate.replication.services.api.issuetracker.script.IExalateAPI
import com.exalate.replication.services.api.replication.scope.ITrackerScopeAndMappingHelper
import com.exalate.util.ReflectionUtils

import scala.jdk.CollectionConverters._

class TextExalateAPI(trackerScopeAndMappingHelper: ITrackerScopeAndMappingHelper)
    extends IExalateAPI[String, TextParams] {

  /** makes a request to Issue Tracker to get an object by `value`, does not take the value from
    * context entity. Context Entity is used to get project / issue type / other context
    *
    * @example
    *   val issueType: BasicHubOption = ExalateAPI.getValueFromIssueTracker( fieldName =
    *   "ISSUE_TYPE", value = StringOptionParams("Task"), contextEntity = issue ) // makes a request
    *   to the issue tracker checking if there actually is an issue type "Task" for the given
    *   project (taken from `contextEntity`)
    * @example
    *   val status: BasicHubStatus = ExalateAPI.getValueFromIssueTracker(fieldName = "STATUS", value
    *   \= StringOptionParams("To Do"), contextEntity = issue)
    */
  override def getValueFromIssueTracker(
      fieldName: String,
      value: TextParams,
      contextEntity: IHubIssueReplica
  ): String = value match {
    case StringTextParams(v)       => v
    case DateTextParams(vDate)     =>
      // TODO maybe parameterize the DateTextParams?
      ScriptGeneratorService.DATE_FORMAT
        .format(vDate)
    case HubOptionTextParams(vOpt) => vOpt.getValue
    case HubUserTextParams(vUser)  =>
      Option(vUser.getEmail)
        .orElse(Option(vUser.getKey))
        .getOrElse(vUser.getDisplayName)
    case SetStringTextParams(vs)   => vs.asScala.mkString(", ")
  }

  /** gets value for the field from the `entity`
    */
  override def getValueFromField(entity: IHubIssueReplica, fieldName: String): String =
    entity.getEntityName match {
      case "issue" =>
        val issue = entity.asInstanceOf[BasicHubIssue]
        EditorFields.withNameOpt(fieldName) match {
          case Some(DESCRIPTION)    =>
            issue.getDescription
          case Some(SUMMARY)        =>
            issue.getSummary
          case Some(AREA_PATH)      =>
            ReflectionUtils
              .invokeMethod(
                issue.getClass,
                issue,
                "get",
                Seq[Tuple2[Class[_], Object]](Tuple2(classOf[Object], "areaPath")).asJava
              )
              .right
              .getOrElse("")
          case Some(ITERATION_PATH) =>
            ReflectionUtils
              .invokeMethod(
                issue.getClass,
                issue,
                "get",
                Seq[Tuple2[Class[_], Object]](Tuple2(classOf[Object], "iterationPath")).asJava
              )
              .right
              .getOrElse("")

          case _ =>
            getCustomFieldByKey(issue, fieldName).flatMap { cf =>
              cf.getType match {
                case HubCustomFieldType.TEXT | HubCustomFieldType.STRING =>
                  Option(cf.getValue)
                    .map(_.toString)
              }
            }.orNull
        }
    }

  override def setValueToField(
      entity: IHubIssueReplica,
      fieldName: String,
      value: TextParams
  ): IHubIssueReplica =
    entity.getEntityName match {
      case "issue" =>
        val issue = entity.asInstanceOf[BasicHubIssue]
        EditorFields.withNameOpt(fieldName) match {
          case Some(DESCRIPTION)    =>
            value match {
              case StringTextParams(v)    =>
                issue.setDescription(v)
                issue
              case HubOptionTextParams(v) =>
                issue.setDescription(v.getValue)
                issue
              case HubUserTextParams(v)   =>
                val user = trackerScopeAndMappingHelper.getUserAsString(v)
                issue.setDescription(user)
                issue
            }
          case Some(SUMMARY)        =>
            value match {
              case StringTextParams(v)    =>
                issue.setSummary(v)
                issue
              case HubOptionTextParams(v) =>
                issue.setSummary(v.getValue)
                issue
              case HubUserTextParams(v)   =>
                val user = trackerScopeAndMappingHelper.getUserAsString(v)
                issue.setSummary(user)
                issue
            }
          case Some(AREA_PATH)      =>
            value match {
              case StringTextParams(v)    =>
                ReflectionUtils.invokeMethod(
                  issue.getClass,
                  issue,
                  "setAreaPath",
                  Seq[Tuple2[Class[_], Object]](Tuple2(classOf[String], v)).asJava
                )
                issue
              case HubOptionTextParams(v) =>
                ReflectionUtils.invokeMethod(
                  issue.getClass,
                  issue,
                  "setAreaPath",
                  Seq[Tuple2[Class[_], Object]](Tuple2(classOf[String], v.getValue)).asJava
                )
                issue
              case HubUserTextParams(v)   =>
                val user = trackerScopeAndMappingHelper.getUserAsString(v)
                ReflectionUtils.invokeMethod(
                  issue.getClass,
                  issue,
                  "setAreaPath",
                  Seq[Tuple2[Class[_], Object]](Tuple2(classOf[String], user)).asJava
                )
                issue
            }
          case Some(ITERATION_PATH) =>
            value match {
              case StringTextParams(v)    =>
                ReflectionUtils.invokeMethod(
                  issue.getClass,
                  issue,
                  "setIterationPath",
                  Seq[Tuple2[Class[_], Object]](Tuple2(classOf[String], v)).asJava
                )
                issue
              case HubOptionTextParams(v) =>
                ReflectionUtils.invokeMethod(
                  issue.getClass,
                  issue,
                  "setIterationPath",
                  Seq[Tuple2[Class[_], Object]](Tuple2(classOf[String], v.getValue)).asJava
                )
                issue
              case HubUserTextParams(v)   =>
                val user = trackerScopeAndMappingHelper.getUserAsString(v)
                ReflectionUtils.invokeMethod(
                  issue.getClass,
                  issue,
                  "setIterationPath",
                  Seq[Tuple2[Class[_], Object]](Tuple2(classOf[String], user)).asJava
                )
                issue
            }
          case _                    =>
            getCustomFieldByKey(issue, fieldName)
              .orElse(Option(issue.getCustomFields.get(fieldName))) match {
              case Some(icf) =>
                val cf = icf.asInstanceOf[BasicHubCustomField]
                value match {
                  case StringTextParams(v)    =>
                    cf.setValue(v)
                    issue
                  case HubOptionTextParams(v) =>
                    cf.setValue(v.getValue)
                    issue
                  case HubUserTextParams(v)   =>
                    val user = trackerScopeAndMappingHelper.getUserAsString(v)
                    cf.setValue(user)
                    issue
                  case DateTextParams(v)      =>
                    val df = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.s")
                    val s = df.format(v)
                    cf.setValue(s)
                    issue

                }
              case None      => issue
            }
        }
    }

  private def getCustomFieldByKey(issue: BasicHubIssue, key: String): Option[IHubCustomField] = {
    val customFieldOpt = issue.getCustomFields.asScala.values
      .find(cf => cf != null && cf.asInstanceOf[IHubCustomField].getUid == key)

    customFieldOpt.map(_.asInstanceOf[IHubCustomField])
  }

}
