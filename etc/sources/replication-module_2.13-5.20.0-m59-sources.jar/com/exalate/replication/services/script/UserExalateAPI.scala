package com.exalate.replication.services.script

import com.exalate.api.domain.hubobject.IHubIssueReplica
import com.exalate.api.domain.hubobject.v1_6.IHubCustomField
import com.exalate.basic.domain.hubobject.v1.{BasicHubCustomField, BasicHubIssue, BasicHubUser}
import com.exalate.domain.script.{HubUserUserParams, StringUserParams, UserParams}
import com.exalate.domain.transport.trackeroptions.EditorFields
import com.exalate.domain.transport.trackeroptions.EditorFields._
import com.exalate.replication.services.api.issuetracker.script.IExalateAPI
import com.exalate.replication.services.api.replication.scope.ITrackerScopeAndMappingHelper
import com.exalate.services.utils.FutureUtils

import scala.jdk.CollectionConverters._
import scala.concurrent.ExecutionContext

class UserExalateAPI(trackerScopeAndMappingHelper: ITrackerScopeAndMappingHelper)(implicit
    val executionContext: ExecutionContext
) extends IExalateAPI[BasicHubUser, UserParams] {

  /** makes a request to Issue Tracker to get an object by `value`, does not take the value from
    * context entity. Context Entity is used to get project / issue type / other context
    *
    * @example
    *   val issueType: BasicHubOption = ExalateAPI.getValueFromIssueTracker( fieldName =
    *   "ISSUE_TYPE", value = StringOptionParams("Task"), contextEntity = issue ) // makes a request
    *   to the issue tracker checking if there actually is an issue type "Task" for the given
    *   project (taken from `contextEntity`)
    * @example
    *   val status: BasicHubStatus = ExalateAPI.getValueFromIssueTracker(fieldName = "STATUS", value
    *   \= StringOptionParams("To Do"), contextEntity = issue)
    */
  override def getValueFromIssueTracker(
      fieldName: String,
      value: UserParams,
      contextEntity: IHubIssueReplica
  ): BasicHubUser =
    contextEntity.getEntityName match {
      case "issue" =>
        val issue = contextEntity.asInstanceOf[BasicHubIssue]
        value match {
          case HubUserUserParams(v) =>
            FutureUtils
              .resultInf(
                trackerScopeAndMappingHelper
                  .getUser(v, Option(issue.getProjectKey), Option(issue.getTypeName))
                  .map(_.map(_.asInstanceOf[BasicHubUser]))
              )
              .orNull
          case StringUserParams(v)  =>
            FutureUtils
              .resultInf(
                trackerScopeAndMappingHelper
                  .getUser(v, Option(issue.getProjectKey), Option(issue.getTypeName))
                  .map(_.map(_.asInstanceOf[BasicHubUser]))
              )
              .orNull

        }
    }

  /** gets value for the field from the `entity`
    */
  override def getValueFromField(entity: IHubIssueReplica, fieldName: String): BasicHubUser =
    entity.getEntityName match {
      case "issue" =>
        val issue = entity.asInstanceOf[BasicHubIssue]
        EditorFields.withNameOpt(fieldName) match {
          case Some(ASSIGNEE) =>
            issue.getAssignee.asInstanceOf[BasicHubUser]
          case Some(REPORTER) =>
            issue.getReporter.asInstanceOf[BasicHubUser]
          case _              =>
            Option(issue.getCustomFields.get(fieldName))
              .map(_.getValue.asInstanceOf[BasicHubUser])
              .orNull
        }
    }

  override def setValueToField(
      entity: IHubIssueReplica,
      fieldName: String,
      value: UserParams
  ): IHubIssueReplica =
    entity.getEntityName match {
      case "issue" =>
        val issue = entity.asInstanceOf[BasicHubIssue]
        value match {
          case HubUserUserParams(v) =>
            EditorFields.withNameOpt(fieldName) match {
              case Some(ASSIGNEE) =>
                issue.setAssignee(v)
                issue
              case Some(REPORTER) =>
                issue.setReporter(v)
                issue
              case _              =>
                getCustomFieldByKey(issue, fieldName)
                  .orElse(Option(issue.getCustomFields.get(fieldName))) match {
                  case Some(icf) =>
                    val cf = icf.asInstanceOf[BasicHubCustomField]
                    cf.setValue(v)
                    issue
                  case _         =>
                    issue
                }
            }
          case StringUserParams(v)  =>
            val user = FutureUtils.resultInf(
              trackerScopeAndMappingHelper.getUser(
                v,
                Option(issue.getProjectKey),
                Option(issue.getType.getName)
              )
            )
            EditorFields.withNameOpt(fieldName) match {
              case Some(ASSIGNEE) =>
                user.map(u => issue.setAssignee(u))
                issue
              case Some(REPORTER) =>
                user.map(u => issue.setReporter(u))
                issue
              case _              =>
                getCustomFieldByKey(issue, fieldName)
                  .orElse(Option(issue.getCustomFields.get(fieldName))) match {
                  case Some(icf) =>
                    val cf = icf.asInstanceOf[BasicHubCustomField]
                    user.map(u => cf.setValue(u))
                    issue
                  case _         =>
                    issue
                }
            }
        }
    }

  private def getCustomFieldByKey(issue: BasicHubIssue, key: String): Option[IHubCustomField] = {
    val customFieldOpt = issue.getCustomFields.asScala.values
      .find(cf => cf != null && cf.asInstanceOf[IHubCustomField].getUid == key)

    customFieldOpt.map(_.asInstanceOf[IHubCustomField])
  }

}
