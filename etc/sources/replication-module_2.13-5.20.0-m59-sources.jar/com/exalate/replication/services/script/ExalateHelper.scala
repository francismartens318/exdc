package com.exalate.replication.services.script

import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.editor.error.EditorErrorSide
import com.exalate.api.domain.hubobject.IHubIssueReplica
import com.exalate.basic.domain.BasicIssueKey
import com.exalate.basic.domain.hubobject.v1.BasicHubIssue
import com.exalate.domain.editor.mappings.Mappings
import com.exalate.domain.exception.editor.RecoveryMappingEditorException
import com.exalate.replication.services.api.issuetracker.script.IExalateHelper
import com.exalate.replication.services.api.replication.IEventSchedulerNotificationService
import com.google.inject.Inject

class ExalateHelper @Inject() (eventSchedulerService: IEventSchedulerNotificationService)
    extends IExalateHelper {

  /** Schedules Exalate Or Update Event
    * @param connection
    * @param issue
    */
  override def scheduleExalateOrUpdateEvent(
      connection: IConnection,
      issue: IHubIssueReplica
  ): Unit = issue match {
    case basicHubIssue: BasicHubIssue =>
      val issueKey =
        new BasicIssueKey(issue.getId, basicHubIssue.getKey, basicHubIssue.getEntityName)
      eventSchedulerService.scheduleExalateOrUpdateEvent(
        connection,
        issueKey,
        None,
        Some(basicHubIssue)
      )
    case i                            =>
      "" == i // line left intentionally for debug purpose
    // do nothing for now
  }

  override def getRecoveryMappingEditorException(
      mappings: Mappings,
      swapSides: Boolean,
      recoveryValueAsString: String
  ): RecoveryMappingEditorException =
    if (swapSides) {
      RecoveryMappingEditorException(mappings, EditorErrorSide.REMOTE, recoveryValueAsString)
    } else {
      RecoveryMappingEditorException(mappings, EditorErrorSide.LOCAL, recoveryValueAsString)
    }

}
