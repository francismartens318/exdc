package com.exalate.replication.services.script

import java.text.SimpleDateFormat
import com.exalate.api.ILoggingService
import com.exalate.api.domain.editor.error.EditorErrorSide
import com.exalate.api.exception.bug.BugException
import com.exalate.domain.editor.FieldDataType
import com.exalate.domain.editor.FieldDataType._
import com.exalate.domain.editor.mappings.{
  CommentFilters,
  FilterKey,
  MappingFieldTypeValue,
  MappingValue,
  Recovery
}
import com.exalate.domain.editor.scopes.{QueryValue, SingleSideScope}
import com.exalate.domain.transport.trackeroptions.EditorFields._
import com.exalate.domain.transport.trackeroptions.ScopeQueryOperators.{apply => _, _}
import com.exalate.domain.transport.trackeroptions.{EditorFields, ScopeQueryOperators}
import com.exalate.domain.values.connection.ConnectionValue
import com.exalate.domain.values.{EditorFieldTypeValue, EditorFieldValue}
import com.exalate.replication.services.api.issuetracker.script.IScriptGeneratorService
import com.exalate.util.json.gson.GsonCaseClassValueJsonService
import com.google.inject.Inject
import groovy.json.StringEscapeUtils
import play.api.libs.json.Json

import scala.reflect.{classTag, ClassTag}
import scala.jdk.CollectionConverters._
import scala.util.{Failure, Success, Try}

object ScriptGeneratorService {
  val EXALATE_SCOPE_UID: String = "__EXALATE_SCOPE_UID"
  val EXALATE_SCOPE_SIDE: String = "__EXALATE_SCOPE_SIDE"
  val EXALATE_SCOPE_INSTANCE_NAME: String = "__EXALATE_SCOPE_INSTANCE_NAME"
  val DATE_FORMAT_STR: String = "yyyy-MM-dd hh:mm:ss.s"
  lazy val DATE_FORMAT: SimpleDateFormat = new SimpleDateFormat(DATE_FORMAT_STR)
}

/** Editor configures Incoming rules through mappings. Mappings are like separate Incoming processor
  * scripts (and, sometimes outgoing processor scripts too) sequenced to execute one after the
  * other. The content of the Mapping's Incoming Script depends on the mapping itself and is
  * determined by the ScriptGeneratorService
  */
class ScriptGeneratorService @Inject() (
    loggingService: ILoggingService
) extends IScriptGeneratorService {
  import ScriptGeneratorService._

  override def generateScriptRules(
      mappingValue: MappingValue,
      connectionValue: ConnectionValue,
      localFieldValues: Seq[EditorFieldValue],
      remoteFieldValues: Seq[EditorFieldValue]
  ): (Try[IncomingScript], Try[OutgoingScript]) = {
    val localEditorFieldOpt =
      localFieldValues.find(fv => mappingValue.local.map(_.field.key).contains(fv.key))
    val remoteEditorFieldOpt =
      remoteFieldValues.find(fv => mappingValue.remote.map(_.field.key).contains(fv.key))

    val incomingScripts = generateIncomingScriptRules(
      mappingValue,
      localEditorFieldOpt,
      remoteEditorFieldOpt,
      connectionValue
    )
    val outgoingScripts = generateOutgoingScriptRules(
      mappingValue,
      localEditorFieldOpt,
      remoteEditorFieldOpt,
      connectionValue
    )

    (incomingScripts, outgoingScripts)
  }

  case class FieldTypeSpecificScripts(
      remoteValueToLocalParamsScript: String,
      localValueToRemoteParamsScript: String,
      remoteValueMatchToMapScript: String,
      localValueMatchToMapScript: String,
      remoteMapToParamScript: String,
      localMapToParamScript: String
  )

  private def generateOutgoingScriptRules(
      mappingValue: MappingValue,
      localEditorFieldOpt: Option[EditorFieldValue],
      remoteEditorFieldOpt: Option[EditorFieldValue],
      connectionValue: ConnectionValue
  ): Try[String] = {

    val scriptStrTry: Try[String] = (localEditorFieldOpt, remoteEditorFieldOpt) match {
      case (Some(localEditorField), Some(remoteEditorField)) =>
        val localInstanceReplicaValueSetterTry = getScriptForReplicaValueSetter(
          "issue",
          localEditorField,
          mappingValue.local.flatMap(_.filters)
        )
        val remoteInstanceReplicaValueSetterTry = getScriptForReplicaValueSetter(
          "issue",
          remoteEditorField,
          mappingValue.remote.flatMap(_.filters)
        )

        val remoteInstanceName = StringEscapeUtils.escapeJava(connectionValue.remoteInstanceName.get)
        val localInstanceName = StringEscapeUtils.escapeJava(connectionValue.localInstanceName.get)

        (localInstanceReplicaValueSetterTry, remoteInstanceReplicaValueSetterTry) match {
          case (
                Success(localInstanceReplicaValueSetter),
                Success(remoteInstanceReplicaValueSetter)
              ) =>
            if (
              localEditorField.key == remoteEditorField.key && localInstanceReplicaValueSetter
                .equals(remoteInstanceReplicaValueSetter)
            ) {
              Success(localInstanceReplicaValueSetter)
            } else {
              Success(s"""
                   | if(executionInstanceName == "$localInstanceName") {
                   |   $localInstanceReplicaValueSetter
                   | }
                   | if(executionInstanceName == "$remoteInstanceName") {
                   |   $remoteInstanceReplicaValueSetter
                   | }
                   |""".stripMargin)
            }
          case (Success(localInstanceReplicaValueSetter), _)  =>
            Success(s"""
                 | if(executionInstanceName == "$localInstanceName") {
                 |   $localInstanceReplicaValueSetter
                 | }
                 |""".stripMargin)
          case (_, Success(remoteInstanceReplicaValueSetter)) =>
            Success(s"""
                 | if(executionInstanceName == "$remoteInstanceName") {
                 |   $remoteInstanceReplicaValueSetter
                 | }
                 |""".stripMargin)
          case (_, _)                                         =>
            // If there are no scripts available on either side, we don't set outscripts
            Success("")
        }
      case (None, Some(_))                                   =>
        Failure(
          new BugException(
            s"No field was found for ${mappingValue.local.map(_.field.key).orNull} on local instance"
          )
        )
      case (Some(_), None)                                   =>
        Failure(
          new BugException(
            s"No field was found for ${mappingValue.remote.map(_.field.key).orNull} on remote instance"
          )
        )
      case (_, _)                                            =>
        Failure(new BugException(s"No local field ${mappingValue.local
            .map(_.field.key)
            .orNull} or remote field ${mappingValue.remote.map(_.field.key).orNull}  was found"))
    }
    scriptStrTry
  }

  private def generateIncomingScriptRules(
      mappingValue: MappingValue,
      localEditorFieldOpt: Option[EditorFieldValue],
      remoteEditorFieldOpt: Option[EditorFieldValue],
      connectionValue: ConnectionValue
  ): Try[String] = {
    val scriptStrTry: Try[String] = (localEditorFieldOpt, remoteEditorFieldOpt) match {
      case (Some(localEditorField), Some(remoteEditorField)) =>
        // paramsForScript : FieldTypeSpecificScripts = FieldTypeSpecificScripts(paramForR: String, paramForL: String, remoteValueMatchToMapScript: String, localValueMatchToMapScript: String)
        val paramsForScriptTry: Try[FieldTypeSpecificScripts] =
          generateFieldSpecificScripts(localEditorField, remoteEditorField)

        val commentsType =
          EditorFieldTypeValue(MULTI.toString, Some(Seq(EditorFieldTypeValue(COMMENT.toString, None))))
        val attachmentsType =
          EditorFieldTypeValue(MULTI.toString, Some(Seq(EditorFieldTypeValue(FILE.toString, None))))

        paramsForScriptTry.map { paramsForScript =>
          val remoteInstanceName =
            StringEscapeUtils.escapeJava(connectionValue.remoteInstanceName.get)
          val localInstanceName = StringEscapeUtils.escapeJava(connectionValue.localInstanceName.get)
          // the second if-else block executes on the side that generates this script, accordingly the first one executes on the destination side
          val script =
            if (localEditorField.`type` == commentsType && remoteEditorField.`type` == commentsType) {
              val localCommentsImpersonationAttributeOpt = mappingValue.local
                .flatMap(l => l.attributes)
                .flatMap(attrs => attrs.find(_.field.key == "AUTHOR"))
              val remoteCommentsImpersonationAttributeOpt = mappingValue.remote
                .flatMap(l => l.attributes)
                .flatMap(attrs => attrs.find(_.field.key == "AUTHOR"))
              generateCommentsRule(
                localInstanceName,
                remoteInstanceName,
                mappingValue,
                localCommentsImpersonationAttributeOpt,
                remoteCommentsImpersonationAttributeOpt
              )
            } else if (
              localEditorField.`type` == attachmentsType && remoteEditorField.`type` == attachmentsType
            ) {
              generateAttachmentsRule(localInstanceName, remoteInstanceName, mappingValue)
            } else {
              generateMappingRule(
                localInstanceName,
                remoteInstanceName,
                mappingValue,
                localEditorField,
                remoteEditorField,
                paramsForScript
              )
            }
          script
        }
      case (None, Some(_))                                   =>
        Failure(
          new BugException(
            s"No field was found for ${mappingValue.local.map(_.field.key).orNull} on local instance"
          )
        )
      case (Some(_), None)                                   =>
        Failure(
          new BugException(
            s"No field was found for ${mappingValue.remote.map(_.field.key).orNull} on remote instance"
          )
        )
      case (_, _)                                            =>
        Failure(new BugException(s"No local field ${mappingValue.local
            .map(_.field.key)
            .orNull} or remote field ${mappingValue.remote.map(_.field.key).orNull}  was found"))
    }
    scriptStrTry
  }

  private def generateMappingRule(
      localInstanceName: String,
      remoteInstanceName: String,
      mappingValue: MappingValue,
      localEditorField: EditorFieldValue,
      remoteEditorField: EditorFieldValue,
      paramsForScript: FieldTypeSpecificScripts
  ): String = {
    val localValue = getScriptForValueFromField("issue", localEditorField)
    val localIssueType =
      getScriptForValueFromField("issue", EditorFields.ISSUE_TYPE.toString, OPTION.toString)

    val localFieldType = localEditorField.`type`.key
    val remoteFieldType = remoteEditorField.`type`.key // TEXT

    val localExalateAPIIndexes = getExalateAPIIndexes(localEditorField.`type`)
    val remoteExalateAPIIndexes = getExalateAPIIndexes(remoteEditorField.`type`)

    val localRecoveryType = mappingValue.local.flatMap(_.recovery.map(_.key)).orNull
    val localRecoveryValue = mappingValue.local.flatMap(
      _.recovery.flatMap(r => getIssueValueFromRecovery(r, Option(localEditorField)))
    )
    val remoteRecoveryType = mappingValue.remote.flatMap(_.recovery.map(_.key)).orNull
    val remoteRecoveryValue = mappingValue.remote.flatMap(
      _.recovery.flatMap(r => getIssueValueFromRecovery(r, Option(remoteEditorField)))
    )

    val localFieldKey = mappingValue.local.map(_.field.key).get
    val remoteFieldKey = mappingValue.remote.map(_.field.key).get
    val maps = mappingValue.maps.map { m =>
      val mapsJson = Json.toJson(m)
      val mapsJsonStr = Json.stringify(mapsJson)
      StringEscapeUtils.escapeJava(mapsJsonStr)
    }.orNull

    val arrow = mappingValue.arrow.getOrElse("LR")
    val leftRule =
      if ("L" == arrow) s"//sync $localInstanceName -> $remoteInstanceName\n//do nothing"
      else s"""
         |({
         |//sync $localInstanceName -> $remoteInstanceName
         |if ("$remoteInstanceName" == executionInstanceName && (arrow == "LR" || arrow == "R")) {
         |  println("#executeMapping $localFieldKey($localInstanceName) -> $remoteFieldKey($remoteInstanceName)")
         |  def issueType = $localIssueType
         |
         |  if(!shouldReceive(issueType?.value, "$remoteFieldKey", ${'"'}""${remoteEditorField.label}""${'"'})) {
         |     return
         |  }
         |
         |
         |  // getIssueValueByKey
         |    def localValue = $localValue
         |    def remoteRecoveryValue = ${remoteRecoveryValue.orNull}
         |    if(remoteRecoveryValue == null){
         |       remoteRecoveryValue = localValue
         |    }
         |    def remoteValue = applyMapsAndRecovery(
         |      maps,
         |      localValue,        // sentValue
         |      "$localFieldType", // sendingFieldType
         |      "$remoteFieldType",// receivingFieldType
         |      "$localFieldKey",  // sendingFieldName
         |      "$remoteFieldKey", // receivingFieldName
         |       ${paramsForScript.localValueToRemoteParamsScript}, // convertToParamsFn
         |       ${paramsForScript.localValueMatchToMapScript},     // sentMatchesFn
         |       { map -> map.local },                              // getMapValueFn
         |       ${paramsForScript.remoteMapToParamScript},         // getParamsFromMapFn
         |       "$remoteRecoveryType",                              // recoveryType
         |       remoteRecoveryValue,             // recoveryValue
         |       ExalateAPI$remoteExalateAPIIndexes                 // receivingExalateAPI
         |    )
         |
         |    if(remoteValue) {
         |      ExalateAPI$remoteExalateAPIIndexes.setValueToField(
         |        issue,
         |        "$remoteFieldKey",
         |        ${paramsForScript.remoteValueToLocalParamsScript}(remoteValue)
         |      )
         |    }
         |} })()
       """.stripMargin
    val rightRule =
      if ("R" == arrow) s"//sync $localInstanceName <- $remoteInstanceName\n//do nothing"
      else s"""
         |({
         |  //sync $localInstanceName <- $remoteInstanceName
         |if ( "$localInstanceName" == executionInstanceName && (arrow == "LR" || arrow == "L") ) {
         |  println("#executeMapping $localFieldKey($localInstanceName) <- $remoteFieldKey($remoteInstanceName)")
         |   def remoteIssueType = ExalateAPI["OPTION"].getValueFromField(issue, "ISSUE_TYPE")
         |
         |    if(!shouldReceive(remoteIssueType?.value, "$localFieldKey", ${'"'}""${localEditorField.label}""${'"'})) {
         |      return
         |    }
         |
         |     def remoteValue = ExalateAPI$remoteExalateAPIIndexes.getValueFromField(replica, "$remoteFieldKey")
         |     def localRecoveryValue = ${localRecoveryValue.orNull}
         |     if(localRecoveryValue == null){
         |        localRecoveryValue = remoteValue
         |     }
         |
         |     def localValue = applyMapsAndRecovery(
         |        maps,
         |        remoteValue,         // sentValue
         |        "$remoteFieldType",  // sendingFieldType
         |        "$localFieldType",   // receivingFieldType
         |        "$remoteFieldKey",   // sendingFieldName
         |        "$localFieldKey",    // receivingFieldName
         |        ${paramsForScript.remoteValueToLocalParamsScript}, // convertToParamsFn
         |        ${paramsForScript.remoteValueMatchToMapScript},    // sentMatchesFn
         |        { map -> map.remote },                             // getMapValueFn
         |        ${paramsForScript.localMapToParamScript},          // getParamsFromMapFn
         |        "$localRecoveryType",                             // recoveryType
         |        localRecoveryValue,            // recoveryValue
         |        ExalateAPI$localExalateAPIIndexes                  // receivingExalateAPI
         |    )
         |    println("#executeMapping after #applyMapsAndRecovery $localFieldKey($localInstanceName) localValue="+$localValue)
         |    if(localValue) {
         |      ExalateAPI$localExalateAPIIndexes.setValueToField(
         |        issue,
         |        "$localFieldKey",
         |        ${paramsForScript.localValueToRemoteParamsScript}(localValue)
         |      )
         |    }
         |} })()
       """.stripMargin
    s"""
       |def applyRecovery = { recoveryType, recoveryValue, receivingFieldName, receivingExalateAPI  ->
       |   def recoveryError = { e -> new com.exalate.domain.exception.editor.RecoveryMappingEditorException(mappings, swapSides ? com.exalate.api.domain.editor.error.EditorErrorSide.REMOTE : com.exalate.api.domain.editor.error.EditorErrorSide.LOCAL, recoveryValue.toString(), scala.Option.apply(e)) }
       |   println("#applyRecovery "+recoveryType+" "+recoveryValue+" "+receivingFieldName+" "+receivingExalateAPI)
       |   if(recoveryType == "DEFAULT") {
       |       try {
       |         def recoveryValueParams
       |         if (executionInstanceName == "$localInstanceName") {
       |           recoveryValueParams = ${localEditorField.`type` match {
        case t if t.key == TEXT.toString                                                      =>
          "new com.exalate.domain.script.StringTextParams(recoveryValue)"
        case t if t.key == OPTION.toString                                                    =>
          "new com.exalate.domain.script.StringOptionParams(recoveryValue)"
        case t if t.key == USER.toString                                                      =>
          "new com.exalate.domain.script.StringUserParams(recoveryValue)"
        case t if t.key == DATE.toString                                                      =>
          "new com.exalate.domain.script.StringDateParams(recoveryValue, \"" + DATE_FORMAT_STR + "\")"
        case t if t.key == MULTI.toString && t.of.exists(_.exists(_.key == COMMENT.toString)) =>
          "({ throw new com.exalate.api.exception.bug.BugException(" + '"' + s"#applyRecovery Can't apply recovery for COMMENTS mapping $localFieldKey ${mappingValue.arrow
              .getOrElse("")} $remoteFieldKey" + '"' + ") })()"
        case t if t.key == MULTI.toString && t.of.exists(_.exists(_.key == FILE.toString))    =>
          "({ throw new com.exalate.api.exception.bug.BugException(" + '"' + s"#applyRecovery Can't apply recovery for FILES mapping $localFieldKey ${mappingValue.arrow
              .getOrElse("")} $remoteFieldKey" + '"' + ") })()"
        case t if t.key == MULTI.toString && t.of.exists(_.exists(_.key == TEXT.toString))    =>
          "new com.exalate.domain.script.StringsMultiTextParams(recoveryValue)"
      }}
       |         } else {
       |           recoveryValueParams = ${remoteEditorField.`type` match {
        case t if t.key == TEXT.toString                                                      =>
          "new com.exalate.domain.script.StringTextParams(recoveryValue)"
        case t if t.key == OPTION.toString                                                    =>
          "new com.exalate.domain.script.StringOptionParams(recoveryValue)"
        case t if t.key == USER.toString                                                      =>
          "new com.exalate.domain.script.StringUserParams(recoveryValue)"
        case t if t.key == DATE.toString                                                      =>
          "new com.exalate.domain.script.StringDateParams(recoveryValue, \"" + DATE_FORMAT_STR + "\")"
        case t if t.key == MULTI.toString && t.of.exists(_.exists(_.key == COMMENT.toString)) =>
          "({ throw new com.exalate.api.exception.bug.BugException(" + '"' + s"#applyRecovery Can't apply recovery for COMMENTS mapping $localFieldKey ${mappingValue.arrow
              .getOrElse("")} $remoteFieldKey" + '"' + ") })()"
        case t if t.key == MULTI.toString && t.of.exists(_.exists(_.key == FILE.toString))    =>
          "({ throw new com.exalate.api.exception.bug.BugException(" + '"' + s"#applyRecovery Can't apply recovery for FILES mapping $localFieldKey ${mappingValue.arrow
              .getOrElse("")} $remoteFieldKey" + '"' + ") })()"
        case t if t.key == MULTI.toString && t.of.exists(_.exists(_.key == TEXT.toString))    =>
          "new com.exalate.domain.script.StringsMultiTextParams(recoveryValue)"
      }}
       |         }
       |         return receivingExalateAPI.getValueFromIssueTracker(receivingFieldName, recoveryValueParams, issue)
       |       } catch(e) {
       |           throw recoveryError(e)
       |       }
       |   } else if(recoveryType == "ERROR") {
       |      throw recoveryError(null)
       |   } else if(recoveryType == "NONE") {
       |      return null
       |   }
       |}
       |
       |def applyMapsAndRecovery = { maps, sentValue, sendingFieldType, receivingFieldType, sendingFieldName, receivingFieldName, convertToParamsFn, sentMatchesFn, getMapValueFn, getParamsFromMapFn, recoveryType, recoveryValue, receivingExalateAPI ->
       |  println("#applyMapsAndRecovery "+maps+" "+sentValue+" "+sendingFieldType+" "+receivingFieldType+" "+sendingFieldName+" "+receivingFieldName+" "+recoveryType+" "+recoveryType+" "+recoveryValue+" "+receivingExalateAPI+" ")
       |  if (!sentValue) {
       |    return applyRecovery(recoveryType, recoveryValue, receivingFieldName, receivingExalateAPI)
       |  }
       |  if (maps != null) {
       |    for (map in maps) {
       |      if (sentMatchesFn(sentValue, getMapValueFn(map))) {
       |        try {
       |          def receivingValueParams = getParamsFromMapFn(map)
       |          return receivingExalateAPI.getValueFromIssueTracker(receivingFieldName, receivingValueParams, issue)
       |        } catch(e) {
       |          return applyRecovery(recoveryType, recoveryValue, receivingFieldName, receivingExalateAPI)
       |        }
       |      }
       |    }
       |    if(maps.isEmpty() && recoveryType == "DEFAULT"){
       |      println("#applyMapsAndRecovery maps isEmpty && recoveryType is DEFAULT")
       |      return applyRecovery(recoveryType, recoveryValue, receivingFieldName, receivingExalateAPI)
       |    }
       |  }
       |  def receivingValueParams = convertToParamsFn(sentValue)
       |  def valueFromIssueTracker = null
       |  try {
       |     valueFromIssueTracker = receivingExalateAPI.getValueFromIssueTracker(receivingFieldName, receivingValueParams, issue)
       |  } catch(e) {
       |    return applyRecovery(recoveryType, recoveryValue, receivingFieldName, receivingExalateAPI)
       |  }
       |  if (maps == null || valueFromIssueTracker != null) {
       |     return valueFromIssueTracker
       |  }
       |  return applyRecovery(recoveryType, recoveryValue, receivingFieldName, receivingExalateAPI)
       |}
       |
       |
       |
       |def shouldReceive = { issueTypeName, receivingFieldKey, receivingFieldName ->
       |    //TODO JCLOUD-1369 replace with field dependencies
       |    def isEpicNameField = receivingFieldName == "Epic Name"
       |    def notEpic = "Epic" != issueTypeName
       |    def epicNameException = isEpicNameField && notEpic
       |    def notEpicNameException = !epicNameException
       |
       |    def notParentIdException = true
       |    // END: JCLOUD-1369 replace with field dependencies
       |    return notEpicNameException && notParentIdException
       |}
       |
       |def mapsJsonStr = "$maps"
       |def js = new groovy.json.JsonSlurper()
       |def maps = js.parseText(mapsJsonStr)
       |
       |
       |// side $localInstanceName generates script:
       |def arrow = "$arrow"
       |$leftRule
       |$rightRule
       |""".stripMargin
  }

  private def generateCommentsRule(
      localInstanceName: String,
      remoteInstanceName: String,
      mappingValue: MappingValue,
      localCommentsImpersonationAttributeOpt: Option[MappingFieldTypeValue],
      remoteCommentsImpersonationAttributeOpt: Option[MappingFieldTypeValue]
  ): String = {

    val arrow = mappingValue.arrow.getOrElse("LR")
    val leftRule =
      if ("L" == arrow) s"//sync $localInstanceName -> $remoteInstanceName\n//do nothing"
      else
        s"""
       |({
       |//sync $localInstanceName -> $remoteInstanceName
       |if ("$remoteInstanceName" == executionInstanceName && (arrow == "LR" || arrow == "R")) {
       |
       |    ${remoteCommentsImpersonationAttributeOpt match {
            case None                                  =>
              "commentHelper.mergeComments(issue, replica)"
            case Some(remoteCommentsImpersonationAttr) =>
              s"""commentHelper.mergeComments(issue, replica, { comment ->
       |        def author = ExalateAPI[\"USER\"].getValueFromIssueTracker(\"REPORTER\", new com.exalate.domain.script.HubUserUserParams(comment.author), issue)
       |        if (author == null) {
       |          ${(
                  remoteCommentsImpersonationAttr.recovery,
                  remoteCommentsImpersonationAttr.recovery.flatMap(_.value)
                ) match {
                  case (Some(r), Some(v)) if r.key == "DEFAULT" =>
                    "author = ExalateAPI[" + '"' + "USER" + '"' + "].getValueFromIssueTracker(" + '"' + "REPORTER" + '"' + ", new com.exalate.domain.script.StringUserParams(" + '"' + StringEscapeUtils
                      .escapeJava(
                        v.asInstanceOf[java.util.Map[String, String]].get("value")
                      ) + '"' + "), issue)"
                  case (None, _)                                =>
                    "// no recovery for author"
                  case (_, None)                                =>
                    "// no default value for author recovery"
                  case (_, _)                                   =>
                    "// non-default recovery for author"
                }}
       |        }
       |        comment.executor = author
       |      })""".stripMargin
          }}
       |} })()""".stripMargin
    val rightRule =
      if ("R" == arrow) s"//sync $localInstanceName <- $remoteInstanceName\n//do nothing"
      else
        s"""
       |({
       |//sync $localInstanceName <- $remoteInstanceName
       |if ( "$localInstanceName" == executionInstanceName && (arrow == "LR" || arrow == "L") ) {
              ${localCommentsImpersonationAttributeOpt match {
            case None                                 =>
              "commentHelper.mergeComments(issue, replica)"
            case Some(localCommentsImpersonationAttr) =>
              s"""commentHelper.mergeComments(issue, replica, { comment ->
       |        def author = ExalateAPI[\"USER\"].getValueFromIssueTracker(\"REPORTER\", new com.exalate.domain.script.HubUserUserParams(comment.author), issue)
       |        if (author == null) {
       |          ${(
                  localCommentsImpersonationAttr.recovery,
                  localCommentsImpersonationAttr.recovery.flatMap(_.value)
                ) match {
                  case (Some(r), Some(v)) if r.key == "DEFAULT" =>
                    "author = ExalateAPI[" + '"' + "USER" + '"' + "].getValueFromIssueTracker(" + '"' + "REPORTER" + '"' + ", new com.exalate.domain.script.StringUserParams(" + '"' + StringEscapeUtils
                      .escapeJava(
                        v.asInstanceOf[java.util.Map[String, String]].get("value")
                      ) + '"' + "), issue)"
                  case (None, _)                                =>
                    "// no recovery for author"
                  case (_, None)                                =>
                    "// no default value for author recovery"
                  case (_, _)                                   =>
                    "// non-default recovery for author"
                }}
       |        }
       |        comment.executor = author
       |      })""".stripMargin
          }}
       |} })()""".stripMargin
    s"""
      |// side $localInstanceName generates script:
      |def arrow = "$arrow"
      |$leftRule
      |$rightRule""".stripMargin
  }

  private def generateAttachmentsRule(
      localInstanceName: String,
      remoteInstanceName: String,
      mappingValue: MappingValue
  ): String = {
    val arrow = mappingValue.arrow.getOrElse("LR")
    val leftRule =
      if ("L" == arrow) s"//sync $localInstanceName -> $remoteInstanceName\n//do nothing" else s"""
     |({
     |  //sync $localInstanceName -> $remoteInstanceName
     |  if ("$remoteInstanceName" == executionInstanceName && (arrow == "LR" || arrow == "R")) {
     |
     |    attachmentHelper.mergeAttachments(issue, replica)
     |  }
     |})()""".stripMargin
    val rightRule =
      if ("R" == arrow) s"//sync $localInstanceName <- $remoteInstanceName\n//do nothing" else s"""
     |({
     |  //sync $localInstanceName <- $remoteInstanceName
     |  if ( "$localInstanceName" == executionInstanceName && (arrow == "LR" || arrow == "L") ) {
     |
     |    attachmentHelper.mergeAttachments(issue, replica)
     |  }
     |})()""".stripMargin
    s"""
       |// side $localInstanceName generates script:
       |def arrow = "$arrow"
       |$leftRule
       |$rightRule""".stripMargin
  }

  private def generateFieldSpecificScripts(
      localField: EditorFieldValue,
      remoteField: EditorFieldValue
  ): Try[FieldTypeSpecificScripts] = {
    val localFieldType = localField.`type`
    val remoteFieldType = remoteField.`type`
    (
      FieldDataType.withNameOpt(localFieldType.key),
      FieldDataType.withNameOpt(remoteFieldType.key)
    ) match {
      case (Some(FieldDataType.TEXT), Some(FieldDataType.TEXT))     =>
        Success(
          FieldTypeSpecificScripts(
            remoteValueToLocalParamsScript =
              "{ value -> new com.exalate.domain.script.StringTextParams(value) }",
            localValueToRemoteParamsScript =
              "{ value -> new com.exalate.domain.script.StringTextParams(value) }",
            //          remoteValueMatchToMapScript = StringToObjectFunction("({ (remoteValue, String remoteMap) -> remoteMap.equals(remoteValue) })", ),
            remoteValueMatchToMapScript = "{ value, String remoteMap -> remoteMap.equals(value) }",
            localValueMatchToMapScript = "{ value, String localMap -> localMap.equals(value) }",
            remoteMapToParamScript =
              "{ map -> new com.exalate.domain.script.StringTextParams(map.remote) }",
            localMapToParamScript =
              "{ map -> new com.exalate.domain.script.StringTextParams(map.local) }"
          )
        )
      case (Some(DATE), Some(FieldDataType.TEXT))                   =>
        Success(
          FieldTypeSpecificScripts(
            remoteValueToLocalParamsScript =
              "{ value -> new com.exalate.domain.script.DateTextParams(value) }",
            localValueToRemoteParamsScript =
              s"""{ value -> new com.exalate.domain.script.StringDateParams(value, "$DATE_FORMAT") }""".stripMargin,
            remoteValueMatchToMapScript =
              "{ (value, String remoteMap) -> remoteMap.equals(value) }",
            localValueMatchToMapScript =
              s"""{ (value, String localMap) -> (new java.text.SimpleDateFormat("$DATE_FORMAT")).parse(localMap).equals(value) }""",
            remoteMapToParamScript =
              "{ (map) -> new com.exalate.domain.script.StringTextParams(map.remote) }",
            localMapToParamScript =
              s"""{ (map) -> new com.exalate.domain.script.StringDateParams(map.local, "$DATE_FORMAT") }"""
          )
        )
      case (Some(FieldDataType.OPTION), Some(FieldDataType.TEXT))   =>
        Success(
          FieldTypeSpecificScripts(
            remoteValueToLocalParamsScript =
              "{ value -> new com.exalate.domain.script.HubOptionTextParams(value) }",
            localValueToRemoteParamsScript =
              "{ value -> new com.exalate.domain.script.StringOptionParams(value) }",
            remoteValueMatchToMapScript = "{ value, String remoteMap -> remoteMap.equals(value) }",
            localValueMatchToMapScript =
              "{ value, String localMap -> localMap.equals(value.getValue()) }",
            remoteMapToParamScript =
              "{ map -> new com.exalate.domain.script.StringTextParams(map.remote) }",
            localMapToParamScript =
              "{ map -> new com.exalate.domain.script.StringOptionParams(map.local) }"
          )
        )
      case (Some(USER), Some(FieldDataType.TEXT))                   =>
        Success(
          FieldTypeSpecificScripts(
            remoteValueToLocalParamsScript =
              "{ value -> new com.exalate.domain.script.HubUserTextParams(value) }",
            localValueToRemoteParamsScript =
              "{ value -> new com.exalate.domain.script.StringUserParams(value) }",
            remoteValueMatchToMapScript =
              s"""{ value, String remoteMap -> remoteMap.equals(value)} """,
            localValueMatchToMapScript =
              s"""{ value, String localMap -> localMap.equals(value.getEmail()) || localMap.equals(value.getKey())} """,
            remoteMapToParamScript =
              s"{ map -> new com.exalate.domain.script.StringTextParams(map.remote) }",
            localMapToParamScript =
              s"{ map -> new com.exalate.domain.script.StringUserParams(map.local)}"
          )
        )
      case (Some(FieldDataType.TEXT), Some(DATE))                   =>
        Success(
          FieldTypeSpecificScripts(
            remoteValueToLocalParamsScript =
              s"""{ value -> new com.exalate.domain.script.StringDateParams(value, "$DATE_FORMAT") }""".stripMargin,
            localValueToRemoteParamsScript =
              "{ value -> new com.exalate.domain.script.DateTextParams(value) }",
            remoteValueMatchToMapScript =
              s"""{ value, String remoteMap -> (new java.text.SimpleDateFormat("$DATE_FORMAT")).parse(remoteMap).equals(value) }"""",
            localValueMatchToMapScript = "{ value, String localMap -> localMap.equals(value) }",
            remoteMapToParamScript =
              s"""{ map -> new com.exalate.domain.script.StringDateParams(map.remote, "$DATE_FORMAT") }""",
            localMapToParamScript =
              "{ map -> new com.exalate.domain.script.StringTextParams(map.local) }"
          )
        )
      case (Some(DATE), Some(DATE))                                 =>
        Success(
          FieldTypeSpecificScripts(
            remoteValueToLocalParamsScript =
              "{ value -> new com.exalate.domain.script.DateDateParams(value) }",
            localValueToRemoteParamsScript =
              "{ value -> new com.exalate.domain.script.DateDateParams(value) }",
            remoteValueMatchToMapScript =
              s"""{ value, String remoteMap -> (new java.text.SimpleDateFormat("$DATE_FORMAT")).parse(remoteMap).equals(value) }""",
            localValueMatchToMapScript =
              s"""{ value, String localMap -> (new java.text.SimpleDateFormat("$DATE_FORMAT")).parse(localMap).equals(value) }""",
            remoteMapToParamScript =
              s"""{ map -> new com.exalate.domain.script.StringDateParams(map.remote, "$DATE_FORMAT") }""",
            localMapToParamScript =
              s"""{ map -> new com.exalate.domain.script.StringDateParams(map.local, "$DATE_FORMAT") }"""
          )
        )
      case (Some(FieldDataType.OPTION), Some(FieldDataType.OPTION)) =>
        Success(
          FieldTypeSpecificScripts(
            remoteValueToLocalParamsScript =
              "{ value -> new com.exalate.domain.script.HubOptionOptionParams(value) }",
            localValueToRemoteParamsScript =
              "{ value -> new com.exalate.domain.script.HubOptionOptionParams(value) }",
            remoteValueMatchToMapScript =
              s"""{ value, String remoteMap -> remoteMap.equals(value.getValue())} """,
            localValueMatchToMapScript =
              s"""{ value, String localMap -> localMap.equals(value.getValue())} """,
            remoteMapToParamScript =
              s"{ map -> new com.exalate.domain.script.StringOptionParams(map.remote) }",
            localMapToParamScript =
              s"{ map -> new com.exalate.domain.script.StringOptionParams(map.local)}"
          )
        )
      case (Some(FieldDataType.TEXT), Some(FieldDataType.OPTION))   =>
        Success(
          FieldTypeSpecificScripts(
            remoteValueToLocalParamsScript =
              "{ value -> new com.exalate.domain.script.HubOptionTextParams(value) }",
            localValueToRemoteParamsScript =
              "{ value -> new com.exalate.domain.script.HubOptionTextParams(value) }",
            remoteValueMatchToMapScript =
              s"""{ value, String remoteMap -> remoteMap.equals(value)} """,
            localValueMatchToMapScript =
              s"""{ value, String localMap -> localMap.equals(value.getValue()) } """,
            remoteMapToParamScript =
              s"{ map -> new com.exalate.domain.script.StringTextParams(map.remote) }",
            localMapToParamScript =
              s"{ map -> new com.exalate.domain.script.StringOptionParams(map.local) }"
          )
        )
      case (Some(USER), Some(USER))                                 =>
        Success(
          FieldTypeSpecificScripts(
            remoteValueToLocalParamsScript =
              "{ value -> new com.exalate.domain.script.HubUserUserParams(value) }",
            localValueToRemoteParamsScript =
              "{ value -> new com.exalate.domain.script.HubUserUserParams(value) }",
            remoteValueMatchToMapScript =
              s"""{ value, String remoteMap -> remoteMap.equals(value.getEmail()) ||
               | remoteMap.equals(value.getKey()) ||
               | remoteMap.equals(value.getDisplayName()) ||
               | remoteMap.equals(value.getUsername()) } """.stripMargin,
            localValueMatchToMapScript =
              s"""{ value, String localMap -> localMap.equals(value.getEmail()) ||
               | localMap.equals(value.getKey()) ||
               | localMap.equals(value.getDisplayName()) ||
               | localMap.equals(value.getUsername()) } """.stripMargin,
            remoteMapToParamScript =
              s"{ map -> new com.exalate.domain.script.StringUserParams(map.remote) }",
            localMapToParamScript =
              s"{ map -> new com.exalate.domain.script.StringUserParams(map.local)}"
          )
        )
      case (Some(FieldDataType.TEXT), Some(USER))                   =>
        Success(
          FieldTypeSpecificScripts(
            remoteValueToLocalParamsScript =
              "{ value -> new com.exalate.domain.script.StringUserParams(value) }",
            localValueToRemoteParamsScript =
              "{ value -> new com.exalate.domain.script.HubUserTextParams(value) }",
            remoteValueMatchToMapScript =
              s"""{ value, String remoteMap -> remoteMap.equals(value)} """,
            localValueMatchToMapScript =
              s"""{ value, String localMap -> localMap.equals(value.getEmail()) ||
               | localMap.equals(value.getKey()) ||
               | localMap.equals(value.getDisplayName()) ||
               | localMap.equals(value.getUsername()) } """.stripMargin,
            remoteMapToParamScript =
              s"{ map -> new com.exalate.domain.script.StringUserParams(map.remote) }",
            localMapToParamScript =
              s"{ map -> new com.exalate.domain.script.StringTextParams(map.local)}"
          )
        )
      case (Some(MULTI), Some(MULTI))                               =>
        val localTypeOf = localFieldType.of.flatMap(_.headOption.map(_.key))
        val remoteTypeOf = remoteFieldType.of.flatMap(_.headOption.map(_.key))

        (localTypeOf, remoteTypeOf) match {
          case (Some(localType), Some(remoteType)) =>
            (FieldDataType.withNameOpt(localType), FieldDataType.withNameOpt(remoteType)) match {
              case (Some(FieldDataType.FILE), Some(FieldDataType.FILE))       =>
                Success(
                  FieldTypeSpecificScripts(
                    remoteValueToLocalParamsScript =
                      "{ value -> new com.exalate.domain.script.HubAttachmentFileParams(value) }",
                    localValueToRemoteParamsScript =
                      "{ value -> new com.exalate.domain.script.HubAttachmentFileParams(value) }",
                    remoteValueMatchToMapScript = s"""{ value, String remoteMap -> true} """,
                    localValueMatchToMapScript = s"""{ value, String localMap -> true} """,
                    remoteMapToParamScript = s"{ map -> null}",
                    localMapToParamScript = s"{ map -> null}"
                  )
                )
              case (Some(FieldDataType.COMMENT), Some(FieldDataType.COMMENT)) =>
                Success(
                  FieldTypeSpecificScripts(
                    remoteValueToLocalParamsScript =
                      "{ value -> new com.exalate.domain.script.HubCommentCommentParams(value) }",
                    localValueToRemoteParamsScript =
                      "{ value -> new com.exalate.domain.script.HubCommentCommentParams(value) }",
                    remoteValueMatchToMapScript = s"""{ value, String remoteMap -> true} """,
                    localValueMatchToMapScript = s"""{ value, String localMap -> true} """,
                    remoteMapToParamScript = s"{ map -> null }",
                    localMapToParamScript = s"{ map -> null }"
                  )
                )
              case (
                    Some(FieldDataType.TEXT),
                    Some(FieldDataType.TEXT)
                  ) => // TODO Implement Label <> TEXT
                Success(
                  FieldTypeSpecificScripts(
                    remoteValueToLocalParamsScript =
                      "{ value -> new com.exalate.domain.script.StringsMultiTextParams(value) }",
                    localValueToRemoteParamsScript =
                      "{ value -> new com.exalate.domain.script.StringsMultiTextParams(value) }",
                    remoteValueMatchToMapScript = s"""{ value, String remoteMap -> true} """,
                    localValueMatchToMapScript = s"""{ value, String localMap -> true} """,
                    remoteMapToParamScript = s"{ map -> null}",
                    localMapToParamScript = s"{ map -> null}"
                  )
                )
            }
        }

      case (lType, rType) =>
        Failure(
          new BugException(
            s"Mapping between `${lType.getOrElse("None")}` and `${rType.getOrElse("None")}` is not supported. Please contact Exalate Support!"
          )
        )
    }
  }

  private def getScriptForValueFromField(
      entityType: String,
      editorFieldValue: EditorFieldValue
  ): String =
    getScriptForValueFromField(entityType, editorFieldValue.key, editorFieldValue.`type`.key)

  private def getScriptForValueFromField(
      entityType: String,
      editorFieldKey: String,
      editorFieldType: String
  ): String = {
    entityType match {
      case "issue" =>
        val fieldName = editorFieldKey
        EditorFields.withNameOpt(fieldName) match {
          case Some(SUMMARY)     =>
            s"replica.summary" // value should have the same type as IExalateAPI ()
          case Some(DESCRIPTION) =>
            s"replica.description" // value should have the same type as IExalateAPI ()
          case Some(DUE) => s"replica.due" // value should have the same type as IExalateAPI ()
          case Some(AREA_PATH)      => s"replica.areaPath"
          case Some(ITERATION_PATH) => s"replica.iterationPath"
          case Some(PROJECT)        =>
            """
              |({
              |if(!replica?.project) return null else {
              | def basicHubOption = new com.exalate.basic.domain.hubobject.v1.BasicHubOption()
              | basicHubOption.setValue(replica.project?.name)
              | basicHubOption.setId(replica.project?.id?.toString())
              |
              | return basicHubOption
              | }
              |})()
            """.stripMargin
          case Some(ISSUE_TYPE)     =>
            """
              |({
              |if(!replica?.type) return null else {
              | def basicHubOption = new com.exalate.basic.domain.hubobject.v1.BasicHubOption()
              | basicHubOption.setValue(replica.type?.name)
              | basicHubOption.setId(replica.type?.id)
              |
              | return basicHubOption
              | }
              |})()
            """.stripMargin
          case Some(STATUS)         =>
            """
              |({
              |if(!replica?.status) return null else {
              | def basicHubOption = new com.exalate.basic.domain.hubobject.v1.BasicHubOption()
              |
              | basicHubOption.setValue(replica.status?.name)
              | basicHubOption.setId(replica.status?.id)
              |
              | return basicHubOption
              |}
              |})()
              |""".stripMargin
          case Some(PRIORITY)       =>
            """
              |({
              |if(!replica?.priority) return null else {
              | def basicHubOption = new com.exalate.basic.domain.hubobject.v1.BasicHubOption()
              |
              | basicHubOption.setValue(replica.priority?.name)
              | basicHubOption.setId(replica.priority?.id)
              |
              | return basicHubOption
              |}
              |})()
              |""".stripMargin

          case Some(ATTACHMENTS)                                      =>
            """
              |({
              |if(!replica?.attachments) return null else {
              |
              | return replica.attachments
              |}
              |})()
              |""".stripMargin
          case Some(COMMENTS)                                         =>
            """
              |({
              |if(!replica?.comments) return null else {
              |
              | return replica.comments
              |}
              |})()
              |""".stripMargin
          case Some(LABELS)                                           =>
            """
              |({
              |if(!replica?.labels) return null else {
              |
              | return replica.labels.collect(new HashSet()){it.getLabel()}
              |}
              |})()
              |""".stripMargin
          case Some(ASSIGNEE)                                         =>
            """
              |({
              |if(!replica?.assignee) return null else {
              |
              | return replica.assignee
              |}
              |})()
              |""".stripMargin
          case Some(REPORTER)                                         =>
            """
              |({
              |if(!replica?.reporter) return null else {
              |
              | return replica.reporter
              |}
              |})()
              |""".stripMargin
          // TODO EXAEDIT-873 depending on type
          case _ if editorFieldType == FieldDataType.TEXT.toString    =>
            s"""replica."${StringEscapeUtils.escapeJava(fieldName)}" """
          case _ if editorFieldType == DATE.toString                  =>
            s"""replica."${StringEscapeUtils.escapeJava(fieldName)}" """
          case _ if editorFieldType == FieldDataType.OPTION.toString  =>
            s"""({
               |  def value = replica."${StringEscapeUtils.escapeJava(fieldName)}"
               |  if(value == null) return null else if (value instanceof com.exalate.basic.domain.hubobject.v1.BasicHubOption){
               |    return value
               |  } else if(value instanceof java.lang.String) { //Handle ADNODE custom fields which are not HubOptions
               |    def basicHubOption = new com.exalate.basic.domain.hubobject.v1.BasicHubOption()
               |    basicHubOption.setValue(value)
               |    return basicHubOption
               |  } else throw new Exception("`"+ value +"` is not instance of BasicHubOption") // TODO EXAEDIT-873 BUG
               |})()""".stripMargin
          case _ if editorFieldType == USER.toString                  =>
            s"""({
               |  def value = replica."${StringEscapeUtils.escapeJava(fieldName)}"
               |  if (value instanceof com.exalate.basic.domain.hubobject.v1.BasicHubUser){
               |    return value
               |  } else throw new Exception(" in not instance of BasicHubUser") // TODO EXAEDIT-873 BUG
               |})()""".stripMargin
          case _ if editorFieldType == FieldDataType.COMMENT.toString => ???
          case _ if editorFieldType == FieldDataType.FILE.toString    => ???
        }
    }
  }

  private def getScriptForReplicaValueSetter(
      entityType: String,
      editorFieldValue: EditorFieldValue,
      filters: Option[Seq[FilterKey]]
  ): Try[String] =
    getScriptForReplicaValueSetter(
      entityType,
      editorFieldValue.key,
      editorFieldValue.`type`.key,
      filters
    )

  private def getScriptForReplicaValueSetter(
      entityType: String,
      editorFieldKey: String,
      editorFieldType: String,
      filters: Option[Seq[FilterKey]]
  ): Try[String] =
    Try(entityType match {
      case "issue" =>
        val fieldName = editorFieldKey
        EditorFields.withNameOpt(fieldName) match {
          case Some(SUMMARY)     => ???
          case Some(DESCRIPTION) =>
            s"""
               |def description =
               |({
               |   try {
               |      return nodeHelper.stripHtml(issue.description)
               |   } catch(scala.NotImplementedError | Exception e) {
               |      return issue.description
               |   }
               |})()
               |issue.setDescription(description)
               |""".stripMargin
          case Some(DUE)         => ???
          case Some(PROJECT)     => ???
          case Some(ISSUE_TYPE)  => ???
          case Some(STATUS)      => ???
          case Some(PRIORITY)    => ???

          case Some(ATTACHMENTS)                                   => ???
          case Some(COMMENTS)                                      =>
            val filteredCommentsScript = "issue.comments" + filters.toSeq.flatten
              .foldLeft("") {
                case (result, f) =>
                  CommentFilters.withNameOpt(f.key) match {
                    case Some(CommentFilters.SKIP_NONE)     => result
                    case Some(CommentFilters.SKIP_EXTERNAL) =>
                      result + ".findAll{it.internal}" // show only internal
                    case Some(CommentFilters.SKIP_INTERNAL) =>
                      result + ".findAll{!it.internal}" // show only external
                    case _                                  => result
                  }
              }

            s"""
              |def comments =
              |                 ({
              |                     if(!issue?.comments) return null else {
              |                       return $filteredCommentsScript.collect {
              |                             try {
              |                               it.body = nodeHelper.stripHtml(it.body)
              |                             } catch(scala.NotImplementedError | Exception e) {
              |                                //Ignore
              |                             }
              |                             it
              |                        }
              |                     }
              |                   })()
              | issue.setComments(comments)
              |""".stripMargin
          case Some(LABELS)                                        => ???
          case Some(ASSIGNEE)                                      => ???
          case Some(REPORTER)                                      => ???
          // TODO EXAEDIT-873 depending on type
          case _ if editorFieldType == FieldDataType.TEXT.toString =>
            s"""
               | issue."${StringEscapeUtils.escapeJava(fieldName)}" =
               |({
               | def textValue = issue."${StringEscapeUtils.escapeJava(fieldName)}"
               | try {
               |   return nodeHelper.stripHtml(textValue)
               | } catch(scala.NotImplementedError | Exception e) {
               |   return textValue
               | }
               | })()
               |""".stripMargin
          case _ if editorFieldType == DATE.toString               => ???

          case _ if editorFieldType == USER.toString                  => ???
          case _ if editorFieldType == FieldDataType.COMMENT.toString => ???
          case _ if editorFieldType == FieldDataType.FILE.toString    => ???
        }
    })

  private def getExalateAPIIndexes(editorFieldType: EditorFieldTypeValue): String =
    editorFieldType.of match {
      case Some(of) =>
        of.headOption match {
          case Some(eft) =>
            s"""["${editorFieldType.key}"]""" + getExalateAPIIndexes(eft)
          case None      =>
            s"""["${editorFieldType.key}"]"""
        }
      case None     =>
        s"""["${editorFieldType.key}"]"""

    }

  private def getIssueValueFromRecovery(
      recovery: Recovery,
      localFieldValueOpt: Option[EditorFieldValue]
  ): Option[String] = {
    def stringFormat = (v: String) => s"""\"$v\""""
    def arrayFormat = (v: String) => s"""[\"$v\"]"""
    def jsonParser[T] =
      GsonCaseClassValueJsonService.read[Map[String, T]](_, classOf[Map[String, T]])
    def jsonParserWithFallback[T: ClassTag] = (jsonString: String) =>
      jsonParser(jsonString)
        .orElse {
          GsonCaseClassValueJsonService
            .read[T](jsonString, classTag[T].runtimeClass)
            .map(str => Map("value" -> str))
        }

    localFieldValueOpt
      .map(_.`type`)
      .flatMap { editorFieldType =>
        FieldDataType
          .withNameOpt(editorFieldType.key)
          .flatMap {
            case OPTION      => getFieldValue(recovery, "label", stringFormat, jsonParser)
            case TEXT | USER =>
              getFieldValue(recovery, "value", stringFormat, jsonParserWithFallback)
            case MULTI if editorFieldType.of.exists(_.exists(_.key == TEXT.toString)) =>
              getFieldValue(recovery, "value", arrayFormat, jsonParser)
            case _                                                                    => None
          }
      }
  }

  private def getFieldValue[T](
      recovery: Recovery,
      key: String,
      formatString: T => String,
      jsonParser: String => Try[Map[String, T]]
  ): Option[String] =
    recovery.value
      .flatMap { obj =>
        GsonCaseClassValueJsonService
          .write(obj)
          .flatMap(jsonParser)
          .toOption
          .flatMap(_.get(key))
          .map(formatString)
      }

  override def generateScriptScopes(
      singleSideScope: SingleSideScope,
      side: EditorErrorSide,
      connectionValue: ConnectionValue,
      fieldValues: Seq[EditorFieldValue]
  ): String = {
    loggingService.info(
      s"#generateScriptScopes generating scripts for scope `${singleSideScope.scopeUid}` (${if (singleSideScope.local) "local"
        else "remote"}) for connection `${connectionValue.name}` (${connectionValue.id.map(_.toString).getOrElse("")})"
    )

    val filtersScript = singleSideScope.query
      .getOrElse(Seq.empty)
      .foldLeft("") { (script, q) =>
        script + generateFiltersScript(q, fieldValues)
      }

    val mainFieldsScript = singleSideScope.mainFields
      .foldLeft(Option.empty[String]) { (script, mf) =>
        (mf.key, mf.value.flatMap(toValueStr)) match {
          case ("PROJECT", Some(scopesProjectId)) =>
            val scopesProjectIdStr = StringEscapeUtils.escapeJava(scopesProjectId)
            Option(
              script.getOrElse("") +
                s"""
                     | ({
                     |   def projectId = issue?.getProject().getIdStr()
                     |
                     |   println("#executeScope #mainFieldMatches `PROJECT` `IS` `$scopesProjectIdStr` projectId=`"+projectId+"`: "+"$scopesProjectIdStr".equals(projectId.toString()));
                     |   matches = matches && ( "$scopesProjectIdStr".equals(projectId.toString()) )
                     | })()
                     |""".stripMargin
            )

          case _ => script
        }
      }
      .getOrElse("")
    val instanceNameOrNull =
      (if (side == EditorErrorSide.LOCAL) connectionValue.localInstanceName
       else connectionValue.remoteInstanceName)
        .map(StringEscapeUtils.escapeJava)
        .map(n => "\"" + n + "\"")
        .orNull

    val script = s"""
           | def matches = true
           | def scope_uid = "${singleSideScope.scopeUid}"
           |
           | $mainFieldsScript
           |
           | $filtersScript
           | println("#executeScope: issueKey=`"+issue.key+"` connection=`"+ connection.name +"` scope=`${singleSideScope.scopeUid}` matches=`"+matches+"`")
           | if(matches) {
           |      issue.putAll(["$EXALATE_SCOPE_UID": scope_uid])
           |      issue.putAll(["$EXALATE_SCOPE_SIDE": "${StringEscapeUtils.escapeJava(
                     side.toString
                   )}"])
           |      issue.putAll(["$EXALATE_SCOPE_INSTANCE_NAME": $instanceNameOrNull])
           |      ExalateHelper.scheduleExalateOrUpdateEvent(connection, issue)
           | }
           |""".stripMargin
    // EASE-7798 : note, how we're using issue.putAll instead of .put to avoid calls to the issue tracker and directly put stuff to internalMap
    loggingService.info(
      s"#generateScriptScopes generated scripts for scope `${singleSideScope.scopeUid}` (${if (singleSideScope.local) "local"
        else "remote"}) for connection `${connectionValue.name}` (${connectionValue.id.map(_.toString).getOrElse("")}): $script"
    )
    script
  }

  private def generateFiltersScript(query: QueryValue, fieldValues: Seq[EditorFieldValue]) = {

    val fieldName = query.field.key
    val editorFieldValueOpt = fieldValues.find(fv => fv.key == fieldName)
    val editorFieldValue = fieldValues.find(fv => fv.key == fieldName).get
    val fieldType = editorFieldValue.`type`.key
    val expectedValue = query.value
    val operator = query.operator.key
    val valueVariableName = s"field_${fieldName.toLowerCase}"

    val indexes = getExalateAPIIndexes(editorFieldValue.`type`)
    s"""
       |({
       | def $valueVariableName = ExalateAPI$indexes.getValueFromField(issue, "$fieldName")
       |
       | matches = matches && ${getFieldMatchesScript(
        fieldName,
        operator,
        valueVariableName,
        fieldType,
        indexes,
        expectedValue
      )}
       |})()
       |""".stripMargin
  }

  private def toValueStr(v: Object) =
    toStr("value")(v)

  private def toStr(key: String)(v: Object) = {
    def mapToStr(in: Map[String, Object]): Option[String] =
      in.get(key)
        .map(_.toString)

    v match {
      case _: java.util.Map[String, Object] =>
        mapToStr(
          v.asInstanceOf[java.util.Map[String, Object]].asScala.toMap
        )
      case _: Map[String, Object]           =>
        mapToStr(
          v
            .asInstanceOf[Map[String, Object]]
        )
      case _: String                        => Option(v.asInstanceOf[String])
      case _                                => Option.empty[String]
    }
  }

  private def getFieldMatchesScript(
      fieldName: String,
      operator: String,
      valueVariableName: String,
      fieldType: String,
      indexes: String,
      expectedValue: Object
  ): String =
    ScopeQueryOperators.withNameOpt(operator) match {
      case Some(IS)               =>
        s"""("${expectedValue.asInstanceOf[String]}" == $valueVariableName)"""
      case Some(IS_NOT)           =>
        s"""("${expectedValue.asInstanceOf[String]}" != $valueVariableName)"""
      case Some(CONTAINS)         =>
        s"""($valueVariableName.contains("${expectedValue.asInstanceOf[String]}"))"""
      case Some(DOES_NOT_CONTAIN) =>
        s"""(!$valueVariableName.contains("${expectedValue.asInstanceOf[String]}"))"""
      case Some(IN)               =>
        toStrSeq(expectedValue)(toValueStr).toOption match {
          case Some(ev) =>
            val evEscaped = ev.map(groovy.json.StringEscapeUtils.escapeJava)
            val expectedValueAsListLiteralScript =
              evEscaped match {
                case _evEscaped if _evEscaped.isEmpty => "[]"
                case _evEscaped => "[\"" + _evEscaped.mkString("\",\"") + "\"]"
              }

            fieldType match {
              case "TEXT"                                        =>
                s"""$expectedValueAsListLiteralScript.any { it.equals($valueVariableName) }"""
              case "USER"                                        =>
                s"""( $expectedValueAsListLiteralScript.any { it.equals($valueVariableName.email) } || $expectedValueAsListLiteralScript.any { it.equals($valueVariableName.key) } || $expectedValueAsListLiteralScript.any { it.equals($valueVariableName.displayName) } )"""
              case "OPTION"                                      =>
                s"""({
                   |  println("#executeScope #fieldMatches `$fieldName` `$operator` `[${evEscaped
                    .mkString(
                      " , "
                    )}]` `$valueVariableName.idStr`=`"+$valueVariableName.idStr+"`: "+$expectedValueAsListLiteralScript.any {it.equals($valueVariableName.idStr) } );
                   |  $expectedValueAsListLiteralScript.any {
                   |    //println("#executeScope #fieldMatches #any `$fieldName` it=`"+it+"` `$valueVariableName.idStr`=`"+$valueVariableName.idStr+"` `it?.getClass()?.name`=`"+it?.getClass()?.name+"` `$valueVariableName.id?.getClass()?.name`=`"+ $valueVariableName.id?.getClass()?.name +"` : "+it.equals($valueVariableName.id));
                   |    it.equals($valueVariableName.idStr)
                   |  }
                   |})()""".stripMargin
              case "MULTI" if indexes == """["MULTI"]["TEXT"]""" =>
                s"""({
                   |  println("#executeScope #fieldMatches `$fieldName` `$operator` `[${evEscaped
                    .mkString(" , ")}]` $valueVariableName="+$valueVariableName);
                   |  $expectedValueAsListLiteralScript.any { expected ->
                   |    $valueVariableName.any { actual -> expected.equalsIgnoreCase(actual) }
                   |  }
                   |})()""".stripMargin
              case _                                             =>
                "" // for now we assume that there are no other filters but USER, TEXT and OPTION
            }
          case _        => ???
        }

      case Some(NOT_IN) =>
        toStrSeq(expectedValue)(toValueStr).toOption match {
          case Some(ev) =>
            val evJson = Json.toJson(ev)
            val evJsonStr = Json.stringify(evJson)
            val expectedValueAsListString = StringEscapeUtils.escapeJava(evJsonStr)

            s"""!$expectedValueAsListString.contains($valueVariableName)"""
          case _        =>
            throw new BugException(
              s"Couldn't parse filter values for field $fieldName using $operator operator"
            )
        }
      case _            => throw new BugException(s"Unsupported operator $operator")
    }

  def toStrSeq(v: Object)(toStrFn: Object => Option[String]): Try[Seq[String]] = v match {
    case vL if vL.isInstanceOf[java.util.List[Object]] =>
      Success(vL.asInstanceOf[java.util.List[Object]].asScala.toSeq.flatMap(v => toStrFn(v)))
    case vS if vS.isInstanceOf[Seq[Object]]            =>
      Success(vS.asInstanceOf[Seq[Object]].flatMap(v => toStrFn(v)))
    case _                                             =>
      Failure[Seq[String]](
        new ClassCastException(
          "Expecting to have Either Java List or a Scala Seq, but got: " + v + "of class: " + v.getClass
        )
      )
  }

}
