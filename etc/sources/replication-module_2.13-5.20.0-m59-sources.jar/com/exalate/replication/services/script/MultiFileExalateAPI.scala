package com.exalate.replication.services.script

import com.exalate.api.domain.hubobject.IHubIssueReplica
import com.exalate.api.hubobject.jira.IAttachmentHelper
import com.exalate.basic.domain.hubobject.v1.{BasicHubAttachment, BasicHubIssue}
import com.exalate.domain.script.{FileParams, HubAttachmentFileParams, Params}
import com.exalate.domain.transport.trackeroptions.EditorFields
import com.exalate.domain.transport.trackeroptions.EditorFields._
import com.exalate.replication.services.api.issuetracker.script.IExalateAPI

class MultiFileExalateAPI(attachmentHelper: IAttachmentHelper)
    extends IExalateAPI[java.util.List[BasicHubAttachment], FileParams] {

  /** makes a request to Issue Tracker to get an object by `value`, does not take the value from
    * context entity. Context Entity is used to get project / issue type / other context
    *
    * @example
    *   val issueType: BasicHubOption = ExalateAPI.getValueFromIssueTracker( fieldName =
    *   "ISSUE_TYPE", value = StringOptionParams("Task"), contextEntity = issue ) // makes a request
    *   to the issue tracker checking if there actually is an issue type "Task" for the given
    *   project (taken from `contextEntity`)
    * @example
    *   val status: BasicHubStatus = ExalateAPI.getValueFromIssueTracker(fieldName = "STATUS", value
    *   \= StringOptionParams("To Do"), contextEntity = issue)
    */
  override def getValueFromIssueTracker(
      fieldName: String,
      value: FileParams,
      contextEntity: IHubIssueReplica
  ): java.util.List[BasicHubAttachment] = value match {
    case HubAttachmentFileParams(as) => as
  }

  /** gets value for the field from the `entity`
    */
  override def getValueFromField(
      entity: IHubIssueReplica,
      fieldName: String
  ): java.util.List[BasicHubAttachment] =
    entity.getEntityName match {
      case "issue" =>
        val issue = entity.asInstanceOf[BasicHubIssue]
        EditorFields.withNameOpt(fieldName) match {
          case Some(ATTACHMENTS) =>
            issue.getAttachments
        }

    }

  override def setValueToField(
      entity: IHubIssueReplica,
      fieldName: String,
      value: FileParams
  ): IHubIssueReplica =
    entity.getEntityName match {
      case "issue" =>
        val issue = entity.asInstanceOf[BasicHubIssue]
        EditorFields.withNameOpt(fieldName) match {
          case Some(ATTACHMENTS) =>
            value match {
              case HubAttachmentFileParams(v) =>
                val replica = new BasicHubIssue()
                replica.setAttachments(v)
                issue.setAttachments(attachmentHelper.mergeAttachments(issue, replica))
                issue
            }
        }
    }

}
