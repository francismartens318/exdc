package com.exalate.replication.services.script

import java.text.SimpleDateFormat
import java.util.Date

import com.exalate.api.domain.hubobject.IHubIssueReplica
import com.exalate.basic.domain.hubobject.v1.BasicHubIssue
import com.exalate.domain.script._
import com.exalate.domain.transport.trackeroptions.EditorFields
import com.exalate.domain.transport.trackeroptions.EditorFields.DUE
import com.exalate.replication.services.api.issuetracker.script.IExalateAPI
import com.exalate.replication.services.api.replication.scope.ITrackerScopeAndMappingHelper

class DateExalateAPI extends IExalateAPI[Date, DateParams] {

  /** makes a request to Issue Tracker to get an object by `value`, does not take the value from
    * context entity. Context Entity is used to get project / issue type / other context
    *
    * @example
    *   val issueType: BasicHubOption = ExalateAPI.getValueFromIssueTracker( fieldName =
    *   "ISSUE_TYPE", value = StringOptionParams("Task"), contextEntity = issue ) // makes a request
    *   to the issue tracker checking if there actually is an issue type "Task" for the given
    *   project (taken from `contextEntity`)
    * @example
    *   val status: BasicHubStatus = ExalateAPI.getValueFromIssueTracker(fieldName = "STATUS", value
    *   \= StringOptionParams("To Do"), contextEntity = issue)
    */
  override def getValueFromIssueTracker(
      fieldName: String,
      value: DateParams,
      contextEntity: IHubIssueReplica
  ): Date = value match {
    case StringDateParams(vStr, format) =>
      val simpleDateFormat = new SimpleDateFormat(format)
      simpleDateFormat.parse(vStr)
    case DateDateParams(vDate)          => vDate
  }

  /** gets value for the field from the `entity`
    */
  override def getValueFromField(entity: IHubIssueReplica, fieldName: String): Date =
    entity.getEntityName match {
      case "issue" =>
        EditorFields.withNameOpt(fieldName) match {
          case Some(DUE) => Option(entity.asInstanceOf[BasicHubIssue].getDue).orNull
        }

    }

  override def setValueToField(
      entity: IHubIssueReplica,
      fieldName: String,
      value: DateParams
  ): IHubIssueReplica = {
    val issue = entity.asInstanceOf[BasicHubIssue]

    issue.getEntityName match {
      case "issue" =>
        value match {
          case StringDateParams(v, format) =>
            val simpleDateFormat = new SimpleDateFormat(format)
            issue.setDue(simpleDateFormat.parse(v))
            issue
          case DateDateParams(v)           =>
            issue.setDue(v)
            issue
        }
    }
  }

}
