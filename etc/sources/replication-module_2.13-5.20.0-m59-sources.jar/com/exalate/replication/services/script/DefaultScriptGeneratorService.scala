package com.exalate.replication.services.script

import com.exalate.domain.values.v4.{GenerateScriptRequestValue, SyncScriptsValue}
import com.exalate.replication.services.api.issuetracker.script.IIssueTrackerScriptGeneratorService
import com.google.inject.Inject

import scala.concurrent.{ExecutionContext, Future}

class DefaultScriptGeneratorService @Inject() ()(implicit ec: ExecutionContext)
    extends IIssueTrackerScriptGeneratorService {

  private val DEFAULT_DATA_FILTER: String =
    "replica.key            = issue.key\n" + "replica.assignee       = issue.assignee \n" + "replica.reporter       = issue.reporter\n" + "replica.summary        = issue.summary\n" + "replica.description    = issue.description\n" + "replica.comments       = issue.comments\n" + "replica.resolution     = issue.resolution\n" + "replica.status         = issue.status\n" + "replica.attachments    = issue.attachments\n" + "replica.project        = issue.project"

  private val DEFAULT_CREATE_PROCESSOR: String =
    "   //Set project key from source issue, if not found set a default\n" +
      "issue.projectKey   = nodeHelper.getProject(replica.project?.key)?.key ?: \"TEST\"\n" +
      "//Set type name from source issue, if not found set a default\n" +
      "issue.typeName     = nodeHelper.getIssueType(replica.type?.name, issue.projectKey)?.name ?: \"Task\"\n" +
      "issue.summary      = replica.summary\n" +
      "issue.description  = replica.description\n" +
      "issue.comments     = commentHelper.mergeComments(issue, replica)\n" +
      "issue.attachments  = attachmentHelper.mergeAttachments(issue, replica)";

  private val DEFAULT_CHANGE_PROCESSOR: String =
    "issue.summary          = replica.summary\n" + "issue.description  = replica.description\n" + "issue.comments     = commentHelper.mergeComments(issue, replica)\n" + "issue.attachments  = attachmentHelper.mergeAttachments(issue, replica)"

  private val DEFAULT_INCOMING_PROCESSOR: String = "if(firstSync){\n" +
    "   //Set project key from source issue, if not found set a default\n" +
    "   issue.projectKey   = nodeHelper.getProject(replica.project?.key)?.key ?: \"TEST\"\n" +
    "   //Set type name from source issue, if not found set a default\n" +
    "   issue.typeName     = nodeHelper.getIssueType(replica.type?.name, issue.projectKey)?.name ?: \"Task\"\n" +
    "}\n" +
    "issue.summary      = replica.summary\n" +
    "issue.description  = replica.description\n" +
    "issue.comments     = commentHelper.mergeComments(issue, replica)\n" +
    "issue.attachments  = attachmentHelper.mergeAttachments(issue, replica)";

  override def generateScriptRules(params: GenerateScriptRequestValue): Future[SyncScriptsValue] =
    Future.successful(
      SyncScriptsValue(
        DEFAULT_DATA_FILTER,
        DEFAULT_CREATE_PROCESSOR,
        DEFAULT_CHANGE_PROCESSOR,
        Some(DEFAULT_INCOMING_PROCESSOR),
        None
      )
    )

}
