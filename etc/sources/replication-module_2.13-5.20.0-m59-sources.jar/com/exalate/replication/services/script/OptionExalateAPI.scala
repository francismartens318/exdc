package com.exalate.replication.services.script

import com.exalate.api.domain.hubobject.IHubIssueReplica
import com.exalate.api.domain.hubobject.v1_6.IHubCustomField
import com.exalate.basic.domain.hubobject.v1.{BasicHubCustomField, BasicHubIssue, BasicHubOption}
import com.exalate.domain.script._
import com.exalate.domain.transport.trackeroptions.EditorFields
import com.exalate.domain.transport.trackeroptions.EditorFields.{
  ISSUE_TYPE,
  PRIORITY,
  PROJECT,
  STATUS
}
import com.exalate.replication.services.api.issuetracker.script.IExalateAPI
import com.exalate.replication.services.api.replication.scope.ITrackerScopeAndMappingHelper
import com.exalate.services.utils.FutureUtils

import scala.jdk.CollectionConverters._
import scala.util.{Failure, Success, Try}

class OptionExalateAPI(trackerScopeAndMappingHelper: ITrackerScopeAndMappingHelper)
    extends IExalateAPI[BasicHubOption, OptionParams] {

  /** makes a request to Issue Tracker to get an object by `value`, does not take the value from
    * context entity. Context Entity is used to get project / issue type / other context
    *
    * @example
    *   val issueType: BasicHubOption = ExalateAPI.getValueFromIssueTracker( fieldName =
    *   "ISSUE_TYPE", value = StringOptionParams("Task"), contextEntity = issue ) // makes a request
    *   to the issue tracker checking if there actually is an issue type "Task" for the given
    *   project (taken from `contextEntity`)
    * @example
    *   val status: BasicHubStatus = ExalateAPI.getValueFromIssueTracker(fieldName = "STATUS", value
    *   \= StringOptionParams("To Do"), contextEntity = issue)
    */

  override def getValueFromIssueTracker(
      fieldName: String,
      value: OptionParams,
      contextEntity: IHubIssueReplica
  ): BasicHubOption =
    contextEntity.getEntityName match {
      case "issue" =>
        val issue = contextEntity.asInstanceOf[BasicHubIssue]
        val projectId = Option(issue.getProject).flatMap(p => Option(p.getIdStr))
        val issueTypeId = Option(issue.getType).flatMap(p => Option(p.getId))
        value match {
          case HubOptionOptionParams(v) =>
            EditorFields.withNameOpt(fieldName) match {
              case Some(ISSUE_TYPE) =>
                FutureUtils
                  .resultInf(trackerScopeAndMappingHelper.getIssueType(v.getValue, projectId))
                  .map { issueType =>
                    val basicHubOption = new BasicHubOption
                    basicHubOption.setId(issueType.getId)
                    basicHubOption.setValue(issueType.getName)
                    basicHubOption
                  }
                  .orNull
              case Some(STATUS)     =>
                FutureUtils
                  .resultInf(
                    trackerScopeAndMappingHelper.getStatus(v.getValue, projectId, issueTypeId)
                  )
                  .map { status =>
                    val basicHubOption = new BasicHubOption
                    basicHubOption.setId(status.getId)
                    basicHubOption.setValue(status.getName)
                    basicHubOption
                  }
                  .orNull
              case Some(PRIORITY)   =>
                FutureUtils
                  .resultInf(trackerScopeAndMappingHelper.getPriority(v.getValue, projectId))
                  .map { priority =>
                    val basicHubOption = new BasicHubOption
                    basicHubOption.setId(priority.getId)
                    basicHubOption.setValue(priority.getName)
                    basicHubOption
                  }
                  .orNull
              case _                =>
                FutureUtils
                  .resultInf(
                    trackerScopeAndMappingHelper
                      .getCfOption(Some(fieldName), fieldName, v.getValue, contextEntity)
                  )
                  .orNull
            }
          case StringOptionParams(v)    =>
            EditorFields.withNameOpt(fieldName) match {
              case Some(ISSUE_TYPE) =>
                FutureUtils
                  .resultInf(trackerScopeAndMappingHelper.getIssueType(v, projectId))
                  .map { issueType =>
                    val basicHubOption = new BasicHubOption
                    basicHubOption.setId(issueType.getId)
                    basicHubOption.setValue(issueType.getName)
                    basicHubOption
                  }
                  .orNull
              case Some(STATUS)     =>
                FutureUtils
                  .resultInf(trackerScopeAndMappingHelper.getStatus(v, projectId, issueTypeId))
                  .map { status =>
                    val basicHubOption = new BasicHubOption
                    basicHubOption.setId(status.getId)
                    basicHubOption.setValue(status.getName)
                    basicHubOption
                  }
                  .orNull
              case Some(PRIORITY)   =>
                FutureUtils
                  .resultInf(trackerScopeAndMappingHelper.getPriority(v, projectId))
                  .map { priority =>
                    val basicHubOption = new BasicHubOption
                    basicHubOption.setId(priority.getId)
                    basicHubOption.setValue(priority.getName)
                    basicHubOption
                  }
                  .orNull
              case _                =>
                FutureUtils
                  .resultInf(
                    trackerScopeAndMappingHelper
                      .getCfOption(Some(fieldName), fieldName, v, contextEntity)
                  )
                  .orNull
            }
        }
    }

  override def getValueFromField(entity: IHubIssueReplica, fieldName: String): BasicHubOption = {
    val basicHubOption = new BasicHubOption()
    entity.getEntityName match {
      case "issue" =>
        val issue = entity.asInstanceOf[BasicHubIssue]
        EditorFields.withNameOpt(fieldName) match {
          case Some(PROJECT)    =>
            Option(entity.asInstanceOf[BasicHubIssue].getProject).map { s =>
              val projectKey = getProjectKeyFromReplica(issue)
              projectKey.map(pk => basicHubOption.setValue(pk))
              basicHubOption.setId(s.getId)

              basicHubOption
            }.orNull
          case Some(ISSUE_TYPE) =>
            Option(entity.asInstanceOf[BasicHubIssue].getType) match {
              case Some(issueType) =>
                basicHubOption.setValue(issueType.getName)
                basicHubOption.setId(issueType.getId)

                basicHubOption
              case None            =>
                Option(entity.asInstanceOf[BasicHubIssue].getTypeName)
                  .filter(_.trim.nonEmpty)
                  .map { s =>
                    basicHubOption.setValue(s)
                    basicHubOption
                  }
                  .orNull
            }
          case Some(STATUS)     =>
            Option(entity.asInstanceOf[BasicHubIssue].getStatus).map { s =>
              basicHubOption.setValue(s.getName)
              basicHubOption.setId(s.getId)

              basicHubOption
            }.orNull
          case Some(PRIORITY)   =>
            Option(entity.asInstanceOf[BasicHubIssue].getPriority).map { p =>
              basicHubOption.setValue(p.getName)
              basicHubOption.setId(p.getId)

              basicHubOption
            }.orNull
          case _                =>
            getCustomFieldByKey(entity.asInstanceOf[BasicHubIssue], fieldName)
              .flatMap(cf => Option(cf.getValue))
              .map { value =>
                Try(value.asInstanceOf[BasicHubOption]) match {
                  case Success(hubOption) =>
                    basicHubOption.setValue(hubOption.getValue)
                    basicHubOption.setId(hubOption.getId)

                    basicHubOption
                  case Failure(exception) =>
                    basicHubOption.setValue(value.asInstanceOf[String])

                    basicHubOption
                }
              }
              .orNull
        }
    }

  }

  override def setValueToField(
      entity: IHubIssueReplica,
      fieldName: String,
      value: OptionParams
  ): IHubIssueReplica =
    entity.getEntityName match {
      case "issue" =>
        val issue = entity.asInstanceOf[BasicHubIssue]
        val projectId = Option(issue.getProject).flatMap(p => Option(p.getIdStr))
        value match {
          case HubOptionOptionParams(v) =>
            EditorFields.withNameOpt(fieldName) match {
              case Some(PROJECT)    =>
                val projectOpt =
                  FutureUtils.resultInf(trackerScopeAndMappingHelper.getProject(v.getValue))
                projectOpt.map(p => issue.setProject(p))
                issue
              case Some(ISSUE_TYPE) =>
                val issueTypeOpt = FutureUtils.resultInf(
                  trackerScopeAndMappingHelper.getIssueType(v.getValue, projectId)
                )
                issueTypeOpt.map(issueType => issue.setIssueType(issueType))
                issue
              case Some(STATUS)     =>
                issue.setStatus(v.getValue)
                issue
              case Some(PRIORITY)   =>
                val priorityOpt = FutureUtils.resultInf(
                  trackerScopeAndMappingHelper.getPriority(v.getValue, projectId)
                )
                priorityOpt.map(priority => issue.setPriority(priority))
                issue
              case _                =>
                getCustomFieldByKey(issue, fieldName)
                  .orElse(Option(issue.getCustomFields.get(fieldName))) match {
                  case Some(icf) =>
                    val cf = icf.asInstanceOf[BasicHubCustomField]
                    cf.setValue(v.getValue)
                    issue
                }
            }
          case StringOptionParams(v)    =>
            EditorFields.withNameOpt(fieldName) match {
              case Some(PROJECT)    =>
                val projectOpt = FutureUtils.resultInf(trackerScopeAndMappingHelper.getProject(v))
                projectOpt.map(p => issue.setProject(p))
                issue
              case Some(ISSUE_TYPE) =>
                val issueTypeOpt =
                  FutureUtils.resultInf(trackerScopeAndMappingHelper.getIssueType(v, projectId))
                issueTypeOpt.map(issueType => issue.setIssueType(issueType))
                issue
              case Some(STATUS)     =>
                issue.setStatus(v)
                issue
              case Some(PRIORITY)   =>
                val priorityOpt =
                  FutureUtils.resultInf(trackerScopeAndMappingHelper.getPriority(v, projectId))
                priorityOpt.map(priority => issue.setPriority(priority))
                issue
              case _                =>
                getCustomFieldByKey(issue, fieldName)
                  .orElse(Option(issue.getCustomFields.get(fieldName))) match {
                  case Some(icf) =>
                    val cf = icf.asInstanceOf[BasicHubCustomField]
                    cf.setValue(v)
                    issue
                }
            }
          case UserOptionParams(v)      =>
            val user = trackerScopeAndMappingHelper.getUserAsString(v)
            getCustomFieldByKey(issue, fieldName)
              .orElse(Option(issue.getCustomFields.get(fieldName))) match {
              case Some(icf) =>
                val cf = icf.asInstanceOf[BasicHubCustomField]
                cf.setValue(user)
            }
            issue
        }
    }

  private def getCustomFieldByKey(issue: BasicHubIssue, key: String): Option[IHubCustomField] = {
    val customFieldOpt = issue.getCustomFields.asScala.values
      .find(cf => cf != null && cf.asInstanceOf[IHubCustomField].getUid == key)

    customFieldOpt.map(_.asInstanceOf[IHubCustomField])
  }

  private def getProjectKeyFromReplica(replica: BasicHubIssue): Option[String] =
    Option(replica.getProject).map(_.getKey) match {
      case Some(projectKey) => Some(projectKey)
      case None             =>
        Option(replica.getProjectKey).flatMap(s => if (s.trim.isEmpty) None else Some(s))
    }

}
