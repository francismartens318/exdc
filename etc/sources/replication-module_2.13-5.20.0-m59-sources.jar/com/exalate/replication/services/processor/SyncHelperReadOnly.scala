package com.exalate.replication.services.processor

import com.exalate.api.domain.IIssueKey

class SyncHelperReadOnly(
    syncHelper: SyncHelper
) {

  /** Exalates issue
    * @param issueKey
    */
  def exalate(issueKey: IIssueKey) = ()

  /** Unexalates issue
    * @param issueKey
    */
  def unexalate(issueKey: IIssueKey) = ()

  /** Check if issue is under sync
    * @param key
    *   issue key
    * @return
    *   true or false
    */
  def isUnderSync(key: IIssueKey): Boolean = syncHelper.isUnderSync(key)

  /** Check if entity is under sync
    * @param entityId
    *   issue (or other entity) id
    * @param entityType
    *   type of entity (issue, sprint etc)
    * @return
    *   true or false
    */
  def isUnderSync(entityId: String, entityType: String): Boolean =
    syncHelper.isUnderSync(entityId, entityType)

  /** Check if entity is under sync
    * @param entityId
    *   issue (or other entity) id
    * @param entityType
    *   type of entity (issue, sprint etc)
    * @param connection
    * @return
    *   true or false
    */
  def isUnderSync(entityId: String, entityType: String, connection: String): Boolean =
    syncHelper.isUnderSync(entityId, entityType, connection)

  /** Check if issue is under sync
    * @param issueId
    *   issue id as string
    * @return
    *   true or false
    */
  def isIssueUnderSync(issueId: String): Boolean = syncHelper.isIssueUnderSync(issueId)

  /** Check if issue is under sync
    * @param issueId
    *   issue is as Long
    * @return
    *   true or false
    */
  def isIssueUnderSync(issueId: Long): Boolean =
    syncHelper.isIssueUnderSync(issueId)

  /** Gets a local key from twintrace repo by provided remote id
    * @param remoteEntityId
    * @param entityType
    * @return
    *   local issue key
    */
  def getLocalKeyFromRemoteId(remoteEntityId: String, entityType: String): IIssueKey =
    syncHelper.getLocalKeyFromRemoteId(remoteEntityId, entityType)

  /** Gets a local key from twintrace repo by provided remote id
    * @param remoteIssueId
    * @return
    */
  def getLocalIssueKeyFromRemoteId(remoteIssueId: String): IIssueKey =
    syncHelper.getLocalIssueKeyFromRemoteId(remoteIssueId)

  /** Gets a local key from twintrace repo by provided remote id
    */
  def getLocalIssueKeyFromRemoteId(remoteIssueId: Long): IIssueKey =
    syncHelper.getLocalIssueKeyFromRemoteId(remoteIssueId)

  /** Gets a local key from twintrace repo by provided remote id
    * @param remoteIssueId
    * @param entityType
    * @return
    */
  def getLocalIssueKeyFromRemoteId(remoteIssueId: String, entityType: String): IIssueKey =
    syncHelper.getLocalIssueKeyFromRemoteId(remoteIssueId, entityType)

  def getLocalIssueKeyFromRemoteId(remoteIssueId: Long, entityType: String): IIssueKey =
    syncHelper.getLocalIssueKeyFromRemoteId(remoteIssueId, entityType)

  def syncBackAfterProcessing() = ()

  def unExalateAfterProcessing() = ()

  def toMarkDownFromHtml(html: String) = syncHelper.toMarkDownFromHtml(html)

  def toHtmlFromMarkdown(commonMarkStr: String) = syncHelper.toHtmlFromMarkdown(commonMarkStr)

  def stripHtml(htmlText: String): String = syncHelper.stripHtml(htmlText)

  def getTrackerUrl(): String = syncHelper.getTrackerUrl()

  def getRemoteTrackerUrl(): String = syncHelper.getRemoteTrackerUrl()

  def getExalateUrl(): String = syncHelper.getExalateUrl()

  def getRemoteExalateUrl(): String = syncHelper.getRemoteExalateUrl()

  def getRemoteIssueUrl(entityId: String, entityType: String): String =
    syncHelper.getRemoteIssueUrl(entityId, entityType)

  def getRemoteIssueUrl(localEntityKey: IIssueKey): String =
    syncHelper.getRemoteIssueUrl(localEntityKey)

}
