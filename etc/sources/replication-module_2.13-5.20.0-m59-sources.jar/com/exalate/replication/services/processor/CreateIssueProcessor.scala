package com.exalate.replication.services.processor

import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.hubobject.IHubIssueReplica
import com.exalate.api.domain.request.ISyncRequest
import com.exalate.api.domain.twintrace.INonPersistentTrace
import com.exalate.api.domain.{IBlobMetadata, IIssueKey, INonPersistentReplica}
import com.exalate.api.exception.bug.BugException
import com.exalate.api.exception.script.{ScriptException, ScriptProcessors}
import com.exalate.api.hubobject.jira.INodeHelper
import com.exalate.api.hubobject.v1.IHubIssueProcessorPreparationService
import com.exalate.api.processor.IExalateProcessor
import com.exalate.basic.domain.hubobject.v1.BasicHubIssue
import com.exalate.generic.services.api.ITrackerHubObjectService
import com.exalate.replication.services.api.error.NotEnoughDataToCreateIssueProcessorException
import com.exalate.replication.services.api.issuetracker.ITriggerWhiteListTrackerService
import com.exalate.replication.services.api.processor.{
  IApplyScriptResultService,
  ICreateIssueProcessor,
  IScriptVariableServiceFactory,
  IStoreClosureFactory
}
import com.exalate.replication.services.api.replication.mapping.IMappingService
import com.exalate.replication.services.api.replication.scope.IScopeService
import com.exalate.replication.services.api.trigger.ITriggerService
import com.exalate.replication.services.utils.ScriptProcessorExceptionHandling
import com.exalate.services.utils.CollectionService.mapToSeq
import org.apache.commons.lang3.StringUtils
import org.slf4j
import org.slf4j.LoggerFactory

import java.util
import javax.inject.Inject
import scala.concurrent.{ExecutionContext, Future}
import scala.util.Try

class CreateIssueProcessor @Inject() (
    processor: IExalateProcessor,
    scriptVariableServiceFactory: IScriptVariableServiceFactory,
    storeClosureFactory: IStoreClosureFactory,
    hubObjectService: ITrackerHubObjectService,
    applyScriptResultService: IApplyScriptResultService,
    triggerWhiteListTrackerService: ITriggerWhiteListTrackerService,
    triggerService: ITriggerService,
    preparationService: IHubIssueProcessorPreparationService,
    scopeService: IScopeService,
    mappingService: IMappingService
)(implicit ec: ExecutionContext)
    extends ICreateIssueProcessor {

  import CreateIssueProcessor.LOG

  /** Create issue process
    * @param connection
    * @param syncRequest
    * @param receivedReplica
    * @param blobMetadataSeq
    * @return
    */
  def createIssue(
      connection: IConnection,
      syncRequest: ISyncRequest,
      receivedReplica: INonPersistentReplica,
      blobMetadataSeq: Seq[IBlobMetadata]
  ): Future[(IIssueKey, Seq[INonPersistentTrace])] = {
    val scriptVariableService = scriptVariableServiceFactory.getScriptVariableService()
    val receivedHubIssue = receivedReplica.getPayload.getHubIssue
    val replica = preparationService.prepareRemoteHubIssue(
      receivedHubIssue.asInstanceOf[BasicHubIssue],
      util.Collections.emptyMap()
    )

    scriptVariableService
      .createIncomingSyncContext(
        replica.asInstanceOf[BasicHubIssue],
        firstSync = true,
        connection,
        syncRequest,
        None,
        Option(receivedReplica.getPayload.getIssueUrl),
        None,
        blobMetadataSeq,
        Seq.empty[INonPersistentTrace],
        LOG
      )
      .flatMap { incomingSyncContext =>
        val context: util.HashMap[String, Object] = new util.HashMap(incomingSyncContext)
        val storeClosure = storeClosureFactory.create()
        context.put("store", storeClosure)
        val _traces = Try(context.get("traces").asInstanceOf[util.ArrayList[INonPersistentTrace]])
          .getOrElse(new util.ArrayList[INonPersistentTrace]())
        val entitiesBeforeUpdating =
          context.get("entitiesBeforeUpdating").asInstanceOf[Seq[IHubIssueReplica]]
        val entities = context.get("entities").asInstanceOf[Seq[IHubIssueReplica]]

        if (Option(connection.getMode).isDefined && connection.isVisual)
          executeVisualRules(
            RuleExecutionParams(
              connection,
              blobMetadataSeq,
              entitiesBeforeUpdating,
              entities,
              replica,
              context,
              _traces,
              syncRequest
            )
          )
        else
          executeScriptRules(
            RuleExecutionParams(
              connection,
              blobMetadataSeq,
              entitiesBeforeUpdating,
              entities,
              replica,
              context,
              _traces,
              syncRequest
            )
          )
      }

  }

  private case class RuleExecutionParams(
      connection: IConnection,
      blobMetadataSeq: Seq[IBlobMetadata],
      entitiesBeforeUpdating: Seq[IHubIssueReplica],
      entities: Seq[IHubIssueReplica],
      replica: IHubIssueReplica,
      context: util.HashMap[String, Object],
      traces: util.ArrayList[INonPersistentTrace],
      syncRequest: ISyncRequest
  )

  /** Executes Visual Rules, namely apply scopes and mapping rules
    * @param ruleExecutionParams
    * @return
    */
  private def executeVisualRules(
      ruleExecutionParams: RuleExecutionParams
  ): Future[(IIssueKey, Seq[INonPersistentTrace])] = ruleExecutionParams match {
    case RuleExecutionParams(
          connection: IConnection,
          blobMetadataSeq: Seq[IBlobMetadata],
          entitiesBeforeUpdating: Seq[IHubIssueReplica],
          entities: Seq[IHubIssueReplica],
          replica: IHubIssueReplica,
          context: util.HashMap[String, Object],
          traces: util.ArrayList[INonPersistentTrace],
          syncRequest
        ) =>
      LOG.debug(s"Executing visual rules for connection ${connection.getName} on create state")
      val issueBeforeUpdating =
        entitiesBeforeUpdating.find(_.getEntityName == "issue").get.asInstanceOf[BasicHubIssue]
      val issue = entities.find(_.getEntityName == "issue").get.asInstanceOf[BasicHubIssue]
      for {
        issueInitiallyFilledFromScope <- scopeService.receive(
          replica,
          issue.asInstanceOf[BasicHubIssue],
          connection.getID,
          syncRequest
        )
        issueFilledFromVisualRules <- mappingService.receive(
          VisualRuleExecutionParams(
            connection,
            traces,
            issueInitiallyFilledFromScope,
            issueBeforeUpdating.asInstanceOf[BasicHubIssue],
            replica.asInstanceOf[BasicHubIssue],
            blobMetadataSeq,
            context,
            syncRequest
          )
        )
        result <- applyScriptResultService.createEntity(
          syncRequest,
          blobMetadataSeq,
          entitiesBeforeUpdating
            .find(_.getEntityName == issueFilledFromVisualRules.getEntityName)
            .get,
          issueFilledFromVisualRules
        )
      } yield result
  }

  /** Gets script processor: whether `CREATE` or `INCOMING`
    * @param connection
    * @return
    */
  private def getScriptProcessor(connection: IConnection): ScriptProcessors =
    if (connection.getVersion == "1") ScriptProcessors.CREATE else ScriptProcessors.INCOMING

  /** Executes script rules when visual editor is not supported
    * @param ruleExecutionParams
    * @return
    */
  private def executeScriptRules(ruleExecutionParams: RuleExecutionParams) =
    ruleExecutionParams match {
      case RuleExecutionParams(
            connection: IConnection,
            blobMetadataSeq: Seq[IBlobMetadata],
            entitiesBeforeUpdating: Seq[IHubIssueReplica],
            entities: Seq[IHubIssueReplica],
            replica: IHubIssueReplica,
            context: util.HashMap[String, Object],
            traces: util.ArrayList[INonPersistentTrace],
            syncRequest
          ) =>
        val f = Future
          .fromTry(
            Try {
              CreateIssueProcessor.threadLocalContext.set(context)
              LOG.debug(
                s"Executing incoming script for connection ${connection.getName} on create state"
              )
              val result = processor.executeProcessor(
                ConnectionScriptHelper.getCreateProcessorScript(connection),
                context,
                getScriptProcessor(connection)
              )
              LOG.debug(s"Incoming script executed")
              result
            }
              .recoverWith {
                case e: ScriptException =>
                  ScriptProcessorExceptionHandling.handleException(e)
              }
          )
          // uni-directional scenario support: (issueBeforeUpdating == issue) => we are not creating an issue, we send a response without a replica
          .flatMap {
            case a @ (_: IIssueKey, _: Seq[INonPersistentTrace]) => Future.successful(a)
            case _                                               =>
              val _entitiesBeforeUpdating =
                context.get("entitiesBeforeUpdating").asInstanceOf[Seq[IHubIssueReplica]]
              val _entities = context.get("entities").asInstanceOf[Seq[IHubIssueReplica]]
              Future
                .fromTry(
                  applyScriptResultService.getModifiedEntity(_entitiesBeforeUpdating, _entities)
                )
                .flatMap {
                  case None    =>
                    LOG.debug(s"The issue hub object has not been filled, can not create an issue!")
                    Future.failed(
                      new NotEnoughDataToCreateIssueProcessorException(
                        "The issue hub object has not been filled, can not create an issue!"
                      )
                    )
                  case Some(a) => Future.successful(a)
                }
          }
          .flatMap { r =>
            val _entitiesBeforeUpdating =
              context.get("entitiesBeforeUpdating").asInstanceOf[Seq[IHubIssueReplica]]
            val _traces = Try(
              context.get("traces").asInstanceOf[util.ArrayList[INonPersistentTrace]]
            ).getOrElse(new util.ArrayList[INonPersistentTrace]())

            val customHttpHeaders: Seq[(String, String)] =
              mapToSeq(context.get("nodeHelper").asInstanceOf[INodeHelper].getHTTPHeaders)

            CreateIssueProcessor.threadLocalContext.set(context)
            val result: Future[(IIssueKey, Seq[INonPersistentTrace], Option[IHubIssueReplica])] =
              r match {

                case (issueKey: IIssueKey, tracesSeq: Seq[INonPersistentTrace]) =>
                  Future.successful(issueKey, tracesSeq, None)

                case entity: IHubIssueReplica if !StringUtils.isEmpty(entity.getId) =>
                  val entityBeforeUpdating =
                    _entitiesBeforeUpdating.find(_.getEntityName == entity.getEntityName).get
                  val issueKeyOpt = Option(context.get("issueKey"))
                    .map(_.asInstanceOf[IIssueKey])
                  val issueKeyOptFuture = issueKeyOpt match {
                    case None          =>
                      hubObjectService.getLocalKeyById(
                        entity.getId,
                        connection,
                        entity.getEntityName
                      )
                    case opt @ Some(_) =>
                      Future.successful(opt)
                  }
                  issueKeyOptFuture.flatMap {
                    case Some(localIssueKey) =>
                      LOG.debug(
                        s"Updating ${localIssueKey.getEntityType} ${localIssueKey.getURN} (${localIssueKey.getIdStr})"
                      )
                      applyScriptResultService
                        .updateEntity(
                          syncRequest,
                          context,
                          localIssueKey,
                          _traces,
                          entity,
                          entityBeforeUpdating,
                          blobMetadataSeq,
                          customHttpHeaders
                        )
                        .map(updatedTraces => (localIssueKey, updatedTraces, Option(entity)))

                    case None =>
                      applyScriptResultService
                        .createEntity(
                          syncRequest,
                          blobMetadataSeq,
                          entityBeforeUpdating,
                          entity,
                          customHttpHeaders
                        )
                        .map(a => (a._1, a._2, Option(entity)))
                  }

                case newEntity: IHubIssueReplica =>
                  val entityBeforeUpdating =
                    _entitiesBeforeUpdating.find(_.getEntityName == newEntity.getEntityName).get
                  LOG.debug(s"Updating ${newEntity.getEntityName} ${newEntity.getId}")
                  applyScriptResultService
                    .createEntity(
                      syncRequest,
                      blobMetadataSeq,
                      entityBeforeUpdating,
                      newEntity,
                      customHttpHeaders
                    )
                    .map(a => (a._1, a._2, Option(newEntity)))
                case a                           =>
                  LOG.error(s"Unexpected result from create processor: $a")
                  Future.failed(
                    new BugException(
                      s"Could create the issue due to a unexpected status after executing incoming script. Result: $a"
                    )
                  )
              }
            CreateIssueProcessor.threadLocalContext.remove()
            result

          }
        CreateIssueProcessor.threadLocalContext.remove()

        f.foreach {
          case (issueKey, _, entityOpt) =>
            val projectKeyOpt = entityOpt.flatMap(entity =>
              triggerWhiteListTrackerService.extractProject(connection, entity)
            )
            triggerService.executeTriggers(issueKey, projectKeyOpt, Some(connection))
        }
        f.map(a => (a._1, a._2))
    }

}

object CreateIssueProcessor {
  /*
  Allows you to get context from the scripts with:
   com.exalate.replication.services.processor.CreateIssueProcessor.MODULE$.threadLocalContext.get().commentHelper
   */
  val threadLocalContext = new ThreadLocal[util.HashMap[String, Object]]
  val LOG: slf4j.Logger = LoggerFactory.getLogger(classOf[CreateIssueProcessor])
}
