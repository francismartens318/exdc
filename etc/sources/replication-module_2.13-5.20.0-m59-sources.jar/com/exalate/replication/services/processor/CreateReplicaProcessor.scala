package com.exalate.replication.services.processor

import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.hubobject.{IHubIssueReplica, IHubPayload}
import com.exalate.api.domain.request.ISyncRequest
import com.exalate.api.domain.{IIssueKey, INonPersistentReplica}
import com.exalate.api.exception.script.{ScriptException, ScriptProcessors}
import com.exalate.api.hubobject.IHubObjectValidator
import com.exalate.api.processor.IExalateProcessor
import com.exalate.basic.domain.BasicHubPayload
import com.exalate.basic.domain.hubobject.v1.BasicHubIssue
import com.exalate.basic.domain.util.SemanticVersionService
import com.exalate.generic.services.api.ITrackerHubObjectService
import com.exalate.replication.services.api.hubobject.IReplicaHelper
import com.exalate.replication.services.api.node.ISelfNodeInfoService
import com.exalate.replication.services.api.processor.{
  ICreateReplicaProcessor,
  IScriptVariableServiceFactory
}
import com.exalate.replication.services.api.replication.mapping.IMappingService
import com.exalate.replication.services.utils.ScriptProcessorExceptionHandling
import org.slf4j
import org.slf4j.LoggerFactory

import java.util
import javax.inject.Inject
import scala.concurrent.{ExecutionContext, Future}
import scala.util.Try

class CreateReplicaProcessor @Inject() (
    processor: IExalateProcessor,
    replicaHelper: IReplicaHelper,
    hubObjectValidator: IHubObjectValidator,
    trackerHubObjectService: ITrackerHubObjectService,
    syncHelperFactory: SyncHelperFactory,
    selfNodeInfoService: ISelfNodeInfoService,
    mappingService: IMappingService,
    scriptVariableServiceFactory: IScriptVariableServiceFactory
)(implicit ec: ExecutionContext)
    extends ICreateReplicaProcessor {
  import CreateReplicaProcessor.LOG

  /** Create replica process (Outgoing info proces)
    * @param connection
    * @param hp
    *   hub payload
    * @param localIssueKey
    * @param syncRequestOpt
    * @return
    */
  def createHubReplica(
      connection: IConnection,
      hp: IHubPayload,
      localIssueKey: IIssueKey,
      syncRequestOpt: Option[ISyncRequest]
  ): Future[INonPersistentReplica] = {
    val scriptVariableService = scriptVariableServiceFactory.getScriptVariableService()
    val issue = hp.getHubIssue
    val replica = new BasicHubIssue()
    val f = Future
      .fromTry(
        Try(
          scriptVariableService.createOutgoingSyncContext(
            connection,
            issue,
            replica,
            localIssueKey,
            syncRequestOpt,
            LOG
          )
        )
      )
      .flatMap(context =>
        if (Option(connection.getMode).isDefined && connection.isVisual)
          executeVisualRules(
            OutRuleExecutionParams(localIssueKey, connection, issue, replica, context)
          )
        else
          executeScriptRules(
            OutRuleExecutionParams(localIssueKey, connection, issue, replica, context)
          )
      )
      .flatMap { context =>
        CreateReplicaProcessor.threadLocalContext.set(context)
        val replicaAfterScripts = context.get("replica").asInstanceOf[BasicHubIssue]
        hubObjectValidator.validateIssueReplica(replicaAfterScripts)
        val hubObjectVersion = SemanticVersionService.get(selfNodeInfoService.getMaxHubObjectVersion)
        val result =
          trackerHubObjectService.getEntityUrl(localIssueKey, connection).map { issueUrl =>
            CreateReplicaProcessor.threadLocalContext.set(context)
            val res = replicaHelper.createNonPersistentReplica(
              localIssueKey,
              Option(replicaAfterScripts.getSummary),
              new BasicHubPayload(hubObjectVersion, replicaAfterScripts, issueUrl.orNull)
            )
            CreateReplicaProcessor.threadLocalContext.remove()
            res
          }
        CreateReplicaProcessor.threadLocalContext.remove()
        result
      }
    f
  }

  /** Executes Visual Rules, namely apply scopes and mapping rules
    * @param ruleExecutionParams
    * @return
    */
  private def executeVisualRules(ruleExecutionParams: OutRuleExecutionParams) =
    ruleExecutionParams match {
      case OutRuleExecutionParams(
            localIssueKey: IIssueKey,
            connection: IConnection,
            issue: IHubIssueReplica,
            replica: IHubIssueReplica,
            context: util.HashMap[String, Object]
          ) =>
        mappingService
          .send(ruleExecutionParams: OutRuleExecutionParams)
          .map { r =>
            context.put("replica", r)
            context
          }
    }

  /** Executes script rules when visual editor is not supported
    * @param ruleExecutionParams
    * @return
    */
  private def executeScriptRules(ruleExecutionParams: OutRuleExecutionParams) =
    ruleExecutionParams match {
      case OutRuleExecutionParams(
            localIssueKey: IIssueKey,
            connection: IConnection,
            issue: IHubIssueReplica,
            replica: IHubIssueReplica,
            context: util.HashMap[String, Object]
          ) =>
        LOG.debug(
          s"Ready to run outgoing script for entity $localIssueKey and connection ${connection.getName}"
        )
        Future.fromTry(
          Try {
            CreateReplicaProcessor.threadLocalContext.set(context)
            processor.executeProcessor(connection.getDataFilter, context, ScriptProcessors.OUTGOING)
            CreateReplicaProcessor.threadLocalContext.remove()
            LOG.debug(
              s"Outgoing script for entity $localIssueKey and connection ${connection.getName} was executed successfully"
            )
            context
          }
            .recoverWith {
              case e: ScriptException =>
                ScriptProcessorExceptionHandling.handleException(e)
            }
        )
    }

  override def createHubReplicaForDeletedIssue(
      issueKey: IIssueKey,
      connectionId: Int
  ): INonPersistentReplica = {
    LOG.debug(
      s"Creating hub replica for deleted entity $issueKey and connection with ID $connectionId"
    )
    val hubObjectVersion = SemanticVersionService.get(selfNodeInfoService.getMaxHubObjectVersion)
    replicaHelper.createNonPersistentReplica(
      issueKey,
      None,
      new BasicHubPayload(hubObjectVersion, new BasicHubIssue)
    )
  }

}

object CreateReplicaProcessor {
  /*
  Allows you to get context from the scripts with:
   com.exalate.replication.services.processor.CreateReplicaProcessor.MODULE$.threadLocalContext.get().commentHelper
   */
  val threadLocalContext = new ThreadLocal[util.HashMap[String, Object]]

  val LOG: slf4j.Logger =
    LoggerFactory.getLogger("application.services.processor.CreateReplicaProcessor")

}
