package com.exalate.replication.services.processor

import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.hubobject.IHubIssueReplica
import com.exalate.api.domain.request.ISyncRequest
import com.exalate.api.domain.twintrace.INonPersistentTrace
import com.exalate.api.domain.{IBlobMetadata, IIssueKey}
import com.exalate.api.exception.bug.BugException
import com.exalate.basic.domain.connection.Connection
import com.exalate.basic.domain.hubobject.v1.BasicHubIssue
import com.exalate.generic.services.api.{ITrackerContextServiceReadOnly, ITrackerHubObjectService}
import com.exalate.hubobject.jira.DebugHelper
import com.exalate.replication.services.api.issuetracker.IIssueTrackerHttpClientFactory
import com.exalate.replication.services.api.processor.{IScriptVariableService, ISyncHelperFactory}

import java.{lang, util}
import javax.inject.Inject
import scala.concurrent.{ExecutionContext, Future}
import scala.jdk.CollectionConverters._

/** Service which forms variables for script execution in Exalate. The context generated here has
  * read only property. It means that during the script execution it will have not affect on the
  * instance itself (etc, no data creation, no data update on the instance)
  */
class ScriptVariableReadOnlyService @Inject() (
    trackerReadOnlyContextService: ITrackerContextServiceReadOnly,
    trackerHubObjectService: ITrackerHubObjectService,
    syncHelperFactory: ISyncHelperFactory,
    issueTrackerHttpClientFactory: IIssueTrackerHttpClientFactory
)(implicit val executionContext: ExecutionContext)
    extends IScriptVariableService {

  override def createOutgoingSyncContext(
      connection: IConnection,
      issue: IHubIssueReplica,
      replica: BasicHubIssue,
      localIssueKey: IIssueKey,
      syncRequestOpt: Option[ISyncRequest],
      log: org.slf4j.Logger,
      isAIScript: Boolean = false
  ): util.HashMap[String, Object] = {
    val connectionWithoutSecret = new Connection(connection, true)
    val context = trackerReadOnlyContextService
      .getDataFilterContextReadOnly(
        connectionWithoutSecret,
        localIssueKey,
        issue,
        replica,
        isAIScript
      )
    context.put(localIssueKey.getEntityType, issue)
    context.put("entity", issue)
    context.put("issueKey", localIssueKey)
    context.put("replica", replica)
    context.put("connection", connectionWithoutSecret)
    context.put("relation", connectionWithoutSecret)
    context.put("syncRequest", syncRequestOpt.orNull)

    context.put("groovyHttpClient", issueTrackerHttpClientFactory.getGroovyHttpClientReadOnly())
    val httpClientReadOnly =
      if (!isAIScript) issueTrackerHttpClientFactory.getHttpClientReadOnly()
      else issueTrackerHttpClientFactory.getHttpClientAIReadOnly()
    context.putIfAbsent("httpClient", httpClientReadOnly)
    context.put("log", log)
    context.put(
      "syncHelper",
      syncHelperFactory.getSyncHelperReadOnly(connectionWithoutSecret, syncRequestOpt.orNull)
    )
    context.put("debug", new DebugHelper())
    context
  }

  override def createIncomingSyncContext(
      replica: BasicHubIssue,
      firstSync: Boolean,
      connection: IConnection,
      syncRequest: ISyncRequest,
      prevOpt: Option[IHubIssueReplica],
      remoteEntityUrlOpt: Option[String],
      localIssueKeyOpt: Option[IIssueKey],
      blobMetadataSeq: Seq[IBlobMetadata],
      traces: Seq[INonPersistentTrace],
      log: org.slf4j.Logger,
      isAIScript: Boolean = false
  ): Future[util.Map[String, Object]] = {
    val syncRequestOpt = Option(syncRequest)
    val connectionWithoutSecret = new Connection(connection, true)

    localIssueKeyOpt match {
      case None =>
        val entitiesBeforeUpdatingF =
          trackerHubObjectService.getHubEntitiesTemplate(connection).recover {
            case _ =>
              Seq.empty
          }
        val entitiesF =
          trackerHubObjectService.getHubEntitiesTemplate(connection).recover {
            case _ =>
              Seq.empty
          }

        val httpClientReadOnly =
          if (!isAIScript) issueTrackerHttpClientFactory.getHttpClientReadOnly()
          else
            issueTrackerHttpClientFactory.getHttpClientAIReadOnly()
        for {
          entitiesBeforeUpdating <- entitiesBeforeUpdatingF
          entities <- entitiesF
          _traces = new util.ArrayList[INonPersistentTrace](traces.asJava)
          context: util.HashMap[String, Object] = trackerReadOnlyContextService
            .getCreateProcessorContextReadOnly(
              connectionWithoutSecret,
              entities,
              replica,
              _traces,
              blobMetadataSeq,
              entitiesBeforeUpdating,
              isAIScript
            )
          //////////////////////////////////
          // Hello, future Exalate developer!
          // these variable names and their availability are very important!
          // if you need to change them, check:
          // * customer scripts relying on them (search for keys embedded into their scripts)
          // * `StoreClosureAggregate.call` search for places, where context map is accessed.
          // * `MappingService.receive` search for places, where context map is accessed.
          // * external scripts that we document on docs.exalate.com
          //////////////////////////////////
          _ = context.put(
            "entityType",
            syncRequestOpt.map(_.getReplica.getIssueKey.getEntityType).orNull
          )
          _ = context.put(
            "groovyHttpClient",
            issueTrackerHttpClientFactory.getGroovyHttpClientReadOnly()
          )
          _ = context.put(
            "remoteEntityType",
            syncRequestOpt.map(_.getReplica.getIssueKey.getEntityType).orNull
          )
          _ = context.put(
            "syncHelper",
            syncHelperFactory.getSyncHelper(connectionWithoutSecret, syncRequestOpt.orNull)
          )
          _ = context.put("blobMetadataSeq", blobMetadataSeq)
          _ = context.put("connection", connectionWithoutSecret)
          _ = context.put("debug", new DebugHelper())
          _ = context.put("entities", entities)
          _ = context.put("entitiesBeforeUpdating", entitiesBeforeUpdating)
          _ = context.put("firstSync", lang.Boolean.valueOf(firstSync))
          _ = context.put("issueKey", null)
          _ = context.put("issueToBeCreated", lang.Boolean.valueOf(firstSync))
          _ = context.put("issueUrl", remoteEntityUrlOpt.orNull)
          _ = context.put("log", log)
          _ = context.put("relation", connectionWithoutSecret)
          _ = context.put("remoteIssueUrl", remoteEntityUrlOpt.orNull)
          _ = context.put("replica", replica)
          _ = context.put("syncRequest", syncRequest)
          _ = context.put("traces", _traces)
          _ = context.putIfAbsent("httpClient", httpClientReadOnly)
          _ = entitiesBeforeUpdating.foreach(e => context.put(s"${e.getEntityName}BeforeScript", e))
        } yield context

      case Some(localIssueKey) =>
        trackerHubObjectService
          .get2HubPayloadsFromTracker(localIssueKey, connection)
          .map {
            case Some((issueBeforeUpdatingPayload, hubPayload)) =>
              val issueBeforeUpdating = issueBeforeUpdatingPayload.getHubIssue
              val issue = hubPayload.getHubIssue
              val previous = prevOpt.orNull

              val _traces = new util.ArrayList[INonPersistentTrace](traces.asJava)
              val context: util.HashMap[String, Object] =
                trackerReadOnlyContextService.getChangeProcessorContextReadOnly(
                  connectionWithoutSecret,
                  localIssueKey,
                  issue,
                  previous,
                  replica,
                  _traces,
                  blobMetadataSeq,
                  issueBeforeUpdating,
                  isAIScript
                )
              //////////////////////////////////
              // Hello, future Exalate developer!
              // these variable names and their availability are very important!
              // if you need to change them, check:
              // * customer scripts relying on them (search for keys embedded into their scripts)
              // * `StoreClosureAggregate.call` search for places, where context map is accessed.
              // * `MappingService.receive` search for places, where context map is accessed.
              // * external scripts that we document on docs.exalate.com
              //////////////////////////////////
              context.put(
                "remoteEntityType",
                syncRequestOpt.map(_.getReplica.getIssueKey.getEntityType).orNull
              )
              context.put(
                "syncHelper",
                syncHelperFactory.getSyncHelper(connection, syncRequestOpt.orNull)
              )
              context.put("blobMetadataSeq", blobMetadataSeq)
              context.put("connection", connectionWithoutSecret)
              context.put("debug", new DebugHelper())
              context.put("entities", Seq(issue))
              context.put("entitiesBeforeUpdating", Seq(issueBeforeUpdating))
              context.put("entity", issue)
              context.put("entityBeforeScript", issueBeforeUpdating)
              context.put("entityType", localIssueKey.getEntityType)
              context.put("firstSync", lang.Boolean.valueOf(firstSync))
              context.put("issueKey", localIssueKey)
              context.put("issueUrl", remoteEntityUrlOpt.orNull)
              context.put("log", log)
              context.put("previous", previous)
              context.put("relation", connectionWithoutSecret)
              context.put("remoteIssueUrl", remoteEntityUrlOpt.orNull)
              context.put("replica", replica)
              context.put("syncRequest", syncRequestOpt.orNull)
              context.put("traces", _traces)
              context.put(s"${issueBeforeUpdating.getEntityName}BeforeScript", issueBeforeUpdating)
              context
            case None                                           =>
              throw new BugException(
                s"Exalate couldn't find local issue ${localIssueKey.getURN} (${localIssueKey.getIdStr}) to run the Exalate Scripts. Please resolve and retry the error or contact Exalate Support"
              )
          }
    }
  }

}
