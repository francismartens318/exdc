package com.exalate.replication.services.processor

import com.exalate.api.domain.connection.IConnection

object ConnectionScriptHelper {

  /** Depending on the version returns script for creating entity, whether from IncomingProcessor or
    * from CreateProcessor
    * @param connection
    * @return
    *   script string
    */
  def getCreateProcessorScript(connection: IConnection): String =
    if (connection.getVersion == "2") connection.getIncomingProcessor
    else connection.getCreateProcessor

  /** Depending on the version returns script for changing entity, whether from IncomingProcessor or
    * from ChangeProcessor
    * @param connection
    * @return
    *   script string
    */
  def getChangeProcessorScript(connection: IConnection): String =
    if (connection.getVersion == "2") connection.getIncomingProcessor
    else connection.getChangeProcessor

}
