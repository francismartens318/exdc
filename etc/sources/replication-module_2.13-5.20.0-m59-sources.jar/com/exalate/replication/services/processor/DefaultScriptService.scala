package com.exalate.replication.services.processor

import com.exalate.api.exception.bug.BugException
import com.exalate.api.persistence.relation.IRelationRepository
import com.exalate.replication.services.api.processor.IDefaultScriptService
import com.exalate.replication.services.transport.value.DefaultScriptValue
import com.exalate.services.api.IMessagesService
import javax.inject.Inject

import scala.concurrent.{ExecutionContext, Future}

class DefaultScriptService @Inject() (
    connectionRepository: IRelationRepository,
    val messagesApi: IMessagesService
)(implicit ec: ExecutionContext)
    extends IDefaultScriptService {

  /** Generates default script rules. Is executed when frontend calls following request: GET
    * /rest/issuehub/4.0/editor/connections/:connectionId/mappings/defaultScript
    * @param connectionId
    *   id of the connection
    * @return
    *   DefaultScriptValue
    */
  def getDefaultScript(connectionId: Int): Future[DefaultScriptValue] =
    for {
      cOpt <- connectionRepository.getConnectionFuture(connectionId)
      c <- cOpt match {
        case None    =>
          Future.failed(new BugException("There is no connection anymore. Please try again."))
        case Some(c) =>
          Future.successful(c)
      }
      localInstanceName = c.getLocalInstanceName
      remoteInstanceName = c.getRemoteInstance.getName
      localInstanceVarName = VariableNameScriptService.getVariableName(localInstanceName)
      remoteInstanceVarName = VariableNameScriptService.getVariableName(remoteInstanceName)
      helper = ExampleHelper(
        localInstanceName,
        remoteInstanceName,
        localInstanceVarName,
        remoteInstanceVarName
      )
      script: String = Seq(
        helper.getTextCfExample(),
        helper.getSelectSingleCfExample(),
        helper.getLabelsExample()
      ).mkString("\n\n")
    } yield DefaultScriptValue(script)

  private case class ExampleHelper(
      localInstanceName: String,
      remoteInstanceName: String,
      localInstanceVarName: String,
      remoteInstanceVarName: String
  ) {

    def getLabelsExample(): String = messagesApi
      .translate(
        "com.exalate.default.script.labels",
        Seq(localInstanceVarName, remoteInstanceVarName)
      )
      .getOrElse(s"""// labels sync
                   |//$localInstanceVarName.issue.labels = $remoteInstanceVarName.issue.labels """.stripMargin)

    // Text Field (single line) / (multi-line) custom field
    def getTextCfExample(): String = messagesApi
      .translate(
        "com.exalate.default.script.text.cf",
        Seq(localInstanceVarName, remoteInstanceVarName)
      )
      .getOrElse(
        s"""// sync value from "remote side text custom field" to the local "text custom field"
         |//$localInstanceVarName.issue.customFields."text custom field".value = $remoteInstanceVarName.issue.customFields."remote side text custom field".value
         |// Set a fixed value "Exalate" in the custom field with name  "My custom field"
         |//$localInstanceVarName.issue.customFields."My custom field".value = "Exalate" """.stripMargin
      )

    // Select List (single choice) / Radio Buttons custom field
    def getSelectSingleCfExample(): String = messagesApi
      .translate(
        "com.exalate.default.script.select.single.cf",
        Seq(localInstanceVarName, remoteInstanceVarName)
      )
      .getOrElse(
        s"""// sync value from "remote side select list custom field" to the local "select list custom field"
         |//$localInstanceVarName.issue.customFields."select list custom field".value = $remoteInstanceVarName.issue.customFields."remote side select list custom field".value?.value
         |// Set "Red" as a value in the custom fields "My select list"
         |//$localInstanceVarName.issue.customFields."My select list".value = "Red" """.stripMargin
      )

    // Date Picker / Date Time Picker custom field
    def getDateCfExample(): String = messagesApi
      .translate(
        "com.exalate.default.script.date.cf",
        Seq(localInstanceName, remoteInstanceName, localInstanceVarName, remoteInstanceVarName)
      )
      .getOrElse(
        s"""// if you have a custom field called "My Date" (of type Date Picker or Date Time Picker)
         |// on $localInstanceName and you'd like to populate it from
         |// "Their Date" of $remoteInstanceName (of type Date Picker or Date Time Picker)
         |//$localInstanceVarName.issue.customFields."My Date".value = $remoteInstanceVarName.issue.customFields."Their Date".value
         |// or if you'd like to assign a fixed moment in time:
         |//$localInstanceVarName.issue.customFields."My Date".value = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss z")
         |    .parse("2019-10-24 13:30:59 EET") """.stripMargin
      )

    // Labels custom field
    def getLabelsCfExample(): String = messagesApi
      .translate(
        "com.exalate.default.script.labels.cf",
        Seq(localInstanceVarName, remoteInstanceVarName)
      )
      .getOrElse(
        s"""// sync value from "remote side labels" to the local "My labels"
         |//$localInstanceVarName.issue.customFields."My labels".value = $remoteInstanceVarName.issue.customFields."remote side labels".value
         |// add "attention" to the custom field "My labels"
         |//$localInstanceVarName.issue.customFields."My labels".value += nodeHelper.getLabel("attention") """.stripMargin
      )

    // User Picker (single user) custom field
    def getUserPickerCfExample(): String = messagesApi
      .translate(
        "com.exalate.default.script.user.picker.cf",
        Seq(localInstanceVarName, remoteInstanceVarName)
      )
      .getOrElse(
        s"""// sync value from "remote side user picker custom field" to the local "user picker custom field"
         |//$localInstanceVarName.issue.customFields."user picker custom field".value = nodeHelper.getUser($remoteInstanceVarName.issue.customFields."remote side user picker custom field".value)
         |// Set a fixed value "557358:bda57a72g56a9-4219-9c29-7d666481388f" (id for a user in your system) in the custom field with name  "My user picker"
         |//$localInstanceVarName.issue.customFields."My user picker".value = "557358:bda57a72g56a9-4219-9c29-7d666481388f" """.stripMargin
      )

    // Select List (multiple choice) / Checkboxes custom field
    def getSelectMultiCfExample(): String = messagesApi
      .translate(
        "com.exalate.default.script.select.multi.cf",
        Seq(localInstanceVarName, remoteInstanceVarName)
      )
      .getOrElse(
        s"""// sync value from "remote multi-select list custom field" to the local "select list multiple choice"
         |//$localInstanceVarName.issue.customFields."select list multiple choice".value = $remoteInstanceVarName.issue.customFields."remote multi-select list custom field".value?.value
         |// Add "Red" as a value in the custom fields "My multi-select list"
         |//$localInstanceVarName.issue.customFields."My multi-select list".value += nodeHelper.getOption("Red") """.stripMargin
      )

    // Select List (cascading) custom field
    def getSelectCascadeCfExample(): String = ???

    // Number custom field
    def getNumberCfExample(): String = messagesApi
      .translate(
        "com.exalate.default.script.number.cf",
        Seq(localInstanceVarName, remoteInstanceVarName)
      )
      .getOrElse(
        s"""// sync value from "remote side number custom field" to the local "numeric custom field"
         |//$localInstanceVarName.issue.customFields."numeric custom field".value = $remoteInstanceVarName.issue.customFields."remote side number custom field".value
         |// Set a fixed value 10 in the custom field with name "My custom field"
         |//$localInstanceVarName.issue.customFields."My custom field".value = 10 """.stripMargin
      )

    // URL Field custom field
    def getUrlCfExample(): String = messagesApi
      .translate(
        "com.exalate.default.script.url.cf",
        Seq(localInstanceVarName, remoteInstanceVarName)
      )
      .getOrElse(
        s"""// sync value from "remote side url custom field" to the local "url custom field"
         |//$localInstanceVarName.issue.customFields."url custom field".value = $remoteInstanceVarName.issue.customFields."remote side url custom field".value
         |// Set a fixed value "https://exalate.com" in the custom field with name  "My url custom field"
         |//$localInstanceVarName.issue.customFields."My url custom field".value = "https://exalate.com" """.stripMargin
      )

  }

}
