package com.exalate.replication.services.processor

import com.exalate.domain.values.SyncPriorityValue
import org.slf4j.LoggerFactory

import scala.collection.mutable

sealed case class SyncPriority(number: Int, displayText: String) extends Ordered[SyncPriority] {
  SyncPriority.byNumber.put(number, this)

  def toValue: SyncPriorityValue = SyncPriorityValue(number, displayText)

  override def compare(that: SyncPriority): Int = this.number.compareTo(that.number)

  override def toString: String = s"$displayText($number)"
}

object SyncPriority {
  private val byNumber = mutable.Map[Int, SyncPriority]()

  // For java compatibility
  def apply(number: Integer): SyncPriority = apply(Option(number).map(n => n.toInt))

  def apply(number: Option[Int]): SyncPriority = number match {
    case None      =>
      // Backward compatibility for receiving requests with no priority set: use default priority
      Default
    case Some(num) => apply(num)
  }

  def apply(number: Int): SyncPriority = byNumber.get(number) match {
    case Some(p) => p
    case None    =>
      // Forward compatibility for receiving requests with a new priority value not defined in current version
      // We keep the priority number and display it as "Other" in UI
      SyncPriority(number, "Other")
  }

  val High: SyncPriority = SyncPriority(10, "High")
  val Default: SyncPriority = SyncPriority(50, "Default")
  val Low: SyncPriority = SyncPriority(100, "Low")

}
