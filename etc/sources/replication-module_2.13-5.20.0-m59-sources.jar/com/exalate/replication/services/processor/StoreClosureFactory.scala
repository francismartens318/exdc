package com.exalate.replication.services.processor

import com.exalate.replication.services.api.processor.{
  IApplyScriptResultService,
  IScriptVariableServiceFactory,
  IStoreClosureFactory,
  StoreClosureAggregate
}
import javax.inject.Inject

class StoreClosureFactory @Inject() (
    applyScriptResultService: IApplyScriptResultService,
    scriptVariableServiceFactory: IScriptVariableServiceFactory
) extends IStoreClosureFactory {

  override def create(): StoreClosureAggregate =
    new StoreClosureAggregate(applyScriptResultService, scriptVariableServiceFactory)

}
