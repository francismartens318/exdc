package com.exalate.replication.services.processor.log

import ch.qos.logback.classic.{Level, Logger => LogbackLogger, LoggerContext}
import com.exalate.domain.processor.log.CollectLogResult
import org.slf4j.LoggerFactory

import scala.concurrent.{ExecutionContext, Future}
import scala.util.{Failure, Success, Try}

object LoggingUtil {

  def executeAndCollectLogs[R](
      withLogger: LoggerWrapper => Future[R]
  )(implicit ec: ExecutionContext): Future[CollectLogResult[Try[R]]] = {
    val loggerContext = LoggerFactory.getILoggerFactory.asInstanceOf[LoggerContext]
    val memoryAppender = new MemoryAppender

    // Set appender properties
    memoryAppender.setName(MemoryAppender.NAME)
    memoryAppender.setContext(loggerContext)
    memoryAppender.start()

    // Get logger and add appender
    val logger = LoggerFactory
      .getLogger(LoggerWrapper.NAME)
      .asInstanceOf[LogbackLogger]
    logger.addAppender(memoryAppender)
    logger.setLevel(Level.TRACE)
    logger.setAdditive(false) // so logs are only collected in our appender, and not elsewhere

    def finalize = {
      // Cleanup
      memoryAppender.stop()
      logger.detachAppender(memoryAppender)
    }

    // Execute the function that potentially logs something
    Future
      .fromTry(
        Try(
          withLogger(new LoggerWrapper(logger, memoryAppender))
            .map { result =>
              val loggedEvents = memoryAppender.getLogEvents
              finalize
              CollectLogResult(
                loggedEvents,
                Success(result): Try[R]
              )
            }
            .recover {
              case e =>
                val loggedEvents = memoryAppender.getLogEvents
                finalize
                CollectLogResult(
                  loggedEvents,
                  Failure(e): Try[R]
                )
            }
        )
      )
      .flatten
      .recover {
        case e: Exception =>
          finalize
          val loggedEvents = memoryAppender.getLogEvents
          finalize
          CollectLogResult(
            loggedEvents,
            Failure(e): Try[R]
          )
      }

  }

  def logbackToSlf4jLevel(level: Level): org.slf4j.event.Level =
    level.toInt match {
      case Level.TRACE_INT => org.slf4j.event.Level.TRACE
      case Level.DEBUG_INT => org.slf4j.event.Level.DEBUG
      case Level.INFO_INT  => org.slf4j.event.Level.INFO
      case Level.WARN_INT  => org.slf4j.event.Level.WARN
      case Level.ERROR_INT => org.slf4j.event.Level.ERROR
      case _               => org.slf4j.event.Level.ERROR
    }

}
