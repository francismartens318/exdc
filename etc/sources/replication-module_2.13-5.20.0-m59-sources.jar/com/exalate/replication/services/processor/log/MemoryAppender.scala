package com.exalate.replication.services.processor.log

import ch.qos.logback.classic.spi.ILoggingEvent
import ch.qos.logback.core.AppenderBase
import com.exalate.domain.processor.log.LogEvent
import com.exalate.replication.services.processor.log.LoggingUtil.logbackToSlf4jLevel

import scala.collection.mutable.ListBuffer

class MemoryAppender extends AppenderBase[ILoggingEvent] {
  private val logEvents: ListBuffer[ILoggingEvent] = ListBuffer.empty[ILoggingEvent]

  override def append(eventObject: ILoggingEvent): Unit =
    logEvents += eventObject

  def getLogEvents: Seq[LogEvent] = logEvents.toSeq
    .map(e => LogEvent(logbackToSlf4jLevel(e.getLevel), e.getMessage))

}

object MemoryAppender {
  val NAME: String = "MEMORY_APPENDER"
}
