package com.exalate.replication.services.processor

import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.hubobject.IHubIssueReplica
import com.exalate.api.domain.request.ISyncRequest
import com.exalate.api.domain.twintrace.{INonPersistentTrace, ITrace, TraceType}
import com.exalate.api.domain.{IBlobMetadata, IIssueKey, INonPersistentReplica}
import com.exalate.api.exception.RetriableException
import com.exalate.api.exception.script.{ScriptException, ScriptProcessors}
import com.exalate.api.hubobject.jira.INodeHelper
import com.exalate.api.hubobject.v1.IHubIssueProcessorPreparationService
import com.exalate.api.processor.IExalateProcessor
import com.exalate.basic.domain.BasicNonPersistentTrace
import com.exalate.basic.domain.hubobject.v1.BasicHubIssue
import com.exalate.domain.exception.editor.EditorCategorizedException
import com.exalate.replication.services.api.processor.{
  IApplyScriptResultService,
  IChangeIssueProcessor,
  IScriptVariableServiceFactory,
  IStoreClosureFactory
}
import com.exalate.replication.services.api.replication.mapping.IMappingService
import com.exalate.replication.services.api.replication.scope.IScopeService
import com.exalate.services.utils.CollectionService.mapToSeq
import org.apache.commons.lang3.exception.ExceptionUtils
import org.slf4j
import org.slf4j.LoggerFactory

import java.util
import javax.inject.Inject
import scala.concurrent.{ExecutionContext, Future}
import scala.jdk.CollectionConverters._
import scala.util.{Failure, Try}

class ChangeIssueProcessor @Inject() (
    processor: IExalateProcessor,
    scriptVariableServiceFactory: IScriptVariableServiceFactory,
    storeClosureFactory: IStoreClosureFactory,
    applyScriptResultService: IApplyScriptResultService,
    preparationService: IHubIssueProcessorPreparationService,
    scopeService: IScopeService,
    mappingService: IMappingService
)(implicit ec: ExecutionContext)
    extends IChangeIssueProcessor {

  import ChangeIssueProcessor.LOG

  /** Change issue process
    * @param connection
    * @param syncRequest
    * @param prevReplica
    *   previous replica
    * @param receivedReplica
    *   received replica
    * @param localIssueKey
    * @param blobMetadataSeq
    * @param fieldTraces
    * @return
    *   Future[Option[Seq[INonPersistentTrace]]]
    */
  def changeIssue(
      connection: IConnection,
      syncRequest: ISyncRequest,
      prevReplica: INonPersistentReplica,
      receivedReplica: INonPersistentReplica,
      localIssueKey: IIssueKey,
      blobMetadataSeq: Seq[IBlobMetadata],
      fieldTraces: Map[TraceType, Seq[ITrace]]
  ): Future[Option[Seq[INonPersistentTrace]]] = {
    val scriptVariableService = scriptVariableServiceFactory.getScriptVariableService()
    val current = receivedReplica.getPayload.getHubIssue
    val fieldTracesJavaMap = fieldTraces.map {
      case (traceType, ts) => (traceType, ts.asJava)
    }.asJava
    val replica = preparationService.prepareRemoteHubIssue(
      current.asInstanceOf[BasicHubIssue],
      fieldTracesJavaMap
    )

    val traces = fieldTraces.foldLeft(Seq.empty[INonPersistentTrace]) {
      case (r, (_, ts)) =>
        r ++ ts.map(t => new BasicNonPersistentTrace().from(t))
    }
    val prevOpt = Option(prevReplica)
      .flatMap(r => Option(r.getPayload))
      .flatMap(p => Option(p.getHubIssue))

    scriptVariableService
      .createIncomingSyncContext(
        replica.asInstanceOf[BasicHubIssue],
        firstSync = false,
        connection,
        syncRequest,
        prevOpt,
        Option(receivedReplica.getPayload.getIssueUrl),
        Option(localIssueKey),
        blobMetadataSeq,
        traces,
        LOG
      )
      .flatMap { context =>
        val storeClosure = storeClosureFactory.create()
        context.put("store", storeClosure)

        val _context = new util.HashMap[String, Object](context)
        val issueBeforeUpdating = context
          .get("entitiesBeforeUpdating")
          .asInstanceOf[Seq[IHubIssueReplica]]
          .head
        val issue = context
          .get("entities")
          .asInstanceOf[Seq[IHubIssueReplica]]
          .head

        if (Option(connection.getMode).isDefined && connection.isVisual)
          executeVisualRules(
            RuleExecutionParams(
              connection,
              _context,
              localIssueKey,
              issue,
              issueBeforeUpdating,
              replica.asInstanceOf[BasicHubIssue],
              blobMetadataSeq,
              syncRequest
            )
          )
        else
          executeScriptRules(
            RuleExecutionParams(
              connection,
              _context,
              localIssueKey,
              issue,
              issueBeforeUpdating,
              replica.asInstanceOf[BasicHubIssue],
              blobMetadataSeq,
              syncRequest
            )
          )
      }
  }

  private case class RuleExecutionParams(
      connection: IConnection,
      context: util.HashMap[String, Object],
      localIssueKey: IIssueKey,
      issue: IHubIssueReplica,
      issueBeforeUpdating: IHubIssueReplica,
      replica: BasicHubIssue,
      blobMetadataSeq: Seq[IBlobMetadata],
      syncRequest: ISyncRequest
  )

  /** Executes Visual Rules, namely apply scopes and mapping rules
    * @param ruleExecutionParams
    * @return
    */
  private def executeVisualRules(
      ruleExecutionParams: RuleExecutionParams
  ): Future[Option[Seq[INonPersistentTrace]]] = ruleExecutionParams match {
    case RuleExecutionParams(
          connection: IConnection,
          context: util.HashMap[String, Object],
          localIssueKey: IIssueKey,
          entity: IHubIssueReplica,
          entityBeforeUpdating: IHubIssueReplica,
          replica: BasicHubIssue,
          blobMetadataSeq: Seq[IBlobMetadata],
          syncRequest: ISyncRequest
        ) =>
      val issue = entity.asInstanceOf[BasicHubIssue]
      val issueBeforeUpdating = entityBeforeUpdating.asInstanceOf[BasicHubIssue]
      val traces = getTracesFromContext(context)
      for {
        issueFilledFromScope <- scopeService.receive(
          replica,
          issue.asInstanceOf[BasicHubIssue],
          connection.getID,
          syncRequest
        )
        issueFilledFromVisualRules <- mappingService.receive(
          VisualRuleExecutionParams(
            connection,
            traces,
            issueFilledFromScope,
            issueBeforeUpdating.asInstanceOf[BasicHubIssue],
            replica.asInstanceOf[BasicHubIssue],
            blobMetadataSeq,
            context,
            syncRequest
          )
        )
        result <- applyScriptResultService
          .updateEntity(
            syncRequest,
            context,
            localIssueKey,
            traces,
            issueFilledFromVisualRules,
            issueBeforeUpdating,
            blobMetadataSeq
          )
      } yield Some(result)
  }

  /** Gets script processor: whether `CHANGE` or `INCOMING`
    * @param connection
    * @return
    *   ScriptProcessors
    */
  private def getScriptProcessor(connection: IConnection): ScriptProcessors =
    if (connection.getVersion == "1") ScriptProcessors.CHANGE else ScriptProcessors.INCOMING

  /** Executes script rules when visual editor is not supported
    * @param ruleExecutionParams
    * @return
    */
  private def executeScriptRules(
      ruleExecutionParams: RuleExecutionParams
  ): Future[Option[Seq[INonPersistentTrace]]] = ruleExecutionParams match {
    case RuleExecutionParams(
          connection: IConnection,
          context: util.HashMap[String, Object],
          localIssueKey: IIssueKey,
          issue: IHubIssueReplica,
          issueBeforeUpdating: IHubIssueReplica,
          replica: IHubIssueReplica,
          blobMetadataSeq: Seq[IBlobMetadata],
          syncRequest: ISyncRequest
        ) =>
      LOG.debug(
        s"Ready to run incoming update script for entity $localIssueKey and connection ${connection.getName}"
      )
      val f = Future
        .fromTry(
          Try {
            ChangeIssueProcessor.threadLocalContext.set(context)
            val result = processor.executeProcessor(
              ConnectionScriptHelper.getChangeProcessorScript(connection),
              context,
              getScriptProcessor(connection)
            )
            LOG.debug(
              s"Incoming update script for entity $localIssueKey and connection ${connection.getName} was executed successfully"
            )
            result
          }
            .recoverWith {
              case e: ScriptException =>
                ExceptionUtils
                  .getThrowableList(e)
                  .asScala
                  .reverse
                  .foldLeft(Option.empty[Exception]) {
                    case (eOpt @ Some(_), _) => eOpt // found a handled exception
                    case (None, cause)
                        if cause.isInstanceOf[RetriableException] || cause
                          .isInstanceOf[EditorCategorizedException] =>
                      Some(cause.asInstanceOf[Exception])
                    case _                   => None
                  } match {
                  case Some(handledException) =>
                    Failure(handledException)
                  case None                   =>
                    //                val exception = ScriptExceptionCategoryService.wrapAsChangeProcessorException(e, connection.getName, localIssueKey.getURN)
                    Failure(e)
                }
            }
        )
        .flatMap {
          case (_: IIssueKey, tracesSeq: Seq[INonPersistentTrace]) =>
            Future.successful(Some(tracesSeq))
          case _                                                   =>
            val _entityBeforeUpdating = context
              .get("entitiesBeforeUpdating")
              .asInstanceOf[Seq[IHubIssueReplica]]
              .head
            val _entity = context
              .get("entities")
              .asInstanceOf[Seq[IHubIssueReplica]]
              .head
            val tracesAfterScriptsProcessed = getTracesFromContext(context)
            val blobMetadataAfterScriptsProcessed = getBlobMetadataFromContext(context)

            val customHttpHeaders: Seq[(String, String)] =
              mapToSeq(context.get("nodeHelper").asInstanceOf[INodeHelper].getHTTPHeaders)

            applyScriptResultService
              .updateEntity(
                syncRequest,
                context,
                localIssueKey,
                tracesAfterScriptsProcessed,
                _entity,
                _entityBeforeUpdating,
                blobMetadataAfterScriptsProcessed,
                customHttpHeaders
              )
              .map(Some.apply)
        }
      ChangeIssueProcessor.threadLocalContext.remove()
      f
  }

  private def getTracesFromContext(
      context: util.HashMap[String, Object]
  ): util.List[INonPersistentTrace] =
    Try(context.get("traces").asInstanceOf[util.ArrayList[INonPersistentTrace]])
      .getOrElse(new util.ArrayList[INonPersistentTrace]())

  private def getBlobMetadataFromContext(
      context: util.HashMap[String, Object]
  ): Seq[IBlobMetadata] =
    Try(context.get("blobMetadataSeq").asInstanceOf[Seq[IBlobMetadata]]).getOrElse(Seq[IBlobMetadata]())

}

object ChangeIssueProcessor {
  /*
  Allows you to get context from the scripts with:
   com.exalate.replication.services.processor.ChangeIssueProcessor$.MODULE$.threadLocalContext.get().commentHelper
   */
  val threadLocalContext = new ThreadLocal[util.HashMap[String, Object]]
  val LOG: slf4j.Logger = LoggerFactory.getLogger(classOf[ChangeIssueProcessor])
}
