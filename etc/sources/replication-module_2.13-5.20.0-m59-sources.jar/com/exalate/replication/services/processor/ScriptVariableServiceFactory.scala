package com.exalate.replication.services.processor

import com.exalate.api.hubobject.jira.IAttachmentHelper
import com.exalate.generic.services.api.{ITrackerContextServiceReadOnly, ITrackerHubObjectService}
import com.exalate.replication.services.api.issuetracker.IIssueTrackerHttpClientFactory
import com.exalate.replication.services.api.issuetracker.script.IExalateHelper
import com.exalate.replication.services.api.processor.{
  IScriptVariableService,
  IScriptVariableServiceFactory,
  ISyncHelperFactory
}
import com.exalate.replication.services.api.replication.scope.ITrackerScopeAndMappingHelper

import javax.inject.Inject
import scala.concurrent.ExecutionContext

class ScriptVariableServiceFactory @Inject() (
    hubObjectService: ITrackerHubObjectService,
    syncHelperFactory: ISyncHelperFactory,
    trackerScopeAndMappingHelper: ITrackerScopeAndMappingHelper,
    attachmentHelper: IAttachmentHelper,
    exalateHelper: IExalateHelper,
    issueTrackerHttpClientFactory: IIssueTrackerHttpClientFactory,
    trackerReadOnlyContextService: ITrackerContextServiceReadOnly
)(implicit val executionContext: ExecutionContext)
    extends IScriptVariableServiceFactory {

  def getScriptVariableService(): IScriptVariableService = new ScriptVariableService(
    hubObjectService,
    syncHelperFactory,
    trackerScopeAndMappingHelper,
    attachmentHelper,
    exalateHelper,
    issueTrackerHttpClientFactory
  )

  def getScriptVariableReadOnlyService(): IScriptVariableService =
    new ScriptVariableReadOnlyService(
      trackerReadOnlyContextService,
      hubObjectService,
      syncHelperFactory,
      issueTrackerHttpClientFactory
    )

}
