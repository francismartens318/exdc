package com.exalate.replication.services.processor

import java.util

import com.exalate.api.domain.hubobject.IHubIssueReplica
import com.exalate.api.domain.request.ISyncRequest
import com.exalate.api.domain.twintrace.{INonPersistentTrace, ITrace, TraceType}
import com.exalate.api.domain.{IBlobMetadata, IIssueKey}
import com.exalate.api.exception.script.ScriptException
import com.exalate.api.hubobject.IHubObjectValidator
import com.exalate.api.hubobject.v1.IHubIssueProcessorPreparationService
import com.exalate.basic.domain.hubobject.v1.BasicHubIssue
import com.exalate.generic.services.api.ITrackerHubObjectService
import com.exalate.replication.services.api.processor.IApplyScriptResultService
import com.exalate.replication.services.utils.TraceUtils
import javax.inject.Inject

import scala.jdk.CollectionConverters._
import scala.concurrent.Future
import scala.util.{Failure, Success, Try}

class ApplyScriptResultService @Inject() (
    hubObjectValidator: IHubObjectValidator,
    hubObjectService: ITrackerHubObjectService,
    preparationService: IHubIssueProcessorPreparationService
) extends IApplyScriptResultService {

  override def getModifiedEntity(
      entitiesBefore: Seq[IHubIssueReplica],
      entitiesAfter: Seq[IHubIssueReplica]
  ): Try[Option[IHubIssueReplica]] =
    // check if more than one entity was touched
    // find which entity was touched
    // iterate through the after, for each of them check if it was touch, if it was mark it, if you find a new one, throw error

    entitiesAfter.foldLeft[Try[Option[IHubIssueReplica]]](Success(None)) {
      case (finalReplica, entity) =>
        val key = entity.getEntityName
        if (finalReplica.isFailure) {
          finalReplica
        } else {
          val entityBefore = entitiesBefore.find(_.getEntityName == key).get
          if (!entity.equals(entityBefore)) {
            if (finalReplica.get.isEmpty) {
              Success(Some(entity))
            } else {
              Failure(new ScriptException("Multiple entities touched on first sync"))
            }
          } else {
            finalReplica
          }
        }
    }

  override def createEntity(
      syncRequest: ISyncRequest,
      blobMetadataSeq: Seq[IBlobMetadata],
      issueBeforeUpdating: IHubIssueReplica,
      issue: IHubIssueReplica,
      customHttpHeaders: Seq[(String, String)] = Nil
  ): Future[(IIssueKey, Seq[INonPersistentTrace])] = {
    val preparedEntity = issue match {
      case i: IHubIssueReplica =>
        i match {
          case issue1: BasicHubIssue => hubObjectValidator.validateIssueReplica(issue1)
          case _                     =>
        }
        preparationService.prepareLocalHubIssueViaPrevious(
          issueBeforeUpdating,
          i,
          util.Collections.emptyMap()
        )
      case i                   => i
    }

    hubObjectService.createEntity(
      issueBeforeUpdating,
      preparedEntity,
      syncRequest,
      blobMetadataSeq,
      customHttpHeaders
    )
  }

  /** Updates issue on issue tracker with provided data
    * @param syncRequest
    * @param context
    * @param localIssueKey
    *   issue key that will be updated
    * @param traces
    * @param issue
    * @param issueBeforeUpdating
    * @param blobMetadataSeq
    * @return
    */
  override def updateEntity(
      syncRequest: ISyncRequest,
      context: util.HashMap[String, Object],
      localIssueKey: IIssueKey,
      traces: util.List[INonPersistentTrace],
      issue: IHubIssueReplica,
      issueBeforeUpdating: IHubIssueReplica,
      blobMetadataSeq: Seq[IBlobMetadata],
      customHttpHeaders: Seq[(String, String)] = Nil
  ): Future[Seq[INonPersistentTrace]] = {
    val updatedTracesMap: Map[TraceType, Seq[ITrace]] = TraceUtils.convertTraces(traces)

    val updatedTracesJavaMap: util.Map[TraceType, util.List[ITrace]] =
      TraceUtils.convertTraces(updatedTracesMap)

    val preparedEntity = issue match {
      case i: IHubIssueReplica =>
        i match {
          case issue1: BasicHubIssue => hubObjectValidator.validateIssueReplica(issue1)
          case _                     =>
        }
        preparationService.prepareLocalHubIssueViaPrevious(
          issueBeforeUpdating,
          i,
          updatedTracesJavaMap
        )
      case i                   => i
    }
    ChangeIssueProcessor.threadLocalContext.set(context)
    val result = if (issueBeforeUpdating.equals(preparedEntity)) {
      Future.successful(traces.asScala.toSeq)
    } else {
      hubObjectService.updateEntity(
        issueBeforeUpdating,
        preparedEntity,
        syncRequest,
        localIssueKey,
        blobMetadataSeq,
        updatedTracesMap,
        customHttpHeaders
      )
    }
    ChangeIssueProcessor.threadLocalContext.remove()
    result
  }

}
