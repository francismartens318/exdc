package com.exalate.replication.services.processor

import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.hubobject.IHubIssueReplica
import com.exalate.api.domain.request.ISyncRequest
import com.exalate.api.domain.twintrace.INonPersistentTrace
import com.exalate.api.domain.{IBlobMetadata, IIssueKey}
import com.exalate.api.exception.bug.BugException
import com.exalate.api.hubobject.jira.IAttachmentHelper
import com.exalate.basic.domain.connection.Connection
import com.exalate.basic.domain.hubobject.v1.BasicHubIssue
import com.exalate.domain.editor.FieldDataType
import com.exalate.domain.editor.mappings.Mappings
import com.exalate.generic.services.api.ITrackerHubObjectService
import com.exalate.hubobject.jira.DebugHelper
import com.exalate.replication.services.api.issuetracker.IIssueTrackerHttpClientFactory
import com.exalate.replication.services.api.issuetracker.script.IExalateHelper
import com.exalate.replication.services.api.processor.{
  IScriptVariableService,
  ISyncHelperFactory,
  LocalInstanceAggregate,
  RemoteInstanceAggregate
}
import com.exalate.replication.services.api.replication.scope.ITrackerScopeAndMappingHelper
import com.exalate.replication.services.script._

import java.{lang, util}
import javax.inject.Inject
import scala.concurrent.{ExecutionContext, Future}
import scala.jdk.CollectionConverters._

class ScriptVariableService @Inject() (
    hubObjectService: ITrackerHubObjectService,
    syncHelperFactory: ISyncHelperFactory,
    trackerScopeAndMappingHelper: ITrackerScopeAndMappingHelper,
    attachmentHelper: IAttachmentHelper,
    exalateHelper: IExalateHelper,
    issueTrackerHttpClientFactory: IIssueTrackerHttpClientFactory
)(implicit val executionContext: ExecutionContext)
    extends IScriptVariableService {

  override def createOutgoingSyncContext(
      connection: IConnection,
      issue: IHubIssueReplica,
      replica: BasicHubIssue,
      localIssueKey: IIssueKey,
      syncRequestOpt: Option[ISyncRequest],
      log: org.slf4j.Logger,
      isAIScript: Boolean = false
  ): util.HashMap[String, Object] = {
    val connectionWithoutSecret = new Connection(connection, true)
    val context = hubObjectService
      .getDataFilterContext(connectionWithoutSecret, localIssueKey, issue, replica)
    context.put(localIssueKey.getEntityType, issue)
    context.put("entity", issue)
    context.put("issueKey", localIssueKey)
    context.put("replica", replica)
    context.put("connection", connectionWithoutSecret)
    context.put("relation", connectionWithoutSecret)
    context.put("syncRequest", syncRequestOpt.orNull)
    context.put("groovyHttpClient", issueTrackerHttpClientFactory.getGroovyHttpClient())
    context.putIfAbsent("httpClient", issueTrackerHttpClientFactory.getHttpClient())
    context.put("log", log)
    context.put(
      "syncHelper",
      syncHelperFactory.getSyncHelper(connectionWithoutSecret, syncRequestOpt.orNull)
    )
    context.put("debug", new DebugHelper())
    context
  }

  override def createIncomingSyncContext(
      replica: BasicHubIssue,
      firstSync: Boolean,
      connection: IConnection,
      syncRequest: ISyncRequest,
      prevOpt: Option[IHubIssueReplica],
      remoteEntityUrlOpt: Option[String],
      localIssueKeyOpt: Option[IIssueKey],
      blobMetadataSeq: Seq[IBlobMetadata],
      traces: Seq[INonPersistentTrace],
      log: org.slf4j.Logger,
      isAIScript: Boolean = false
  ): Future[util.Map[String, Object]] = {
    val connectionWithoutSecret = new Connection(connection, true)

    localIssueKeyOpt match {
      case None =>
        val entitiesBeforeUpdatingF = hubObjectService.getHubEntitiesTemplate(connection).recover {
          case _ =>
            Seq.empty
        }
        val entitiesF = hubObjectService.getHubEntitiesTemplate(connection).recover {
          case _ =>
            Seq.empty
        }

        for {
          entitiesBeforeUpdating <- entitiesBeforeUpdatingF
          entities <- entitiesF
          _traces = new util.ArrayList[INonPersistentTrace](traces.asJava)
          context: util.HashMap[String, Object] = hubObjectService.getCreateProcessorContext(
            connectionWithoutSecret,
            entities,
            replica,
            _traces,
            blobMetadataSeq,
            entitiesBeforeUpdating
          )
          //////////////////////////////////
          // Hello, future Exalate developer!
          // these variable names and their availability are very important!
          // if you need to change them, check:
          // * customer scripts relying on them (search for keys embedded into their scripts)
          // * `StoreClosureAggregate.call` search for places, where context map is accessed.
          // * `MappingService.receive` search for places, where context map is accessed.
          // * external scripts that we document on docs.exalate.com
          //////////////////////////////////
          _ = context.put("replica", replica)
          _ = context.put("connection", connectionWithoutSecret)
          _ = context.put("relation", connectionWithoutSecret)
          _ = context.put("syncRequest", syncRequest)
          _ = context.put("log", log)
          _ = context.put("traces", _traces)
          _ = context.put("firstSync", lang.Boolean.valueOf(firstSync))
          _ = context.put("issueToBeCreated", lang.Boolean.valueOf(firstSync))
          _ = context.put("entityType", syncRequest.getReplica.getIssueKey.getEntityType)
          _ = context.put("remoteEntityType", syncRequest.getReplica.getIssueKey.getEntityType)
          _ = context.put(
            "syncHelper",
            syncHelperFactory.getSyncHelper(connectionWithoutSecret, syncRequest)
          )
          _ = context.put("remoteIssueUrl", remoteEntityUrlOpt.orNull)
          _ = context.put("issueUrl", remoteEntityUrlOpt.orNull)
          _ = context.put("debug", new DebugHelper())
          _ = context.put("entities", entities)
          _ = context.put("entitiesBeforeUpdating", entitiesBeforeUpdating)
          _ = entitiesBeforeUpdating.foreach(e => context.put(s"${e.getEntityName}BeforeScript", e))
          _ = context.put("blobMetadataSeq", blobMetadataSeq)
          _ = context.put("groovyHttpClient", issueTrackerHttpClientFactory.getGroovyHttpClient())
          _ = context.putIfAbsent("httpClient", issueTrackerHttpClientFactory.getHttpClient())
          _ = context.put("issueKey", null)
        } yield context

      case Some(localIssueKey) =>
        hubObjectService.get2HubPayloadsFromTracker(localIssueKey, connection).map {
          case Some((issueBeforeUpdatingPayload, hubPayload)) =>
            val issueBeforeUpdating = issueBeforeUpdatingPayload.getHubIssue
            val issue = hubPayload.getHubIssue
            val previous = prevOpt.orNull

            val _traces = new util.ArrayList[INonPersistentTrace](traces.asJava)
            val context: util.HashMap[String, Object] = hubObjectService.getChangeProcessorContext(
              connectionWithoutSecret,
              localIssueKey,
              issue,
              previous,
              replica,
              _traces,
              blobMetadataSeq,
              issueBeforeUpdating
            )
            //////////////////////////////////
            // Hello, future Exalate developer!
            // these variable names and their availability are very important!
            // if you need to change them, check:
            // * customer scripts relying on them (search for keys embedded into their scripts)
            // * `StoreClosureAggregate.call` search for places, where context map is accessed.
            // * `MappingService.receive` search for places, where context map is accessed.
            // * external scripts that we document on docs.exalate.com
            //////////////////////////////////
            context.put("entity", issue)
            context.put("connection", connectionWithoutSecret)
            context.put("relation", connectionWithoutSecret)
            context.put("replica", replica)
            context.put("previous", previous)
            context.put("syncRequest", syncRequest)
            context.put("log", log)
            context.put("firstSync", lang.Boolean.valueOf(firstSync))
            context.put("entityType", localIssueKey.getEntityType)
            context.put("remoteEntityType", syncRequest.getReplica.getIssueKey.getEntityType)
            context.put("syncHelper", syncHelperFactory.getSyncHelper(connection, syncRequest))
            context.put("remoteIssueUrl", remoteEntityUrlOpt.orNull)
            context.put("issueUrl", remoteEntityUrlOpt.orNull)
            context.put("debug", new DebugHelper())
            context.put("entities", Seq(issue))
            context.put("entitiesBeforeUpdating", Seq(issueBeforeUpdating))
            context.put("blobMetadataSeq", blobMetadataSeq)
            context.put("issueKey", localIssueKey)
            context.put("traces", _traces)
            context.put("entityBeforeScript", issueBeforeUpdating)
            context.put(s"${issueBeforeUpdating.getEntityName}BeforeScript", issueBeforeUpdating)
            context
          case None                                           =>
            throw new BugException(
              s"Exalate couldn't find local issue ${localIssueKey.getURN} (${localIssueKey.getIdStr}) to run the Exalate Scripts. Please resolve and retry the error or contact Exalate Support"
            )
        }
    }
  }

  override def updateIncomingSyncContext(
      context: util.Map[String, Object],
      connection: IConnection,
      issue: BasicHubIssue,
      replica: BasicHubIssue,
      mapping: Mappings,
      swapSides: Boolean,
      sendingInstanceName: String,
      receivingInstanceName: String
  ): util.Map[String, Object] = {
    val localInstance = new LocalInstanceAggregate(issue)
    val remoteInstance = new RemoteInstanceAggregate(replica)

    if (VariableNameScriptService.isValidGroovyVariableName(receivingInstanceName)) {
      context.put(receivingInstanceName, localInstance)
    }
    if (VariableNameScriptService.isValidGroovyVariableName(sendingInstanceName)) {
      context.put(sendingInstanceName, remoteInstance)
    }
    context.put(
      "ExalateAPI",
      Map(
        FieldDataType.OPTION.toString -> new OptionExalateAPI(trackerScopeAndMappingHelper),
        FieldDataType.DATE.toString -> new DateExalateAPI(),
        FieldDataType.TEXT.toString -> new TextExalateAPI(trackerScopeAndMappingHelper),
        FieldDataType.USER.toString -> new UserExalateAPI(trackerScopeAndMappingHelper),
        FieldDataType.MULTI.toString -> Map(
          FieldDataType.FILE.toString -> new MultiFileExalateAPI(attachmentHelper),
          FieldDataType.COMMENT.toString -> new MultiCommentExalateAPI(),
          FieldDataType.TEXT.toString -> new MultiTextExalateAPI()
        ).asJava
      ).asJava
    )
    context.put("ExalateHelper", exalateHelper)

    context.put("executionInstanceName", receivingInstanceName)
    context.put("sendingInstanceName", sendingInstanceName)

    context.put("swapSides", lang.Boolean.valueOf(swapSides))
    context.put("mappings", mapping)

    val on = new util.HashMap[String, Object]()
    on.put(receivingInstanceName, localInstance)
    on.put(sendingInstanceName, remoteInstance)
    context.put(VariableNameScriptService.instanceWrapperVariableName, on)
    context
  }

}
