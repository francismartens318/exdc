package com.exalate.replication.services.processor.log

import ch.qos.logback.classic.{Logger => LogbackLogger}
import com.exalate.domain.processor.log.LogEvent

class LoggerWrapper(val logger: LogbackLogger, memoryAppender: MemoryAppender) {

  def getLogEvents: Seq[LogEvent] =
    memoryAppender.getLogEvents

}

object LoggerWrapper {
  val NAME: String = "com.exalate.scripts.out.dry_run"
}
