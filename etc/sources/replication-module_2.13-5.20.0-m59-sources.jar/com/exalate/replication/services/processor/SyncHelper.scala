package com.exalate.replication.services.processor

import com.exalate.api.domain.IIssueKey
import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.request.ISyncRequest
import com.exalate.api.persistence.relation.IRelationRepository
import com.exalate.api.persistence.replication.request.IRequestReplicationRepository
import com.exalate.api.persistence.twintrace.ITwinTraceRepository
import com.exalate.basic.domain.syncstatus.RemoteIssueUrlContext
import com.exalate.basic.domain.{BasicIssueKey, NonPersistentConnectContext}
import com.exalate.replication.services.api.config.{IGeneralSettingsService, Private, Public}
import com.exalate.replication.services.api.transport.ITransportServiceFactory
import com.exalate.replication.services.replication.EventSchedulerNotificationService
import com.exalate.services.utils.FutureUtils
import com.github.tkqubo.html2md.Html2Markdown
import org.commonmark.parser.Parser
import org.commonmark.renderer.html.HtmlRenderer
import org.jsoup.Jsoup
import play.api.libs.json.Json

import scala.concurrent.{ExecutionContext, Future}

class SyncHelper(
    syncRequestReplication: IRequestReplicationRepository,
    eventSchedulerNotificationService: EventSchedulerNotificationService,
    twinTraceRepository: ITwinTraceRepository,
    connectionRepository: IRelationRepository,
    connection: IConnection,
    syncRequest: ISyncRequest,
    generalSettingsService: IGeneralSettingsService,
    transportServiceFactory: ITransportServiceFactory
)(implicit val executionContext: ExecutionContext) {

  /** Exalates issue
    * @param issueKey
    */
  def exalate(issueKey: IIssueKey) =
    eventSchedulerNotificationService.scheduleExalateOrUpdateEvent(connection, issueKey, None)

  /** Unexalates issue
    * @param issueKey
    */
  def unexalate(issueKey: IIssueKey) =
    eventSchedulerNotificationService.scheduleUnexalateEvent(connection, issueKey)

  /** Check if issue is under sync
    * @param key
    *   issue key
    * @return
    *   true or false
    */
  def isUnderSync(key: IIssueKey): Boolean =
    FutureUtils
      .resultInf(twinTraceRepository.getTwinTraceByLocalIssueKeyFuture(connection, key))
      .isDefined

  /** Check if entity is under sync
    * @param entityId
    *   issue (or other entity) id
    * @param entityType
    *   type of entity (issue, sprint etc)
    * @return
    *   true or false
    */
  def isUnderSync(entityId: String, entityType: String): Boolean = {
    val key = new BasicIssueKey(entityId, entityId, entityType)
    isUnderSync(key)
  }

  /** Check if entity is under sync
    * @param entityId
    *   issue (or other entity) id
    * @param entityType
    *   type of entity (issue, sprint etc)
    * @param connection
    * @return
    *   true or false
    */
  def isUnderSync(entityId: String, entityType: String, connection: String): Boolean = {
    val key = new BasicIssueKey(entityId, entityId, entityType)

    FutureUtils.resultInf(
      connectionRepository
        .getConnectionFuture(connection)
        .flatMap(
          _.map(c =>
            twinTraceRepository.getTwinTraceByLocalIssueKeyFuture(c, key).map(r => r.isDefined)
          ).getOrElse(Future.successful(false))
        )
    )

  }

  /** Check if issue is under sync
    * @param issueId
    *   issue id as string
    * @return
    *   true or false
    */
  def isIssueUnderSync(issueId: String): Boolean = {
    val key = new BasicIssueKey(issueId, issueId)
    isUnderSync(key)
  }

  /** Check if issue is under sync
    * @param issueId
    *   issue is as Long
    * @return
    *   true or false
    */
  def isIssueUnderSync(issueId: Long): Boolean =
    isIssueUnderSync(issueId.toString)

  /** Gets a local key from twintrace repo by provided remote id
    * @param remoteEntityId
    * @param entityType
    * @return
    *   local issue key
    */
  def getLocalKeyFromRemoteId(remoteEntityId: String, entityType: String): IIssueKey = {
    if (remoteEntityId == null) {
      return null
    }
    val twinTraceOpt = FutureUtils.resultInf(
      twinTraceRepository.getTwinTraceByRemoteIssueIdFuture(connection, remoteEntityId, entityType)
    )
    twinTraceOpt.flatMap(tt => Option(tt.getLocalReplica)).map(_.getIssueKey).orNull
  }

  /** Gets a local key from twintrace repo by provided remote id
    * @param remoteIssueId
    * @return
    */
  def getLocalIssueKeyFromRemoteId(remoteIssueId: String): IIssueKey = {
    if (remoteIssueId == null) {
      return null
    }
    val twinTraceOpt = FutureUtils.resultInf(
      twinTraceRepository.getTwinTraceByRemoteIssueIdFuture(
        connection,
        remoteIssueId.toString,
        "issue"
      )
    )
    twinTraceOpt.flatMap(tt => Option(tt.getLocalReplica)).map(_.getIssueKey).orNull
  }

  /** Gets a local key from twintrace repo by provided remote id
    */
  def getLocalIssueKeyFromRemoteId(remoteIssueId: Long): IIssueKey =
    getLocalIssueKeyFromRemoteId(remoteIssueId.toString)

  /** Gets a local key from twintrace repo by provided remote id
    * @param remoteIssueId
    * @param entityType
    * @return
    */
  def getLocalIssueKeyFromRemoteId(remoteIssueId: String, entityType: String): IIssueKey = {
    if (remoteIssueId == null) {
      return null
    }
    val twinTraceOpt = FutureUtils.resultInf(
      twinTraceRepository.getTwinTraceByRemoteIssueIdFuture(
        connection,
        remoteIssueId.toString,
        entityType
      )
    )
    twinTraceOpt.flatMap(tt => Option(tt.getLocalReplica)).map(_.getIssueKey).orNull
  }

  def getLocalIssueKeyFromRemoteId(remoteIssueId: Long, entityType: String): IIssueKey =
    getLocalIssueKeyFromRemoteId(remoteIssueId.toString, entityType)

  def syncBackAfterProcessing() =
    if (syncRequest != null) {
      val cc = new NonPersistentConnectContext(true, true, true, true, false, false)
      syncRequestReplication.updateSyncRequestConnectContext(syncRequest, cc)
    }

  def unExalateAfterProcessing() =
    if (syncRequest != null) {
      val cc = new NonPersistentConnectContext(false, false, false, false, false, true)
      syncRequestReplication.updateSyncRequestConnectContext(syncRequest, cc)
    }

  def toMarkDownFromHtml(html: String) =
    if (!Option(html).exists(_ != "")) {
      null
    } else {
      Html2Markdown.toMarkdown(html)
    }

  def toHtmlFromMarkdown(commonMarkStr: String) =
    if (!Option(commonMarkStr).exists(_ != "")) {
      null
    } else {
      val parser = Parser.builder.build
      val document = parser.parse(commonMarkStr)
      val renderer = HtmlRenderer.builder.build
      renderer.render(document)

    }

  def stripHtml(htmlText: String): String =
    Option(htmlText).map(str => Jsoup.parse(str).text()).orNull

  def getTrackerUrl(): String =
    FutureUtils
      .resultInf(generalSettingsService.get)
      .map(_.getIssueTrackerUrl)
      .orNull

  def getRemoteTrackerUrl(): String =
    Option(connection.getRemoteInstance)
      .flatMap(a => Option(a.getNodeInfo))
      .map(_.getIssueTrackerUrl)
      .orNull

  def getExalateUrl(): String =
    FutureUtils
      .resultInf(generalSettingsService.get)
      .flatMap(_.getExalateUrl)
      .orNull

  def getRemoteExalateUrl(): String =
    Option(connection.getRemoteInstance)
      .flatMap(a => Option(a.getNodeInfo))
      .map(_.getExalateUrl)
      .orNull

  def getRemoteIssueUrl(entityId: String, entityType: String): String = {
    val key = new BasicIssueKey(entityId, entityId, entityType)
    getRemoteIssueUrl(key)
  }

  def getRemoteIssueUrl(localEntityKey: IIssueKey): String =
    FutureUtils.resultInf(
      twinTraceRepository.getTwinTraceByLocalIssueKeyFuture(connection, localEntityKey).flatMap {
        case Some(tt) =>
          if (Option(tt.getConnection.getRemoteInstance.getNodeInfo).exists(!_.isPollOnly)) {
            (Option(tt.getRemoteReplica), Option(tt.getRemoteTwinTraceId)) match {
              case (Some(remoteReplica), Some(_)) =>
                ((Json.parse(remoteReplica.getPayload) \ "issueUrl").asOpt[String] match {
                  case a @ Some(_) => Future.successful(a)
                  case None        =>
                    Future
                      .fromTry(transportServiceFactory.get(connection))
                      .flatMap(_.getRemoteIssueUrl(tt.getLocalReplica.getIssueKey, connection))
                })
                  .map {
                    case Some(issueUrl) => issueUrl
                    case None           => null
                  }
              case _                              => Future.successful(null)
            }
          } else {
            Future.successful(null)
          }
        case None     => Future.successful(null)
      }
    )

}
