package com.exalate.replication.services.processor

object VariableNameScriptService {

  /*
  Identifiers start with a letter, a dollar or an underscore. They cannot start with a number.

  A letter can be in the following ranges:

  'a' to 'z' (lowercase ascii letter)

  'A' to 'Z' (uppercase ascii letter)

  '\u00C0' to '\u00D6'

  '\u00D8' to '\u00F6'

  '\u00F8' to '\u00FF'

  '\u0100' to '\uFFFE'

  Then following characters can contain letters and numbers.

  Here are a few examples of valid identifiers (here, variable names):
   */
  def isValidGroovyVariableName(str: String): Boolean =
    if (str.isEmpty) false
    else {
      val h = str.head
      val t = str.tail
      (isLetter(h) || isUnderscore(h) || isDollar(h)) &&
      (t.isEmpty || t.forall(c => isLetter(c) || isUnderscore(c) || isNumber(c) || isDollar(c)))
    }

  private def isLetter(c: Char): Boolean =
    (c >= 'A' && c <= 'Z') ||
      (c >= 'a' && c <= 'z') ||
      (c >= '\u00C0' && c <= '\u00D6') ||
      (c >= '\u00D8' && c <= '\u00F6') ||
      (c >= '\u00F8' && c <= '\u00FF') ||
      (c >= '\u0100' && c <= '\uFFFE')

  private def isUnderscore(c: Char): Boolean =
    c == '_'

  private def isDollar(c: Char): Boolean =
    c == '$'

  private def isNumber(c: Char): Boolean =
    c >= '0' && c <= '9'

  def getTripleQuoteSafe(str: String): String =
    str.replaceAll("\"\"\"", "\\\"\\\"\\\"")

  def getStringLiteralSafe(str: String): String =
    str.replaceAll("\"", "\\\"")

  def getVariableName(instanceName: String): String =
    if (isValidGroovyVariableName(instanceName)) instanceName
    else
      s"$instanceWrapperVariableName[" + "\"\"\"" + s"${getTripleQuoteSafe(instanceName)}" + "\"\"\"" + "]"

  lazy val instanceWrapperVariableName: String = "on"
}
