package com.exalate.replication.services.processor

import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.request.ISyncRequest
import com.exalate.api.persistence.relation.IRelationRepository
import com.exalate.api.persistence.replication.request.IRequestReplicationRepository
import com.exalate.api.persistence.twintrace.ITwinTraceRepository
import com.exalate.replication.services.api.config.IGeneralSettingsService
import com.exalate.replication.services.api.processor.ISyncHelperFactory
import com.exalate.replication.services.api.transport.ITransportServiceFactory
import com.exalate.replication.services.replication.EventSchedulerNotificationService
import com.google.inject.ImplementedBy

import javax.inject.Inject
import scala.concurrent.ExecutionContext

class SyncHelperFactory @Inject() (
    syncRequestReplication: IRequestReplicationRepository,
    eventSchedulerNotificationService: EventSchedulerNotificationService,
    twinTraceRepository: ITwinTraceRepository,
    connectionRepository: IRelationRepository,
    generalSettingsService: IGeneralSettingsService,
    transportServiceFactory: ITransportServiceFactory
)(implicit val executionContext: ExecutionContext)
    extends ISyncHelperFactory {

  override def getSyncHelper(connection: IConnection, syncRequest: ISyncRequest): Object =
    new SyncHelper(
      syncRequestReplication,
      eventSchedulerNotificationService,
      twinTraceRepository,
      connectionRepository,
      connection,
      syncRequest,
      generalSettingsService,
      transportServiceFactory
    )

  override def getSyncHelperReadOnly(connection: IConnection, syncRequest: ISyncRequest): Object = {
    val realSyncHelper = new SyncHelper(
      syncRequestReplication,
      eventSchedulerNotificationService,
      twinTraceRepository,
      connectionRepository,
      connection,
      syncRequest,
      generalSettingsService,
      transportServiceFactory
    )

    new SyncHelperReadOnly(realSyncHelper)
  }

}
