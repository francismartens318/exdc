package com.exalate.replication.services.processor

import java.util

import com.exalate.api.domain.IBlobMetadata
import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.request.ISyncRequest
import com.exalate.api.domain.twintrace.INonPersistentTrace
import com.exalate.basic.domain.hubobject.v1.BasicHubIssue

case class VisualRuleExecutionParams(
    connection: IConnection,
    traces: util.List[INonPersistentTrace],
    issue: BasicHubIssue,
    issueBeforeUpdating: BasicHubIssue,
    replica: BasicHubIssue,
    blobMetadataSeq: Seq[IBlobMetadata],
    context: util.HashMap[String, Object],
    syncRequest: ISyncRequest
)
