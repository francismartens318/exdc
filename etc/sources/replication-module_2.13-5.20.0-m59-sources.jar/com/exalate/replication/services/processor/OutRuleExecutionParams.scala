package com.exalate.replication.services.processor

import java.util

import com.exalate.api.domain.IIssueKey
import com.exalate.api.domain.connection.IConnection
import com.exalate.api.domain.hubobject.IHubIssueReplica

case class OutRuleExecutionParams(
    localIssueKey: IIssueKey,
    connection: IConnection,
    issue: IHubIssueReplica,
    replica: IHubIssueReplica,
    context: util.HashMap[String, Object]
)
