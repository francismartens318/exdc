package com.exalate.replication.services.processor.dryrun

import com.exalate.api.domain.IIssueKey
import com.exalate.api.domain.connection._
import com.exalate.api.domain.hubobject.IHubPayload
import com.exalate.api.domain.instance.{IInstanceIssueTrackerSettings, InstanceStatus}
import com.exalate.api.processor.IExalateProcessor
import com.exalate.basic.domain.connection.Connection
import com.exalate.basic.domain.instance.Instance
import com.exalate.basic.domain.nodeinfo.NodeInfo
import com.exalate.domain.processor.dryrun._
import com.exalate.domain.processor.log.LogEvent
import com.exalate.generic.services.api.ITrackerHubObjectService
import com.exalate.replication.services.api.processor.ICreateReplicaProcessor
import com.exalate.replication.services.processor.log.LoggerWrapper
import com.exalate.replication.services.processor.log.LoggingUtil.executeAndCollectLogs
import play.api.libs.json.{JsObject, Json}

import java.net.URL
import java.util.UUID
import javax.inject.Inject
import scala.concurrent.duration._
import scala.concurrent.{Await, ExecutionContext, Future, TimeoutException}
import scala.util.{Failure, Random, Success, Try}

class DryRunScriptService @Inject() (
    createReplicaProcessor: ICreateReplicaProcessor,
    exalateProcessor: IExalateProcessor,
    hubObjectService: ITrackerHubObjectService
) {

  def dryRunOutScript(
      dryRunOutScriptRequest: DryRunOutScriptRequest
  )(implicit ec: ExecutionContext): Future[IDryRunResultValue] =
    executeAndCollectLogs { loggerWrapper =>
      val connection = fakeConnection(Option(dryRunOutScriptRequest.script), None)
      val issueKeyOptFuture = hubObjectService.getLocalKey(
        dryRunOutScriptRequest.entityUrn,
        connection,
        dryRunOutScriptRequest.entityType,
        dryRunOutScriptRequest.fieldValues.orNull
      )
      issueKeyOptFuture.flatMap {
        case None           =>
          issueNotFound(dryRunOutScriptRequest, loggerWrapper)
        case Some(issueKey) =>
          val hubPayloadOptFuture =
            hubObjectService.getHubPayloadFromTracker(issueKey, connection, None)
          hubPayloadOptFuture.flatMap {
            case None                          =>
              issueNotFound(dryRunOutScriptRequest, loggerWrapper)
            case Some(hubPayload: IHubPayload) =>
              getCompilerErrors(dryRunOutScriptRequest) match {
                case Some(compilerFailure) =>
                  Future.successful(compilerFailure)
                case None                  =>
                  dryRunOutScript(
                    dryRunOutScriptRequest,
                    loggerWrapper,
                    connection,
                    issueKey,
                    hubPayload
                  )
              }
          }
      }
    }
      .map(_.result match {
        case Failure(e) =>
          FailedDueExceptionDryRunResultValue(
            ExceptionValue(e.getMessage, getStackTrace(e)),
            Seq.empty[LogEvent],
            dryRunOutScriptRequest.timeoutMillis
          )
        case Success(v) =>
          v
      })

  private def getCompilerErrors(dryRunOutScriptRequest: DryRunOutScriptRequest) =
    Try(exalateProcessor.compile(dryRunOutScriptRequest.script))
      .fold(e => Some(FailedDueCompilationDryRunResultValue(e.getMessage)), _ => None)

  private def dryRunOutScript(
      dryRunOutScriptRequest: DryRunOutScriptRequest,
      loggerWrapper: LoggerWrapper,
      connection: Connection,
      issueKey: IIssueKey,
      hubPayload: IHubPayload
  )(implicit ec: ExecutionContext): Future[IDryRunResultValue] =
    Future.fromTry(Try {
      val timedResult = measureTime {
        Await.result(
          createReplicaProcessor.createHubReplica(
            connection,
            hubPayload,
            issueKey,
            None
          ),
          dryRunOutScriptRequest.timeoutMillis.millis
        )
      }
      SuccessfulDryRunResultValue(
        DryRunVariableResult(
          (Json.parse(timedResult._1.getPayloadAsString) \ "hubIssue").as[JsObject]
        ),
        loggerWrapper.getLogEvents,
        timedResult._2
      )
    }) recover {
      case te: TimeoutException =>
        FailedDueTimeoutDryRunResultValue(
          getStackTrace(te),
          loggerWrapper.getLogEvents,
          dryRunOutScriptRequest.timeoutMillis
        )
      case e: Exception         =>
        FailedDueExceptionDryRunResultValue(
          ExceptionValue(e.getMessage, getStackTrace(e)),
          loggerWrapper.getLogEvents,
          0
        )
    }

  private def fakeConnection(outScriptOpt: Option[String], inScriptOpt: Option[String]) =
    new Connection(
      0,
      "dryRunOutScript",
      Option.empty[String].orNull,
      ConnectionStatus.ACTIVE,
      InvitationStatus.ACCEPTED,
      fakeInstance,
      outScriptOpt.orNull,
      Option.empty[String].orNull,
      Option.empty[String].orNull,
      Option.empty[IConnectionIssueTrackerSettings].orNull,
      Option.empty[String].orNull,
      Option.empty[String].orNull,
      false,
      false,
      SendProtocol.DIRECT_HTTP,
      ReceiveProtocol.DIRECT_HTTP,
      Random.nextString(32),
      inScriptOpt.orNull,
      "2",
      new java.util.HashMap[String, String]()
    )

  private def fakeInstance =
    new Instance(
      0,
      "dryRunOutScript",
      Option.empty[String].orNull,
      new URL("https://example.com"),
      new URL("https://example.com"),
      InstanceStatus.ACTIVE,
      fakeNodeInfo,
      Option.empty[IInstanceIssueTrackerSettings].orNull,
      Option.empty[String].orNull,
      Option.empty[String].orNull,
      false,
      Option.empty[String].orNull,
      new java.util.HashMap[String, String]()
    )

  private def fakeNodeInfo =
    new NodeInfo(
      0,
      "dryRunOutScript",
      "https://example.com",
      "https://example.com",
      "DRY_RUN",
      "5.2",
      "5.6.0",
      "1.0.0",
      "1.14.0",
      "1.0.0",
      "5.2.0",
      false,
      "5.6.0",
      UUID.randomUUID().toString,
      Option.empty[String].orNull,
      "https://example.com/favicon.ico",
      Option.empty[String].orNull
    )

  private def measureTime[A](block: => A): (A, Long) = {
    val startTime = System.nanoTime()
    val result = block
    val endTime = System.nanoTime()
    val duration = ((endTime - startTime) / 1e6).toLong // Convert to milliseconds
    (result, duration)
  }

  private def getStackTrace(e: Throwable): String = getStackTrace(e.getStackTrace)

  private def getStackTrace(e: Array[StackTraceElement]): String =
    e.mkString("", System.lineSeparator(), System.lineSeparator())

  private def issueNotFound(
      dryRunOutScriptRequest: DryRunOutScriptRequest,
      loggerWrapper: LoggerWrapper
  ) =
    Future.successful(
      FailedDueExceptionDryRunResultValue(
        ExceptionValue(
          s"${dryRunOutScriptRequest.entityType} ${dryRunOutScriptRequest.entityUrn} not found",
          getStackTrace(Thread.currentThread().getStackTrace)
        ),
        loggerWrapper.getLogEvents,
        dryRunOutScriptRequest.timeoutMillis
      )
    )

}
