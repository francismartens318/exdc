package com.exalate.replication.services.processor

import java.nio.file.Path
import com.exalate.api.processor.IClassPathProvider
import com.exalate.replication.services.api.node.filesystem.IFileSystemService
import play.api.Logger

import java.util
import javax.inject.Inject
import scala.util.{Failure, Success}

class FileSystemClassPathProvider @Inject() (fileSystemService: IFileSystemService)
    extends IClassPathProvider {

  val LOG: Logger = Logger(classOf[FileSystemClassPathProvider])

  override lazy val getAdditionalClassPaths: java.util.List[Path] =
    fileSystemService.getExalateScriptsPath() match {
      case Failure(exception) =>
        LOG.error("Error while getting exalate scripts path", exception)
        util.Collections.emptyList[Path]
      case Success(value)     =>
        util.Arrays.asList(value)
    }

}
