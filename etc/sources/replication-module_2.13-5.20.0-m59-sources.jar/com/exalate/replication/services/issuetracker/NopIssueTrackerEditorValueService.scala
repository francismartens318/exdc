package com.exalate.replication.services.issuetracker

import com.exalate.domain.values.{FeatureValue, VisualFieldValue}
import com.exalate.replication.services.api.issuetracker.IIssueTrackerEditorValueService

import scala.concurrent.Future

class NopIssueTrackerEditorValueService extends IIssueTrackerEditorValueService {

  override def get(features: Option[Seq[FeatureValue]]): Future[Option[VisualFieldValue]] =
    Future.successful(None)

}
