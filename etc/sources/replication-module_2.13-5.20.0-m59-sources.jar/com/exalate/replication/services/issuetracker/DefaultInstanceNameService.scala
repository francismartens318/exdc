package com.exalate.replication.services.issuetracker

import com.exalate.api.ILoggingService
import com.exalate.replication.services.api.config.IGeneralSettingsService
import com.exalate.replication.services.api.issuetracker.IInstanceNameService
import com.exalate.replication.services.transport.v1.rest.NodeInfoProvider
import com.google.inject.Inject

import scala.concurrent.{ExecutionContext, Future}

class DefaultInstanceNameService @Inject() (
    generalSettingsService: IGeneralSettingsService,
    loggingService: ILoggingService
)(implicit ec: ExecutionContext)
    extends IInstanceNameService {

  override def generateLocalInstanceName(): Future[String] = {
    /*
 This pattern extract a name of the instance from issue tracker url
 For example: https://support.idalko.com/ -> the output will be "support"
     */
    val pattern = "(?<=\\/\\/)[^\\.]+".r
    for {
      settingsOpt <- generalSettingsService.get
      instanceName <- settingsOpt match {
        case None           =>
          loggingService.error(s"No general settings configured.")
          Future.successful("")
        case Some(settings) =>
          val urlOpt = Option(settings.getIssueTrackerUrl)
          val instanceName = urlOpt.flatMap(url => pattern.findFirstIn(url)).getOrElse("")
          Future.successful(instanceName)
      }
    } yield instanceName
  }

}
