package com.exalate.replication.services.issuetracker.readonlyclient

import com.exalate.api.domain.issuetracker.Response
import com.exalate.api.exception.script.ScriptException
import com.exalate.replication.services.api.issuetracker.IHttpClient
import com.exalate.replication.services.issuetracker.HttpClient
import com.google.inject.Inject
import groovy.lang.Closure

class HttpClientReadOnly @Inject() (httpClient: HttpClient)
    extends GroovyHttpClientReadOnly
      with IHttpClient {

  def http[R](
      method: String,
      path: String,
      body: String = null,
      queryParameters: java.util.Map[String, java.util.List[String]] = null,
      headers: java.util.Map[String, java.util.List[String]] = null,
      handleResponse: Closure[R]
  ): R = throw new ScriptException(
    s"`$method` request not allowed on Read Only operations. \nPath: $path\nBody: $body\nQuery Parameters: $queryParameters\n Headers: $headers"
  )

  def get[R](
      path: String,
      queryParameters: java.util.Map[String, java.util.List[String]],
      headers: java.util.Map[String, java.util.List[String]],
      handleResponse: Closure[R]
  ): R = httpClient.get(path, queryParameters, headers, handleResponse)

  def get(path: String): Object = httpClient.get(path)

  def get(
      path: String,
      queryParameters: java.util.Map[String, java.util.List[String]],
      headers: java.util.Map[String, java.util.List[String]]
  ): Object =
    httpClient.get(path, queryParameters, headers)

  def getResponse(path: String): Response = httpClient.getResponse(path)

  def getResponse(
      path: String,
      queryParameters: java.util.Map[String, java.util.List[String]],
      headers: java.util.Map[String, java.util.List[String]]
  ): Response = httpClient.getResponse(path, queryParameters, headers)

  def getOrThrow(path: String): Object = httpClient.getOrThrow(path)

  def getOrThrow(
      path: String,
      queryParameters: java.util.Map[String, java.util.List[String]],
      headers: java.util.Map[String, java.util.List[String]]
  ): Object = httpClient.getOrThrow(path, queryParameters, headers)

  def post[R](
      path: String,
      body: String,
      queryParameters: java.util.Map[String, java.util.List[String]],
      headers: java.util.Map[String, java.util.List[String]],
      handleResponse: Closure[R]
  ): R = throw new ScriptException(
    s"`POST` request not allowed on Read Only operations. \nPath: $path\nBody: $body\nQuery Parameters: $queryParameters\n Headers: $headers"
  )

  def post(path: String, body: String): Object = throw new ScriptException(
    s"`POST` request not allowed on Read Only operations. \nPath: $path\nBody: $body"
  )

  def post(
      path: String,
      body: String,
      queryParameters: java.util.Map[String, java.util.List[String]],
      headers: java.util.Map[String, java.util.List[String]]
  ): Object = throw new ScriptException(
    s"`POST` request not allowed on Read Only operations. \nPath: $path\nBody: $body\nQuery Parameters: $queryParameters\n Headers: $headers"
  )

  def postOrThrow(path: String, body: String): Object = throw new ScriptException(
    s"`POST` request not allowed on Read Only operations. \nPath: $path\nBody: $body"
  )

  def postOrThrow(
      path: String,
      body: String,
      queryParameters: java.util.Map[String, java.util.List[String]],
      headers: java.util.Map[String, java.util.List[String]]
  ): Object =
    throw new ScriptException(
      s"`POST` request not allowed on Read Only operations. \nPath: $path\nBody: $body\nQuery Parameters: $queryParameters\n Headers: $headers"
    )

  def postResponse(path: String, body: String): Object = throw new ScriptException(
    s"`POST` response not allowed on Read Only operations. \nPath: $path\nBody: $body"
  )

  def postResponse(
      path: String,
      body: String,
      queryParameters: java.util.Map[String, java.util.List[String]],
      headers: java.util.Map[String, java.util.List[String]]
  ): Object = throw new ScriptException(
    s"`POST` request not allowed on Read Only operations. \nPath: $path\nBody: $body\nQuery Parameters: $queryParameters\n Headers: $headers"
  )

  def put[R](
      path: String,
      body: String,
      queryParameters: java.util.Map[String, java.util.List[String]],
      headers: java.util.Map[String, java.util.List[String]],
      handleResponse: Closure[R]
  ): R = throw new ScriptException(
    s"`PUT` request not allowed on Read Only operations. \nPath: $path\nBody: $body\nQuery Parameters: $queryParameters\n Headers: $headers"
  )

  def put(path: String, body: String): Object =
    throw new ScriptException(
      s"`PUT` request not allowed on Read Only operations. \nPath: $path\nBody: $body"
    )

  def put(
      path: String,
      body: String,
      queryParameters: java.util.Map[String, java.util.List[String]],
      headers: java.util.Map[String, java.util.List[String]]
  ): Object =
    throw new ScriptException(
      s"`PUT` request not allowed on Read Only operations. \nPath: $path\nBody: $body\nQuery Parameters: $queryParameters\n Headers: $headers"
    )

  def putOrThrow(path: String, body: String): Object =
    throw new ScriptException(
      s"`PUT` request not allowed on Read Only operations. \nPath: $path\nBody: $body"
    )

  def putOrThrow(
      path: String,
      body: String,
      queryParameters: java.util.Map[String, java.util.List[String]],
      headers: java.util.Map[String, java.util.List[String]]
  ): Object = throw new ScriptException(
    s"`PUT` request not allowed on Read Only operations. \nPath: $path\nBody: $body\nQuery Parameters: $queryParameters\n Headers: $headers"
  )

  def putResponse(path: String, body: String): Object =
    throw new ScriptException(
      s"`PUT` request not allowed on Read Only operations. \nPath: $path\nBody: $body"
    )

  def putResponse(
      path: String,
      body: String,
      queryParameters: java.util.Map[String, java.util.List[String]],
      headers: java.util.Map[String, java.util.List[String]]
  ): Object =
    throw new ScriptException(
      s"`PUT` request not allowed on Read Only operations. \nPath: $path\nBody: $body\nQuery Parameters: $queryParameters\n Headers: $headers"
    )

  def patch[R](
      path: String,
      body: String,
      queryParameters: java.util.Map[String, java.util.List[String]],
      headers: java.util.Map[String, java.util.List[String]],
      handleResponse: Closure[R]
  ): R =
    http[R](
      "PATCH",
      path,
      body,
      queryParameters,
      headers,
      handleResponse
    )

  def patch(path: String, body: String): Object =
    throw new ScriptException(
      s"`PATCH` request not allowed on Read Only operations. \nPath: $path\nBody: $body"
    )

  def patch(
      path: String,
      body: String,
      queryParameters: java.util.Map[String, java.util.List[String]],
      headers: java.util.Map[String, java.util.List[String]]
  ): Object =
    throw new ScriptException(
      s"`PATCH` request not allowed on Read Only operations. \nPath: $path\nBody: $body\nQuery Parameters: $queryParameters\n Headers: $headers"
    )

  def patchOrThrow(path: String, body: String): Object =
    throw new ScriptException(
      s"`PATCH` request not allowed on Read Only operations. \nPath: $path\nBody: $body"
    )

  def patchOrThrow(
      path: String,
      body: String,
      queryParameters: java.util.Map[String, java.util.List[String]],
      headers: java.util.Map[String, java.util.List[String]]
  ): Object =
    throw new ScriptException(
      s"`PATCH` request not allowed on Read Only operations. \nPath: $path\nBody: $body\nQuery Parameters: $queryParameters\n Headers: $headers"
    )

  def patchResponse(path: String, body: String): Response =
    throw new ScriptException(
      s"`PATCH` request not allowed on Read Only operations. \nPath: $path\nBody: $body"
    )

  def patchResponse(
      path: String,
      body: String,
      queryParameters: java.util.Map[String, java.util.List[String]],
      headers: java.util.Map[String, java.util.List[String]]
  ): Response =
    throw new ScriptException(
      s"`PATCH` request not allowed on Read Only operations. \nPath: $path\nBody: $body\nQuery Parameters: $queryParameters\n Headers: $headers"
    )

  def delete[R](path: String, handleResponse: Closure[R]): R =
    http[R](
      "DELETE",
      path,
      null,
      null,
      null,
      handleResponse
    )

}
