package com.exalate.replication.services.issuetracker

import com.exalate.annotations.llm.{LlmClass, LlmMethod}
import com.exalate.api.domain.node.ConnectorNames._
import com.exalate.api.domain.issuetracker.{Request, Response}
import com.exalate.api.exception.IssueTrackerException
import com.exalate.replication.services.api.issuetracker.{IHttpClient, IIssueTrackerClient}
import com.exalate.services.utils.logging.IssueTrackerClientLoggerFilterFactory
import com.exalate.services.utils.{CollectionService, FutureUtils}
import com.google.inject.Inject
import groovy.lang.Closure
import play.api.Logger
import play.api.libs.ws._
import play.mvc.Http.{HeaderNames, MimeTypes}

import scala.concurrent.ExecutionContext
import scala.jdk.CollectionConverters._

//noinspection ScalaUnusedSymbol
@LlmClass(
  connectors = Array(AZURE_DEVOPS, GITHUB, JCLOUD, SERVICE_NOW, SALESFORCE, ZENDESK),
  description =
    "A Scala-based HTTP client for interacting with issue trackers, providing methods for HTTP operations and response handling."
)
class HttpClient @Inject() (
    issueTrackerClient: IIssueTrackerClient,
    ws: WSClient,
    issueTrackerClientLoggerFilterFactory: IssueTrackerClientLoggerFilterFactory
)(implicit ec: ExecutionContext)
    extends GroovyHttpClient(ws, issueTrackerClientLoggerFilterFactory)(ec)
      with IHttpClient {

  import HttpClient._

  @LlmMethod(
    description =
      "Performs an HTTP request using the specified method, path, body, query parameters, headers, and response handler."
  )
  def http[R](
      method: String,
      path: String,
      body: String = null,
      queryParameters: java.util.Map[String, java.util.List[String]] = null,
      headers: java.util.Map[String, java.util.List[String]] = null,
      handleResponse: Closure[R]
  ): R = {
    val wsResponse = FutureUtils.resultInf(
      issueTrackerClient.http(
        method,
        path,
        Option(body),
        CollectionService.toScalaMapOpt(queryParameters),
        CollectionService.toScalaMapOpt(headers)
      )
    )
    val request = Request(method, path)
    val response = toHcResponse(wsResponse)
    handleResponse.call(request, response)
  }

  @LlmMethod(
    description =
      "Performs an HTTP GET request using the specified path, query parameters, headers, and response handler"
  )
  def get[R](
      path: String,
      queryParameters: java.util.Map[String, java.util.List[String]],
      headers: java.util.Map[String, java.util.List[String]],
      handleResponse: Closure[R]
  ): R = {
    val wsResponse = FutureUtils.resultInf(
      issueTrackerClient.http(
        "GET",
        path,
        qParamOpt = CollectionService.toScalaMapOpt(queryParameters),
        headersOpt = CollectionService.toScalaMapOpt(headers)
      )
    )
    val request = Request("GET", path)
    val response = toHcResponse(wsResponse)
    handleResponse.call(request, response)
  }

  @LlmMethod(
    description = "Performs an HTTP GET request using the specified path. " +
      "Uses the default response handler. Returns null in case of failure"
  )
  def get(path: String): Object =
    get[Object](
      path,
      null,
      null,
      fnToClosure(handleResponse((_, _, _) => null))
    )

  @LlmMethod(
    description =
      "Performs an HTTP GET request using the specified path, query parameters, and headers. " +
        "Uses the default response handler. Returns null in case of failure"
  )
  def get(
      path: String,
      queryParameters: java.util.Map[String, java.util.List[String]],
      headers: java.util.Map[String, java.util.List[String]]
  ): Object =
    get[Object](
      path,
      queryParameters,
      headers,
      fnToClosure(handleResponse((_, _, _) => null))
    )

  @LlmMethod(
    description = "Performs an HTTP GET request using the specified path"
  )
  def getResponse(path: String): Response =
    get[Response](
      path,
      null,
      null,
      fnToClosure((_, r) => r)
    )

  @LlmMethod(
    description =
      "Performs an HTTP GET request using the specified path, query parameters, and headers"
  )
  def getResponse(
      path: String,
      queryParameters: java.util.Map[String, java.util.List[String]],
      headers: java.util.Map[String, java.util.List[String]]
  ): Response =
    get[Response](
      path,
      queryParameters,
      headers,
      fnToClosure((_, r) => r)
    )

  @LlmMethod(
    description = "Performs an HTTP GET request using the specified path. " +
      "Uses the default response handler. Throws an IssueTrackerException in case of failure"
  )
  def getOrThrow(path: String): Object =
    get[Object](
      path,
      null,
      null,
      fnToClosure(handleResponse((msg, _, _) => throw new IssueTrackerException(msg)))
    )

  @LlmMethod(
    description =
      "Performs an HTTP GET request using the specified path, query parameters, and headers." +
        "Uses the default response handler. Throws an IssueTrackerException in case of failure"
  )
  def getOrThrow(
      path: String,
      queryParameters: java.util.Map[String, java.util.List[String]],
      headers: java.util.Map[String, java.util.List[String]]
  ): Object =
    get[Object](
      path,
      queryParameters,
      headers,
      fnToClosure(handleResponse((msg, _, _) => throw new IssueTrackerException(msg)))
    )

  @LlmMethod(
    description =
      "Performs an HTTP POST request using the specified path, body, query parameters, headers, and response handler."
  )
  def post[R](
      path: String,
      body: String,
      queryParameters: java.util.Map[String, java.util.List[String]],
      headers: java.util.Map[String, java.util.List[String]],
      handleResponse: Closure[R]
  ): R =
    http[R](
      "POST",
      path,
      body,
      queryParameters,
      headers,
      handleResponse
    )

  @LlmMethod(
    description = "Performs an HTTP POST request using the specified path and body." +
      "Uses the default response handler. Returns null in case of failure"
  )
  def post(path: String, body: String): Object =
    post[Object](
      path,
      body,
      null,
      Map(HeaderNames.CONTENT_TYPE -> Seq(MimeTypes.JSON).asJava).asJava,
      fnToClosure(handleResponse((msg, _, _) => null))
    )

  @LlmMethod(
    description =
      "Performs an HTTP POST request using the specified path, body, query parameters, and headers. " +
        "Uses the default response handler. Returns null in case of failure"
  )
  def post(
      path: String,
      body: String,
      queryParameters: java.util.Map[String, java.util.List[String]],
      headers: java.util.Map[String, java.util.List[String]]
  ): Object =
    post[Object](
      path,
      body,
      queryParameters,
      headers,
      fnToClosure(handleResponse((msg, _, _) => null))
    )

  @LlmMethod(
    description = "Performs an HTTP POST request using the specified path and body. " +
      "Uses the default response handler. Throws an IssueTrackerException in case of failure"
  )
  def postOrThrow(path: String, body: String): Object =
    post[Object](
      path,
      body,
      null,
      Map(HeaderNames.CONTENT_TYPE -> Seq(MimeTypes.JSON).asJava).asJava,
      fnToClosure(handleResponse((msg, _, _) => throw new IssueTrackerException(msg)))
    )

  @LlmMethod(
    description =
      "Performs an HTTP POST request using the specified path, body, query parameters, and headers. " +
        "Uses the default response handler. Throws an IssueTrackerException in case of failure"
  )
  def postOrThrow(
      path: String,
      body: String,
      queryParameters: java.util.Map[String, java.util.List[String]],
      headers: java.util.Map[String, java.util.List[String]]
  ): Object =
    post[Object](
      path,
      body,
      queryParameters,
      headers,
      fnToClosure(handleResponse((msg, _, _) => throw new IssueTrackerException(msg)))
    )

  @LlmMethod(
    description =
      "Performs an HTTP POST request using the specified path, body, query parameters, headers, and response handler."
  )
  def postResponse(path: String, body: String): Object =
    post[Response](
      path,
      body,
      null,
      Map(HeaderNames.CONTENT_TYPE -> Seq(MimeTypes.JSON).asJava).asJava,
      fnToClosure((_, r) => r)
    )

  @LlmMethod(
    description =
      "Performs an HTTP POST request using the specified path, body, query parameters, and headers."
  )
  def postResponse(
      path: String,
      body: String,
      queryParameters: java.util.Map[String, java.util.List[String]],
      headers: java.util.Map[String, java.util.List[String]]
  ): Object =
    post[Response](
      path,
      body,
      queryParameters,
      headers,
      fnToClosure((_, r) => r)
    )

  @LlmMethod(
    description =
      "Performs an HTTP PUT request using the specified path, body, query parameters, headers, and response handler."
  )
  def put[R](
      path: String,
      body: String,
      queryParameters: java.util.Map[String, java.util.List[String]],
      headers: java.util.Map[String, java.util.List[String]],
      handleResponse: Closure[R]
  ): R = http[R](
    "PUT",
    path,
    body,
    queryParameters,
    headers,
    handleResponse
  )

  @LlmMethod(
    description = "Performs an HTTP PUT request using the specified path and body. " +
      "Uses the default response handler. Returns null in case of failure"
  )
  def put(path: String, body: String): Object =
    put[Object](
      path,
      body,
      null,
      Map(HeaderNames.CONTENT_TYPE -> Seq(MimeTypes.JSON).asJava).asJava,
      fnToClosure(handleResponse((msg, _, _) => null))
    )

  @LlmMethod(
    description =
      "Performs an HTTP PUT request using the specified path, body, query parameters, and headers. " +
        "Uses the default response handler. Returns null in case of failure"
  )
  def put(
      path: String,
      body: String,
      queryParameters: java.util.Map[String, java.util.List[String]],
      headers: java.util.Map[String, java.util.List[String]]
  ): Object =
    put[Object](
      path,
      body,
      queryParameters,
      headers,
      fnToClosure(handleResponse((msg, _, _) => null))
    )

  @LlmMethod(
    description =
      "Performs an HTTP PUT request using the specified path, body, query parameters, headers, and response handle. " +
        "Uses the default response handler. Throws an IssueTrackerException in case of failure"
  )
  def putOrThrow(path: String, body: String): Object =
    put[Object](
      path,
      body,
      null,
      Map(HeaderNames.CONTENT_TYPE -> Seq(MimeTypes.JSON).asJava).asJava,
      fnToClosure(handleResponse((msg, _, _) => throw new IssueTrackerException(msg)))
    )

  @LlmMethod(
    description =
      "Performs an HTTP PUT request using the specified path, body, query parameters, and headers. " +
        "Uses the default response handler. Throws an IssueTrackerException in case of failure"
  )
  def putOrThrow(
      path: String,
      body: String,
      queryParameters: java.util.Map[String, java.util.List[String]],
      headers: java.util.Map[String, java.util.List[String]]
  ): Object =
    put[Object](
      path,
      body,
      queryParameters,
      headers,
      fnToClosure(handleResponse((msg, _, _) => throw new IssueTrackerException(msg)))
    )

  @LlmMethod(
    description = "Performs an HTTP PUT request using the specified path and body"
  )
  def putResponse(path: String, body: String): Object =
    put[Response](
      path,
      body,
      null,
      Map(HeaderNames.CONTENT_TYPE -> Seq(MimeTypes.JSON).asJava).asJava,
      fnToClosure((_, r) => r)
    )

  @LlmMethod(
    description =
      "Performs an HTTP PUT request using the specified path, body, query parameters, and headers. "
  )
  def putResponse(
      path: String,
      body: String,
      queryParameters: java.util.Map[String, java.util.List[String]],
      headers: java.util.Map[String, java.util.List[String]]
  ): Object =
    put[Response](
      path,
      body,
      queryParameters,
      headers,
      fnToClosure((_, r) => r)
    )

  @LlmMethod(
    description =
      "Performs an HTTP PATCH request using the specified path, body, query parameters, headers, and response handler."
  )
  def patch[R](
      path: String,
      body: String,
      queryParameters: java.util.Map[String, java.util.List[String]],
      headers: java.util.Map[String, java.util.List[String]],
      handleResponse: Closure[R]
  ): R =
    http[R](
      "PATCH",
      path,
      body,
      queryParameters,
      headers,
      handleResponse
    )

  @LlmMethod(
    description = "Performs an HTTP PATCH request using the specified path and body. " +
      "Uses the default response handler. Returns null in case of failure"
  )
  def patch(path: String, body: String): Object =
    patch[Object](
      path,
      body,
      null,
      Map(HeaderNames.CONTENT_TYPE -> Seq(MimeTypes.JSON).asJava).asJava,
      fnToClosure(handleResponse((msg, _, _) => null))
    )

  @LlmMethod(
    description =
      "Performs an HTTP PATCH request using the specified path, body, query parameters, and headers. " +
        "Uses the default response handler. Returns null in case of failure"
  )
  def patch(
      path: String,
      body: String,
      queryParameters: java.util.Map[String, java.util.List[String]],
      headers: java.util.Map[String, java.util.List[String]]
  ): Object =
    patch[Object](
      path,
      body,
      queryParameters,
      headers,
      fnToClosure(handleResponse((msg, _, _) => null))
    )

  @LlmMethod(
    description = "Performs an HTTP PATCH request using the specified path and body. " +
      "Uses the default response handler. Throws an IssueTrackerException in case of failure"
  )
  def patchOrThrow(path: String, body: String): Object =
    patch[Object](
      path,
      body,
      null,
      Map(HeaderNames.CONTENT_TYPE -> Seq(MimeTypes.JSON).asJava).asJava,
      fnToClosure(handleResponse((msg, _, _) => throw new IssueTrackerException(msg)))
    )

  @LlmMethod(
    description =
      "Performs an HTTP PATCH request using the specified path, body, query parameters, and headers. " +
        "Uses the default response handler. Throws an IssueTrackerException in case of failure"
  )
  def patchOrThrow(
      path: String,
      body: String,
      queryParameters: java.util.Map[String, java.util.List[String]],
      headers: java.util.Map[String, java.util.List[String]]
  ): Object =
    patch[Object](
      path,
      body,
      queryParameters,
      headers,
      fnToClosure(handleResponse((msg, _, _) => throw new IssueTrackerException(msg)))
    )

  @LlmMethod(
    description = "Performs an HTTP PATCH request using the specified path and body."
  )
  def patchResponse(path: String, body: String): Response =
    patch[Response](
      path,
      body,
      null,
      Map(HeaderNames.CONTENT_TYPE -> Seq(MimeTypes.JSON).asJava).asJava,
      fnToClosure((_, r) => r)
    )

  @LlmMethod(
    description =
      "Performs an HTTP PATCH request using the specified path, body, query parameters, and headers."
  )
  def patchResponse(
      path: String,
      body: String,
      queryParameters: java.util.Map[String, java.util.List[String]],
      headers: java.util.Map[String, java.util.List[String]]
  ): Response =
    patch[Response](
      path,
      body,
      queryParameters,
      headers,
      fnToClosure((_, r) => r)
    )

  @LlmMethod(
    description = "Performs an HTTP DELETE request using the specified path and response handler."
  )
  def delete[R](path: String, handleResponse: Closure[R]): R =
    http[R](
      "DELETE",
      path,
      null,
      null,
      null,
      handleResponse
    )

}

object HttpClient {
  private val CLIENT_LOG = Logger(classOf[HttpClient])

  private def toHcResponse(wsResponse: WSResponse): Response =
    Response(
      wsResponse.status,
      Option(wsResponse.body),
      CollectionService.toJavaBody,
      Option(wsResponse.headers.view.mapValues(_.toSeq).toMap)
    )

  @LlmMethod(
    description = "Handles HTTP responses.  " +
      "Logs errors if the response code is >= 400, otherwise returns the response body. " +
      "Default response handler",
    isStatic = true
  )
  def handleResponse(
      handleFailedResponse: (String, Request, Response) => Null
  )(request: Request, response: Response): Object =
    if (response.code >= 400) {
      val msg = s"${request.method} request to ${request.path} ${request.body
          .map(b => s"with body:\n$b\n")
          .getOrElse("")}failed with status ${response.code} and response body: \n${response.bodyStrOpt.orNull}"
      CLIENT_LOG.error(msg)
      handleFailedResponse(msg, request, response)
    } else {
      response.getBody()
    }

  private def fnToClosure[R](fn: (Request, Response) => R): Closure[R] = new Closure[R](null) {

    override def call(args: Object*): R = {
      val req = args.head.asInstanceOf[Request]
      val res = args.tail.head.asInstanceOf[Response]
      fn(req, res)
    }

  }

}
