package com.exalate.replication.services.issuetracker

import com.exalate.replication.services.api.config.IGeneralSettingsService
import com.exalate.replication.services.api.issuetracker.IIssueTrackerUrlService
import com.exalate.util.UrlUtils
import com.google.inject.Inject

import java.util.UUID
import scala.concurrent.{ExecutionContext, Future}

class DefaultIssueTrackerUrlService @Inject() (generalSettingsService: IGeneralSettingsService)(
    implicit ec: ExecutionContext
) extends IIssueTrackerUrlService {

  /** Returns the base url which points stores the favicon.ico. If base url is same as issue tracker
    * url, should return None. This is implemented due to some issue trackers having a unique
    * endpoint for getting favicon.ico file, such as Azure Devops.
    *
    * @return
    */
  override def iconUrl: Option[String] = None

  override def getRedirectUrl(
      issueTrackerUrl: String,
      invitationId: String,
      remoteExalateUrlOpt: Option[String]
  ): Option[String] = {
    val exalateNodeConnectionPage = s"/connections?invitation=$invitationId"
    remoteExalateUrlOpt.map(remoteExalateUrl =>
      UrlUtils.concat(remoteExalateUrl, exalateNodeConnectionPage)
    )
  }

  override def getSuccessUrl(): Future[Option[String]] =
    generalSettingsService.get.map(
      _.flatMap(gs => gs.getExalateUrl.map(exalateUrl => UrlUtils.concat(exalateUrl, "license")))
    )

}
