package com.exalate.replication.services.issuetracker

import com.exalate.domain.values.VisualFieldValue
import com.exalate.replication.services.api.issuetracker.IIssueTrackerBasicNonEditorValueService

import scala.concurrent.Future

class NopIssueTrackerBasicNonEditorValueService extends IIssueTrackerBasicNonEditorValueService {
  override def get(): Future[Option[VisualFieldValue]] = Future.successful(None)
}
