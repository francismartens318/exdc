package com.exalate.replication.services.issuetracker

import com.exalate.domain.InferredGeneralSettings
import com.exalate.replication.services.api.issuetracker.rest.IIssueTrackerVersionClient

import scala.concurrent.Future

class IssueTrackerVersionClient extends IIssueTrackerVersionClient {

  override def getSiteVersionsJsonString(sett: InferredGeneralSettings): Future[String] =
    Future.successful("7.0.0")

}
