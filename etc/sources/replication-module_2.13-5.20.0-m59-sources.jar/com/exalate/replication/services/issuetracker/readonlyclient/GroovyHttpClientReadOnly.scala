package com.exalate.replication.services.issuetracker.readonlyclient

import akka.stream.scaladsl.Source
import akka.util.ByteString
import com.exalate.domain.http.{
  GroovyHttpRequest,
  GroovyHttpResponse,
  MultiPartUploadGroovyHttpRequest,
  StreamingGroovyHttpResponse
}
import com.exalate.replication.services.api.issuetracker.IHttpClient
import com.exalate.services.utils.logging.config.WsLoggingConfig

import scala.concurrent.duration.Duration

class GroovyHttpClientReadOnly extends IHttpClient {

  private val fakeResponse = new GroovyHttpResponse(200, null, null, null)
  private val fakeNotAllowedResponse = new GroovyHttpResponse(405, null, null, null)

  private val fakeStreamingResponse = new StreamingGroovyHttpResponse(
    200,
    null,
    Source(
      List(ByteString("response"))
    )
  )

  def uploadMultiPart(request: MultiPartUploadGroovyHttpRequest): GroovyHttpResponse =
    fakeNotAllowedResponse

  def uploadMultiPart(
      request: MultiPartUploadGroovyHttpRequest,
      timeOut: Duration
  ): GroovyHttpResponse =
    fakeNotAllowedResponse

  def download(request: GroovyHttpRequest): StreamingGroovyHttpResponse =
    fakeStreamingResponse

  def download(request: GroovyHttpRequest, timeOut: Duration): StreamingGroovyHttpResponse =
    fakeStreamingResponse

  def http(request: GroovyHttpRequest): GroovyHttpResponse =
    fakeResponse

  /** please, use this method for uploading attachments and specify in logging config not to log
    * request (for attachment upload) and not to log response (for attachment body fetch)
    */
  def http(
      request: GroovyHttpRequest,
      loggingConfig: WsLoggingConfig,
      timeOut: Duration
  ): GroovyHttpResponse = fakeResponse

}
