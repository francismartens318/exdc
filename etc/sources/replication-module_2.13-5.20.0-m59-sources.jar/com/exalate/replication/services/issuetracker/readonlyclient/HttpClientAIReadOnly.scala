package com.exalate.replication.services.issuetracker.readonlyclient

import com.exalate.api.domain.issuetracker.{Request, Response}
import com.exalate.api.exception.IssueTrackerException
import com.exalate.replication.services.issuetracker.HttpClient
import com.exalate.services.utils.CollectionService
import com.google.inject.Inject
import groovy.lang.Closure
import play.api.Logger
import play.mvc.Http.{HeaderNames, MimeTypes}

import scala.jdk.CollectionConverters._
import java.util

class HttpClientAIReadOnly @Inject() (httpClient: HttpClient) extends HttpClientReadOnly(httpClient) {
  private val CLIENT_LOG = Logger(classOf[HttpClient])

  override def patch[R](
      path: String,
      body: String,
      queryParameters: java.util.Map[String, java.util.List[String]],
      headers: java.util.Map[String, java.util.List[String]],
      handleResponse: Closure[R]
  ): R =
    http[R](
      "PATCH",
      path,
      body,
      queryParameters,
      headers,
      handleResponse
    )

  override def http[R](
      method: String,
      path: String,
      body: String = null,
      queryParameters: java.util.Map[String, java.util.List[String]] = null,
      headers: java.util.Map[String, java.util.List[String]] = null,
      handleResponse: Closure[R]
  ): R = {
    val request = Request(method, path)
    val response =
      Response(200, Some(s"$method not allowed for AI script"), CollectionService.toJavaBody, None)
    handleResponse.call(request, response)
  }

  override def delete[R](path: String, handleResponse: Closure[R]): R =
    http[R](
      "DELETE",
      path,
      null,
      null,
      null,
      handleResponse
    )

  override def post[R](
      path: String,
      body: String,
      queryParameters: util.Map[String, util.List[String]],
      headers: util.Map[String, util.List[String]],
      handleResponse: Closure[R]
  ): R =
    http[R](
      "POST",
      path,
      body,
      queryParameters,
      headers,
      handleResponse
    )

  override def post(path: String, body: String): Object =
    post[Object](
      path,
      body,
      null,
      Map(HeaderNames.CONTENT_TYPE -> Seq(MimeTypes.JSON).asJava).asJava,
      fnToClosure(handleResponse((msg, _, _) => null))
    )

  override def post(
      path: String,
      body: String,
      queryParameters: java.util.Map[String, java.util.List[String]],
      headers: java.util.Map[String, java.util.List[String]]
  ): Object =
    post[Object](
      path,
      body,
      null,
      Map(HeaderNames.CONTENT_TYPE -> Seq(MimeTypes.JSON).asJava).asJava,
      fnToClosure(handleResponse((msg, _, _) => null))
    )

  override def postOrThrow(path: String, body: String): Object =
    post[Object](
      path,
      body,
      null,
      Map(HeaderNames.CONTENT_TYPE -> Seq(MimeTypes.JSON).asJava).asJava,
      fnToClosure(handleResponse((msg, _, _) => throw new IssueTrackerException(msg)))
    )

  override def postOrThrow(
      path: String,
      body: String,
      queryParameters: java.util.Map[String, java.util.List[String]],
      headers: java.util.Map[String, java.util.List[String]]
  ): Object =
    post[Object](
      path,
      body,
      queryParameters,
      headers,
      fnToClosure(handleResponse((msg, _, _) => throw new IssueTrackerException(msg)))
    )

  override def postResponse(path: String, body: String): Object =
    post[Response](
      path,
      body,
      null,
      Map(HeaderNames.CONTENT_TYPE -> Seq(MimeTypes.JSON).asJava).asJava,
      fnToClosure((_, r) => r)
    )

  override def postResponse(
      path: String,
      body: String,
      queryParameters: java.util.Map[String, java.util.List[String]],
      headers: java.util.Map[String, java.util.List[String]]
  ): Object =
    post[Response](
      path,
      body,
      queryParameters,
      headers,
      fnToClosure((_, r) => r)
    )

  override def put[R](
      path: String,
      body: String,
      queryParameters: java.util.Map[String, java.util.List[String]],
      headers: java.util.Map[String, java.util.List[String]],
      handleResponse: Closure[R]
  ): R =
    http[R](
      "PUT",
      path,
      body,
      queryParameters,
      headers,
      handleResponse
    )

  override def put(path: String, body: String): Object =
    put[Object](
      path,
      body,
      null,
      Map(HeaderNames.CONTENT_TYPE -> Seq(MimeTypes.JSON).asJava).asJava,
      fnToClosure(handleResponse((msg, _, _) => null))
    )

  override def put(
      path: String,
      body: String,
      queryParameters: java.util.Map[String, java.util.List[String]],
      headers: java.util.Map[String, java.util.List[String]]
  ): Object =
    put[Object](
      path,
      body,
      queryParameters,
      headers,
      fnToClosure(handleResponse((msg, _, _) => null))
    )

  override def putOrThrow(path: String, body: String): Object =
    put[Object](
      path,
      body,
      null,
      Map(HeaderNames.CONTENT_TYPE -> Seq(MimeTypes.JSON).asJava).asJava,
      fnToClosure(handleResponse((msg, _, _) => throw new IssueTrackerException(msg)))
    )

  override def putOrThrow(
      path: String,
      body: String,
      queryParameters: java.util.Map[String, java.util.List[String]],
      headers: java.util.Map[String, java.util.List[String]]
  ): Object =
    put[Object](
      path,
      body,
      queryParameters,
      headers,
      fnToClosure(handleResponse((msg, _, _) => throw new IssueTrackerException(msg)))
    )

  override def putResponse(path: String, body: String): Object =
    put[Response](
      path,
      body,
      null,
      Map(HeaderNames.CONTENT_TYPE -> Seq(MimeTypes.JSON).asJava).asJava,
      fnToClosure((_, r) => r)
    )

  override def putResponse(
      path: String,
      body: String,
      queryParameters: java.util.Map[String, java.util.List[String]],
      headers: java.util.Map[String, java.util.List[String]]
  ): Object =
    put[Response](
      path,
      body,
      queryParameters,
      headers,
      fnToClosure((_, r) => r)
    )

  override def patch(path: String, body: String): Object =
    patch[Object](
      path,
      body,
      null,
      Map(HeaderNames.CONTENT_TYPE -> Seq(MimeTypes.JSON).asJava).asJava,
      fnToClosure(handleResponse((msg, _, _) => null))
    )

  override def patch(
      path: String,
      body: String,
      queryParameters: java.util.Map[String, java.util.List[String]],
      headers: java.util.Map[String, java.util.List[String]]
  ): Object =
    patch[Object](
      path,
      body,
      queryParameters,
      headers,
      fnToClosure(handleResponse((msg, _, _) => null))
    )

  override def patchOrThrow(path: String, body: String): Object =
    patch[Object](
      path,
      body,
      null,
      Map(HeaderNames.CONTENT_TYPE -> Seq(MimeTypes.JSON).asJava).asJava,
      fnToClosure(handleResponse((msg, _, _) => throw new IssueTrackerException(msg)))
    )

  override def patchOrThrow(
      path: String,
      body: String,
      queryParameters: java.util.Map[String, java.util.List[String]],
      headers: java.util.Map[String, java.util.List[String]]
  ): Object =
    patch[Object](
      path,
      body,
      queryParameters,
      headers,
      fnToClosure(handleResponse((msg, _, _) => throw new IssueTrackerException(msg)))
    )

  override def patchResponse(path: String, body: String): Response =
    patch[Response](
      path,
      body,
      null,
      Map(HeaderNames.CONTENT_TYPE -> Seq(MimeTypes.JSON).asJava).asJava,
      fnToClosure((_, r) => r)
    )

  override def patchResponse(
      path: String,
      body: String,
      queryParameters: java.util.Map[String, java.util.List[String]],
      headers: java.util.Map[String, java.util.List[String]]
  ): Response =
    patch[Response](
      path,
      body,
      queryParameters,
      headers,
      fnToClosure((_, r) => r)
    )

  private def fnToClosure[R](fn: (Request, Response) => R): Closure[R] = new Closure[R](null) {

    override def call(args: Object*): R = {
      val req = args.head.asInstanceOf[Request]
      val res = args.tail.head.asInstanceOf[Response]
      fn(req, res)
    }

  }

  def handleResponse(
      handleFailedResponse: (String, Request, Response) => Null
  )(request: Request, response: Response): Object =
    if (response.code >= 400) {
      val msg = s"${request.method} request to ${request.path} ${request.body
          .map(b => s"with body:\n$b\n")
          .getOrElse("")}failed with status ${response.code} and response body: \n${response.bodyStrOpt.orNull}"
      CLIENT_LOG.error(msg)
      handleFailedResponse(msg, request, response)
    } else {
      response.getBody()
    }

}
