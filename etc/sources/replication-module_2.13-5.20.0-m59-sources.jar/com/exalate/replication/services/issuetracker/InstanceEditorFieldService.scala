package com.exalate.replication.services.issuetracker

import com.exalate.api.domain.instance.IInstance
import com.exalate.domain.values.EditorFieldValue
import com.exalate.replication.services.api.editor.IEditorCustomFieldService
import com.exalate.replication.services.api.issuetracker.IInstanceEditorFieldService
import com.exalate.replication.services.transport.v1.rest.NodeInfoProvider
import com.exalate.replication.services.transport.value.helpers.NodeInfoValueHelper
import com.google.inject.Inject
import play.api.libs.json.{JsError, JsSuccess, Json}

import scala.concurrent.{ExecutionContext, Future}

class InstanceEditorFieldService @Inject() (
    nodeInfoProvider: NodeInfoProvider,
    editorCustomFieldService: IEditorCustomFieldService
)(implicit ec: ExecutionContext)
    extends IInstanceEditorFieldService {

  /** Extracts seq of Editor Field Values, which consists of list of supported system fields
    * (extracted from `instance` input param ) and custom fields extracted from `instance` input
    * param also
    * @param instance
    *   \- the remote instance
    * @return
    *   \- Seq[EditorFieldValue]
    */
  override def getRemoteEditorFieldValues(instance: IInstance): Seq[EditorFieldValue] = {
    val nodeFieldValues = NodeInfoValueHelper.toNodeInfoValue(instance.getNodeInfo).editor match {
      case Some(editorValue) => editorValue.editorFields
      case None              => Seq.empty
    }
    val customFieldValues = toEditorFieldValueSeq(Option(instance.getCustomFieldValues))

    nodeFieldValues ++ customFieldValues
  }

  /** Extracts seq of Editor Field Values, which consists of list of supported system fields
    * (extracted from node info) and custom fields extracted from the local instance
    * @return
    */
  override def getLocalEditorFieldValues(): Future[Seq[EditorFieldValue]] =
    for {
      mainFieldValues <- getLocalEditorMainFieldValues()
      publicFieldValues <- getLocalPublicEditorFieldValues()
      customFieldValues <- getCustomLocalEditorFieldValues()
    } yield publicFieldValues ++ customFieldValues ++ mainFieldValues

  /** Converts a json of custom fields to seq of Editor Field Values
    * @param customFieldsStrOpt
    * @return
    */
  def toEditorFieldValueSeq(customFieldsStrOpt: Option[String]): Seq[EditorFieldValue] =
    customFieldsStrOpt match {
      case Some(customFieldsStr) =>
        Json.parse(customFieldsStr).validate[Seq[EditorFieldValue]] match {
          case JsSuccess(customFields, _) => customFields
          case e: JsError                 => Seq.empty
        }
      case _                     => Seq.empty
    }

  def getLocalEditorMainFieldValues(): Future[Seq[EditorFieldValue]] =
    nodeInfoProvider.get
      .map(_.editor)
      .map(_.map(_.editorFields.filter(_.main.contains(true))).getOrElse(Seq.empty))

  override def getLocalPublicEditorFieldValues(): Future[Seq[EditorFieldValue]] =
    nodeInfoProvider.get
      .map(_.editor)
      .map(
        _.map(_.editorFields.filter(f => f.main.isEmpty || f.main.contains(false)))
          .getOrElse(Seq.empty)
      )

  // TODO review if it make sense to have getCustomFieldValues in a different service. It seems that InstanceEditorFieldService should also be responsible of getting custom field values
  override def getCustomLocalEditorFieldValues(): Future[Seq[EditorFieldValue]] =
    editorCustomFieldService.getCustomFieldValues()

}
