package com.exalate.replication.services.issuetracker

import com.exalate.api.exception.bug.BugException
import com.exalate.replication.services.api.issuetracker.IIssueTrackerClient
import play.api.libs.ws.WSResponse

import scala.concurrent.Future

class NopIssueTrackerClient extends IIssueTrackerClient {

  override def http(
      method: String,
      path: String,
      bodyOpt: Option[String],
      qParamOpt: Option[Map[String, Seq[String]]],
      headersOpt: Option[Map[String, Seq[String]]]
  ): Future[WSResponse] = Future.failed(
    new BugException(
      "Please contact Exalate Support - default implementation of issue tracker client is used!"
    )
  )

}
