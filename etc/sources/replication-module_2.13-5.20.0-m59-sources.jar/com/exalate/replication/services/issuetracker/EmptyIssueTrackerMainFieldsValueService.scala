package com.exalate.replication.services.issuetracker

import com.exalate.domain.values.{BasicConnectionValue, SupportedEditorField}
import com.exalate.replication.services.api.issuetracker.IIssueTrackerMainFieldsValueService

import scala.concurrent.Future

class EmptyIssueTrackerMainFieldsValueService extends IIssueTrackerMainFieldsValueService {

  override def get(): Future[Option[BasicConnectionValue]] = {
    val fields = Seq.empty[SupportedEditorField]
    Future.successful(Some(BasicConnectionValue(fields)))
  }

}
