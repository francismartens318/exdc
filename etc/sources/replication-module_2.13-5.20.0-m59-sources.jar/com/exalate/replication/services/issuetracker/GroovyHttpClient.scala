package com.exalate.replication.services.issuetracker

import akka.stream.scaladsl.Source
import akka.util.ByteString
import com.exalate.api.exception.IssueTrackerException
import com.exalate.api.exception.bug.BugException
import com.exalate.domain.http.{
  GroovyHttpRequest,
  GroovyHttpResponse,
  MultiPartUploadGroovyHttpRequest,
  StreamingGroovyHttpResponse
}
import com.exalate.replication.services.api.issuetracker.IHttpClient
import com.exalate.services.utils.logging.IssueTrackerClientLoggerFilterFactory
import com.exalate.services.utils.logging.config.WsLoggingConfig
import com.exalate.services.utils.{CollectionService, FutureUtils}
import com.google.inject.Inject
import play.api.http.{ContentTypes, HeaderNames}
import play.api.libs.ws._
import play.api.mvc.Codec
import play.api.mvc.MultipartFormData._

import java.net.{URI, URL, URLDecoder, URLEncoder}
import scala.concurrent.ExecutionContext
import scala.concurrent.duration._
import scala.jdk.CollectionConverters._
import scala.util.{Failure, Success, Try}

//noinspection ScalaUnusedSymbol
class GroovyHttpClient @Inject() (
    ws: WSClient,
    issueTrackerClientLoggerFilterFactory: IssueTrackerClientLoggerFilterFactory
)(implicit executionContext: ExecutionContext)
    extends IHttpClient {

  import GroovyHttpClient._

  def uploadMultiPart(request: MultiPartUploadGroovyHttpRequest): GroovyHttpResponse =
    uploadMultiPart(request, 10.minutes)

  // noinspection ConvertibleToMethodValue,ScalaWeakerAccess
  def uploadMultiPart(
      request: MultiPartUploadGroovyHttpRequest,
      timeOut: Duration
  ): GroovyHttpResponse =
    FutureUtils
      .toTry(
        httpPreExecute(
          request.method,
          request.url,
          CollectionService.toScalaMapOpt(request.queryParameters),
          CollectionService.toScalaMapOpt(request.headers),
          Option(WsLoggingConfig(logRequestBody = false))
        ) { req =>
          val multipartSeq = getMultiPartSeq(request)
          val parts: Source[Part[Source[ByteString, _]], _] = Source(multipartSeq)
          val requestWithBody = req.withBody(parts)

          addContentLengthIfFilePartsHaveSize(requestWithBody, multipartSeq)
        }
          .execute(),
        timeOut
      )
      .map(toResponse(_))
      .recoverWith {
        case e =>
          Failure(new IssueTrackerException(e))
      }
      .get

  private[issuetracker] def getMultiPartSeq(
      request: MultiPartUploadGroovyHttpRequest
  ): Seq[Part[Source[ByteString, _]]] = {
    val filePartsSeqTry = getFilePartsSeqTry(request)
    FutureUtils.foldLeftTry(filePartsSeqTry)(identity) match {
      case Success(s) => s
      case _          =>
        throw new BugException(
          "Failed to get sequence from Try " +
            "while extracting Multi Parts from Request."
        )
    }
  }

  private def addContentLengthIfFilePartsHaveSize(
      requestWithBody: WSRequest,
      multipartSeq: Seq[Part[Source[ByteString, _]]]
  ): WSRequest = {
    val (fileParts, dataParts) = splitFileAndDataParts(multipartSeq)
    val hasAllFileSizes = fileParts.forall { case fp: FilePart[_] => fp.fileSize > -1 }
    if (hasAllFileSizes) {
      val contentLength = calculateMultipartFormDataLength(
        dataParts.map(_.asInstanceOf[DataPart]),
        fileParts.map(_.asInstanceOf[FilePart[Any]])
      )
      requestWithBody.addHttpHeaders(HeaderNames.CONTENT_LENGTH -> contentLength.toString)
    } else requestWithBody
  }

  private[issuetracker] def splitFileAndDataParts(
      multipartSeq: Seq[Part[Source[ByteString, _]]]
  ): (Seq[Part[Source[ByteString, _]]], Seq[Part[Source[ByteString, _]]]) =
    multipartSeq.partition {
      case _: DataPart    => false
      case _: FilePart[_] => true
    }

  private[issuetracker] def getFilePartsSeqTry(
      request: MultiPartUploadGroovyHttpRequest
  ): Seq[Try[Part[Source[ByteString, _]]]] =
    request.formParts.asScala.map {
      case dataPart: MultiPartUploadGroovyHttpRequest.DataPart       =>
        Success(DataPart(dataPart.key, dataPart.value))
      case filePart: MultiPartUploadGroovyHttpRequest.SourceFilePart =>
        if (filePart.dispositionType == null)
          Success(
            FilePart(
              filePart.key,
              filePart.filename,
              Option(filePart.contentType),
              filePart.ref,
              filePart.fileSize
            )
          ): Try[Part[Source[ByteString, _]]]
        else
          Success(
            FilePart(
              filePart.key,
              filePart.filename,
              Option(filePart.contentType),
              filePart.ref,
              filePart.fileSize,
              filePart.dispositionType
            )
          ): Try[Part[Source[ByteString, _]]]
      case p                                                         =>
        Failure(
          new BugException(
            s"Groovy Http Client doesn't support other types of Parts " +
              s"but the data part and the Source File Part, attempted to pass $p to it!"
          )
        ): Try[Part[Source[ByteString, _]]]
    }.toSeq

  def download(request: GroovyHttpRequest): StreamingGroovyHttpResponse =
    download(request, 10.minutes)

  def download(request: GroovyHttpRequest, timeOut: Duration): StreamingGroovyHttpResponse =
    FutureUtils
      .toTry(
        httpPreExecuteBody(
          request.method,
          request.url,
          Option(request.body),
          CollectionService.toScalaMapOpt(request.queryParameters),
          CollectionService.toScalaMapOpt(request.headers),
          Option(WsLoggingConfig(logResponseBody = false))
        )
          .stream(),
        timeOut
      )
      .map(toStreamedResponse)
      .recoverWith {
        case e =>
          Failure(new IssueTrackerException(e))
      }
      .get

  def http(request: GroovyHttpRequest): GroovyHttpResponse =
    http(request, WsLoggingConfig(), 1.minute)

  /** please, use this method for uploading attachments and specify in logging config not to log
    * request (for attachment upload) and not to log response (for attachment body fetch)
    */
  def http(
      request: GroovyHttpRequest,
      loggingConfig: WsLoggingConfig,
      timeOut: Duration
  ): GroovyHttpResponse =
    FutureUtils
      .toTry(
        httpPreExecuteBody(
          request.method,
          request.url,
          Option(request.body),
          CollectionService.toScalaMapOpt(request.queryParameters),
          CollectionService.toScalaMapOpt(request.headers),
          Option(loggingConfig)
        )
          .execute(),
        timeOut
      )
      .map(toResponse)
      .recoverWith {
        case e =>
          Failure(new IssueTrackerException(e))
      }
      .get

  private[issuetracker] def calculateMultipartFormDataLength[A](
      dataParts: Seq[DataPart],
      fileParts: Seq[FilePart[A]],
      codec: Codec = Codec.utf_8
  ): Long = {
    val boundary: String = "brrKqsutjWC8xZVSyH"
    val endBoundaryBytesLength = s"--$boundary--".getBytes(codec.charset).length

    def formatDataPartsLength(data: Seq[DataPart]): Long =
      data
        .map {
          case DataPart(name, value) =>
            s"""--$boundary\r\n${HeaderNames.CONTENT_DISPOSITION}: form-data; name="$name"\r\nContent-Type: text/plain\r\n\r\n$value\r\n"""
        }
        .mkString
        .getBytes(codec.charset)
        .length

    def filePartHeaderLength(file: FilePart[A]): Long = {
      val name = file.key
      val filename = file.filename
      val contentType = file.contentType
        .map { ct =>
          s"${HeaderNames.CONTENT_TYPE}: $ct"
        }
        .getOrElse("")
      val headerLength =
        s"""--$boundary\r\n${HeaderNames.CONTENT_DISPOSITION}: form-data; name="$name"; filename="$filename"\r\n$contentType\r\n\r\n"""
          .getBytes(codec.charset)
          .length
      headerLength
    }

    val dataPartsLength = formatDataPartsLength(dataParts)
    val lineBreakSize = "\r\n".getBytes(codec.charset).length
    val filePartsLength = fileParts.map { filePart =>
      val fileHeaderSize = filePartHeaderLength(filePart)
      val fileSize = filePart.fileSize
      fileHeaderSize + fileSize + lineBreakSize
    }.sum

    dataPartsLength + filePartsLength + endBoundaryBytesLength
  }

  private def httpPreExecute(
      method: String,
      url: String,
      queryParamOpt: Option[Map[String, Seq[String]]] = None,
      headersOpt: Option[Map[String, Seq[String]]] = None,
      loggingConfigOpt: Option[WsLoggingConfig]
  )(bodyFn: WSRequest => WSRequest): WSRequest = {

    val wsRequestFilter = issueTrackerClientLoggerFilterFactory.create(
      Some("#http"),
      loggingConfigOpt.getOrElse(WsLoggingConfig())
    )

    val request = createRequest(ws)(
      method,
      url,
      queryParamOpt,
      headersOpt
    )(bodyFn)
    request
      .withRequestFilter(wsRequestFilter)
  }

  private def httpPreExecuteBody(
      method: String,
      url: String,
      bodyOpt: Option[String] = None,
      qParamOpt: Option[Map[String, Seq[String]]] = None,
      headersOpt: Option[Map[String, Seq[String]]] = None,
      loggingConfigOpt: Option[WsLoggingConfig]
  ): WSRequest =
    httpPreExecute(method, url, qParamOpt, headersOpt, loggingConfigOpt)(defaultBodyFn(bodyOpt))

  private[issuetracker] def toResponse(wsResponse: WSResponse): GroovyHttpResponse =
    new GroovyHttpResponse(
      wsResponse.status,
      Option(wsResponse.headers)
        .map(_.view.mapValues(_.asJava).toMap.asJava)
        .orNull,
      () => Option(wsResponse.body).orNull,
      () => CollectionService.toJavaBody(Option(wsResponse.body))
    )

  private[issuetracker] def toStreamedResponse(
      wsResponse: WSResponse
  ): StreamingGroovyHttpResponse =
    new StreamingGroovyHttpResponse(
      wsResponse.status,
      Option(wsResponse.headers)
        .map(_.view.mapValues(_.asJava).toMap.asJava)
        .orNull,
      wsResponse.bodyAsSource
    )

}

object GroovyHttpClient {

  private[issuetracker] def sanitizeUrl(url: String): String = {
    val u = new URL(url)
    url.replace(s"?${u.getQuery}", "")
  }

  private[issuetracker] def encodeUrl(url: String): String = {
    val u = new URL(url)
    Option(u.getQuery) match {
      case Some(query) =>
        val listOfQuery = query
          .split("&")
          .foldLeft(List.empty[String]) { (result, param) =>
            val kv = param
              .split("=", 2)
              .toSeq
            val kOpt = kv.headOption
            val vOpt = kv.tail.headOption
            (kOpt, vOpt) match {
              case (Some(k), Some(v)) =>
                val a = s"${URLEncoder.encode(k, "UTF-8")}=${URLEncoder.encode(v, "UTF-8")}"
                result :+ a
              case _                  =>
                result
            }
          }

        val encodedQuery = listOfQuery.mkString("&")
        url.replace(s"${u.getQuery}", encodedQuery)
      case None        => url
    }

  }

  private[issuetracker] def getHeaderTuplesFromMapValues(
      headers: Map[String, Seq[String]]
  ): Seq[(String, String)] =
    headers.toSeq
      .flatMap { case (k, vs) => vs.map(v => (k, v)) }
      .filter {
        case (null, _) => false
        case (_, null) => false
        case _         => true
      }

  private[issuetracker] def getAllQueryParamsFromUri(
      queryParamFromExtendedUri: Option[Map[String, String]],
      queryParamOpt: Option[Map[String, Seq[String]]]
  ): Seq[(String, String)] =
    (queryParamFromExtendedUri
      .getOrElse(Map.empty[String, String]) ++ queryParamOpt
      .map(
        _.toSeq
          .flatMap { case (k, vs) => vs.map(v => (k, v)) }
          .filter {
            case (null, _) => false
            case (_, null) => false
            case _         => true
          }
          .toMap
      )
      .getOrElse(Map.empty[String, String])).toSeq

  private[issuetracker] def parseUri(uriStr: String): Try[ExtendedUri] =
    Try {
      val uri = new URI(encodeUrl(uriStr))
      val extendedUriWithMail: ExtendedUri = parseMailUri(uri)
      val extendedUriWithFragments: ExtendedUri = parseUriFragments(uri, extendedUriWithMail)
      val extendedUriWithQueryMap: ExtendedUri = parseUriQueryToMap(uri, extendedUriWithFragments)
      val uriWithParsedQueryValues = parseUriQueryValues(extendedUriWithQueryMap)
      uriWithParsedQueryValues
    }

  private def parseMailUri(initialUri: URI) =
    if (initialUri.getScheme == "mailto") {
      val schemeSpecificPartList = initialUri.getSchemeSpecificPart.split("\\?", 2)
      val tempMailMap = queryStringToMap(schemeSpecificPartList.tail.head)
      ExtendedUri(
        initialUri,
        mailMap = Some(
          Map(
            "recipient" -> schemeSpecificPartList.head,
            "cc" -> tempMailMap.find { case (k, _) => k.equalsIgnoreCase("cc") }.map(_._2).orNull,
            "bcc" -> tempMailMap.find { case (k, _) => k.equalsIgnoreCase("bcc") }.map(_._2).orNull,
            "subject" -> tempMailMap
              .find { case (k, _) => k.equalsIgnoreCase("subject") }
              .map(_._2)
              .orNull,
            "body" -> tempMailMap
              .find { case (k, _) => k.equalsIgnoreCase("body") }
              .map(_._2)
              .orNull
          )
        )
      )
    } else {
      ExtendedUri(initialUri, None, None, None, None)
    }

  private[issuetracker] def queryStringToMap(string: String): Map[String, String] =
    string
      .split("&")
      .foldLeft(Map.empty[String, String]) { (result, param) =>
        val kv = param
          .split("=", 2)
          .toSeq
        val kOpt = kv.headOption
        val vOpt = kv.tail.headOption
        (kOpt, vOpt) match {
          case (Some(k), Some(v)) =>
            result.+((URLDecoder.decode(k, "UTF-8"), URLDecoder.decode(v, "UTF-8")))
          case _                  =>
            result
        }
      }

  private def parseUriFragments(uri: URI, extendedUri: ExtendedUri) =
    if (uri.getFragment != null && uri.getFragment.contains("?")) {
      extendedUri.copy(
        uri = new URI(
          uri.getScheme,
          uri.getUserInfo,
          uri.getHost,
          uri.getPort,
          uri.getPath,
          uri.getFragment.split("\\?").lift(1).orNull,
          uri.getFragment.split("\\?").headOption.orNull
        ),
        rawQuery = uri.getRawFragment.split("\\?").lift(1),
        rawFragment = uri.getRawFragment.split("\\?").headOption
      )
    } else extendedUri

  private def parseUriQueryToMap(uri: URI, extendedUri: ExtendedUri) =
    if (uri.getRawQuery != null) {
      extendedUri.copy(
        queryMap = Option(
          queryStringToMap(uri.getRawQuery)
        )
      )
    } else extendedUri

  private def parseUriQueryValues(extendedUri: ExtendedUri) =
    if (extendedUri.queryMap.exists(_.nonEmpty)) {
      extendedUri.copy(
        queryMap = Option(
          extendedUri.queryMap.get
            .foldLeft(Map.empty[String, String]) {
              case (result, (k, v)) =>
                if (v.startsWith("http") || v.startsWith("/")) {
                  result.+((k, parseUri(v).toOption.map(_.uri.toString).orNull))
                } else result.+((k, v))
            }
        )
      )
    } else extendedUri

  def createRequest(ws: WSClient)(
      method: String,
      url: String,
      queryParamOpt: Option[Map[String, Seq[String]]] = None,
      headersOpt: Option[Map[String, Seq[String]]] = None
  )(bodyFn: WSRequest => WSRequest): WSRequest = {

    val baseRequest = ws
      .url(url)
      .withMethod(method)

    val headersWithoutContentType = headersOpt match {
      case None          =>
        Seq.empty[(String, String)]
      case Some(headers) =>
        headers
          .filterNot(isContentTypeHeader)
          .toSeq
          .flatMap { case (k, vs) => vs.map(v => (k, v)) }
    }

    val contentTypeHeaderOpt = headersOpt.flatMap(hs => hs.find(isContentTypeHeader))
    val requestWithContentType = contentTypeHeaderOpt match {
      case Some((k, contentTypes)) if contentTypes.nonEmpty =>
        val contentType = contentTypes.head
        baseRequest.addHttpHeaders((k, contentType))
      case _                                                => baseRequest
    }
    val allQueryParams: Seq[(String, String)] =
      getAllQueryParamsFromUri(None, queryParamOpt)
    val requestWithQueryParams = requestWithContentType.addQueryStringParameters(allQueryParams: _*)
    val requestWithBody = bodyFn(
      requestWithQueryParams
    )
    val requestWithHeaders = requestWithBody
      .addHttpHeaders(headersWithoutContentType: _*)
    requestWithHeaders
  }

  private def isContentTypeHeader(header: (String, Seq[String])): Boolean =
    header._1.equalsIgnoreCase(HeaderNames.CONTENT_TYPE)

  def createRequestWithBody(ws: WSClient)(
      method: String,
      url: String,
      bodyOpt: Option[String] = None,
      qParamOpt: Option[Map[String, Seq[String]]] = None,
      headersOpt: Option[Map[String, Seq[String]]] = None
  ): WSRequest =
    createRequest(ws)(
      method,
      url,
      qParamOpt,
      headersOpt
    )(defaultBodyFn(bodyOpt))

  private[issuetracker] def defaultBodyFn(bodyOpt: Option[String])(request: WSRequest): WSRequest =
    bodyOpt match {
      case None       => request
      case Some(body) => request.withBody(body)
    }

}

case class ExtendedUri(
    uri: URI,
    mailMap: Option[Map[String, String]] = None,
    queryMap: Option[Map[String, String]] = None,
    rawQuery: Option[String] = None,
    rawFragment: Option[String] = None
)
