package com.exalate.replication.services.issuetracker

import com.exalate.domain.values.BasicConnectionValue
import com.exalate.replication.services.api.issuetracker.IIssueTrackerMainFieldsValueService

import scala.concurrent.Future

class NopIssueTrackerMainFieldsValueService extends IIssueTrackerMainFieldsValueService {
  override def get(): Future[Option[BasicConnectionValue]] = Future.successful(None)
}
