package com.exalate.replication.services.issuetracker

import com.exalate.replication.services.api.issuetracker.{
  IHttpClient,
  IIssueTrackerHttpClientFactory
}
import com.exalate.replication.services.issuetracker.readonlyclient.{
  GroovyHttpClientReadOnly,
  HttpClientAIReadOnly,
  HttpClientReadOnly
}

import javax.inject.Inject

class DefaultIssueTrackerHttpClientFactory @Inject() (
    groovyHttpClient: GroovyHttpClient,
    httpClient: HttpClient
) extends IIssueTrackerHttpClientFactory {
  override def getGroovyHttpClient(): IHttpClient = groovyHttpClient

  override def getHttpClient(): IHttpClient = httpClient

  override def getGroovyHttpClientReadOnly(): IHttpClient = new GroovyHttpClientReadOnly()

  override def getHttpClientReadOnly(): IHttpClient = new HttpClientReadOnly(httpClient)

  override def getHttpClientAIReadOnly(): IHttpClient = new HttpClientAIReadOnly(httpClient)
}
