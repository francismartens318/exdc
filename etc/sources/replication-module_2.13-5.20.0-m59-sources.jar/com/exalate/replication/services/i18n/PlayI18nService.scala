package com.exalate.replication.services.i18n

import java.util.Locale

import com.exalate.replication.services.api.i18n.Ii18nService
import javax.inject.Inject
import play.api.i18n.{Lang, MessagesApi}

class PlayI18nService @Inject() (messagesApi: MessagesApi) extends Ii18nService {

  /** Helps to translate a message.
    * @param key
    *   key of the message
    * @param values
    *   additional value that should be provided to the message
    * @param localeOpt
    *   language
    * @return
    *   translated message
    */
  override def translate(key: String, values: String*)(implicit
      localeOpt: Option[Locale]
  ): Option[String] = {
    val loc = localeOpt.getOrElse(Locale.ENGLISH)
    messagesApi.translate(key, values.toSeq)(Lang(loc))
  }

}
