package com.exalate.domain.values.v2_5.connection

import com.exalate.domain.values.NodeInfoValue

case class AcceptInvitationValue(
    invitationSecret: String,
    invitedSendProtocol: String,
    nodeInfo: NodeInfoValue,
    mode: Option[String] = None
)
