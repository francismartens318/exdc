package com.exalate.domain.values

import com.exalate.domain.editor.FieldDataType
import com.exalate.domain.transport.trackeroptions.EditorFields

import play.api.libs.json.{Json, OFormat}

case class BasicConnectionValue(
    fields: Seq[SupportedEditorField] = Seq(
      SupportedEditorField(
        key = EditorFields.PROJECT.toString,
        label = "Project",
        `type` = FieldTypeValue(FieldDataType.OPTION.toString, None),
        operators = Seq.empty[FieldTypeValue]
      )
    )
)

object BasicConnectionValue {
  implicit val format: OFormat[BasicConnectionValue] = Json.format
}
