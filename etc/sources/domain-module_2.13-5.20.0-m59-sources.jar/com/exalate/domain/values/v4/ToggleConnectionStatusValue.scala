package com.exalate.domain.values.v4

case class ToggleConnectionStatusValue(activate: Boolean)
