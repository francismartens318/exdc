package com.exalate.domain.values.v4

/** Holds names for automatic generation of the connection name
  * @param name
  * @param localInstanceName
  * @param remoteInstanceName
  */
case class ConnectionNameValue(
    name: Option[String],
    localInstanceName: Option[String],
    remoteInstanceName: Option[String]
)
