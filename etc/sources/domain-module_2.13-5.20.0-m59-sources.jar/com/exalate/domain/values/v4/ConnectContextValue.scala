package com.exalate.domain.values.v4

import play.api.libs.json.{Json, OFormat}

case class ConnectContextValue(
    synchronizeComments: Boolean,
    synchronizeAttachments: Boolean,
    synchronizeWorklogs: Boolean,
    triggerSyncEvent: Boolean,
    triggerUpdate: Option[Boolean],
    triggerUnexalate: Option[Boolean]
)

object ConnectContextValue {
  implicit val format: OFormat[ConnectContextValue] = Json.format
}
