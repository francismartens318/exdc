package com.exalate.domain.values.v4

case class FeatureFlagsValue(
    licensingService: Boolean,
    groovyLsp: Boolean,
    chargeBee: Boolean,
    newGettingStartedUi: Boolean,
    aiAssist: Boolean
)
