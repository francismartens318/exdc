package com.exalate.domain.values.v4

import com.exalate.domain.values.SimplifiedInstanceValue

case class RelationValue(
    id: Option[Int],
    name: String,
    description: Option[String],
    status: Option[String],
    remoteInstance: SimplifiedInstanceValue,
    createRemoteIssueLink: Option[Boolean],
    syncPanelIssueLink: Option[Boolean],
    hpqcDomain: Option[String],
    hpqcProject: Option[String],
    issueLinkFieldName: Option[String],
    proxyUsername: Option[String],
    proxyPassword: Option[String],
    authRequiredBoolean: Option[Boolean],
    dataFilter: Option[String],
    createProcessor: Option[String],
    changeProcessor: Option[String]
) {

  override def toString =
    s"RelationValue($id, $name, $description, $status, $remoteInstance, $createRemoteIssueLink, $syncPanelIssueLink, $hpqcDomain, " +
      s"$hpqcProject, $issueLinkFieldName, $proxyUsername, $authRequiredBoolean, $dataFilter, $createProcessor, $changeProcessor)"

}
