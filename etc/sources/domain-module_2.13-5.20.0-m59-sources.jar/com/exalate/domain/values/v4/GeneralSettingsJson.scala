package com.exalate.domain.values.v4

import play.api.libs.json.JsValue

/** { exalateUrl: { "value": "http://localhost:9002" }, issueTrackerUrl: {"value": "http://..."},
  * "fieldValues": { "username": { "value":"f" }, "password": { "value":"***" } } }
  */
case class GeneralSettingsJson(
    exalateUrl: Map[String, JsValue],
    issueTrackerUrl: Map[String, JsValue],
    fieldValues: Map[String, Map[String, JsValue]]
    /*
                                {password: {value: "asd", encrypt: true}}
     */
)

case class GSFieldValues(fieldValues: Map[String, Map[String, JsValue]])
