package com.exalate.domain.values.v4

import play.api.libs.json.{Json, OFormat}

case class ConnectValue(
    fieldValues: Option[Map[String, String]],
    entityType: String,
    remoteIssueUrn: String,
    connectContext: Option[ConnectContextValue]
)

object ConnectValue {
  implicit val formatConnectValue: OFormat[ConnectValue] = Json.format[ConnectValue]
}
