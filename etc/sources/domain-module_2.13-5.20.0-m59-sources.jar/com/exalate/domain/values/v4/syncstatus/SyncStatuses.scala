package com.exalate.domain.values.v4.syncstatus

case class SyncStatuses(
    statuses: Seq[SyncStatus],
    doesEntityExist: Boolean,
    belongsToProject: Boolean
)
