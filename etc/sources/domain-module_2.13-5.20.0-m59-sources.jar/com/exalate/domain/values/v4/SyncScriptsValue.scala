package com.exalate.domain.values.v4

case class SyncScriptsValue(
    dataFilter: String,
    createProcessor: String,
    changeProcessor: String,
    incomingProcessor: Option[String],
    postExalateProcessor: Option[String]
)
