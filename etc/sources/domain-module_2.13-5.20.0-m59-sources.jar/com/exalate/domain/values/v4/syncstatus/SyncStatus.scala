package com.exalate.domain.values.v4.syncstatus

case class SyncStatus(
    status: String,
    connectionName: String,
    twinTraceId: Int,
    remoteUrl: Option[String],
    remoteSummary: Option[String],
    remoteIssueUrn: Option[String],
    localUrl: Option[String] = None,
    localIssueUrn: Option[String] = None
)
