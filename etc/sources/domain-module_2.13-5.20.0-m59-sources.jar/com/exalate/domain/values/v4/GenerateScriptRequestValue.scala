package com.exalate.domain.values.v4

import com.exalate.domain.values.connection.MainFieldInfoValue

/** # {"mainFieldInfo" : { * local : [{ * key : "PROJECT", * value: { * value : "id", * label :
  * "name+key" * } * }], * remote: [{ * ... * }] // Option // only for local connection }
  * connectionMode: "BASIC" }
  */
case class GenerateScriptRequestValue(
    mainFieldInfo: Option[MainFieldInfoValue],
    connectionMode: Option[String]
)
