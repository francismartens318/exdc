package com.exalate.domain.values.v4

case class RemoteInstanceValue(remoteInstanceName: String)
