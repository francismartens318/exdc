package com.exalate.domain.values.v4

case class ConnectionInfoValue(triggersCount: Int, issuesCount: Int)
