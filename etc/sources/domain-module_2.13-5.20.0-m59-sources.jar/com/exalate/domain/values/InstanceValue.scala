package com.exalate.domain.values

case class InstanceValue(
    id: Option[Int],
    name: Option[String],
    description: Option[String],
    url: Option[String],
    issueTrackerUrl: Option[String],
    status: Option[String],
    paymentModel: Option[String],
    nodeInfo: Option[NodeInfoValue],
    authenticationRequired: Option[Boolean],
    proxyUsername: Option[String],
    proxyPassword: Option[String],
    customFieldsValue: Option[String]
) {

  override def toString =
    s"InstanceValue($id, $name, $description, $url, $issueTrackerUrl, $status, $paymentModel, $nodeInfo, " +
      s"$authenticationRequired, $proxyUsername), $customFieldsValue"

}
