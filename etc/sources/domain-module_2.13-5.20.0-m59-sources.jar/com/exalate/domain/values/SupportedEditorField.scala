package com.exalate.domain.values

import play.api.libs.json.{Json, OFormat}

//TODO: should be renamed? used also for Basic Connection
case class SupportedEditorField(
    key: String,
    label: String,
    `type`: FieldTypeValue,
    operators: Seq[FieldTypeValue],
    placeholder: Option[String] = None
)

object SupportedEditorField {
  implicit val format: OFormat[SupportedEditorField] = Json.format
}

case class FieldsScopeParamsValue(fields: Seq[SupportedEditorField])

case class SingleSideScopeParamsValue(
    mainFields: Seq[SupportedEditorField],
    query: FieldsScopeParamsValue
)

case class ScopeParamsValue(
    local: SingleSideScopeParamsValue,
    remote: Option[SingleSideScopeParamsValue]
)
