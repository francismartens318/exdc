package com.exalate.domain.values

import play.api.libs.json.{Json, OFormat}

case class BlobEventValue(
    id: Int,
    status: String,
    syncEvent: SyncEventValue,
    blobMetadata: BlobMetadataValue,
    errorResponseReason: Option[String],
    errorResponseMessage: Option[String],
    errorId: Option[Int],
    fileName: String,
    fileSize: Long
)

object BlobEventValue {
  implicit val format: OFormat[BlobEventValue] = Json.format
}
