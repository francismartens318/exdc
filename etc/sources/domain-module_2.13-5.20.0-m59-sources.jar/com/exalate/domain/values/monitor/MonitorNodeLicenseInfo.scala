package com.exalate.domain.values.monitor

import com.exalate.domain.values.license.LicenseValue

case class MonitorNodeLicenseInfo(
    licenseInfo: Option[LicenseValue],
    isPluginInstalled: Option[Boolean],
    state: Option[String],
    errorMessage: Option[String]
)

object MonitorNodeLicenseInfo {
  val Empty: MonitorNodeLicenseInfo = MonitorNodeLicenseInfo(None, None, None, None)
}
