package com.exalate.domain.values

case class TriggerPollContextAllFields(
    id: Int,
    lastPollStr: Option[String],
    pairPollOffset: Long,
    pairPollLimit: Int,
    pairPollTotalResults: Option[Long],
    triggerId: Int
)
