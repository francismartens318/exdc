package com.exalate.domain.values

import play.api.libs.json.{Json, OFormat}

case class AuthenticationFailureValue(title: String, body: String, docsLink: Option[String] = None)

object AuthenticationFailureValue {
  implicit val format: OFormat[AuthenticationFailureValue] = Json.format
}
