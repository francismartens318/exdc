package com.exalate.domain.values

import com.exalate.domain.editor.mappings.MappingValue

case class MappingsSuggestionValue(mappings: Seq[MappingValue])
