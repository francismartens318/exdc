package com.exalate.domain.values

case class EditorFieldErrorValue(
    editorField: EditorFieldValue,
    errorMessage: String,
    value: Option[Object]
)
