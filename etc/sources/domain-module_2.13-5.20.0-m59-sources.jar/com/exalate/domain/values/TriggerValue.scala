package com.exalate.domain.values

import com.exalate.domain.ObjectJsonFormatters
import play.api.libs.json.{Format, Json, OFormat}

case class TriggerValue(
    id: Option[Int],
    jqlFilter: Option[String],
    entityType: String,
    notes: Option[String],
    relation: SimplifiedRelationValue,
    status: String,
    fieldValues: Option[Map[String, Object]],
    isManagedRemotely: Option[Boolean] = None
)

object TriggerValue {
  implicit val objFormat: Format[Object] = ObjectJsonFormatters.objFormat

  implicit val format: OFormat[TriggerValue] = Json.format
}
