package com.exalate.domain.values

import play.api.libs.json.{Json, OFormat}

case class PaginationValueWrite[T](
    offset: Option[Int],
    limit: Option[Int],
    total: Int,
    results: Seq[T]
)

object PaginationValueWrite {
  implicit def format[T: OFormat]: OFormat[PaginationValueWrite[T]] = Json.format
}

/** + * + * @param sort list of strings in format "column_name dot 'asc' or 'desc'", aka
  * List("col1.asc", "col2.desc") +
  */
case class PageRequest(
    limit: Option[Int] = None,
    offset: Option[Int] = None,
    sort: Seq[String] = Nil
)

object PageRequest {

  val ALL: PageRequest = PageRequest(None, None)

  implicit val format: OFormat[PageRequest] = Json.format

}

case class PageResult[V](results: Seq[V], total: Int, pageRequest: PageRequest)

object PageResult {
  implicit def format[T: OFormat]: OFormat[PageResult[T]] = Json.format
}
