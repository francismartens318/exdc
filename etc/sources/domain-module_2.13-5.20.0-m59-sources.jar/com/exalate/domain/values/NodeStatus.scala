package com.exalate.domain.values

import com.exalate.domain.values.license.LicenseValue
import ai.x.play.json.Jsonx
import play.api.libs.json.{Json, OFormat}

case class NodeStatus(
    licenseSummary: Option[LicenseValue],
    lastSyncDate: Option[String],
    lastSuccessfulSyncDate: Option[String],
    lastEditorSyncDate: Option[String],
    numberOfConnections: Int,
    numberOfEditorConnections: Int,
    numberOfBasicConnections: Int,
    numberOfNotFinishedConnections: Int,
    numberOfAcceptedConnections: Int,
    numberOfTriggers: Int,
    numberOfTriggersForBasicConnection: Int,
    numberOfIssuesUnderSync: Int,
    numberOfEditorIssuesUnderSync: Int,
    numberOfNodeLevelErrors: Int,
    numberOfConnectionLevelErrors: Int,
    numberOfTriggerLevelErrors: Int,
    numberOfIssueLevelErrors: Int,
    numberOfWarningLevelErrors: Int,
    numberOfEntitiesInSyncEventQueue: Int,
    numberOfEntitiesInSyncRequestQueue: Int,
    issueTrackerUrl: Option[String],
    instanceUid: Option[String],
    isEulaAccepted: Boolean,
    isVerified: Boolean,
    exaCompVersion: String,
    exaNodeVersion: String,
    connectedTo: Seq[String],
    trackerInfo: TrackerInfo,
    connectionInfo: Seq[ConnectionInfo],
    numberOfUsers: Int
)

object NodeStatus {
  import ai.x.play.json.Encoders.encoder
  implicit val format: OFormat[NodeStatus] = Jsonx.formatCaseClass[NodeStatus]
}

case class TrackerInfo(
    isPluginInstalled: Option[Boolean],
    pluginState: Option[String],
    trackerErrorMessages: Option[String]
)

object TrackerInfo {
  implicit val format: OFormat[TrackerInfo] = Json.format
}

case class ConnectionInfo(
    name: String,
    mode: String,
    wasUpgraded: Boolean,
    lastSuccessfulSyncDate: Option[String],
    numberOfIssuesUnderSync: Int,
    numberOfNodeLevelErrors: Int,
    numberOfConnectionLevelErrors: Int,
    numberOfTriggerLevelErrors: Int,
    numberOfIssueLevelErrors: Int,
    numberOfWarningLevelErrors: Int,
    numberOfEntitiesInSyncEventQueue: Int,
    numberOfEntitiesInSyncRequestQueue: Int,
    remoteIssueTrackerUrl: Option[String],
    remoteExalateUrl: Option[String],
    connectionType: String,
    isSyncedFirstIssue: Boolean,
    establishingMetrics: Seq[MetricInfo]
)

object ConnectionInfo {
  implicit val format: OFormat[ConnectionInfo] = Json.format
}

case class MetricInfo(
    eventName: String,
    eventDate: String,
    eventDuration: Long
)

object MetricInfo {
  implicit val format: OFormat[MetricInfo] = Json.format
}
