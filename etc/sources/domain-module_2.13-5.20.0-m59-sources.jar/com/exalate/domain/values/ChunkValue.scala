package com.exalate.domain.values

/** @param c
  *   \- content of a chunk
  * @param id
  *   \- message id
  * @param x
  *   \- startIndexInMessage
  * @param t
  *   \- totalChunksInMessage
  * @param m
  *   \- messageType
  */

trait ChunkValue {}

case class PlainChunkValue(c: Array[Byte], id: Int, x: Int, t: Int, m: String) extends ChunkValue

case class EncodedChunkValue(c: String, id: Int, x: Int, t: Int, m: String) extends ChunkValue
