package com.exalate.domain.values

import play.api.libs.json.{Json, OFormat}

case class ReplicaValue(id: Int, issueId: String, issueKey: String, payload: String)

object ReplicaValue {
  implicit val format: OFormat[ReplicaValue] = Json.format
}
