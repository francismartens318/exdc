package com.exalate.domain.values.license

import play.api.libs.json.JsonNaming.SnakeCase
import play.api.libs.json.{Json, JsonConfiguration, OFormat}

case class ChargeBeeLicense(
    licenseId: String,
    instanceUId: String,
    trackerUrl: String,
    subscriptionId: String,
    customerId: String
)

case class ChargeBeeSubscription(
    subscriptionId: String,
    customerId: String,
    currentTermStart: Long,
    currentTermEnd: Long,
    issueTrackerUrl: String,
    status: String
)

case class ChargeBeeSubscriptionValue(
    subscriptionId: String,
    customerId: String,
    instanceUid: String,
    currentTermStart: Long,
    currentTermEnd: Long,
    issueTrackerUrl: String,
    status: SubscriptionStatus
)

case class ChargeBeeSubscriptionEvent(
    id: String,
    customerId: String,
    currentTermStart: Long,
    currentTermEnd: Long,
    cfIssueTrackerUrl: String,
    cfInstanceUid: String,
    status: String
)

case class ChargeBeeCancelledEvent(
    id: String,
    customerId: String,
    currentTermStart: Long,
    currentTermEnd: Long,
    cancelledAt: Long,
    cfIssueTrackerUrl: String,
    cfInstanceUid: String,
    status: String
)

case class SubscriptionStatus(
    name: String
)

object SubscriptionStatus {
  implicit val statusFormat: OFormat[SubscriptionStatus] = Json.format[SubscriptionStatus]
}

object ChargeBeeSubscriptionValue {

  implicit val cbSubscriptionValueFormat: OFormat[ChargeBeeSubscriptionValue] =
    Json.format[ChargeBeeSubscriptionValue]

}

object ChargeBeeSubscriptionEvent {

  implicit val chargeBeeSubscriptionEventFormat: OFormat[ChargeBeeSubscriptionEvent] =
    Json.configured(JsonConfiguration(SnakeCase)).format

}

object ChargeBeeCancelledEvent {

  implicit val chargeBeeCancelledEventFormat: OFormat[ChargeBeeCancelledEvent] =
    Json.configured(JsonConfiguration(SnakeCase)).format

}
