package com.exalate.domain.values.license

case class LicensePayloadValue(payload: String)
