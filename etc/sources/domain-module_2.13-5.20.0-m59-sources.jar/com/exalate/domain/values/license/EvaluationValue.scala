package com.exalate.domain.values.license

import play.api.libs.json.{Json, OFormat}

case class EvaluationValue(
    trackertype: String,
    trackerurl: String,
    instanceUID: Option[String],
    requestUserMail: String,
    exalateURL: Option[String],
    proxyUser: String,
    licenseVersion: String
)

object EvaluationValue {
  implicit val format: OFormat[EvaluationValue] = Json.format
}
