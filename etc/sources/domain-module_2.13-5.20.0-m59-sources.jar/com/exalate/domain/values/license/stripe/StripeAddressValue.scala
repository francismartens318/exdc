package com.exalate.domain.values.license.stripe

case class StripeAddressValue(
    city: String,
    country: String,
    line1: String,
    line2: Option[String],
    postal_code: String,
    state: String
)
