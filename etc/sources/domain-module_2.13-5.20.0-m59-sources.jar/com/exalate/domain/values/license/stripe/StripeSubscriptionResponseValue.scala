package com.exalate.domain.values.license.stripe

case class StripeSubscriptionResponseValue(
    subscription_status: String,
    payment_intent_status: String,
    client_secret: Option[String]
)
