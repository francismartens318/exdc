package com.exalate.domain.values.license

import com.exalate.domain.{InstanceUId, RemoteInstanceUId}
import com.exalate.domain.values.license.TemporalLicense.EndDate
import com.exalate.domain.values.license.LicenseInfo.StartDate
import com.exalate.domain.values.license.PayloadBased.PayloadString

import java.time.LocalDate

sealed trait LicenseInfo {
  def instanceUId: InstanceUId
  def startDate: StartDate
  def isExpired: Boolean
  def isDeleted: Boolean

}

object LicenseInfo {
  case class StartDate(value: LocalDate) extends AnyVal
}

sealed trait PayloadBased extends LicenseInfo {
  def payload: PayloadString
}

object PayloadBased {
  case class PayloadString(value: String) extends AnyVal
}

sealed trait TemporalLicense extends LicenseInfo {
  def endDate: EndDate

}

object TemporalLicense {
  case class EndDate(value: LocalDate) extends AnyVal
}

sealed trait VolumeBased extends LicenseInfo {
  def volumeLimit: Long
  def previousVolumeRenewalDate: LocalDate
  def nextVolumeRenewalDate: LocalDate

}

sealed trait SubscriptionBased extends LicenseInfo with TemporalLicense {
  def subscriptionId: String
}

case class InstanceLicenseInfo(
    instanceUId: InstanceUId,
    startDate: StartDate,
    endDate: EndDate,
    isExpired: Boolean,
    payload: PayloadString,
    isDeleted: Boolean
) extends LicenseInfo
      with PayloadBased
      with TemporalLicense

case class NetworkLicenseInfo(
    instanceUId: InstanceUId,
    startDate: StartDate,
    endDate: EndDate,
    isExpired: Boolean,
    payload: PayloadString,
    maxPaidInstances: Long,
    paidInstances: Seq[RemoteInstanceUId],
    isDeleted: Boolean
) extends LicenseInfo
      with PayloadBased
      with TemporalLicense

case class FreemiumLicenseInfo(
    instanceUId: InstanceUId,
    startDate: StartDate,
    volumeLimit: Long,
    previousVolumeRenewalDate: LocalDate,
    nextVolumeRenewalDate: LocalDate,
    isExpired: Boolean = false,
    isDeleted: Boolean = false
) extends LicenseInfo
      with VolumeBased

case class EvaluationLicenseInfo(
    instanceUId: InstanceUId,
    startDate: StartDate,
    endDate: EndDate,
    isExpired: Boolean,
    payload: PayloadString,
    volumeLimit: Long,
    previousVolumeRenewalDate: LocalDate,
    nextVolumeRenewalDate: LocalDate,
    isDeleted: Boolean
) extends LicenseInfo
      with PayloadBased
      with TemporalLicense
      with VolumeBased

case class StripeLicenseInfo(
    instanceUId: InstanceUId,
    startDate: StartDate,
    endDate: EndDate,
    isExpired: Boolean,
    payload: PayloadString,
    subscriptionId: String,
    isDeleted: Boolean
) extends LicenseInfo
      with SubscriptionBased
      with PayloadBased

case class ChargeBeeLicenseInfo(
    instanceUId: InstanceUId,
    startDate: StartDate,
    endDate: EndDate,
    isExpired: Boolean,
    subscriptionId: String,
    status: String,
    isDeleted: Boolean
) extends LicenseInfo
      with SubscriptionBased

case class AllLicenseInfo(activeLicense: LicenseInfo, expiredLicense: Option[LicenseInfo] = None)
