package com.exalate.domain.values.license

case class ExalateLicensesValue(
    currentLicense: Option[LicenseValue],
    expiredLicense: Option[LicenseValue]
)
