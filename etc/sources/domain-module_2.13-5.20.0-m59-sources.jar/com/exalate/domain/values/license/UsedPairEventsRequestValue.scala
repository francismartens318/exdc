package com.exalate.domain.values.license

import play.api.libs.json.{Json, OFormat}

case class UsedPairEventsRequestValue(startAt: Long)

object UsedPairEventsRequestValue {

  implicit val format: OFormat[UsedPairEventsRequestValue] = Json.format
}
