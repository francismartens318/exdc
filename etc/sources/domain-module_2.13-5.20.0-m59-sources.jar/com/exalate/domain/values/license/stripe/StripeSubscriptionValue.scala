package com.exalate.domain.values.license.stripe

import play.api.libs.json.{Json, OFormat}
/*
{
  "id": "sub_F2HsOAEyPIJXdS",
  "object": "subscription",
  "application_fee_percent": null,
  "billing": "charge_automatically",
  "billing_cycle_anchor": 1557412387,
  "billing_thresholds": null,
  "cancel_at": null,
  "cancel_at_period_end": false,
  "canceled_at": null,
  "created": 1557412387,
  "current_period_end": 1560090787,
  "current_period_start": 1557412387,
  "customer": "cus_F2HstH8XlSUape",
  "days_until_due": null,
  "default_payment_method": "pm_1EYDIzKPzmPVgbC7eSg64hfM",
  "default_source": null,
  "default_tax_rates": [],
  "discount": null,
  "ended_at": null,
  "items": {
    "object": "list",
    "data": [
      {
        "id": "si_F2HsmkIX4lXRVg",
        "object": "subscription_item",
        "billing_thresholds": null,
        "created": 1557412388,
        "metadata": {},
        "plan": {
          "id": "plan_Eujo0LwNOWK1Lu",
          "object": "plan",
          "active": true,
          "aggregate_usage": null,
          "amount": 1000,
          "billing_scheme": "per_unit",
          "created": 1555671189,
          "currency": "eur",
          "interval": "month",
          "interval_count": 1,
          "livemode": false,
          "metadata": {},
          "nickname": "Exalate Github",
          "product": "prod_EtaYKnnBN0SS6E",
          "tiers": null,
          "tiers_mode": null,
          "transform_usage": null,
          "trial_period_days": null,
          "usage_type": "licensed"
        },
        "quantity": 1,
        "subscription": "sub_F2HsOAEyPIJXdS"
      }
    ],
    "has_more": false,
    "total_count": 1,
    "url": "/v1/subscription_items?subscription=sub_F2HsOAEyPIJXdS"
  },
  "latest_invoice": "in_1EYDJ1KPzmPVgbC7M9WQ5wAe",
  "livemode": false,
  "metadata": {
    "instanceUid": "dashpu12381283ja"
  },
  "plan": {
    "id": "plan_Eujo0LwNOWK1Lu",
    "object": "plan",
    "active": true,
    "aggregate_usage": null,
    "amount": 1000,
    "billing_scheme": "per_unit",
    "created": 1555671189,
    "currency": "eur",
    "interval": "month",
    "interval_count": 1,
    "livemode": false,
    "metadata": {},
    "nickname": "Exalate Github",
    "product": "prod_EtaYKnnBN0SS6E",
    "tiers": null,
    "tiers_mode": null,
    "transform_usage": null,
    "trial_period_days": null,
    "usage_type": "licensed"
  },
  "quantity": 1,
  "schedule": null,
  "start": 1557412387,
  "status": "active",
  "tax_percent": null,
  "trial_end": null,
  "trial_start": null
}
 */

case class StripeSubscriptionValue(
    id: String,
    current_period_start: Long,
    current_period_end: Long,
    metadata: Map[String, String],
    status: String,
    trial_end: Option[Long],
    customer: String
)

object StripeSubscriptionValue {
  implicit val format: OFormat[StripeSubscriptionValue] = Json.format
}
