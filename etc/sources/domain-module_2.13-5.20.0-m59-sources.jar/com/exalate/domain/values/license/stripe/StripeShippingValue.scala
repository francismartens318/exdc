package com.exalate.domain.values.license.stripe

case class StripeShippingValue(address: StripeAddressValue, name: String)
