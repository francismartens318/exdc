package com.exalate.domain.values.license.stripe

case class StripeCustomerValue(
    id: Option[String],
    address: StripeAddressValue,
    shipping: Option[StripeShippingValue],
    email: String,
    name: String,
    source: Option[String],
    metadata: Option[Map[String, String]],
    tax_id_data: Option[StripeVATValue]
)
