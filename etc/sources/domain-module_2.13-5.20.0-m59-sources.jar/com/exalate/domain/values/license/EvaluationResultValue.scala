package com.exalate.domain.values.license

case class EvaluationResultValue(resultCode: String, message: String, redirectTo: String)
