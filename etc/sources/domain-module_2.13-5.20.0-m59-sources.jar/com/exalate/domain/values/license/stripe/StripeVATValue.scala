package com.exalate.domain.values.license.stripe

case class StripeVATValue(
    `type`: String,
    value: String
)
