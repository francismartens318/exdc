package com.exalate.domain.values.license

import com.exalate.domain.utils.DateConverter.localDateToDate

import java.util.Date
import com.exalate.domain.values.connection.ConnectionValue
import play.api.libs.json.{Json, OFormat}

case class LicenseValue(
    isActive: Boolean,
    isEvaluation: Boolean,
    isFreemium: Boolean,
    isTrackerLicense: Boolean,
    startDate: Option[Date] = None,
    endDate: Option[Date] = None,
    isExpired: Boolean,
    key: Option[String] = None,
    connections: Option[Int] = None,
    usedConnections: Option[Int] = None,
    subscriptionId: Option[String] = None,
    numberOfPair: Option[Long] = None,
    usedPairEvents: Option[Long] = None,
    volumeBasedRenewDate: Option[Date] = None,
    calendarUnit: Option[String] = None,
    transactionRef: Option[String] = None, // (SEN../ EASE)
    licenseType: Option[String] = None, // (Commercial Network, Evaluation)
    status: Option[String] = None
)

object LicenseValue {

  implicit val format: OFormat[LicenseValue] = Json.format

  def convert(licenseInfo: LicenseInfo): LicenseValue =
    licenseInfo match {
      case network: NetworkLicenseInfo       =>
        LicenseValue(
          isActive = !network.isExpired,
          isEvaluation = false,
          isFreemium = false,
          isTrackerLicense = false,
          startDate = Option(localDateToDate(network.startDate.value)),
          endDate = Option(localDateToDate(network.endDate.value)),
          isExpired = network.isExpired,
          key = Option(network.payload.value),
          connections = Option(network.maxPaidInstances.toInt),
          usedConnections = Option(network.paidInstances.size)
        )
      case instance: InstanceLicenseInfo     =>
        LicenseValue(
          isActive = !instance.isExpired,
          isEvaluation = false,
          isFreemium = false,
          isTrackerLicense = false,
          startDate = Option(localDateToDate(instance.startDate.value)),
          endDate = Option(localDateToDate(instance.endDate.value)),
          isExpired = instance.isExpired,
          key = Option(instance.payload.value)
        )
      case evaluation: EvaluationLicenseInfo =>
        LicenseValue(
          isActive = !evaluation.isExpired,
          isEvaluation = true,
          isFreemium = false,
          isTrackerLicense = false,
          startDate = Option(localDateToDate(evaluation.startDate.value)),
          endDate = Option(localDateToDate(evaluation.endDate.value)),
          isExpired = evaluation.isExpired,
          numberOfPair = Option(evaluation.volumeLimit),
          key = Option(evaluation.payload.value),
          volumeBasedRenewDate = Option(localDateToDate(evaluation.nextVolumeRenewalDate))
        )
      case freemium: FreemiumLicenseInfo     =>
        LicenseValue(
          isActive = !freemium.isExpired,
          isEvaluation = false,
          isFreemium = true,
          isTrackerLicense = false,
          startDate = Option(localDateToDate(freemium.startDate.value)),
          endDate = None,
          isExpired = freemium.isExpired,
          numberOfPair = Option(freemium.volumeLimit),
          key = None,
          volumeBasedRenewDate = Option(localDateToDate(freemium.nextVolumeRenewalDate))
        )
      case stripe: StripeLicenseInfo         =>
        LicenseValue(
          isActive = !stripe.isExpired,
          isEvaluation = false,
          isFreemium = false,
          isTrackerLicense = false,
          startDate = Option(localDateToDate(stripe.startDate.value)),
          endDate = Option(localDateToDate(stripe.endDate.value)),
          isExpired = stripe.isExpired,
          key = Option(stripe.payload.value),
          subscriptionId = Option(stripe.subscriptionId)
        )
      case chargeBee: ChargeBeeLicenseInfo   =>
        LicenseValue(
          isActive = !chargeBee.isExpired,
          isEvaluation = false,
          isFreemium = false,
          isTrackerLicense = false,
          startDate = Option(localDateToDate(chargeBee.startDate.value)),
          endDate = Option(localDateToDate(chargeBee.endDate.value)),
          isExpired = chargeBee.isExpired,
          key = None,
          subscriptionId = Option(chargeBee.subscriptionId),
          status = Option(chargeBee.status)
        )
    }

}

case class LicensesValue(
    trackerLicense: Option[LicenseValue],
    exalateLicense: Option[LicenseValue],
    expiredExalateLicense: Option[LicenseValue],
    edgeNode: Boolean
)

case class LicenseUsageValue(connections: Seq[ConnectionValue], payed: Boolean)

case class LicenseUsageOverviewValue(connections: Int, usages: Seq[LicenseUsageValue])

case class LicenseValidationResult(exalateLicense: Boolean, trackerLicense: Boolean)

case class GetLicenseResult(licenseKey: String, email: String)
