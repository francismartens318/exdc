package com.exalate.domain.values.license.stripe

import play.api.libs.json.{Json, OFormat}

case class StripePaymentIntentValue(status: String, client_secret: String)

object StripePaymentIntentValue {
  implicit val format: OFormat[StripePaymentIntentValue] = Json.format
}

case class StripeInvoiceValue(id: String, payment_intent: StripePaymentIntentValue)

object StripeInvoiceValue {
  implicit val format: OFormat[StripeInvoiceValue] = Json.format
}

case class StripeExpandedSubscriptionValue(
    id: String,
    current_period_start: Long,
    current_period_end: Long,
    metadata: Map[String, String],
    status: String,
    trial_end: Option[Long],
    customer: String,
    latest_invoice: StripeInvoiceValue
)

object StripeExpandedSubscriptionValue {
  implicit val format: OFormat[StripeExpandedSubscriptionValue] = Json.format
}
