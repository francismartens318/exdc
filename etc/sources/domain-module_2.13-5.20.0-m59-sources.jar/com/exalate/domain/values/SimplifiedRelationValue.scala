package com.exalate.domain.values

import play.api.libs.json.{Json, OFormat}

case class SimplifiedRelationValue(
    id: Int,
    name: Option[String],
    status: Option[String],
    remoteInstance: Option[SimplifiedInstanceValue]
)

object SimplifiedRelationValue {
  implicit val format: OFormat[SimplifiedRelationValue] = Json.format
}
