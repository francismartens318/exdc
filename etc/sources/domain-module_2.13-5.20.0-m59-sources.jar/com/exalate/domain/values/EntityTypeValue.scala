package com.exalate.domain.values

import play.api.libs.json.{Json, OFormat}

case class EntityTypeValue(
    name: String,
    queryLanguageSupported: Boolean,
    label: Option[String],
    allowEmptyQuery: Boolean
)

object EntityTypeValue {
  implicit lazy val entityTypeValueFormat: OFormat[EntityTypeValue] = Json.format[EntityTypeValue]
}
