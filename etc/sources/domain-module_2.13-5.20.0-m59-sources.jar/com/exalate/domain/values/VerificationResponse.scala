package com.exalate.domain.values

case class VerificationResponse(result: String, email: String, status: String)
