package com.exalate.domain.values

import play.api.libs.json.{Json, OFormat}

case class BlobMetadataValue(
    id: Int,
    blobId: String,
    filePath: Option[String],
    checksum: Option[String]
)

object BlobMetadataValue {
  implicit val format: OFormat[BlobMetadataValue] = Json.format
}
