package com.exalate.domain.values

import com.exalate.domain.editor.FieldDataType
import com.exalate.domain.ObjectJsonFormatters._
import com.exalate.domain.transport.trackeroptions.{EditorFields, ScopeQueryOperators}
import com.exalate.util.json.gson.GsonCaseClassValueJsonService
import play.api.libs.json.Json.{toJson, WithDefaultValues}
import play.api.libs.json.{Json, OFormat}

case class OfValue(key: String)

object OfValue {
  implicit val format: OFormat[OfValue] = Json.format
}

case class FieldTypeValue(key: String, of: Option[Seq[OfValue]])

object FieldTypeValue {
  implicit val format: OFormat[FieldTypeValue] = Json.format
}

case class EditorFieldTypeValue(key: String, of: Option[Seq[EditorFieldTypeValue]]) {
  def toFieldTypeValue: FieldTypeValue = FieldTypeValue(key, of.map(_.map(o => OfValue(o.key))))
}

object EditorFieldTypeValue {
  implicit val format: OFormat[EditorFieldTypeValue] = Json.format
}

case class OperatorValue(key: String)

object OperatorValue {
  implicit val format: OFormat[OperatorValue] = Json.format
}

case class EditorFieldValue(
    key: String,
    label: String,
    placeholder: Option[String] = None,
    queryable: Option[Boolean] = Some(true),
    main: Option[Boolean] = Some(false),
    `type`: EditorFieldTypeValue,
    operators: Option[Seq[OperatorValue]] = Some(Seq.empty[OperatorValue])
) {
  lazy val isMain: Boolean = main.getOrElse(false)
  lazy val isQueryable: Boolean = queryable.getOrElse(false)
}

object EditorFieldValue {
  implicit val format: OFormat[EditorFieldValue] = Json.format
}

case class FeatureValue(key: String)

object FeatureValue {
  implicit val format: OFormat[FeatureValue] = Json.format
}

case class VisualFieldValue(
    adminProofUrlTemplate: Option[String],
    // keeping fields a Seq[Object] because we don't want to tie this value case class to Play Json.
    // And we need it to be Object to allow storing any sort of remote field info (even the ones we don't support yet)
    fields: Seq[Object] = Seq(
      Map(
        "key" -> EditorFields.PROJECT.toString,
        "label" -> "Project",
        "queryable" -> Some(false),
        "main" -> Some(true),
        "type" -> Map(
          "key" -> FieldDataType.OPTION.toString
        ),
        "operators" -> Some(
          Seq(
            Map("key" -> ScopeQueryOperators.IS.toString),
            Map("key" -> ScopeQueryOperators.IS_NOT.toString)
          )
        )
      ),
      Map(
        "key" -> EditorFields.LABELS.toString,
        "label" -> "Labels",
        "type" -> Map(
          "key" -> FieldDataType.MULTI.toString,
          "of" -> Seq(
            Map(
              "key" -> FieldDataType.TEXT.toString
            )
          )
        ),
        "operators" -> Some(
          Seq(
            Map("key" -> ScopeQueryOperators.IS.toString),
            Map("key" -> ScopeQueryOperators.IS_NOT.toString),
            Map("key" -> ScopeQueryOperators.IN.toString),
            Map("key" -> ScopeQueryOperators.NOT_IN.toString)
          )
        )
      ),
      Map(
        "key" -> EditorFields.ISSUE_TYPE.toString,
        "label" -> "Issue type",
        "type" -> Map(
          "key" -> FieldDataType.OPTION.toString
        ),
        "operators" -> Some(
          Seq(
            Map("key" -> ScopeQueryOperators.IS.toString),
            Map("key" -> ScopeQueryOperators.IS_NOT.toString)
          )
        )
      ),
      Map(
        "key" -> EditorFields.STATUS.toString,
        "label" -> "Status",
        "type" -> Map(
          "key" -> FieldDataType.OPTION.toString
        ),
        "operators" -> Some(
          Seq(
            Map("key" -> ScopeQueryOperators.IS.toString),
            Map("key" -> ScopeQueryOperators.IS_NOT.toString)
          )
        )
      ),
      Map(
        "key" -> EditorFields.PRIORITY.toString,
        "label" -> "Priority",
        "type" -> Map(
          "key" -> FieldDataType.OPTION.toString
        ),
        "operators" -> Some(
          Seq(
            Map("key" -> ScopeQueryOperators.IS.toString),
            Map("key" -> ScopeQueryOperators.IS_NOT.toString)
          )
        )
      ),
      Map(
        "key" -> EditorFields.SUMMARY.toString,
        "label" -> "Summary",
        "type" -> Map(
          "key" -> FieldDataType.TEXT.toString
        ),
        "operators" -> Some(
          Seq(
            Map("key" -> ScopeQueryOperators.IS.toString),
            Map("key" -> ScopeQueryOperators.IS_NOT.toString),
            Map("key" -> ScopeQueryOperators.CONTAINS.toString),
            Map("key" -> ScopeQueryOperators.DOES_NOT_CONTAIN.toString)
          )
        )
      ),
      Map(
        "key" -> EditorFields.DESCRIPTION.toString,
        "label" -> "Description",
        "type" -> Map(
          "key" -> FieldDataType.TEXT.toString
        ),
        "operators" -> Some(
          Seq(
            Map("key" -> ScopeQueryOperators.IS.toString),
            Map("key" -> ScopeQueryOperators.IS_NOT.toString),
            Map("key" -> ScopeQueryOperators.CONTAINS.toString),
            Map("key" -> ScopeQueryOperators.DOES_NOT_CONTAIN.toString)
          )
        )
      ),
      Map(
        "key" -> EditorFields.COMMENTS.toString,
        "label" -> "Comments",
        "type" -> Map(
          "key" -> FieldDataType.MULTI.toString,
          "of" -> Some(Seq(Map("key" -> FieldDataType.COMMENT.toString)))
        ),
        "queryable" -> Some(false)
      ),
      Map(
        "key" -> EditorFields.ATTACHMENTS.toString,
        "label" -> "Attachments",
        "type" -> Map(
          "key" -> FieldDataType.MULTI.toString,
          "of" -> Some(Seq(Map("key" -> FieldDataType.FILE.toString)))
        ),
        "queryable" -> Some(false)
      ),
      Map(
        "key" -> EditorFields.ASSIGNEE.toString,
        "label" -> "Assignee",
        "placeholder" -> Some("Email or user id"),
        "type" -> Map(
          "key" -> FieldDataType.USER.toString
        ),
        "operators" -> Some(
          Seq(
            Map("key" -> ScopeQueryOperators.IS.toString),
            Map("key" -> ScopeQueryOperators.IS_NOT.toString)
          )
        )
      ),
      Map(
        "key" -> EditorFields.REPORTER.toString,
        "label" -> "Reporter",
        "placeholder" -> Some("Email or user id"),
        "type" -> Map(
          "key" -> FieldDataType.USER.toString
        ),
        "operators" -> Some(
          Seq(
            Map("key" -> ScopeQueryOperators.IS.toString),
            Map("key" -> ScopeQueryOperators.IS_NOT.toString)
          )
        )
      ),
      Map(
        "key" -> EditorFields.DUE.toString,
        "label" -> "Due date",
        "type" -> Map(
          "key" -> FieldDataType.DATE.toString
        ),
        "queryable" -> Some(false), // TODO support date in filters
        "operators" -> Some(Nil)
      )
    ),
    features: Option[Seq[FeatureValue]] = Some(Seq(FeatureValue("DATE_SUPPORT")))
) {

  def editorFields: Seq[EditorFieldValue] =
    this.fields.flatMap(o => Json.toJson(o).asOpt[EditorFieldValue])

}

object VisualFieldValue {
  implicit val format: OFormat[VisualFieldValue] = Json.using[WithDefaultValues].format
}

case class EditorCustomFieldResponseValue(
    accessToken: Option[String],
    key: String,
    customFieldValue: EditorFieldValue
)

object EditorCustomFieldResponseValue {

  implicit val format: OFormat[EditorCustomFieldResponseValue] =
    Json.using[WithDefaultValues].format

}
