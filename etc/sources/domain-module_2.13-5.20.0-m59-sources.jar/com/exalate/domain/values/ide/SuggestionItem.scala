package com.exalate.domain.values.ide

import com.exalate.api.domain.hubobject.EntityType

import play.api.libs.json.{Json, OFormat}

/** suggestion of a custom field or a helper methods
  *
  * @param name
  *   custom field or helper method name
  * @param description
  *   description
  * @param signature
  *   type signature of field or method
  * @param entityType
  *   entity type under which custom field belongs (for salesforce and snow)
  */
case class SuggestionItem(
    name: String,
    signature: Option[String],
    description: Option[String],
    entityType: Option[String]
)

object SuggestionItem {

  implicit val format: OFormat[SuggestionItem] = Json.format[SuggestionItem]

  def apply(name: String): SuggestionItem =
    SuggestionItem(name, None, None, None)

  // FYI, this will need to be renamed when we need constructor for `name` and `description`.
  def apply(name: String, signature: Option[String]): SuggestionItem =
    SuggestionItem(name, signature, None, None)

  def apply(name: String, entityType: EntityType): SuggestionItem =
    SuggestionItem(name, None, None, Some(entityType.label))

}
