package com.exalate.domain.values.ide

import play.api.libs.json.{Json, OFormat}

case class Suggestions(suggestions: Seq[SuggestionValue])

object Suggestions {
  implicit val format: OFormat[Suggestions] = Json.format[Suggestions]
}
