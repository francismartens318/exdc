package com.exalate.domain.values.ide

import play.api.libs.json.{Json, OFormat}

/** code completion information to render on frontend
  *
  * example,
  *   - `issue.customFields."CUSTOM FIELD"`
  *   - `entity.customKeys."KEY1"`
  *   - `attachmentHelper.mergeAttachments`
  *
  * @param quoted
  *   render suggestion item with or without quotes
  * @param variables
  *   variable name, possibly more than one. (ex. zendesk can use `issue` and `ticket`)
  * @param accessor
  *   field or method name of variable, could be empty.
  * @param items
  *   list of suggestion items
  */
case class SuggestionValue(
    quoted: Boolean,
    variables: Seq[String],
    accessor: Option[String],
    items: Seq[SuggestionItem]
)

object SuggestionValue {
  implicit val format: OFormat[SuggestionValue] = Json.format[SuggestionValue]

  def renderQuoted(
      variables: Seq[String],
      accessor: Option[String],
      items: Seq[SuggestionItem]
  ): SuggestionValue =
    SuggestionValue(quoted = true, variables, accessor, items)

  def replica(items: Seq[SuggestionItem]): SuggestionValue =
    SuggestionValue.renderSimple(List("replica"), None, items)

  def renderSimple(
      variables: Seq[String],
      accessor: Option[String],
      items: Seq[SuggestionItem]
  ): SuggestionValue =
    SuggestionValue(quoted = false, variables, accessor, items)

}
