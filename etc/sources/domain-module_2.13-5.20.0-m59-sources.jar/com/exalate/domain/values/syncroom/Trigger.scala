package com.exalate.domain.values.syncroom

import com.exalate.api.domain.trigger.ITrigger
import play.api.libs.json.{Json, OFormat}

/** Trigger response object
  * @param id
  *   type: integer description: The identifier of a specific trigger on a node
  * @param status
  *   type: string enum: ["ACTIVE", "DEACTIVATED"]
  * @param entityType
  *   type: string description: The type of entity that is affected by the trigger
  * @param query
  *   type: string description: The query for the trigger, for example a JQL filter on a project key
  *   in jira cloud example: "project = DEV"
  * @param notes
  *   type: string description: Some additional information about the trigger
  */
case class Trigger(id: Int, status: String, entityType: String, query: String, notes: String)

object Trigger {
  implicit val format: OFormat[Trigger] = Json.format[Trigger]

  def apply(trigger: ITrigger): Trigger =
    Trigger(
      trigger.getId,
      trigger.getStatus.name(),
      trigger.getEntityType,
      trigger.getJqlFilter,
      trigger.getNotes
    )

}

case class TriggerRequest(
    status: String,
    entityType: String,
    query: Option[String],
    notes: Option[String]
)

object TriggerRequest {

  implicit val format: OFormat[TriggerRequest] = Json.format[TriggerRequest]

}

case class TriggerValidationResult(isValid: Boolean, totalIssueUrns: Long, error: Option[String])

object TriggerValidationResult {
  implicit val format: OFormat[TriggerValidationResult] = Json.format[TriggerValidationResult]
}
