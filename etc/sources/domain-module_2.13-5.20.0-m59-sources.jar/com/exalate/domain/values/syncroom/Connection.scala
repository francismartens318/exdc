package com.exalate.domain.values.syncroom

import com.exalate.api.domain.connection.{ConnectionStatus, IConnection}
import com.exalate.api.domain.connection.fieldvalues.ConnectionMode
import play.api.libs.json.{Format, JsString, JsValue, Json, Reads, Writes}

import scala.util.Try

case class Connection(
    id: String,
    name: String,
    status: ConnectionStatus,
    description: Option[String],
    remoteUrl: String,
    mode: ConnectionMode
)

object Connection {

  def apply(connection: IConnection): Connection =
    Connection(
      name = connection.getName,
      status = connection.getStatus,
      mode = getConnectionMode(connection.getMode),
      description = Option(connection.getDescription),
      id = connection.getID.toString,
      remoteUrl = Try(connection.getRemoteInstance.getNodeInfo.getExalateUrl).getOrElse("")
    )

  private def getConnectionMode(mode: String): ConnectionMode =
    if (mode == null || mode.isEmpty) {
      ConnectionMode.SCRIPT
    } else {
      ConnectionMode.valueOf(mode)
    }

  implicit val connectionStatusWrites: Writes[ConnectionStatus] =
    Writes[ConnectionStatus] { value: ConnectionStatus =>
      JsString(value.toString)
    }

  implicit val connectionStatusReads: Reads[ConnectionStatus] =
    Reads[ConnectionStatus] { jsValue: JsValue =>
      jsValue.validate[String].map(ConnectionStatus.valueOf)
    }

  implicit val connectionModeWrites: Writes[ConnectionMode] =
    Writes[ConnectionMode] { value: ConnectionMode =>
      JsString(value.toString)
    }

  implicit val connectionModeReads: Reads[ConnectionMode] =
    Reads[ConnectionMode] { jsValue: JsValue =>
      jsValue.validate[String].map(getConnectionMode)
    }

  implicit val connectionWrites: Format[Connection] = Json.format[Connection]

}
