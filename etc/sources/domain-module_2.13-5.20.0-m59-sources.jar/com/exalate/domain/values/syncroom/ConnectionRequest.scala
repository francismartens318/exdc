package com.exalate.domain.values.syncroom

/** Create/Update connection request
  * @param status
  *   \- The desired ACTIVE or DEACTIVATED state
  * @param description
  *   \- The description of the connection
  */
case class ConnectionRequest(status: String, description: Option[String])

object ConnectionRequest {
  import play.api.libs.json.{Format, Json}
  implicit val connectionRequestFormat: Format[ConnectionRequest] = Json.format[ConnectionRequest]
}
