package com.exalate.domain.values.syncroom

import com.exalate.domain.values.syncroom.ScriptsDirection.ScriptsDirection
import play.api.libs.json.{Json, OFormat}

/** Script
  * @param script
  *   \- The script
  * @param direction
  *   \- The direction of the script
  */
case class Script(script: String, direction: ScriptsDirection)

object Script {
  implicit val format: OFormat[Script] = Json.format[Script]
}

case class ValidScript(isValid: Boolean, errors: Option[String] = None)

object ValidScript {
  implicit val format: OFormat[ValidScript] = Json.format[ValidScript]
}
