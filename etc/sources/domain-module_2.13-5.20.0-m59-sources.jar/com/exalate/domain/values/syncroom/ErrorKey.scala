package com.exalate.domain.values.syncroom

/** Types of errors that might trigger during request handling from Sync Room
  */
object ErrorKey extends Enumeration {
  type ErrorKey = Value

  val CONSTRAINT_VIOLATION: ErrorKey = Value
  val DATA_INTEGRITY_VIOLATION: ErrorKey = Value
  val ENTITY_ALREADY_EXISTS: ErrorKey = Value
  val ENTITY_PROPERTY_NOT_UNIQUE: ErrorKey = Value
  val FORBIDDEN: ErrorKey = Value
  val REQUEST_METHOD_NOT_ALLOWED: ErrorKey = Value
  val REQUEST_METHOD_NOT_FOUND: ErrorKey = Value
  val REQUEST_MISSING_FORM_MULTIPART: ErrorKey = Value
  val REQUEST_MISSING_PARAMETER: ErrorKey = Value
  val REQUEST_PARAMETER_TYPE_MISMATCH: ErrorKey = Value
  val REQUEST_PARAMETER_INVALID: ErrorKey = Value
  val REQUEST_TIMEOUT: ErrorKey = Value
  val REQUEST_UNAUTHENTICATED: ErrorKey = Value
  val ENTITY_NOT_FOUND: ErrorKey = Value
  val UNKNOWN: ErrorKey = Value

}
