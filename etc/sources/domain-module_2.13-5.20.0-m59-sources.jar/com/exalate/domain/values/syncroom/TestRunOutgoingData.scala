package com.exalate.domain.values.syncroom

import play.api.libs.json.{Json, OFormat}

case class TestRunOutgoingData(script: Script, issueUrns: Seq[IssueFields])

object TestRunOutgoingData {
  implicit val format: OFormat[TestRunOutgoingData] = Json.format[TestRunOutgoingData]
}

case class TestRunOutgoingResponse(
    issue: IssueFields,
    replica: Option[String],
    errors: Option[Seq[Error]] = None
)

case class IssueFields(urn: Option[String], key: Option[String], entityType: Option[String])

object IssueFields {
  implicit val format: OFormat[IssueFields] = Json.format[IssueFields]
}

object TestRunOutgoingResponse {
  implicit val format: OFormat[TestRunOutgoingResponse] = Json.format[TestRunOutgoingResponse]
}

case class Error(message: String)

object Error {
  implicit val format: OFormat[Error] = Json.format[Error]
}
