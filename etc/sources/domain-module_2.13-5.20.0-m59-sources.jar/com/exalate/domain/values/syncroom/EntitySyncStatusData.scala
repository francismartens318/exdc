package com.exalate.domain.values.syncroom

import play.api.libs.json.{Json, OFormat}

case class EntitySyncStatusData(
    entityExists: Boolean,
    localEntitySyncStatus: Option[EntitySyncStatus] = None,
    statuses: Option[Seq[StatusData]] = None
)

object EntitySyncStatusData {
  implicit val format: OFormat[EntitySyncStatusData] = Json.format[EntitySyncStatusData]
}

case class EntitySyncStatus(issueUrn: String, url: String, summary: String)

object EntitySyncStatus {
  implicit val format: OFormat[EntitySyncStatus] = Json.format[EntitySyncStatus]
}

case class StatusData(
    connectionId: Int,
    status: String,
    twinTraceId: Int,
    remoteEntitySyncStatus: Option[EntitySyncStatus]
)

object StatusData {
  implicit val format: OFormat[StatusData] = Json.format[StatusData]
}
