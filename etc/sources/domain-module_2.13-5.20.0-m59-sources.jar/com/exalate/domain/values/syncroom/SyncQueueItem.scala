package com.exalate.domain.values.syncroom

import com.exalate.api.domain.IError
import com.exalate.api.domain.event.ISyncEvent
import com.exalate.api.domain.request.ISyncRequest
import play.api.libs.json.{Json, OFormat}

case class SyncQueueItemOutgoing(
    id: Int,
    connectionId: Int,
    eventNumber: Long,
    localIssueUrn: Option[String],
    remoteIssueUrn: Option[String],
    localReplica: Option[String],
    errors: Seq[NodeError]
)

object SyncQueueItemOutgoing {
  implicit val format: OFormat[SyncQueueItemOutgoing] = Json.format[SyncQueueItemOutgoing]

  def apply(itemId: Int, event: ISyncEvent, errors: Seq[IError]): SyncQueueItemOutgoing = {
    val localReplica = Option(event.getLocalReplica)
    SyncQueueItemOutgoing(
      id = itemId,
      connectionId = event.getConnection.getID,
      eventNumber = event.getEventNumber,
      localIssueUrn = localReplica.map(_.getIssueKey.getURN),
      localReplica = localReplica.map(_.getPayload),
      remoteIssueUrn = Option(event.getRemoteReplica).map(_.getIssueKey.getURN),
      errors = errors.map(NodeError(_))
    )
  }

}

case class SyncQueueItemIncoming(
    id: Int,
    connectionId: Int,
    eventNumber: Long,
    localIssueUrn: Option[String],
    remoteIssueUrn: Option[String],
    remoteReplica: Option[String],
    errors: Seq[NodeError]
)

object SyncQueueItemIncoming {
  implicit val format: OFormat[SyncQueueItemIncoming] = Json.format[SyncQueueItemIncoming]

  def apply(itemId: Int, request: ISyncRequest, errors: Seq[IError]): SyncQueueItemIncoming = {
    val remoteReplica = Option(request.getReplica)
    SyncQueueItemIncoming(
      id = itemId,
      connectionId = request.getConnection.getID,
      eventNumber = request.getRemoteSyncEventNumber,
      localIssueUrn = Option(request.getSyncedTo).map(_.getURN),
      remoteIssueUrn = remoteReplica.map(_.getIssueKey.getURN),
      remoteReplica = remoteReplica.map(_.getPayload),
      errors = errors.map(NodeError(_))
    )
  }

}
