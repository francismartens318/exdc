package com.exalate.domain.values.syncroom

import play.api.libs.json.{Json, OFormat}

case class Issue(
    id: String,
    entityType: String,
    issueUrn: String,
    `type`: Option[String],
    summary: Option[String]
)

object Issue {
  implicit val format: OFormat[Issue] = Json.format[Issue]
  implicit val paginatedResultFormat: OFormat[PaginatedResult[Issue]] = PaginatedResult.format
}
