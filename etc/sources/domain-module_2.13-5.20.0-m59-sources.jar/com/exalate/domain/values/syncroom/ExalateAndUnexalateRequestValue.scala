package com.exalate.domain.values.syncroom

import play.api.libs.json.{Json, OFormat}

case class ExalateAndUnexalateRequestValue(connection: Int, entityType: String)

object ExalateAndUnexalateRequestValue {

  implicit val format: OFormat[ExalateAndUnexalateRequestValue] =
    Json.format[ExalateAndUnexalateRequestValue]

}

case class ConnectRequestValue(
    connection: Int,
    entityType: String,
    remoteIssueUrn: String,
    synchronizeComments: Boolean,
    synchronizeAttachments: Boolean,
    synchronizeWorklogs: Boolean,
    triggerSyncEvent: Boolean,
    triggerUpdate: Boolean
)

object ConnectRequestValue {
  implicit val format: OFormat[ConnectRequestValue] = Json.format[ConnectRequestValue]
}
