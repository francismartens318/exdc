package com.exalate.domain.values.syncroom

import com.exalate.api.domain.IError
import play.api.libs.json.{Json, OFormat}

final case class NodeError(
    id: Int,
    stacktrace: Option[String],
    creationTime: Long,
    `type`: String,
    rootCause: Option[String],
    rootCauseDetails: Option[String],
    connectionId: Option[Int],
    localIssueUrn: Option[String],
    remoteIssueUrn: Option[String]
)

object NodeError {

  def apply(error: IError): NodeError =
    NodeError(
      id = error.getId,
      stacktrace = Option(error.getStackTrace),
      creationTime = error.getCreationTime.getTime,
      `type` = error.getErrorEntityType.name(),
      rootCause = Option(error.getRootCauseErrorTypeName),
      rootCauseDetails = Option(error.getRootCauseDetails),
      connectionId = Option(error.getConnection.getID),
      localIssueUrn = Option(error.getIssueKey).map(_.getURN),
      remoteIssueUrn = Option(error.getConnectRemoteIssueUrn)
    )

  implicit val format: OFormat[NodeError] = Json.format[NodeError]
  implicit val paginatedResultFormat: OFormat[PaginatedResult[NodeError]] = PaginatedResult.format
}
