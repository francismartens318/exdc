package com.exalate.domain.values.syncroom

import play.api.libs.json.{Json, OFormat}

case class SyncQueueStatisticsData(
    incoming: Int,
    incomingAttachments: Int,
    outgoing: Int,
    outgoingAttachments: Int
)

object SyncQueueStatisticsData {
  implicit val format: OFormat[SyncQueueStatisticsData] = Json.format[SyncQueueStatisticsData]
}

case class SyncQueueItemsData(
    id: Int,
    localIssueUrn: Option[String],
    remoteIssueUrn: Option[String],
    connectionId: Int,
    status: String,
    errorId: Option[Int],
    fileName: Option[String] = None,
    fileSize: Option[Long] = None
)

object SyncQueueItemsData {
  implicit val format: OFormat[SyncQueueItemsData] = Json.format[SyncQueueItemsData]
}
