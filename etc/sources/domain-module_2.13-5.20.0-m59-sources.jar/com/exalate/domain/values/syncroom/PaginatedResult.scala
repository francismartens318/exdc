package com.exalate.domain.values.syncroom

import com.exalate.domain.values.PageResult
import play.api.libs.json.{Json, OFormat}

final case class PaginatedResult[+T](
    total: Int,
    results: Seq[T],
    offset: Option[Int],
    limit: Option[Int]
) {

  def map[R](f: T => R): PaginatedResult[R] =
    this.copy(results = results.map(f))

}

object PaginatedResult {

  def apply[T](pageResult: PageResult[T]): PaginatedResult[T] =
    PaginatedResult(
      total = pageResult.total,
      results = pageResult.results,
      offset = pageResult.pageRequest.offset,
      limit = pageResult.pageRequest.limit
    )

  implicit def format[T: OFormat]: OFormat[PaginatedResult[T]] = Json.format
}
