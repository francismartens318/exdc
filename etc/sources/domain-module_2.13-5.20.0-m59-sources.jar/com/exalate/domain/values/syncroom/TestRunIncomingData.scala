package com.exalate.domain.values.syncroom

import play.api.libs.json.{Json, OFormat}

case class TestRunIncomingData(script: Script, sourceReplicas: List[SourceReplica])

object TestRunIncomingData {
  implicit val format: OFormat[TestRunIncomingData] = Json.format[TestRunIncomingData]
}

case class SourceReplica(sourceIssue: IssueFields, sourceReplica: String)

object SourceReplica {
  implicit val format: OFormat[SourceReplica] = Json.format[SourceReplica]
}

case class TestRunIncomingResponse(
    sourceIssue: IssueFields,
    targetIssue: IssueFields,
    targetReplica: Option[String],
    errors: Option[Seq[Error]]
)

object TestRunIncomingResponse {
  implicit val format: OFormat[TestRunIncomingResponse] = Json.format[TestRunIncomingResponse]
}
