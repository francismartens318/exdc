package com.exalate.domain.values.syncroom

import play.api.libs.json.{Json, OFormat}

case class Replicas(localReplica: String, remoteReplica: Option[String])

object Replicas {
  implicit val format: OFormat[Replicas] = Json.format[Replicas]
}
