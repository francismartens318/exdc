package com.exalate.domain.values.syncroom

import play.api.libs.json.{Json, OFormat}

/** NodeInfo response object
  * @param instanceUid
  *   type: string format: uuid description: The unique identifier of a node example:
  *   ece581b5-abd9-49b2-8122-9308adf99a3e
  * @param baseUrl
  *   type: string description: The baseURL of the node example:
  *   https://jcloudnode-abcd-efgh-ijkm-lmno.exalate.cloud
  * @param name
  *   type: string
  * @param issueTrackerUrl
  *   type: string description: The URL of the issue tracker for which the node is responsible
  *   example: https://my-jira-instance.atlassian.net
  * @param adminUrl
  *   type: string description: The URL of the admin interface on the issue tracker itself example:
  *   https://my-jira-instance.atlassian.net/plugins/servlet/ac/com.exalate.jiranode/general-item
  * @param nodeType
  *   type: string enum: ["JIRA_CLOUD", "GITHUB", "ZENDESK", "SERVICE_NOW", "AZURE_DEVOPS",
  *   "SALESFORCE"]
  * @param nodeVersion
  *   type: string; description: The software version that the node is running; example: 5.13.0
  * @param rawNodeVersion
  *   type: string; description: The raw software version that the node is running; example:
  *   5.13.0-m14
  */
case class NodeInfoForSyncRoom(
    instanceUid: String,
    baseUrl: String,
    name: String,
    issueTrackerUrl: String,
    adminUrl: String,
    nodeType: String,
    nodeVersion: String,
    rawNodeVersion: String
)

object NodeInfoForSyncRoom {

  implicit val nodeInfoForSyncRoomFormat: OFormat[NodeInfoForSyncRoom] =
    Json.format[NodeInfoForSyncRoom]

}
