package com.exalate.domain.values.syncroom

import play.api.libs.json._

object ScriptsDirection extends Enumeration {
  type ScriptsDirection = Value

  val INCOMING: ScriptsDirection = Value
  val OUTGOING: ScriptsDirection = Value

  implicit val scriptsDirectionReads: Reads[ScriptsDirection] = Reads.enumNameReads(ScriptsDirection)
  implicit val scriptsDirectionWrites: Writes[ScriptsDirection] = Writes.enumNameWrites

}
