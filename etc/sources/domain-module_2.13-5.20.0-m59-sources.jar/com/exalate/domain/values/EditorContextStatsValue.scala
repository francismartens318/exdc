package com.exalate.domain.values

case class EditorContextStatsValue(
    expectedCustomFieldsNumber: Option[Int] = None,
    actualCustomFieldsNumber: Option[Int] = None,
    expectedOptionsNumber: Option[Int] = None,
    actualOptionsNumber: Option[Int] = None
)
