package com.exalate.domain.values

import play.api.libs.json.{Json, OFormat}

case class SyncPriorityValue(number: Int, displayText: String)

object SyncPriorityValue {
  implicit val format: OFormat[SyncPriorityValue] = Json.format
}
