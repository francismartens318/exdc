package com.exalate.domain.values.v3_6

import com.exalate.domain.values.NodeInfoValue

case class UpgradeBasicConnectionResponseValue(
    connectionName: String,
    syncMainFieldInfo: Option[String],
    nodeInfo: NodeInfoValue
)
