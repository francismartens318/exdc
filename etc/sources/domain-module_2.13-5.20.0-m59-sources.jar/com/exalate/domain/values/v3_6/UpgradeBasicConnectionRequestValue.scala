package com.exalate.domain.values.v3_6

import com.exalate.domain.values.NodeInfoValue

case class UpgradeBasicConnectionRequestValue(
    connectionName: String,
    mode: String,
    accessToken: Option[String],
    nodeInfo: NodeInfoValue
)
