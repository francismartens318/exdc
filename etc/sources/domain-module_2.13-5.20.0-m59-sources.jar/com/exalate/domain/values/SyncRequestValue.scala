package com.exalate.domain.values

import play.api.libs.json.{Json, OFormat}

case class SyncRequestValue(
    id: Int,
    remoteEventNumber: Long,
    status: String,
    deletedRemoteIssueUrn: Option[String],
    unexalateRemoteIssueUrn: Option[String],
    connectIssueUrn: Option[String],
    errorReason: Option[String],
    errorResponseMessage: Option[String],
    relation: SimplifiedRelationValue,
    localIssueKey: Option[String],
    updatedReplica: Option[ReplicaValue],
    remoteReplica: Option[ReplicaValue],
    errorId: Option[Int],
    remoteTwinTraceId: Option[Int],
    syncType: Option[String],
    priority: SyncPriorityValue
)

object SyncRequestValue {
  implicit val format: OFormat[SyncRequestValue] = Json.format
}
