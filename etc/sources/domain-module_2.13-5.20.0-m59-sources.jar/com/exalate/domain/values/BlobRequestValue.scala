package com.exalate.domain.values

import play.api.libs.json.{Json, OFormat}

case class BlobRequestValue(
    id: Int,
    status: String,
    syncRequest: SyncRequestValue,
    blobMetadata: BlobMetadataValue,
    errorResponseReason: Option[String],
    errorResponseMessage: Option[String],
    errorId: Option[Int],
    fileName: String,
    fileSize: Long
)

object BlobRequestValue {
  implicit val format: OFormat[BlobRequestValue] = Json.format
}
