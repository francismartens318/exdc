package com.exalate.domain.values

case class TrackerConfig(
    showSyncStatusSearch: Boolean,
    localSupported: Boolean,
    showGetEvaluation: Boolean,
    showInstanceLicense: Boolean,
    tokenAuthSupported: Boolean,
    mainEntity: String,
    showSelectEntityTypeOnExalateDialog: Boolean,
    showSignOutButton: Boolean
)
