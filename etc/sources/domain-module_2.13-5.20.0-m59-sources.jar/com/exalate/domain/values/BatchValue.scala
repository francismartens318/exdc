package com.exalate.domain.values

case class BatchValue[T <: ChunkValue](chunkValues: Array[T])
