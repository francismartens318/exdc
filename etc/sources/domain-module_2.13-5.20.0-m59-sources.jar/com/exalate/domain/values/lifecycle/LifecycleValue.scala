package com.exalate.domain.values.lifecycle

import java.util.Date

case class LifecycleValue(
    isEulaAccepted: Boolean,
    getRegistrationDate: Date,
    lastErrorEmailDate: Option[Date],
    lastLicenseEmailDate: Option[Date] = None,
    exalateVersion: Option[String],
    context: LifecycleContextValue,
    isWarningPeriod: Option[Boolean] = None,
    expiryDate: Option[Date] = None,
    uninstallDate: Option[Date] = None,
    instanceUid: Option[String],
    verified: Boolean,
    lastArchiveWarningEmailDate: Option[Date] = None
)
