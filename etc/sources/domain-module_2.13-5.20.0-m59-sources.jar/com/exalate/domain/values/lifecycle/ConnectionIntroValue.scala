package com.exalate.domain.values.lifecycle

case class ConnectionIntroValue(show: Boolean, shownFor: Seq[String])
