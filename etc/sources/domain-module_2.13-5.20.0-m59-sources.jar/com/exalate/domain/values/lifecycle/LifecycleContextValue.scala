package com.exalate.domain.values.lifecycle

case class LifecycleContextValue(connectionIntro: ConnectionIntroValue, firstVisit: Boolean)
