package com.exalate.domain.values

import play.api.libs.json.{Json, OFormat}

case class SimplifiedInstanceValue(id: Int, name: String, status: Option[String], url: Option[String])

object SimplifiedInstanceValue {
  implicit val format: OFormat[SimplifiedInstanceValue] = Json.format
}
