package com.exalate.domain.values

case class AuthenticationValue(
    user: Option[String],
    password: Option[String],
    token: Option[String],
    authProtocol: String
) {
  override def toString = s"AuthenticationValue($user, $token, $authProtocol)"
}
