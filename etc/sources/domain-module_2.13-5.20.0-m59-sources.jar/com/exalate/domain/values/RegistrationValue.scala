package com.exalate.domain.values

case class RegistrationValue(companyName: String, fullName: String, email: String)
