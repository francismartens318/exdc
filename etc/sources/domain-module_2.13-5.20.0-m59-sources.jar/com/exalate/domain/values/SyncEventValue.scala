package com.exalate.domain.values

import play.api.libs.json.{Json, OFormat}

case class SyncEventValue(
    id: Int,
    eventNumber: Long,
    status: String,
    deletedIssueUrn: Option[String],
    unexalateIssueUrn: Option[String],
    connectRemoteIssueUrn: Option[String],
    errorResponseReason: Option[String],
    errorResponseMessage: Option[String],
    relation: SimplifiedRelationValue,
    localReplica: Option[ReplicaValue],
    remoteReplica: Option[ReplicaValue],
    errorId: Option[Int],
    remoteTwinTraceId: Option[Int],
    twinTraceId: Option[Int],
    syncType: Option[String],
    priority: SyncPriorityValue
)

object SyncEventValue {
  implicit val format: OFormat[SyncEventValue] = Json.format
}
