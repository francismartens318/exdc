package com.exalate.domain.values

case class MappingEditorField(
    key: String,
    label: String,
    `type`: FieldTypeValue,
    placeholder: Option[String] = None
)

case class SingleSideMappingsParamsValue(fields: Seq[MappingEditorField])

case class MappingsParamsValue(
    local: SingleSideMappingsParamsValue,
    remote: Option[SingleSideMappingsParamsValue]
)
