package com.exalate.domain.values

case class BulkConnectValidationResult(
    overused: Boolean,
    limit: Int,
    allowedSync: Int,
    mappingCount: Int
)
