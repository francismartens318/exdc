package com.exalate.domain.values

case class NodeInfoUpdateValue(relationName: String, nodeInfo: NodeInfoValue)
