package com.exalate.domain.values

import play.api.libs.json.{Json, OFormat}

case class ConnectFile(name: String, url: String)

object ConnectFile {
  implicit val connectFileFormat: OFormat[ConnectFile] = Json.format[ConnectFile]
}
