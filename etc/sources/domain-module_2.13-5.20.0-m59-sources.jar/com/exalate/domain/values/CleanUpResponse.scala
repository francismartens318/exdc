package com.exalate.domain.values

import play.api.libs.json.{Format, Json, OFormat, Reads, Writes}

case class CleanUpResponse(relationName: String, issuePairs: Seq[IssuePairs], file: ConnectFile)

object CleanUpResponse {
  implicit val cleanUpResponseFormat: OFormat[CleanUpResponse] = Json.format[CleanUpResponse]

  implicit val seqCleanUpResponseFormat: Format[Seq[CleanUpResponse]] =
    Format(Reads.traversableReads[Seq, CleanUpResponse], Writes.seq[CleanUpResponse])

}

case class IssuePairs(localIssueUrn: String, remoteIssueUrn: String)

object IssuePairs {
  implicit val issuePairsFormat: OFormat[IssuePairs] = Json.format[IssuePairs]

  implicit val seqIssuePairsFormatFormat: Format[Seq[IssuePairs]] =
    Format(Reads.traversableReads[Seq, IssuePairs], Writes.seq[IssuePairs])

}

case class RemoteSupportsCleanUpResult(remoteSupportsCleanUp: Boolean)

object RemoteSupportsCleanUpResult {

  implicit val format: OFormat[RemoteSupportsCleanUpResult] =
    Json.format[RemoteSupportsCleanUpResult]

}
