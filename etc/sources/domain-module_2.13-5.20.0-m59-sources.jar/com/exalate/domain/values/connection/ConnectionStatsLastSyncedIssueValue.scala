package com.exalate.domain.values.connection

import play.api.libs.json.{Json, OFormat}

case class ConnectionStatsLastSyncedIssueValue(
    id: String,
    key: String,
    entityType: String,
    date: Long
)

object ConnectionStatsLastSyncedIssueValue {
  implicit val format: OFormat[ConnectionStatsLastSyncedIssueValue] = Json.format
}
