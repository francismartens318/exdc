package com.exalate.domain.values.connection

case class ConnectionCreatedResult(resultMessage: String, connection: ConnectionValue)
