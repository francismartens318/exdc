package com.exalate.domain.values.connection

import com.exalate.api.domain.connectiondraft.{ConnectionDraftOperation, ConnectionDraftStatus}
import com.exalate.domain.editor.mappings.MappingValue
import com.exalate.domain.editor.scopes.ScopeValue
import play.api.libs.json.{Json, OFormat}

import java.sql.Timestamp

case class ConnectionDraft(
    id: Option[Int],
    createdOn: Timestamp,
    status: ConnectionDraftStatus,
    connectionId: Int,
    operation: ConnectionDraftOperation
)

case class ConnectionDraftRequestValue(
    draftId: Int,
    createdOn: Long,
    status: String,
    connectionId: Int,
    operation: String,
    scopes: Seq[ScopeValue],
    mappings: Seq[MappingValue],
    accessToken: Option[String]
)

object ConnectionDraftRequestValue {
  implicit val format: OFormat[ConnectionDraftRequestValue] = Json.format
}

case class ConnectionDraftResponseValue(draftId: Int, status: String)

object ConnectionDraftResponseValue {
  implicit val format: OFormat[ConnectionDraftResponseValue] = Json.format
}
