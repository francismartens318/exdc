package com.exalate.domain.values.connection

import com.exalate.domain.values.NodeInfoValue
import play.api.libs.json.{Json, OFormat}

case class InvitationValue(
    invitationSecret: String,
    invitedInstanceUid: Option[String],
    nodeInfo: NodeInfoValue,
    connection: ConnectionValue
)

object InvitationValue {
  implicit val format: OFormat[InvitationValue] = Json.format
}
