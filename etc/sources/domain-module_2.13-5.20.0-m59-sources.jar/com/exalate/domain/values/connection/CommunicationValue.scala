package com.exalate.domain.values.connection

import com.exalate.domain.values.NodeInfoValue
import play.api.libs.json.{Json, OFormat}

case class CommunicationValue(
    sendProtocol: String,
    receiveProtocol: Option[String],
    localUrl: Option[String],
    remoteUrl: Option[String],
    issueTrackerUrl: Option[String],
    localNodeInfo: Option[NodeInfoValue],
    remoteNodeInfo: Option[NodeInfoValue],
    proxyUsername: Option[String],
    proxyPassword: Option[String]
) {

  override def toString = s"CommunicationValue(" +
    s"$sendProtocol, " +
    s"$receiveProtocol, " +
    s"$localUrl, " +
    s"$remoteUrl, " +
    s"$issueTrackerUrl, " +
    s"$localNodeInfo, " +
    s"$remoteNodeInfo, " +
    s"${proxyUsername.map(_ => "***")}, " +
    s"${proxyPassword.map(_ => "***")}" +
    s")"

}

object CommunicationValue {

  implicit val format: OFormat[CommunicationValue] = Json.format

}
