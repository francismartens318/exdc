package com.exalate.domain.values.connection

import play.api.libs.json.{Json, OFormat}

case class ConnectionStatsValue(
    hasErrors: Boolean,
    issuesUnderSync: Int,
    commentsUnderSync: Int,
    attachmentsUnderSync: Int,
    lastIssueSynced: Option[ConnectionStatsLastSyncedIssueValue]
)

object ConnectionStatsValue {
  implicit val format: OFormat[ConnectionStatsValue] = Json.format[ConnectionStatsValue]
}
