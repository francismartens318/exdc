package com.exalate.domain.values.connection

/** Holds mode which were chosen on th UI for upgrading connection from BASIC to either
  * CONFIGURE_BOTH_SIDES or scripted
  * @param mode
  */
case class ConnectionModeValue(mode: String)
