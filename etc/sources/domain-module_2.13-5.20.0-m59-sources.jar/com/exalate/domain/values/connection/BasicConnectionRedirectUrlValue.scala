package com.exalate.domain.values.connection

/** Holds redirect url with invitation code for initialization of BASIC connection
  * @param url
  */
case class BasicConnectionRedirectUrlValue(url: String)
