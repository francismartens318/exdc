package com.exalate.domain.values.connection

case class InvitedCode(invitedCode: String)
