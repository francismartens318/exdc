package com.exalate.domain.values.connection

import com.exalate.api.domain.instance.{INonPersistentInstance, InstanceStatus}
import com.exalate.basic.domain.instance.NonPersistentInstance
import com.exalate.domain.editor.error.EditorErrorValue
import com.exalate.domain.editor.mappings.MappingValue
import com.exalate.domain.editor.scopes.ScopeValue
import play.api.libs.json.{Json, OFormat}

import java.net.URL
import scala.util.Try

case class ConnectionValue(
    id: Option[Int],
    name: String,
    // mode == None => pre 5.0.0 connection - still scripts and triggers are to be used
    // mode == Some(CONFIGURE_ONE_SIDE) => a >= 5.X connection - new interface is shown for Dual Admin
    // mode == Some(CONFIGURE_BOTH_SIDES) => a >= 5.X connection - new interface is shown for Single Admin
    mode: Option[String] = None,
    status: Option[String],
    invitationStatus: Option[String],
    description: Option[String],
    syncRules: Option[SyncRulesValue],
    communication: CommunicationValue,
    isLocal: Option[Boolean],
    localInstanceName: Option[String],
    remoteInstanceName: Option[String],
    scopes: Option[Seq[ScopeValue]],
    mappings: Option[Seq[MappingValue]],
    stats: Option[ConnectionStatsValue] = None,
    mappingErrors: Option[Seq[EditorErrorValue]] = None,
    editorContextProgress: Option[String] = None,
    isManagedRemotely: Option[Boolean] = None
)

object ConnectionValue {

  def toNonPersistentInstance(connectionValue: ConnectionValue): INonPersistentInstance =
    new NonPersistentInstance(
      connectionValue.remoteInstanceName.getOrElse(connectionValue.name),
      null,
      connectionValue.communication.remoteUrl.flatMap(url => Try(new URL(url)).toOption).orNull,
      null,
      InstanceStatus.ACTIVE,
      null,
      null,
      connectionValue.communication.proxyUsername.orNull,
      connectionValue.communication.proxyPassword.orNull,
      false,
      null,
      null
    )

  implicit val format: OFormat[ConnectionValue] = Json.format

}

case class ConnectionValueForList(
    id: Option[Int],
    name: String,
    // mode == None => pre 5.0.0 connection - still scripts and triggers are to be used
    // mode == Some(CONFIGURE_ONE_SIDE) => a >= 5.X connection - new interface is shown for Dual Admin
    // mode == Some(CONFIGURE_BOTH_SIDES) => a >= 5.X connection - new interface is shown for Single Admin
    status: Option[String],
    invitationStatus: Option[String],
    description: Option[String],
    isLocal: Option[Boolean],
    communication: CommunicationValue,
    stats: Option[ConnectionStatsValue] = None,
    mode: Option[String],
    hasRemoteAccess: Option[Boolean] = None,
    isManagedRemotely: Option[Boolean] = None
)

object ConnectionValueForList {
  implicit val format: OFormat[ConnectionValueForList] = Json.format
}

case class ConnectionSimplifiedValue(id: Int, name: String)

object ConnectionSimplifiedValue {
  implicit val format: OFormat[ConnectionSimplifiedValue] = Json.format
}
