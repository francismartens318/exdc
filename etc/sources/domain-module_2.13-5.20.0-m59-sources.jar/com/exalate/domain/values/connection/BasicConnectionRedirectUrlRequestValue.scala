package com.exalate.domain.values.connection

case class BasicConnectionRedirectUrlRequestValue(
    issueTrackerUrl: String,
    invitationCode: String,
    exalateUrl: String
)
