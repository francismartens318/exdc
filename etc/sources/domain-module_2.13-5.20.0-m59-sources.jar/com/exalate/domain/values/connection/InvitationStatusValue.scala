package com.exalate.domain.values.connection

case class InvitationStatusValue(invitationStatus: String)
