package com.exalate.domain.values.connection

import com.exalate.domain.editor.scopes.ValueOfFieldValue
import play.api.libs.json.{Json, OFormat}

/** 'MainFieldInfoValue' - info about local/remote project that was chosen during connection
  * establishing which is added to "relation" table and is received from UI side in 'syncRules' (in
  * SF data from UI doesn't contain 'filedInfo') looks like "mainFieldInfo" : { local : [{ key :
  * "PROJECT", value: { value : "id", label : "name+key" } }], remote: [{ ... }] // Option // only
  * for local connection both - local and remote 'mainFieldInfo' should be reworked as
  * Option[SingleMainFieldInfoValue] as long as one connection contains one project
  * (https://iproducts.atlassian.net/browse/XLT-4590)
  * @param local
  * @param remote
  */
case class SingleMainFieldInfoValue(key: String, value: ValueOfFieldValue)

object SingleMainFieldInfoValue {

  implicit val format: OFormat[SingleMainFieldInfoValue] = Json.format

}

case class MainFieldInfoValue(
    local: Option[Seq[SingleMainFieldInfoValue]],
    remote: Option[Seq[SingleMainFieldInfoValue]]
)

object MainFieldInfoValue {

  implicit val format: OFormat[MainFieldInfoValue] = Json.format

}
