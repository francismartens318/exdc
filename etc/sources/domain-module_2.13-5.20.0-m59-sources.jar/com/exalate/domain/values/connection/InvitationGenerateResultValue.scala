package com.exalate.domain.values.connection

case class InvitationGenerateResultValue(message: String, invitationCode: String)
