package com.exalate.domain.values.connection

import play.api.libs.json.{Json, OFormat}

case class SyncRulesValue(
    dataFilter: Option[String],
    createProcessor: Option[String],
    changeProcessor: Option[String],
    version: String,
    incomingProcessor: Option[String],
    postExalateProcessor: Option[String],
    hpqcDomain: Option[String],
    hpqcProject: Option[String],
    hpqcLinkField: Option[String],
    linkType: Option[
      String
    ] /* can also be Some("SYNC_PANEL") / Some("REMOTE_ISSUE_LINK") / Some("NONE") / Some("BOTH") */,
    fieldValues: Option[Map[String, String]],
    mainFieldInfo: Option[MainFieldInfoValue]
)

object SyncRulesValue {
  implicit val format: OFormat[SyncRulesValue] = Json.format
}
