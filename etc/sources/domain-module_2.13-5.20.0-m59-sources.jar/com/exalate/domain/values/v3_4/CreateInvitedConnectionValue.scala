package com.exalate.domain.values.v3_4

import com.exalate.domain.values.connection.InvitationValue

case class CreateInvitedConnectionValue(adminProofToken: String, invitationValue: InvitationValue)
