package com.exalate.domain.values

import play.api.libs.json.{Json, OFormat}

case class NodeInfoValue(
    id: Option[Int],
    name: String,
    baseUrl: Option[String],
    issueTrackerUrl: Option[String],
    nodeType: String,
    issueTrackerVersion: String,
    nodeAppVersion: String,
    nodeVersion: String,
    exalatePluginVersion: String,
    minHubObjectsVersion: String,
    maxHubObjectsVersion: String,
    minRestVersion: String,
    maxRestVersion: String,
    pollOnly: Option[Boolean],
    exaCompVersion: Option[String],
    rawExaCompVersion: Option[String],
    instanceUid: Option[String],
    editor: Option[VisualFieldValue],
    iconUrl: Option[String],
    basicConnection: Option[BasicConnectionValue]
)

object NodeInfoValue {
  implicit val format: OFormat[NodeInfoValue] = Json.format
}
