package com.exalate.domain.utils

import java.time._
import java.util.Date

object DateConverter {

  def now(zone: ZoneId = ZoneOffset.UTC): LocalDate = Instant.now().atZone(zone).toLocalDate

  def dateToLocalDate(dateToConvert: Date, zone: ZoneId = ZoneOffset.UTC): LocalDate =
    dateToConvert.toInstant.atZone(zone).toLocalDate

  def dateToLocalDateTime(dateToConvert: Date, zone: ZoneId = ZoneOffset.UTC): LocalDateTime =
    dateToConvert.toInstant.atZone(zone).toLocalDateTime

  def longToLocalDate(dateToConvert: Long, zone: ZoneId = ZoneOffset.UTC): LocalDate =
    Instant.ofEpochMilli(dateToConvert).atZone(zone).toLocalDate

  def longToLocalDateTime(dateToConvert: Long, zone: ZoneId = ZoneOffset.UTC): LocalDateTime =
    Instant.ofEpochMilli(dateToConvert).atZone(zone).toLocalDateTime

  def localDateToLong(dateToConvert: LocalDate, zone: ZoneId = ZoneOffset.UTC): Long =
    dateToConvert.atStartOfDay(zone).toInstant.toEpochMilli

  def localDateToSeconds(dateToConvert: LocalDate, zone: ZoneId = ZoneOffset.UTC): Long =
    dateToConvert.atStartOfDay(zone).toInstant.getEpochSecond

  def secondsToLocalDate(dateToConvert: Long, zone: ZoneId = ZoneOffset.UTC): LocalDate =
    Instant.ofEpochSecond(dateToConvert).atZone(zone).toLocalDate

  def localDateToDate(dateToConvert: LocalDate, zone: ZoneId = ZoneOffset.UTC): Date =
    Date.from(dateToConvert.atStartOfDay(zone).toInstant)

  def localDateTimeToDate(dateToConvert: LocalDateTime, zone: ZoneOffset = ZoneOffset.UTC): Date =
    Date.from(dateToConvert.toInstant(zone))

  def localDateTimeToLong(dateToConvert: LocalDateTime, zone: ZoneId = ZoneOffset.UTC): Long =
    dateToConvert.atZone(zone).toInstant.toEpochMilli

}
