package com.exalate.domain

import java.sql.Timestamp
import java.util.UUID

case class TemporaryData(
    id: String,
    data: String,
    message: Option[String] = None,
    invitedInstanceUid: Option[String] = None,
    connectionName: Option[String] = None,
    updatedAt: Timestamp = new Timestamp(System.currentTimeMillis())
) {

  def toTemporaryDataDAO: TemporaryDataDAO = TemporaryDataDAO(
    UUID.fromString(id),
    data,
    message,
    invitedInstanceUid,
    connectionName,
    updatedAt
  )

}

case class TemporaryDataDAO(
    id: UUID,
    data: String,
    message: Option[String] = None,
    invitedInstanceUid: Option[String] = None,
    connectionName: Option[String] = None,
    updatedAt: Timestamp = new Timestamp(System.currentTimeMillis())
) {

  def toTemporaryData: TemporaryData =
    TemporaryData(id.toString, data, message, invitedInstanceUid, connectionName, updatedAt)

}
