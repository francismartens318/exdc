package com.exalate.domain.ai

import play.api.libs.json.{Json, OFormat}

case class AISettingsValue(enabled: Boolean = true)

object AISettingsValue {

  implicit val aiSettingsValueFormat: OFormat[AISettingsValue] =
    Json.format[AISettingsValue]

}
