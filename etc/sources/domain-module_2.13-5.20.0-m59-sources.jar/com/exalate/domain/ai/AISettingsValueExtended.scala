package com.exalate.domain.ai

import play.api.libs.json.{Json, OFormat}

case class AISettingsValueExtended(aiSettingsValue: AISettingsValue, serviceURL: String)

object AISettingsValueExtended {

  implicit val aiSettingsValueExtendedFormat: OFormat[AISettingsValueExtended] =
    Json.format[AISettingsValueExtended]

}
