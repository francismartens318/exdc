package com.exalate.domain.jira

import com.exalate.domain.InferredGeneralSettings

case class JiraInferredGeneralSettings(
    id: Option[Int],
    exalateUrl: Option[String],
    issueTrackerUrl: String,
    instanceUid: Option[String],
    emailNotifications: Boolean,
    inJiraNotifications: Boolean,
    proxyUsername: Option[String],
    pollingFrequency: Long,
    showExalateConnect: Boolean,
    showUnexalate: Boolean,
    showDisabledConnections: Boolean,
    authRequired: Boolean
) extends InferredGeneralSettings {
  override def getExalateUrl: Option[String] = exalateUrl

  override def getIssueTrackerUrl: String = issueTrackerUrl

  override def getAuthRequired: Boolean = authRequired

  override def fieldValues: Map[String, String] = Map.empty

  override def getInstanceUid: Option[String] = instanceUid
}
