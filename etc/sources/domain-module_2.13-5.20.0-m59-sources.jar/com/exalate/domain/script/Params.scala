package com.exalate.domain.script

import com.exalate.basic.domain.hubobject.v1.{
  BasicHubAttachment,
  BasicHubComment,
  BasicHubOption,
  BasicHubUser
}

import java.util.Date

sealed trait Params

sealed trait OptionParams extends Params

case class HubOptionOptionParams(v: BasicHubOption) extends OptionParams
case class StringOptionParams(v: String) extends OptionParams
case class UserOptionParams(v: BasicHubUser) extends OptionParams

sealed trait DateParams extends Params

case class StringDateParams(v: String, format: String) extends DateParams
case class DateDateParams(v: Date) extends DateParams

sealed trait TextParams extends Params

case class StringTextParams(v: String) extends TextParams
case class DateTextParams(v: Date) extends TextParams
case class HubOptionTextParams(v: BasicHubOption) extends TextParams
case class HubUserTextParams(v: BasicHubUser) extends TextParams
case class SetStringTextParams(v: java.util.Set[String]) extends TextParams

sealed trait MultiTextParams extends Params

case class StringsMultiTextParams(strings: java.util.Collection[String]) extends MultiTextParams

sealed trait FileParams extends Params

case class HubAttachmentFileParams(v: java.util.List[BasicHubAttachment]) extends FileParams

sealed trait UserParams extends Params

case class HubUserUserParams(v: BasicHubUser) extends UserParams
case class StringUserParams(v: String) extends UserParams

sealed trait CommentParams extends Params

case class HubCommentCommentParams(v: java.util.List[BasicHubComment]) extends CommentParams
