package com.exalate.domain.twintrace

case class TwinTraceCreateParams(useRemoteScope: Option[Boolean] = None)
