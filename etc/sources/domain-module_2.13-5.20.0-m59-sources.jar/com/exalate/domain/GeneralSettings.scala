package com.exalate.domain

case class GeneralSettings(
    exalateUrl: Option[String],
    issueTrackerUrl: String,
    fieldValues: Map[String, String],
    instanceUid: Option[String] = None
) extends InferredGeneralSettings {
  override def getExalateUrl: Option[String] = exalateUrl

  override def getIssueTrackerUrl: String = issueTrackerUrl

  override def getAuthRequired: Boolean = true

  override def getInstanceUid: Option[String] = instanceUid
}
