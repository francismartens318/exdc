package com.exalate.domain.exception.config

import com.exalate.api.domain.ErrorEntityType
import com.exalate.api.exception.config.ExalateConfigException

case class ConnectionOnRemoteSideNotFoundExalateConfigException(message: String, cause: Throwable)
    extends ExalateConfigException(message, cause) {

  def this(message: String) = this(message, null)

  override def getDocsLink: String = ""

  override def getRootCauseErrorTypeName: String =
    "Connection was not found on the Destination side"

  override def getErrorEntityType: ErrorEntityType = ErrorEntityType.RELATION
}

object ConnectionOnRemoteSideNotFoundExalateConfigException {

  def apply(message: String): ConnectionOnRemoteSideNotFoundExalateConfigException =
    new ConnectionOnRemoteSideNotFoundExalateConfigException(message)

}
