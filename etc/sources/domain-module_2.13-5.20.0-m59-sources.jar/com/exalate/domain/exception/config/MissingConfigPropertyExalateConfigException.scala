package com.exalate.domain.exception.config

import com.exalate.api.exception.config.ExalateConfigException

case class MissingConfigPropertyExalateConfigException(message: String, cause: Throwable)
    extends ExalateConfigException(message, cause) {

  def this(message: String) = this(message, null)

  override def getDocsLink: String = ""

  override def getRootCauseErrorTypeName: String = "Missing configuration property"
}
