package com.exalate.domain.exception.editor

import com.exalate.api.domain.editor.error.{EditorErrorSide, ErrorLocationType}
import com.exalate.api.exception.CategorizedException
import com.exalate.domain.editor.error._
import com.exalate.domain.editor.mappings.Mappings
import com.exalate.domain.editor.scopes.SingleSideScope
import com.exalate.domain.transport.trackeroptions.EditorFields
import com.exalate.domain.values.EditorFieldValue

abstract class EditorCategorizedException(val editorError: EditorError, val cause: Option[Throwable])
    extends CategorizedException(editorError.errorValue.key, cause.orNull) {
  override def getDocsLink: String = "https://docs.exalate.com/docs/dealing-with-specific-errors"
  override def getRootCauseErrorTypeName: String = "Connection configuration"

  def getBlockingKey: String = editorError.toString
}

/** Exception which is returned when Project is not specified in visual rules. SCOPE Exceptions
  * @param scopeUid
  * @param projectName
  * @param projectId
  * @param `type`
  * @param side
  * @param cause
  */
final case class NoProjectEditorCategorizedException(
    scopeUid: String,
    projectName: String,
    projectId: String,
    `type`: ErrorLocationType,
    side: EditorErrorSide = EditorErrorSide.LOCAL,
    override val cause: Option[Throwable] = None
) extends EditorCategorizedException(
      ScopeMainFieldEditorError(
        scopeUid,
        EditorFields.PROJECT.toString,
        side,
        EditorErrorValue(
          "com.exalate.admin.editor.errors.stale.project",
          s"The project $projectName ($projectId) does not exist. Please select a valid project.",
          Some(Map("0" -> projectName, "1" -> projectId))
        )
      ),
      cause
    )

/** Exception which is returned when the query field is Stale
  * @param scopeUid
  * @param label
  * @param field
  * @param fieldLabel
  * @param side
  * @param cause
  */
final case class StaleQueryValueEditorCategorizedException(
    scopeUid: String,
    label: String, // Task
    field: String, // ISSUE_TYPE
    fieldLabel: String, // Issue Type
    side: EditorErrorSide = EditorErrorSide.LOCAL,
    override val cause: Option[Throwable] = None
) extends EditorCategorizedException(
      ScopeQueryEditorError(
        scopeUid,
        field,
        side,
        EditorErrorValue(
          "com.exalate.admin.editor.errors.stale.query",
          s"There's no $fieldLabel `$label` anymore",
          Some(
            Map(
              "0" -> fieldLabel,
              "1" -> label
            )
          )
        )
      ),
      cause
    )

//MAPPING Exceptions
/** Exception which is returned when recovery/mapping is missing
  * @param mapping
  * @param side
  * @param replicaValueStr
  * @param cause
  */
final case class RecoveryMappingEditorException(
    mapping: Mappings,
    side: EditorErrorSide,
    replicaValueStr: String,
    override val cause: Option[Throwable] = None
) extends EditorCategorizedException(
      MappingEditorError(
        mapping.id.get,
        side,
        EditorErrorValue(
          "com.exalate.admin.editor.errors.mappings.recovery",
          s"Missing mapping. Please add mapping for `$replicaValueStr`.",
          Some(Map("0" -> s"$replicaValueStr"))
        )
      ),
      cause
    )

/** Exception which is returned when recovery value is not available
  * @param mapping
  * @param side
  * @param replicaValueStr
  * @param cause
  */
final case class RecoveryDefaultMappingEditorException(
    mapping: Mappings,
    side: EditorErrorSide,
    replicaValueStr: String,
    override val cause: Option[Throwable] = None
) extends EditorCategorizedException(
      RecoveryDefaultEditorError(
        mapping.id.get,
        side,
        EditorErrorValue(
          "com.exalate.admin.editor.errors.mappings.default.recovery",
          s"The default value `$replicaValueStr` is not available.Please set a new default value.",
          Some(Map("0" -> s"$replicaValueStr"))
        )
      ),
      cause
    )

/** Exception which is returned when mapping maps is not valid or not found
  * @param mapping
  * @param localMapValue
  * @param remoteMapValue
  * @param side
  * @param receivingField
  * @param cause
  */
final case class MappingMapsEditorException(
    mapping: Mappings,
    localMapValue: String,
    remoteMapValue: String,
    side: EditorErrorSide,
    receivingField: EditorFieldValue,
    override val cause: Option[Throwable] = None
) extends EditorCategorizedException(
      MappingMapsEditorError(
        mapping.id.get, // if we have exception it means that we already have mapping with id
        localMapValue,
        remoteMapValue,
        side,
        EditorErrorValue(
          "com.exalate.admin.editor.errors.mappings.maps",
          s"`${receivingField.label}` with name `$localMapValue` is not found. Please select a valid `${receivingField.label}`.",
          Some(Map("0" -> receivingField.label, "1" -> localMapValue))
        )
      ),
      cause
    )

/** Exception which is returned when mapping maps field is disabled
  * @param mapping
  * @param localMapValue
  * @param remoteMapValue
  * @param side
  * @param receivingField
  * @param cause
  */
final case class MappingMapsDisabledEditorException(
    mapping: Mappings,
    localMapValue: String,
    remoteMapValue: String,
    side: EditorErrorSide,
    receivingField: EditorFieldValue,
    override val cause: Option[Throwable] = None
) extends EditorCategorizedException(
      MappingMapsEditorError(
        mapping.id.get, // if we have exception it means that we already have mapping with id
        localMapValue,
        remoteMapValue,
        side,
        EditorErrorValue(
          "com.exalate.admin.editor.errors.mappings.maps.disabled",
          s"${receivingField.label} with name $localMapValue is disabled",
          Some(Map("0" -> receivingField.label, "1" -> localMapValue))
        )
      ),
      cause
    )

/** Exception which is returned when a required field mapping is missed
  * @param receivingField
  * @param cause
  */
final case class MissingMappingEditorException(
    receivingField: EditorFieldValue,
    override val cause: Option[Throwable] = None
) extends EditorCategorizedException(
      MissingMappingEditorError(
        EditorErrorValue(
          "com.exalate.admin.editor.errors.mappings.missing",
          s"No mapping for a required field. Please add mapping for ${receivingField.label} field.",
          Some(Map("0" -> receivingField.label))
        )
      ),
      cause
    )

/** Exception which is returned when one of the field mapping is missed
  * @param errorFromIssueTracker
  * @param mapping
  * @param side
  * @param receivingField
  * @param cause
  */
final case class OverallMappingEditorException(
    errorFromIssueTracker: String,
    mapping: Mappings,
    side: EditorErrorSide,
    receivingField: EditorFieldValue,
    override val cause: Option[Throwable] = None
) extends EditorCategorizedException(
      MappingEditorError(
        mapping.id.get,
        side,
        EditorErrorValue(
          "com.exalate.admin.editor.errors.mappings",
          errorFromIssueTracker,
          Some(Map("0" -> errorFromIssueTracker))
        )
      ),
      cause
    )

/** Exception which is returned when the custom Field Mapping is Stale
  * @param mapping
  * @param side
  * @param receivingField
  * @param cause
  */
final case class StaleCustomFieldMappingEditorException(
    mapping: Mappings,
    side: EditorErrorSide,
    receivingField: EditorFieldValue,
    override val cause: Option[Throwable] = None
) extends EditorCategorizedException(
      MappingEditorError(
        mapping.id.get,
        side,
        EditorErrorValue(
          "com.exalate.admin.editor.errors.mappings.field.stale",
          s"`${receivingField.label}` (${receivingField.key}) can not be found!",
          Some(Map("0" -> receivingField.label, "1" -> receivingField.key))
        )
      ),
      cause
    )

/** Exception which is returned when the problem with mapping scripts
  * @param errorFromExecution
  * @param mapping
  * @param cause
  */
final case class ScriptEditorException(
    errorFromExecution: String,
    mapping: Mappings,
    override val cause: Option[Throwable] = None
) extends EditorCategorizedException(
      ScriptMappingEditorError(
        mapping.id,
        EditorErrorValue(
          "com.exalate.admin.editor.errors.mappings.script",
          errorFromExecution,
          Some(Map("0" -> errorFromExecution))
        )
      ),
      cause
    )

/** Exception which is returned when the problem with scope scripts
  * @param errorFromExecution
  * @param scope
  * @param cause
  */
final case class ScopeScriptEditorException(
    errorFromExecution: String,
    scope: SingleSideScope,
    override val cause: Option[Throwable] = None
) extends EditorCategorizedException(
      ScriptScopeEditorError(
        scope.id.get,
        EditorErrorValue(
          "com.exalate.admin.editor.errors.scopes.script",
          errorFromExecution,
          Some(Map("0" -> errorFromExecution))
        )
      ),
      cause
    )

/** Exception which is returned when the problem with general scripts
  * @param fieldLabel
  * @param mapping
  * @param cause
  */
final case class BlameScriptEditorException(
    fieldLabel: String,
    mapping: Mappings,
    override val cause: Option[Throwable] = None
) extends EditorCategorizedException(
      ScriptMappingEditorError(
        mapping.id,
        EditorErrorValue(
          "com.exalate.admin.editor.errors.mappings.script.blame",
          s"This script rule might be removing the value from `$fieldLabel`",
          Some(Map("0" -> fieldLabel))
        )
      ),
      cause
    )
