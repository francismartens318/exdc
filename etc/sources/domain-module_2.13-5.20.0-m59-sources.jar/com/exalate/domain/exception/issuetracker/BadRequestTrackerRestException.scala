package com.exalate.domain.exception.issuetracker

class BadRequestTrackerRestException(message: String) extends TrackerRestException(message, 400)

object BadRequestTrackerRestException {
  def unapply(e: BadRequestTrackerRestException): Option[String] = Some(e.message)
}
