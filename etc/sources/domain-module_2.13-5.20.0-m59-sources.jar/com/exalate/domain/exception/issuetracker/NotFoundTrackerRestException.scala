package com.exalate.domain.exception.issuetracker

class NotFoundTrackerRestException(message: String) extends TrackerRestException(message, 404) {
  override def getRootCauseErrorTypeName: String = "Resource not found error"

  override def getDocsLink: String = ""
}

object NotFoundTrackerRestException {
  def unapply(e: NotFoundTrackerRestException): Option[String] = Some(e.message)
}
