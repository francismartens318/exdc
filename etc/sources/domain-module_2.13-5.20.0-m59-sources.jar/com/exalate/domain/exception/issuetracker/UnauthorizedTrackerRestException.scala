package com.exalate.domain.exception.issuetracker

class UnauthorizedTrackerRestException(message: String) extends TrackerRestException(message, 401) {

  override def getRootCauseErrorTypeName: String = "Unauthorized error"

  override def getDocsLink: String = ""
}

object UnauthorizedTrackerRestException {
  def unapply(e: UnauthorizedTrackerRestException): Option[String] = Some(e.message)
}
