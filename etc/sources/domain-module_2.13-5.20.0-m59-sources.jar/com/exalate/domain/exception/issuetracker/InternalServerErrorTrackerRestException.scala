package com.exalate.domain.exception.issuetracker

class InternalServerErrorTrackerRestException(message: String)
    extends TrackerRestException(message, 500) {

  override def getRootCauseErrorTypeName: String = "Internal server error"

  override def getDocsLink: String = ""
}

object InternalServerErrorTrackerRestException {
  def unapply(e: InternalServerErrorTrackerRestException): Option[String] = Some(e.message)
}
