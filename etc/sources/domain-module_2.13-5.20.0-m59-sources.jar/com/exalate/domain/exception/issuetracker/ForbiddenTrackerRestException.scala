package com.exalate.domain.exception.issuetracker

class ForbiddenTrackerRestException(message: String) extends TrackerRestException(message, 403) {

  override def getRootCauseErrorTypeName: String = "Permissions error"

  override def getDocsLink: String = ""
}

object ForbiddenTrackerRestException {
  def unapply(e: ForbiddenTrackerRestException): Option[String] = Some(e.message)
}
