package com.exalate.domain.exception.issuetracker

class NotAuthenticatedTrackerRestException(message: String)
    extends TrackerRestException(message, 401) {

  override def getRootCauseErrorTypeName: String = "Authentication error"

  override def getDocsLink: String = ""
}

object NotAuthenticatedTrackerRestException {
  def unapply(e: NotAuthenticatedTrackerRestException): Option[String] = Some(e.message)
}
