package com.exalate.domain.exception.issuetracker

import com.exalate.api.exception.IssueTrackerException

case class TrackerRestException(message: String, statusCode: Int)
    extends IssueTrackerException(message)
