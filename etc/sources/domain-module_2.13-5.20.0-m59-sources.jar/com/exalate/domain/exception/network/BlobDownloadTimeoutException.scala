package com.exalate.domain.exception.network

import com.exalate.api.exception.network.AvailabilityNetworkException

case class BlobDownloadTimeoutException(message: String, cause: Throwable)
    extends AvailabilityNetworkException(message, cause)
