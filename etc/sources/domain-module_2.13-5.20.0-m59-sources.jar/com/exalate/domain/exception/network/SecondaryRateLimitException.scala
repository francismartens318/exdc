package com.exalate.domain.exception.network

import com.exalate.api.exception.network.AvailabilityNetworkException

import scala.concurrent.duration.{Duration, _}

object SecondaryRateLimitException {

  def apply(
      message: Option[String],
      cause: Option[Throwable],
      nextRetryIn: Option[Duration] = Some(30.seconds)
  ): SecondaryRateLimitException = new SecondaryRateLimitException(
    message,
    cause,
    nextRetryIn
  )

  def unapply(
      arg: SecondaryRateLimitException
  ): Option[(Option[String], Option[Throwable], Option[Duration])] = Some(
    (
      arg.message,
      arg.cause,
      arg.nextRetryIn
    )
  )

}

class SecondaryRateLimitException(
    val message: Option[String],
    val cause: Option[Throwable],
    val nextRetryIn: Option[Duration]
) extends AvailabilityNetworkException(message.orNull, cause.orNull) {
  override def toString = s"SecondaryRateLimitException($message, $cause, $nextRetryIn)"
  override def getRootCauseErrorTypeName: String = "Secondary Rate Limit Exception"
}
