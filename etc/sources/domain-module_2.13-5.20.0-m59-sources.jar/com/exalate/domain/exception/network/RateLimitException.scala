package com.exalate.domain.exception.network

import com.exalate.api.exception.network.AvailabilityNetworkException

import scala.concurrent.duration.Duration

object RateLimitException {

  def apply(
      message: Option[String],
      cause: Option[Throwable],
      nextRetryIn: Option[Duration],
      rateLimit: Option[Long],
      rateLimitRemaining: Option[Long]
  ): RateLimitException = new RateLimitException(
    message,
    cause,
    nextRetryIn,
    rateLimit,
    rateLimitRemaining
  )

  def unapply(
      arg: RateLimitException
  ): Option[(Option[String], Option[Throwable], Option[Duration], Option[Long], Option[Long])] =
    Some(
      (
        arg.message,
        arg.cause,
        arg.nextRetryIn,
        arg.rateLimit,
        arg.rateLimitRemaining
      )
    )

}

class RateLimitException(
    val message: Option[String],
    val cause: Option[Throwable],
    val nextRetryIn: Option[Duration],
    val rateLimit: Option[Long],
    val rateLimitRemaining: Option[Long]
) extends AvailabilityNetworkException(message.orNull, cause.orNull) {

  override def toString =
    s"RateLimitException($message, $cause, $nextRetryIn, $rateLimit, $rateLimitRemaining)"

  override def getRootCauseErrorTypeName: String = "Rate Limit Exception"
}
