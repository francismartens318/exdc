package com.exalate.domain.exception.filesystem

import com.exalate.api.exception.filesystem.ExalateFileSystemException

case class CouldNotStoreBlobOnRemoteSideExalateFileSystemException(message: String, cause: Throwable)
    extends ExalateFileSystemException(message, cause) {

  def this(message: String) = this(message, null)

  override def getDocsLink: String = ""

  override def getRootCauseErrorTypeName: String = "Attachment sync error"

}

object CouldNotStoreBlobOnRemoteSideExalateFileSystemException {

  def apply(message: String): CouldNotStoreBlobOnRemoteSideExalateFileSystemException =
    new CouldNotStoreBlobOnRemoteSideExalateFileSystemException(message)

}
