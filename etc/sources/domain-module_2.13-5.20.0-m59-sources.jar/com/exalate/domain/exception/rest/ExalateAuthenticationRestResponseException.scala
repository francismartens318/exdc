package com.exalate.domain.exception.rest

case class ExalateAuthenticationRestResponseException(message: String, statusCode: Int)
    extends ExalateRestResponseException(message)
