package com.exalate.domain.exception.rest

class ExalateRestResponseException(message: String = "") extends Exception(message)
