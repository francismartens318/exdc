package com.exalate.domain.exception.rest

case class ExalateErrorValueRestResponseException(causeEntityName: String, message: String)
    extends ExalateRestResponseException(message)
