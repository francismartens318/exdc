package com.exalate.domain.exception.auth

import com.exalate.api.exception.bug.auth.AuthBugException

class JwtAuthBugException(message: String, cause: Throwable, jwt: String)
    extends AuthBugException(message, cause) {

  def this(message: String) = this(message, null, null)

  def this(message: String, jwt: String) = this(message, null, jwt)

  override def getDocsLink: String = ""

  override def getRootCauseErrorTypeName: String = "JWT authentication error"

  def getJwt: String = jwt

}

object JwtAuthBugException {
  def apply(message: String): JwtAuthBugException = new JwtAuthBugException(message)

  def apply(message: String, jwt: String): JwtAuthBugException =
    new JwtAuthBugException(message, jwt)

}
