package com.exalate.domain.exception.trigger

class TriggerQueryExalateException(message: String, e: Throwable)
    extends ExalateTriggerException(message, e) {
  def this(message: String) = this(message, null)
}

object TriggerQueryExalateException {

  def apply(message: String, e: Throwable): TriggerQueryExalateException =
    new TriggerQueryExalateException(message, e)

  def apply(message: String): TriggerQueryExalateException = new TriggerQueryExalateException(
    message
  )

  def unapply(e: TriggerQueryExalateException): Option[(String, Throwable)] = Some(e.message, e.e)
}
