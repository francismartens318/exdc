package com.exalate.domain.exception.trigger

import com.exalate.api.domain.ErrorEntityType
import com.exalate.api.domain.trigger.ITrigger
import com.exalate.api.exception.CategorizedException

case class ExalateTriggerException(trigger: ITrigger, message: String, e: Throwable)
    extends CategorizedException(message, e) {

  def this(trigger: ITrigger, message: String) = this(trigger, message, null)
  def this(message: String, e: Throwable) = this(null, message, e)
  def this(message: String) = this(null, message, null)

  override def getDocsLink: String = "https://docs.exalate.com/docs/triggers-in-exalate"

  override def getRootCauseErrorTypeName: String = "Trigger configuration error"

  override def getErrorEntityType: ErrorEntityType = ErrorEntityType.TRIGGER
}

object ExalateTriggerException {

  def apply(trigger: ITrigger, message: String): ExalateTriggerException =
    new ExalateTriggerException(trigger, message)

  def apply(message: String, e: Throwable): ExalateTriggerException =
    new ExalateTriggerException(message, e)

  def apply(message: String): ExalateTriggerException = new ExalateTriggerException(message)
}
