package com.exalate.domain.processor.dryrun

case class DryRunOutScriptRequest(
    script: String,
    entityUrn: String,
    entityId: Option[String],
    entityType: String,
    fieldValues: Option[Map[String, String]],
    timeoutMillis: Long
)
