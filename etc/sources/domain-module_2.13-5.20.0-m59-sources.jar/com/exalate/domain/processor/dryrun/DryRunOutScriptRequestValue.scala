package com.exalate.domain.processor.dryrun

/** @param script
  *   \- Outgoing sync script to execute
  * @param entityUrn
  *   \- issue key, e.g. "A-1"
  * @param entityId
  *   \- optional issue unique id, e.g. "10001"
  * @param entityType
  *   \- optional type, e.g. "issue" or "sprint"
  * @param fieldValues
  *   \- optional map of modifiers, that help to clarify which object are we talking about, e.g.
  *   Map("repo"->"radix-ai/poetry-cookiecutter")
  * @param timeoutMillis
  *   \- optional timeout in milliseconds, capped to 10 minutes
  */
case class DryRunOutScriptRequestValue(
    script: String,
    entityUrn: String,
    entityId: Option[String],
    entityType: Option[String],
    fieldValues: Option[Map[String, String]],
    timeoutMillis: Option[Long]
)
