package com.exalate.domain.processor.dryrun

import com.exalate.domain.processor.log.LogEvent

trait IDryRunResultValue {
  def apiVersion: String = "5.2"
}

case class SuccessfulDryRunResultValue(
    result: DryRunVariableResult,
    logs: Seq[LogEvent],
    executionTimeMillis: Long
) extends IDryRunResultValue

case class FailedDueTimeoutDryRunResultValue(
    stackTrace: String,
    logs: Seq[LogEvent],
    executionTimeMillis: Long
) extends IDryRunResultValue

case class FailedDueCompilationDryRunResultValue(compilerOutput: String) extends IDryRunResultValue

case class FailedDueExceptionDryRunResultValue(
    exception: ExceptionValue,
    logs: Seq[LogEvent],
    executionTimeMillis: Long
) extends IDryRunResultValue
