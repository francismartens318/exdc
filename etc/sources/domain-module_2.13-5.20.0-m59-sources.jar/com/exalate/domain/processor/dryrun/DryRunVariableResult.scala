package com.exalate.domain.processor.dryrun

import play.api.libs.json.JsObject

case class DryRunVariableResult(replica: JsObject)
