package com.exalate.domain.processor.dryrun

case class ExceptionValue(message: String, stackTrace: String)
