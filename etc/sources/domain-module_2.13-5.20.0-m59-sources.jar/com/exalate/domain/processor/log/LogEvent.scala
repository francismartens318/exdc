package com.exalate.domain.processor.log

import org.slf4j.event.Level

case class LogEvent(level: Level, message: String)
