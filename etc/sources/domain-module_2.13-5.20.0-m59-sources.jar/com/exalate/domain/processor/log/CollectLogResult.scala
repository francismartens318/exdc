package com.exalate.domain.processor.log

case class CollectLogResult[R](logs: Seq[LogEvent], result: R)
