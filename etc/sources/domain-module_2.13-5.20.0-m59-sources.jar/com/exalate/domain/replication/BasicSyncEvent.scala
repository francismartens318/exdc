package com.exalate.domain.replication

import com.exalate.api.domain.SyncRequestEventType
import com.exalate.api.domain.event.ISyncEvent
import com.exalate.api.domain.twintrace.{ITwinTrace, TwinType}
import org.apache.commons.lang3.StringUtils

object BasicSyncEvent {

  def isDeleteEvent(syncEvent: ISyncEvent): Boolean =
    StringUtils.isNotEmpty(syncEvent.getDeletedIssueUrn) ||
      Option(syncEvent.getSyncType).contains(SyncRequestEventType.DELETE)

  /** Checks whether sync event status is CLEANUP
    * @param syncEvent
    * @return
    *   true or false
    */
  def isCleanupEvent(syncEvent: ISyncEvent): Boolean =
    Option(syncEvent.getSyncType).contains(SyncRequestEventType.CLEANUP)

  def isConnectEvent(syncEvent: ISyncEvent): Boolean =
    StringUtils.isNotEmpty(syncEvent.getConnectRemoteIssueUrn) ||
      Option(syncEvent.getSyncType).contains(SyncRequestEventType.CONNECT)

  /** Checks whether sync event for CLEANUP or UNEXALATE
    * @param syncEvent
    * @return
    *   true or false
    */
  def isCleanupOrUnexalateEvent(syncEvent: ISyncEvent): Boolean =
    isCleanupEvent(syncEvent) || isUnexalateEvent(syncEvent)

  /** Checks whether sync event for CLEANUP or UNEXALATE or DELETE
    * @param syncEvent
    * @return
    */
  def isCleanupOrUnexalateOrDeleteEvent(syncEvent: ISyncEvent): Boolean =
    isCleanupOrUnexalateEvent(syncEvent) || isDeleteEvent(syncEvent)

  /** Checks whether sync event status is UNEXALATE
    * @param syncEvent
    * @return
    *   true or false
    */
  def isUnexalateEvent(syncEvent: ISyncEvent): Boolean =
    StringUtils.isNotEmpty(syncEvent.getUnexalateIssueUrn) ||
      Option(syncEvent.getSyncType).contains(SyncRequestEventType.UNEXALATE)

  def isPairResponse(syncEvent: ISyncEvent, twinTrace: ITwinTrace): Boolean = {
    // In a bidirectional scenario, Issue Tracker A sends a pair request to Issue Tracker B. When the request is processed, B will
    // have a TwinTrace with the "lastProcessedRemoteEventNumber" filled in (= 1).
    // When a change on B is made, it will send a sync request with event number 1 to A, but this should not be
    // treated as a pair request anymore, but as a regular sync request.
    val isTreatedAsUpdateResponse = twinTrace.getLastProcessedRemoteEventNumber >= 1L
    !isTreatedAsUpdateResponse && syncEvent.getEventNumber == 1L
  }

  /** Checks whether event is pair or connect
    * @param event
    * @return
    *   true or false
    */
  def isPairOrConnectEvent(event: ISyncEvent, twinTrace: Option[ITwinTrace]): Boolean =
    twinTrace.exists(_.getType == TwinType.PARENT && event.getEventNumber == 1L)

  /** Checks whether its update event
    * @param event
    * @return
    */
  def isUpdateEvent(event: ISyncEvent, twinTrace: Option[ITwinTrace]): Boolean =
    !isCleanupOrUnexalateOrDeleteEvent(event) && !isPairOrConnectEvent(event, twinTrace)

}
