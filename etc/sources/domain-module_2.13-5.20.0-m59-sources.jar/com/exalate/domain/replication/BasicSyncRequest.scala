package com.exalate.domain.replication

import com.exalate.api.domain._
import com.exalate.api.domain.license.ISubscriptionContext
import com.exalate.api.domain.request.{ISyncRequest, RequestStatus}
import org.apache.commons.lang3.StringUtils

final case class BasicSyncRequest(
    id: Int,
    remoteSyncEventId: Int,
    remoteSyncEventNumber: Long,
    remoteTwinTraceId: Option[Int],
    connectIssueUrn: Option[String],
    deletedRemoteIssueUrn: Option[String],
    unexalateRemoteIssueUrn: Option[String],
    connectContext: Option[IPersistentConnectContext],
    errorResponseMessage: Option[String],
    errorReason: Option[ErrorReason],
    replica: IPersistentReplica,
    updatedReplica: Option[IPersistentReplica],
    connectionId: Int,
    createdIssueKey: Option[IIssueKey],
    syncedTo: Option[IIssueKey],
    status: RequestStatus,
    isPayed: Boolean,
    subscriptionContext: ISubscriptionContext,
    syncType: SyncRequestEventType
)

object BasicSyncRequest {

  def apply(
      syncRequest: ISyncRequest,
      newStatusOpt: Option[RequestStatus] = None,
      updatedReplicaOpt: Option[IPersistentReplica] = None
  ): BasicSyncRequest =
    BasicSyncRequest(
      id = syncRequest.getId,
      remoteSyncEventId = syncRequest.getRemoteSyncEventId,
      remoteSyncEventNumber = syncRequest.getRemoteSyncEventNumber,
      remoteTwinTraceId = Option(syncRequest.getRemoteTwinTraceId),
      connectIssueUrn = Option(syncRequest.getConnectIssueUrn),
      deletedRemoteIssueUrn = Option(syncRequest.getDeletedRemoteIssueUrn),
      unexalateRemoteIssueUrn = Option(syncRequest.getUnexalateRemoteIssueUrn),
      connectContext = Option(syncRequest.getConnectContext),
      errorResponseMessage = Option(syncRequest.getErrorResponseMessage),
      errorReason = Option(syncRequest.getErrorReason),
      replica = syncRequest.getReplica,
      updatedReplica =
        if (updatedReplicaOpt.isDefined) updatedReplicaOpt
        else Option(syncRequest.getUpdatedReplica),
      connectionId = syncRequest.getConnection.getID,
      createdIssueKey = Option(syncRequest.getCreatedIssueKey),
      syncedTo = Option(syncRequest.getSyncedTo),
      status = newStatusOpt.getOrElse(syncRequest.getStatus),
      isPayed = syncRequest.isPayed,
      subscriptionContext = syncRequest.getSubscriptionContext,
      syncType = syncRequest.getSyncType
    )

  def isConnectRequest(syncRequest: ISyncRequest): Boolean =
    Option(syncRequest.getConnectIssueUrn).exists(_ != "") ||
      Option(syncRequest.getSyncType).contains(SyncRequestEventType.CONNECT)

  def isConnectRequest(basicSyncRequest: BasicSyncRequest): Boolean =
    basicSyncRequest.connectIssueUrn.exists(
      _ != ""
    ) || basicSyncRequest.syncType == SyncRequestEventType.CONNECT

  def isCleanupRequest(syncRequest: ISyncRequest): Boolean =
    Option(syncRequest.getSyncType).contains(SyncRequestEventType.CLEANUP)

  def isCleanupRequest(basicRequest: BasicSyncRequest): Boolean =
    Option(basicRequest.syncType).contains(SyncRequestEventType.CLEANUP)

  def isCleanupOrUnexalateRequest(syncRequest: ISyncRequest): Boolean =
    isCleanupRequest(syncRequest) || isUnexalateRequest(syncRequest)

  def isCleanupOrUnexalateRequest(basicSyncRequest: BasicSyncRequest): Boolean =
    isCleanupRequest(basicSyncRequest) || isUnexalateRequest(basicSyncRequest)

  def isCleanupOrUnexalateOrDeleteRequest(syncRequest: ISyncRequest): Boolean =
    isCleanupOrUnexalateRequest(syncRequest) || isDeleteRequest(syncRequest)

  def isCleanupOrUnexalateOrDeleteRequest(basicSyncRequest: BasicSyncRequest): Boolean =
    isCleanupOrUnexalateRequest(basicSyncRequest) || isDeleteRequest(basicSyncRequest)

  def isDeleteRequest(syncRequest: ISyncRequest): Boolean =
    Option(syncRequest.getDeletedRemoteIssueUrn).exists(StringUtils.isNotEmpty) ||
      Option(syncRequest.getSyncType).contains(SyncRequestEventType.DELETE)

  def isDeleteRequest(basicSyncRequest: BasicSyncRequest): Boolean =
    basicSyncRequest.deletedRemoteIssueUrn.exists(StringUtils.isNotEmpty) ||
      Option(basicSyncRequest.syncType).contains(SyncRequestEventType.DELETE)

  private def isUnexalateRequest(syncRequest: ISyncRequest): Boolean =
    Option(syncRequest.getUnexalateRemoteIssueUrn).exists(StringUtils.isNotEmpty) ||
      Option(syncRequest.getSyncType).contains(SyncRequestEventType.UNEXALATE)

  private def isUnexalateRequest(basicSyncRequest: BasicSyncRequest): Boolean =
    basicSyncRequest.unexalateRemoteIssueUrn.exists(StringUtils.isNotEmpty) ||
      Option(basicSyncRequest.syncType).contains(SyncRequestEventType.UNEXALATE)

  def isUpdateRequest(syncRequest: ISyncRequest): Boolean =
    Option(syncRequest.getSyncType).contains(SyncRequestEventType.UPDATE)

  def isUpdateRequest(basicSyncRequest: BasicSyncRequest): Boolean =
    basicSyncRequest.syncType == SyncRequestEventType.UPDATE

}
