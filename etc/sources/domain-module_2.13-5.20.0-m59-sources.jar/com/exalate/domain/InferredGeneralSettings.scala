package com.exalate.domain

trait InferredGeneralSettings {
  def getExalateUrl: Option[String]
  def getIssueTrackerUrl: String
  def getInstanceUid: Option[String]
  def getAuthRequired: Boolean

  /** This field will allow node implementors to store any key-value information they need for their
    * exalate node configuration
    */
  def fieldValues: Map[String, String]
}
