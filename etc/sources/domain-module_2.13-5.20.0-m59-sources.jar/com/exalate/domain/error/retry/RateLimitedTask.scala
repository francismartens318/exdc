package com.exalate.domain.error.retry

import java.util.Date

import scala.concurrent.duration.Duration
import scala.concurrent.{Future, Promise}

case class RateLimitedTask[R](
    nextRetry: Date,
    prevBackoff: Duration,
    fn: () => Future[R],
    taskPromise: Promise[R],
    isSecondary: Boolean = false
)
