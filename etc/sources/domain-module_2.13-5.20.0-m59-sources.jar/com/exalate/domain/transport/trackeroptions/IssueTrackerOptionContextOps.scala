package com.exalate.domain.transport.trackeroptions

object IssueTrackerOptionContextOps {

  /** The method merges 2 Issue Tracker Option Context into one
    * @param leftCtx
    * @param rightCtx
    * @return
    */
  def mergeContexts(
      leftCtx: Option[IssueTrackerOptionContext],
      rightCtx: Option[IssueTrackerOptionContext]
  ): Option[IssueTrackerOptionContext] = {
    val mergedCtx = (leftCtx, rightCtx) match {
      case (None, None)                              => None
      case (Some(existingContext), None)             => Some(existingContext)
      case (None, Some(newContext))                  => Some(newContext)
      case (Some(existingContext), Some(newContext)) =>
        val existingDepSet = existingContext.dependsOnEither
        val newDepSet = newContext.dependsOnEither
        val comboSet = existingDepSet ++ newDepSet
        Some(existingContext.copy(comboSet))
    }
    mergedCtx
  }

  /** The method remove duplicates from the seq of IssueTrackerOption
    * @param optionsWithDuplicates
    * @return
    */
  def mergeContexts(optionsWithDuplicates: Seq[IssueTrackerOption]): Seq[IssueTrackerOption] =
    optionsWithDuplicates
      .groupBy(o => o.value)
      .foldLeft(Seq.empty[IssueTrackerOption]) {
        case (result, (_, sameOptions)) =>
          result ++ sameOptions.foldLeft(Option.empty[IssueTrackerOption]) {
            case (None, o)               => Some(o)
            case (Some(resultOption), o) =>
              val leftCtx = resultOption.context
              val rightCtx = o.context
              val mergedCtx: Option[IssueTrackerOptionContext] =
                IssueTrackerOptionContextOps.mergeContexts(leftCtx, rightCtx)
              Some(resultOption.copy(context = mergedCtx))
          }
      }

  /** from all the options from that issue tracker for that field, find only the ones (for which all
    * of the following works out): 1) their context is fully satisfied with the query: for all
    * context dependencies of the checked issue tracker option, there is either 1.1) a matching
    * dependency passed from query 1.2) no dependency passed from query 2) the option's text matches
    * the query After that options with the "best match" (i.e. biggest number of matched
    * dependencies) are filtered
    */
  def filterOptions(
      opts: Seq[IssueTrackerOption],
      queryOpt: Option[String],
      queryDependencies: Option[Iterable[IssueTrackerOptionDependency]]
  ): Seq[IssueTrackerOption] = {
    if (opts.isEmpty) return opts
    case class OptMatch(option: IssueTrackerOption, isMatch: Boolean, matchedFields: Set[String])
    val options = queryDependencies match {
      case None           => opts
      case Some(queryCtx) =>
        opts.map { actualOption =>
          actualOption.context match {
            case None            => OptMatch(actualOption, true, Set())
            case Some(actualCtx) =>
              val result = actualCtx.dependsOnEither match {
                case empty if empty.isEmpty =>
                  OptMatch(actualOption, true, Set()) // the option has no dependencies - perfect!
                case actualDeps             =>
                  actualDeps
                    .map { // at least one combination is satisfied
                      case IssueTrackerOptionDependencyCombo(actualDepVs) =>
                        actualDepVs.foldLeft(OptMatch(actualOption, true, Set())) {
                          case (optionMatch, IssueTrackerOptionDependency(_, None)) => optionMatch
                          case (optionMatch, IssueTrackerOptionDependency(f, Some(actualDepV))) =>
                            val noContextFieldProvidedByQuery =
                              queryCtx.forall(_.field != f) // no such field passed from query
                            val contextFieldProvidedByQueryMatches = queryCtx.filter(qDep =>
                              qDep.field == f && qDep.value.contains(actualDepV)
                            )
                            OptMatch(
                              actualOption,
                              optionMatch.isMatch && (noContextFieldProvidedByQuery || contextFieldProvidedByQueryMatches.nonEmpty),
                              optionMatch.matchedFields ++ contextFieldProvidedByQueryMatches.map(
                                _.value.get
                              )
                            )
                        }
                    }
                    .filter(_.isMatch)
                    .foldLeft(OptMatch(actualOption, false, Set()))((m1, m2) =>
                      OptMatch(actualOption, true, m1.matchedFields ++ m2.matchedFields)
                    )
              }
              result
          }
        } match {
          case Nil        => Nil
          case optMatches =>
            val bestMatch = optMatches.map(_.matchedFields.size).max
            optMatches.filter(m => m.isMatch && m.matchedFields.size == bestMatch).map(_.option)
        }

    }
    (queryOpt match {
      case Some(query) =>
        options
          .filter(_.label.toLowerCase.contains(query.toLowerCase))
      case None        => options
    })
      .groupBy(_.label)
      .flatMap(_._2.headOption.toSeq)
      .toSeq
  }

}
