package com.exalate.domain.transport.trackeroptions

object ScopeQueryOperators extends Enumeration {
  type ScopeQueryOperators = Value
  val IS: ScopeQueryOperators = Value("IS")
  val IS_NOT: ScopeQueryOperators = Value("ISNOT")
  val CONTAINS: ScopeQueryOperators = Value("CONTAINS")
  val DOES_NOT_CONTAIN: ScopeQueryOperators = Value("DOESNOTCONTAIN")
  val IN: ScopeQueryOperators = Value("IN")
  val NOT_IN: ScopeQueryOperators = Value("NOTIN")

  def withNameOpt(s: String): Option[Value] =
    values.find(_.toString == s)

  def getReadableLabelByKey(key: String): String =
    withNameOpt(key)
      .map {
        case IS               => "is"
        case IS_NOT           => "is_not"
        case CONTAINS         => "contains"
        case DOES_NOT_CONTAIN => "does_not_contain"
        case IN               => "in"
        case NOT_IN           => "not_in"
      }
      .getOrElse(???)

}
