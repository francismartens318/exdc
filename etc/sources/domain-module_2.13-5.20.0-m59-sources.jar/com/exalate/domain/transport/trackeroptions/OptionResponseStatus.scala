package com.exalate.domain.transport.trackeroptions

object OptionResponseStatus extends Enumeration {
  type OptionResponseStatus = Value
  val SUCCESS, FAIL = Value
}
