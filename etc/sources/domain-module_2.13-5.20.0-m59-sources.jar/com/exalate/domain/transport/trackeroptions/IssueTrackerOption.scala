package com.exalate.domain.transport.trackeroptions

import java.sql.Timestamp

import play.api.libs.json._

/** @param id
  *   \- exalate-assigned id or none, if not persisted yet
  */
case class IssueTrackerOption(
    id: Option[Int],
    validOn: Timestamp,
    label: String,
    value: String,
    instanceUid: String,
    field: String,
    context: Option[IssueTrackerOptionContext] = None
)

case class IssueTrackerOptionSimplified(label: String, value: String)

object IssueTrackerOptionSimplified {
  implicit val format: OFormat[IssueTrackerOptionSimplified] = Json.format
}

case class IssueTrackerOptionValue(
    validOn: Long,
    label: String,
    value: String,
    field: String,
    context: Option[IssueTrackerOptionContext] = None
)

object IssueTrackerOptionValue {
  implicit val format: OFormat[IssueTrackerOptionValue] = Json.format
}

case class OptionRequestContentValue(accessToken: String, field: String)

object OptionRequestContentValue {
  implicit val format: OFormat[OptionRequestContentValue] = Json.format
}

case class OptionResponseContentValue(
    accessToken: Option[String],
    status: String,
    field: String,
    options: Option[Seq[IssueTrackerOptionValue]]
)

object OptionResponseContentValue {
  implicit val format: OFormat[OptionResponseContentValue] = Json.format
}

case class IssueTrackerOptionsForAutocomplete(
    query: Option[String],
    total: Int,
    offset: Option[Int],
    limit: Option[Int],
    results: Seq[IssueTrackerOptionValue]
)

object IssueTrackerOptionsForAutocomplete {
  implicit val format: OFormat[IssueTrackerOptionsForAutocomplete] = Json.format
}

case class IssueTrackerOptionDependency(field: String, value: Option[String])

object IssueTrackerOptionDependency {
  implicit val format: OFormat[IssueTrackerOptionDependency] = Json.format
}

case class IssueTrackerOptionDependencyCombo(combination: Set[IssueTrackerOptionDependency])

object IssueTrackerOptionDependencyCombo {

  implicit val format: OFormat[IssueTrackerOptionDependencyCombo] = Json.format

}

/** { "dependsOnEither":[ {"combination":[ {"field":"PROJECT", "value":"100000"},
  * {"field":"ISSUE_TYPE", "value":"100"} ]} ]}
  */
case class IssueTrackerOptionContext(dependsOnEither: Set[IssueTrackerOptionDependencyCombo])

object IssueTrackerOptionContext {
  implicit val format: OFormat[IssueTrackerOptionContext] = Json.format
}
