package com.exalate.domain.transport.trackeroptions

import java.sql.Timestamp

object EditorOptionsValueHelper {

  def toIssueTrackerOptionValue(trackerOption: IssueTrackerOption): IssueTrackerOptionValue =
    IssueTrackerOptionValue(
      trackerOption.validOn.getTime,
      trackerOption.label,
      trackerOption.value,
      trackerOption.field,
      trackerOption.context
    )

  def toIssueTrackerOption(
      trackerOptionValue: IssueTrackerOptionValue,
      instanceUid: String
  ): IssueTrackerOption =
    IssueTrackerOption(
      None,
      new Timestamp(trackerOptionValue.validOn),
      trackerOptionValue.label,
      trackerOptionValue.value,
      instanceUid,
      trackerOptionValue.field,
      trackerOptionValue.context
    )

}
