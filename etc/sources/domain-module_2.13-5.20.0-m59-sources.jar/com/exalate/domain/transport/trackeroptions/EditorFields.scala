package com.exalate.domain.transport.trackeroptions

object EditorFields extends Enumeration {
  type EditorFields = Value
  val PROJECT = Value
  val ISSUE_TYPE = Value
  val SUMMARY = Value
  val PRIORITY = Value
  val STATUS = Value
  val DESCRIPTION = Value
  val LABELS = Value
  val COMMENTS = Value
  val ATTACHMENTS = Value
  val ASSIGNEE = Value
  val REPORTER = Value
  val DUE = Value
  val AREA_PATH = Value
  val ITERATION_PATH = Value

  /** deprecated since it is issue tracker specific, so you must use IInstanceEditorFieldService
    * instead
    */
  @deprecated("use IInstanceEditorFieldService instead")
  def getReadableLabelByKey(key: String): String =
    withNameOpt(key)
      .map {
        case PROJECT        => "Project"
        case ISSUE_TYPE     => "Issue type"
        case SUMMARY        => "Summary"
        case PRIORITY       => "Priority"
        case STATUS         => "Status"
        case DESCRIPTION    => "Description"
        case LABELS         => "Labels"
        case COMMENTS       => "Comments"
        case ATTACHMENTS    => "Attachments"
        case DUE            => "Due"
        case AREA_PATH      => "Area"
        case ITERATION_PATH => "Iteration"

      }
      .getOrElse(???)

  def withNameOpt(s: String): Option[Value] =
    values.find(_.toString == s)

}

object RecoveryKey extends Enumeration {
  type RecoveryKey = Value
  val DEFAULT = Value
  val ERROR = Value
  val NONE = Value
}
