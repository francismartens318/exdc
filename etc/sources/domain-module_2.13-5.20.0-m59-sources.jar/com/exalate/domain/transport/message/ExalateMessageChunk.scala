package com.exalate.domain.transport.message

import com.exalate.domain.transport.message.ChunkStatus.ChunkStatus

case class ExalateMessageChunk(
    id: Option[Int],
    messageId: Int,
    batchUUID: String,
    content: String,
    connectionId: Int,
    startIndexInMessage: Int,
    totalChunksInMessage: Int,
    status: String,
    messageType: String
)
