package com.exalate.domain.transport.message

object MessageStatus extends Enumeration {
  type MessageStatus = Value
  val BATCHING, READY = Value
}

object ChunkStatus extends Enumeration {
  type ChunkStatus = Value
  val BATCHING, SENDING, UNBATCHING = Value
}

object MessageDirection extends Enumeration {
  type MessageDirection = Value
  val IN, OUT = Value
}

object MessageType extends Enumeration {
  type MessageType = Value

  val SYNC_REQUEST, PROJECT_REQUEST, CONNECTION_DRAFT_REQUEST, CONNECTION_DRAFT_RESPONSE,
      OPTION_REQUEST, OPTION_RESPONSE, OPTION_RESPONSE_NUMBER, CUSTOM_FIELD_RESPONSE,
      CUSTOM_FIELD_RESPONSE_NUMBER = Value

  def fromString(str: String): Option[Value] =
    values.find(_.toString == str)

}
