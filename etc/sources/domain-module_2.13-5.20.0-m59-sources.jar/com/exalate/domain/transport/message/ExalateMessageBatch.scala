package com.exalate.domain.transport.message

case class ExalateMessageBatch(uuid: String, chunks: Seq[ExalateMessageChunk])
