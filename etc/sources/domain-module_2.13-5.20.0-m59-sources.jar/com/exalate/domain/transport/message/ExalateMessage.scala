package com.exalate.domain.transport.message

case class ExalateMessage(
    content: String,
    messageType: String,
    connectionId: Int,
    id: Option[Int] = None,
    direction: String = MessageDirection.OUT.toString,
    status: String = MessageStatus.BATCHING.toString
)
