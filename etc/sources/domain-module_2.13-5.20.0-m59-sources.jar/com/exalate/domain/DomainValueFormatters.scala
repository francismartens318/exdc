package com.exalate.domain

import com.exalate.domain.editor.FieldDataType
import com.exalate.domain.editor.FieldDataType.FieldDataType
import com.exalate.domain.node.storeblob.CloudObjectMetaDataValue
import com.exalate.domain.values._
import play.api.libs.json._
import play.api.libs.functional.syntax._

object DomainValueFormatters {

  implicit val cloudObjectMetaDataValueFormat: OFormat[CloudObjectMetaDataValue] =
    Json.format[CloudObjectMetaDataValue]

  implicit val fieldDataTypeFormat: Format[FieldDataType] = Format(
    Reads {
      case JsString(str) =>
        FieldDataType.withNameOpt(str) match {
          case None     => JsError(s"Unknown field type `$str`")
          case Some(ft) => JsSuccess(ft)
        }
      case JsNull        => JsSuccess(null)
      case x             =>
        JsError(
          s"Unrecognized JSON type passed for field type: `$x`, while expected either String or null"
        )
    },
    Writes {
      case null => JsNull
      case v    => JsString(v.toString)
    }
  )

  implicit val editorFeatureValueFormat: OFormat[FeatureValue] = Json.format[FeatureValue]

  implicit val optSeqeditorFeatureValueFormat: Format[Option[Seq[FeatureValue]]] =
    Format(Reads.optionNoError[Seq[FeatureValue]], Writes.optionWithNull[Seq[FeatureValue]])

  implicit val editorfieldTypeValueFormat: OFormat[com.exalate.domain.values.FieldTypeValue] =
    Json.format[com.exalate.domain.values.FieldTypeValue]

  implicit val seqEditorfieldTypeValueFormat: Format[
    Seq[com.exalate.domain.values.FieldTypeValue]
  ] = Format(
    Reads.traversableReads[Seq, com.exalate.domain.values.FieldTypeValue],
    Writes.seq[com.exalate.domain.values.FieldTypeValue]
  )

  implicit val editorFieldTypeValueSequenceFormat: Format[Seq[EditorFieldTypeValue]] =
    Format(Reads.traversableReads[Seq, EditorFieldTypeValue], Writes.seq[EditorFieldTypeValue])

  implicit val editorCustomFieldResponseValue: Format[EditorCustomFieldResponseValue] =
    Json.format[EditorCustomFieldResponseValue]

  implicit val editorContextStatsValue: OFormat[EditorContextStatsValue] =
    Json.format[EditorContextStatsValue]

}
