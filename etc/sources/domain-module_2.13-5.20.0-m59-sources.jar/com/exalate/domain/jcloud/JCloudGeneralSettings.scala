package com.exalate.domain.jcloud

import com.exalate.domain.InferredGeneralSettings

case class JCloudGeneralSettings(
    id: Option[Int],
    exalateUrl: Option[String],
    issueTrackerUrl: String,
    sharedSecret: Option[String],
    oauthClientId: Option[String],
    clientKey: Option[String],
    publicKey: Option[String],
    showExalateConnect: Boolean,
    showUnexalate: Boolean,
    showSyncPanelForAdmin: Boolean,
    showDisabledConnections: Boolean,
    credentialsRequired: Boolean,
    allowProjectLevelConsole: Boolean,
    instanceUid: Option[String] = None
) extends InferredGeneralSettings {
  override def getExalateUrl: Option[String] = exalateUrl

  override def getIssueTrackerUrl: String = issueTrackerUrl

  override def getAuthRequired = credentialsRequired

  override def fieldValues: Map[String, String] = Map.empty

  override def getInstanceUid: Option[String] = instanceUid
}
