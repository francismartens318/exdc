package com.exalate

import java.time.LocalDate

package object domain {

  case class CustomerRegistrationDate(value: LocalDate) extends AnyVal

  case class InstanceUId(value: String) extends AnyVal

  case class RemoteInstanceUId(value: String) extends AnyVal

}
