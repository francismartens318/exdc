package com.exalate.domain

import com.exalate.util.json.gson.GsonCaseClassValueJsonService
import play.api.libs.json._

/** Formatter for json converting process
  */
object ObjectJsonFormatters {

  implicit lazy val objFormat: Format[Object] = Format(
    Reads { json =>
      val vTry = GsonCaseClassValueJsonService.read[Object](json.toString(), classOf[Object])
      val vOrNull = vTry.toOption.orNull
      JsSuccess(vOrNull)
    },
    Writes { obj =>
      Json.parse(
        GsonCaseClassValueJsonService
          .write(obj)
          .toOption
          .getOrElse(JsNull.toString())
      )
    }
  )

  implicit lazy val objOptFormat: Format[Option[Object]] = Format.optionWithNull[Object](objFormat)

  implicit lazy val objSeqFormat: Format[Seq[Object]] =
    Format(Reads.seq[Object](objFormat), Writes.seq[Object](objFormat))

  implicit lazy val objMapFormat: Format[scala.collection.immutable.Map[String, Object]] =
    Format(Reads.mapReads[Object](objFormat), Writes.genericMapWrites(objFormat))

  implicit lazy val optMap: Format[Option[Map[String, Object]]] =
    Format.optionWithNull[Map[String, Object]](objMapFormat)

}
