package com.exalate.domain.node.storeblob

case class CloudObjectMetaDataValue(
    key: String,
    bucket: String,
    region: String,
    storageBaseUrl: String,
    md5: String,
    contentLength: Long,
    storageType: Option[String] = None
)
