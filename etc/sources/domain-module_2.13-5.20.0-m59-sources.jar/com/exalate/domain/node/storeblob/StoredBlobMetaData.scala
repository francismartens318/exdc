package com.exalate.domain.node.storeblob

import com.exalate.api.domain.IBlobMetadata
import com.exalate.domain.DomainValueFormatters.cloudObjectMetaDataValueFormat
import org.slf4j.LoggerFactory
import play.api.libs.json.{JsError, JsSuccess, Json}

import scala.util.{Failure, Success, Try}

object StoredBlob {

  def generateOutgoingBlobName(syncEventId: Int, blobId: String): String =
    s"event-$syncEventId-blob-$blobId"

  def generateIncomingBlobName(connectionId: Int, remoteBlobEventId: Int): String =
    s"${connectionId}_sync_$remoteBlobEventId"

}

sealed trait StoredBlobMetaData {
  def filePath: String
}

object StoredBlobMetaData {
  private val LOG = LoggerFactory.getLogger(classOf[StoredBlobMetaData])

  def get(blobMetaData: IBlobMetadata): Option[StoredBlobMetaData] =
    get(blobMetaData.getBlobFilePath)

  def get(storedIn: String): Option[StoredBlobMetaData] =
    if (storedIn == null) {
      LOG.debug(
        s"filePath `$storedIn` is null => there's no file stored!"
      )
      None
    } else {
      Try(Json.parse(storedIn)) match {
        case Failure(_)    =>
          LOG.debug(
            s"filePath `$storedIn` is not JSON => it's a file system path!"
          )
          Some(FileSystemStoredBlobMetaData(storedIn))
        case Success(json) =>
          LOG.debug(
            s"filePath `$storedIn` is JSON, trying to format it into cloud stored blob meta data now"
          )
          json.validate[CloudObjectMetaDataValue] match {
            case JsError(errors)                        =>
              LOG.debug(
                s"filePath `$storedIn` is not a cloud stored blob meta data JSON: ${errors
                    .map { case (path, error) => s"$path: `${error.mkString("`,`")}``" }
                    .mkString("; ")}. Suggesting, that there's no such blob anymore"
              )
              None
            case JsSuccess(cloudObjectMetaDataValue, _) =>
              LOG.debug(
                s"filePath `$storedIn` is a cloud stored blob meta data JSON!"
              )
              Some(CloudStoredBlobMetaData(cloudObjectMetaDataValue.key, cloudObjectMetaDataValue))
          }
      }
    }

}

case class CloudStoredBlobMetaData(objectKey: String, objectJsonValue: CloudObjectMetaDataValue)
    extends StoredBlobMetaData {

  override val filePath: String = Json
    .toJson(objectJsonValue)
    .toString()

}

case class FileSystemStoredBlobMetaData(override val filePath: String) extends StoredBlobMetaData
