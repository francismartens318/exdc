package com.exalate.domain.http

object HttpMethod extends Enumeration {
  type HttpMethod = Value

  val GET: HttpMethod = Value
  val POST: HttpMethod = Value
  val PUT: HttpMethod = Value
  val DELETE: HttpMethod = Value
  val PATCH: HttpMethod = Value

  def withNameOpt(s: String): Option[Value] =
    values.find(_.toString == s)

}
