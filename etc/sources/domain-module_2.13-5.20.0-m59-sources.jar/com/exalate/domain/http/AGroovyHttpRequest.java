package com.exalate.domain.http;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public abstract class AGroovyHttpRequest {

    public final String method;
    public final String url;
    public final Map<String, List<String>> queryParameters;
    public final Map<String, List<String>> headers;

    public AGroovyHttpRequest(@Nonnull String method,
                              @Nonnull String url,
                              @Nonnull Map<String, List<String>> queryParameters,
                              @Nonnull Map<String, List<String>> headers) {
        this.method = method;
        this.url = url;
        this.queryParameters = queryParameters;
        this.headers = headers;
    }
    @Override
    public String toString() {
        return "AGroovyHttpRequest{" +
                "method='" + method + '\'' +
                ", url='" + url + '\'' +
                ", queryParameters=" + queryParameters +
                ", headers=" + headers +
                '}';
    }
}
