package com.exalate.domain.http;

import javax.annotation.Nullable;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public abstract class AGroovyHttpResponse {
    public final int code;
    public final Map<String, List<String>> headers;

    public AGroovyHttpResponse(int code, @Nullable Map<String, List<String>> headers) {
        this.code = code;
        if (headers == null) {
            this.headers = Collections.emptyMap();
        } else {
            this.headers = headers;
        }
    }

    public int getCode() {
        return code;
    }

    public Map<String, List<String>> getHeaders() {
        return headers;
    }
}
