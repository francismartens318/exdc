package com.exalate.domain.http;

import akka.stream.scaladsl.Source;
import akka.util.ByteString;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.List;
import java.util.Map;

public class StreamingGroovyHttpResponse extends AGroovyHttpResponse {

    public final Source<ByteString, ?> source;

    public StreamingGroovyHttpResponse(int code, @Nullable Map<String, List<String>> headers, @Nonnull Source<ByteString, ?> source) {
        super(code, headers);
        this.source = source;
    }
}
