package com.exalate.domain.http

case class HttpResponse(headers: Map[String, Seq[String]], body: String, status: Int)
