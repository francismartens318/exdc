package com.exalate.domain.http

case class HttpRequest(
    headers: Map[String, Seq[String]],
    url: String,
    body: Option[String],
    method: HttpMethod.HttpMethod,
    actionPerformed: String
)
