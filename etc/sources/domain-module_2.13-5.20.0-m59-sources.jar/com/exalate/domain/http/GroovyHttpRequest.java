package com.exalate.domain.http;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public final class GroovyHttpRequest extends AGroovyHttpRequest {

    public final String body;

    public GroovyHttpRequest(@Nonnull String method,
                             @Nonnull String url,
                             @Nullable String body,
                             @Nonnull Map<String, List<String>> queryParameters,
                             @Nonnull Map<String, List<String>> headers) {
        super(
                method,
                url,
                queryParameters,
                headers
        );
        this.body = body;
    }
    public GroovyHttpRequest(@Nonnull String url) {
        this(
                "GET",
                url,
                null,
                Collections.emptyMap(),
                Collections.emptyMap()
        );
    }
    @Override
    public String toString() {
        return "GroovyHttpRequest{" +
                "method='" + method + '\'' +
                ", url='" + url + '\'' +
                ", body='" + body + '\'' +
                ", queryParameters=" + queryParameters +
                ", headers=" + headers +
                '}';
    }
}
