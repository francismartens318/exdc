package com.exalate.domain.http;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

public final class GroovyHttpResponse extends AGroovyHttpResponse {
    private final Supplier<String> getBodyStrFn;
    private final Supplier<Object> getBodyObjFn;

    public GroovyHttpResponse(int code, @Nullable Map<String, List<String>> headers, @Nonnull Supplier<String> getBodyStrFn, @Nonnull Supplier<Object> getBodyObjFn) {
        super(
                code,
                headers
        );
        this.getBodyStrFn = getBodyStrFn;
        this.getBodyObjFn = getBodyObjFn;
    }

    public int getCode() {
        return code;
    }

    public String getBodyString() {
        return getBodyStrFn.get();
    }

    public Object getBody() {
        return getBodyObjFn.get();
    }

    public Map<String, List<String>> getHeaders() {
        return headers;
    }
}
