package com.exalate.domain.http;

import akka.stream.scaladsl.Source;
import akka.util.ByteString;
import com.exalate.domain.http.AGroovyHttpRequest;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.List;
import java.util.Map;

public class MultiPartUploadGroovyHttpRequest extends AGroovyHttpRequest {

    public final List<IFormPart> formParts;

    public MultiPartUploadGroovyHttpRequest(@Nullable String method,
                                            @Nonnull String url,
                                            @Nonnull List<IFormPart> formParts,
                                            @Nonnull Map<String, List<String>> queryParameters,
                                            @Nonnull Map<String, List<String>> headers) {
        super(
                defaultMethod(method),
                url,
                queryParameters,
                headers
        );
        this.formParts = formParts;
    }
    @Override
    public String toString() {
        return "MultiPartUploadGroovyHttpRequest{" +
                "method='" + method + '\'' +
                ", url='" + url + '\'' +
                ", formParts='" + formParts + '\'' +
                ", queryParameters=" + queryParameters +
                ", headers=" + headers +
                '}';
    }

    @Nonnull
    private static String defaultMethod(@Nullable String method) {
        if (method == null)  return "POST";
        else return method;
    }

    public static interface IFormPart {
        public String getKey();
    }

    public static class DataPart implements IFormPart {
        public final String key;
        public final String value;

        public DataPart(String key, String value) {
            this.key = key;
            this.value = value;
        }

        @Override
        public String getKey() {
            return key;
        }
    }

    public static class SourceFilePart implements IFormPart {
        public final String key;
        public final String filename;
        public final String contentType;
        public final Source<ByteString, ?> ref;
        public final long fileSize;
        public final String dispositionType;

        public SourceFilePart(
                @Nonnull String key,
                @Nonnull String filename,
                @Nullable String contentType,
                @Nonnull Source<ByteString, ?> ref,
                @Nullable Long fileSize,
                @Nullable String dispositionType) {
            this.key = key;
            this.filename = filename;
            this.contentType = contentType;
            this.ref = ref;

            if(fileSize == null) this.fileSize = -1;
            else this.fileSize = fileSize;

            if (dispositionType == null) this.dispositionType = "form-data";
            else this.dispositionType = dispositionType;
        }

        @Override
        public String toString() {
            return "SourceFilePart{" +
                    "key='" + key + '\'' +
                    ", filename='" + filename + '\'' +
                    ", contentType='" + contentType + '\'' +
                    ", fileSize=" + fileSize +
                    ", dispositionType='" + dispositionType + '\'' +
                    '}';
        }

        @Override
        public String getKey() {
            return key;
        }
    }
}

