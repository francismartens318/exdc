package com.exalate.domain.editor

object EditorContextProgress extends Enumeration {
  type EditorContextProgress = Value

  val LOADING: EditorContextProgress = Value
  val COMPLETED: EditorContextProgress = Value

  def withNameOpt(s: String): Option[Value] =
    values.find(_.toString == s)

}
