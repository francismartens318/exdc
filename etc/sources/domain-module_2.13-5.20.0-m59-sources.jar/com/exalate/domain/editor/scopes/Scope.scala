package com.exalate.domain.editor.scopes

import java.util.UUID
import com.exalate.api.domain.editor.scopes.{SyncCriteria, TriggerCriteria}
import com.exalate.domain.editor.error.EditorErrorValue
import com.exalate.domain.ObjectJsonFormatters.objFormat
import play.api.libs.json.Json.WithDefaultValues
import play.api.libs.json._

case class Scope(local: SingleSideScope, remote: SingleSideScope) {

  def toScopeValue: ScopeValue =
    ScopeValue(local.toSingleSideScopeValue, remote.toSingleSideScopeValue)

  def prettyPrintStr: String = {
    val s = this
    val localScopeStr = s.local.mainFields
      .map(f => s"${f.key}:${f.value.toString}")
      .mkString(",")
    val remoteScopeStr = s.remote.mainFields
      .map(f => s"${f.key}:${f.value.toString}")
      .mkString(",")
    val lArrowStr = if (s.remote.syncCriteria != SyncCriteria.NONE) "<" else ""
    val rArrowStr = if (s.local.syncCriteria != SyncCriteria.NONE) ">" else ""
    s"$localScopeStr $lArrowStr$rArrowStr $remoteScopeStr"
  }

}

case class SingleSideScope(
    id: Option[Int],
    connectionId: Int,
    syncCriteria: SyncCriteria,
    query: Option[Seq[QueryValue]],
    triggerCriteria: TriggerCriteria,
    scopeUid: String,
    local: Boolean,
    mainFields: Seq[FieldValue],
    script: Option[String]
) {

  def toSingleSideScopeValue: SingleSideScopeValue =
    SingleSideScopeValue(
      Option(scopeUid),
      mainFields,
      Some(SyncCriteriaValue(syncCriteria, query)),
      Option(TriggerCriteriaValue(triggerCriteria)),
      script
    )

}

case class QueryValue(
    field: FieldValue,
    operator: OperatorValue,
    value: Object,
    error: Option[EditorErrorValue] = None
)

object QueryValue {
  implicit val format: OFormat[QueryValue] = Json.format
}

case class FieldValue(
    key: String,
    `type`: Option[FieldTypeValue],
    value: Option[Object],
    error: Option[EditorErrorValue] = None
)

object FieldValue {
  implicit val format: OFormat[FieldValue] = Json.format
}

case class ValueOfFieldValue(value: String, label: String)

object ValueOfFieldValue {
  implicit val format: OFormat[ValueOfFieldValue] = Json.format[ValueOfFieldValue]
}

case class FieldTypeValue(key: String)

object FieldTypeValue {
  implicit val format: OFormat[FieldTypeValue] = Json.format
}

case class OperatorValue(key: String)

object OperatorValue {
  implicit val format: OFormat[OperatorValue] = Json.format
}

/** ScopeValue which is used in Visual Editor, holds both side info
  * @param local
  *   \- scope of the local side
  * @param remote
  *   \- scope of the remote side
  */
case class ScopeValue(local: SingleSideScopeValue, remote: SingleSideScopeValue)

object ScopeValue {
  implicit val format: OFormat[ScopeValue] = Json.format
}

/** Scope value of one of the side
  * @param scopeUid
  *   \- uid of the scope
  * @param mainFields
  *   \- main field value of the scope (e.g. Project in Jira)
  * @param syncCriteria
  *   \- QUERY, ALL, NONE;
  * @param triggerCriteria
  *   \- AUTOMATIC, MANUAL, API;
  * @param script
  *   \- script genearated based on the scope rules
  */
case class SingleSideScopeValue(
    scopeUid: Option[String],
    mainFields: Seq[FieldValue],
    syncCriteria: Option[SyncCriteriaValue],
    triggerCriteria: Option[TriggerCriteriaValue] = Some(TriggerCriteriaValue(TriggerCriteria.API)),
    script: Option[String] = None
) {

  def toSingleSideScope(connectionId: Int, local: Boolean, scopeUUID: UUID): SingleSideScope =
    SingleSideScope(
      None,
      connectionId,
      syncCriteria match {
        case Some(sC) => sC.`type`
        case None     => SyncCriteria.ALL
      },
      syncCriteria.flatMap(_.query),
      triggerCriteria.map(_.`type`).getOrElse(TriggerCriteria.API),
      scopeUid.getOrElse(scopeUUID.toString),
      local,
      mainFields,
      script
    )

}

object SingleSideScopeValue {
  implicit val format: OFormat[SingleSideScopeValue] = Json.using[WithDefaultValues].format
}

case class SyncCriteriaValue(`type`: SyncCriteria, query: Option[Seq[QueryValue]])

object SyncCriteriaValue {

  implicit val syncCriteriaFormat: Format[SyncCriteria] = ScopeFormatters.syncCriteriaFormat

  implicit val format: OFormat[SyncCriteriaValue] = Json.format
}

case class TriggerCriteriaValue(`type`: TriggerCriteria)

object TriggerCriteriaValue {

  implicit val triggerCriteriaFormat: Format[TriggerCriteria] =
    ScopeFormatters.triggerCriteriaFormat

  implicit val format: OFormat[TriggerCriteriaValue] = Json.format
}

object ScopeFormatters {

  implicit val triggerCriteriaFormat: Format[TriggerCriteria] = Format(
    Reads {
      case JsString(mt: String) =>
        TriggerCriteria
          .fromString(mt)
          .map(JsSuccess(_))
          .getOrElse(
            JsError(
              s"Unknown TriggerCriteria `$mt`. Known TriggerCriteria: `${TriggerCriteria.values.mkString("`, `")}`"
            )
          )
      case other                =>
        JsError(
          s"Unknown TriggerCriteria `$other`. Expecting a JSON string with either of: `${TriggerCriteria.values
              .mkString("`, `")}`"
        )
    },
    Writes { mt: TriggerCriteria =>
      JsString(mt.toString)
    }
  )

  implicit val syncCriteriaFormat: Format[SyncCriteria] = Format(
    Reads {
      case JsString(mt: String) =>
        SyncCriteria
          .fromString(mt)
          .map(JsSuccess(_))
          .getOrElse(
            JsError(
              s"Unknown SyncCriteria `$mt`. Known SyncCriteria: `${SyncCriteria.values.mkString("`, `")}`"
            )
          )
      case other                =>
        JsError(
          s"Unknown SyncCriteria `$other`. Expecting a JSON string with either of: `${SyncCriteria.values
              .mkString("`, `")}`"
        )
    },
    Writes { mt: SyncCriteria =>
      JsString(mt.toString)
    }
  )

  implicit val fieldValueSeqFormat: Format[Seq[FieldValue]] =
    Format(Reads.traversableReads[Seq, FieldValue], Writes.seq[FieldValue])

  implicit val queryValueSeqFormat: Format[Seq[com.exalate.domain.editor.scopes.QueryValue]] =
    Format(
      Reads.traversableReads[Seq, com.exalate.domain.editor.scopes.QueryValue],
      Writes.seq[com.exalate.domain.editor.scopes.QueryValue]
    )

}
