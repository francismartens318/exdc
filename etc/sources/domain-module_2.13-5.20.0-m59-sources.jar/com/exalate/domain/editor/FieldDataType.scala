package com.exalate.domain.editor

/** The list of field data types supported by Visual editor
  */
object FieldDataType extends Enumeration {
  type FieldDataType = Value

  val TEXT: FieldDataType = Value
  val OPTION: FieldDataType = Value
  val MULTI: FieldDataType = Value
  val FILE: FieldDataType = Value
  val COMMENT: FieldDataType = Value
  val USER: FieldDataType = Value

  val DATE: FieldDataType = Value

  val NUMBER: FieldDataType = Value

  def withNameOpt(s: String): Option[Value] =
    values.find(_.toString == s)

}
