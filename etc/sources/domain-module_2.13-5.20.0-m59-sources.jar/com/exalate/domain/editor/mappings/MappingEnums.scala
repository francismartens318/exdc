package com.exalate.domain.editor.mappings

import com.exalate.api.domain.editor.mappings.MappingType
import com.exalate.api.domain.editor.mappings.MappingType._

object MappingTypeOps {

  def infer(m: Mappings): MappingType =
    /*if (m.script.isDefined) SCRIPT
    else MAPPING*/
    if (m.local.isDefined) MAPPING else SCRIPT

  def fromString(str: String): Option[MappingType] =
    MappingType.fromString(str)

}

object Arrow extends Enumeration {
  type Arrow = Value
  // "arrow":"L"   - "<-- "
  // "arrow":"LR" - "<-->"
  // "arrow":"R"   - " -->"
  val L: Arrow = Value
  val LR: Arrow = Value
  val R: Arrow = Value

  def arrowPseudoGraphic(arrow: Arrow): String =
    arrow match {
      case L  => "<-- "
      case LR => "<-->"
      case R  => " -->"
    }

  def withNameOpt(s: String): Option[Value] =
    values.find(_.toString == s)

}

object AttachmentFilters extends Enumeration {
  type AttachmentFilters = Value

  val SKIP_FILESIZE_GREATER_THAN, SKIP_FILESIZE_LESS_THAN, SKIP_FILESIZE_GREATER_OR_EQUAL,
      SKIP_FILESIZE_LESS_OR_EQUAL = Value

  def withNameOpt(s: String): Option[Value] =
    values.find(_.toString == s)

}

object AttachmentFilterValueUnit extends Enumeration {
  type AttachmentFilterValueUnit = Value
  val GB, MB, KB, BYTE = Value

  def withNameOpt(s: String): Option[AttachmentFilterValueUnit] =
    values
      .find(_.toString.equalsIgnoreCase(s))
      .orElse(values.find(v => (v.toString + "s").equalsIgnoreCase(s)))

  def toBytes(unit: String, amount: Long): Long =
    toBytes(withNameOpt(unit).getOrElse(MB), amount)

  def toBytes(unit: AttachmentFilterValueUnit, amount: Long): Long =
    unit match {
      case BYTE => 1024 * amount
      case KB   => 1024 * amount
      case MB   => 1024 * 1024 * amount
      case GB   => 1024 * 1024 * 1024 * amount
    }

}

object CommentFilters extends Enumeration {
  type CommentFilters = Value
  val SKIP_INTERNAL, SKIP_EXTERNAL, SKIP_ALL, SKIP_NONE = Value

  def withNameOpt(s: String): Option[Value] =
    values.find(_.toString == s)

}
