package com.exalate.domain.editor.mappings

import com.exalate.api.domain.editor.mappings.MappingType
import com.exalate.domain.ObjectJsonFormatters
import com.exalate.domain.editor.error.EditorErrorValue
import play.api.libs.json.Json.WithDefaultValues
import play.api.libs.json._

case class Mappings(
    id: Option[Int],
    connectionId: Int,
    local: Option[MappingFieldTypeValue],
    arrow: Option[String],
    maps: Option[Seq[MapValue]],
    remote: Option[MappingFieldTypeValue],
    inScript: Option[String] = None,
    outScript: Option[String] = None
) {

  def toMappingValue: MappingValue =
    MappingValue(id, local, arrow, maps, remote, inScript, outScript, MappingTypeOps.infer(this))

}

object Mappings {

  implicit val format: OFormat[Mappings] = Json.format

}

/** MappingValue which is used in Visual Editor
  * @param id
  * @param local
  * @param arrow
  * @param maps
  * @param remote
  * @param script
  * @param outScript
  * @param `type`
  * @param errors
  * @param localErrors
  * @param remoteErrors
  */
case class MappingValue(
    id: Option[Int],
    local: Option[MappingFieldTypeValue],
    arrow: Option[String],
    maps: Option[Seq[MapValue]],
    remote: Option[MappingFieldTypeValue],
    script: Option[String] = None, // TODO: Change name to inScript on front-end
    outScript: Option[String] = None,
    `type`: MappingType = MappingType.MAPPING,
    errors: Option[Seq[EditorErrorValue]] = None,
    localErrors: Option[Seq[EditorErrorValue]] = None,
    remoteErrors: Option[Seq[EditorErrorValue]] = None
) {

  def toMappings(connectionId: Int): Mappings =
    Mappings(id, connectionId, local, arrow, maps, remote, script, outScript)

}

object MappingValue {

  implicit val mappingTypeFormat: Format[MappingType] = MappingTypeFormat.format

  implicit val format: OFormat[MappingValue] = Json.using[WithDefaultValues].format

}

case class MappingFieldTypeValue(
    field: FieldValue,
    recovery: Option[Recovery],
    filters: Option[Seq[FilterKey]],
    attributes: Option[Seq[MappingFieldTypeValue]]
)

object MappingFieldTypeValue {

  implicit val format: OFormat[MappingFieldTypeValue] = Json.format

}

case class Recovery(key: String, value: Option[Object], errors: Option[Seq[EditorErrorValue]] = None)

object Recovery {

  implicit val objectFormat: Format[Object] = ObjectJsonFormatters.objFormat

  implicit val format: OFormat[Recovery] = Json.using[WithDefaultValues].format

}

case class FieldValue(key: String, icon: String)

object FieldValue {

  implicit val format: OFormat[FieldValue] = Json.format

}

case class MapValue(
    local: String,
    arrow: String,
    remote: String,
    localError: Option[EditorErrorValue] = None,
    remoteError: Option[EditorErrorValue] = None
)

object MapValue {

  implicit val format: OFormat[MapValue] = Json.format

}

case class FilterKey(key: String, value: Option[FilterKeyValue], isActive: Option[Boolean])

object FilterKey {

  implicit val format: OFormat[FilterKey] = Json.format

}

case class FilterKeyValue(unit: String, value: Int)

object FilterKeyValue {

  implicit val format: OFormat[FilterKeyValue] = Json.format

}

object MappingTypeFormat {

  implicit val format: Format[MappingType] = Format(
    Reads {
      case JsString(mt: String) =>
        MappingType
          .fromString(mt)
          .map(JsSuccess(_))
          .getOrElse(
            JsError(
              s"Unknown MappingType `$mt`. Known MappingTypes: `${MappingType.values.mkString("`, `")}`"
            )
          )
      case other                =>
        JsError(
          s"Unknown MappingType `$other`. Expecting a JSON string with either of: `${MappingType.values
              .mkString("`, `")}`"
        )
    },
    Writes { mt: MappingType =>
      JsString(mt.toString)
    }
  )

}
