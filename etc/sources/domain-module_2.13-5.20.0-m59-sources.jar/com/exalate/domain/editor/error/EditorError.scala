package com.exalate.domain.editor.error

import com.exalate.api.domain.editor.error.{EditorErrorSide, ErrorLocationType}
import com.exalate.util.json.gson.GsonCaseClassValueJsonService
import play.api.libs.json.{JsError, Json, _}

sealed abstract class EditorError(
    val `type`: ErrorLocationType,
    val side: EditorErrorSide,
    val errorValue: EditorErrorValue
)

/** Visual editor error in case exception occurs in SCOPE SCOPE Errors
  * @param scopeUid
  * @param mainField
  * @param side
  * @param errorValue
  */
sealed case class ScopeMainFieldEditorError(
    scopeUid: String,
    mainField: String,
    override val side: EditorErrorSide,
    override val errorValue: EditorErrorValue
) extends EditorError(
      ErrorLocationType.SCOPE_MAIN_FIELD,
      side,
      errorValue
    )

/** Visual editor error in case exception occurs in SCOPE query
  * @param scopeUid
  * @param queryField
  * @param side
  * @param errorValue
  */
sealed case class ScopeQueryEditorError(
    scopeUid: String,
    queryField: String,
    override val side: EditorErrorSide,
    override val errorValue: EditorErrorValue
) extends EditorError(
      ErrorLocationType.SCOPE_QUERY,
      side,
      errorValue
    )

/** Visual editor error in case exception occurs in MAPPING MAPPING Errors
  * @param mappingId
  * @param side
  * @param errorValue
  */
case class MappingEditorError(
    mappingId: Int,
    override val side: EditorErrorSide,
    override val errorValue: EditorErrorValue
) extends EditorError(
      ErrorLocationType.OVERALL_MAPPING,
      side,
      errorValue
    )

/** Visual editor error in case exception occurs in mapping Recovery
  * @param mappingId
  * @param side
  * @param errorValue
  */
case class RecoveryDefaultEditorError(
    mappingId: Int,
    override val side: EditorErrorSide,
    override val errorValue: EditorErrorValue
) extends EditorError(
      ErrorLocationType.RECOVERY_DEFAULT_VALUE,
      side,
      errorValue
    )

/** Visual editor error in case exception occurs in mapping script
  * @param mappingId
  * @param errorValue
  */
case class ScriptMappingEditorError(
    mappingId: Option[Int], // , line: Option[Int], column: Option[Int]
    override val errorValue: EditorErrorValue
) extends EditorError(
      ErrorLocationType.SCRIPT,
      EditorErrorSide.LOCAL,
      errorValue
    )

/** Visual editor error in case one of the mappings is missing
  * @param errorValue
  */
case class MissingMappingEditorError(override val errorValue: EditorErrorValue)
    extends EditorError(
      ErrorLocationType.MAPPING_BUTTON,
      EditorErrorSide.LOCAL,
      errorValue
    )

/** Visual editor error in case exception occurs in mapping maps
  * @param mappingId
  * @param localMapValue
  * @param remoteMapValue
  * @param side
  * @param errorValue
  */
case class MappingMapsEditorError(
    mappingId: Int,
    localMapValue: String,
    remoteMapValue: String,
    override val side: EditorErrorSide,
    override val errorValue: EditorErrorValue
) extends EditorError(
      ErrorLocationType.MAPPING_MAPS,
      side,
      errorValue
    )

/** Visual editor error in case exception occurs in scope script
  * @param scopeId
  * @param errorValue
  */
case class ScriptScopeEditorError(
    scopeId: Int, // , line: Option[Int], column: Option[Int]
    override val errorValue: EditorErrorValue
) extends EditorError(
      ErrorLocationType.SCRIPT,
      EditorErrorSide.LOCAL,
      errorValue
    )

object EditorErrorFormatters {

  implicit val editorErrorSideFormat: Format[EditorErrorSide] = Format(
    Reads {
      case JsString(mt: String) =>
        EditorErrorSide
          .fromString(mt)
          .map(JsSuccess(_))
          .getOrElse(
            JsError(
              s"Unknown EditorErrorSide `$mt`. Known EditorErrorSide: `${EditorErrorSide.values.mkString("`, `")}`"
            )
          )
      case other                =>
        JsError(
          s"Unknown EditorErrorSide `$other`. Expecting a JSON string with either of: `${EditorErrorSide.values
              .mkString("`, `")}`"
        )
    },
    Writes { mt: EditorErrorSide =>
      JsString(mt.toString)
    }
  )

  implicit val errorLocationTypeFormat: Format[ErrorLocationType] = Format(
    Reads {
      case JsString(mt: String) =>
        ErrorLocationType
          .fromString(mt)
          .map(JsSuccess(_))
          .getOrElse(
            JsError(
              s"Unknown ErrorLocationType `$mt`. Known ErrorLocationType: `${ErrorLocationType.values
                  .mkString("`, `")}`"
            )
          )
      case other                =>
        JsError(
          s"Unknown ErrorLocationType `$other`. Expecting a JSON string with either of: `${ErrorLocationType.values
              .mkString("`, `")}`"
        )
    },
    Writes { mt: ErrorLocationType =>
      JsString(mt.toString)
    }
  )

  implicit val scopeMainFieldEditorErrorFormat: OFormat[ScopeMainFieldEditorError] =
    Json.format[ScopeMainFieldEditorError]

  implicit val scopeQueryEditorErrorFormat: OFormat[ScopeQueryEditorError] =
    Json.format[ScopeQueryEditorError]

  implicit val mappingEditorErrorFormat: OFormat[MappingEditorError] =
    Json.format[MappingEditorError]

  implicit val missingMappingEditorErrorFormat: OFormat[MissingMappingEditorError] =
    Json.format[MissingMappingEditorError]

  implicit val mappingMapsEditorErrorFormat: OFormat[MappingMapsEditorError] =
    Json.format[MappingMapsEditorError]

  implicit val recoveryDefaultEditorErrorFormat: OFormat[RecoveryDefaultEditorError] =
    Json.format[RecoveryDefaultEditorError]

  implicit val scriptMappingEditorErrorFormat: OFormat[ScriptMappingEditorError] =
    Json.format[ScriptMappingEditorError]

  implicit val editorErrorFormat: Format[EditorError] = Format(
    Reads[EditorError] {
      case o @ JsObject(v) =>
        (o \ "type").as[ErrorLocationType] match {
          case ErrorLocationType.SCOPE_MAIN_FIELD       => o.validate[ScopeMainFieldEditorError]
          case ErrorLocationType.SCOPE_QUERY            => o.validate[ScopeQueryEditorError]
          case ErrorLocationType.MAPPING_MAPS           => o.validate[MappingMapsEditorError]
          case ErrorLocationType.OVERALL_MAPPING        => o.validate[MappingEditorError]
          case ErrorLocationType.MAPPING_BUTTON         => o.validate[MissingMappingEditorError]
          case ErrorLocationType.RECOVERY_DEFAULT_VALUE => o.validate[RecoveryDefaultEditorError]
          case ErrorLocationType.SCRIPT                 => o.validate[ScriptMappingEditorError]
          case _ => JsError("JSON didn't match any known EditorError subclass")
        }

      case _ => JsError("Expecting a JSON object")
    },
    Writes[EditorError] { v =>
      Json.parse(
        GsonCaseClassValueJsonService
          .write(v)
          .toOption
          .getOrElse(JsNull.toString())
      )
    }
  )

}
