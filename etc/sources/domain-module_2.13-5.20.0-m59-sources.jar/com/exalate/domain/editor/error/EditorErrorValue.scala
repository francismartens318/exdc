package com.exalate.domain.editor.error

import play.api.libs.json._

//"error":{"key":"com.exalate.admin.editor.errors.stale.project", "label":"There's no such project anymore", "value":{"0":"Foo (FOO)"}}
// i18n
/** GIVEN key com.exalate.admin.editor.errors.stale.project i18n.properties has following record:
  * com.exalate.admin.editor.errors.stale.project=There's no project {0} ({1}) anymore value {"0" :
  * "FOO", "1": "100500"} WHEN the error is shown to the user, THEN it looks like this: There's no
  * project FOO (100500) anymore
  */
case class EditorErrorValue(
    key: String,
    label: String,
    value: Option[Map[String, String]] = None,
    line: Option[Int] = None,
    column: Option[Int] = None
)

object EditorErrorValue {

  implicit val format: OFormat[EditorErrorValue] = Json.format

}
