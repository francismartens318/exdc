package com.exalate.domain.oauth

import java.sql.Timestamp

case class OAuthClient(
    id: Option[Long],
    clientId: String,
    clientSecret: String,
    clientIdIssueAt: Timestamp,
    clientSecretExpiresAt: Option[Timestamp],
    tokenEndpointAuthMethod: Option[String],
    clientName: String,
    redirectUris: Seq[String],
    clientUri: String,
    grantTypes: Seq[String],
    responseTypes: Seq[String],
    scope: String,
    authServerUid: String,
    isLocal: Boolean = false
)
