package com.exalate.domain

object TokenType extends Enumeration {
  type TokenType = Value

  val ACCESS_TOKEN: TokenType = Value
  val REFRESH_TOKEN: TokenType = Value

  def withNameOpt(s: String): Option[Value] =
    values.find(_.toString == s)

}
