package com.exalate.domain.metrics

case class MetricsResponseValue(eventKey: String)
