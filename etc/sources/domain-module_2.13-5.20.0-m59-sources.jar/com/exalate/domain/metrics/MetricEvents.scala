package com.exalate.domain.metrics

object MetricEvents extends Enumeration {
  type MetricEvents = Value

  val INITIATE_CONNECTION_STARTED: MetricEvents = Value(
    "initiate_connection_started"
  ) // (duration 0)
  val ACCEPT_INVITATION_STARTED: MetricEvents = Value("accept_invitation_started") // (duration 0)

  val URL_VALIDATION: MetricEvents = Value(
    "url_validation"
  ) // the time user spent to write valid URL (or click "I don't have URL")

  val INVITATION_VALIDATION: MetricEvents = Value(
    "invitation_validation"
  ) // the time user spent to write valid invitation code and click "Next"

  val SELECT_MODE_FINISHED: MetricEvents = Value(
    "select_mode_finished"
  ) // the time user spent to select the connection mode and click "Next"
  val SELECT_MAIN_FIELD_FINISHED: MetricEvents = Value("select_main_field_finished") //
  val SELECT_ADMIN_FINISHED: MetricEvents = Value("select_admin_finished") //
  val CONNECTION_INFO_FINISHED: MetricEvents = Value("connection_info_finished") //

  val OAUTH_PROCESS_STARTED: MetricEvents = Value(
    "oauth_process_started"
  ) // the time user spent to click "Validate admin rights"

  val OAUTH_PROCESS_FINISHED: MetricEvents = Value(
    "oauth_process_finished"
  ) // the time user spent to click "Accept" on the remote side

  val OAUTH_FINISHED: MetricEvents = Value(
    "oauth_finished"
  ) // the time user spent to go back to side A and click Next

  val INITIATE_CONNECTION_FINISHED: MetricEvents = Value(
    "initiate_connection_finished"
  ) // (in this event we will have connection name) - the duration of the connection creation process

  val EXALATE_VALIDATION: MetricEvents = Value(
    "exalate_validation"
  ) // (connection name is required) - the time user spent to write the issue key and click "exalate" (first time)

  val EXALATE_STARTED: MetricEvents = Value(
    "exalate_started"
  ) // (connection name is required) - the time user spent from the first "exalate" click to the real exalation process start

  val EXALATE_FINISHED: MetricEvents = Value(
    "exalate_finished"
  ) // (connection name is required) - the time user wait for exalate process to finish successfully

  def withNameOpt(name: String): Option[Value] =
    MetricEvents.values.find(_.toString.equals(name))

}
