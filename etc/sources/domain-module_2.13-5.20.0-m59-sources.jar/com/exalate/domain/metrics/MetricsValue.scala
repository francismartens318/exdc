package com.exalate.domain.metrics

case class MetricsValue(
    id: Option[Int],
    eventName: String, // name of the event - it is one small part of one big common process
    eventDate: Long,
    eventDuration: Long, // how many ms passed from previous process
    eventKey: Option[String], // unique identifier that point to one common process
    connectionId: Option[Int]
)
