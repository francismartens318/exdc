package com.exalate.domain.issuetracker

import com.exalate.api.domain.IIssueKey
import com.exalate.api.domain.hubobject.IHubIssueReplica
import com.exalate.api.domain.request.ISyncRequest
import com.exalate.api.domain.twintrace.INonPersistentTrace

trait IEntityUpdateContext {
  def entity: IHubIssueReplica
  def issueKey: IIssueKey
  def syncRequest: ISyncRequest
  def traces: Seq[INonPersistentTrace]
}

case class EntityUpdateContext(
    override val entity: IHubIssueReplica,
    override val issueKey: IIssueKey,
    override val syncRequest: ISyncRequest,
    override val traces: Seq[INonPersistentTrace]
) extends IEntityUpdateContext
