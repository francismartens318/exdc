package com.exalate.basic.domain.license;

import com.exalate.api.domain.license.IPersistentLicense;

public class PersistentLicense implements IPersistentLicense {

    private int id;
    private String payload;

    public PersistentLicense(final int id, final String payload) {
        this.id = id;
        this.payload = payload;
    }

    @Override
    public int getId() {
        return id;
    }

    @Override
    public String getPayload() {
        return payload;
    }

}
