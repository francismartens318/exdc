package com.exalate.basic.domain.license;

import com.exalate.api.domain.license.ILicense;
import com.exalate.api.domain.license.INonPersistentLicense;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.google.common.base.Objects;

import java.time.temporal.ChronoUnit;
import java.util.Date;

public class NonPersistentLicense implements INonPersistentLicense {

    private String licenseVersion;
    private String organisation;
    @JsonFormat(pattern = "MMM dd, yyyy HH:mm:ss a")
    private Date startDate;
    @JsonFormat(pattern = "MMM dd, yyyy HH:mm:ss a")
    private Date endDate;
    private String opportunity;
    private Long connections;
    private String signature;
    private boolean isEvaluation;
    private boolean isFreemium;
    private String instanceUid, stripeSubscriptionId;
    private Long pairNumber;
    private ChronoUnit calendarUnit;
    private Long useplan;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        NonPersistentLicense that = (NonPersistentLicense) o;
        return isEvaluation == that.isEvaluation && isFreemium == that.isFreemium && Objects.equal(licenseVersion, that.licenseVersion) && Objects.equal(organisation, that.organisation) && Objects.equal(startDate, that.startDate) && Objects.equal(endDate, that.endDate) && Objects.equal(opportunity, that.opportunity) && Objects.equal(connections, that.connections) && Objects.equal(signature, that.signature) && Objects.equal(instanceUid, that.instanceUid) && Objects.equal(stripeSubscriptionId, that.stripeSubscriptionId) && Objects.equal(pairNumber, that.pairNumber) && calendarUnit == that.calendarUnit && Objects.equal(useplan, that.useplan);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(licenseVersion, organisation, startDate, endDate, opportunity, connections, signature, isEvaluation, isFreemium, instanceUid, stripeSubscriptionId, pairNumber, calendarUnit, useplan);
    }

    public NonPersistentLicense() {
        super();
    }

    public NonPersistentLicense(String licenseVersion,
                                String organisation,
                                Date startDate,
                                Date endDate,
                                String opportunity,
                                Long connections,
                                Long useplan,
                                String signature,
                                boolean isEvaluation,
                                boolean isFreemium, String instanceUid,
                                String stripeSubscriptionId,
                                Long pairNumber,
                                ChronoUnit calendarUnit) {
        this.licenseVersion = licenseVersion;
        this.organisation = organisation;
        this.startDate = startDate;
        this.endDate = endDate;
        this.opportunity = opportunity;
        this.connections = connections;
        this.useplan = useplan;
        this.signature = signature;
        this.isEvaluation = isEvaluation;
        this.isFreemium = isFreemium;
        this.instanceUid = instanceUid;
        this.stripeSubscriptionId = stripeSubscriptionId;
        this.pairNumber = pairNumber;
        this.calendarUnit = calendarUnit;
    }

    public NonPersistentLicense(ILicense license) {
        this(license.getLicenseVersion(),
                license.getOrganisation(),
                license.getStartDate(),
                license.getEndDate(),
                license.getOpportunity(),
                license.getConnections(),
                0L,
                license.getSignature(),
                license.getIsEvaluation(),
                license.getIsFreemium(),
                license.getInstanceUid(),
                license.getStripeSubscriptionId(),
                license.getPairNumber(),
                license.getCalendarUnit());
    }

    /* Used for License V3
        organisation, opportunity, connections are set to null
        signature - is set later
     */
    public NonPersistentLicense(String licenseVersion,
                                Date startDate,
                                Date endDate,
                                boolean isEvaluation,
                                String instanceUid,
                                String stripeSubscriptionId) {
        this(licenseVersion,
                null,
                startDate,
                endDate,
                null,
                0L,
                0L,
                null,
                isEvaluation,
                false,
                instanceUid,
                stripeSubscriptionId,
                -1L,
                ChronoUnit.MONTHS);
    }


    public String getLicenseVersion() {
        return licenseVersion;
    }

    public String getOrganisation() {
        return organisation;
    }

    public Date getStartDate() {
        return startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public String getOpportunity() {
        return opportunity;
    }

    public Long getConnections() {
        return connections;
    }

    public String getSignature() {
        return signature;
    }

    @Override
    public void setSignature(final String signature) {
        this.signature = signature;
    }

    @Override
    public boolean getIsEvaluation() {
        return isEvaluation;
    }

    @Override
    public boolean getIsFreemium() {
        return isFreemium;
    }

    @Override
    public String getStripeSubscriptionId() {
        return stripeSubscriptionId;
    }

    @Override
    public String getInstanceUid() {
        return instanceUid;
    }

    @Override
    public Long getPairNumber() {
        return pairNumber;
    }

    @Override
    public ChronoUnit getCalendarUnit() {
        return calendarUnit;
    }

    @Override
    public Long getUseplan() {
        return useplan;
    }
}
