package com.exalate.basic.domain.license;

import com.exalate.api.domain.license.ILicense;
import com.exalate.api.domain.license.INonPersistentLicense;
import com.exalate.api.domain.license.IPersistentLicense;

import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.Objects;

public class License implements ILicense {

    private int id;
    private String licenseVersion;
    private String organisation;
    private Date startDate;
    private Date endDate;
    private String opportunity;
    private long connections;
    private String signature;
    private boolean isEvaluation;
    private boolean isFreemium;
    private String instanceUid, stripeSubscriptionId;
    private Long pairNumber;
    private ChronoUnit calendarUnit;

    public License(final int id, final String licenseVersion, final String organisation,
                   final Date startDate, final Date endDate, final String opportunity,
                   final long connections, final String signature,
                   boolean isEvaluation, boolean isFreemium, String instanceUid, String stripeSubscriptionId,
                   Long pairNumber, ChronoUnit calendarUnit) {
        this.id = id;
        this.licenseVersion = licenseVersion;
        this.organisation = organisation;
        this.startDate = startDate;
        this.endDate = endDate;
        this.opportunity = opportunity;
        this.connections = connections;
        this.signature = signature;
        this.isEvaluation = isEvaluation;
        this.isFreemium = isFreemium;
        this.instanceUid = instanceUid;
        this.stripeSubscriptionId = stripeSubscriptionId;
        this.pairNumber = pairNumber;
        this.calendarUnit = calendarUnit;
    }

    public License(final IPersistentLicense persistentLicense,final INonPersistentLicense nonPersistentLicense) {
        setAttributes(persistentLicense.getId(), nonPersistentLicense);
    }

    public License(final Integer licenseId,final INonPersistentLicense nonPersistentLicense) {
        setAttributes(licenseId, nonPersistentLicense);
    }

    private void setAttributes(int licenseId, INonPersistentLicense nonPersistentLicense) {
        this.id = licenseId;
        this.licenseVersion = nonPersistentLicense.getLicenseVersion();
        this.organisation = nonPersistentLicense.getOrganisation();
        this.startDate = nonPersistentLicense.getStartDate();
        this.endDate = nonPersistentLicense.getEndDate();
        this.opportunity = nonPersistentLicense.getOpportunity();
        this.connections = nonPersistentLicense.getConnections();
        this.signature = nonPersistentLicense.getSignature();
        this.isEvaluation = nonPersistentLicense.getIsEvaluation();
        this.isFreemium = nonPersistentLicense.getIsFreemium();
        this.instanceUid = nonPersistentLicense.getInstanceUid();
        this.stripeSubscriptionId = nonPersistentLicense.getStripeSubscriptionId();
        this.pairNumber = nonPersistentLicense.getPairNumber();
        this.calendarUnit = nonPersistentLicense.getCalendarUnit();
    }

    @Override
    public int getId() { return id; }

    @Override
    public String getLicenseVersion() {
        return licenseVersion;
    }

    @Override
    public String getOrganisation() {
        return organisation;
    }

    @Override
    public Date getStartDate() {
        return startDate;
    }


    @Override
    public Date getEndDate() {
        return endDate;
    }

    @Override
    public String getOpportunity() {
        return opportunity;
    }

    @Override
    public long getConnections() {
        return connections;
    }

    @Override
    public String getSignature() {
        return signature;
    }

    @Override
    public boolean getIsEvaluation() {
        return isEvaluation;
    }

    @Override
    public boolean getIsFreemium() {
        return isFreemium;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        License license = (License) o;

        if (id != license.id) return false;
        if (connections != license.connections) return false;
        if (!Objects.equals(licenseVersion, license.licenseVersion))
            return false;
        if (!Objects.equals(organisation, license.organisation))
            return false;
        if (!Objects.equals(startDate, license.startDate)) return false;
        if (!Objects.equals(endDate, license.endDate)) return false;
        if (!Objects.equals(opportunity, license.opportunity)) return false;
        if (!Objects.equals(instanceUid, license.instanceUid)) return false;
        if (!Objects.equals(isEvaluation, license.isEvaluation)) return false;
        if (!Objects.equals(stripeSubscriptionId, license.stripeSubscriptionId)) return false;
        if (!Objects.equals(pairNumber, license.pairNumber)) return false;
        if (!Objects.equals(calendarUnit, license.calendarUnit)) return false;
        return Objects.equals(signature, license.signature);
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + (licenseVersion != null ? licenseVersion.hashCode() : 0);
        result = 31 * result + (organisation != null ? organisation.hashCode() : 0);
        result = 31 * result + (startDate != null ? startDate.hashCode() : 0);
        result = 31 * result + (endDate != null ? endDate.hashCode() : 0);
        result = 31 * result + (opportunity != null ? opportunity.hashCode() : 0);
        result = 31 * result + (instanceUid != null ? instanceUid.hashCode() : 0);
        result = 31 * result + (stripeSubscriptionId != null ? stripeSubscriptionId.hashCode() : 0);
        result = 31 * result + (calendarUnit != null ? calendarUnit.hashCode() : 0);
        result = 31 * result + (int) (connections ^ (connections >>> 32));
        result = 31 * result + (int) (pairNumber ^ (pairNumber >>> 32));
        result = 31 * result + (signature != null ? signature.hashCode() : 0);
        return result;
    }

    @Override
    public String getStripeSubscriptionId() {
        return stripeSubscriptionId;
    }

    @Override
    public String getInstanceUid() {
        return instanceUid;
    }

    @Override
    public Long getPairNumber() {
        return pairNumber;
    }

    @Override
    public ChronoUnit getCalendarUnit() {
        return calendarUnit;
    }
}
