package com.exalate.basic.domain.license;

import com.exalate.api.domain.instance.IInstance;
import com.exalate.api.domain.license.IAssignedLicense;
import com.exalate.api.domain.license.IPersistentLicense;
import com.exalate.api.domain.license.PaymentModel;

public class AssignedLicense implements IAssignedLicense {

    private int id;
    private IInstance instance;
    private PaymentModel paymentModel;

    public AssignedLicense(int id, IInstance instance, PaymentModel paymentModel) {
        this.id = id;
        this.instance = instance;
        this.paymentModel = paymentModel;
    }

    @Override
    public int getId() {
        return id;
    }

    @Override
    public IInstance getInstance() {
        return instance;
    }

    @Override
    public PaymentModel getPaymentModel() {
        return paymentModel;
    }
}
