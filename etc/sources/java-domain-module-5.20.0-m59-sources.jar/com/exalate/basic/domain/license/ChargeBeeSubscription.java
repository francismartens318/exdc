package com.exalate.basic.domain.license;

import com.exalate.api.domain.license.ILicense;

import java.time.temporal.ChronoUnit;
import java.util.Date;

/**
 * This is a temporary solution. Should be removed once we overwrite the {{LicenseReplicationService}}
 */
public class ChargeBeeSubscription implements ILicense {
    private String id;
    private String status;
    private String subscriptionId;

    private Date startDate;
    private Date endDate;

    @Override
    public int getId() {
        try {
            return Integer.parseInt(id);
        }
        catch(Exception e) {
            return 0;
        }
    }

    @Override
    public String getLicenseVersion() {
        return null;
    }

    @Override
    public String getOrganisation() {
        return null;
    }

    @Override
    public Date getStartDate() {
        return startDate;
    }

    @Override
    public Date getEndDate() {
        return endDate;
    }

    @Override
    public String getOpportunity() {
        return null;
    }

    @Override
    public long getConnections() {
        return 0;
    }

    @Override
    public String getSignature() {
        return null;
    }

    @Override
    public boolean getIsEvaluation() {
        return false;
    }

    @Override
    public boolean getIsFreemium() {
        return false;
    }

    @Override
    public String getStripeSubscriptionId() {
        return null;
    }

    @Override
    public String getInstanceUid() {
        return null;
    }

    @Override
    public Long getPairNumber() {
        return 1000L;
    }

    @Override
    public ChronoUnit getCalendarUnit() {
        return null;
    }

    public String getStatus() {
        return status;
    }

    public ChargeBeeSubscription(String id, String status, String subscriptionId, Date startDate, Date endDate) {
        this.id = id;
        this.status = status;
        this.subscriptionId = subscriptionId;
        this.startDate = startDate;
        this.endDate = endDate;
    }

    public String getSubscriptionId() {
        return subscriptionId;
    }
}
