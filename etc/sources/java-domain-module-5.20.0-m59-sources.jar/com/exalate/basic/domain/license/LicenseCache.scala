package com.exalate.basic.domain.license

import java.sql.Timestamp

final case class LicenseCache(
    key: String,
    license: String,
    persistentDuration: Long,
    updatedAt: Timestamp = new Timestamp(System.currentTimeMillis())
)
