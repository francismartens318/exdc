package com.exalate.basic.domain.license;

import com.exalate.api.domain.license.ISubscriptionContext;

public class SubscriptionContext implements ISubscriptionContext {
    private final boolean remoteWithNodeSubscription;
    private final boolean remoteWithExalateSubscription;

    public SubscriptionContext(boolean remoteWithNodeSubscription, boolean remoteWithExalateSubscription) {
        this.remoteWithNodeSubscription = remoteWithNodeSubscription;
        this.remoteWithExalateSubscription = remoteWithExalateSubscription;
    }

    @Override
    public boolean isRemoteWithNodeSubscription() {
        return remoteWithNodeSubscription;
    }

    @Override
    public boolean isRemoteWithExalateSubscription() {
        return remoteWithExalateSubscription;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SubscriptionContext that = (SubscriptionContext) o;

        return remoteWithNodeSubscription == that.remoteWithNodeSubscription && remoteWithExalateSubscription == that.remoteWithExalateSubscription;
    }

    @Override
    public int hashCode() {
        int result = (remoteWithNodeSubscription ? 1 : 0);
        result = 31 * result + (remoteWithExalateSubscription ? 1 : 0);
        return result;
    }
}
