package com.exalate.basic.domain;

import com.exalate.api.domain.IIssueKey;
import com.google.common.collect.Maps;

import java.util.Map;

public class BasicIssueKey implements IIssueKey {

    private final String id, urn, entityType;
    private Map<String, String> fieldValues;

    public BasicIssueKey(String id, String urn) {
        this.id = id;
        this.urn = urn;
        this.entityType = "issue";
        this.fieldValues = Maps.newHashMap();
    }

    public BasicIssueKey(String id, String urn, String entityType) {
        this.id = id;
        this.urn = urn;
        this.entityType = entityType;
        this.fieldValues = Maps.newHashMap();
    }

    public BasicIssueKey(String id, String urn, String entityType, Map<String, String> fieldValues) {
        this.id = id;
        this.urn = urn;
        this.entityType = entityType;
        this.fieldValues = fieldValues;
    }

    public BasicIssueKey(Long id, String urn) {
        this.id = String.valueOf(id);
        this.urn = urn;
        this.entityType = "issue";
        this.fieldValues = Maps.newHashMap();
    }

    @Override
    public String getIdStr() {
        return id;
    }

    public Long getId() {
        if(id == null) return null;
        return Long.valueOf(id);
    }

    public String getKey(){
        return this.urn;
    }

    @Override
    public String getURN() {
        return urn;
    }

    @Override
    public String getEntityType() {
        return entityType;
    }

    @Override
    public Map<String, String> getFieldValues() {
        return fieldValues;
    }

    @Override
    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }

        if (object == null || getClass() != object.getClass()) {
            return false;
        }

        BasicIssueKey that = (BasicIssueKey)object;

        if (urn != null ? !urn.equals(that.urn) : that.urn != null) {
            return false;
        }
        if (id != null ? !id.equals(that.id) : that.id != null) {
            return false;
        }
        if (entityType != null ? !entityType.equals(that.entityType) : that.entityType != null) {
            return false;
        }
        if (fieldValues != null ? !fieldValues.equals(that.fieldValues) : that.fieldValues != null) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (urn != null ? urn.hashCode() : 0);
        result = 31 * result + (entityType != null ? entityType.hashCode() : 0);
        result = 31 * result + (fieldValues != null ? fieldValues.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "BasicIssueKey{" +
                "@id=`" + id + '`' +
                ", @urn=`" + urn + '`' +
                ", @fieldValues=`" + fieldValues + '`' +
                ", @entityType=`" + entityType + '`' +
            '}';
    }
}
