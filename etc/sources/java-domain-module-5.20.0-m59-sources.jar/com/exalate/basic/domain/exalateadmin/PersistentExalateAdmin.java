package com.exalate.basic.domain.exalateadmin;

import com.exalate.api.domain.ErrorEntityType;
import com.exalate.api.domain.exalateadmin.IPersistentExalateAdmin;

public class PersistentExalateAdmin implements IPersistentExalateAdmin {

    private int id;
    private String name;
    private String emailAddress;
    private ErrorEntityType minimumErrorLevel;


    public PersistentExalateAdmin(int id, String name, String emailAddress, ErrorEntityType minimumErrorLevel) {
        this.id = id;
        this.name = name;
        this.emailAddress = emailAddress;
        this.minimumErrorLevel = minimumErrorLevel;
    }


    @Override
    public ErrorEntityType getMinimumErrorLevel() {
        return minimumErrorLevel;
    }

    @Override
    public String getEmailAddress() {
        return emailAddress;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public int getId() {
        return id;
    }
}
