package com.exalate.basic.domain.exalateadmin;

import com.exalate.api.domain.ErrorEntityType;
import com.exalate.api.domain.exalateadmin.INonPersistentExalateAdmin;

public class NonPersistentExalateAdmin implements INonPersistentExalateAdmin {

    private String name;
    private String emailAddress;
    private ErrorEntityType minimumErrorLevel;


    public NonPersistentExalateAdmin(String name, String emailAddress, ErrorEntityType minimumErrorLevel) {
        this.name = name;
        this.emailAddress = emailAddress;
        this.minimumErrorLevel = minimumErrorLevel;
    }


    @Override
    public ErrorEntityType getMinimumErrorLevel() {
        return minimumErrorLevel;
    }

    @Override
    public void setMinimumErrorLevel(ErrorEntityType minimumErrorLevel) {
        this.minimumErrorLevel = minimumErrorLevel;
    }

    @Override
    public String getEmailAddress() {
        return emailAddress;
    }

    @Override
    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }
}
