package com.exalate.basic.domain.nodeinfo;

import com.exalate.api.domain.nodeinfo.INodeInfo;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

/**
 * basic implementation of persistent {@link INodeInfo}
 */
public class NodeInfo implements INodeInfo {

    private final int id;
    private final String name;
    private final String exalateUrl;
    private final String issueTrackerUrl;
    private final String nodeType;
    private final String issueTrackerVersion;
    private final String nodeVersion;
    private final String minHubObjectsVersion;
    private final String maxHubObjectsVersion;
    private final String minRestVersion;
    private final String maxRestVersion;
    private final boolean pollOnly;
    private final String exaCompVersion;
    private final String instanceUid;
    private final String editorValue;
    private final String iconUrl;
    private final String basicConnectionValue;

    public NodeInfo(int id, String name, String exalateUrl, String issueTrackerUrl, String nodeTypeStr, String issueTrackerVersion,
                    String nodeVersion, String minHubObjectsVersion, String maxHubObjectsVersion, String minRestVersion, String maxRestVersion, boolean pollOnly, String exaCompVersion, String instanceUid,
                    String editorValue, String iconUrl, String basicConnectionValue) {
        this.id = id;
        this.name = name;
        this.exalateUrl = exalateUrl;
        this.issueTrackerUrl = issueTrackerUrl;
        this.nodeType =nodeTypeStr;
        this.issueTrackerVersion = issueTrackerVersion;
        this.nodeVersion = nodeVersion;
        this.minHubObjectsVersion = minHubObjectsVersion;
        this.maxHubObjectsVersion = maxHubObjectsVersion;
        this.minRestVersion = minRestVersion;
        this.maxRestVersion = maxRestVersion;
        this.pollOnly = pollOnly;
        this.exaCompVersion = exaCompVersion;
        this.instanceUid = instanceUid;
        this.editorValue = editorValue;
        this.iconUrl = iconUrl;
        this.basicConnectionValue = basicConnectionValue;
    }

    @Override
    public int getId() {
        return id;
    }

    @Nonnull
    @Override
    public String getName() {
        return name;
    }

    @Nonnull
    @Override
    public String getExalateUrl() {
        return exalateUrl;
    }

    @Nonnull
    @Override
    public String getIssueTrackerUrl() {
        return issueTrackerUrl;
    }

    @Nonnull
    @Override
    public String getNodeType() {
        return nodeType;
    }

    @Nonnull
    @Override
    public String getIssueTrackerVersion() {
        return issueTrackerVersion;
    }

    @Nonnull
    @Override
    public String getNodeVersion() {
        return nodeVersion;
    }

    @Nonnull
    @Override
    public String getMinHubObjectsVersion() {
        return minHubObjectsVersion;
    }

    @Nonnull
    @Override
    public String getMaxHubObjectsVersion() {
        return maxHubObjectsVersion;
    }

    @Nonnull
    @Override
    public String getMinRestVersion() {
        return minRestVersion;
    }

    @Nonnull
    @Override
    public String getMaxRestVersion() {
        return maxRestVersion;
    }

    @Override
    public boolean isPollOnly() {
        return pollOnly;
    }

    @Nullable
    @Override
    public String getExaCompVersion() {
        return exaCompVersion;
    }

    @Override
    public String getInstanceUid() {
        return instanceUid;
    }

    @Override
    public String getEditorValue() {
        return editorValue;
    }

    @Override
    public String getIconUrl() {
        return iconUrl;
    }

    @Override
    public String getBasicConnectionValue() {
        return basicConnectionValue;
    }
}
