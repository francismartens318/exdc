/*
 * Copyright (C) 2015, Exalate NV
 * All rights reserved.
 *
 *
 * THIS SOURCE CODE IS AN UNPUBLISHED PROPRIETARY TRADE SECRET OF iDalko NV, unless stated otherwise
 * in the license text.
 *
 *
 * The copyright notice above does not evidence any actual or intended publication of such source code.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
 */
package com.exalate.basic.domain.nodeinfo;

import com.exalate.api.domain.hubobject.ISemanticVersion;
import com.exalate.api.domain.nodeinfo.INodeInfo;
import com.exalate.api.domain.nodeinfo.INonPersistentNodeInfo;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

public class BasicNodeInfo implements INonPersistentNodeInfo, INonPersistentNodeInfo.Builder {
    private final String name;
    private final String exalateUrl;
    private final String issueTrackerUrl;
    private final String nodeType;
    private final String issueTrackerVersion;
    private final String nodeVersion;
    private final String minHubObjectsVersion;
    private final String maxHubObjectsVersion;
    private final String minRestVersion;
    private final String maxRestVersion;
    private final boolean pollOnly;
    private final String exaCompVersion;
    private final String instanceUid;
    private final String editorValue;
    private final String iconUrl;
    private final String basicConnectionValue;


    private final boolean isNameSet;
    private final boolean isExalateUrlSet;
    private final boolean isIssueTrackerUrlSet;
    private final boolean isNodeTypeSet;
    private final boolean isIssueTrackerVersionSet;
    private final boolean isNodeVersionSet;
    private final boolean isMinHubObjectsVersionSet;
    private final boolean isMaxHubObjectsVersionSet;
    private final boolean isMinRestVersionSet;
    private final boolean isMaxRestVersionSet;
    private final boolean isPollOnlySet;
    private final boolean isExaCompVersionSet;
    private final boolean isInstanceUidSet;
    private final boolean isEditorValueSet;
    private final boolean isIconUrlSet;
    private final boolean isBasicConnectionValueSet;

    public BasicNodeInfo() {
        this(
                false, null,
                false, null,
                false, null,
                false, null,
                false, null,
                false, null,
                false, null,
                false, null,
                false, null,
                false, null,
                false, false,
                false, null,
                false,null,
                false, null,
                false, null,
                false, null
        );
    }

    private BasicNodeInfo(
            boolean isNameSet, String name,
            boolean isExalateUrlSet, String exalateUrl,
            boolean isIssueTrackerUrlSet, String issueTrackerUrl,
            boolean isNodeTypeSet,
            String nodeType,
            boolean isIssueTrackerVersionSet, String issueTrackerVersion,
            boolean isNodeVersionSet, String nodeVersion,
            boolean isMinHubObjectsVersionSet, String minHubObjectsVersion,
            boolean isMaxHubObjectsVersionSet, String maxHubObjectsVersion,
            boolean isMinRestVersionSet, String minRestVersion,
            boolean isMaxRestVersionSet, String maxRestVersion,
            boolean isPollOnlySet, boolean pollOnly,
            boolean isExaCompVersionSet, String exaCompVersion,
            boolean isInstanceUidSet, String instanceUid,
            boolean isEditorValueSet, String editorValue,
            boolean isIconUrlSet, String iconUrl,
            boolean isBasicConnectionValueSet, String basicConnectionValue) {
        this.name = name;
        this.exalateUrl = exalateUrl;
        this.issueTrackerUrl = issueTrackerUrl;
        this.nodeType = nodeType;
        this.issueTrackerVersion = issueTrackerVersion;
        this.nodeVersion = nodeVersion;
        this.minHubObjectsVersion = minHubObjectsVersion;
        this.maxHubObjectsVersion = maxHubObjectsVersion;
        this.minRestVersion = minRestVersion;
        this.maxRestVersion = maxRestVersion;
        this.pollOnly = pollOnly;
        this.exaCompVersion = exaCompVersion;
        this.instanceUid = instanceUid;
        this.editorValue = editorValue;
        this.iconUrl = iconUrl;

        this.isNameSet = isNameSet;
        this.isExalateUrlSet = isExalateUrlSet;
        this.isIssueTrackerUrlSet = isIssueTrackerUrlSet;
        this.isNodeTypeSet = isNodeTypeSet;
        this.isIssueTrackerVersionSet = isIssueTrackerVersionSet;
        this.isNodeVersionSet = isNodeVersionSet;
        this.isMinHubObjectsVersionSet = isMinHubObjectsVersionSet;
        this.isMaxHubObjectsVersionSet = isMaxHubObjectsVersionSet;
        this.isMinRestVersionSet = isMinRestVersionSet;
        this.isMaxRestVersionSet = isMaxRestVersionSet;
        this.isPollOnlySet = isPollOnlySet;
        this.isExaCompVersionSet = isExaCompVersionSet;
        this.isInstanceUidSet = isInstanceUidSet;
        this.isEditorValueSet = isEditorValueSet;
        this.isIconUrlSet = isIconUrlSet;

        this.isBasicConnectionValueSet = isBasicConnectionValueSet;
        this.basicConnectionValue = basicConnectionValue;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public String getExalateUrl() { return exalateUrl; }

    @Override
    public String getIssueTrackerUrl() {
        return issueTrackerUrl;
    }

    @Override
    public String getNodeType() {
        return nodeType;
    }

    public String getIssueTrackerVersion() {
        return issueTrackerVersion;
    }

    public String getNodeVersion() {
        return nodeVersion;
    }

    @Override
    public String getMinHubObjectsVersion() {
        return minHubObjectsVersion;
    }

    @Override
    public String getMaxHubObjectsVersion() {
        return maxHubObjectsVersion;
    }

    @Override
    public String getMinRestVersion() {
        return minRestVersion;
    }

    @Override
    public String getMaxRestVersion() {
        return maxRestVersion;
    }

    @Override
    public boolean isPollOnly() {
        return pollOnly;
    }

    @Override
    public String getExaCompVersion() {
        return exaCompVersion;
    }

    @Override
    public String getInstanceUid() {
        return instanceUid;
    }

    @Override
    public String getEditorValue() {
        return editorValue;
    }

    @Override
    public String getIconUrl() {
        return iconUrl;
    }

    @Override
    public boolean isNameSet() {
        return isNameSet;
    }

    @Override
    public boolean isExalateUrlSet() {
        return isExalateUrlSet;
    }

    @Override
    public boolean isIssueTrackerUrlSet() { return isIssueTrackerUrlSet;    }

    @Override
    public boolean isNodeTypeSet() {
        return isNodeTypeSet;
    }

    @Override
    public boolean isIssueTrackerVersionSet() {
        return isIssueTrackerVersionSet;
    }

    @Override
    public boolean isNodeVersionSet() {
        return isNodeVersionSet;
    }

    @Override
    public boolean isMinHubObjectsVersionSet() {
        return isMinHubObjectsVersionSet;
    }

    @Override
    public boolean isMaxHubObjectsVersionSet() {
        return isMaxHubObjectsVersionSet;
    }

    @Override
    public boolean isMinRestVersionSet() {
        return isMinRestVersionSet;
    }

    @Override
    public boolean isMaxRestVersionSet() {
        return isMaxRestVersionSet;
    }

    @Override
    public boolean isPollOnlySet() {
        return isPollOnlySet;
    }

    @Override
    public boolean isExaCompVersionSet() {
        return isExaCompVersionSet;
    }

    @Override
    public boolean isInstanceUidSet() {
        return isInstanceUidSet;
    }

    @Override
    public boolean isEditorValueSet() {
        return isEditorValueSet;
    }

    @Override
    public boolean isIconUrlSet() {
        return isIconUrlSet;
    }

    @Override
    public boolean isBasicConnectionValueSet() {
        return isBasicConnectionValueSet;
    }

    @Override
    public String getBasicConnectionValue() {
        return basicConnectionValue;
    }

    @Override
    public BasicNodeInfo build() {
        return this;
    }

    @Nonnull
    @Override
    public BasicNodeInfo from(@Nonnull INodeInfo nodeInfo) {
        return getBasicNodeInfo(nodeInfo);
    }

    @Nonnull
    @Override
    public BasicNodeInfo setName(@Nonnull String name) {
        return new BasicNodeInfo(
                true, name,
                isExalateUrlSet, exalateUrl,
                isIssueTrackerUrlSet, issueTrackerUrl,
                isNodeTypeSet, nodeType,
                isIssueTrackerVersionSet, issueTrackerVersion,
                isNodeVersionSet, nodeVersion,
                isMinHubObjectsVersionSet, minHubObjectsVersion,
                isMaxHubObjectsVersionSet, maxHubObjectsVersion,
                isMinRestVersionSet, minRestVersion,
                isMaxRestVersionSet, maxRestVersion,
                isPollOnlySet, pollOnly,
                isExaCompVersionSet, exaCompVersion,
                isInstanceUidSet, instanceUid,
                isEditorValueSet, editorValue,
                isIconUrlSet, iconUrl,
                isBasicConnectionValueSet, basicConnectionValue
        );
    }

    @Nonnull
    @Override
    public BasicNodeInfo setExalateUrl(@Nonnull String exalateUrl) {
        return new BasicNodeInfo(
                isNameSet, name,
                true, exalateUrl,
                isIssueTrackerUrlSet, issueTrackerUrl,
                isNodeTypeSet, nodeType,
                isIssueTrackerVersionSet, issueTrackerVersion,
                isNodeVersionSet, nodeVersion,
                isMinHubObjectsVersionSet, minHubObjectsVersion,
                isMaxHubObjectsVersionSet, maxHubObjectsVersion,
                isMinRestVersionSet, minRestVersion,
                isMaxRestVersionSet, maxRestVersion,
                isPollOnlySet, pollOnly,
                isExaCompVersionSet, exaCompVersion,
                isInstanceUidSet, instanceUid,
                isEditorValueSet, editorValue,
                isIconUrlSet, iconUrl,
                isBasicConnectionValueSet, basicConnectionValue
        );
    }

    @Nonnull
    @Override
    public BasicNodeInfo setIssueTrackerUrl(@Nonnull String issueTrackerUrl) {
        return new BasicNodeInfo(
                isNameSet, name,
                isExalateUrlSet, exalateUrl,
                true, issueTrackerUrl,
                isNodeTypeSet, nodeType,
                isIssueTrackerVersionSet, issueTrackerVersion,
                isNodeVersionSet, nodeVersion,
                isMinHubObjectsVersionSet, minHubObjectsVersion,
                isMaxHubObjectsVersionSet, maxHubObjectsVersion,
                isMinRestVersionSet, minRestVersion,
                isMaxRestVersionSet, maxRestVersion,
                isPollOnlySet, pollOnly,
                isExaCompVersionSet, exaCompVersion,
                isInstanceUidSet, instanceUid,
                isEditorValueSet, editorValue,
                isIconUrlSet, iconUrl,
                isBasicConnectionValueSet, basicConnectionValue
        );
    }

    @Nonnull
    @Override
    public BasicNodeInfo setNodeType(@Nonnull String nodeType) {
        return new BasicNodeInfo(
                isNameSet, name,
                isExalateUrlSet, exalateUrl,
                isIssueTrackerUrlSet, issueTrackerUrl,
                true, nodeType,
                isIssueTrackerVersionSet, issueTrackerVersion,
                isNodeVersionSet, nodeVersion,
                isMinHubObjectsVersionSet, minHubObjectsVersion,
                isMaxHubObjectsVersionSet, maxHubObjectsVersion,
                isMinRestVersionSet, minRestVersion,
                isMaxRestVersionSet, maxRestVersion,
                isPollOnlySet, pollOnly,
                isExaCompVersionSet, exaCompVersion,
                isInstanceUidSet, instanceUid,
                isEditorValueSet, editorValue,
                isIconUrlSet, iconUrl,
                isBasicConnectionValueSet, basicConnectionValue
        );
    }

    @Nonnull
    public BasicNodeInfo setIssueTrackerVersion(@Nonnull ISemanticVersion issueTrackerVersion) {
        String issueTrackerVersionStr = issueTrackerVersion.toString();
        return new BasicNodeInfo(
                isNameSet, name,
                isExalateUrlSet, exalateUrl,
                isIssueTrackerUrlSet, issueTrackerUrl,
                isNodeTypeSet, nodeType,
                true, issueTrackerVersionStr,
                isNodeVersionSet, nodeVersion,
                isMinHubObjectsVersionSet, minHubObjectsVersion,
                isMaxHubObjectsVersionSet, maxHubObjectsVersion,
                isMinRestVersionSet, minRestVersion,
                isMaxRestVersionSet, maxRestVersion,
                isPollOnlySet, pollOnly,
                isExaCompVersionSet, exaCompVersion,
                isInstanceUidSet, instanceUid,
                isEditorValueSet, editorValue,
                isIconUrlSet, iconUrl,
                isBasicConnectionValueSet, basicConnectionValue
        );
    }

    @Nonnull
    public BasicNodeInfo setNodeVersion(@Nonnull ISemanticVersion nodeVersion) {
        String nodeVersionStr = nodeVersion.toString();
        return new BasicNodeInfo(
                isNameSet, name,
                isExalateUrlSet, exalateUrl,
                isIssueTrackerUrlSet, issueTrackerUrl,
                isNodeTypeSet, nodeType,
                isIssueTrackerVersionSet, issueTrackerVersion,
                true, nodeVersionStr,
                isMinHubObjectsVersionSet, minHubObjectsVersion,
                isMaxHubObjectsVersionSet, maxHubObjectsVersion,
                isMinRestVersionSet, minRestVersion,
                isMaxRestVersionSet, maxRestVersion,
                isPollOnlySet, pollOnly,
                isExaCompVersionSet, exaCompVersion,
                isInstanceUidSet, instanceUid,
                isEditorValueSet, editorValue,
                isIconUrlSet, iconUrl,
                isBasicConnectionValueSet, basicConnectionValue
        );
    }

    @Nonnull
    @Override
    public BasicNodeInfo setMinHubObjectsVersion(@Nonnull ISemanticVersion hubObjectsVersion) {
        String hubObjVersionStr = hubObjectsVersion.toString();
        return new BasicNodeInfo(
                isNameSet, name,
                isExalateUrlSet, exalateUrl,
                isIssueTrackerUrlSet, issueTrackerUrl,
                isNodeTypeSet, nodeType,
                isIssueTrackerVersionSet, issueTrackerVersion,
                isNodeVersionSet, nodeVersion,
                true, hubObjVersionStr,
                isMaxHubObjectsVersionSet, maxHubObjectsVersion,
                isMinRestVersionSet, minRestVersion,
                isMaxRestVersionSet, maxRestVersion,
                isPollOnlySet, pollOnly,
                isExaCompVersionSet, exaCompVersion,
                isInstanceUidSet, instanceUid,
                isEditorValueSet, editorValue,
                isIconUrlSet, iconUrl,
                isBasicConnectionValueSet, basicConnectionValue
        );
    }

    @Nonnull
    @Override
    public BasicNodeInfo setMaxHubObjectsVersion(@Nonnull ISemanticVersion hubObjectsVersion) {
        String hubObjectsVersionStr = hubObjectsVersion.toString();
        return new BasicNodeInfo(
                isNameSet, name,
                isExalateUrlSet, exalateUrl,
                isIssueTrackerUrlSet, issueTrackerUrl,
                isNodeTypeSet, nodeType,
                isIssueTrackerVersionSet, issueTrackerVersion,
                isNodeVersionSet, nodeVersion,
                isMinHubObjectsVersionSet, minHubObjectsVersion,
                true, hubObjectsVersionStr,
                isMinRestVersionSet, minRestVersion,
                isMaxRestVersionSet, maxRestVersion,
                isPollOnlySet, pollOnly,
                isExaCompVersionSet, exaCompVersion,
                isInstanceUidSet, instanceUid,
                isEditorValueSet, editorValue,
                isIconUrlSet, iconUrl,
                isBasicConnectionValueSet, basicConnectionValue
        );
    }

    @Nonnull
    @Override
    public BasicNodeInfo setMinRestVersion(@Nonnull ISemanticVersion minRestVersion) {
        String minRestVersionStr = minRestVersion.toString();
        return new BasicNodeInfo(
                isNameSet, name,
                isExalateUrlSet, exalateUrl,
                isIssueTrackerUrlSet, issueTrackerUrl,
                isNodeTypeSet, nodeType,
                isIssueTrackerVersionSet, issueTrackerVersion,
                isNodeVersionSet, nodeVersion,
                isMinHubObjectsVersionSet, minHubObjectsVersion,
                isMaxHubObjectsVersionSet, maxHubObjectsVersion,
                true, minRestVersionStr,
                isMaxRestVersionSet, maxRestVersion,
                isPollOnlySet, pollOnly,
                isExaCompVersionSet, exaCompVersion,
                isInstanceUidSet, instanceUid,
                isEditorValueSet, editorValue,
                isIconUrlSet, iconUrl,
                isBasicConnectionValueSet, basicConnectionValue
        );
    }


    @Nonnull
    @Override
    public BasicNodeInfo setMaxRestVersion(@Nonnull ISemanticVersion restVersion) {
        String restVersionStr = restVersion.toString();
        return new BasicNodeInfo(
                isNameSet, name,
                isExalateUrlSet, exalateUrl,
                isIssueTrackerUrlSet, issueTrackerUrl,
                isNodeTypeSet, nodeType,
                isIssueTrackerVersionSet, issueTrackerVersion,
                isNodeVersionSet, nodeVersion,
                isMinHubObjectsVersionSet, minHubObjectsVersion,
                isMaxHubObjectsVersionSet, maxHubObjectsVersion,
                isMinRestVersionSet, minRestVersion,
                true, restVersionStr,
                isPollOnlySet, pollOnly,
                isExaCompVersionSet, exaCompVersion,
                isInstanceUidSet, instanceUid,
                isEditorValueSet, editorValue,
                isIconUrlSet, iconUrl,
                isBasicConnectionValueSet, basicConnectionValue
        );
    }

    @Nonnull
    @Override
    public BasicNodeInfo setPollOnly(boolean pollOnly) {
        return new BasicNodeInfo(
                isNameSet, name,
                isExalateUrlSet, exalateUrl,
                isIssueTrackerUrlSet, issueTrackerUrl,
                isNodeTypeSet, nodeType,
                isIssueTrackerVersionSet, issueTrackerVersion,
                isNodeVersionSet, nodeVersion,
                isMinHubObjectsVersionSet, minHubObjectsVersion,
                isMaxHubObjectsVersionSet, maxHubObjectsVersion,
                isMinRestVersionSet, minRestVersion,
                isMaxRestVersionSet, maxRestVersion,
                true, pollOnly,
                isExaCompVersionSet, exaCompVersion,
                isInstanceUidSet, instanceUid,
                isEditorValueSet, editorValue,
                isIconUrlSet, iconUrl,
                isBasicConnectionValueSet, basicConnectionValue
        );
    }

    @Nonnull
    @Override
    public BasicNodeInfo setExaCompVersion(@Nonnull String exaCompVersion) {
        return new BasicNodeInfo(
                isNameSet, name,
                isExalateUrlSet, exalateUrl,
                isIssueTrackerUrlSet, issueTrackerUrl,
                isNodeTypeSet, nodeType,
                isIssueTrackerVersionSet, issueTrackerVersion,
                isNodeVersionSet, nodeVersion,
                isMinHubObjectsVersionSet, minHubObjectsVersion,
                isMaxHubObjectsVersionSet, maxHubObjectsVersion,
                isMinRestVersionSet, minRestVersion,
                isMaxRestVersionSet, maxRestVersion,
                isPollOnlySet, pollOnly,
                true, exaCompVersion,
                isInstanceUidSet, instanceUid,
                isEditorValueSet, editorValue,
                isIconUrlSet, iconUrl,
                isBasicConnectionValueSet, basicConnectionValue
        );
    }

    @Nonnull
    @Override
    public BasicNodeInfo setInstanceUid(@Nonnull String instanceUid) {
        return new BasicNodeInfo(
                isNameSet, name,
                isExalateUrlSet, exalateUrl,
                isIssueTrackerUrlSet, issueTrackerUrl,
                isNodeTypeSet, nodeType,
                isIssueTrackerVersionSet, issueTrackerVersion,
                isNodeVersionSet, nodeVersion,
                isMinHubObjectsVersionSet, minHubObjectsVersion,
                isMaxHubObjectsVersionSet, maxHubObjectsVersion,
                isMinRestVersionSet, minRestVersion,
                isMaxRestVersionSet, maxRestVersion,
                isPollOnlySet, pollOnly,
                isExaCompVersionSet, exaCompVersion,
                true, instanceUid,
                isEditorValueSet, editorValue,
                isIconUrlSet, iconUrl,
                isBasicConnectionValueSet, basicConnectionValue
        );
    }

    @Nonnull
    @Override
    public BasicNodeInfo setEditorValue(@Nonnull String editorValue) {
        return new BasicNodeInfo(
                isNameSet, name,
                isExalateUrlSet, exalateUrl,
                isIssueTrackerUrlSet, issueTrackerUrl,
                isNodeTypeSet, nodeType,
                isIssueTrackerVersionSet, issueTrackerVersion,
                isNodeVersionSet, nodeVersion,
                isMinHubObjectsVersionSet, minHubObjectsVersion,
                isMaxHubObjectsVersionSet, maxHubObjectsVersion,
                isMinRestVersionSet, minRestVersion,
                isMaxRestVersionSet, maxRestVersion,
                isPollOnlySet, pollOnly,
                isExaCompVersionSet, exaCompVersion,
                isInstanceUidSet, instanceUid,
                true, editorValue,
                isIconUrlSet, iconUrl,
                isBasicConnectionValueSet, basicConnectionValue
        );
    }


    @Nonnull
    @Override
    public BasicNodeInfo setBasicConnectionValue(String basicConnectionValue) {
        return new BasicNodeInfo(
                isNameSet, name,
                isExalateUrlSet, exalateUrl,
                isIssueTrackerUrlSet, issueTrackerUrl,
                isNodeTypeSet, nodeType,
                isIssueTrackerVersionSet, issueTrackerVersion,
                isNodeVersionSet, nodeVersion,
                isMinHubObjectsVersionSet, minHubObjectsVersion,
                isMaxHubObjectsVersionSet, maxHubObjectsVersion,
                isMinRestVersionSet, minRestVersion,
                isMaxRestVersionSet, maxRestVersion,
                isPollOnlySet, pollOnly,
                isExaCompVersionSet, exaCompVersion,
                isInstanceUidSet, instanceUid,
                isEditorValueSet, editorValue,
                isIconUrlSet, iconUrl,
                true, basicConnectionValue
        );
    }

    @Nonnull
    @Override
    public BasicNodeInfo setIconUrl(@Nonnull String iconUrl) {
        return new BasicNodeInfo(
                isNameSet, name,
                isExalateUrlSet, exalateUrl,
                isIssueTrackerUrlSet, issueTrackerUrl,
                isNodeTypeSet, nodeType,
                isIssueTrackerVersionSet, issueTrackerVersion,
                isNodeVersionSet, nodeVersion,
                isMinHubObjectsVersionSet, minHubObjectsVersion,
                isMaxHubObjectsVersionSet, maxHubObjectsVersion,
                isMinRestVersionSet, minRestVersion,
                isMaxRestVersionSet, maxRestVersion,
                isPollOnlySet, pollOnly,
                isExaCompVersionSet, exaCompVersion,
                isInstanceUidSet, instanceUid,
                true, editorValue,
                true, iconUrl,
                isBasicConnectionValueSet, basicConnectionValue
        );
    }

    @Nullable
    public static BasicNodeInfo nodeInfoOrNull(@Nullable INodeInfo nodeInfo) {
        if (nodeInfo == null) {
            return null;
        }
        return getBasicNodeInfo(nodeInfo);
    }

    @Nonnull
    private static BasicNodeInfo getBasicNodeInfo(@Nonnull INodeInfo nodeInfo) {
        return new BasicNodeInfo(
                true, nodeInfo.getName(),
                true, nodeInfo.getExalateUrl(),
                true, nodeInfo.getIssueTrackerUrl(),
                true, nodeInfo.getNodeType(),
                true, nodeInfo.getIssueTrackerVersion(),
                true, nodeInfo.getNodeVersion(),
                true, nodeInfo.getMinHubObjectsVersion(),
                true, nodeInfo.getMaxHubObjectsVersion(),
                true, nodeInfo.getMinRestVersion(),
                true, nodeInfo.getMaxRestVersion(),
                true, nodeInfo.isPollOnly(),
                true, nodeInfo.getExaCompVersion(),
                true, nodeInfo.getInstanceUid(),
                true, nodeInfo.getEditorValue(),
                true, nodeInfo.getIconUrl(),
                true, nodeInfo.getBasicConnectionValue()
        );
    }
}
