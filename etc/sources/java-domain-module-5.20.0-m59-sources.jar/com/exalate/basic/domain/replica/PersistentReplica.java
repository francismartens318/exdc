package com.exalate.basic.domain.replica;

import com.exalate.api.domain.IIssueKey;
import com.exalate.api.domain.IPersistentReplica;
import com.exalate.api.domain.ISummary;
import com.exalate.api.domain.ITimestamp;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

public class PersistentReplica implements IPersistentReplica {

    private int id;
    private ITimestamp validOn;
    private IIssueKey issueKey;
    private ISummary summary;
    private String payload;

    public PersistentReplica(final int id, final ITimestamp validOn, final IIssueKey issueKey, final ISummary summary,
                             final String payload) {
        this.id = id;
        this.validOn = validOn;
        this.issueKey = issueKey;
        this.summary = summary;
        this.payload = payload;
    }

    public void setId(final int id) {
        this.id = id;
    }

    public void setValidOn(final ITimestamp validOn) {
        this.validOn = validOn;
    }

    public void setIssueKey(final IIssueKey issueKey) {
        this.issueKey = issueKey;
    }

    public void setSummary(final ISummary summary) {
        this.summary = summary;
    }

    public void setPayload(final String payload) {
        this.payload = payload;
    }

    public int getId() {
        return id;
    }

    @Nonnull
    public ITimestamp getValidOn() {
        return validOn;
    }

    @Nonnull
    public IIssueKey getIssueKey() {
        return issueKey;
    }

    @Nullable
    public ISummary getSummary() {
        return summary;
    }

    @Nonnull
    public String getPayload() {
        return payload;
    }

    @Override
    public String toString() {
        return "PersistentReplica{" +
                "@id=`"+ id +"`" +
                ", @payload=`"+ payload +"`" +
                "}";
    }
}
