package com.exalate.basic.domain.oauth;

import com.exalate.api.domain.oauth.IOAuthData;

import javax.annotation.Nonnull;

public class OAuthData implements IOAuthData {

    private int id;
    private String userKey;
    private String accessToken;
    private Long expiration;
    private String secret;
    private String issuer;
    private String code;
    private String tokenType;

    public OAuthData(int id,
                     @Nonnull String userKey,
                     @Nonnull String accessToken,
                     Long expiration,
                     String secret,
                     String issuer,
                     String code,
                     @Nonnull String tokenType) {
        this.id = id;
        this.userKey = userKey;
        this.accessToken = accessToken;
        this.expiration = expiration;
        this.secret = secret;
        this.issuer = issuer;
        this.code = code;
        this.tokenType = tokenType;
    }

    @Override
    public int getID() {
        return id;
    }

    @Nonnull
    @Override
    public String getUserKey() {
        return userKey;
    }

    @Nonnull
    @Override
    public String getAccessToken() {
        return accessToken;
    }

    @Nonnull
    @Override
    public Long getExpiration() {
        return expiration;
    }

    @Override
    public String getSecret() {
        return secret;
    }

    @Override
    public String getIssuer() {
        return issuer;
    }

    @Override
    public String getCode() {
        return code;
    }

    @Override
    public String getTokenType(){
        return tokenType;
    }
}
