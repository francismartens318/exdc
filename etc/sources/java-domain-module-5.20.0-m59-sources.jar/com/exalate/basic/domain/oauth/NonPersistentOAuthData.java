package com.exalate.basic.domain.oauth;

import com.exalate.api.domain.oauth.INonPersistentOAuthData;

import javax.annotation.Nonnull;

public class NonPersistentOAuthData implements INonPersistentOAuthData {

    private final String userKey;
    private final String accessToken;
    private final Long expiration;
    private final String secret;
    private final String issuer;
    private final String code;
    private final String tokenType;

    public NonPersistentOAuthData(@Nonnull String userKey,
                                  @Nonnull String accessToken,
                                  Long expiration,
                                  String secret,
                                  String issuer,
                                  String code,
                                  @Nonnull String tokenType
                                  ) {
        this.userKey = userKey;
        this.accessToken = accessToken;
        this.expiration = expiration;
        this.secret = secret;
        this.issuer = issuer;
        this.code = code;
        this.tokenType = tokenType;
    }

    @Nonnull
    @Override
    public String getUserKey() {
        return userKey;
    }

    @Nonnull
    @Override
    public String getToken() {
        return accessToken;
    }

    @Nonnull
    @Override
    public Long getExpiration() {
        return expiration;
    }

    @Override
    public String getSecret() {return secret; }

    public String getAccessToken() {
        return accessToken;
    }

    @Override
    public String getIssuer() {
        return issuer;
    }

    @Override
    public String getCode() {
        return code;
    }

    @Override
    public String getTokenType() {
        return tokenType;
    }

}
