package com.exalate.basic.domain;

import com.exalate.api.domain.IPersistentConnectContext;

public class PersistentConnectContext implements IPersistentConnectContext {


    private int id;
    private boolean synchronizeComments;
    private boolean synchronizeAttachments;
    private boolean synchronizeWorklogs;
    private boolean triggerSyncEvent;
    private boolean triggerUpdate;
    private boolean triggerUnexalate;

    public PersistentConnectContext(int id,
                                    boolean synchronizeComments,
                                    boolean synchronizeAttachments,
                                    boolean synchronizeWorklogs,
                                    boolean triggerSyncEvent,
                                    boolean triggerUpdate,
                                    boolean triggerUnexalate) {
        this.id = id;
        this.synchronizeComments = synchronizeComments;
        this.synchronizeAttachments = synchronizeAttachments;
        this.synchronizeWorklogs = synchronizeWorklogs;
        this.triggerSyncEvent = triggerSyncEvent;
        this.triggerUpdate = triggerUpdate;
        this.triggerUnexalate = triggerUnexalate;
    }

    @Override
    public int getId() {
        return id;
    }

    @Override
    public boolean isSynchronizeComments() {
        return synchronizeComments;
    }

    @Override
    public boolean isSynchronizeAttachments() {
        return synchronizeAttachments;
    }

    @Override
    public boolean isSynchronizeWorklogs() {
        return synchronizeWorklogs;
    }

    @Override
    public boolean isTriggerSyncEvent() {
        return triggerSyncEvent;
    }

    public boolean isTriggerUpdate() {
        return triggerUpdate;
    }

    @Override
    public boolean isTriggerUnexalate() {
        return triggerUnexalate;
    }

    @Override
    public String toString() {
        return "PersistentConnectContext{" +
                "@synchronizeComments='" + synchronizeComments + "`" +
                ", @synchronizeAttachments=' " + synchronizeAttachments + "`" +
                ", @synchronizeWorklogs=' " + synchronizeWorklogs + "`" +
                ", @triggerSyncEvent=' " + triggerSyncEvent + "`" +
                ", @triggerUpdate=' " + triggerUpdate + "`" +
                ", @triggerUnexalate=' " + triggerUnexalate + "`" +
                '}';
    }
}
