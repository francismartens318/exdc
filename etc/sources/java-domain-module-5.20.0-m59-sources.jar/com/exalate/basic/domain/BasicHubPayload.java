/*
 * Copyright (C) 2015, iDalko NV
 * All rights reserved.
 *
 *
 * THIS SOURCE CODE IS AN UNPUBLISHED PROPRIETARY TRADE SECRET OF iDalko NV, unless stated otherwise
 * in the license text.
 *
 *
 * The copyright notice above does not evidence any actual or intended publication of such source code.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
 */
package com.exalate.basic.domain;

import com.exalate.api.domain.hubobject.IHubIssueReplica;
import com.exalate.api.domain.hubobject.IHubPayload;
import com.exalate.api.domain.hubobject.ISemanticVersion;
import com.exalate.api.domain.hubobject.IssueSyncMessageKey;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.LinkedHashMap;

import static com.exalate.api.domain.hubobject.IssueSyncMessageKey.HUB_ISSUE;
import static com.exalate.api.domain.hubobject.IssueSyncMessageKey.ISSUE_URL;
import static com.exalate.api.domain.hubobject.IssueSyncMessageKey.VERSION;

public class BasicHubPayload extends LinkedHashMap<String, Object> implements IHubPayload {

    public BasicHubPayload(@Nonnull ISemanticVersion version,
                           @Nonnull IHubIssueReplica hubIssue) {
        this(version, hubIssue, null);
    }

    public BasicHubPayload(
            @Nonnull ISemanticVersion version,
            @Nonnull IHubIssueReplica hubIssue,
            @Nullable String issueUrl) {
        super(3);
        this.put(VERSION.jsonName, version);
        this.put(HUB_ISSUE.jsonName, hubIssue);
        this.put(ISSUE_URL.jsonName, issueUrl);
    }

    @Nonnull
    @Override
    public ISemanticVersion getVersion() {
        return (ISemanticVersion) get(VERSION.jsonName);
    }

    @Nonnull
    @Override
    public IHubIssueReplica getHubIssue() {
        return (IHubIssueReplica) get(HUB_ISSUE.jsonName);
    }

    @Nullable
    @Override
    public String getIssueUrl() {
        return (String) get(ISSUE_URL.jsonName);
    }
}
