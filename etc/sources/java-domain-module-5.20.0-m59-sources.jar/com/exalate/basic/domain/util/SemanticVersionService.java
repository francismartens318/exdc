/*
 * Copyright (C) 2015, iDalko NV
 * All rights reserved.
 *
 *
 * THIS SOURCE CODE IS AN UNPUBLISHED PROPRIETARY TRADE SECRET OF iDalko NV, unless stated otherwise
 * in the license text.
 *
 *
 * The copyright notice above does not evidence any actual or intended publication of such source code.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
 */
package com.exalate.basic.domain.util;

import com.exalate.api.domain.hubobject.ISemanticVersion;
import com.exalate.api.exception.bug.VersionBugException;
import com.exalate.basic.domain.BasicSemanticVersion;
import com.google.common.collect.Lists;
import com.google.common.primitives.Ints;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class SemanticVersionService {

    private static final Logger LOG = org.slf4j.LoggerFactory.getLogger(SemanticVersionService.class);

    @Nonnull
    public static ISemanticVersion get(@Nonnull String version) throws VersionBugException {
        final int[] parts = getVersionNumbers(version);
        switch (parts.length) {
            case 1:
                return create(getMajorVersion(version, parts), 0, 0);
            case 2:
                return create(getMajorVersion(version, parts), getMinorVersion(version, parts), 0);
            case 3:
            default:
                return create(getMajorVersion(version, parts), getMinorVersion(version, parts), getPatchVersion(
                        version, parts));
        }
    }

    @Nonnull
    public static ISemanticVersion create(int major, int minor, int patch) {
        return new BasicSemanticVersion(major, minor, patch);
    }

    /**
     * Gets a maximal feature version supported by local and supported by remote
     * <p></p>
     * Overlap rules:
     * <ol>
     * <li>Lmax &lt; Rmin =&gt; null</li>
     * <li>Lmax &gt; Rmin =&gt; Lmax</li>
     * <li>Rmax &gt; Lmin =&gt; Rmax</li>
     * <li>Rmax &lt; Lmin =&gt; null</li>
     * </ol>
     *
     * @param localMinFeatureVersion  local node minimal feature version
     * @param localMaxFeatureVersion  local node maximal feature version
     * @param remoteMinFeatureVersion remote node minimal feature version
     * @param remoteMaxFeatureVersion remote node maximal feature version
     * @return ISemanticVersion representing the highest overlap version,
     * null - if the major local feature version is less than the remote one
     */
    @Nullable
    public static ISemanticVersion getMaxOverlapVersion(
            @Nonnull ISemanticVersion localMinFeatureVersion,
            @Nonnull ISemanticVersion localMaxFeatureVersion,
            @Nonnull ISemanticVersion remoteMinFeatureVersion,
            @Nonnull ISemanticVersion remoteMaxFeatureVersion) {
        if (localMaxFeatureVersion.getMajor() < remoteMinFeatureVersion.getMajor()) {
            return null;
        }
        if (remoteMaxFeatureVersion.getMajor() < localMinFeatureVersion.getMajor()) {
            return null;
        }
        if (compare(remoteMaxFeatureVersion, localMaxFeatureVersion) == -1) {
            return remoteMaxFeatureVersion;
        }
        return localMaxFeatureVersion;
    }

    public static boolean isLeftOlderThanRight(@Nonnull ISemanticVersion left, @Nonnull ISemanticVersion right) {
        return compare(left, right) < 0;
    }

    public static boolean isLeftEqualOrOlderThanRight(@Nonnull ISemanticVersion left, @Nonnull ISemanticVersion right) {
        return compare(left, right) <= 0;
    }

    public static Integer getMajorVersion(final String versionStr, final int[] versionParts) throws VersionBugException {
        if (versionParts.length < 1) {
            throw new VersionBugException("No major part in version number `" + versionStr + "`.");
        }
        return versionParts[0];
    }

    public static Integer getMinorVersion(final String versionStr, final int[] versionParts) throws VersionBugException {
        if (versionParts.length < 2) {
            throw new VersionBugException("No minor part in version number `" + versionStr + "`.");
        }
        return versionParts[1];
    }

    public static Integer getPatchVersion(final String versionStr, final int[] versionParts) throws VersionBugException {
        if (versionParts.length < 3) {
            throw new VersionBugException("No patch part in version number `" + versionStr + "`.");
        }
        return versionParts[2];
    }

    @Nullable
    private static Integer getVersionPart(String verPartStr) {
        if (!NumberUtils.isNumber(verPartStr)) {
            return null;
        }
        return NumberUtils.createInteger(verPartStr);
    }

    /**
     * @param leftVersion
     * @param rightVersion
     * @return 1 if right version is older than left version
     * -1 if left version is older tan right version
     * 0 if versions are equivalent
     */
    public static int compare(ISemanticVersion leftVersion, ISemanticVersion rightVersion) {
        long result = leftVersion.getMajor() - rightVersion.getMajor();
        if (result == 0) {
            result = leftVersion.getMinor() - rightVersion.getMinor();
            if (result == 0) {
                result = leftVersion.getPatch() - rightVersion.getPatch();
            }
        }

        if (result < 0) {
            return -1;
        } else if (result > 0) {
            return 1;
        }
        return 0;
    }

    @Nonnull
    public static int[] getVersionNumbers(@Nonnull String versionString) {
        List<Integer> ints = Lists.newLinkedList();
        Matcher m = Pattern.compile("([0-9]+)(\\.?)(.*)").matcher("");
        String rest = versionString;

        while (isVersionMatching(m, rest)) {
            String i = m.group(1);
            ints.add(Integer.valueOf(i));
            String dot = m.group(2);
            rest = m.group(3);
            if (!".".equals(dot)) {
                break;
            }
        }

        while (ints.size() < 3) {
            ints.add(Integer.valueOf(0));
        }

        return Ints.toArray(ints);
    }

    private static boolean isVersionMatching(Matcher m, String rest) {
        if (rest == null) return false;
        else try {
            return m.reset(rest).matches();
        } catch (Exception e) {
            LOG.error("failed to parse version `" + rest + "` via version pattern `" + m.pattern() + "`", e);
            return false;
        }
    }

    @Nonnull
    public static String getVersionThreeDigitString(int[] versionNumbers) {
        int[] threeDigitVersionNumbers = new int[]{0, 0, 0};
        for (int versionPartIdx = 0; versionPartIdx < threeDigitVersionNumbers.length; versionPartIdx++) {
            if (versionPartIdx >= versionNumbers.length) {
                break;
            }
            threeDigitVersionNumbers[versionPartIdx] = versionNumbers[versionPartIdx];
        }
        BasicSemanticVersion semanticVersion = new BasicSemanticVersion(
                threeDigitVersionNumbers[0],
                threeDigitVersionNumbers[1],
                threeDigitVersionNumbers[2]
        );
        return semanticVersion.toString();
    }
}
