package com.exalate.basic.domain.util;

import com.exalate.api.domain.hubobject.ILockable;
import com.google.common.base.Function;
import com.google.common.collect.Collections2;
import com.google.common.collect.Lists;

import javax.annotation.Nullable;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class HubObjectLockingUtil {
    public static <H extends ILockable> Set<H> lock(Set<H> lockableSet) {
        return new HashSet<H>(Collections2.transform(lockableSet, new Function<H, H>() {
            @Nullable
            @Override
            public H apply(@Nullable H label) {
                if (label == null) {
                    return null;
                }
                label.lock();
                return label;
            }
        }));
    }
    public static <H extends ILockable> List<H> lock(List<H> lockableList) {
        return Lists.transform(lockableList, new Function<H, H>() {
            @Nullable
            @Override
            public H apply(@Nullable H label) {
                if (label == null) {
                    return null;
                }
                label.lock();
                return label;
            }
        });
    }
}

