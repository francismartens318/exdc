package com.exalate.basic.domain.event;

import com.exalate.api.domain.*;
import com.exalate.api.domain.connection.IConnection;
import com.exalate.api.domain.event.EventStatus;
import com.exalate.api.domain.event.ISyncEvent;
import com.exalate.api.domain.twintrace.ITrace;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.List;

public class SyncEvent implements ISyncEvent {

    private int id;
    private Integer remoteTwinTraceId;
    private Long eventNumber;
    private IConnection connection;
    private IPersistentReplica localReplica;
    private IPersistentReplica remoteReplica;
    private String connectRemoteIssueUrn;
    private IPersistentConnectContext connectContext;
    private String deletedIssueUrn;
    private String unexalateIssueUrn;
    private EventStatus status;
    private List<ITrace> traces;
    private List<IBlobMetadata> blobMetadataList;
    private boolean isPayed;
    private String proxyUser;
    private boolean changingIssue;
    private ErrorReason errorReason;
    private String errorResponseMessage;
    private SyncRequestEventType syncType;
    private Integer twinTraceId;
    private String originator;
    private Integer priority;

    public SyncEvent(final int id, final Long eventNumber, final IConnection connection,
                     final Integer remoteTwinTraceId,
                     final IPersistentReplica localReplica,
                     final IPersistentReplica remoteReplica,
                     final IPersistentConnectContext connectContext,
                     final String connectRemoteIssueUrn,
                     final String deletedIssueUrn,
                     final String unexalateIssueUrn,
                     final EventStatus status,
                     final List<ITrace> traces,
                     final List<IBlobMetadata> blobMetadataList,
                     final boolean isPayed,
                     final ErrorReason errorReason,
                     final String errorResponseMessage,
                     final SyncRequestEventType syncType,
                     final Integer twinTraceId) {
        this.id = id;
        this.eventNumber = eventNumber;
        this.connection = connection;
        this.remoteTwinTraceId = remoteTwinTraceId;
        this.localReplica = localReplica;
        this.remoteReplica = remoteReplica;
        this.connectContext = connectContext;
        this.connectRemoteIssueUrn = connectRemoteIssueUrn;
        this.deletedIssueUrn = deletedIssueUrn;
        this.unexalateIssueUrn = unexalateIssueUrn;
        this.status = status;
        this.traces = traces;
        this.blobMetadataList = blobMetadataList;
        this.isPayed = isPayed;
        this.errorReason = errorReason;
        this.errorResponseMessage = errorResponseMessage;
        this.syncType = syncType;
        //FIXME init the connect context for the sync event
        this.twinTraceId = twinTraceId;
    }

    public void setId(final int id) {
        this.id = id;
    }

    public void setEventNumber(final Long eventNumber) {
        this.eventNumber = eventNumber;
    }

    public void setConnection(final IConnection connection) {
        this.connection = connection;
    }

    public void setLocalReplica(final IPersistentReplica localReplica) {
        this.localReplica = localReplica;
    }

    public void setConnectRemoteIssueUrn(final String connectRemoteIssueUrn) {
        this.connectRemoteIssueUrn = connectRemoteIssueUrn;
    }

    public void setDeletedIssueUrn(final String deletedIssueUrn) {
        this.deletedIssueUrn = deletedIssueUrn;
    }

    public void setUnexalateIssueUrn(final String unexalateIssueUrn) {
        this.unexalateIssueUrn = unexalateIssueUrn;
    }

    public int getId() {
        return id;
    }

    @Nonnull
    public Long getEventNumber() {
        return eventNumber;
    }

    @Nonnull
    public IConnection getConnection() {
        return connection;
    }

    @Nonnull
    public IPersistentReplica getLocalReplica() {
        return localReplica;
    }

    @Nullable
    public String getConnectRemoteIssueUrn() {
        return connectRemoteIssueUrn;
    }

    @Override
    public IPersistentConnectContext getConnectContext() {
        return connectContext;
    }

    @Nullable
    public String getDeletedIssueUrn() {
        return deletedIssueUrn;
    }

    @Nullable
    public String getUnexalateIssueUrn() {
        return unexalateIssueUrn;
    }

    @Nullable
    public IPersistentReplica getRemoteReplica() {
        return remoteReplica;
    }

    public void setRemoteReplica(@Nullable final IPersistentReplica remoteReplica) {
        this.remoteReplica = remoteReplica;
    }

    @Nonnull
    public EventStatus getStatus() {
        return status;
    }

    public void setStatus(@Nonnull final EventStatus status) {
        this.status = status;
    }

    public boolean canBeProcessed() {
        EventStatus status = getStatus();
        return EventStatus.WAITING_FOR_RESPONSE != status &&
                EventStatus.PROCESSED != status &&
                EventStatus.WAITING_REQUEST_RECEIVED != status;
    }

    @Nonnull
    public List<IBlobMetadata> getBlobMetadataList() {
        return this.blobMetadataList;
    }

    @Nonnull
    public List<ITrace> getTraces() {
        return traces;
    }

    @Override
    public boolean isPayed() {
        return isPayed;
    }

    @Override
    public void setPayed(boolean payed) {
        isPayed = payed;
    }

    @Override
    public String toString() {
        return "SyncEvent{" +
                "@id=`" + localReplica.getId() + "`" +
                ", @localIssueKey=`" + localReplica.getIssueKey().getURN() + "`" +
                ", @connection=`" + getConnection().getName() + "`" +
                ", @status=`" + getStatus() + "`" +
                '}';
    }

    @Nullable
    @Override
    public Integer getRemoteTwinTraceId() {
        return remoteTwinTraceId;
    }

    @Override
    public void setRemoteTwinTraceId(@Nullable Integer remoteTwinTraceId) {
        this.remoteTwinTraceId = remoteTwinTraceId;
    }

    @Override
    public String getProxyUser() {
        return proxyUser;
    }

    @Override
    public void setProxyUser(String proxyUser) {
        this.proxyUser = proxyUser;
    }

    @Override
    public boolean isChangingIssue() {
        return changingIssue;
    }

    @Override
    public void setChangingIssue(boolean changingIssue) {
        this.changingIssue = changingIssue;
    }

    @Nullable
    @Override
    public ErrorReason getErrorReason() {
        return this.errorReason;
    }

    @Override
    public void setErrorReason(ErrorReason errorReason) {
        this.errorReason = errorReason;
    }

    @Nullable
    @Override
    public String getErrorResponseMessage() {
        return this.errorResponseMessage;
    }

    @Override
    public void setErrorResponseMessage(String errorResponseMessage) {
        this.errorResponseMessage = errorResponseMessage;
    }

    @Override
    public SyncRequestEventType getSyncType() {
        return syncType;
    }

    public void setSyncType(SyncRequestEventType type) {
        this.syncType = type;
    }

    @Override
    public Integer getTwinTraceId() {
        return twinTraceId;
    }

    public void setTwinTraceId(Integer twinTraceId) {
        this.twinTraceId = twinTraceId;
    }

    @Override
    public String getOriginator() {
        return originator;
    }

    @Override
    public void setOriginator(String originator) {
        this.originator = originator;
    }

    @Override
    public Integer getPriority() {
        return priority;
    }

    @Override
    public void setPriority(Integer priority) {
        this.priority = priority;
    }

    @Override
    public boolean canProcessSyncResponse() {
        return status == EventStatus.WAITING_FOR_RESPONSE || status == EventStatus.SEND_REQUEST || status == EventStatus.WAITING_REQUEST_RECEIVED;

    }

}
