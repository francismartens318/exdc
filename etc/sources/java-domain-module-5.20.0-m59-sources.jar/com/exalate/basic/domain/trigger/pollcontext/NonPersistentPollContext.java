package com.exalate.basic.domain.trigger.pollcontext;

import com.exalate.api.domain.trigger.pollcontext.INonPersistentPollContext;

import javax.annotation.Nullable;

public class NonPersistentPollContext implements INonPersistentPollContext {
    private final Long lastPollTime;
    private final long pairPollOffset;
    private final int pairPollLimit;
    private final Long pairPollTotalResults;
    private final int relationId;

    public NonPersistentPollContext(Long lastPollTime, long pairPollOffset, int pairPollLimit, Long pairPollTotalResults, int relationId) {
        this.lastPollTime = lastPollTime;
        this.pairPollOffset = pairPollOffset;
        this.pairPollLimit = pairPollLimit;
        this.pairPollTotalResults = pairPollTotalResults;
        this.relationId = relationId;
    }

    @Nullable
    @Override
    public Long getLastPollTime() {
        return lastPollTime;
    }

    @Override
    public long getPairPollOffset() {
        return pairPollOffset;
    }

    @Override
    public int getPairPollLimit() {
        return pairPollLimit;
    }

    @Nullable
    @Override
    public Long getPairPollTotalResults() {
        return pairPollTotalResults;
    }

    @Override
    public int getRelationId() {
        return relationId;
    }
}
