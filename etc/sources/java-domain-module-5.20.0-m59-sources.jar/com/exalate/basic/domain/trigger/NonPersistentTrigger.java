package com.exalate.basic.domain.trigger;

import com.exalate.api.domain.connection.IConnection;
import com.exalate.api.domain.trigger.INonPersistentTrigger;
import com.exalate.api.domain.trigger.TriggerStatus;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.Map;
import java.util.Objects;

public class NonPersistentTrigger implements INonPersistentTrigger {

    private String jqlFilter, entityType;
    private IConnection relation;
    private String notes;
    private TriggerStatus status;
    private String projectWhiteList;
    private Map<String, Object> fieldValues;

    public NonPersistentTrigger(
            String jqlFilter,
            String entityType,
            IConnection relation,
            String notes,
            TriggerStatus status,
            Map<String, Object> fieldValues) {
        this.jqlFilter = jqlFilter;
        this.entityType = entityType;
        this.relation = relation;
        this.notes = notes;
        this.status = status;
        this.fieldValues = fieldValues;
    }

    @Nonnull
    @Override
    public String getJqlFilter() {
        return jqlFilter;
    }

    @Override
    public void setJqlFilter(@Nonnull String jqlFilter) {
        this.jqlFilter = jqlFilter;
    }

    @Nonnull
    @Override
    public String getEntityType() {
        return entityType;
    }

    @Override
    public void setEntityType(@Nonnull String entityType) {
        this.entityType = entityType;
    }

    @Nonnull
    @Override
    public IConnection getConnection() {
        return relation;
    }

    @Override
    public void setConnection(@Nonnull IConnection relation) {
        this.relation = relation;
    }

    @Nullable
    @Override
    public String getNotes() {
        return notes;
    }

    @Override
    public void setNotes(@Nullable String notes) {
        this.notes = notes;
    }

    @Nonnull
    @Override
    public TriggerStatus getStatus() {
        return status;
    }

    @Override
    public void setStatus(@Nonnull TriggerStatus status) {
        this.status = status;
    }

    @Override
    public String getProjectWhiteList() {
        return projectWhiteList;
    }

    @Override
    public void setProjectWhiteList(String projectWhiteList) {
        this.projectWhiteList = projectWhiteList;
    }

    @Override
    public Map<String, Object> getFieldValues() {
        return this.fieldValues;
    }

    @Override
    public void setFieldValues(Map<String, Object> fieldValues) {
        this.fieldValues = fieldValues;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        NonPersistentTrigger that = (NonPersistentTrigger) o;
        if (!jqlFilter.equals(that.jqlFilter)) return false;
        if (!relation.equals(that.relation)) return false;
        if (notes != null ? !notes.equals(that.notes) : that.notes != null) return false;
        if (!Objects.equals(fieldValues, that.fieldValues)) return false;
        return status == that.status;
    }

    @Override
    public int hashCode() {
        int result = jqlFilter.hashCode();
        result = 31 * result + relation.hashCode();
        result = 31 * result + (notes != null ? notes.hashCode() : 0);
        result = 31 * result + status.hashCode();
        result = 31 * result + fieldValues.hashCode();
        return result;
    }

    @Override
    public String toString() {
        return "NonPersistentTrigger{" +
                "jqlFilter='" + jqlFilter + '\'' +
                ", relation=" + relation +
                ", notes='" + notes + '\'' +
                ", fieldValues='" + fieldValues + '\'' +
                ", status=" + status +
                '}';
    }
}
