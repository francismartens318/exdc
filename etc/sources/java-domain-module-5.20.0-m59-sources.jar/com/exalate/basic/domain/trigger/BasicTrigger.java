package com.exalate.basic.domain.trigger;

import com.exalate.api.domain.connection.IConnection;
import com.exalate.api.domain.trigger.ITrigger;
import com.exalate.api.domain.trigger.TriggerStatus;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.Map;
import java.util.Objects;

public class BasicTrigger implements ITrigger {

    private int id;
    private String jqlFilter, entityType;
    private IConnection relation;
    private String notes;
    private TriggerStatus status;
    private String projectWhiteList;
    private Map<String, Object> fieldValues;

    public BasicTrigger(
            final int id,
            final String jqlFilter,
            final String entityType,
            final IConnection relation,
            final String notes,
            final TriggerStatus status,
            final String projectWhiteList,
            Map<String, Object> fieldValues) {
        this.id = id;
        this.jqlFilter = jqlFilter;
        this.entityType = entityType;
        this.relation = relation;
        this.notes = notes;
        this.status = status;
        this.projectWhiteList = projectWhiteList;
        this.fieldValues = fieldValues;
    }

    @Override
    public int getId() {
        return id;
    }

    @Nonnull
    @Override
    public String getJqlFilter() {
        return jqlFilter;
    }

    @Override
    public String getEntityType() {
        return this.entityType;
    }

    @Nonnull
    @Override
    public IConnection getConnection() {
        return relation;
    }

    @Nullable
    @Override
    public String getNotes() {
        return notes;
    }

    @Nonnull
    @Override
    public TriggerStatus getStatus() {
        return status;
    }

    @Override
    public String getProjectWhiteList() {
        return projectWhiteList;
    }

    @Override
    public Map<String, Object> getFieldValues() {
        return this.fieldValues;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        BasicTrigger that = (BasicTrigger) o;
        if (id != that.id) return false;
        if (!jqlFilter.equals(that.jqlFilter)) return false;
        if (!relation.equals(that.relation)) return false;
        if (notes != null ? !notes.equals(that.notes) : that.notes != null) return false;
        if (!Objects.equals(fieldValues, that.fieldValues)) return false;
        return status == that.status;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + jqlFilter.hashCode();
        result = 31 * result + relation.hashCode();
        result = 31 * result + (notes != null ? notes.hashCode() : 0);
        result = 31 * result + status.hashCode();
        result = 31 * result + fieldValues.hashCode();
        return result;
    }

    @Override
    public String toString() {
        return "BasicTrigger{" +
                "id=" + id +
                ", jqlFilter='" + jqlFilter + '\'' +
                ", relation=" + relation +
                ", notes='" + notes + '\'' +
                ", fieldValues='" + fieldValues + '\'' +
                ", status=" + status +
                '}';
    }
}
