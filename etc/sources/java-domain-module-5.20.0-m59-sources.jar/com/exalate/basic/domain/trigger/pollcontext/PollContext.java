package com.exalate.basic.domain.trigger.pollcontext;

import com.exalate.api.domain.trigger.pollcontext.IPollContext;

import javax.annotation.Nullable;

public class PollContext implements IPollContext {
    private final int id;
    private final String lastPollTime;
    private final long pairPollOffset;
    private final int pairPollLimit;
    private final Long pairPollTotalResults;
    private final long syncPollOffset;
    private final int syncPollLimit;
    private final Long syncPollTotalResults;
    private final int relationId;

    private final int errorsSinceLastSuccess;

    public PollContext(int id,
                       String lastPollTime,
                       long pairPollOffset,
                       int pairPollLimit,
                       Long pairPollTotalResults,
                       long syncPollOffset,
                       int syncPollLimit,
                       Long syncPollTotalResults,
                       int relationId,
                       int errorsSinceLastSuccess) {
        this.id = id;
        this.lastPollTime = lastPollTime;
        this.pairPollOffset = pairPollOffset;
        this.pairPollLimit = pairPollLimit;
        this.pairPollTotalResults = pairPollTotalResults;
        this.syncPollOffset = syncPollOffset;
        this.syncPollLimit = syncPollLimit;
        this.syncPollTotalResults = syncPollTotalResults;
        this.relationId = relationId;
        this.errorsSinceLastSuccess = errorsSinceLastSuccess;
    }

    @Override
    public int getId() {
        return id;
    }

    @Nullable
    @Override
    public String getLastPollTime() {
        return lastPollTime;
    }

    @Override
    public long getPairPollOffset() {
        return pairPollOffset;
    }

    @Override
    public int getPairPollLimit() {
        return pairPollLimit;
    }

    @Nullable
    @Override
    public Long getPairPollTotalResults() {
        return pairPollTotalResults;
    }

    @Override
    public long getSyncPollOffset() {
        return syncPollOffset;
    }

    @Override
    public int getSyncPollLimit() {
        return syncPollLimit;
    }

    @Nullable
    @Override
    public Long getSyncPollTotalResults() {
        return syncPollTotalResults;
    }

    @Override
    public int getRelationId() {
        return relationId;
    }

    @Override
    public int getErrorsSinceLastSuccess() {
        return errorsSinceLastSuccess;
    }
}
