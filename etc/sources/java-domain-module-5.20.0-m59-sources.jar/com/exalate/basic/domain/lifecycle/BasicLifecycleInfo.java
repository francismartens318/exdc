package com.exalate.basic.domain.lifecycle;

import com.exalate.api.domain.lifecycle.ILifecycleInfo;
import com.exalate.api.domain.lifecycle.MigrationStatus;

import javax.annotation.Nullable;
import java.util.Date;

public class BasicLifecycleInfo implements ILifecycleInfo {

    private boolean eulaAccepted;
    private Date registrationDate;

    public BasicLifecycleInfo(boolean eulaAccepted, Date registrationDate) {
        this.eulaAccepted = eulaAccepted;
        this.registrationDate = registrationDate;
    }

    @Nullable
    @Override
    public MigrationStatus getMigrationStatus() {
        return MigrationStatus.DONE;
    }

    @Override
    public boolean isEulaAccepted() {
        return eulaAccepted;
    }

    @Override
    public Date getRegistrationDate() {
        return registrationDate;
    }
}
