package com.exalate.basic.domain.auditlog;

import com.exalate.api.domain.auditlog.INonPersistentAuditLog;
import com.exalate.api.domain.webhook.WebhookEntityType;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

public class NonPersistentAuditLog implements INonPersistentAuditLog {

    @Nonnull final private String issueId;
    @Nonnull final private String userKey;
    @Nonnull final private WebhookEntityType entityType;
    @Nullable final private String resultEntityId;
    @Nullable final private String resultEntityJson;

    public NonPersistentAuditLog(@Nonnull String issueId,
                    @Nonnull String userKey,
                    @Nonnull WebhookEntityType entityType,
                    @Nullable String resultEntityId,
                    @Nullable String resultEntityJson) {
        this.issueId = issueId;
        this.userKey = userKey;
        this.entityType = entityType;
        this.resultEntityId = resultEntityId;
        this.resultEntityJson = resultEntityJson;
    }

    @Nonnull
    @Override
    public String getIssueId() {
        return issueId;
    }

    @Nonnull
    @Override
    public String getUserKey() {
        return userKey;
    }

    @Nonnull
    @Override
    public WebhookEntityType getEntityType() {
        return entityType;
    }

    @Nullable
    @Override
    public String getResultEntityId() {
        return resultEntityId;
    }

    @Nullable
    @Override
    public String getResultEntityJson() {
        return resultEntityJson;
    }
}
