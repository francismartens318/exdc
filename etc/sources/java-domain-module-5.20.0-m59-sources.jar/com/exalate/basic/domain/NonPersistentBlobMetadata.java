package com.exalate.basic.domain;

import com.exalate.api.domain.INonPersistentBlobMetadata;
import com.exalate.api.domain.event.ISyncEvent;
import com.exalate.api.domain.request.ISyncRequest;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

/**
 * IBlobMetadata implementation that is not managed by active objects.
 * This class can be used to create an IBlobMetadata instance that will be persisted in the database at a later time.
 */
public class NonPersistentBlobMetadata implements INonPersistentBlobMetadata {
    private String blobId;

    private String blobFilePath;
    private String checksum;

    private ISyncEvent syncEvent;
    private ISyncRequest syncRequest;
    /**
     * Should be used only when the blob is saved on a system
     * */

    public NonPersistentBlobMetadata(String blobId, String blobFilePath, String checksum) {
        this.blobId = blobId;
        this.blobFilePath = blobFilePath;
        this.checksum = checksum;
    }
    public NonPersistentBlobMetadata(Long blobId, String blobFilePath, String checksum) {
       this(blobId.toString(), blobFilePath, checksum);
    }

    /**
     * Blob's filepath is set only when the blob is saved on a system
     * */
    public NonPersistentBlobMetadata(String blobId, String checksum) {
        this.blobId = blobId;
        this.checksum = checksum;
    }
    public NonPersistentBlobMetadata(Long blobId, String checksum) {
        this(blobId.toString(), checksum);
    }

    @Override
    public String getBlobId() {
        return blobId;
    }

    @Override
    public void setBlobId(String blobId) {
        this.blobId = blobId;
    }

    @Override
    public String getBlobFilePath() {
        return blobFilePath;
    }

    @Override
    public void setBlobFilePath(String blobPath) {
        this.blobFilePath = blobPath;
    }

    @Override
    public String getChecksum() {
        return this.checksum;
    }

    @Override
    public void setChecksum(String checksum) {
        this.checksum = checksum;
    }

    @Nullable
    @Override
    public ISyncEvent getSyncEvent() {
        return syncEvent;
    }
    @Override
    public void setSyncEvent(@Nonnull ISyncEvent syncEvent) {
        this.syncEvent = syncEvent;
    }

    @Nullable
    @Override
    public ISyncRequest getSyncRequest() {
        return syncRequest;
    }
    @Override
    public void setSyncRequest(@Nonnull ISyncRequest syncRequest) {
        this.syncRequest = syncRequest;
    }
}
