/*
 * Copyright (C) 2015, Exalate NV
 * All rights reserved.
 *
 *
 * THIS SOURCE CODE IS AN UNPUBLISHED PROPRIETARY TRADE SECRET OF iDalko NV, unless stated otherwise
 * in the license text.
 *
 *
 * The copyright notice above does not evidence any actual or intended publication of such source code.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
 */
package com.exalate.basic.domain;

import com.exalate.api.domain.IIssueKey;
import com.exalate.api.domain.INonPersistentReplica;
import com.exalate.api.domain.ISummary;
import com.exalate.api.domain.ITimestamp;
import com.exalate.api.domain.hubobject.IHubPayload;
import com.exalate.basic.domain.BasicSummary;
import com.exalate.basic.domain.BasicTimestamp;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

public class NonPersistentReplica implements INonPersistentReplica {

    private final ITimestamp validOn;
    private final IIssueKey issueKey;
    private final ISummary summary;
    private final IHubPayload payload;
    private final String payloadAsString;

    public NonPersistentReplica(@Nonnull IIssueKey issueKey, @Nullable String summary, @Nonnull IHubPayload payload, @Nonnull String payloadAdString) {
        this.validOn = new BasicTimestamp();
        this.issueKey = issueKey;
        this.summary = new BasicSummary(summary);
        this.payload = payload;
        this.payloadAsString = payloadAdString;
    }

    @Override
    @Nonnull
    public ITimestamp getValidOn() {
        return validOn;
    }

    @Override
    @Nonnull
    public IIssueKey getIssueKey() {
        return issueKey;
    }

    @Override
    @Nullable
    public ISummary getSummary() {
        return summary;
    }

    @Override
    @Nonnull
    public IHubPayload getPayload() {
        return payload;
    }

    @Nonnull
    @Override
    public String getPayloadAsString() {
        return payloadAsString;
    }
}
