/*
 * Copyright (C) 2015, Exalate NV
 * All rights reserved.
 *
 *
 * THIS SOURCE CODE IS AN UNPUBLISHED PROPRIETARY TRADE SECRET OF iDalko NV, unless stated otherwise
 * in the license text.
 *
 *
 * The copyright notice above does not evidence any actual or intended publication of such source code.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
 */
package com.exalate.basic.domain.instance;

import com.exalate.api.domain.instance.IInstanceIssueTrackerSettings;
import com.exalate.api.domain.instance.INonPersistentInstance;
import com.exalate.api.domain.instance.InstanceStatus;
import com.exalate.api.domain.nodeinfo.INonPersistentNodeInfo;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.net.URL;
import java.util.Map;

public class NonPersistentInstance implements INonPersistentInstance {
    private String name;
    private String description;
    private URL url, issueTrackerUrl;
    private InstanceStatus status;
    private INonPersistentNodeInfo nodeInfo;
    private IInstanceIssueTrackerSettings trackerSettings;
    private String customFieldValues;
    private Map<String,String> fieldValues;

    //Authentication context
    private String remoteUsername, remotePassword;
    private boolean authenticationRequired;


    public NonPersistentInstance(String name, String description, URL url, URL issueTrackerUrl,
                                 InstanceStatus status, INonPersistentNodeInfo nodeInfo,
                                 IInstanceIssueTrackerSettings trackerSettings,
                                 String username,
                                 String password,
                                 boolean authenticationRequired,
                                 String customFieldValues,
                                 Map<String,String> fieldValues) {
        this.name = name;
        this.description = description;
        this.url = url;
        this.issueTrackerUrl = issueTrackerUrl;
        this.status = status;
        this.nodeInfo = nodeInfo;
        this.trackerSettings = trackerSettings;
        remoteUsername = username;
        remotePassword = password;
        this.authenticationRequired = authenticationRequired;
        this.customFieldValues = customFieldValues;
        this.fieldValues = fieldValues;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public String getDescription() {
        return description;
    }

    @Override
    public URL getUrl() {
        return url;
    }

    @Nonnull
    @Override
    public InstanceStatus getStatus() {
        return status;
    }

    @Override
    public void setName(@Nonnull String name) {
        this.name = name;
    }

    @Override
    public void setDescription(@Nonnull String description) {
        this.description = description;
    }

    @Override
    public void setUrl(@Nonnull URL url) {
        this.url = url;
    }

    @Nullable
    @Override
    public URL getIssueTrackerUrl() {
        return issueTrackerUrl;
    }

    @Override
    public void setIssueTrackerUrl(@Nullable URL issueTrackerUrl) {
        this.issueTrackerUrl = issueTrackerUrl;
    }

    @Override
    public void setStatus(@Nonnull InstanceStatus status) {
        this.status = status;
    }

    @Nullable
    @Override
    public INonPersistentNodeInfo getNodeInfo() {
        return nodeInfo;
    }

    @Override
    public void setNodeInfo(@Nonnull INonPersistentNodeInfo nodeInfo) {
        this.nodeInfo = nodeInfo;
    }

    @Override
    public IInstanceIssueTrackerSettings getIssueTrackerSettings() {
        return trackerSettings;
    }

    @Override
    public void setIssueTrackerSettings(IInstanceIssueTrackerSettings settings) {
        this.trackerSettings = settings;
    }

    @Override
    public boolean isAuthenticationRequired() {
        return authenticationRequired;
    }

    public void setAuthenticationRequired(boolean authenticationRequired) {
        this.authenticationRequired = authenticationRequired;
    }

    @Override
    public String getRemoteUsername() {
        return remoteUsername;
    }

    @Override
    public void setRemoteUsername(String remoteUsername) {
        this.remoteUsername = remoteUsername;
    }

    @Override
    public String getRemoteUserPassword() {
        return remotePassword;
    }

    @Override
    public void setRemoteUserPassword(String remotePassword) {
        this.remotePassword = remotePassword;
    }

    @Override
    public String getCustomFieldValues(){
        return customFieldValues;
    }

    @Override
    public void setCustomFieldValues(String customFieldValues) {
        this.customFieldValues = customFieldValues;
    }

    @Override
    public Map<String,String> getFieldValues(){
        return fieldValues;
    }

    @Override
    public void setFieldValues(Map<String,String> fieldValues) {
        this.fieldValues = fieldValues;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof NonPersistentInstance)) return false;

        NonPersistentInstance that = (NonPersistentInstance) o;

        if (description != null ? !description.equals(that.description) : that.description != null) return false;
        if (name != null ? !name.equals(that.name) : that.name != null) return false;
        if (nodeInfo != null ? !nodeInfo.equals(that.nodeInfo) : that.nodeInfo != null) return false;
        if (status != that.status) return false;
        if (url != null ? !url.equals(that.url) : that.url != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = name != null ? name.hashCode() : 0;
        result = 31 * result + (description != null ? description.hashCode() : 0);
        result = 31 * result + (url != null ? url.hashCode() : 0);
        result = 31 * result + (status != null ? status.hashCode() : 0);
        result = 31 * result + (nodeInfo != null ? nodeInfo.hashCode() : 0);
        return result;
    }
}
