package com.exalate.basic.domain.instance;

import com.exalate.api.domain.instance.INonPersistentInstanceIssueTrackerSettings;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.net.URL;

public class NonPersistentInstanceIssueTrackerSettings implements INonPersistentInstanceIssueTrackerSettings, INonPersistentInstanceIssueTrackerSettings.Builder {

    private final String issueTrackerType;
    private final String username;
    private final String password;
    private final URL issueTrackerUrl;
    private final Integer pollingFrequency;
    private final String clientKey;
    private final String publicKey;
    private final String oauthClientId;
    private final String sharedSecret;
    private final boolean pollOnly;
    private final boolean showExalateConnect;
    private final boolean showUnexalate;
    private final boolean showDisabledConnections;
    private final String publicUrl;

    public NonPersistentInstanceIssueTrackerSettings(@Nonnull String issueTrackerType) {
        this(issueTrackerType, null, null, null, null, null, null, null, null, false, true, true, false, null);
    }

    public NonPersistentInstanceIssueTrackerSettings(@Nonnull String issueTrackerType,
                                                     @Nullable String username,
                                                     @Nullable String password,
                                                     @Nullable URL issueTrackerUrl,
                                                     @Nullable Integer pollingFrequency,
                                                     @Nullable String clientKey,
                                                     @Nullable String publicKey,
                                                     @Nullable String oauthClientId,
                                                     @Nullable String sharedSecret,
                                                     @Nonnull boolean isPollOnly,
                                                     @Nonnull boolean showExalateConnect,
                                                     @Nonnull boolean showUnexalate,
                                                     @Nonnull boolean showDisabledConnections,
                                                     @Nullable String publicUrl) {
        this.issueTrackerType = issueTrackerType;
        this.username = username;
        this.password = password;
        this.issueTrackerUrl = issueTrackerUrl;
        this.pollingFrequency = pollingFrequency;
        this.clientKey = clientKey;
        this.publicKey = publicKey;
        this.oauthClientId = oauthClientId;
        this.sharedSecret = sharedSecret;
        this.pollOnly = isPollOnly;
        this.showExalateConnect = showExalateConnect;
        this.showUnexalate = showUnexalate;
        this.showDisabledConnections = showDisabledConnections;
        this.publicUrl = publicUrl;
    }

    @Override
    @Nullable
    public String getUsername() {
        return username;
    }

    @Override
    @Nullable
    public String getPassword() {
        return password;
    }

    @Override
    @Nullable
    public URL getIssueTrackerUrl() {
        return issueTrackerUrl;
    }

    @Override
    @Nullable
    public Integer getPollingFrequency() {
        return pollingFrequency;
    }

    @Override
    @Nonnull
    public String getIssueTrackerType() {
        return issueTrackerType;
    }

    @Nullable
    @Override
    public String getClientKey() {
        return clientKey;
    }

    @Nullable
    @Override
    public String getPublicKey() {
        return publicKey;
    }

    @Nullable
    @Override
    public String getOAuthClientId() {
        return oauthClientId;
    }

    @Nullable
    @Override
    public String getSharedSecret() {
        return sharedSecret;
    }

    @Nonnull
    @Override
    public boolean isPollOnly() {
        return pollOnly;
    }

    @Nonnull
    @Override
    public boolean isShowExalateConnect() {
        return showExalateConnect;
    }

    @Nonnull
    @Override
    public boolean isShowUnexalate() {
        return showUnexalate;
    }

    @Nonnull
    @Override
    public boolean isShowDisabledConnections() {
        return showDisabledConnections;
    }

    @Nullable
    @Override
    public String getPublicUrl() {
        return publicUrl;
    }

    @Override
    @Nonnull
    public NonPersistentInstanceIssueTrackerSettings setUsername(String username) {
        return new NonPersistentInstanceIssueTrackerSettings(issueTrackerType, username, password, issueTrackerUrl, pollingFrequency, clientKey, publicKey, oauthClientId, sharedSecret, pollOnly, showExalateConnect, showUnexalate, showDisabledConnections, publicUrl);
    }

    @Override
    @Nonnull
    public NonPersistentInstanceIssueTrackerSettings setPassword(String password) {
        return new NonPersistentInstanceIssueTrackerSettings(issueTrackerType, username, password, issueTrackerUrl, pollingFrequency, clientKey, publicKey, oauthClientId, sharedSecret, pollOnly, showExalateConnect, showUnexalate, showDisabledConnections, publicUrl);
    }

    @Override
    @Nonnull
    public NonPersistentInstanceIssueTrackerSettings setIssueTrackerUrl(URL issueTrackerUrl) {
        return new NonPersistentInstanceIssueTrackerSettings(issueTrackerType, username, password, issueTrackerUrl, pollingFrequency, clientKey, publicKey, oauthClientId, sharedSecret, pollOnly, showExalateConnect, showUnexalate, showDisabledConnections, publicUrl);
    }

    @Override
    @Nonnull
    public NonPersistentInstanceIssueTrackerSettings setPollingFrequency(Integer pollingFrequency) {
        return new NonPersistentInstanceIssueTrackerSettings(issueTrackerType, username, password, issueTrackerUrl, pollingFrequency, clientKey, publicKey, oauthClientId, sharedSecret, pollOnly, showExalateConnect, showUnexalate, showDisabledConnections, publicUrl);
    }

    @Override
    @Nonnull
    public NonPersistentInstanceIssueTrackerSettings setIssueTrackerType(String type) {
        return new NonPersistentInstanceIssueTrackerSettings(type, username, password, issueTrackerUrl, pollingFrequency, clientKey, publicKey, oauthClientId, sharedSecret, pollOnly, showExalateConnect, showUnexalate, showDisabledConnections, publicUrl);
    }

    @Nonnull
    @Override
    public Builder setClientKey(String clientKey) {
        return new NonPersistentInstanceIssueTrackerSettings(issueTrackerType, username, password, issueTrackerUrl, pollingFrequency, clientKey, publicKey, oauthClientId, sharedSecret, pollOnly, showExalateConnect, showUnexalate, showDisabledConnections, publicUrl);
    }

    @Nonnull
    @Override
    public Builder setPublicKey(String publicKey) {
        return new NonPersistentInstanceIssueTrackerSettings(issueTrackerType, username, password, issueTrackerUrl, pollingFrequency, clientKey, publicKey, oauthClientId, sharedSecret, pollOnly, showExalateConnect, showUnexalate, showDisabledConnections, publicUrl);
    }

    @Nonnull
    @Override
    public Builder setOAuthClientId(String oauthClientId) {
        return new NonPersistentInstanceIssueTrackerSettings(issueTrackerType, username, password, issueTrackerUrl, pollingFrequency, clientKey, publicKey, oauthClientId, sharedSecret, pollOnly, showExalateConnect, showUnexalate, showDisabledConnections, publicUrl);
    }

    @Nonnull
    @Override
    public Builder setSharedSecret(String sharedSecret) {
        return new NonPersistentInstanceIssueTrackerSettings(issueTrackerType, username, password, issueTrackerUrl, pollingFrequency, clientKey, publicKey, oauthClientId, sharedSecret, pollOnly, showExalateConnect, showUnexalate, showDisabledConnections, publicUrl);
    }

    @Override
    public Builder setPollOnly(boolean pollOnly) {
        return new NonPersistentInstanceIssueTrackerSettings(issueTrackerType, username, password, issueTrackerUrl, pollingFrequency, clientKey, publicKey, oauthClientId, sharedSecret, pollOnly, showExalateConnect, showUnexalate, showDisabledConnections, publicUrl);
    }

    @Override
    public Builder setShowExalateConnect(boolean showExalateConnect) {
        return new NonPersistentInstanceIssueTrackerSettings(issueTrackerType, username, password, issueTrackerUrl, pollingFrequency, clientKey, publicKey, oauthClientId, sharedSecret, pollOnly, showExalateConnect, showUnexalate, showDisabledConnections, publicUrl);
    }

    @Override
    public Builder setShowUnexalate(boolean showUnexalate) {
        return new NonPersistentInstanceIssueTrackerSettings(issueTrackerType, username, password, issueTrackerUrl, pollingFrequency, clientKey, publicKey, oauthClientId, sharedSecret, pollOnly, showExalateConnect, showUnexalate, showDisabledConnections, publicUrl);
    }

    @Override
    public Builder setShowDisabledConnections(boolean showDisabledConnections) {
        return new NonPersistentInstanceIssueTrackerSettings(issueTrackerType, username, password, issueTrackerUrl, pollingFrequency, clientKey, publicKey, oauthClientId, sharedSecret, pollOnly, showExalateConnect, showUnexalate, showDisabledConnections, publicUrl);
    }

    @Override
    public Builder setPublicUrl(String publicUrl) {
        return new NonPersistentInstanceIssueTrackerSettings(issueTrackerType, username, password, issueTrackerUrl, pollingFrequency, clientKey, publicKey, oauthClientId, sharedSecret, pollOnly, showExalateConnect, showUnexalate, showDisabledConnections, publicUrl);
    }

    @Nonnull
    @Override
    public INonPersistentInstanceIssueTrackerSettings build() {
        return this;
    }
}
