package com.exalate.basic.domain.instance;

import com.exalate.api.domain.instance.IInstance;
import com.exalate.api.domain.instance.IInstanceIssueTrackerSettings;
import com.exalate.api.domain.instance.InstanceStatus;
import com.exalate.api.domain.nodeinfo.INodeInfo;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.net.URL;
import java.util.Map;

public class Instance implements IInstance {

    private int id;
    private String name, description;
    private URL url, issueTrackerUrl;
    private InstanceStatus status;
    private INodeInfo nodeInfo;
    private IInstanceIssueTrackerSettings issueTrackerSettings;
    private String customFieldValues;
    private Map<String, String> fieldValues;

    //Authentication context
    private String remoteUsername, remotePassword;
    private boolean authenticationRequired;

    public Instance(final int id, final String name, final String description, final URL url, final URL issueTrackerUrl,
                    final InstanceStatus status, final INodeInfo nodeInfo,
                    final IInstanceIssueTrackerSettings issueTrackerSettings,
                    final String remoteUsername,
                    final String remotePassword,
                    final boolean authenticationRequired,
                    final String customFieldValues,
                    final Map<String, String> fieldValues) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.url = url;
        this.issueTrackerUrl = issueTrackerUrl;
        this.status = status;
        this.nodeInfo = nodeInfo;
        this.issueTrackerSettings = issueTrackerSettings;
        this.remoteUsername = remoteUsername;
        this.remotePassword = remotePassword;
        this.authenticationRequired = authenticationRequired;
        this.customFieldValues = customFieldValues;
        this.fieldValues = fieldValues;
    }

    public void setStatus(final InstanceStatus status) {
        this.status = status;
    }

    public void setNodeInfo(final INodeInfo nodeInfo) {
        this.nodeInfo = nodeInfo;
    }

    public void setId(final int id) {
        this.id = id;
    }

    public int getID() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(final String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(final String description) {
        this.description = description;
    }

    public URL getUrl() {
        return url;
    }

    public void setUrl(final URL url) {
        this.url = url;
    }

    @Nullable
    @Override
    public URL getIssueTrackerUrl() {
        return issueTrackerUrl;
    }

    @Override
    public void setIssueTrackerUrl(@Nullable URL issueTrackerUrl) {
        this.issueTrackerUrl = issueTrackerUrl;
    }

    @Nonnull
    public InstanceStatus getStatus() {
        return status;
    }

    @Nullable
    public INodeInfo getNodeInfo() {
        return nodeInfo;
    }

    @Override
    public IInstanceIssueTrackerSettings getIssueTrackerSettings() {
        return issueTrackerSettings;
    }

    @Override
    public boolean isAuthenticationRequired() {
        return authenticationRequired;
    }

    @Override
    public String getRemoteUsername() {
        return remoteUsername;
    }

    @Override
    public String getRemoteUserPassword() {
        return remotePassword;
    }

    @Override
    public String getCustomFieldValues() {
        return customFieldValues;
    }

    @Override
    public Map<String, String> getFieldValues() {
        return fieldValues;
    }
}
