package com.exalate.basic.domain.instance;

import com.exalate.api.domain.instance.IInstanceIssueTrackerSettings;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.net.URL;

public class InstanceIssueTrackerSettings implements IInstanceIssueTrackerSettings {

    private int id;
    private String issueTrackerType;
    private String username;
    private String password;
    private URL issueTrackerUrl;
    private Integer pollingFrequency;
    private String clientKey;
    private String publicKey;
    private String oauthClientId;
    private String sharedSecret;
    private boolean pollOnly;
    private boolean showExalateConnect;
    private boolean showUnexalate;
    private boolean showDisabledConnections;
    private String publicUrl;

    public InstanceIssueTrackerSettings(int id,
                                        @Nonnull String issueTrackerType,
                                        @Nullable String username,
                                        @Nullable String password,
                                        @Nullable URL issueTrackerUrl,
                                        @Nullable Integer pollingFrequency,
                                        @Nullable String clientKey,
                                        @Nullable String publicKey,
                                        @Nullable String oauthClientId,
                                        @Nullable String sharedSecret,
                                        @Nonnull boolean isPollOnly,
                                        @Nonnull boolean showExalateConnect,
                                        @Nonnull boolean showUnexalate,
                                        @Nonnull boolean showDisabledConnections,
                                        @Nullable String publicUrl) {
        this.id = id;
        this.issueTrackerType = issueTrackerType;
        this.username = username;
        this.password = password;
        this.issueTrackerUrl = issueTrackerUrl;
        this.pollingFrequency = pollingFrequency;
        this.clientKey = clientKey;
        this.publicKey = publicKey;
        this.oauthClientId = oauthClientId;
        this.sharedSecret = sharedSecret;
        this.pollOnly = isPollOnly;
        this.showExalateConnect = showExalateConnect;
        this.showUnexalate = showUnexalate;
        this.showDisabledConnections = showDisabledConnections;
        this.publicUrl = publicUrl;
    }

    @Override
    public int getID() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public URL getIssueTrackerUrl() {
        return issueTrackerUrl;
    }

    public Integer getPollingFrequency() {
        return pollingFrequency;
    }

    @Nonnull
    public String getIssueTrackerType() {
        return issueTrackerType;
    }

    @Nullable
    @Override
    public String getClientKey() {
        return clientKey;
    }

    @Nullable
    @Override
    public String getPublicKey() {
        return publicKey;
    }

    @Nullable
    @Override
    public String getOAuthClientId() {
        return oauthClientId;
    }

    @Nullable
    @Override
    public String getSharedSecret() {
        return sharedSecret;
    }

    @Nonnull
    @Override
    public boolean isPollOnly() {
        return pollOnly;
    }

    @Nonnull
    @Override
    public boolean isShowExalateConnect() {
        return showExalateConnect;
    }

    @Nonnull
    @Override
    public boolean isShowDisabledConnections() {
        return showDisabledConnections;
    }

    @Nonnull
    @Override
    public boolean isShowUnexalate() {
        return showUnexalate;
    }

    @Nonnull
    @Override
    public String getPublicUrl() {
        return publicUrl;
    }
}
