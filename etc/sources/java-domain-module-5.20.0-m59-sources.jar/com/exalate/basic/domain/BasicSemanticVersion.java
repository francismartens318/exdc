/*
 * Copyright (C) 2015, iDalko NV
 * All rights reserved.
 *
 *
 * THIS SOURCE CODE IS AN UNPUBLISHED PROPRIETARY TRADE SECRET OF iDalko NV, unless stated otherwise
 * in the license text.
 *
 *
 * The copyright notice above does not evidence any actual or intended publication of such source code.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
 */
package com.exalate.basic.domain;

import com.exalate.api.domain.hubobject.ISemanticVersion;

public class BasicSemanticVersion implements ISemanticVersion {

    private final long major;
    private final long minor;
    private final long patch;

    public BasicSemanticVersion(int major, int minor, int patch) {
        this.major = major;
        this.minor = minor;
        this.patch = patch;
    }
    public BasicSemanticVersion(long major, long minor, long patch) {
        this.major = major;
        this.minor = minor;
        this.patch = patch;
    }

    @Override
    public long getMajor() {
        return major;
    }

    @Override
    public long getMinor() {
        return minor;
    }

    @Override
    public long getPatch() {
        return patch;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof BasicSemanticVersion)) return false;

        BasicSemanticVersion that = (BasicSemanticVersion) o;

        if (major != that.major) return false;
        if (minor != that.minor) return false;
        //noinspection RedundantIfStatement
        if (patch != that.patch) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = (int) (major ^ (major >>> 32));
        result = 31 * result + (int) (minor ^ (minor >>> 32));
        result = 31 * result + (int) (patch ^ (patch >>> 32));
        return result;
    }

    @Override
    public String toString() {
        return "" + major + '.' + minor + '.' + patch;
    }
}
