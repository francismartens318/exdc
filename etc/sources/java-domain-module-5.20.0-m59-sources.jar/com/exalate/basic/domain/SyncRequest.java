package com.exalate.basic.domain;

import com.exalate.api.domain.*;
import com.exalate.api.domain.license.ISubscriptionContext;
import com.exalate.api.domain.connection.IConnection;
import com.exalate.api.domain.request.ISyncRequest;
import com.exalate.api.domain.request.RequestStatus;
import com.exalate.api.domain.twintrace.ITrace;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.List;

public class SyncRequest implements ISyncRequest {

    private final int id;
    private final int remoteSyncEventId;
    private final long remoteSyncEventNumber;
    private final Integer remoteTwinTraceId;
    private final String connectIssueUrn, deletedRemoteIssueUrn, unexalateRemoteIssueUrn;
    private final IPersistentConnectContext connectContext;
    private String errorResponseMessage;
    private ErrorReason errorReason;
    private final IPersistentReplica replica;
    private IPersistentReplica updatedReplica;
    private final IConnection relation;
    private IIssueKey createdIssueKey;
    private final IIssueKey syncedTo;
    private final List<IBlobMetadata> blobMetadataList;
    private final List<ITrace> traces;
    private RequestStatus status;
    private final boolean isPayed;
    private final ISubscriptionContext subscriptionContext;
    private final String proxyUser;
    private boolean changingIssue;
    private SyncRequestEventType syncType;
    private Integer priority;

    public SyncRequest(int id,
                       int remoteSyncEventId,
                       long remoteSyncEventNumber,
                       Integer remoteTwinTraceId,
                       String connectIssueUrn,
                       String deletedRemoteIssueUrn,
                       String unexalateRemoteIssueUrn,
                       IPersistentConnectContext connectContext,
                       String errorResponseMessage,
                       ErrorReason errorReason,
                       IPersistentReplica replica,
                       IPersistentReplica updatedReplica,
                       IConnection relation,
                       IIssueKey createdIssueKey,
                       IIssueKey syncedTo, List<IBlobMetadata> blobMetadataList,
                       List<ITrace> traces,
                       RequestStatus status,
                       boolean isPayed,
                       ISubscriptionContext subscriptionContext,
                       SyncRequestEventType syncType) {
        this.id = id;
        this.remoteSyncEventId = remoteSyncEventId;
        this.remoteSyncEventNumber = remoteSyncEventNumber;
        this.remoteTwinTraceId = remoteTwinTraceId;
        this.connectIssueUrn = connectIssueUrn;
        this.deletedRemoteIssueUrn = deletedRemoteIssueUrn;
        this.unexalateRemoteIssueUrn = unexalateRemoteIssueUrn;
        this.connectContext = connectContext;
        this.errorResponseMessage = errorResponseMessage;
        this.errorReason = errorReason;
        this.replica = replica;
        this.updatedReplica = updatedReplica;
        this.relation = relation;
        this.createdIssueKey = createdIssueKey;
        this.syncedTo = syncedTo;
        this.blobMetadataList = blobMetadataList;
        this.traces = traces;
        this.status = status;
        this.isPayed = isPayed;
        this.subscriptionContext = subscriptionContext;
        this.proxyUser = null;
        this.syncType = syncType;
    }


    @Override
    public int getId() {
        return id;
    }

    @Override
    public int getRemoteSyncEventId() {
        return remoteSyncEventId;
    }

    @Override
    public Long getRemoteSyncEventNumber() {
        return remoteSyncEventNumber;
    }

    @Override
    public String getConnectIssueUrn() {
        return connectIssueUrn;
    }

    @Override
    public IPersistentConnectContext getConnectContext() {
        return connectContext;
    }

    @Override
    public String getDeletedRemoteIssueUrn() {
        return deletedRemoteIssueUrn;
    }

    @Override
    public String getUnexalateRemoteIssueUrn() {
        return unexalateRemoteIssueUrn;
    }

    @Override
    public String getErrorResponseMessage() {
        return errorResponseMessage;
    }

    @Override
    public void setErrorResponseMessage(String errorResponseMessage) {
        this.errorResponseMessage = errorResponseMessage;
    }

    @Override
    public IConnection getConnection() {
        return relation;
    }

    @Override
    public IPersistentReplica getReplica() {
        return replica;
    }

    @Nonnull
    @Override
    public List<IBlobMetadata> getBlobMetadataList() {
        return blobMetadataList;
    }

    @Nonnull
    @Override
    public List<ITrace> getTraces() {
        return traces;
    }

    @Override
    public IIssueKey getCreatedIssueKey() {
        return createdIssueKey;
    }

    @Override
    public void setCreatedIssueKey(IIssueKey createdIssueKey) {
        this.createdIssueKey = createdIssueKey;
    }

    @Nullable
    @Override
    public IIssueKey getSyncedTo() {
        return syncedTo;
    }

    @Override
    public IPersistentReplica getUpdatedReplica() {
        return updatedReplica;
    }

    @Override
    public void setUpdatedReplica(IPersistentReplica replica) {
        this.updatedReplica = replica;
    }

    @Override
    public RequestStatus getStatus() {
        return status;
    }

    @Override
    public void setStatus(RequestStatus status) {
        this.status = status;
    }

    @Override
    public ErrorReason getErrorReason() {
        return errorReason;
    }

    @Override
    public void setErrorReason(ErrorReason errorReason) {
        this.errorReason = errorReason;
    }

    @Override
    public boolean isPayed() {
        return isPayed;
    }

    @Override
    public ISubscriptionContext getSubscriptionContext() {
        return subscriptionContext;
    }

    @Override
    public String getProxyUser() {
        return proxyUser;
    }

    @Override
    public boolean isChangingIssue() {
        return changingIssue;
    }

    @Override
    public void setChangingIssue(boolean changingIssue) {
        this.changingIssue = changingIssue;
    }

    @Override
    public Integer getRemoteTwinTraceId() {
        return remoteTwinTraceId;
    }

    @Override
    public SyncRequestEventType getSyncType() {
        return syncType;
    }

    public void setSyncType(SyncRequestEventType syncType) {
        this.syncType = syncType;
    }

    @Override
    public Integer getPriority() {
        return priority;
    }

    @Override
    public void setPriority(Integer priority) {
        this.priority = priority;
    }
}
