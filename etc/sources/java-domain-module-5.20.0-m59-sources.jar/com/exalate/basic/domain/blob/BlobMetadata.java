package com.exalate.basic.domain.blob;

import com.exalate.api.domain.IBlobMetadata;

public class BlobMetadata implements IBlobMetadata {
    private int id;
    private String blobId;
    private String filePath;
    private String checksum;

    public BlobMetadata(int id, String blobId, String filePath, String checksum) {
        this.id = id;
        this.blobId = blobId;
        this.filePath = filePath;
        this.checksum = checksum;
    }


    @Override
    public int getId() {
        return id;
    }


    @Override
    public String getBlobId() {
        return blobId;
    }



    @Override
    public void setBlobId(String blobId) {
        this.blobId = blobId;
    }

    @Override
    public String getBlobFilePath() {
        return filePath;
    }

    @Override
    public void setBlobFilePath(String blobPath) {
        this.filePath = blobPath;
    }

    @Override
    public String getChecksum() {
        return this.checksum;
    }

    @Override
    public void setChecksum(String checksum) {
        this.checksum = checksum;
    }
}
