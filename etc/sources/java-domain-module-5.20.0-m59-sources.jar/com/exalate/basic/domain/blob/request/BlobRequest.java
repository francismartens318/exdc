package com.exalate.basic.domain.blob.request;

import com.exalate.api.domain.IBlobMetadata;
import com.exalate.api.domain.blob.BlobErrorReason;
import com.exalate.api.domain.blob.request.BlobRequestStatus;
import com.exalate.api.domain.blob.request.IBlobRequest;
import com.exalate.api.domain.request.ISyncRequest;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

public class BlobRequest implements IBlobRequest {
    private int id;
    private Integer remoteBlobEventId;
    private BlobRequestStatus status;
    private ISyncRequest syncRequest;
    private IBlobMetadata blobMetadata;
    private String errorResponseMessage;
    private BlobErrorReason blobErrorReason;

    public BlobRequest(int id,
                       Integer remoteBlobEventId,
                       BlobRequestStatus status,
                       ISyncRequest syncRequest,
                       IBlobMetadata blobMetadata,
                       String errorResponseMessage,
                       BlobErrorReason blobErrorReason) {
        this.id = id;
        this.remoteBlobEventId = remoteBlobEventId;
        this.status = status;
        this.syncRequest = syncRequest;
        this.blobMetadata = blobMetadata;
        this.errorResponseMessage = errorResponseMessage;
        this.blobErrorReason = blobErrorReason;
    }

    @Override
    public int getId() {
        return id;
    }

    @Nonnull
    @Override
    public BlobRequestStatus getStatus() {
        return status;
    }

    @Override
    public void setStatus(@Nonnull BlobRequestStatus status) {
        this.status = status;
    }

    @Nonnull
    @Override
    public ISyncRequest getSyncRequest() {
        return syncRequest;
    }

    @Nonnull
    @Override
    public IBlobMetadata getBlobMetadata() {
        return blobMetadata;
    }

    @Nullable
    @Override
    public String getErrorResponseMessage() {
        return errorResponseMessage;
    }

    @Override
    public void setErrorResponseMessage(String errorResponseMessage) {
        this.errorResponseMessage = errorResponseMessage;
    }

    @Override
    public BlobErrorReason getBlobErrorReason() {
        return blobErrorReason;
    }

    @Override
    public void setBlobErrorReason(BlobErrorReason blobErrorReason) {
        this.blobErrorReason = blobErrorReason;
    }

    @Override
    public boolean isFinishedCorrectly() {
        return getErrorResponseMessage() == null && getBlobErrorReason() == null;
    }

    @Override
    @Nullable
    public Integer getRemoteBlobEventId() {
        return remoteBlobEventId;
    }
}
