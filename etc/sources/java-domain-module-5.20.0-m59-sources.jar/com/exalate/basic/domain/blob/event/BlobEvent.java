package com.exalate.basic.domain.blob.event;

import com.exalate.api.domain.IBlobMetadata;
import com.exalate.api.domain.blob.BlobErrorReason;
import com.exalate.api.domain.blob.event.BlobEventStatus;
import com.exalate.api.domain.blob.event.IBlobEvent;
import com.exalate.api.domain.event.ISyncEvent;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

public class BlobEvent implements IBlobEvent {
    private int id;
    private BlobEventStatus status;
    private ISyncEvent syncEvent;
    private IBlobMetadata blobMetadata;
    private BlobErrorReason blobErrorReason;
    private String errorResponseMessage;

    public BlobEvent(int id, BlobEventStatus status, ISyncEvent syncEvent, IBlobMetadata blobMetadata, BlobErrorReason blobErrorReason, String errorResponseMessage) {
        this.id = id;
        this.status = status;
        this.syncEvent = syncEvent;
        this.blobMetadata = blobMetadata;
        this.blobErrorReason = blobErrorReason;
        this.errorResponseMessage = errorResponseMessage;
    }


    @Override
    public int getId() {
        return id;
    }

    @Nonnull
    @Override
    public BlobEventStatus getStatus() {
        return status;
    }

    @Override
    public void setStatus(@Nonnull BlobEventStatus blobEventStatus) {
        this.status = blobEventStatus;
    }

    @Nonnull
    @Override
    public ISyncEvent getSyncEvent() {
        return syncEvent;
    }

    @Nonnull
    @Override
    public IBlobMetadata getBlobMetadata() {
        return blobMetadata;
    }

    @Nullable
    @Override
    public String getErrorResponseMessage() {
        return this.errorResponseMessage;
    }

    @Override
    public void setErrorResponseMessage(String errorResponseMessage) {
        this.errorResponseMessage = errorResponseMessage;
    }

    @Nullable
    @Override
    public BlobErrorReason getBlobErrorReason() {
        return blobErrorReason;
    }

    @Override
    public void setBlobErrorReason(BlobErrorReason blobErrorReason) {
        this.blobErrorReason = blobErrorReason;
    }
}
