package com.exalate.basic.domain;

import com.exalate.api.domain.INonPersistentConnectContext;

public class NonPersistentConnectContext implements INonPersistentConnectContext {

    private boolean synchronizeComments;
    private boolean synchronizeAttachments;
    private boolean synchronizeWorklogs;
    private boolean triggerSyncEvent;
    private boolean triggerUpdate;
    private boolean triggerUnexalate;

    public NonPersistentConnectContext(boolean synchronizeComments, boolean synchronizeAttachments,
                                boolean synchronizeWorklogs, boolean triggerSyncEvent, boolean triggerUpdate, boolean triggerUnexalate) {
        this.synchronizeComments = synchronizeComments;
        this.synchronizeAttachments = synchronizeAttachments;
        this.synchronizeWorklogs = synchronizeWorklogs;
        this.triggerSyncEvent = triggerSyncEvent;
        this.triggerUpdate = triggerUpdate;
        this.triggerUnexalate = triggerUnexalate;
    }

    @Override
    public boolean isSynchronizeComments() {
        return synchronizeComments;
    }

    @Override
    public boolean isSynchronizeAttachments() {
        return synchronizeAttachments;
    }

    @Override
    public boolean isSynchronizeWorklogs() {
        return synchronizeWorklogs;
    }

    @Override
    public boolean isTriggerSyncEvent() {
        return triggerSyncEvent;
    }

    public boolean isTriggerUpdate() {
        return triggerUpdate;
    }

    @Override
    public boolean isTriggerUnexalate() {
        return triggerUnexalate;
    }

    @Override
    public String toString() {
        return "ConnectContext{" +
                "@synchronizeComments='" + synchronizeComments + "`" +
                ", @synchronizeAttachments=' " + synchronizeAttachments + "`" +
                ", @synchronizeWorklogs=' " + synchronizeWorklogs + "`" +
                ", @triggerSyncEvent=' " + triggerSyncEvent + "`" +
                ", @triggerUpdate=' " + triggerUpdate + "`" +
                ", @triggerUnexalate=' " + triggerUnexalate + "`" +
                '}';
    }
}
