package com.exalate.basic.domain.webhook;

import com.exalate.api.domain.webhook.INonPersistentWebhookInfo;
import com.exalate.api.domain.webhook.WebhookEntityType;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

public class NonPersistentWebhookInfo implements INonPersistentWebhookInfo {

    @Nonnull final private String issueId;
    @Nonnull final private String issueUrn;
    @Nonnull final private String userKey;
    @Nonnull final private WebhookEntityType entityType;
    @Nonnull final private String entityId;
    @Nonnull final private String entityJson;

    public NonPersistentWebhookInfo(@Nonnull String issueId,
                                    @Nonnull String issueUrn,
                                    @Nonnull String userKey,
                                    @Nonnull WebhookEntityType entityType,
                                    @Nonnull String entityId,
                                    @Nonnull String entityJson) {
        this.issueId = issueId;
        this.issueUrn = issueUrn;
        this.userKey = userKey;
        this.entityType = entityType;
        this.entityId = entityId;
        this.entityJson = entityJson;
    }

    @Nonnull
    @Override
    public String getIssueId() {
        return issueId;
    }

    @Nonnull
    @Override
    public String getIssueUrn() {
        return issueUrn;
    }

    @Nonnull
    @Override
    public String getUserKey() {
        return userKey;
    }

    @Nonnull
    @Override
    public WebhookEntityType getEntityType() {
        return entityType;
    }

    @Nonnull
    @Override
    public String getEntityId() {
        return entityId;
    }

    @Nonnull
    @Override
    public String getEntityJson() {
        return entityJson;
    }

    @Override
    public String toString() {
        return "NonPersistentWebhookInfo{" +
                "issueId='" + issueId + '\'' +
                ", issueUrn='" + issueUrn + '\'' +
                ", userKey='" + userKey + '\'' +
                ", entityType=" + entityType +
                ", entityId='" + entityId + '\'' +
                ", entityJson='" + entityJson + '\'' +
                '}';
    }
}
