package com.exalate.basic.domain.connection;

import com.exalate.api.domain.connection.*;
import com.exalate.api.domain.connection.fieldvalues.ConnectionMode;
import com.exalate.api.domain.connection.fieldvalues.FieldValues;
import com.exalate.api.domain.instance.IInstance;

import java.util.Map;

public class Connection implements IConnection {

    private int id;
    private String name, description, dataFilter, createProcessor, changeProcessor;
    private ConnectionStatus status;
    private InvitationStatus invitationStatus;
    private IInstance remoteInstance;
    private IConnectionIssueTrackerSettings trackerSettings;

    private SendProtocol sendProtocol;
    private ReceiveProtocol receiveProtocol;
    private String invitationSecret, version, incomingProcessor;

    private Map<String, String> fieldValues;

    //Authentication context
    private String remoteUsername, remotePassword;
    private boolean authenticationRequired;
    private boolean isLocal;

    private boolean isManagedRemotely;

    private String managedBy;

    private String syncRoomId;


    public Connection(final int id,
                      final String name,
                      final String description,
                      final ConnectionStatus status,
                      final InvitationStatus invitationStatus,
                      final IInstance remoteInstance,
                      final String dataFilter,
                      final String createProcessor,
                      final String changeProcessor,
                      final IConnectionIssueTrackerSettings trackerSettings,
                      final String remoteUsername,
                      final String remotePassword,
                      final boolean authenticationRequired,
                      boolean isLocal,
                      final SendProtocol sendProtocol,
                      final ReceiveProtocol receiveProtocol,
                      String invitationSecret,
                      final String incomingProcessor,
                      final String version,
                      Map<String, String> fieldValues) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.status = status;
        this.invitationStatus = invitationStatus;
        this.remoteInstance = remoteInstance;
        this.dataFilter = dataFilter;
        this.createProcessor = createProcessor;
        this.changeProcessor = changeProcessor;
        this.trackerSettings = trackerSettings;
        this.remoteUsername = remoteUsername;
        this.remotePassword = remotePassword;
        this.authenticationRequired = authenticationRequired;
        this.isLocal = isLocal;
        this.sendProtocol = sendProtocol;
        this.receiveProtocol = receiveProtocol;
        this.invitationSecret = invitationSecret;
        this.incomingProcessor = incomingProcessor;
        this.version = version;
        this.fieldValues = fieldValues;
    }

    public Connection(IConnection connection, Boolean hideSecret) {
        this.id = connection.getID();
        this.name = connection.getName();
        this.description = connection.getDescription();
        this.status = connection.getStatus();
        this.invitationStatus = connection.getInvitationStatus();
        this.remoteInstance = connection.getRemoteInstance();
        this.dataFilter = connection.getDataFilter();
        this.createProcessor = connection.getCreateProcessor();
        this.changeProcessor = connection.getChangeProcessor();
        this.trackerSettings = connection.getTrackerSettings();
        this.remoteUsername = connection.getRemoteUsername();
        this.remotePassword = connection.getRemotePassword();
        this.authenticationRequired = connection.isAuthenticationRequired();
        this.isLocal = connection.isLocal();
        this.sendProtocol = connection.getSendProtocol();
        this.receiveProtocol = connection.getReceiveProtocol();
        this.invitationSecret = hideSecret ? "**********" : connection.getInvitationSecret();
        this.incomingProcessor = connection.getIncomingProcessor();
        this.version = connection.getVersion();
        this.fieldValues = connection.getFieldValues();
    }


    public void setId(final int id) {
        this.id = id;
    }

    public int getID() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(final String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(final String description) {
        this.description = description;
    }

    public ConnectionStatus getStatus() {
        return status;
    }

    public void setStatus(final ConnectionStatus status) {
        this.status = status;
    }

    public InvitationStatus getInvitationStatus() {
        return invitationStatus;
    }

    public void setInvitationStatus(InvitationStatus invitationStatus) {
        this.invitationStatus = invitationStatus;
    }

    public IInstance getRemoteInstance() {
        return remoteInstance;
    }

    public void setRemoteInstance(final IInstance remoteInstance) {
        this.remoteInstance = remoteInstance;
    }

    public String getDataFilter() {
        return dataFilter;
    }

    public void setDataFilter(final String filter) {
        this.dataFilter = filter;
    }

    public String getCreateProcessor() {
        return createProcessor;
    }

    public void setCreateProcessor(final String createProcessor) {
        this.createProcessor = createProcessor;
    }

    public String getChangeProcessor() {
        return changeProcessor;
    }

    public void setChangeProcessor(final String processor) {
        this.changeProcessor = processor;
    }

    public IConnectionIssueTrackerSettings getTrackerSettings() {
        return trackerSettings;
    }

    public void setTrackerSettings(IConnectionIssueTrackerSettings trackerSettings) {
        this.trackerSettings = trackerSettings;
    }

    @Override
    public boolean isAuthenticationRequired() {
        return authenticationRequired;
    }

    @Override
    public boolean isLocal() {
        return isLocal;
    }

    @Override
    public void setIsLocal(boolean isLocal) {
        this.isLocal = isLocal;
    }

    @Override
    public SendProtocol getSendProtocol() {
        return sendProtocol;
    }

    @Override
    public ReceiveProtocol getReceiveProtocol() {
        return receiveProtocol;
    }

    @Override
    public String getRemoteUsername() {
        return remoteUsername;
    }

    @Override
    public String getRemotePassword() {
        return remotePassword;
    }

    @Override
    public String getLocalUrl() {
        return fieldValues.get("localUrl");
    }

    @Override
    public String getInvitationSecret() {
        return invitationSecret;
    }

    @Override
    public String getVersion() {
        return this.version;
    }

    @Override
    public String getIncomingProcessor() {
        return incomingProcessor;
    }

    @Override
    public void setIncomingProcessor(final String processor) {
        this.incomingProcessor = processor;
    }

    @Override
    public String getPostExalateProcessor() {
        return null;
    }

    @Override
    public void setPostExalateProcessor(String postExalateProcessor) {
    }

    @Override
    public Map<String, String> getFieldValues() {
        return fieldValues;
    }

    @Override
    public void setFieldValues(Map<String, String> fieldValues) {
        this.fieldValues = fieldValues;
    }

    @Override
    public String getLocalInstanceName() {
        return fieldValues.get(FieldValues.LOCAL_INSTANCE_NAME.toString());
    }

    @Override
    public void setLocalInstanceName(String localInstanceName) {
        fieldValues.put(FieldValues.LOCAL_INSTANCE_NAME.toString(), localInstanceName);
    }

    @Override
    public String getMode() {
        return fieldValues.get(FieldValues.MODE.toString());
    }

    /**
     * We remove mode for SCRIPT connections. All other types of connection have its own mode
     *
     * @param mode
     */
    @Override
    public void setMode(String mode) {
        if (mode == null) {
            fieldValues.remove(FieldValues.MODE.toString());
        } else {
            fieldValues.put(FieldValues.MODE.toString(), mode);
        }
    }

    @Override
    public boolean isVisual() {
        return ConnectionMode.CONFIGURE_BOTH_SIDES.toString().equals(getMode());
    }

    @Override
    public boolean isBasic() {
        return ConnectionMode.BASIC.toString().equals(getMode());
    }

    @Override
    public String getSyncMainFieldInfo() {
        return fieldValues.get(FieldValues.MAIN_FIELD_INFO.toString());
    }

    @Override
    public void setSyncMainFieldInfo(String syncMainFieldInfo) {
        if (syncMainFieldInfo == null) {
            fieldValues.remove(FieldValues.MAIN_FIELD_INFO.toString());
        } else {
            fieldValues.put(FieldValues.MAIN_FIELD_INFO.toString(), syncMainFieldInfo);
        }
    }

    @Override
    public String getUpgradeDate() {
        return fieldValues.get(FieldValues.UPGRADE_DATE.toString());
    }

    @Override
    public void setUpgradeDate(String upgradeDate) {
        fieldValues.put(FieldValues.UPGRADE_DATE.toString(), upgradeDate);
    }

    public IConnection withWipedInvitationSecret() {
        return new Connection(this, true);
    }

    public boolean isManagedRemotely() {
        return isManagedRemotely;
    }

    public void setManagedRemotely(boolean managedRemotely) {
        isManagedRemotely = managedRemotely;
    }

    public String getManagedBy() {
        return managedBy;
    }

    public void setManagedBy(String managedBy) {
        this.managedBy = managedBy;
    }

    public String getSyncRoomId() {
        return syncRoomId;
    }

    public void setSyncRoomId(String syncRoomId) {
        this.syncRoomId = syncRoomId;
    }
}
