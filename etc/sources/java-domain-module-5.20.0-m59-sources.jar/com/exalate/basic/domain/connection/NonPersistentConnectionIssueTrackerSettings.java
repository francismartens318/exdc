package com.exalate.basic.domain.connection;

import com.exalate.api.domain.connection.INonPersistentConnectionIssueTrackerSettings;

import java.util.Map;

public class NonPersistentConnectionIssueTrackerSettings implements INonPersistentConnectionIssueTrackerSettings {

    private String issueTrackerType;
    private Boolean createLinks;
    private Boolean createSyncPanelLink;
    private String issueFilter;
    private String hpqcProject;
    private String hpqcDomain;
    private String issueLinkFieldName;
    private Map<String, String> fieldValues; //used for old connections. That way we may detect if there still should be select list for repo/.. on UI, and for backend - we have a backup, where we check if repo/... is in relation_issue_tracker_settings


    public NonPersistentConnectionIssueTrackerSettings(String issueTrackerType,
                                                       Boolean createLinks,
                                                       Boolean createSyncPanelLink,
                                                       String issueFilter,
                                                       String hpqcProject,
                                                       String hpqcDomain,
                                                       String issueLinkFieldName,
                                                       Map<String, String> fieldValues) {
        this.issueTrackerType = issueTrackerType;
        this.createLinks = createLinks;
        this.createSyncPanelLink = createSyncPanelLink;
        this.issueFilter = issueFilter;
        this.hpqcProject = hpqcProject;
        this.hpqcDomain = hpqcDomain;
        this.issueLinkFieldName = issueLinkFieldName;
        this.fieldValues = fieldValues;
    }

    @Override
    public String getIssueTrackerType() {
        return issueTrackerType;
    }

    @Override
    public void setIssueTrackerType(String issueTrackerType) {
        this.issueTrackerType = issueTrackerType;
    }

    @Override
    public Boolean getCreateLinks() {
        return createLinks;
    }

    @Override
    public void setCreateLinks(final Boolean createLinks) {
        this.createLinks = createLinks;
    }

    @Override
    public Boolean getCreateSyncPanelLink() {
        return createSyncPanelLink;
    }

    @Override
    public void setCreateSyncPanelLink(final Boolean createSyncPanelLink) {
        this.createSyncPanelLink = createSyncPanelLink;
    }

    @Override
    public String getIssueFilter(){ return this.issueFilter; }

    @Override
    public void setIssueFilter(String issueFilter){
        this.issueFilter = issueFilter;
    }

    @Override
    public void setHpqcDomain(String hpqcDomain) {
        this.hpqcDomain = hpqcDomain;
    }

    @Override
    public String getHpqcDomain() {
        return hpqcDomain;
    }

    @Override
    public String getHpqcProject() {
        return hpqcProject;
    }

    @Override
    public void setHpqcProject(String hpqcProject) {
        this.hpqcProject = hpqcProject;
    }

    @Override
    public String getIssueLinkFieldName() {
        return issueLinkFieldName;
    }

    @Override
    public void setIssueLinkFieldName(final String issueLinkFieldName) {
        this.issueLinkFieldName = issueLinkFieldName;
    }

    @Override
    public Map<String, String> getFieldValues() {
        return fieldValues;
    }

    @Override
    public void setFieldValues(Map<String, String> fieldValues) {
        this.fieldValues = fieldValues;
    }
}
