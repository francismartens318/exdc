/*
 * Copyright (C) 2013, iDalko NV
 * All rights reserved.
 *
 * THIS SOURCE CODE IS AN UNPUBLISHED PROPRIETARY TRADE SECRET OF iDalko BVBA, unless stated otherwise
 * in the license text.
 *
 * The copyright notice above does not evidence any actual or intended publication of such source code.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
 */

package com.exalate.basic.domain.connection;

import com.exalate.api.domain.connection.*;
import com.exalate.api.domain.connection.fieldvalues.FieldValues;
import com.exalate.api.domain.instance.INonPersistentInstance;

import java.util.HashMap;
import java.util.Map;

public class NonPersistentConnection implements INonPersistentConnection {

    private String name;
    private String description;
    private String dataFilter, changeProcessor, createProcessor, postExalateProcessor;
    private INonPersistentInstance remoteInstance;
    private ConnectionStatus status;
    private InvitationStatus invitationStatus;
    private IConnectionIssueTrackerSettings trackerSettings;

    private SendProtocol sendProtocol;
    private ReceiveProtocol receiveProtocol;

    private String invitationSecret;

    private String remoteUsername, remotePasswordEncrypted;
    private boolean authenticationRequired, isLocal;

    private String localUrl, version, incomingProcessor;

    private Map<String, String> fieldValues;


    public NonPersistentConnection(String name,
                                   String description,
                                   ConnectionStatus status,
                                   InvitationStatus invitationStatus,
                                   String dataFilter,
                                   String changeProcessor,
                                   String createProcessor,
                                   INonPersistentInstance remoteInstance,
                                   IConnectionIssueTrackerSettings trackerSettings,
                                   String username,
                                   String remotePasswordEncrypted,
                                   boolean authenticationRequired,
                                   boolean isLocal,
                                   SendProtocol sendProtocol,
                                   ReceiveProtocol receiveProtocol,
                                   String localUrl,
                                   String incomingProcessor,
                                   String version,
                                   Map<String, String> fieldValues) {
        this.name = name;
        this.description = description;
        this.status = status;
        this.invitationStatus = invitationStatus;
        this.dataFilter = dataFilter;
        this.changeProcessor = changeProcessor;
        this.createProcessor = createProcessor;
        this.remoteInstance = remoteInstance;
        this.trackerSettings = trackerSettings;
        this.remoteUsername = username;
        this.remotePasswordEncrypted = remotePasswordEncrypted;
        this.authenticationRequired = authenticationRequired;
        this.isLocal = isLocal;
        this.sendProtocol = sendProtocol;
        this.receiveProtocol = receiveProtocol;
        this.localUrl = localUrl;
        this.incomingProcessor = incomingProcessor;
        this.version = version;
        this.fieldValues = fieldValues != null ? new HashMap<String, String>(fieldValues) : new HashMap<String, String>();
        this.fieldValues.put(FieldValues.LOCAL_URL.toString(), localUrl);
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String getDescription() {
        return this.description;
    }

    @Override
    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public ConnectionStatus getStatus() {
        return status;
    }

    @Override
    public void setStatus(ConnectionStatus status) {
        this.status = status;
    }

    public InvitationStatus getInvitationStatus() {
        return invitationStatus;
    }

    public void setInvitationStatus(InvitationStatus invitationStatus) {
        this.invitationStatus = invitationStatus;
    }

    public INonPersistentInstance getRemoteInstance() {
        return remoteInstance;
    }

    public void setRemoteInstance(INonPersistentInstance remoteInstance) {
        this.remoteInstance = remoteInstance;
    }

    @Override
    public String getDataFilter() {
        return this.dataFilter;
    }

    @Override
    public void setDataFilter(String filter) {
        this.dataFilter = filter;
    }

    @Override
    public String getCreateProcessor() {
        return createProcessor;
    }

    @Override
    public void setCreateProcessor(String createProcessor) {
        this.createProcessor = createProcessor;
    }

    @Override
    public String getChangeProcessor() {
        return changeProcessor;
    }

    @Override
    public void setChangeProcessor(String processor) {
        this.changeProcessor = processor;
    }

    @Override
    public IConnectionIssueTrackerSettings getTrackerSettings() {
        return this.trackerSettings;
    }

    @Override
    public void setTrackerSettings(IConnectionIssueTrackerSettings settings) {
        this.trackerSettings = settings;
    }

    @Override
    public boolean isAuthenticationRequired() {
        return authenticationRequired;
    }

    @Override
    public SendProtocol getSendProtocol() {
        return sendProtocol;
    }

    @Override
    public void setSendProtocol(SendProtocol sendProtocol) {
        this.sendProtocol = sendProtocol;
    }

    @Override
    public ReceiveProtocol getReceiveProtocol() {
        return receiveProtocol;
    }

    @Override
    public void setReceiveProtocol(ReceiveProtocol receiveProtocol) {
        this.receiveProtocol = receiveProtocol;
    }

    @Override
    public String getRemoteUsername() {
        return remoteUsername;
    }

    @Override
    public String getRemotePassword() {
        return remotePasswordEncrypted;
    }

    @Override
    public boolean isLocal() {
        return isLocal;
    }

    @Override
    public void setIsLocal(boolean isLocal) {
        this.isLocal = isLocal;
    }

    @Override
    public String getLocalUrl() {
        return localUrl;
    }

    @Override
    public void setLocalUrl(String localUrl) {
        this.localUrl = localUrl;
        if (localUrl != null) {
            fieldValues.put(FieldValues.LOCAL_URL.toString(), localUrl);
        } else {
            fieldValues.remove(FieldValues.LOCAL_URL.toString());
        }
    }

    @Override
    public String getInvitationSecret() {
        return invitationSecret;
    }

    @Override
    public void setInvitationSecret(String invitationSecret) {
        this.invitationSecret = invitationSecret;
    }

    @Override
    public String getPostExalateProcessor() {
        return postExalateProcessor;
    }

    @Override
    public void setPostExalateProcessor(String postExalateProcessor) {
        this.postExalateProcessor = postExalateProcessor;
    }

    @Override
    public String getVersion() {
        return this.version;
    }

    @Override
    public void setVersion(String version) {
        this.version = version;
    }

    @Override
    public String getIncomingProcessor() {
        return this.incomingProcessor;
    }

    @Override
    public void setIncomingProcessor(String incomingProcessor) {
        this.incomingProcessor = incomingProcessor;
    }

    @Override
    public Map<String, String> getFieldValues() {
        return fieldValues;
    }

    @Override
    public void setFieldValues(Map<String, String> fieldValues) {
        this.fieldValues = fieldValues;
    }

    @Override
    public String getLocalInstanceName() {
        return fieldValues.get(FieldValues.LOCAL_INSTANCE_NAME.toString());
    }

    @Override
    public void setLocalInstanceName(String localInstanceName) {
        fieldValues.put(FieldValues.LOCAL_INSTANCE_NAME.toString(), localInstanceName);
    }

    @Override
    public String getSyncMainFieldInfo() {
        return fieldValues.get(FieldValues.MAIN_FIELD_INFO.toString());
    }

    @Override
    public void setSyncMainFieldInfo(String localProjectKey) {
        fieldValues.put(FieldValues.MAIN_FIELD_INFO.toString(), localProjectKey);
    }

    @Override
    public String getUpgradeDate() {
        return fieldValues.get(FieldValues.UPGRADE_DATE.toString());
    }

    @Override
    public void setUpgradeDate(String upgradeDate) {
        fieldValues.put(FieldValues.UPGRADE_DATE.toString(), upgradeDate);
    }

    public String getMode() {
        return fieldValues.get(FieldValues.MODE.toString());
    }

    public void setMode(String mode) {
        if (mode == null) {
            fieldValues.remove(FieldValues.MODE.toString());
        } else {
            fieldValues.put(FieldValues.MODE.toString(), mode);
        }
    }
}
