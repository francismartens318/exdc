package com.exalate.basic.domain.connection;

import com.exalate.api.domain.connection.IConnectionIssueTrackerSettings;

import java.util.Map;

public class ConnectionIssueTrackerSettings implements IConnectionIssueTrackerSettings {

    private int id;
    private String issueTrackerType;
    private Boolean createLinks, createSyncPanelLinks;
    private String issueFilter;
    private String hpqcProject;
    private String hpqcDomain;
    private String issueLinkFieldName;
    private Map<String, String> fieldValues;

    public ConnectionIssueTrackerSettings(int id,
                                          String issueTrackerType,
                                          Boolean createLinks,
                                          Boolean createSyncPanelLinks,
                                          String issueFilter,
                                          String hpqcProject,
                                          String hpqcDomain,
                                          String issueLinkFieldName,
                                          Map<String, String> fieldValues) {
        this.id = id;
        this.issueTrackerType = issueTrackerType;
        this.createLinks = createLinks;
        this.createSyncPanelLinks = createSyncPanelLinks;
        this.issueFilter = issueFilter;
        this.hpqcProject = hpqcProject;
        this.hpqcDomain = hpqcDomain;
        this.issueLinkFieldName = issueLinkFieldName;
        this.fieldValues = fieldValues;
    }

    @Override
    public int getID() {
        return id;
    }

    @Override
    public String getIssueTrackerType() {
        return issueTrackerType;
    }

    @Override
    public String getHpqcProject() {
        return hpqcProject;
    }

    @Override
    public String getHpqcDomain() {
        return hpqcDomain;
    }

    @Override
    public Boolean getCreateLinks() {
        return createLinks;
    }

    public Boolean getCreateSyncPanelLinks() {
        return createSyncPanelLinks;
    }

    @Override
    public String getIssueFilter(){ return issueFilter; }

    @Override
    public String getIssueLinkFieldName() {
        return issueLinkFieldName;
    }

    @Override
    public Map<String, String> getFieldValues() {
        return fieldValues;
    }
}
