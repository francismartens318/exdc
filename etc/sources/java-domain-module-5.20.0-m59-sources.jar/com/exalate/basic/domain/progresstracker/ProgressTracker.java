package com.exalate.basic.domain.progresstracker;

import com.exalate.api.domain.progresstracker.IProgressTracker;
import com.exalate.api.domain.progresstracker.ProgressTrackerStatus;
import com.exalate.api.domain.progresstracker.TaskType;

public class ProgressTracker implements IProgressTracker {

    private int id;
    private TaskType taskType;
    private ProgressTrackerStatus status;
    private String result;
    private String errors;

    public ProgressTracker(final int id, final TaskType taskType, final ProgressTrackerStatus status, final String result, final String errors) {
        this.id = id;
        this.taskType = taskType;
        this.status = status;
        this.result = result;
        this.errors = errors;
    }

    @Override
    public int getId() {
        return id;
    }

    @Override
    public void setId(int id) {
        this.id = id;
    }

    @Override
    public TaskType getTaskType() {
        return taskType;
    }

    @Override
    public void setTaskType(TaskType type) {
        this.taskType = type;
    }

    @Override
    public ProgressTrackerStatus getStatus() {
        return status;
    }

    @Override
    public void setStatus(ProgressTrackerStatus status) {
        this.status = status;
    }

    @Override
    public String getResult() {
        return result;
    }

    @Override
    public void setResult(String result) {
        this.result = result;
    }

    @Override
    public String getErrors() {
        return errors;
    }

    @Override
    public void setErrors(String errors) {
        this.errors = errors;
    }
}
