package com.exalate.basic.domain.syncstatus;

import com.exalate.api.domain.syncstatus.IRemoteIssueUrlContext;

import javax.annotation.Nonnull;

public class RemoteIssueUrlContext implements IRemoteIssueUrlContext {
    private final String remoteIssueUrl;
    private final String trimmedSummary;
    private final String issueUrn;
    private final String issueId;

    public RemoteIssueUrlContext(@Nonnull String remoteIssueUrl,
                                 @Nonnull String trimmedSummary,
                                 @Nonnull String issueUrn,
                                 @Nonnull String issueId) {
        this.remoteIssueUrl = remoteIssueUrl;
        this.trimmedSummary = trimmedSummary;
        this.issueUrn = issueUrn;
        this.issueId = issueId;
    }

    @Override
    public String getRemoteIssueUrl() {
        return remoteIssueUrl;
    }

    @Override
    public String getTrimmedSummary() {
        return trimmedSummary;
    }

    @Override
    public String getIssueUrn() {
        return issueUrn;
    }

    @Override
    public String getIssueId() {
        return issueId;
    }
}
