/*
 * Copyright (C) 2015, Exalate NV
 * All rights reserved.
 *
 *
 * THIS SOURCE CODE IS AN UNPUBLISHED PROPRIETARY TRADE SECRET OF iDalko NV, unless stated otherwise
 * in the license text.
 *
 *
 * The copyright notice above does not evidence any actual or intended publication of such source code.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
 */
package com.exalate.basic.domain.syncstatus;

import com.exalate.api.domain.syncstatus.IRemoteIssueUrlContext;
import com.exalate.api.domain.syncstatus.ISyncStatusBean;
import com.exalate.api.domain.twintrace.SyncStatus;
import com.exalate.basic.domain.ErrorInfo;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

public class SyncStatusBean implements ISyncStatusBean {
    private final SyncStatus syncStatus;
    private final ErrorInfo errorInfo;
    private final Integer twinTraceId;
    private final IRemoteIssueUrlContext remoteIssueUrlContext;
    private final String relationName, relationId;

    public SyncStatusBean(SyncStatus syncStatus, ErrorInfo errorInfo, Integer twinTraceId, String relationName, String relationId, IRemoteIssueUrlContext remoteIssueUrlContext) {
        this.syncStatus = syncStatus;
        this.errorInfo = errorInfo;
        this.twinTraceId = twinTraceId;
        this.remoteIssueUrlContext = remoteIssueUrlContext;
        this.relationName = relationName;
        this.relationId = relationId;
    }

    @Override
    @Nonnull
    public SyncStatus getStatus() {
        return syncStatus;
    }

    @Override
    @Nonnull
    public ErrorInfo getErrorInfo() {
        return errorInfo;
    }

    @Override
    @Nullable
    public Integer getTwinTraceId() {
        return twinTraceId;
    }

    @Override
    @Nullable
    public IRemoteIssueUrlContext getRemoteIssueUrlContext() {
        return remoteIssueUrlContext;
    }

    @Nullable
    @Override
    public String getRelationName() {
        return relationName;
    }

    @Override
    public String getRelationId() {
        return relationId;
    }

    @Override
    public String toString() {
        return "SyncStatusBean{" +
                "@twinTraceId=`" + twinTraceId + "`" +
                ", @relationName=`" + relationName + "`" +
                ", @syncStatus=`" + syncStatus + "`" +
                ", @errorInfo=`" + errorInfo + "`" +
                ", @remoteIssueUrlContext=`" + remoteIssueUrlContext + "`" +
                '}';
    }
}
