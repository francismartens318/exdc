package com.exalate.basic.domain.register;

import com.google.gson.Gson;
import org.apache.commons.codec.binary.Base64;


public class RegistrationData {

    protected String companyName;
    protected String fullName;
    protected String email;
    protected String systemId;
    protected String jiraVersion;
    protected String licenseType;
    protected String returnPath;
    protected String addonName;
    protected String addonVersion;

    public RegistrationData() {
    }

    public RegistrationData(String companyName,
                            String fullName,
                            String email,
                            String systemId,
                            String jiraVersion,
                            String licenseType,
                            String returnPath,
                            String addonName,
                            String addonVersion) {
        this.companyName = companyName;
        this.fullName = fullName;
        this.email = email;
        this.systemId = systemId;
        this.jiraVersion = jiraVersion;
        this.licenseType = licenseType;
        this.returnPath = returnPath;
        this.addonName = addonName;
        this.addonVersion = addonVersion;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }


    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }


    public String getSystemId() {
        return systemId;
    }

    public void setSystemId(String systemId) {
        this.systemId = systemId;
    }


    public String getJiraVersion() {
        return jiraVersion;
    }

    public void setJiraVersion(String jiraVersion) {
        this.jiraVersion = jiraVersion;
    }

    public String getLicenseType() {
        return licenseType;
    }

    public void setLicenseType(String licenseType) {
        this.licenseType = licenseType;
    }


    public String getReturnPath() {
        return returnPath;
    }

    public void setReturnPath(String returnPath) {
        this.returnPath = returnPath;
    }

    public String getAddonName() {
        return addonName;
    }

    public void setAddonName(String addonName) {
        this.addonName = addonName;
    }

    public String getAddonVersion() {
        return addonVersion;
    }

    public void setAddonVersion(String addonVersion) {
        this.addonVersion = addonVersion;
    }

    /**
     * Convert to json, and base 64 encode the registration data
    */

    public String toBase64() {
        String json = new Gson().toJson(this);
        return new String(Base64.encodeBase64(json.getBytes()));
    }

    /**
     * Convert from base64 to json to object
     * @param base64
     * @return
     */

    public static RegistrationData fromBase64(String base64) {
        String json = new String(Base64.decodeBase64(base64.getBytes()));

        return new Gson().fromJson(json, RegistrationData.class);
    }

}
