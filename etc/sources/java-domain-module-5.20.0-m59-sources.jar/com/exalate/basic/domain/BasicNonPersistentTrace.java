/*
 * Copyright (C) 2015, iDalko NV
 * All rights reserved.
 *
 *
 * THIS SOURCE CODE IS AN UNPUBLISHED PROPRIETARY TRADE SECRET OF iDalko NV, unless stated otherwise
 * in the license text.
 *
 *
 * The copyright notice above does not evidence any actual or intended publication of such source code.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
 */
package com.exalate.basic.domain;

import com.exalate.api.domain.twintrace.INonPersistentTrace;
import com.exalate.api.domain.twintrace.ITrace;
import com.exalate.api.domain.twintrace.TraceAction;
import com.exalate.api.domain.twintrace.TraceType;

import javax.annotation.Nonnull;

public class BasicNonPersistentTrace implements INonPersistentTrace, INonPersistentTrace.Builder {
    private final TraceType type;
    private final String localId;
    private final String remoteId;
    private TraceAction action;
    private final boolean toSynchronize;
    private final Integer requestId;
    private final Integer twinTraceId;
    private final Integer eventIdForLocal;
    private final Integer eventIdForRemote;

    public BasicNonPersistentTrace() {
        this(null, null, null, null, true, null, null, null, null);
    }

    private BasicNonPersistentTrace(TraceType type, String localId, String remoteId, TraceAction action,
                                    boolean toSynchronize) {
        this(type, localId, remoteId, action, toSynchronize, null, null, null, null);
    }

    private BasicNonPersistentTrace(TraceType type, String localId, String remoteId, TraceAction action,
                                    boolean toSynchronize, Integer requestId, Integer twinTraceId,
                                    Integer eventIdForLocal, Integer eventIdForRemote) {
        this.type = type;
        this.localId = localId;
        this.remoteId = remoteId;
        this.action = action;
        this.toSynchronize = toSynchronize;
        this.requestId = requestId;
        this.twinTraceId = twinTraceId;
        this.eventIdForLocal = eventIdForLocal;
        this.eventIdForRemote = eventIdForRemote;
    }

    @Nonnull
    @Override
    public TraceType getType() {
        return type;
    }

    @Override
    public String getLocalId() {
        return localId;
    }

    @Override
    public String getRemoteId() {
        return remoteId;
    }

    @Override
    public TraceAction getAction() {
        return action;
    }

    @Override
    public boolean isToSynchronize() {
        return toSynchronize;
    }

    public Boolean getToSynchronize() {
        return toSynchronize;
    }

    @Override
    public Integer getRequestId() {
        return requestId;
    }

    @Override
    public Integer getTwinTraceId() {
        return twinTraceId;
    }

    @Override
    public Integer getEventId() {
        return eventIdForRemote;
    }

    @Nonnull
    @Override
    public BasicNonPersistentTrace setType(@Nonnull TraceType traceType) {
        return new BasicNonPersistentTrace(traceType, localId, remoteId, action, toSynchronize, requestId, twinTraceId,
                                           eventIdForLocal, eventIdForRemote);
    }

    @Nonnull
    @Override
    public BasicNonPersistentTrace setLocalId(@Nonnull String localId) {
        return new BasicNonPersistentTrace(type, localId, remoteId, action, toSynchronize, requestId, twinTraceId,
                                           eventIdForLocal, eventIdForRemote);
    }

    @Nonnull
    @Override
    public BasicNonPersistentTrace setRemoteId(@Nonnull String remoteId) {
        return new BasicNonPersistentTrace(type, localId, remoteId, action, toSynchronize, requestId, twinTraceId,
                                           eventIdForLocal, eventIdForRemote);
    }

    @Nonnull
    @Override
    public BasicNonPersistentTrace setAction(@Nonnull TraceAction action) {
        return new BasicNonPersistentTrace(type, localId, remoteId, action, toSynchronize, requestId, twinTraceId,
                                           eventIdForLocal, eventIdForRemote);
    }

    @Nonnull
    @Override
    public BasicNonPersistentTrace setToSynchronize(boolean toSynchronize) {
        return new BasicNonPersistentTrace(type, localId, remoteId, action, toSynchronize, requestId, twinTraceId,
                                           eventIdForLocal, eventIdForRemote);
    }

    @Nonnull
    @Override
    public BasicNonPersistentTrace setRequestId(int requestId) {
        return new BasicNonPersistentTrace(type, localId, remoteId, action, toSynchronize, requestId, twinTraceId,
                                           eventIdForLocal, eventIdForRemote);
    }

    @Nonnull
    @Override
    public BasicNonPersistentTrace setTwinTraceId(int twinTraceId) {
        return new BasicNonPersistentTrace(type, localId, remoteId, action, toSynchronize, requestId, twinTraceId,
                                           eventIdForLocal, eventIdForRemote);
    }

    @Nonnull
    @Override
    public BasicNonPersistentTrace setEventId(int eventId) {
        return new BasicNonPersistentTrace(type, localId, remoteId, action, toSynchronize, requestId, twinTraceId,
                                           eventIdForLocal, eventId);
    }

    //todo ihor rework those methods
    @Nonnull
    @Override
    public BasicNonPersistentTrace from(@Nonnull ITrace trace) {
        TraceType thatType = trace.getType();
        String thatLocalId = trace.getLocalId();
        String thatRemoteId = trace.getRemoteId();
        TraceAction thatAction = trace.getAction();
        Boolean thatToSynchronize = trace.isToSynchronize();
        return new BasicNonPersistentTrace(thatType, thatLocalId, thatRemoteId, thatAction, thatToSynchronize);
    }

    @Nonnull
    @Override
    public BasicNonPersistentTrace from(@Nonnull INonPersistentTrace trace) {
        if (trace instanceof BasicNonPersistentTrace) {
            return ((BasicNonPersistentTrace) trace);
        }
        TraceType thatType = trace.getType();
        String thatLocalId = trace.getLocalId();
        String thatRemoteId = trace.getRemoteId();
        TraceAction thatAction = trace.getAction();
        Boolean thatToSynchronize = trace.isToSynchronize();
        return new BasicNonPersistentTrace(thatType, thatLocalId, thatRemoteId, thatAction, thatToSynchronize);
    }

    @Nonnull
    @Override
    public INonPersistentTrace build() {
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof BasicNonPersistentTrace)) {
            return false;
        }

        BasicNonPersistentTrace that = (BasicNonPersistentTrace) o;

        if (localId != null ? !localId.equals(that.localId) : that.localId != null) {
            return false;
        }
        if (remoteId != null ? !remoteId.equals(that.remoteId) : that.remoteId != null) {
            return false;
        }
        //noinspection RedundantIfStatement
        if (type != that.type) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        int result = type != null ? type.hashCode() : 0;
        result = 61 * result + (localId != null ? localId.hashCode() : 0);
        result = 61 * result + (remoteId != null ? remoteId.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "BasicNonPersistentTrace{" +
                "@type=`" + type + "`" +
                ", @localId=`" + localId + '`' +
                ", @remoteId=`" + remoteId + '`' +
                ", @act=`" + action + '`' +
                '}';
    }
}
