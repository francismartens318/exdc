package com.exalate.basic.domain.twintrace;

import com.exalate.api.domain.twintrace.ITrace;
import com.exalate.api.domain.twintrace.TraceAction;
import com.exalate.api.domain.twintrace.TraceType;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.Objects;

public class Trace implements ITrace {
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Trace trace = (Trace) o;
        return getId() == trace.getId() &&
                isToSynchronize() == trace.isToSynchronize() &&
                getType() == trace.getType() &&
                Objects.equals(getLocalId(), trace.getLocalId()) &&
                Objects.equals(getRemoteId(), trace.getRemoteId()) &&
                getAction() == trace.getAction();
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getType(), getLocalId(), getRemoteId(), getAction(), isToSynchronize());
    }

    private int id;
    private TraceType type;
    private String localId;
    private String remoteId;
    private TraceAction action;
    private boolean isToSynchronize;
    private Integer requestId;
    private Integer twinTraceId;
    private Integer eventId;

    public Trace(final int id, final TraceType type, final String localId, final String remoteId,
                 final TraceAction action, final boolean isToSynchronize, final Integer requestId,
                 final Integer twinTraceId,
                 final Integer eventId) {
        this.id = id;
        this.type = type;
        this.localId = localId;
        this.remoteId = remoteId;
        this.action = action;
        this.isToSynchronize = isToSynchronize;
        this.requestId = requestId;
        this.twinTraceId = twinTraceId;
        this.eventId = eventId;
    }

    public void setId(final int id) {
        this.id = id;
    }

    public void setType(@Nonnull final TraceType type) {
        this.type = type;
    }

    public void setLocalId(@Nonnull final String localId) {
        this.localId = localId;
    }

    public void setRemoteId(@Nonnull final String remoteId) {
        this.remoteId = remoteId;
    }

    public void setAction(@Nonnull final TraceAction action) {
        this.action = action;
    }

    public void setToSynchronize(final boolean toSynchronize) {
        isToSynchronize = toSynchronize;
    }

    public void setRequestId(@Nonnull final Integer requestId) {
        this.requestId = requestId;
    }

    public void setTwinTraceId(@Nonnull final Integer twinTraceId) {
        this.twinTraceId = twinTraceId;
    }

    public void setEventId(@Nonnull  final Integer eventId) {
        this.eventId = eventId;
    }

    public int getId() {
        return id;
    }

    @Nonnull
    public TraceType getType() {
        return type;
    }

    @Nullable
    public String getLocalId() {
        return localId;
    }

    @Nullable
    public String getRemoteId() {
        return remoteId;
    }

    @Nonnull
    public TraceAction getAction() {
        return action;
    }

    public boolean isToSynchronize() {
        return isToSynchronize;
    }

    @Nullable
    public Integer getRequestId() {
        return requestId;
    }

    public Integer getTwinTraceId() {
        return twinTraceId;
    }

    @Nullable
    public Integer getEventId() {
        return eventId;
    }
}
