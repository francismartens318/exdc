package com.exalate.basic.domain.twintrace;

import com.exalate.api.domain.IPersistentReplica;
import com.exalate.api.domain.connection.IConnection;
import com.exalate.api.domain.twintrace.ITrace;
import com.exalate.api.domain.twintrace.ITwinTrace;
import com.exalate.api.domain.twintrace.TraceType;
import com.exalate.api.domain.twintrace.TwinTraceStatus;
import com.exalate.api.domain.twintrace.TwinType;
import scala.Option;
import scala.Option$;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.*;

public class TwinTrace implements ITwinTrace {

    private int id;
    private Integer remoteTwinTraceId;
    private IConnection connection;
    private IPersistentReplica localReplica;
    private IPersistentReplica remoteReplica;
    private Long numberOfEvents;
    private TwinTraceStatus status;
    private int lastReceivedResponse;
    private Long lastProcessedRemoteEventNumber;
    private TwinType type;
    private Map<TraceType, List<ITrace>> fieldTracesMap = new HashMap<TraceType, List<ITrace>>();
    private List<ITrace> fieldTraces = new ArrayList<ITrace>();
    private final boolean useRemoteScope;
    private Date createdDate;
    private Date payedDate;

    public TwinTrace(final int id, final IConnection connection, final IPersistentReplica localReplica,
                     final IPersistentReplica remoteReplica, final Long numberOfEvents,
                     final Integer remoteTwinTraceId,
                     final TwinTraceStatus status, final int lastReceivedResponse,
                     final Long lastProcessedRemoteEventNumber,
                     final TwinType type,
                     final Map<TraceType, List<ITrace>> fieldTracesMap,
                     final List<ITrace> fieldTraces,
                     Option<Boolean> useRemoteScopeOpt,
                     Date createdDate,
                     Date payedDate) {
        this.id = id;
        this.connection = connection;
        this.localReplica = localReplica;
        this.remoteReplica = remoteReplica;
        this.numberOfEvents = numberOfEvents;
        this.remoteTwinTraceId = remoteTwinTraceId;
        this.status = status;
        this.lastReceivedResponse = lastReceivedResponse;
        this.lastProcessedRemoteEventNumber = lastProcessedRemoteEventNumber;
        this.type = type;
        this.fieldTracesMap = fieldTracesMap;
        this.fieldTraces = fieldTraces;
        this.createdDate = createdDate;
        this.payedDate = payedDate;
        if (useRemoteScopeOpt.isEmpty()) {
            this.useRemoteScope = false;
        } else {
            this.useRemoteScope = useRemoteScopeOpt.get();
        }
    }

    public TwinTrace(final int id, final IConnection connection, final IPersistentReplica localReplica,
                     final IPersistentReplica remoteReplica, final Long numberOfEvents,
                     final Integer remoteTwinTraceId,
                     final TwinTraceStatus status, final int lastReceivedResponse,
                     final Long lastProcessedRemoteEventNumber,
                     final TwinType type,
                     final Map<TraceType, List<ITrace>> fieldTracesMap,
                     final List<ITrace> fieldTraces, Date createdDate, Date payedDate) {
        this(
                id,
                connection,
                localReplica,
                remoteReplica,
                numberOfEvents,
                remoteTwinTraceId,
                status,
                lastReceivedResponse,
                lastProcessedRemoteEventNumber,
                type,
                fieldTracesMap,
                fieldTraces,
                Option$.MODULE$.<Boolean>empty(),
                createdDate, payedDate);
    }

    public void setId(final int id) {
        this.id = id;
    }

    public void setConnection(final IConnection connection) {
        this.connection = connection;
    }

    public void setLocalReplica(final IPersistentReplica localReplica) {
        this.localReplica = localReplica;
    }

    public void setRemoteReplica(final IPersistentReplica remoteReplica) {
        this.remoteReplica = remoteReplica;
    }

    public void setNumberOfEvents(final Long numberOfEvents) {
        this.numberOfEvents = numberOfEvents;
    }

    public void setStatus(final TwinTraceStatus status) {
        this.status = status;
    }

    public void setLastReceivedResponse(final int lastReceivedResponse) {
        this.lastReceivedResponse = lastReceivedResponse;
    }

    public void setLastProcessedRemoteEventNumber(final Long lastProcessedRemoteEventNumber) {
        this.lastProcessedRemoteEventNumber = lastProcessedRemoteEventNumber;
    }

    public void setType(final TwinType type) {
        this.type = type;
    }

    public void setFieldTracesMap(
            final Map<TraceType, List<ITrace>> fieldTracesMap) {
        this.fieldTracesMap = fieldTracesMap;
    }

    public void setFieldTraces(final List<ITrace> fieldTraces) {
        this.fieldTraces = fieldTraces;
    }

    public int getId() {
        return id;
    }

    public IConnection getConnection() {
        return connection;
    }

    public IPersistentReplica getLocalReplica() {
        return localReplica;
    }

    public IPersistentReplica getRemoteReplica() {
        return remoteReplica;
    }

    public Long getNumberOfEvents() {
        return numberOfEvents;
    }

    public TwinTraceStatus getStatus() {
        return status;
    }

    public int getLastReceivedResponse() {
        return lastReceivedResponse;
    }

    public Long getLastProcessedRemoteEventNumber() {
        return lastProcessedRemoteEventNumber;
    }

    public List<ITrace> getFieldTraces(final TraceType traceType) {
        List<ITrace> result = fieldTracesMap.get(traceType);
        if (result == null) {
            return new ArrayList<ITrace>();
        }

        return result;
    }

    public List<ITrace> getAllFieldTraces() {
        return fieldTraces;
    }

    public Map<TraceType, List<ITrace>> getFieldTraces() {
        return fieldTracesMap;
    }

    public boolean hasChanges(@Nonnull final IPersistentReplica newLocalReplica) {
        String newPayload = newLocalReplica.getPayload();
        String syncedPayload = localReplica.getPayload();
        return !syncedPayload.equals(newPayload);
    }

    public TwinType getType() {
        return type;
    }

    @Nullable
    @Override
    public Integer getRemoteTwinTraceId() {
        return remoteTwinTraceId;
    }

    @Override
    public boolean isUseRemoteScope() {
        return useRemoteScope;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    @Override
    public Date getPayedDate() {
        return payedDate;
    }

    public void setPayedDate(Date payedDate) {
        this.payedDate = payedDate;
    }

    @Override
    public String toString() {
        return "TwinTrace{" +
                "id=" + id +
                ", remoteTwinTraceId=" + remoteTwinTraceId +
                ", connection=" + connection +
                ", localReplica=" + localReplica +
                ", remoteReplica=" + remoteReplica +
                ", numberOfEvents=" + numberOfEvents +
                ", status=" + status +
                ", lastReceivedResponse=" + lastReceivedResponse +
                ", lastProcessedRemoteEventNumber=" + lastProcessedRemoteEventNumber +
                ", type=" + type +
                ", fieldTracesMap=" + fieldTracesMap +
                ", fieldTraces=" + fieldTraces +
                ", useRemoteScope=" + useRemoteScope +
                ", createdDate=" + createdDate +
                ", payedDate=" + payedDate +
                '}';
    }
}
