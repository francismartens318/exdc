package com.exalate.basic.domain.error;

import com.exalate.api.domain.*;
import com.exalate.api.domain.blob.event.IBlobEvent;
import com.exalate.api.domain.blob.request.IBlobRequest;
import com.exalate.api.domain.event.ISyncEvent;
import com.exalate.api.domain.instance.IInstance;
import com.exalate.api.domain.connection.IConnection;
import com.exalate.api.domain.request.ISyncRequest;
import com.exalate.api.domain.trigger.ITrigger;

import java.util.Date;
import java.util.Map;

public class NonPersistentError {

    private Date creationTime;
    private String stackTrace;
    private String rootCauseErrorTypeName;
    private String rootCauseDetails;
    private ErrorEntityType errorEntityType;
    private ErrorActType actType;
    private String connectRemoteIssueUrn;
    private IPersistentConnectContext connectContext;
    private IConnection connection;
    private IInstance instance;
    private IIssueKey issueKey;
    private IIssueKey remoteIssueKey;
    private ISyncEvent syncEvent;
    private ISyncRequest syncRequest;
    private IBlobEvent blobEvent;
    private IBlobRequest blobRequest;
    private ITrigger trigger;
    private String failedToExalateIssues;
    private String usersDismissed;
    private String key;
    Map<String, String>  fieldValues;

    public NonPersistentError(final Date creationTime, final String stackTrace,
                              final String rootCauseErrorTypeName, final String rootCauseDetails,
                              final ErrorEntityType errorEntityType, final ErrorActType actType,
                              final String connectRemoteIssueUrn, final IPersistentConnectContext connectContext,
                              final IConnection connection, final IInstance instance,
                              final IIssueKey issueKey, final IIssueKey remoteIssueKey, final ISyncEvent syncEvent,
                              final ISyncRequest syncRequest, final IBlobEvent blobEvent, final IBlobRequest blobRequest,
                              final ITrigger trigger, final Map<String, String> fieldValues, final String usersDismissed, final String key)
    {
        this.creationTime = creationTime;
        this.stackTrace = stackTrace;
        this.rootCauseErrorTypeName = rootCauseErrorTypeName;
        this.rootCauseDetails = rootCauseDetails;
        this.errorEntityType = errorEntityType;
        this.actType = actType;
        this.connectRemoteIssueUrn = connectRemoteIssueUrn;
        this.connectContext = connectContext;
        this.connection = connection;
        this.instance = instance;
        this.issueKey = issueKey;
        this.remoteIssueKey = remoteIssueKey;
        this.syncEvent = syncEvent;
        this.syncRequest = syncRequest;
        this.blobEvent = blobEvent;
        this.blobRequest = blobRequest;
        this.trigger = trigger;
        this.usersDismissed = usersDismissed;
        this.key = key;
        this.fieldValues = fieldValues;
    }

    public NonPersistentError(IError error) {
        this.creationTime = error.getCreationTime();
        this.stackTrace = error.getStackTrace();
        this.rootCauseErrorTypeName = error.getRootCauseErrorTypeName();
        this.rootCauseDetails = error.getRootCauseDetails();
        this.errorEntityType = error.getErrorEntityType();
        this.actType = error.getActType();
        this.connectRemoteIssueUrn = error.getConnectRemoteIssueUrn();
        this.connectContext = error.getConnectContext();
        this.connection = error.getConnection();
        this.instance = error.getInstance();
        this.issueKey = error.getIssueKey();
        this.remoteIssueKey = error.getRemoteIssueKey();
        this.syncEvent = error.getSyncEvent();
        this.syncRequest = error.getSyncRequest();
        this.blobEvent = error.getBlobEvent();
        this.blobRequest = error.getBlobRequest();
        this.trigger = error.getTrigger();
        this.fieldValues = error.getFieldValues();
        this.usersDismissed = error.getUsersDismissed();
    }


    public void setCreationTime(Date creationTime) {
        this.creationTime = creationTime;
    }

    public void setStackTrace(String stackTrace) {
        this.stackTrace = stackTrace;
    }

    public void setRootCauseErrorTypeName(String rootCauseErrorTypeName) {
        this.rootCauseErrorTypeName = rootCauseErrorTypeName;
    }

    public void setRootCauseDetails(String rootCauseDetails) {
        this.rootCauseDetails = rootCauseDetails;
    }

    public void setErrorEntityType(ErrorEntityType errorEntityType) {
        this.errorEntityType = errorEntityType;
    }

    public void setActType(ErrorActType actType) {
        this.actType = actType;
    }

    public void setConnectRemoteIssueUrn(String connectRemoteIssueUrn) {
        this.connectRemoteIssueUrn = connectRemoteIssueUrn;
    }

    public void setConnectContext(IPersistentConnectContext connectContext) {
        this.connectContext = connectContext;
    }

    public void setConnection(IConnection connection) {
        this.connection = connection;
    }

    public void setInstance(IInstance instance) {
        this.instance = instance;
    }

    public void setIssueKey(IIssueKey issueKey) {
        this.issueKey = issueKey;
    }

    public void setRemoteIssueKey(IIssueKey remoteIssueKey) {
        this.remoteIssueKey = remoteIssueKey;
    }

    public void setSyncEvent(ISyncEvent syncEvent) {
        this.syncEvent = syncEvent;
    }

    public void setSyncRequest(ISyncRequest syncRequest) {
        this.syncRequest = syncRequest;
    }

    public void setBlobEvent(IBlobEvent blobEvent) {
        this.blobEvent = blobEvent;
    }

    public void setBlobRequest(IBlobRequest blobRequest) {
        this.blobRequest = blobRequest;
    }

    public Date getCreationTime() {
        return creationTime;
    }

    public String getStackTrace() {
        return stackTrace;
    }

    public String getRootCauseErrorTypeName() {
        return rootCauseErrorTypeName;
    }

    public String getRootCauseDetails() {
        return rootCauseDetails;
    }

    public ErrorEntityType getErrorEntityType() {
        return errorEntityType;
    }

    public ErrorActType getActType() {
        return actType;
    }

    public String getConnectRemoteIssueUrn() {
        return connectRemoteIssueUrn;
    }

    public IPersistentConnectContext getConnectContext() {
        return connectContext;
    }

    public IConnection getConnection() {
        return connection;
    }

    public IInstance getInstance() {
        return instance;
    }

    public IIssueKey getIssueKey() {
        return issueKey;
    }

    public ISyncEvent getSyncEvent() {
        return syncEvent;
    }

    public ISyncRequest getSyncRequest() {
        return syncRequest;
    }

    public IBlobEvent getBlobEvent() {
        return blobEvent;
    }

    public IBlobRequest getBlobRequest() {
        return blobRequest;
    }

    public IIssueKey getRemoteIssueKey() {
        return remoteIssueKey;
    }

    public ITrigger getTrigger() {
        return trigger;
    }

    public void setTrigger(ITrigger trigger) {
        this.trigger = trigger;
    }

    public void setFailedToExalateIssues(String failedToExalateIssues) {
        this.failedToExalateIssues = failedToExalateIssues;
    }

    public String getUsersDismissed() {
        return usersDismissed;
    }

    public void setUsersDismissed(String usersDismissed) {
        this.usersDismissed = usersDismissed;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public Map<String, String> getFieldValues() {
        return fieldValues;
    }

    public void setFieldValues(Map<String, String> fieldValues) {
        this.fieldValues = fieldValues;
    }
}
