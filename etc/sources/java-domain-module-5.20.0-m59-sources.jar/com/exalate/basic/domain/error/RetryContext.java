package com.exalate.basic.domain.error;

import com.exalate.api.domain.blob.event.IBlobEvent;
import com.exalate.api.domain.blob.request.IBlobRequest;
import com.exalate.api.domain.error.IRetryContext;
import com.exalate.api.domain.error.RetryStrategy;
import com.exalate.api.domain.event.ISyncEvent;
import com.exalate.api.domain.request.ISyncRequest;

import java.util.Date;

public class RetryContext implements IRetryContext {

    private int id;
    private Date nextRetry;
    private int attemptedRetries;
    private RetryStrategy retryStrategy;

    private ISyncEvent syncEvent;
    private ISyncRequest syncRequest;
    private IBlobEvent blobEvent;
    private IBlobRequest blobRequest;

    public RetryContext(int id,
                        Date nextRetry,
                        int attemptedRetries,
                        RetryStrategy retryStrategy,
                        ISyncEvent syncEvent,
                        ISyncRequest syncRequest,
                        IBlobEvent blobEvent,
                        IBlobRequest blobRequest) {
        this.id = id;
        this.nextRetry = nextRetry;
        this.attemptedRetries = attemptedRetries;
        this.retryStrategy = retryStrategy;
        this.syncEvent = syncEvent;
        this.syncRequest = syncRequest;
        this.blobEvent = blobEvent;
        this.blobRequest = blobRequest;
    }

    public RetryContext(int id,
                        Date nextRetry,
                        int attemptedRetries,
                        RetryStrategy retryStrategy) {
        this.id = id;
        this.nextRetry = nextRetry;
        this.attemptedRetries = attemptedRetries;
        this.retryStrategy = retryStrategy;
    }

    @Override
    public int getId() {
        return id;
    }

    @Override
    public Date getNextRetry() {
        return nextRetry;
    }

    @Override
    public int getAttemptedRetries() {
        return attemptedRetries;
    }

    @Override
    public RetryStrategy getRetryStrategy() {
        return retryStrategy;
    }

    @Override
    public ISyncEvent getSyncEvent() {
        return syncEvent;
    }

    @Override
    public ISyncRequest getSyncRequest() {
        return syncRequest;
    }

    @Override
    public IBlobEvent getBlobEvent() {
        return blobEvent;
    }

    @Override
    public IBlobRequest getBlobRequest() {
        return blobRequest;
    }
}
