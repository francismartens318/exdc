package com.exalate.basic.domain.error;

import com.exalate.api.domain.ErrorActType;
import com.exalate.api.domain.ErrorEntityType;
import com.exalate.api.domain.IError;
import com.exalate.api.domain.IIssueKey;
import com.exalate.api.domain.IPersistentConnectContext;
import com.exalate.api.domain.blob.event.IBlobEvent;
import com.exalate.api.domain.blob.request.IBlobRequest;
import com.exalate.api.domain.event.ISyncEvent;
import com.exalate.api.domain.instance.IInstance;
import com.exalate.api.domain.connection.IConnection;
import com.exalate.api.domain.request.ISyncRequest;
import com.exalate.api.domain.trigger.ITrigger;

import javax.annotation.Nullable;
import java.util.Date;
import java.util.Map;

public class ExalateError implements IError {

    private int id;
    private Date creationTime;
    private String stackTrace;
    private String rootCauseErrorTypeName;
    private String rootCauseDetails;
    private ErrorEntityType errorEntityType;
    private ErrorActType actType;
    private String connectRemoteIssueUrn;
    private IConnection relation;
    private IInstance instance;
    private IIssueKey issueKey;
    private IIssueKey remoteIssueKey;
    private IPersistentConnectContext connectContext;
    private ISyncEvent syncEvent;
    private ISyncRequest syncRequest;
    private IBlobEvent blobEvent;
    private IBlobRequest blobRequest;
    private ITrigger trigger;
    private Map<String, String> fieldValues;
    private String usersDismissed;
    private String key;

    public ExalateError() {
    }

    public ExalateError(final int id, final Date creationTime, final String stackTrace,
                        final String rootCauseErrorTypeName, final String rootCauseDetails,
                        final ErrorEntityType errorEntityType, final ErrorActType actType,
                        final String connectRemoteIssueUrn, final IConnection relation, final IInstance instance,
                        final IIssueKey issueKey, final IIssueKey remoteIssueKey, final ISyncEvent syncEvent,
                        final ISyncRequest syncRequest, final IBlobEvent blobEvent, final IBlobRequest blobRequest,
                        final ITrigger trigger, final Map<String, String> fieldValues, final String usersDismissed,
                        final String key) {
        this.id = id;
        this.creationTime = creationTime;
        this.stackTrace = stackTrace;
        this.rootCauseErrorTypeName = rootCauseErrorTypeName;
        this.rootCauseDetails = rootCauseDetails;
        this.errorEntityType = errorEntityType;
        this.actType = actType;
        this.connectRemoteIssueUrn = connectRemoteIssueUrn;
        this.relation = relation;
        this.instance = instance;
        this.issueKey = issueKey;
        this.remoteIssueKey = remoteIssueKey;
        this.syncEvent = syncEvent;
        this.syncRequest = syncRequest;
        this.blobEvent = blobEvent;
        this.blobRequest = blobRequest;
        this.trigger = trigger;
        this.fieldValues = fieldValues;
        this.usersDismissed = usersDismissed;
        this.key = key;
    }

    @Override
    public int getId() {
        return id;
    }


    @Override
    public Date getCreationTime() {
        return creationTime;
    }

    @Override
    public String getStackTrace() {
        return stackTrace;
    }

    @Override
    public String getRootCauseErrorTypeName() {
        return rootCauseErrorTypeName;
    }

    @Override
    public String getRootCauseDetails() {
        return rootCauseDetails;
    }

    @Override
    public ErrorEntityType getErrorEntityType() {
        return errorEntityType;
    }

    @Override
    public ErrorActType getActType() {
        return actType;
    }

    @Override
    public String getConnectRemoteIssueUrn() {
        return connectRemoteIssueUrn;
    }

    @Override
    public IConnection getConnection() {
        return relation;
    }

    @Override
    public IInstance getInstance() {
        return instance;
    }

    @Override
    public IIssueKey getIssueKey() {
        return issueKey;
    }

    @Override
    public ISyncEvent getSyncEvent() {
        return syncEvent;
    }

    @Override
    public ISyncRequest getSyncRequest() {
        return syncRequest;
    }

    @Override
    public IBlobEvent getBlobEvent() {
        return blobEvent;
    }

    @Override
    public IBlobRequest getBlobRequest() {
        return blobRequest;
    }

    @Nullable
    @Override
    public ITrigger getTrigger() {
        return trigger;
    }

    @Nullable
    @Override
    public String getUsersDismissed() {
        return usersDismissed;
    }

    @Nullable
    @Override
    public Map<String, String> getFieldValues() {
        return fieldValues;
    }

    @Override
    public IIssueKey getRemoteIssueKey() {
        return remoteIssueKey;
    }



    @Nullable
    @Override
    public IPersistentConnectContext getConnectContext() {
        return connectContext;
    }

    @Override
    public String getKey() {
        return key;
    }

}
