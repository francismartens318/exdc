package com.exalate.basic.domain.hubobject.v1;

import com.exalate.api.domain.hubobject.v1_2.IHubStatus;

/**
 * By default, we don't use the webhook payload to generate the HubIssue used on the scheduling.
 *
 * This class is used to allow exalate nodes to pass hub issue info to the scheduling
 * A good reason to do that is that you would want to read some data from a webhook
 * and pass that data to the scheduling so it's used on the construction of the issue
 *
 */
public class UpdateBasicHubIssue {

    private BasicHubIssue issue;
    private boolean statusSet = false;

    public UpdateBasicHubIssue() {
        this(new BasicHubIssue());
    }

    public UpdateBasicHubIssue(BasicHubIssue issue) {
        this.issue = issue;
    }

    public void setStatus(IHubStatus status){
        issue.setStatus(status);
        statusSet = true;
    }

    public boolean isStatusSet(){
        return this.statusSet;
    }

    public IHubStatus getStatus(){
        return this.issue.getStatus();
    }

    public BasicHubIssue getIssue() {
        return issue;
    }

    public void setIssue(BasicHubIssue issue) {
        this.issue = issue;
    }
}
