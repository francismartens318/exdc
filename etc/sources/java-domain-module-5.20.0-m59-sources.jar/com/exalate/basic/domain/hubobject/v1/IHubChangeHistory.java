package com.exalate.basic.domain.hubobject.v1;


import com.exalate.api.domain.hubobject.v1_15.IHubChangeItem;
import com.exalate.api.domain.hubobject.v1_2.IHubUser;

import java.sql.Timestamp;
import java.util.List;

public interface IHubChangeHistory {
    public long getId();

    public IHubUser getAuthor();

    public Timestamp getCreated();

    public List<IHubChangeItem> getChangeItems();
}
