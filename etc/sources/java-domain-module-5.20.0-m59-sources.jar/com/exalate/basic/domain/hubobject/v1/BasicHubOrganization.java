package com.exalate.basic.domain.hubobject.v1;

import com.exalate.api.domain.hubobject.IHubOrganization;

import java.io.Serializable;
import java.util.List;
import java.util.Objects;

public class BasicHubOrganization implements IHubOrganization, Serializable {

    private String organizationName;
    private List<String> customers;

    public BasicHubOrganization(String organizationName, List<String> customers) {
        this.organizationName = organizationName;
        this.customers = customers;
    }

    public String getOrganizationName() {
        return organizationName;
    }

    public String getName() {
        return organizationName;
    }

    public List<String> getCustomers() {
        return customers;
    }

    public void setOrganizationName(String organizationName) {
        this.organizationName = organizationName;
    }

    public void setCustomers(List<String> customers) {
        this.customers = customers;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        BasicHubOrganization that = (BasicHubOrganization) o;
        return Objects.equals(organizationName, that.organizationName) &&
                Objects.equals(customers, that.customers);
    }

    @Override
    public int hashCode() {
        return Objects.hash(organizationName, customers);
    }
}
