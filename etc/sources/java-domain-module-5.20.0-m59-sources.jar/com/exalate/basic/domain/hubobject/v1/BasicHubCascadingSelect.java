package com.exalate.basic.domain.hubobject.v1;

import com.exalate.api.domain.hubobject.v1_11.IHubCascadingSelect;
import com.exalate.api.domain.hubobject.v1_2.IHubOption;

import java.io.Serializable;

public class BasicHubCascadingSelect implements IHubCascadingSelect, Serializable {

    private IHubOption parent;
    private IHubOption child;

    public BasicHubCascadingSelect() {
    }

    public BasicHubCascadingSelect(IHubOption parent, IHubOption child) {
        this.parent = parent;
        this.child = child;
    }

    public void setParent(IHubOption parent) {
        this.parent = parent;
    }

    public void setChild(IHubOption child) {
        this.child = child;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        BasicHubCascadingSelect that = (BasicHubCascadingSelect) o;

        if (parent != null ? !parent.equals(that.parent) : that.parent != null) return false;
        return child != null ? child.equals(that.child) : that.child == null;
    }

    @Override
    public int hashCode() {
        int result = parent != null ? parent.hashCode() : 0;
        result = 31 * result + (child != null ? child.hashCode() : 0);
        return result;
    }

    @Override
    public IHubOption getParent() {
        return parent;
    }

    @Override
    public IHubOption getChild() {
        return child;
    }
}
