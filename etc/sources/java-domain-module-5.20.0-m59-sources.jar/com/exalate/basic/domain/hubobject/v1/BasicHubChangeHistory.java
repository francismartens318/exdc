package com.exalate.basic.domain.hubobject.v1;

import com.exalate.api.domain.hubobject.v1_15.IHubChangeItem;
import com.exalate.api.domain.hubobject.v1_2.IHubUser;

import java.sql.Timestamp;
import java.util.List;

public class BasicHubChangeHistory implements IHubChangeHistory {
    private long id;
    private IHubUser author;
    private Timestamp created;
    private List<IHubChangeItem> changeItems;

    public BasicHubChangeHistory(long id,
                                 IHubUser author,
                                 Timestamp created,
                                 List<IHubChangeItem> changeItems) {
        this.id = id;
        this.author = author;
        this.created = created;
        this.changeItems = changeItems;
    }

    @Override
    public long getId() {
        return this.id;
    }

    @Override
    public IHubUser getAuthor() {
        return author;
    }

    @Override
    public Timestamp getCreated() {
        return created;
    }

    @Override
    public List<IHubChangeItem> getChangeItems() {
        return changeItems;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof BasicHubChangeHistory)) return false;

        BasicHubChangeHistory that = (BasicHubChangeHistory) o;

        if (id != that.id) return false;
        if (author != null ? !author.equals(that.author) : that.author != null) return false;
        if (created != null ? !created.equals(that.created) : that.created != null) return false;
        return changeItems != null ? changeItems.equals(that.changeItems) : that.changeItems == null;
    }

    @Override
    public int hashCode() {
        int result = (int) (id ^ (id >>> 32));
        result = 31 * result + (author != null ? author.hashCode() : 0);
        result = 31 * result + (created != null ? created.hashCode() : 0);
        result = 31 * result + (changeItems != null ? changeItems.hashCode() : 0);
        return result;
    }
}
