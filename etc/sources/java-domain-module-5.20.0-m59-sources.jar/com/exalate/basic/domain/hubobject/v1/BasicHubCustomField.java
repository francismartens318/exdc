/*
 * Copyright (C) 2015, iDalko NV
 * All rights reserved.
 *
 *
 * THIS SOURCE CODE IS AN UNPUBLISHED PROPRIETARY TRADE SECRET OF iDalko NV, unless stated otherwise
 * in the license text.
 *
 *
 * The copyright notice above does not evidence any actual or intended publication of such source code.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
 */
package com.exalate.basic.domain.hubobject.v1;

import com.exalate.api.domain.hubobject.v1_2.HubCustomFieldType;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.io.Serializable;

public class BasicHubCustomField implements com.exalate.api.domain.hubobject.v1_6.IHubCustomField, Serializable {

    private Long id;
    private String name;
    private String uid;
    private String description;
    private HubCustomFieldType type;
    private Object value;

    private transient boolean _locked = false;

    @Nullable
    @Override
    public Long getId() {
        return id;
    }

    @Nullable
    @Override
    public String getName() {
        return name;
    }

    @Nullable
    @Override
    public String getUid() {
        return uid;
    }

    @Nullable
    @Override
    public String getDescription() {
        return description;
    }

    @Nullable
    @Override
    public HubCustomFieldType getType() {
        return type;
    }

    @Nullable
    @Override
    public Object getValue() {
        return value;
    }

    public void setType(@Nonnull HubCustomFieldType type) {
        if (!_locked) this.type = type;
    }

    public void setValue(@Nullable Object value) {
        if (!_locked) this.value = value;
    }

    public void setName(@Nonnull String name) {
        if (!_locked) this.name = name;
    }

    public void setUid(@Nonnull String uid) {
        if (!_locked) this.uid = uid;
    }

    public void setDescription(String description) {
        if (!_locked) this.description = description;
    }

    public void setId(Long id) {
        if (!_locked) this.id = id;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof BasicHubCustomField)) return false;

        BasicHubCustomField that = (BasicHubCustomField) o;

        if (id != null ? !id.equals(that.id) : that.id != null) return false;
        if (name != null ? !name.equals(that.name) : that.name != null) return false;
        //noinspection RedundantIfStatement
        if (value != null ? !value.equals(that.value) : that.value != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (name != null ? name.hashCode() : 0);
        result = 31 * result + (value != null ? value.hashCode() : 0);
        return result;
    }
    public void lock() {
        this._locked = true;
    }

    public boolean isLocked() {
        return _locked;
    }
}
