package com.exalate.basic.domain.hubobject.v1;

import com.exalate.api.domain.hubobject.IHubOrganization;
import com.exalate.api.domain.hubobject.IHubOrganizations;

import java.io.Serializable;
import java.util.List;
import java.util.Objects;

/**
 * @deprecated use ArrayList of {@link com.exalate.api.domain.hubobject.IHubOrganization}
 */
@Deprecated
public class BasicHubOrganizations implements IHubOrganizations, Serializable {

    private List<IHubOrganization> organizations;

    public BasicHubOrganizations(List<IHubOrganization> organizations) {
        this.organizations = organizations;
    }

    public List<IHubOrganization> getOrganizations() {
        return organizations;
    }

    public void setOrganizations(List<IHubOrganization> organizations) {
        this.organizations = organizations;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        BasicHubOrganizations that = (BasicHubOrganizations) o;
        return Objects.equals(organizations, that.organizations);
    }

    @Override
    public int hashCode() {
        return Objects.hash(organizations);
    }
}
