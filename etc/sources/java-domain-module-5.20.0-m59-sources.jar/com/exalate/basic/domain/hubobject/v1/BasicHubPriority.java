/*
 * Copyright (C) 2015, iDalko NV
 * All rights reserved.
 *
 *
 * THIS SOURCE CODE IS AN UNPUBLISHED PROPRIETARY TRADE SECRET OF iDalko NV, unless stated otherwise
 * in the license text.
 *
 *
 * The copyright notice above does not evidence any actual or intended publication of such source code.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
 */
package com.exalate.basic.domain.hubobject.v1;

import com.exalate.api.domain.hubobject.v1_2.IHubOption;
import com.exalate.api.domain.hubobject.v1_2.IHubPriority;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.io.Serializable;
import java.util.List;

public class BasicHubPriority implements IHubPriority, Serializable {

    private String id;
    private String name;
    private String description;

    private transient boolean _locked = false;
    @Nonnull
    @Override
    public String getId() {
        return id;
    }

    @Nonnull
    @Override
    public String getName() {
        return name;
    }

    @Nullable
    @Override
    public String getDescription() {
        return description;
    }

    public void setId(String id) {
        if (!_locked) this.id = id;
    }

    public void setName(String name) {
        if (!_locked) this.name = name;
    }

    public void setDescription(String description) {
        if (!_locked) this.description = description;
    }

    @Nullable
    @Override
    public Long getSequence() {
        return null;
    }

    @Nullable
    @Override
    public String getValue() {
        return name;
    }

    public void setValue(String value) {
        if(!_locked) this.name = value;
    }

    @Nullable
    @Override
    public Boolean isDisabled() {
        return null;
    }

    @Nullable
    @Override
    public IHubOption getParentOption() {
        return null;
    }

    @Nonnull
    @Override
    public List<IHubOption> getChildOptions() {
        return null;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof BasicHubPriority) || !(o instanceof BasicHubOption)) return false;

        if(o instanceof BasicHubPriority) {
            BasicHubPriority that = (BasicHubPriority) o;

            if (id != null ? !id.equals(that.id) : that.id != null) return false;
            //noinspection RedundantIfStatement
            if (name != null ? !name.equals(that.name) : that.name != null) return false;
        }

        if(o instanceof BasicHubOption) {
            BasicHubOption that = (BasicHubOption) o;

            if (id != null ? !id.equals(that.getId()) : that.getId() != null) return false;
            //noinspection RedundantIfStatement
            if (name != null ? !name.equals(that.getValue()) : that.getValue() != null) return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (name != null ? name.hashCode() : 0);
        return result;
    }

    public void lock() {
        if (_locked) {
            return;
        }
        this._locked = true;
    }

    public boolean isLocked() {
        return _locked;
    }
}
