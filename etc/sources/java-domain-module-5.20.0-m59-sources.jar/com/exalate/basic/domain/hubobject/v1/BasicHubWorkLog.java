/*
 * Copyright (C) 2015, Exalate NV
 * All rights reserved.
 *
 *
 * THIS SOURCE CODE IS AN UNPUBLISHED PROPRIETARY TRADE SECRET OF iDalko NV, unless stated otherwise
 * in the license text.
 *
 *
 * The copyright notice above does not evidence any actual or intended publication of such source code.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
 */
package com.exalate.basic.domain.hubobject.v1;

import com.exalate.api.domain.hubobject.v1_12.WorkLogAdjustmentMode;
import com.exalate.api.domain.hubobject.v1_2.IHubUser;
import com.exalate.api.domain.hubobject.v1_12.IHubWorkLog;
import com.exalate.api.domain.twintrace.TraceType;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.io.Serializable;
import java.util.Date;

public class BasicHubWorkLog implements IHubWorkLog, Serializable, ITraceable {

    private String id;
    private IHubUser author;
    private IHubUser updateAuthor;
    private Date startDate;
    private Long timeSpent;
    private String comment;
    private Date created;
    private Date updated;
    private String group;
    private String role;
    private String remoteId;
    private transient WorkLogAdjustmentMode adjustmentMode;
    private transient String adjustRemainingBy;
    private transient String newEstimate;

    private transient boolean _locked = false;

    @Override
    public Long getId() {
        if(id == null) return null;
        return Long.valueOf(id);
    }

    @Override
    public String getIdStr() {
        return id;
    }

    @Nullable
    @Override
    public IHubUser getAuthor() {
        return author;
    }

    @Nullable
    @Override
    public IHubUser getUpdateAuthor() {
        return updateAuthor;
    }

    @Nonnull
    @Override
    public Date getStartDate() {
        return startDate;
    }

    @Nonnull
    @Override
    public Long getTimeSpent() {
        return timeSpent;
    }

    @Nullable
    @Override
    public String getComment() {
        return comment;
    }

    @Nonnull
    @Override
    public Date getCreated() {
        return created;
    }

    @Override
    public Date getUpdated() {
        return updated;
    }

    @Nullable
    @Override
    public String getGroupLevel() {
        return group;
    }

    @Nullable
    @Override
    public String getRoleLevel() {
        return role;
    }

    @Nullable
    @Override
    public Long getRemoteId() {
        if(remoteId == null) return null;
        return Long.valueOf(remoteId);
    }

    @Nullable
    @Override
    public String getRemoteIdStr() {
        return remoteId;
    }

    @Override
    public TraceType getTraceType() {
        return TraceType.WORKLOG;
    }

    @Nonnull
    @Override
    public WorkLogAdjustmentMode getAdjustmentMode() {
        return adjustmentMode == null ? WorkLogAdjustmentMode.AUTO_ADJUST : adjustmentMode;
    }

    @Nullable
    @Override
    public String getAdjustRemainingBy() {
        return adjustRemainingBy;
    }

    @Nullable
    @Override
    public String getNewEstimate() {
        return newEstimate;
    }

    public void setId(Long id) {
        if (!_locked) this.id = String.valueOf(id);
    }

    @Override
    public void setId(String id) {
        if (!_locked) this.id = id;
    }

    public void setStartDate(Date startDate) {
        if (!_locked) this.startDate = startDate;
    }

    public void setTimeSpent(Long timeSpent) {
        if (!_locked) this.timeSpent = timeSpent;
    }

    public void setComment(String comment) {
        if (!_locked) this.comment = comment;
    }

    public void setCreated(Date created) {
        if (!_locked) this.created = created;
    }

    public void setUpdated(Date updated) {
        if (!_locked) this.updated = updated;
    }

    public void setAuthor(IHubUser author) {
        if (!_locked) this.author = author;
    }

    public void setUpdateAuthor(IHubUser updateAuthor) {
        if (!_locked) this.updateAuthor = updateAuthor;
    }

    public void setGroupLevel(@Nullable String group) {
        if (!_locked) this.group = group;
    }

    public void setRoleLevel(@Nullable String role) {
        if (!_locked) this.role = role;
    }

    public void setRemoteId(Long remoteId) {
        if (!_locked) this.remoteId = String.valueOf(remoteId);
    }

    public void setRemoteId(String remoteId) {
        if (!_locked) this.remoteId = remoteId;
    }

    public void setAutoAdjust() {
        if (!_locked) {
            this.adjustmentMode = WorkLogAdjustmentMode.AUTO_ADJUST;
            this.adjustRemainingBy = null;
            this.newEstimate = null;
        }
    }

    public void setRetain() {
        if (!_locked) {
            this.adjustmentMode = WorkLogAdjustmentMode.RETAIN;
            this.adjustRemainingBy = null;
            this.newEstimate = null;
        }
    }

    public void setManuallyAdjust(String timeForManuallyAdjustingRemainingEstimate) {
        if (!_locked) {
            this.adjustmentMode = WorkLogAdjustmentMode.ADJUST_MANUALLY;
            this.adjustRemainingBy = timeForManuallyAdjustingRemainingEstimate;
            this.newEstimate = null;
        }
    }

    public void setNew(String newRemainingEstimate) {
        if (!_locked) {
            this.adjustmentMode = WorkLogAdjustmentMode.SET_NEW;
            this.newEstimate = newRemainingEstimate;
            this.adjustRemainingBy = null;
        }
    }

    @Override
    public String toString() {
        return "BasicHubWorkLog{" +
                "@startDate=`" + startDate + '`' +
                ", @timeSpent=`" + timeSpent + '`' +
                ", @comment=`" + comment + '`' +
                ", @id=`" + id + '`' +
                ", @remoteId=`" + remoteId + '`' +
                ", @adjustmentMode=`" + adjustmentMode + '`' +
                ", @author=`" + author + '`' +
                ", @created=`" + created + '`' +
                ", @updateAuthor=`" + updateAuthor + '`' +
                ", @updated=`" + updated + '`' +
                ", @group=`" + group + "`" +
                ", @role=`" + role + "`" +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        BasicHubWorkLog that = (BasicHubWorkLog) o;
        if (id == null) return false;
        return id.equals(that.id);
    }

    @Override
    public int hashCode() {
        return id.hashCode();
    }

    public void lock() {
        if (_locked) {
            return;
        }
        this._locked = true;
        if (author != null) {
            author.lock();
        }
        if (updateAuthor != null) {
            updateAuthor.lock();
        }
    }

    public boolean isLocked() {
        return _locked;
    }
}
