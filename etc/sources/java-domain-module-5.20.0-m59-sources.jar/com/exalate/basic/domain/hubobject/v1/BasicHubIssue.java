/*
 * Copyright (C) 2015, iDalko NV
 * All rights reserved.
 *
 *
 * THIS SOURCE CODE IS AN UNPUBLISHED PROPRIETARY TRADE SECRET OF iDalko NV, unless stated otherwise
 * in the license text.
 *
 *
 * The copyright notice above does not evidence any actual or intended publication of such source code.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
 */
package com.exalate.basic.domain.hubobject.v1;

import com.exalate.api.domain.IIssueKey;
import com.exalate.api.domain.hubobject.EventTriggerContext;
import com.exalate.api.domain.hubobject.v1_17.IHubIssue;
import com.exalate.api.domain.hubobject.v1_15.IHubIssueSecurityLevel;
import com.exalate.api.domain.hubobject.v1_2.*;
import com.exalate.api.domain.hubobject.v1_3.IWorkflowContext;
import com.exalate.api.domain.hubobject.v1_15.IMutableHubIssue;
import com.exalate.basic.domain.BasicIssueKey;
import com.exalate.basic.domain.hubobject.v1.status.BasicHubStatus;
import com.google.common.collect.Maps;
import com.exalate.basic.domain.util.HubObjectLockingUtil;
import com.exalate.util.collect.NopImmutableMap;
import com.google.common.base.Function;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.InvocationTargetException;
import java.io.Serializable;
import java.util.*;

import static com.exalate.util.CollectionUtils.*;

public class BasicHubIssue implements IMutableHubIssue, IHubIssue, Serializable, IHpqcHubIssue, Map<String, Object> {
    private String key;
    private String id;
    private String summary;
    private String description;
    private IHubProject project;
    private String projectKey;
    private List<IHubComponent> components;
    private Map<String, Object> customKeys = new HashMap<>(); //TODO EXAEDIT-873 think about service now custom keys
    private Map<String, IHubCustomField> customFields = new HashMap<>();
    private Set<IHubLabel> labels;
    private Set<IHubVersion> affectedVersions;
    private Set<IHubVersion> fixVersions;
    private List<BasicHubWorkLog> workLogs;
    private IHubUser assignee;
    private Set<IHubUser> assignees;
    private Set<IHubUser> approvers;
    private IHubUser reporter;
    private IHubUser creator;
    private List<BasicHubAttachment> attachments;
    private List<BasicHubComment> comments;
    private BasicHubStatus status;
    private IHubIssueType issueType;
    private String issueTypeName;
    private IHubResolution resolution; //TODO EXAEDIT-873 Option
    private Date resolutionDate;
    private IHubPriority priority;
    private Long votes;
    private Set<IHubUser> voters;
    private Long watches;
    private Set<IHubUser> watchers;
    private String environment;
    private Date due;
    private Long originalEstimate;
    private Long estimate;
    private Long spent;
    private String severityName;
    private String commentsArea;
    private Date created;
    private Date updated;

    private String parentId;
    private IIssueKey parent;

    private Map<String, Object> entityProperties  = new HashMap<>();
    private Map<String, Object> internalMap = new HashMap<>();
    private IHubIssueSecurityLevel securityLevel;

    private transient List<BasicHubComment> addedComments;
    private transient List<BasicHubComment> changedComments;
    private transient List<BasicHubComment> removedComments;

    private transient List<BasicHubAttachment> addedAttachments;
    private transient List<BasicHubAttachment> removedAttachments;

    private transient List<BasicHubWorkLog> addedWorklogs;
    private transient List<BasicHubWorkLog> changedWorklogs;
    private transient List<BasicHubWorkLog> removedWorklogs;

    private List<BasicHubChangeHistory> basicHubChangeHistory;


    private List<BasicHubIssueLink> issueLinks;

    private EventTriggerContext eventTriggerContext = EventTriggerContext.empty();

    private transient String doTransition;
    private transient IWorkflowContext workflowContext;

    private IIssueKey entityKey;
    private String entityUrl;

    private transient boolean _locked = false;

    public void setEntityKey(@Nullable IIssueKey issueKey) {
        if(!_locked) {
            this.entityKey = issueKey;
        }
    }
    public void setEntityUrl(@Nullable String issueUrl) {
        if(!_locked) {
            this.entityUrl = issueUrl;
        }
    }
    @Override
    public void setKey(@Nullable String key) {
        if (!_locked) this.key = key;
    }

    @Override
    public void setSummary(@Nullable String summary) {
        if (!_locked) this.summary = summary;
    }

    @Override
    public void setDescription(@Nullable String description) {
        if (!_locked) this.description = description;
    }

    @Override
    public void setEnvironment(@Nullable String environment) {
        if (!_locked) this.environment = environment;
    }

    @Override
    public void setAssignee(@Nullable IHubUser assignee) {
        if (!_locked) this.assignee = assignee;
    }

    @Override
    public void setReporter(@Nullable IHubUser reporter) {
        if (!_locked) this.reporter = reporter;
    }

    @Override
    public void setStatus(@Nonnull IHubStatus status) {
        // we rely here on the fact that there is only one implementation for the IHubStatus
        // whenever we introduce another one we would need the logic to converge to a compatible status
        if (!_locked) this.status = (BasicHubStatus) status;
    }

    @Override
    public void setStatus(@Nonnull IHubOption status) {
        BasicHubStatus newStatus = new BasicHubStatus();
        newStatus.setId(((BasicHubOption) status).getIdStr());
        newStatus.setName(status.getValue());
        // we rely here on the fact that there is only one implementation for the IHubStatus
        // whenever we introduce another one we would need the logic to converge to a compatible status
        if (!_locked) this.status = newStatus;
    }


    public void setStatus(@Nonnull String statusName) {
        if(_locked) {
            return;
        }
        BasicHubStatus s = new BasicHubStatus();
        s.setName(statusName);
        this.status = s;
    }

    /**
     * @param object Resolves ambiguous calls on Groovy when argument is null for setStatus
     */
    public void setStatus(Object object) {
        if(object == null) {
            return;
        } else if(object instanceof IHubStatus) {
            setStatus((IHubStatus) object);
        } else if(object instanceof IHubOption) {
            setStatus((IHubOption) object);
        } else if(object instanceof String) {
            setStatus((String) object);
        }
        throw new IllegalArgumentException(String.format("Illegal argument type %s for setStatus", object.getClass()));
    }

    @Override
    public void setResolution(@Nullable IHubResolution resolution) {
        if (!_locked) this.resolution = resolution;
    }

    public void setResolution(@Nullable IHubOption resolution) {
        BasicHubResolution newResolution = new BasicHubResolution();
        newResolution.setName(resolution.getValue());
        newResolution.setId(((BasicHubOption)resolution).getIdStr());
        if (!_locked) this.resolution = newResolution;
    }

    /**
     * @param object Resolves ambiguous calls on Groovy when argument is null for setResolution
     */
    public void setResolution(Object object) {
        if(object == null) {
            return;
        } else if(object instanceof IHubResolution) {
            setResolution((IHubResolution) object);
        } else if(object instanceof IHubOption) {
            setResolution((IHubOption) object);
        }
        throw new IllegalArgumentException(String.format("Illegal argument type %s for setResolution", object.getClass()));
    }

    @Override
    public void setType(@Nullable IHubIssueType issueType) {
        if (!_locked) this.issueType = issueType;
    }

    @Override
    public void setType(@Nullable IHubOption issueType) {
        BasicHubIssueType newIssueType = new BasicHubIssueType();
        newIssueType.setId(((BasicHubOption) issueType).getIdStr());
        newIssueType.setName(issueType.getValue());

        if (!_locked) this.issueType = newIssueType;
    }

    /**
     * @param object Resolves ambiguous calls on Groovy when argument is null for setType
     */
    public void setType(Object object) {
        if(object == null) {
            return;
        } else if(object instanceof IHubIssueType) {
            setType((IHubIssueType) object);
        } else if(object instanceof IHubOption) {
            setType((IHubOption) object);
        }
        throw new IllegalArgumentException(String.format("Illegal argument type %s for setType", object.getClass()));
    }

    public void setIssueType(@Nullable IHubIssueType issueType) {
        if (!_locked) this.issueType = issueType;
    }

    public void setIssueType(@Nullable IHubOption issueType) {
        this.setType(issueType);
    }

    /**
     * @param object Resolves ambiguous calls on Groovy when argument is null for setIssueType
     */
    public void setIssueType(Object object) {
        if(object == null) {
            return;
        } else if(object instanceof IHubIssueType) {
            setIssueType((IHubIssueType) object);
        } else if(object instanceof IHubOption) {
            setIssueType((IHubOption) object);
        }
        throw new IllegalArgumentException(String.format("Illegal argument type %s for setIssueType", object.getClass()));
    }

    @Override
    public void setPriority(@Nonnull IHubPriority priority) {
        if (!_locked) this.priority = priority;
    }

    @Override
    public void setPriority(@Nonnull IHubOption priority) {
        BasicHubPriority newPriority = new BasicHubPriority();
        newPriority.setId(((BasicHubOption) priority).getIdStr());
        newPriority.setName(priority.getValue());

        if (!_locked) this.priority = newPriority;
    }

    /**
     * @param object Resolves ambiguous calls on Groovy when argument is null for setPriority
     */
    public void setPriority(Object object) {
        if(object == null) {
            return;
        } else if(object instanceof IHubPriority) {
            setPriority((IHubPriority) object);
        } else if(object instanceof IHubOption) {
            setPriority((IHubOption) object);
        }
        throw new IllegalArgumentException(String.format("Illegal argument type %s for setPriority", object.getClass()));
    }

    @Override
    public void setAffectedVersions(@Nonnull Set<IHubVersion> affectedVersions) {
        if (!_locked) this.affectedVersions = affectedVersions;
    }

    @Override
    public void setFixVersions(@Nonnull Set<IHubVersion> fixVersions) {
        if (!_locked) this.fixVersions = fixVersions;
    }

    @Override
    public void setDue(@Nullable Date dueDate) {
        if (!_locked) this.due = dueDate;
    }

    @Override
    public void setResolutionDate(Date resolutionDate) {
        if (!_locked) this.resolutionDate = resolutionDate;
    }

    @Override
    public Date getResolutionDate() {
        return resolutionDate;
    }

    public void setSeverityName(String severityName) {
        if (!_locked) this.severityName = severityName;
    }

    @Override
    public String getSeverityName() {
        return this.severityName;
    }

    @Override
    public void setOriginalEstimate(@Nullable Long originalEstimate) {
        if (!_locked) this.originalEstimate = originalEstimate;
    }

    @Override
    public void setRemainingEstimate(@Nullable Long remainingEstimate) {
        if (!_locked) this.estimate = remainingEstimate;
    }

    public void setEstimate(@Nullable Long estimate) {
        if (!_locked) this.estimate = estimate;
    }

    public Long getEstimate() {
        return this.estimate;
    }

    @Override
    public void setTimeSpent(@Nullable Long timeSpent) {
        if (!_locked) this.spent = timeSpent;
    }

    public void setSpent(@Nullable Long spent) {
        if (!_locked) this.spent = spent;
    }

    public Long getSpent() {
        return this.spent;
    }

    @Override
    public void setProject(@Nullable IHubProject project) {
        if (!_locked) this.project = project;
    }

    @Override
    public void setProjectKey(@Nonnull String projectKey) {
        if (!_locked) this.projectKey = projectKey;
    }

    @Override
    public void setTypeName(@Nonnull String issueTypeName) {
        if (!_locked) this.issueTypeName = issueTypeName;
    }

    @Override
    public void setComponents(@Nonnull List<IHubComponent> components) {
        if (!_locked) this.components = components;
    }

    @Override
    public void setLabels(@Nonnull Set<IHubLabel> labels) {
        if (!_locked) this.labels = labels;
    }

    @Override
    public void setWorkLogs(@Nonnull List<BasicHubWorkLog> workLogs) {
        if (!_locked) this.workLogs = workLogs;
    }

    @Override
    public void setAttachments(@Nonnull List<BasicHubAttachment> attachments) {
        if (!_locked) this.attachments = attachments;
    }

    @Override
    public void setComments(@Nonnull List<BasicHubComment> comments) {
        if (!_locked) this.comments = comments;
    }

    @Override
    public void setVotes(@Nonnull Long votes) {
        if (!_locked) this.votes = votes;
    }

    @Override
    public void setVoters(@Nonnull Set<IHubUser> voters) {
        if (!_locked) this.voters = voters;
    }

    @Override
    public void setWatches(@Nonnull Long watches) {
        if (!_locked) this.watches = watches;
    }

    @Override
    public void setWatchers(@Nonnull Set<IHubUser> watchers) {
        if (!_locked) this.watchers = watchers;
    }

    @Override
    public void setCustomKeys(@Nonnull Map<String, Object> customKeys) {
        if (!_locked) this.customKeys = customKeys;
    }

    @Override
    public void setCustomFields(@Nonnull Map<String, IHubCustomField> customFields) {
        if (!_locked) this.customFields = customFields;
    }

    @Override
    public void setDoTransition(@Nonnull String transitionName) {
        if (!_locked) {
            this.doTransition = transitionName;

            this.workflowContext = new BasicWorkflowContext();
            this.workflowContext.setTransitionName(transitionName);
        }
    }

    @Override
    public void setWorkflowContext(@Nonnull IWorkflowContext workflowContext) {
        if (!_locked) this.workflowContext = workflowContext;
    }

    public void setAddedComments(@Nonnull List<BasicHubComment> addedComments) {
        if (!_locked) this.addedComments = addedComments;
    }

    public void setChangedComments(@Nonnull List<BasicHubComment> changedComments) {
        if (!_locked) this.changedComments = changedComments;
    }

    public void setRemovedComments(@Nonnull List<BasicHubComment> removedComments) {
        if (!_locked) this.removedComments = removedComments;
    }

    public void setAddedAttachments(@Nonnull List<BasicHubAttachment> addedAttachments) {
        if (!_locked) this.addedAttachments = addedAttachments;
    }

    public void setRemovedAttachments(@Nonnull List<BasicHubAttachment> removedAttachments) {
        if (!_locked) this.removedAttachments = removedAttachments;
    }

    public void setAddedWorkLogs(List<BasicHubWorkLog> addedWorkLogs) {
        if (!_locked) this.addedWorklogs = addedWorkLogs;
    }

    public void setChangedWorkLogs(List<BasicHubWorkLog> changedWorkLogs) {
        if (!_locked) this.changedWorklogs = changedWorkLogs;
    }

    public void setRemovedWorkLogs(List<BasicHubWorkLog> removedWorkLogs) {
        if (!_locked) this.removedWorklogs = removedWorkLogs;
    }

    public void setEntityProperties(Map<String, Object> entityProperties) {
        if (!_locked) this.entityProperties = entityProperties;
    }

    @Nullable
    @Override
    public String getDoTransition() {
        return doTransition;
    }

    @Override
    @Nonnull
    public IWorkflowContext getWorkflowContext() {
        if (workflowContext == null) {
            workflowContext = new BasicWorkflowContext();
        }

        return workflowContext;
    }

    @Nonnull
    @Override
    public String getKey() {
        return key;
    }

    @Nullable
    @Override
    public String getSummary() {
        return summary;
    }

    @Nullable
    @Override
    public String getDescription() {
        return description;
    }

    @Nullable
    @Override
    public String getEnvironment() {
        return environment;
    }

    @Nullable
    @Override
    public IHubUser getAssignee() {
        return assignee;
    }

    @Nullable
    @Override
    public IHubUser getReporter() {
        return reporter;
    }

    @Nonnull
    @Override
    public IHubStatus getStatus() {
        return status;
    }

    @Nullable
    @Override
    public IHubResolution getResolution() {
        return resolution;
    }

    @Nonnull
    @Override
    public IHubIssueType getType() {
        return issueType;
    }

    @Nonnull
    public IHubIssueType getIssueType() {
        return issueType;
    }


    @Nonnull
    @Override
    public IHubPriority getPriority() {
        return priority;
    }

    @Nonnull
    @Override
    public Set<IHubVersion> getAffectedVersions() {
        return affectedVersions = toNonNull(!_locked, affectedVersions);
    }

    @Nonnull
    @Override
    public Set<IHubVersion> getFixVersions() {
        return fixVersions = toNonNull(!_locked, fixVersions);
    }

    @Nullable
    @Override
    public Date getDue() {
        return due;
    }

    @Nullable
    @Override
    public Long getOriginalEstimate() {
        return originalEstimate;
    }

    @Nullable
    @Override
    public Long getRemainingEstimate() {
        return estimate;
    }

    @Nullable
    @Override
    public Long getTimeSpent() {
        return spent;
    }

    @Nullable
    @Override
    public IHubProject getProject() {
        return project;
    }

    @Nullable
    public String getProjectKey() {
        if (this.projectKey == null && this.project != null) {
            return project.getKey();
        }
        return projectKey;
    }

    public String getTypeName() {
        if (this.issueType != null && this.issueTypeName == null) {
            return this.issueType.getName();
        }
        return issueTypeName;
    }

    @Nonnull
    @Override
    public List<IHubComponent> getComponents() {
        return this.components = toNonNull(!_locked, components);
    }

    @Nonnull
    @Override
    public List<BasicHubWorkLog> getWorkLogs() {
        return this.workLogs = toNonNull(!_locked, workLogs);
    }

    @Nonnull
    @Override
    public Map<String, Object> getCustomKeys() {
        return this.customKeys = toNonNull(!_locked, customKeys);
    }

    @Nonnull
    @Override
    public Map<String, IHubCustomField> getCustomFields() {
        return this.customFields = toNonNull(!_locked, customFields);
    }

    @Nonnull
    @Override
    public Set<IHubLabel> getLabels() {
        return this.labels = toNonNull(!_locked, labels);
    }

    @Nonnull
    @Override
    public List<BasicHubAttachment> getAttachments() {
        return this.attachments = toNonNull(!_locked, attachments);
    }

    @Nonnull
    @Override
    public List<BasicHubComment> getComments() {
        return this.comments = toNonNull(!_locked, comments);
    }

    @Nonnull
    @Override
    public Long getVotes() {
        return votes;
    }

    @Nonnull
    @Override
    public Set<IHubUser> getVoters() {
        return this.voters = toNonNull(!_locked, voters);
    }

    @Nonnull
    @Override
    public Long getWatches() {
        return watches;
    }

    @Nonnull
    @Override
    public Set<IHubUser> getWatchers() {
        return this.watchers = toNonNull(!_locked, watchers);
    }

    @Nonnull
    @Override
    public List<BasicHubComment> getAddedComments() {
        return this.addedComments = toNonNull(!_locked, addedComments);
    }

    @Nonnull
    @Override
    public List<BasicHubComment> getChangedComments() {
        return this.changedComments = toNonNull(!_locked, changedComments);
    }

    @Nonnull
    @Override
    public List<BasicHubComment> getRemovedComments() {
        return this.removedComments = toNonNull(!_locked, removedComments);
    }

    @Nonnull
    @Override
    public List<BasicHubAttachment> getAddedAttachments() {
        return this.addedAttachments = toNonNull(!_locked, addedAttachments);
    }

    @Nonnull
    @Override
    public List<BasicHubAttachment> getRemovedAttachments() {
        return this.removedAttachments = toNonNull(!_locked, removedAttachments);
    }

    @Nonnull
    @Override
    public List<BasicHubWorkLog> getAddedWorkLogs() {
        return toNonNull(!_locked, addedWorklogs);
    }

    @Nonnull
    @Override
    public List<BasicHubWorkLog> getChangedWorkLogs() {
        return toNonNull(!_locked, changedWorklogs);
    }

    @Nonnull
    @Override
    public List<BasicHubWorkLog> getRemovedWorkLogs() {
        return toNonNull(!_locked, removedWorklogs);
    }

    @Override
    public String getCommentsArea() {
        return commentsArea;
    }

    public void setCommentsArea(String commentsArea) {
        if (!_locked) this.commentsArea = commentsArea;
    }

    @Override
    public int size() {
        return internalMap.size();
    }

    @Override
    public boolean isEmpty() {
        return false;
    }

    @Override
    public boolean containsKey(Object key) {
        return internalMap.containsKey(key);
    }

    @Override
    public boolean containsValue(Object value) {
        return internalMap.containsValue(value);
    }

    @Override
    public Object get(Object key) {
        try {
            for (PropertyDescriptor propertyDescriptor : Introspector.getBeanInfo(this.getClass(), Object.class).getPropertyDescriptors()) {
                if(propertyDescriptor.getName().equals(key)) {
                    return propertyDescriptor.getReadMethod().invoke(this);
                }
            }
        } catch (IntrospectionException | IllegalAccessException | InvocationTargetException e) {
            return new RuntimeException("Bug situation, couldn't retrieve field "+key, e);
        }
        try {
            IHubCustomField customField = this.customFields.get(key);
            if (customField != null) {
                return customField.getValue();
            }
        }catch (Exception ignored){

        }
        return internalMap.get(key);
    }

    public void setInternalMap(Map<String, Object> internalMap) {
        if (!_locked) this.internalMap = internalMap;
    }

    @Override
    public Object put(String key, Object value) {
        if (_locked) { return null; }
        try{
            IHubCustomField customField = this.customFields.get(key);
            if (customField != null) {
                IHubCustomField iHubCustomField = customField;
                Object prevValue = iHubCustomField.getValue();
                ((BasicHubCustomField) iHubCustomField).setValue(value);
                return prevValue;
            }
        }catch(Exception ignored){

        }

        return internalMap.put(key, value);
    }

    @Override
    public Object remove(Object key) {
        if (_locked) { return null; }
        return internalMap.remove(key);
    }

    @Override
    public void putAll(Map<? extends String, ?> m) {
        if (_locked) { return; }
        // please consider impact on the EASE-7798 fix (ScriptGeneratorService) which relies on putAll not to call issue tracker rest api
        internalMap.putAll(m);
    }

    @Override
    public void clear() {
        if (_locked) { return; }
        internalMap.clear();
    }

    @Override
    public Set<String> keySet() {
        return internalMap.keySet();
    }

    @Override
    public Collection<Object> values() {
        return internalMap.values();
    }

    @Override
    public Set<Entry<String, Object>> entrySet() {
        return internalMap.entrySet();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof BasicHubIssue)) return false;

        BasicHubIssue that = (BasicHubIssue) o;

        if (!getAffectedVersions().equals(that.getAffectedVersions())) return false;
        if (assignee != null ? !assignee.equals(that.assignee) : that.assignee != null) return false;
        if (!getAttachments().equals(that.getAttachments())) return false;
        if (!getComments().equals(that.getComments())) return false;
        if (!getCustomFields().equals(that.getCustomFields())) return false;
        if (!getCustomKeys().equals(that.getCustomKeys())) return false;
        if (!internalMap.equals(that.internalMap)) return false;
        if (description != null ? !description.equals(that.description) : that.description != null) return false;
        if (due != null ? !due.equals(that.due) : that.due != null) return false;
        if (environment != null ? !environment.equals(that.environment) : that.environment != null) return false;
        if (originalEstimate != null ? !originalEstimate.equals(that.originalEstimate) : that.originalEstimate != null)
            return false;
        if (!getFixVersions().equals(that.getFixVersions())) return false;
        if (issueType != null ? !issueType.equals(that.issueType) : that.issueType != null) return false;
        if (key != null ? !key.equals(that.key) : that.key != null) return false;
        if (severityName != null ? !severityName.equals(that.severityName) : that.severityName != null) return false;
        if (!internalMap.equals(that.internalMap)) return false;
        if (securityLevel != null ? !securityLevel.equals(that.securityLevel) : that.securityLevel != null)
            return false;
        if (issueTypeName != null ? !issueTypeName.equals(that.issueTypeName) : that.issueTypeName != null)
            return false;
        if (commentsArea != null ? !commentsArea.equals(that.commentsArea) : that.commentsArea != null) return false;
        if (!getLabels().equals(that.getLabels())) return false;
        if (priority != null ? !priority.equals(that.priority) : that.priority != null) return false;
        if (project != null ? !project.equals(that.project) : that.project != null) return false;
        if (!getComponents().equals(that.getComponents())) return false;
        if (estimate != null ? !estimate.equals(that.estimate) : that.estimate != null) return false;
        if (reporter != null ? !reporter.equals(that.reporter) : that.reporter != null) return false;
        if (resolution != null ? !resolution.equals(that.resolution) : that.resolution != null) return false;
        if (spent != null ? !spent.equals(that.spent) : that.spent != null) return false;
        if (status != null ? !status.equals(that.status) : that.status != null) return false;
        if (summary != null ? !summary.equals(that.summary) : that.summary != null) return false;
        if (!getVoters().equals(that.getVoters())) return false;
        if (votes != null ? !votes.equals(that.votes) : that.votes != null) return false;
        if (!getWatchers().equals(that.getWatchers())) return false;
        if (watches != null ? !watches.equals(that.watches) : that.watches != null) return false;
        if (!getWorkLogs().equals(that.getWorkLogs())) return false;
        if (!getAddedAttachments().equals(that.getAddedAttachments())) return false;
        if (!getRemovedAttachments().equals(that.getRemovedAttachments())) return false;
        if (!getAddedComments().equals(that.getAddedComments())) return false;
        if (!getRemovedComments().equals(that.getRemovedComments())) return false;
        if (!getChangedComments().equals(that.getChangedComments())) return false;
        if (!getAddedWorkLogs().equals(that.getAddedWorkLogs())) return false;
        if (!getChangedWorkLogs().equals(that.getChangedWorkLogs())) return false;
        //noinspection RedundantIfStatement
        if (!getRemovedWorkLogs().equals(that.getRemovedWorkLogs())) return false;
        if (workflowContext != null ? !workflowContext.equals(that.workflowContext) : that.workflowContext != null)
            return false;

        return true;
    }


    /**
     * This method is used on jiranode, where we want to check if two hub issues are equals excluding comments
     * to validate if we should update it if is a non editable state (where adding comments is allowed)
     */
    public boolean equalsExcludeComments(Object o) {
        if (this == o) return true;
        if (!(o instanceof BasicHubIssue)) return false;

        BasicHubIssue that = (BasicHubIssue) o;

        if (!getAffectedVersions().equals(that.getAffectedVersions())) return false;
        if (assignee != null ? !assignee.equals(that.assignee) : that.assignee != null) return false;
        if (!getAttachments().equals(that.getAttachments())) return false;
        if (!getCustomFields().equals(that.getCustomFields())) return false;
        if (!getCustomKeys().equals(that.getCustomKeys())) return false;
        if (description != null ? !description.equals(that.description) : that.description != null) return false;
        if (due != null ? !due.equals(that.due) : that.due != null) return false;
        if (environment != null ? !environment.equals(that.environment) : that.environment != null) return false;
        if (!internalMap.equals(that.internalMap)) return false;
        if (originalEstimate != null ? !originalEstimate.equals(that.originalEstimate) : that.originalEstimate != null)
            return false;
        if (!getFixVersions().equals(that.getFixVersions())) return false;
        if (issueType != null ? !issueType.equals(that.issueType) : that.issueType != null) return false;
        if (key != null ? !key.equals(that.key) : that.key != null) return false;
        if (severityName != null ? !severityName.equals(that.severityName) : that.severityName != null) return false;
        if (securityLevel != null ? !securityLevel.equals(that.securityLevel) : that.securityLevel != null)
            return false;
        if (issueTypeName != null ? !issueTypeName.equals(that.issueTypeName) : that.issueTypeName != null)
            return false;
        if (commentsArea != null ? !commentsArea.equals(that.commentsArea) : that.commentsArea != null) return false;
        if (!getLabels().equals(that.getLabels())) return false;
        if (priority != null ? !priority.equals(that.priority) : that.priority != null) return false;
        if (project != null ? !project.equals(that.project) : that.project != null) return false;
        if (!getComponents().equals(that.getComponents())) return false;
        if (estimate != null ? !estimate.equals(that.estimate) : that.estimate != null) return false;
        if (reporter != null ? !reporter.equals(that.reporter) : that.reporter != null) return false;
        if (resolution != null ? !resolution.equals(that.resolution) : that.resolution != null) return false;
        if (spent != null ? !spent.equals(that.spent) : that.spent != null) return false;
        if (status != null ? !status.equals(that.status) : that.status != null) return false;
        if (summary != null ? !summary.equals(that.summary) : that.summary != null) return false;
        if (!getVoters().equals(that.getVoters())) return false;
        if (votes != null ? !votes.equals(that.votes) : that.votes != null) return false;
        if (!getWatchers().equals(that.getWatchers())) return false;
        if (watches != null ? !watches.equals(that.watches) : that.watches != null) return false;
        if (!getWorkLogs().equals(that.getWorkLogs())) return false;
        if (!getAddedAttachments().equals(that.getAddedAttachments())) return false;
        if (!getRemovedAttachments().equals(that.getRemovedAttachments())) return false;
        if (!getAddedWorkLogs().equals(that.getAddedWorkLogs())) return false;
        if (!getChangedWorkLogs().equals(that.getChangedWorkLogs())) return false;
        //noinspection RedundantIfStatement
        if (!getRemovedWorkLogs().equals(that.getRemovedWorkLogs())) return false;
        if (workflowContext != null ? !workflowContext.equals(that.workflowContext) : that.workflowContext != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = key != null ? key.hashCode() : 0;
        result = 31 * result + (summary != null ? summary.hashCode() : 0);
        result = 31 * result + (description != null ? description.hashCode() : 0);
        result = 31 * result + (project != null ? project.hashCode() : 0);
        result = 31 * result + (components != null ? components.hashCode() : 0);
        result = 31 * result + (customKeys != null ? customKeys.hashCode() : 0);
        result = 31 * result + (internalMap != null ? internalMap.hashCode() : 0);
        result = 31 * result + (customFields != null ? customFields.hashCode() : 0);
        result = 31 * result + (labels != null ? labels.hashCode() : 0);
        result = 31 * result + (affectedVersions != null ? affectedVersions.hashCode() : 0);
        result = 31 * result + (fixVersions != null ? fixVersions.hashCode() : 0);
        result = 31 * result + (workLogs != null ? workLogs.hashCode() : 0);
        result = 31 * result + (assignee != null ? assignee.hashCode() : 0);
        result = 31 * result + (reporter != null ? reporter.hashCode() : 0);
        result = 31 * result + (internalMap != null ? internalMap.hashCode() : 0);
        result = 31 * result + (attachments != null ? attachments.hashCode() : 0);
        result = 31 * result + (comments != null ? comments.hashCode() : 0);
        result = 31 * result + (status != null ? status.hashCode() : 0);
        result = 31 * result + (issueType != null ? issueType.hashCode() : 0);
        result = 31 * result + (resolution != null ? resolution.hashCode() : 0);
        result = 31 * result + (priority != null ? priority.hashCode() : 0);
        result = 31 * result + (votes != null ? votes.hashCode() : 0);
        result = 31 * result + (watches != null ? watches.hashCode() : 0);
        result = 31 * result + (environment != null ? environment.hashCode() : 0);
        result = 31 * result + (due != null ? due.hashCode() : 0);
        result = 31 * result + (voters != null ? voters.hashCode() : 0);
        result = 31 * result + (watchers != null ? watchers.hashCode() : 0);
        result = 31 * result + (originalEstimate != null ? originalEstimate.hashCode() : 0);
        result = 31 * result + (securityLevel != null ? securityLevel.hashCode() : 0);
        result = 31 * result + (estimate != null ? estimate.hashCode() : 0);
        result = 31 * result + (spent != null ? spent.hashCode() : 0);
        result = 31 * result + (addedAttachments != null ? addedAttachments.hashCode() : 0);
        result = 31 * result + (removedAttachments != null ? removedAttachments.hashCode() : 0);
        result = 31 * result + (addedWorklogs != null ? addedWorklogs.hashCode() : 0);
        result = 31 * result + (changedWorklogs != null ? changedWorklogs.hashCode() : 0);
        result = 31 * result + (removedWorklogs != null ? removedWorklogs.hashCode() : 0);
        result = 31 * result + (severityName != null ? severityName.hashCode() : 0);
        result = 31 * result + (issueTypeName != null ? issueTypeName.hashCode() : 0);
        result = 31 * result + (commentsArea != null ? commentsArea.hashCode() : 0);
        result = 31 * result + (workflowContext != null ? workflowContext.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return String.format("{ @key : %s, @summary: %s}", key, summary);
    }

    @Override
    public void setCreated(Date created) {
        if (!_locked) this.created = created;
    }

    @Override
    public void setUpdated(Date updated) {
        if (!_locked) this.updated = updated;
    }

    @Override
    public Date getUpdated() {
        return updated;
    }

    @Override
    public Date getCreated() {
        return created;
    }

    public IIssueKey getParent() {
        return parent;
    }

    public void setParent(IIssueKey parent) {
        if(!_locked) {
            this.parent = parent;
            this.parentId = parent != null ? parent.getIdStr() : null;
        }
    }

    public String getParentId() {
        if(parent == null && parentId == null)  {
            return null;
        }

        if(parent != null) {
            return parent.getIdStr();
        }

        return parentId;
    }

    public void setParentId(String parentId) {
        if (!_locked) {
            this.parentId = parentId;
        }
    }

    public void setParentId(Long parentId) {
        if (_locked) { return; }
        this.parentId = String.valueOf(parentId);
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        if (!_locked) this.id = id;
    }

    @Nonnull
    @Override
    public Map<String, Object> getEntityProperties() {
        return this.entityProperties = toNonNull(!_locked, entityProperties);
    }

    @Nonnull
    @Override
    public List<BasicHubIssueLink> getIssueLinks() {
        return this.issueLinks = toNonNull(!_locked, issueLinks);
    }

    public void setIssueLinks(List<BasicHubIssueLink> issueLinks) {
        if (!_locked) this.issueLinks = toNonNullMutableList(issueLinks);
    }


    @Nonnull
    @Override
    public List<BasicHubChangeHistory> getChangeHistory() {
        return this.basicHubChangeHistory = toNonNull(!_locked, basicHubChangeHistory);
    }

    @Override
    public IHubUser getCreator() {
        return creator;
    }

    public void setCreator(IHubUser creator) {
        if (!_locked) this.creator = creator;
    }

    public void setChangeHistory(List<BasicHubChangeHistory> basicHubChangeHistory) {
        if (!_locked) this.basicHubChangeHistory = basicHubChangeHistory;
    }

    @Override
    public void setDetectedBy(@Nullable IHubUser reporter) {
        if (!_locked) this.reporter = reporter;
    }

    @Override
    public IHubUser getDetectedBy() {
        return reporter;
    }

    @Override
    public void setSeverity(String severityName) {
        if (!_locked) this.severityName = severityName;
    }

    @Override
    public String getSeverity() {
        return severityName;
    }

    @Override
    public void setDevComments(String commentsArea) {
        if (!_locked) this.commentsArea = commentsArea;
    }

    @Override
    public String getDevComments() {
        return commentsArea;
    }

    @Override
    public void setEstimatedFixTime(@Nullable Long originalEstimate) {
        if (!_locked) this.originalEstimate = originalEstimate;
    }

    @Override
    public Long getEstimatedFixTime() {
        return originalEstimate;
    }

    @Override
    public void setActualFixTime(@Nullable Long timeSpent) {
        if (!_locked) this.setTimeSpent(timeSpent);
    }

    @Override
    public Long getActualFixTime() {
        return getTimeSpent();
    }

    @Override
    public void setDetectedInRel(@Nonnull Set<IHubVersion> affectedVersions) {
        if (!_locked) this.setAffectedVersions(affectedVersions);
    }

    @Override
    public Set<IHubVersion> getDetectedInRel() {
        return affectedVersions;
    }

    @Override
    public void setTargetRel(@Nonnull Set<IHubVersion> fixVersions) {
        if (!_locked) this.fixVersions = fixVersions;
    }

    @Override
    public Set<IHubVersion> getTargetRel() {
        return fixVersions;
    }

    @Override
    public void setClosingDate(Date resolutionDate) {
        if (!_locked) this.resolutionDate = resolutionDate;
    }

    @Override
    public Date getClosingDate() {
        return resolutionDate;
    }

    @Override
    public void setOwner(@Nullable IHubUser assignee) {
        if (!_locked) this.assignee = assignee;
    }

    @Override
    public IHubUser getOwner() {
        return assignee;
    }

    public void setUserFields(@Nonnull Map<String, IHubCustomField> customFields) {
        if (!_locked) this.customFields = customFields;
    }

    public Map<String, IHubCustomField> getUserFields() {
        return customFields;
    }

    public IHubIssueSecurityLevel getSecurityLevel() {
        return securityLevel;
    }

    public void setSecurityLevel(IHubIssueSecurityLevel securityLevel) {
        if (!_locked) this.securityLevel = securityLevel;
    }

    public Set<IHubUser> getAssignees() {
        return assignees;
    }

    public void setAssignees(Set<IHubUser> assignees) {
        if (!_locked) this.assignees = assignees;
    }

    @Nullable
    @Override
    public Set<IHubUser> getApprovers() {
        return approvers;
    }

    public void setApprovers(Set<IHubUser> approvers) {
        this.approvers = approvers;
    }

    @Override
    public EventTriggerContext getEventTriggerContext() {
        return eventTriggerContext;
    }


    @Override
    public void setEventTriggerContext(EventTriggerContext eventTriggerContext) {
        this.eventTriggerContext = eventTriggerContext;
    }


    @Override
    public String getEntityName() {
        return "issue";
    }

    @Override
    public IIssueKey getEntityKey() {
        return entityKey;
    }

    @Override
    public String getEntityUrl() {
        return entityUrl;
    }

    public void lock() {
        if (_locked) {
            return;
        }
        this._locked = true;
        if (project != null) {
            project.lock();
        }
        if (customKeys != null) {
            customKeys = new NopImmutableMap<String, Object>(customKeys);
        }
        if (customFields != null) {
            customFields = new NopImmutableMap<String, IHubCustomField>(
                    Maps.transformValues(customFields, new Function<IHubCustomField, IHubCustomField>() {
                        @Nullable
                        @Override
                        public IHubCustomField apply(@Nullable IHubCustomField cf) {
                            if (cf == null) {
                                return null;
                            }
                            cf.lock();
                            return cf;
                        }
                    })
            );
        }
        if (labels != null) {
            labels = HubObjectLockingUtil.lock(labels);
        }
        if (affectedVersions != null) {
            affectedVersions = HubObjectLockingUtil.lock(affectedVersions);
        }
        if (fixVersions != null) {
            fixVersions = HubObjectLockingUtil.lock(fixVersions);
        }
        if (workLogs != null) {
            workLogs = HubObjectLockingUtil.lock(workLogs);
        }
        if (assignee != null) {
            assignee.lock();
        }
        if (assignees != null) {
            assignees = HubObjectLockingUtil.lock(assignees);
        }
        if (reporter != null) {
            reporter.lock();
        }
        if (creator != null) {
            creator.lock();
        }
        if (comments != null) {
            comments = HubObjectLockingUtil.lock(comments);
        }
        if (status != null) {
            status.lock();
        }
        if (resolution != null) {
            resolution.lock();
        }
        if (priority != null) {
            priority.lock();
        }
        if (voters != null) {
            voters = HubObjectLockingUtil.lock(voters);
        }
        if (watchers != null) {
            watchers = HubObjectLockingUtil.lock(watchers);
        }
        if (entityProperties != null) {
            entityProperties = new NopImmutableMap<String, Object>(entityProperties);
        }
        if (securityLevel != null) {
            securityLevel.lock();
        }
        if (internalMap != null) {
            internalMap = new NopImmutableMap<String, Object>(internalMap);
        }
    }

    public boolean isLocked() {
        return _locked;
    }
}
