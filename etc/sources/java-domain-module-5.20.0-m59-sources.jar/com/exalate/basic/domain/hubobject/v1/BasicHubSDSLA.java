package com.exalate.basic.domain.hubobject.v1;

import com.exalate.api.domain.hubobject.v1_5.IHubSDSLA;

import java.io.Serializable;

public class BasicHubSDSLA implements IHubSDSLA, Serializable {

    private String jsonRepresentation;

    @Override
    public String getJsonRepresentation() {
        return this.jsonRepresentation;
    }

    @Override
    public void setJsonRepresentation(String json) {
        this.jsonRepresentation = json;
    }


}
