package com.exalate.basic.domain.hubobject.v1;

import com.exalate.api.domain.hubobject.v1_10.IHubLexoRank;

import javax.annotation.Nullable;

public class BasicHubLexoRank implements IHubLexoRank {
    private String value;

    public BasicHubLexoRank() {
    }

    public BasicHubLexoRank(@Nullable String value) {
        this.value = value;
    }

    @Override
    public String getValue() {
        return value;
    }

    public void setValue(@Nullable String value) {
        this.value = value;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof BasicHubLexoRank)) return false;

        BasicHubLexoRank that = (BasicHubLexoRank) o;

        return value != null ? value.equals(that.value) : that.value == null;

    }

    @Override
    public int hashCode() {
        return value != null ? value.hashCode() : 0;
    }
}
