package com.exalate.basic.domain.hubobject.v1;

import com.exalate.api.domain.hubobject.v1_2.IHubUser;
import com.exalate.api.domain.hubobject.v1_3.IWorkflowContext;
import org.apache.commons.lang3.StringUtils;

import javax.annotation.Nullable;
import java.util.Objects;

public class BasicWorkflowContext implements IWorkflowContext {

    private String transitionName;
    private IHubUser executor;
    private BasicHubComment comment;
    private boolean checked;

    @Override
    @Nullable
    public String getTransitionName() {
        return transitionName;
    }

    @Override
    public void setTransitionName(@Nullable String transitionName) {
        this.transitionName = transitionName;
    }

    @Override
    public boolean hasTransitionName() {
        return StringUtils.isNotBlank(transitionName);
    }

    @Override
    @Nullable
    public IHubUser getExecutor() {
        return executor;
    }

    @Override
    public void setExecutor(@Nullable IHubUser executor) {
        this.executor = executor;
    }

    @Override
    public boolean hasExecutor() {
        return executor != null && StringUtils.isNotBlank(executor.getKey());
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        BasicWorkflowContext that = (BasicWorkflowContext) o;
        return Objects.equals(transitionName, that.transitionName) &&
                Objects.equals(executor, that.executor);
    }

    @Override
    public int hashCode() {
        return Objects.hash(transitionName, executor);
    }

    @Override
    public boolean isChecked() {
        return checked;
    }

    @Override
    public void setChecked(boolean checked) {
        this.checked = checked;
    }

    @Override
    public BasicHubComment getComment() {
        return comment;
    }

    @Override
    public void setComment(BasicHubComment comment) {
        this.comment = comment;
    }
}
