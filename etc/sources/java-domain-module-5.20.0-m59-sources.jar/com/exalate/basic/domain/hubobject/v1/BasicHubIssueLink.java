package com.exalate.basic.domain.hubobject.v1;

import com.exalate.api.domain.hubobject.v1_15.IHubIssueLink;

import java.util.Objects;

public class BasicHubIssueLink implements IHubIssueLink {

    private Long otherIssueId;

    private String linkName, linkTypeName;
    private IssueLinkType linkType;
    private String url;
    private Boolean isOutward;

    public BasicHubIssueLink(Long otherIssueId,
                             String linkName,
                             String linkTypeName,
                             IssueLinkType linkType,
                             String url,
                             Boolean isOutward) {
        this.otherIssueId = otherIssueId;
        this.linkName = linkName;
        this.linkTypeName = linkTypeName;
        this.linkType = linkType;
        this.url = url;
        this.isOutward = isOutward;
    }

    @Override
    public String getLinkTypeName() {
        return linkTypeName;
    }

    @Override
    public String getLinkName() {
        return linkName;
    }

    @Override
    public Long getOtherIssueId() {
        return otherIssueId;
    }

    @Override
    public String getIssueLinkType() {
        return linkType.name();
    }

    @Override
    public String getUrl() {
        return url;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        BasicHubIssueLink that = (BasicHubIssueLink) o;
        return isOutward() == that.isOutward() &&
                Objects.equals(getOtherIssueId(), that.getOtherIssueId()) &&
                Objects.equals(getLinkName(), that.getLinkName());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getOtherIssueId(), getLinkName(), isOutward());
    }

    @Override
    public Boolean isOutward() {
        return isOutward;
    }

    public enum IssueLinkType{
        REMOTE_URL, ISSUE
    }
}
