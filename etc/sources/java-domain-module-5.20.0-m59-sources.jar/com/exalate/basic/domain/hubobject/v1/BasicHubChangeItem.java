package com.exalate.basic.domain.hubobject.v1;

import com.exalate.api.domain.hubobject.v1_15.IHubChangeItem;

public class BasicHubChangeItem implements IHubChangeItem {
    private String from, fromValue, to, toValue, field, fieldType;

    public BasicHubChangeItem(String from,
                              String fromValue,
                              String to,
                              String toValue,
                              String field,
                              String fieldType) {
        this.from = from;
        this.fromValue = fromValue;
        this.to = to;
        this.toValue = toValue;
        this.field = field;
        this.fieldType = fieldType;
    }

    @Override
    public String getField() {
        return field;
    }

    @Override
    public String getFrom() {
        return from;
    }

    @Override
    public String getFromValue() {
        return fromValue;
    }

    @Override
    public String getToValue() {
        return toValue;
    }

    @Override
    public String getTo() {
        return to;
    }

    public String getFieldType() {
        return fieldType;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof BasicHubChangeItem)) return false;

        BasicHubChangeItem that = (BasicHubChangeItem) o;

        if (from != null ? !from.equals(that.from) : that.from != null) return false;
        if (fromValue != null ? !fromValue.equals(that.fromValue) : that.fromValue != null) return false;
        if (to != null ? !to.equals(that.to) : that.to != null) return false;
        if (toValue != null ? !toValue.equals(that.toValue) : that.toValue != null) return false;
        if (field != null ? !field.equals(that.field) : that.field != null) return false;
        return fieldType != null ? fieldType.equals(that.fieldType) : that.fieldType == null;
    }

    @Override
    public int hashCode() {
        int result = from != null ? from.hashCode() : 0;
        result = 31 * result + (fromValue != null ? fromValue.hashCode() : 0);
        result = 31 * result + (to != null ? to.hashCode() : 0);
        result = 31 * result + (toValue != null ? toValue.hashCode() : 0);
        result = 31 * result + (field != null ? field.hashCode() : 0);
        result = 31 * result + (fieldType != null ? fieldType.hashCode() : 0);
        return result;
    }
}
