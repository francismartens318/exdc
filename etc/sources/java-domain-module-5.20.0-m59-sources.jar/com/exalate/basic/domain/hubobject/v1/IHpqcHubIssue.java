package com.exalate.basic.domain.hubobject.v1;


import com.exalate.api.domain.hubobject.v1_2.IHubCustomField;
import com.exalate.api.domain.hubobject.v1_2.IHubUser;
import com.exalate.api.domain.hubobject.v1_2.IHubVersion;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.Date;
import java.util.Map;
import java.util.Set;

public interface IHpqcHubIssue {

    public void setDetectedBy(@Nullable IHubUser reporter);
    public IHubUser getDetectedBy();

    public void setSeverity(String severityName);
    public String getSeverity();

    public void setDevComments(String commentsArea);
    public String getDevComments();

    public void setEstimatedFixTime(@Nullable Long originalEstimate);
    public Long getEstimatedFixTime();

    public void setActualFixTime(@Nullable Long timeSpent);
    public Long getActualFixTime();

    public void setDetectedInRel(@Nonnull Set<IHubVersion> affectedVersions);
    public Set<IHubVersion> getDetectedInRel();

    public void setTargetRel(@Nonnull Set<IHubVersion> fixVersions);
    public Set<IHubVersion> getTargetRel();


    public void setClosingDate(Date resolutionDate);
    public Date getClosingDate();

    public void setOwner(@Nullable IHubUser assignee);
    public IHubUser getOwner();

    public void setUserFields(@Nonnull Map<String, IHubCustomField> customFields);
    public Map<String, IHubCustomField> getUserFields();

}
