package com.exalate.basic.domain.hubobject.v1;

import com.exalate.api.domain.IIssueKey;
import com.exalate.api.domain.hubobject.EventTriggerContext;
import com.exalate.api.domain.hubobject.v1_11.IHubSprint;
import com.exalate.basic.domain.BasicIssueKey;
import com.google.common.collect.Lists;
import com.exalate.api.exception.IssueTrackerException;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.Date;
import java.util.List;
import java.util.Objects;

public class BasicHubSprint implements IHubSprint {

    private String id;
    private String state;
    private String name;
    private String originBoardId;
    @Nullable private Date startDate;
    @Nullable private Date endDate;
    @Nullable private Date completeDate;
    @Nullable private Long sequence;
    @Nullable private String goal;
    @Nonnull private EventTriggerContext eventTriggerContext = EventTriggerContext.empty();
    private String entityUrl;

    @Override
    public String getId() {
        return id;
    }

    public IIssueKey getEntityKey() {
        return new BasicIssueKey(
                id, id, "sprint"
        );
    }

    @Override
    public String getEntityUrl() {
        return entityUrl;
    }

    public void setEntityUrl(@Nullable String issueUrl) {
        this.entityUrl = issueUrl;
    }

    @Override
    public void setId(String id) {
        this.id = id;
    }

    @Override
    public String getState() {
        return state;
    }

    @Override
    public void setState(String state) {
        this.state = state;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }

    @Override
    @Nullable
    public Date getStartDate() {
        return startDate;
    }

    @Override
    public void setStartDate(@Nullable Object startDate) {
        if(startDate == null) {
            this.startDate = null;
        } else {
            if(startDate instanceof Date) {
                this.startDate = (Date)startDate;
            } else if(startDate instanceof Double) {
                this.startDate = new Date(((Double)startDate).longValue());
            } else {
                throw new RuntimeException("Can not set startDate field for sprint." + startDate.getClass().getName() + " is not assignable for startDate.");
            }
        }
    }

    @Override
    @Nullable
    public Date getEndDate() {
        return endDate;
    }

    @Override
    public void setEndDate(@Nullable Object endDate) {
        if(endDate == null) {
            this.endDate = null;
        } else {
            if(endDate instanceof Date) {
                this.endDate = (Date)endDate;
            } else if(endDate instanceof Double) {
                this.endDate = new Date(((Double)endDate).longValue());
            } else {
                throw new RuntimeException("Can not set endDate field for sprint." + endDate.getClass().getName() + " is not assignable for endDate.");
            }
        }
    }

    @Override
    @Nullable
    public Date getCompleteDate() {
        return completeDate;
    }

    @Override
    public void setCompleteDate(@Nullable Object completeDate) {
        if(completeDate == null) {
            this.completeDate = null;
        } else {
            if(completeDate instanceof Date) {
                this.completeDate = (Date)endDate;
            } else if(completeDate instanceof Double) {
                this.completeDate = new Date(((Double)completeDate).longValue());
            } else {
                throw new RuntimeException("Can not set completeDate field for sprint." + completeDate.getClass().getName() + " is not assignable for completeDate.");
            }
        }
    }

    @Override
    @Nullable
    public Long getSequence() {
        return sequence;
    }

    @Override
    public void setSequence(@Nullable Object sequence) {
        if(sequence == null) {
            this.sequence = null;
        } else {
            if(sequence instanceof Long) {
                this.sequence = (Long)sequence;
            } else if(sequence instanceof Double) {
                this.sequence = ((Double)sequence).longValue();
            } else {
                throw new RuntimeException("Can not set sequence field for sprint." + sequence.getClass().getName() + " is not assignable for sequence.");
            }
        }
    }

    @Override
    @Nullable
    public String getGoal() {
        return goal;
    }

    @Override
    public void setGoal(@Nullable String goal) {
        this.goal = goal;
    }

    @Override
    public String getEntityName() {
        return "sprint";
    }

    @Override
    public String getOriginBoardId() {
        return originBoardId;
    }

    @Override
    public void setOriginBoardId(String originBoardId) {
        this.originBoardId = originBoardId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        BasicHubSprint that = (BasicHubSprint) o;
        return Objects.equals(state, that.state) &&
                Objects.equals(name, that.name) &&
                Objects.equals(originBoardId, that.originBoardId) &&
                Objects.equals(startDate, that.startDate) &&
                Objects.equals(endDate, that.endDate) &&
                Objects.equals(completeDate, that.completeDate) &&
                Objects.equals(sequence, that.sequence) &&
                Objects.equals(goal, that.goal);
    }

    @Override
    public int hashCode() {
        return Objects.hash(state, name, originBoardId, startDate, endDate, completeDate, sequence, goal);
    }

    // implementation for IHubIssueReplica interface
    @Override
    public void setRemovedComments(@Nonnull List<BasicHubComment> removedComments) {

    }

    @Override
    public void setChangedComments(@Nonnull List<BasicHubComment> changedComments) {

    }

    @Override
    public void setAddedComments(@Nonnull List<BasicHubComment> addedComments) {

    }

    @Nonnull
    @Override
    public List<BasicHubComment> getComments() {
        return Lists.newArrayList();
    }

    @Nonnull
    @Override
    public List<BasicHubComment> getAddedComments() {
        return Lists.newArrayList();
    }

    @Nonnull
    @Override
    public List<BasicHubComment> getChangedComments() {
        return Lists.newArrayList();
    }

    @Nonnull
    @Override
    public List<BasicHubComment> getRemovedComments() {
        return Lists.newArrayList();
    }

    @Nonnull
    @Override
    public List<BasicHubAttachment> getAddedAttachments() {
        return Lists.newArrayList();
    }

    @Nonnull
    @Override
    public List<BasicHubAttachment> getRemovedAttachments() {
        return Lists.newArrayList();
    }

    @Nonnull
    @Override
    public List<BasicHubAttachment> getAttachments() {
        return Lists.newArrayList();
    }

    @Override
    public void setAddedAttachments(@Nonnull List<BasicHubAttachment> addedAttachments) {

    }

    @Override
    public void setRemovedAttachments(@Nonnull List<BasicHubAttachment> removedAttachments) {

    }

    @Nonnull
    @Override
    public List<BasicHubWorkLog> getWorkLogs() {
        return Lists.newArrayList();
    }

    @Override
    public void setRemovedWorkLogs(List<BasicHubWorkLog> removedWorkLogs) {

    }

    @Override
    public void setChangedWorkLogs(List<BasicHubWorkLog> changedWorkLogs) {

    }

    @Override
    public void setAddedWorkLogs(List<BasicHubWorkLog> addedWorkLogs) {

    }


    @Override
    public EventTriggerContext getEventTriggerContext() {
        return eventTriggerContext;
    }


    @Override
    public void setEventTriggerContext(EventTriggerContext eventTriggerContext) {
        this.eventTriggerContext = eventTriggerContext;
    }
}
