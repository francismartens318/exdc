/*
 * Copyright (C) 2015, iDalko NV
 * All rights reserved.
 *
 *
 * THIS SOURCE CODE IS AN UNPUBLISHED PROPRIETARY TRADE SECRET OF iDalko NV, unless stated otherwise
 * in the license text.
 *
 *
 * The copyright notice above does not evidence any actual or intended publication of such source code.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
 */
package com.exalate.basic.domain.hubobject.v1;

import com.exalate.api.domain.hubobject.v1_2.IHubOption;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.io.Serializable;
import java.util.List;

public class BasicHubOption implements IHubOption, Serializable {

    private String id;
    private Long sequence;
    private String value;
    private Boolean disabled;
    private IHubOption parentOption;
    private List<IHubOption> childOptions;

    @Nullable
    public String getId() {
       return id;
    }

    public String getIdStr() {
        return id;
    }

    @Override
    public Long getSequence() {
        return sequence;
    }

    @Override
    public String getValue() {
        return value;
    }

    @Nullable
    @Override
    public Boolean isDisabled() {
        return disabled;
    }

    @Nullable
    public Boolean getDisabled() {
        return disabled;
    }

    @Nullable
    @Override
    public IHubOption getParentOption() {
        return parentOption;
    }

    @Nonnull
    @Override
    public List<IHubOption> getChildOptions() {
        return childOptions;
    }

    public void setId(Long id) {
        this.id = String.valueOf(id);
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setSequence(Long sequence) {
        this.sequence = sequence;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public void setDisabled(Boolean disabled) {
        this.disabled = disabled;
    }

    public void setParentOption(IHubOption parentOption) {
        this.parentOption = parentOption;
    }

    public void setChildOptions(List<IHubOption> childOptions) {
        this.childOptions = childOptions;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if(o instanceof String){
            String v = (String)o;
            return v.equals(this.value);
        }
        if (!(o instanceof BasicHubOption)) return false;

        BasicHubOption that = (BasicHubOption) o;

        if (id != null ? !id.equals(that.id) : that.id != null) return false;
        //noinspection RedundantIfStatement
        if (value != null ? !value.equals(that.value) : that.value != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (value != null ? value.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "BasicHubOption{" +
                "id='" + id + '\'' +
                ", value=" + value +
                ", sequence='" + sequence + '\'' +
                ", disabled='" + disabled + '\'' +
                '}';
    }
}
