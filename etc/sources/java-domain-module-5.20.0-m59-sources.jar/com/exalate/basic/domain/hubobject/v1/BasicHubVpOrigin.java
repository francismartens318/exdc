package com.exalate.basic.domain.hubobject.v1;

import com.exalate.api.domain.hubobject.v1_13.IHubVpOrigin;

import java.io.Serializable;

public class BasicHubVpOrigin implements IHubVpOrigin, Serializable {

    private String portalKey;
    private String requestTypeKey;
    private String representationValue;
    private String requestTypeId;
    private String requestTypeName;
    private String serviceDeskId;
    private String serviceDeskProjectName;
    private String serviceDeskProjectKey;

    @Override
    public String getRequestTypeId() {
        return requestTypeId;
    }

    @Override
    public String getRequestTypeName() {
        return requestTypeName;
    }

    @Override
    public String getServiceDeskId() {
        return serviceDeskId;
    }

    @Override
    public String getServiceDeskProjectName() {
        return serviceDeskProjectName;
    }

    @Override
    public String getServiceDeskProjectKey() {
        return serviceDeskProjectKey;
    }

    @Override
    public String getPortalKey() {
        return portalKey;
    }

    @Override
    public String getRequestTypeKey() {
        return requestTypeKey;
    }

    @Override
    public String getRepresentationValue() {
        return representationValue;
    }

    public void setRequestTypeId(String requestTypeId) {
        this.requestTypeId = requestTypeId;
    }

    public void setRequestTypeName(String requestTypeName) {
        this.requestTypeName = requestTypeName;
    }

    public void setServiceDeskId(String serviceDeskId) {
        this.serviceDeskId = serviceDeskId;
    }

    public void setServiceDeskProjectName(String serviceDeskProjectName) {
        this.serviceDeskProjectName = serviceDeskProjectName;
    }

    public void setServiceDeskProjectKey(String serviceDeskProjectKey) {
        this.serviceDeskProjectKey = serviceDeskProjectKey;
    }

    public void setRepresentationValue(String representationValue) {
        this.representationValue = representationValue;
    }

    public void setPortalKey(String portalKey) {
        this.portalKey = portalKey;
    }

    public void setRequestTypeKey(String requestTypeKey) {
        this.requestTypeKey = requestTypeKey;
    }

    /**
     * Should be consistent with the service desk's VPOriginCFType.getStringFromSingularObject(VPOrigin).
     * Meaning, that if the vp origin custom field stores the value in ${portalKey}/${requestTypeKey} format,
     * the toString should also return it in the same way.
     * */
    @Override
    public String toString() {
        return portalKey + "/" + requestTypeKey;
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        final BasicHubVpOrigin vpOrigin = (BasicHubVpOrigin) o;

        if (portalKey != null ? !portalKey.equals(vpOrigin.portalKey) : vpOrigin.portalKey != null) {
            return false;
        }
        if (requestTypeKey != null ? !requestTypeKey
                .equals(vpOrigin.requestTypeKey) : vpOrigin.requestTypeKey != null) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        int result = portalKey != null ? portalKey.hashCode() : 0;
        result = 31 * result + (requestTypeKey != null ? requestTypeKey.hashCode() : 0);
        return result;
    }
}
