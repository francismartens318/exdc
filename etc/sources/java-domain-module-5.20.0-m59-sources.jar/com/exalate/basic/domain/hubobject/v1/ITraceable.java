package com.exalate.basic.domain.hubobject.v1;


import com.exalate.api.domain.twintrace.TraceType;

import java.io.Serializable;

public interface ITraceable extends Serializable{
    Long getId();
    String getIdStr();
    Long getRemoteId();
    String getRemoteIdStr();
    void setId(Long id);
    void setId(String id);
    void setRemoteId(Long remoteId);
    void setRemoteId(String remoteId);
    TraceType getTraceType();
}
