/*
 * Copyright (C) 2015, iDalko NV
 * All rights reserved.
 *
 *
 * THIS SOURCE CODE IS AN UNPUBLISHED PROPRIETARY TRADE SECRET OF iDalko NV, unless stated otherwise
 * in the license text.
 *
 *
 * The copyright notice above does not evidence any actual or intended publication of such source code.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
 */
package com.exalate.basic.domain.hubobject.v1;

import com.exalate.api.domain.hubobject.v1_2.IHubComponent;
import com.exalate.api.domain.hubobject.v1_2.IHubProject;
import com.exalate.api.domain.hubobject.v1_2.IHubUser;
import com.exalate.api.domain.hubobject.v1_2.IHubVersion;
import com.exalate.util.collect.NopImmutableList;
import com.exalate.util.collect.NopImmutableSet;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.io.Serializable;
import java.util.List;
import java.util.Set;

import static com.exalate.util.CollectionUtils.toNonNull;

public class BasicHubProject implements IHubProject, Serializable {
    private String idStr;
    private String key;
    private String name;
    private IHubUser lead;
    private Set<IHubVersion> versions;
    private List<IHubComponent> components;
    private transient boolean _locked = false;

    @Nullable
    @Override
    public String getIdStr() {
        return idStr;
    }

    @Nullable
    @Override
    public Long getId() {
        try {
            return Long.valueOf(idStr);
        } catch (Exception e) {
            return null;
        }
    }

    @Nonnull
    @Override
    public String getKey() {
        return key;
    }

    @Nonnull
    @Override
    public String getName() {
        return name;
    }

    @Nullable
    @Override
    public IHubUser getLead() {
        return lead;
    }

    @Nonnull
    @Override
    public Set<IHubVersion> getVersions() {
        return this.versions = toNonNull(!_locked, versions);
    }

    @Nonnull
    @Override
    public List<IHubComponent> getComponents() {
        return this.components = toNonNull(!_locked, components);
    }

    public void setId(@Nonnull Long id) {
        if (!_locked) this.idStr = id.toString();
    }

    public void setId(@Nonnull String idStr) {
        if (!_locked) this.idStr = idStr;
    }


    public void setKey(@Nonnull String key) {
        if (!_locked) this.key = key;
    }

    public void setName(@Nonnull String name) {
        if (!_locked) this.name = name;
    }

    public void setLead(@Nullable IHubUser lead) {
        if (!_locked) this.lead = lead;
    }

    public void setVersions(@Nonnull Set<IHubVersion> versions) {
        if (!_locked) this.versions = versions;
    }

    public void setComponents(@Nonnull List<IHubComponent> components) {
        if (!_locked) this.components = components;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof BasicHubProject)) return false;

        BasicHubProject that = (BasicHubProject) o;

        if (idStr != null ? !idStr.equals(that.idStr) : that.idStr != null) return false;
        if (key != null ? !key.equals(that.key) : that.key != null) return false;
        //noinspection RedundantIfStatement
        if (name != null ? !name.equals(that.name) : that.name != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = idStr != null ? idStr.hashCode() : 0;
        result = 31 * result + (key != null ? key.hashCode() : 0);
        result = 31 * result + (name != null ? name.hashCode() : 0);
        return result;
    }

    @Override
    public void lock() {
        if (_locked) {
            return;
        }
        this._locked = true;
        if (components != null) {
            components = new NopImmutableList<IHubComponent>(components);
        }
        if (versions != null) {
            versions = new NopImmutableSet<IHubVersion>(versions);
        }
    }

    @Override
    public boolean isLocked() {
        return _locked;
    }
}
