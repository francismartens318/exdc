package com.exalate.basic.domain.hubobject.v1.status;

import com.exalate.api.domain.hubobject.v1_2.IHubOption;
import com.exalate.api.domain.hubobject.v1_8.IHubStatusCategory;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.List;

public class BasicHubStatusCategory implements IHubStatusCategory {
    private String id;
    private String key;
    private String name;

    private transient boolean _locked = false;

    @Override
    public String getId() {
        return id;
    }

    @Override
    public String getKey() {
        return key;
    }

    @Override
    public String getName() {
        return name;
    }

    public void setId(String id) {
        if (!_locked) this.id = id;
    }

    public void setName(String name) {
        if (!_locked) this.name = name;
    }

    public void setKey(String key) {
        if (!_locked) this.key = key;
    }

    @Nullable
    @Override
    public Long getSequence() {
        return null;
    }

    @Nullable
    @Override
    public String getValue() {
        return name;
    }

    @Nullable
    @Override
    public Boolean isDisabled() {
        return null;
    }

    @Nullable
    @Override
    public IHubOption getParentOption() {
        return null;
    }

    @Nonnull
    @Override
    public List<IHubOption> getChildOptions() {
        return null;
    }

    public void lock() {
        if (_locked) {
            return;
        }
        this._locked = true;
    }

    public boolean isLocked() {
        return _locked;
    }
}
