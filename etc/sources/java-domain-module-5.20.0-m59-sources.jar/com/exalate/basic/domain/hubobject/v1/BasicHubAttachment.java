/*
 * Copyright (C) 2015, iDalko NV
 * All rights reserved.
 *
 *
 * THIS SOURCE CODE IS AN UNPUBLISHED PROPRIETARY TRADE SECRET OF iDalko NV, unless stated otherwise
 * in the license text.
 *
 *
 * The copyright notice above does not evidence any actual or intended publication of such source code.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
 */
package com.exalate.basic.domain.hubobject.v1;

import com.exalate.api.domain.hubobject.v1_2.IHubAttachment;
import com.exalate.api.domain.hubobject.v1_2.IHubUser;
import com.exalate.api.domain.twintrace.TraceType;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.io.Serializable;
import java.util.Date;

public class BasicHubAttachment implements IHubAttachment, Serializable, ITraceable {

    private String id;
    private String mimetype;
    private String filename;
    private Date created;
    private Long filesize;
    private String remoteId;
    private IHubUser author;
    private Boolean thumbnailable;
    private Boolean internal = false;
    private boolean zip;
    private IHubUser executor;

    private transient boolean _locked = false;

    @Override
    public Long getId() {
        if(id == null) return null;
        return Long.parseLong(id);
    }

    public Boolean isInternal(){
        return this.internal;
    }

    public void setInternal(boolean internal){
        this.internal = internal;
    }

    @Override
    public String getIdStr() {
        return id;
    }

    @Nonnull
    @Override
    public String getMimetype() {
        return mimetype;
    }

    @Nonnull
    @Override
    public String getFilename() {
        return filename;
    }

    @Nonnull
    @Override
    public Date getCreated() {
        return created;
    }

    @Nonnull
    @Override
    public Long getFilesize() {
        return filesize;
    }

    @Nonnull
    @Override
    public IHubUser getAuthor() {
        return author;
    }

    @Nonnull
    @Override
    public Boolean isThumbnailable() {
        return thumbnailable;
    }

    @Override
    public TraceType getTraceType() {
        return TraceType.ATTACHMENT;
    }

    public void setId(Long id) {
        if (!_locked) this.id = String.valueOf(id);
    }

    public void setId(String id) {
        if (!_locked) this.id = id;
    }

    public void setMimetype(String mimetype) {
        if (!_locked) this.mimetype = mimetype;
    }

    public void setFilename(String filename) {
        if (!_locked) this.filename = filename;
    }

    public void setCreated(Date created) {
        if (!_locked) this.created = created;
    }

    public void setFilesize(Long filesize) {
        if (!_locked) this.filesize = filesize;
    }

    public void setAuthor(IHubUser author) {
        if (!_locked) this.author = author;
    }

    public void setThumbnailable(Boolean thumbnailable) {
        if (!_locked) this.thumbnailable = thumbnailable;
    }

    @Override
    public boolean isZip() {
        return this.zip;
    }

    public void setZip(boolean zip) {
        if (!_locked) this.zip = zip;
    }

    @Nullable
    @Override
    public Long getRemoteId() {
        if(remoteId == null) return null;
        return Long.valueOf(remoteId);
    }
    @Nullable
    @Override
    public String getRemoteIdStr() {
        return remoteId;
    }

    public void setRemoteId(Long remoteId) {
        if (!_locked) this.remoteId = String.valueOf(remoteId);
    }

    public void setRemoteId(String remoteId) {
        if (!_locked) this.remoteId = remoteId;
    }
    
    public IHubUser getExecutor() {
        return executor;
    }

    public void setExecutor(final IHubUser executor) {
        this.executor = executor;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof BasicHubAttachment)) return false;

        BasicHubAttachment that = (BasicHubAttachment) o;

        if (id != null ? !id.equals(that.id) : that.id != null) return false;
        return true;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        return result;
    }

    @Override
    public String toString() {
        return "BasicHubAttachment{" +
                "id=" + id +
                ", remoteId=`" + remoteId + '`' +
                ", mimetype=`" + mimetype + '`' +
                ", filename=`" + filename + '`' +
                ", created=`" + created + "`" +
                ", filesize=`" + filesize + "`" +
                ", author=`" + author + "`" +
                ", thumbnailable=`" + thumbnailable + "`" +
                ", zip='" + zip + "'" +
                '}';
    }

    public void lock() {
        if (_locked) {
            return;
        }
        this._locked = true;
        author.lock();
    }

    public boolean isLocked() {
        return _locked;
    }
}
