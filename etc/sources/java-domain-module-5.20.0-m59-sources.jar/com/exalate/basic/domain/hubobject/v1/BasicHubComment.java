/*
 * Copyright (C) 2015, iDalko NV
 * All rights reserved.
 *
 *
 * THIS SOURCE CODE IS AN UNPUBLISHED PROPRIETARY TRADE SECRET OF iDalko NV, unless stated otherwise
 * in the license text.
 *
 *
 * The copyright notice above does not evidence any actual or intended publication of such source code.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
 */
package com.exalate.basic.domain.hubobject.v1;

import com.exalate.api.domain.hubobject.v1_2.IHubUser;
import com.exalate.api.domain.hubobject.v1_5.IHubComment;
import com.exalate.api.domain.twintrace.TraceType;

import javax.annotation.Nullable;
import java.io.Serializable;
import java.util.Date;

public class BasicHubComment implements IHubComment, Serializable, ITraceable {

    private String id;
    private IHubUser author;
    private IHubUser updateAuthor;
    private String body;
    private Date created;
    private Date updated;
    private String remoteId;
    private String group;
    private String role;
    private boolean internal = true;
    private IHubUser executor;
    private boolean restrictSync = false;

    private transient boolean _locked = false;

    @Override
    public Long getId() {
        if(id == null) return null;
        return Long.parseLong(id);
    }

    @Override
    public IHubUser getAuthor() {
        return author;
    }

    @Override
    public IHubUser getUpdateAuthor() {
        return updateAuthor;
    }

    @Override
    public String getBody() {
        return body;
    }

    @Override
    public Date getCreated() {
        return created;
    }

    @Override
    public Date getUpdated() {
        return updated;
    }

    @Nullable
    @Override
    public String getGroupLevel() {
        return group;
    }

    @Nullable
    @Override
    public String getRoleLevel() {
        return role;
    }

    @Override
    public Long getRemoteId() {
        if(remoteId == null) return null;
        return Long.valueOf(remoteId);
    }

    @Override
    public String getRemoteIdStr() {
        return remoteId;
    }

    @Override
    public boolean isInternal() {
        return internal;
    }

    @Nullable
    @Override
    public IHubUser getExecutor() {
        return executor;
    }

    @Override
    public boolean getRestrictSync() {
        return this.restrictSync;
    }

    public void setRestrictSync(boolean sync) {
        this.restrictSync = sync;
    }

    @Override
    public String getIdStr() {
        return id;
    }

    @Override
    public TraceType getTraceType() {
        return TraceType.COMMENT;
    }

    public void setExecutor(final IHubUser executor) {
        this.executor = executor;
    }

    public void setInternal(boolean internal) {
        if (!_locked) this.internal = internal;
    }

    public void setId(Long id) {
        if (!_locked) this.id = String.valueOf(id);
    }

    @Override
    public void setId(String id) {
        if (!_locked) this.id = id;
    }

    public void setAuthor(IHubUser author) {
        if (!_locked) this.author = author;
    }

    public void setUpdateAuthor(IHubUser updateAuthor) {
        if (!_locked) this.updateAuthor = updateAuthor;
    }

    public void setBody(String body) {
        if (!_locked) this.body = body;
    }

    public void setCreated(Date created) {
        if (!_locked) this.created = created;
    }

    public void setUpdated(Date updated) {
        if (!_locked) this.updated = updated;
    }

    public void setGroupLevel(@Nullable String group) {
        if (!_locked) this.group = group;
    }

    public void setRoleLevel(@Nullable String role) {
        if (!_locked) this.role = role;
    }

    public void setRemoteId(Long remoteId) {
        if (!_locked) this.remoteId = String.valueOf(remoteId);
    }

    @Override
    public void setRemoteId(String remoteId) {
        if (!_locked) this.remoteId = remoteId;
    }

    @Override
    public String toString() {
        return "BasicHubComment{" +
                ", @id=`" + id + "`" +
                ", @remoteId=`" + remoteId + "`" +
                ", @author=`" + author + "`" +
                ", @created=`" + created + "`" +
                ", @updateAuthor=`" + updateAuthor + "`" +
                ", @updated=`" + updated + "`" +
                ", @group=`" + group + "`" +
                ", @role=`" + role + "`" +
                ", @internal= `" + internal + "`" +
                ", @executor= `" + executor + "`" +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof BasicHubComment)) {
            return false;
        }

        BasicHubComment that = (BasicHubComment) o;

        if (id != null ? !id.equals(that.id) : that.id != null) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        return result;
    }

    public void lock() {
        if (_locked) {
            return;
        }
        this._locked = true;
        if (author != null) {
            author.lock();
        }
        if (updateAuthor != null) {
            updateAuthor.lock();
        }
    }

    public boolean isLocked() {
        return _locked;
    }
}
