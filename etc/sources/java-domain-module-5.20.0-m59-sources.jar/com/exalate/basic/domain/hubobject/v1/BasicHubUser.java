/*
 * Copyright (C) 2015, Exalate NV
 * All rights reserved.
 *
 *
 * THIS SOURCE CODE IS AN UNPUBLISHED PROPRIETARY TRADE SECRET OF iDalko NV, unless stated otherwise
 * in the license text.
 *
 *
 * The copyright notice above does not evidence any actual or intended publication of such source code.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
 */
package com.exalate.basic.domain.hubobject.v1;

import com.exalate.api.domain.hubobject.v1_2.IHubUser;

import java.io.Serializable;

public class BasicHubUser implements IHubUser, Serializable {

    private String key;
    private boolean active;
    private String email;
    private String displayName;
    private String username;

    private transient boolean _locked = false;

    @Override
    public String getKey() {
        return key;
    }

    public String getUsername() {
        return username;
    }

    @Override
    public boolean isActive() {
        return active;
    }

    @Override
    public String getEmail() {
        return email;
    }

    @Override
    public String getDisplayName() {
        return displayName;
    }

    public void setKey(String key) {
        if (!_locked) this.key = key;
    }

    public void setActive(boolean active) {
        if (!_locked) this.active = active;
    }

    public void setEmail(String email) {
        if (!_locked) this.email = email;
    }

    public void setDisplayName(String displayName) {
        if (!_locked) this.displayName = displayName;
    }

    public void setUsername(String username) {
        if (!_locked) this.username = username;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        BasicHubUser that = (BasicHubUser) o;

        //noinspection RedundantIfStatement
        if (key != null ? !key.equals(that.key) : that.key != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return key != null ? key.hashCode() : 0;
    }

    public void lock() {
        this._locked = true;
    }

    public boolean isLocked() {
        return _locked;
    }

    @Override
    public String toString() {
        return String.format("{ @key : %s}", key);
    }
}
