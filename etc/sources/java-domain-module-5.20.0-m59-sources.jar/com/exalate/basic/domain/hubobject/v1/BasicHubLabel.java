/*
 * Copyright (C) 2015, Exalate NV
 * All rights reserved.
 *
 *
 * THIS SOURCE CODE IS AN UNPUBLISHED PROPRIETARY TRADE SECRET OF iDalko NV, unless stated otherwise
 * in the license text.
 *
 *
 * The copyright notice above does not evidence any actual or intended publication of such source code.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
 */
package com.exalate.basic.domain.hubobject.v1;

import com.exalate.api.domain.hubobject.v1_2.IHubLabel;
import com.exalate.api.domain.hubobject.v1_2.IHubOption;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.io.Serializable;
import java.util.List;

public class BasicHubLabel implements IHubLabel, Serializable {
    private String label;

    private transient boolean _locked = false;

    public String getId() {
        return null;
    }

    @Nonnull
    @Override
    public String getLabel() {
        return label;
    }

    public void setLabel(@Nonnull String label) {
        if (!_locked) this.label = label;
    }

    @Nullable
    @Override
    public Long getSequence() {
        return null;
    }

    @Nullable
    @Override
    public String getValue() {
        return label;
    }

    @Nullable
    @Override
    public Boolean isDisabled() {
        return null;
    }

    @Nullable
    @Override
    public IHubOption getParentOption() {
        return null;
    }

    @Nonnull
    @Override
    public List<IHubOption> getChildOptions() {
        return null;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        if(!(o instanceof BasicHubLabel) || !(o instanceof BasicHubOption)) return false;

        if(o instanceof BasicHubLabel) {
            BasicHubLabel that = (BasicHubLabel) o;

            //noinspection RedundantIfStatement
            if (label != null ? !label.equals(that.label) : that.label != null) return false;
        }

        if(o instanceof BasicHubOption) {
            BasicHubOption that = (BasicHubOption) o;

            //noinspection RedundantIfStatement
            if (label != null ? !label.equals(that.getValue()) : that.getValue() != null) return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return label != null ? label.hashCode() : 0;
    }


    public void lock() {
        if (_locked) {
            return;
        }
        this._locked = true;
    }

    public boolean isLocked() {
        return _locked;
    }
}
