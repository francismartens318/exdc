package com.exalate.basic.domain.hubobject.v1;

import com.exalate.api.domain.hubobject.v1_15.IHubIssueSecurityLevel;

import java.util.Objects;

public class BasicHubIssueSecurityLevel implements IHubIssueSecurityLevel {

    private String id, name, description;

    private transient boolean _locked = false;

    public BasicHubIssueSecurityLevel(){

    }


    public BasicHubIssueSecurityLevel(String id, String name, String description) {
        this.id = id;
        this.name = name;
        this.description = description;
    }

    @Override
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        if (!_locked) this.description = description;
    }

    @Override
    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (!_locked) this.name = name;
    }

    @Override
    public String getId() {
        return id;
    }

    public void setId(String id) {
        if (!_locked) this.id = id;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        BasicHubIssueSecurityLevel that = (BasicHubIssueSecurityLevel) o;
        return Objects.equals(id, that.id) &&
                Objects.equals(name, that.name) &&
                Objects.equals(description, that.description);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name, description);
    }

    @Override
    public String toString() {
        return "BasicHubIssueSecurityLevel{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", description='" + description + '\'' +
                '}';
    }

    public void lock() {
        if (_locked) {
            return;
        }
        _locked = true;
    }

    public boolean isLocked() {
        return _locked;
    }
}
