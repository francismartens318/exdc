package com.exalate.api.exception.filesystem;

public class AccessDeniedFileSystemException extends ExalateFileSystemException {

    public AccessDeniedFileSystemException(String message) {
        super(message);
    }

    public AccessDeniedFileSystemException(String message, Throwable cause) {
        super(message, cause);
    }

    public AccessDeniedFileSystemException(Throwable cause) {
        super(cause);
    }

    @Override
    public String getDocsLink() {
        return "https://docs.exalate.com/docs/server-file-system-access-error";
    }

    @Override
    public String getRootCauseErrorTypeName() {
        return "Server file system access error";
    }
}
