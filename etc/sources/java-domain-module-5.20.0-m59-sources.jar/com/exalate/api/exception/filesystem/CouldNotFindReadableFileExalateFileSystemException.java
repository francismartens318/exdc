package com.exalate.api.exception.filesystem;

public class CouldNotFindReadableFileExalateFileSystemException extends ExalateFileSystemException {

    public CouldNotFindReadableFileExalateFileSystemException(String message) {
        super(message);
    }

    public CouldNotFindReadableFileExalateFileSystemException(String message, Throwable cause) {
        super(message, cause);
    }

    public CouldNotFindReadableFileExalateFileSystemException(Throwable cause) {
        super(cause);
    }

    @Override
    public String getDocsLink() {
        return "";
    }

    @Override
    public String getRootCauseErrorTypeName() {
        return "File reading error";
    }
}
