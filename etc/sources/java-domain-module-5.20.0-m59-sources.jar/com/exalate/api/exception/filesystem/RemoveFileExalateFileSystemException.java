package com.exalate.api.exception.filesystem;

public class RemoveFileExalateFileSystemException extends ExalateFileSystemException {

    public RemoveFileExalateFileSystemException(String message) {
        super(message);
    }

    public RemoveFileExalateFileSystemException(String message, Throwable cause) {
        super(message, cause);
    }

    public RemoveFileExalateFileSystemException(Throwable cause) {
        super(cause);
    }

    @Override
    public String getDocsLink() {
        return "";
    }

    @Override
    public String getRootCauseErrorTypeName() {
        return "File system error while removing a file.";
    }
}
