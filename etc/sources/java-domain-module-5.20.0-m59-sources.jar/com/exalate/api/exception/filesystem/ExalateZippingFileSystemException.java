package com.exalate.api.exception.filesystem;

public class ExalateZippingFileSystemException extends ExalateFileSystemException {

    public ExalateZippingFileSystemException(String message) {
        super(message);
    }

    public ExalateZippingFileSystemException(String message, Throwable cause) {
        super(message, cause);
    }

    public ExalateZippingFileSystemException(Throwable cause) {
        super(cause);
    }

    @Override
    public String getDocsLink() {
        return "";
    }

    @Override
    public String getRootCauseErrorTypeName() {
        return "Zipping file error";
    }
}
