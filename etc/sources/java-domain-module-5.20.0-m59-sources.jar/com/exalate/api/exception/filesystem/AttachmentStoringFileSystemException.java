package com.exalate.api.exception.filesystem;

public class AttachmentStoringFileSystemException extends ExalateFileSystemException {

    public AttachmentStoringFileSystemException(String message) {
        super(message);
    }

    public AttachmentStoringFileSystemException(String message, Throwable cause) {
        super(message, cause);
    }

    public AttachmentStoringFileSystemException(Throwable cause) {
        super(cause);
    }

    @Override
    public String getDocsLink() {
        return "";
    }

    @Override
    public String getRootCauseErrorTypeName() {
        return "Attachment storing error";
    }
}
