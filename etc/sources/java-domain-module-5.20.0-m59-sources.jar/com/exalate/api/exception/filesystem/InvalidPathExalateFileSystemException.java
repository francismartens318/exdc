package com.exalate.api.exception.filesystem;

public class InvalidPathExalateFileSystemException extends ExalateFileSystemException {

    public InvalidPathExalateFileSystemException(String message) {
        super(message);
    }

    public InvalidPathExalateFileSystemException(String message, Throwable cause) {
        super(message, cause);
    }

    public InvalidPathExalateFileSystemException(Throwable cause) {
        super(cause);
    }

    @Override
    public String getDocsLink() {
        return "";
    }

    @Override
    public String getRootCauseErrorTypeName() {
        return "File system invalid path error";
    }
}
