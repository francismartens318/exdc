package com.exalate.api.exception.filesystem;

public class CleanupFileSystemException extends ExalateFileSystemException {

    public CleanupFileSystemException(String message) {
        super(message);
    }

    public CleanupFileSystemException(String message, Throwable cause) {
        super(message, cause);
    }

    public CleanupFileSystemException(Throwable cause) {
        super(cause);
    }

    @Override
    public String getDocsLink() {
        return "";
    }

    @Override
    public String getRootCauseErrorTypeName() {
        return "File system error during Clean-up";
    }
}
