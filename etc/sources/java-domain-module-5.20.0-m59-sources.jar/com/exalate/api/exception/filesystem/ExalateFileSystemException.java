package com.exalate.api.exception.filesystem;

import com.exalate.api.exception.CategorizedException;

public abstract class ExalateFileSystemException extends CategorizedException {

    public ExalateFileSystemException(String message) {
        super(message);
    }

    public ExalateFileSystemException(String message, Throwable cause) {
        super(message, cause);
    }

    public ExalateFileSystemException(Throwable cause) {
        super(cause);
    }
}
