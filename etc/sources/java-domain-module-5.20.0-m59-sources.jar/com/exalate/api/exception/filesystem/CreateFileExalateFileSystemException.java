package com.exalate.api.exception.filesystem;

public class CreateFileExalateFileSystemException extends ExalateFileSystemException {

    public CreateFileExalateFileSystemException(String message) {
        super(message);
    }

    public CreateFileExalateFileSystemException(String message, Throwable cause) {
        super(message, cause);
    }

    public CreateFileExalateFileSystemException(Throwable cause) {
        super(cause);
    }

    @Override
    public String getDocsLink() {
        return "";
    }

    @Override
    public String getRootCauseErrorTypeName() {
        return "File system error while creating a file";
    }
}
