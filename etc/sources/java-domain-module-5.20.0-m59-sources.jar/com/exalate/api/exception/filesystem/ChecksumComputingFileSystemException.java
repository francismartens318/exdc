package com.exalate.api.exception.filesystem;

public class ChecksumComputingFileSystemException extends ExalateFileSystemException {

    public ChecksumComputingFileSystemException(String message) {
        super(message);
    }

    public ChecksumComputingFileSystemException(String message, Throwable cause) {
        super(message, cause);
    }

    public ChecksumComputingFileSystemException(Throwable cause) {
        super(cause);
    }

    @Override
    public String getDocsLink() {
        return "https://docs.exalate.com/docs/attachment-checksum-failed";
    }

    @Override
    public String getRootCauseErrorTypeName() {
        return "Attachment checksum calculating failed";
    }
}
