package com.exalate.api.exception.filesystem;

public class GenerateSupportZipFileSystemException extends ExalateFileSystemException {

    public GenerateSupportZipFileSystemException(String message) {
        super(message);
    }

    public GenerateSupportZipFileSystemException(String message, Throwable cause) {
        super(message, cause);
    }

    public GenerateSupportZipFileSystemException(Throwable cause) {
        super(cause);
    }

    @Override
    public String getDocsLink() {
        return "";
    }

    @Override
    public String getRootCauseErrorTypeName() {
        return "File system error while generating support.zip";
    }
}
