package com.exalate.api.exception.license;

import com.exalate.api.domain.ErrorEntityType;
import com.exalate.api.exception.CategorizedException;

public class LicenseException extends CategorizedException {

    public LicenseException(String message) {
        super(message);
    }

    public LicenseException(String message, Throwable cause) {
        super(message, cause);
    }

    public LicenseException(Throwable cause) {
        super(cause);
    }

    @Override
    public String getDocsLink() {
        return "https://docs.exalate.com/docs/free-plan-license-errors";
    }

    @Override
    public ErrorEntityType getErrorEntityType() {
        return ErrorEntityType.ISSUE;
    }

    @Override
    public String getRootCauseErrorTypeName() {
        return "License error";
    }
}
