package com.exalate.api.exception;

import com.exalate.api.domain.ErrorEntityType;

public abstract class CategorizedException extends Exception {
    public CategorizedException(String message) {
        super(message);
    }

    public CategorizedException(String message, Throwable cause) {
        super(message, cause);
    }

    public CategorizedException(Throwable cause) {
        super(cause);
    }

    public abstract String getDocsLink();

    public ErrorEntityType getErrorEntityType() {
        return ErrorEntityType.ISSUE;
    }

    public abstract String getRootCauseErrorTypeName();
}
