package com.exalate.api.exception;

import javax.annotation.Nonnull;

public enum VerifyCodeErrors {
    SECRET("SECRET", "Secret is not valid"),
    OK("OK", "Verified"),
    EULA("EULA","There was a problem to accept eula."),
    VERIFY("VERIFY", "There was a problem to verify node"),
    GET_LICENSE("GET_LICENSE", "There was a problem to get license"),
    ADMIN("ADMIN", "There was a problem to create admin"),
    LICENSE("LICENSE", "There was a problem to save license"),
    ADMIN_LICENSE("ADMIN_LICENSE", "There was a problem to create admin and save license");

    private final String message, name;

    VerifyCodeErrors(@Nonnull String name, @Nonnull String message) {
        this.name = name;
        this.message = message;
    }

    @Nonnull
    public String getName() {
        return name;
    }

    @Nonnull
    public String getMessage() {
        return message;
    }
}
