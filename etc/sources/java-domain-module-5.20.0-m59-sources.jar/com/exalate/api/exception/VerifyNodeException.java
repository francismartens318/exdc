package com.exalate.api.exception;

public class VerifyNodeException extends CategorizedException{

    public VerifyCodeErrors code;

    public VerifyNodeException(VerifyCodeErrors code, String message) {
        super(message);
        this.code = code;
    }

    public VerifyNodeException(String message) {
        super(message);
    }

    public VerifyNodeException(String message, Throwable cause) {
        super(message, cause);
    }

    public VerifyNodeException(Throwable cause) {
        super(cause);
    }

    @Override
    public String getDocsLink() {
        return "";
    }

    @Override
    public String getRootCauseErrorTypeName() {
        return "Node verify exception";
    }
}
