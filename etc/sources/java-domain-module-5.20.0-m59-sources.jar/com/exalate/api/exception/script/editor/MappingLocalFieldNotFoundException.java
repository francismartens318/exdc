package com.exalate.api.exception.script.editor;

import com.exalate.api.exception.script.IssueTrackerScriptException;

public class MappingLocalFieldNotFoundException extends IssueTrackerScriptException {

    public final String localFieldKey;
    public final String localFieldLabel;

    public MappingLocalFieldNotFoundException(String localFieldKey, String localFieldLabel) {
        super("Custom Field `"+ localFieldLabel +"` ("+localFieldKey+") is not found");
        this.localFieldKey = localFieldKey;
        this.localFieldLabel = localFieldLabel;
    }
}
