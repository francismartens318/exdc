package com.exalate.api.exception.script.editor;

import com.exalate.api.exception.script.IssueTrackerScriptException;

public class MappingLocalValueNotFoundException extends IssueTrackerScriptException {

    public final String localFieldKey;
    public final String value;

    public MappingLocalValueNotFoundException(String message, String localFieldKey, String value) {
        super(message);
        this.localFieldKey = localFieldKey;
        this.value = value;
    }
}
