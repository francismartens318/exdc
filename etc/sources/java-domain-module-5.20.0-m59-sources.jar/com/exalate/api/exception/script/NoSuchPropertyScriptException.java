package com.exalate.api.exception.script;

public class NoSuchPropertyScriptException extends ScriptException {
    public NoSuchPropertyScriptException(String message) {
        super(message);
    }

    public NoSuchPropertyScriptException(String message, Throwable cause) {
        super(message, cause);
    }

    public NoSuchPropertyScriptException(Throwable cause) {
        super(cause);
    }

    @Override
    public String getDocsLink() {
        return "";
    }


}
