package com.exalate.api.exception.script;

import com.exalate.api.domain.ErrorEntityType;

public class DataFilterException extends ScriptException {
    private ErrorEntityType errorEntityType;

    public DataFilterException(String message) {
        super(message);
    }

    public DataFilterException(String message, Throwable t) {
        super(message, t);
    }

    public DataFilterException(Throwable t) {
        super(t);
    }

    public DataFilterException(String message, Throwable t, ErrorEntityType errorEntityType) {
        super(message, t);
        this.errorEntityType = errorEntityType;
    }

    @Override
    public ErrorEntityType getErrorEntityType() {
        if(this.errorEntityType != null) return this.errorEntityType;
        return super.getErrorEntityType();
    }

    @Override
    public String getRootCauseErrorTypeName() {
        return "Outgoing sync error";
    }
}
