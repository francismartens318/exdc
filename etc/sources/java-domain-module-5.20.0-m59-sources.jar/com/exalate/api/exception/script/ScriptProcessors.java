package com.exalate.api.exception.script;

public enum ScriptProcessors {
    OUTGOING, INCOMING, CREATE, CHANGE, RULE, POST_EXALATE_PROCESSOR
}
