package com.exalate.api.exception.script;

import com.exalate.api.domain.ErrorEntityType;

public class CompilationErrorScriptException extends ScriptException {
    public CompilationErrorScriptException(String message) {
        super(message);
    }

    public CompilationErrorScriptException(String message, Throwable cause) {
        super(message, cause);
    }

    public CompilationErrorScriptException(Throwable cause) {
        super(cause);
    }

    @Override
    public String getDocsLink() {
        return "";
    }

    @Override
    public ErrorEntityType getErrorEntityType() {
        return ErrorEntityType.ISSUE;
    }

    @Override
    public String getRootCauseErrorTypeName() {
        return "Compilation error";
    }
}
