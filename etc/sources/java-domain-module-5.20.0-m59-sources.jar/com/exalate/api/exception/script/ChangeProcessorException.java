package com.exalate.api.exception.script;

import com.exalate.api.domain.ErrorEntityType;

public class ChangeProcessorException extends ScriptException {
    private ErrorEntityType errorEntityType;

    public ChangeProcessorException(String message) {
        super(message);
    }

    public ChangeProcessorException(String message, Throwable t) {
        super(message, t);
    }

    public ChangeProcessorException(Throwable t) {
        super(t);
    }

    public ChangeProcessorException(String message, Throwable t, ErrorEntityType errorEntityType) {
        super(message, t);
        this.errorEntityType = errorEntityType;
    }

    @Override
    public ErrorEntityType getErrorEntityType() {
        if(this.errorEntityType != null) return this.errorEntityType;
        return super.getErrorEntityType();
    }

    @Override
    public String getRootCauseErrorTypeName() {
        return "Incoming sync: update sync error";
    }
}
