package com.exalate.api.exception.script.editor;

import com.exalate.api.exception.script.IssueTrackerScriptException;

public class MappingLocalValueDisabledException extends IssueTrackerScriptException {

    public final String localFieldKey;
    public final String localFieldLabel;
    public final String value;

    public MappingLocalValueDisabledException(String localFieldKey, String localFieldLabel, String value) {
        super("Option `"+value+"` is disabled for custom field `"+localFieldLabel+"` ("+ localFieldKey +")");
        this.localFieldKey = localFieldKey;
        this.localFieldLabel = localFieldLabel;
        this.value = value;
    }
}
