package com.exalate.api.exception.script;

import com.exalate.api.domain.ErrorEntityType;
import com.exalate.api.exception.CategorizedException;

public class ScriptException extends CategorizedException {

    private Integer lineNumber;
    private ScriptProcessors scriptProcessor;
    private final String rootCauseErrorTypeName;


    public ScriptException(String message) {
        super(message);
        rootCauseErrorTypeName= "Sync rules error";
    }

    public ScriptException(String message, Throwable cause) {
        super(message, cause);
        rootCauseErrorTypeName= "Sync rules error";
    }

    public ScriptException(String message, Throwable cause, int lineNumber, ScriptProcessors scriptProcessor) {
        super(message, cause);
        this.lineNumber = lineNumber;
        this.scriptProcessor = scriptProcessor;
        switch (scriptProcessor){
            case CHANGE:
                this.rootCauseErrorTypeName =  "Change processor script error";
                break;
            case CREATE:
                this.rootCauseErrorTypeName =  "Create processor script error";
                break;
            case OUTGOING:
                this.rootCauseErrorTypeName =  "Outgoing script error";
                break;
            case INCOMING:
                this.rootCauseErrorTypeName =  "Incoming script error";
                break;
            case RULE:
                this.rootCauseErrorTypeName =  "Script mapping rule error";
                break;
            default:
                rootCauseErrorTypeName= "Sync rules error";
        }
    }

    public ScriptException(Throwable cause) {
        super(cause);
        rootCauseErrorTypeName= "Sync rules error";
    }

    @Override
    public String getDocsLink() {
        return "";
    }

    @Override
    public ErrorEntityType getErrorEntityType() {
        return ErrorEntityType.RELATION;
    }

    @Override
    public String getRootCauseErrorTypeName() {
        return this.rootCauseErrorTypeName;
    }

    public Integer getLineNumber(){
        return this.lineNumber;
    }

    public ScriptProcessors getScriptProcessor(){
        return this.scriptProcessor;
    }
}