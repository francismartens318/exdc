package com.exalate.api.exception.script;

import com.exalate.api.domain.ErrorEntityType;

public class IssueTrackerScriptException extends ScriptException {
    public IssueTrackerScriptException(String message) {
        super(message);
    }

    public IssueTrackerScriptException(String message, Throwable cause) {
        super(message, cause);
    }

    public IssueTrackerScriptException(Throwable cause) {
        super(cause);
    }

    @Override
    public String getDocsLink() {
        return "";
    }

    @Override
    public ErrorEntityType getErrorEntityType() {
        return ErrorEntityType.ISSUE;
    }

}
