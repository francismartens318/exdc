package com.exalate.api.exception.script;

import com.exalate.api.domain.ErrorEntityType;

public class CreateProcessorException extends ScriptException {
    private ErrorEntityType errorEntityType;

    public CreateProcessorException(String message) {
        super(message);
    }

    public CreateProcessorException(String message, Throwable t) {
        super(message, t);
    }

    public CreateProcessorException(Throwable t) {
        super(t);
    }

    public CreateProcessorException(String message, Throwable t, ErrorEntityType errorEntityType) {
        super(message, t);
        this.errorEntityType = errorEntityType;
    }

    @Override
    public ErrorEntityType getErrorEntityType() {
        if(this.errorEntityType != null) return this.errorEntityType;
        return super.getErrorEntityType();
    }

    @Override
    public String getRootCauseErrorTypeName() {
        return "Incoming sync: first sync error";
    }
}
