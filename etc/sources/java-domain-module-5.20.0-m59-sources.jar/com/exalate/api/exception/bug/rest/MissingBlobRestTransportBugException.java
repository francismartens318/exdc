package com.exalate.api.exception.bug.rest;

public class MissingBlobRestTransportBugException extends RestTransportBugException {

    public MissingBlobRestTransportBugException(String message) {
        super(message);
    }

    public MissingBlobRestTransportBugException(String message, Throwable cause) {
        super(message, cause);
    }

    public MissingBlobRestTransportBugException(Throwable cause) {
        super(cause);
    }

    @Override
    public String getDocsLink() {
        return "";
    }

    @Override
    public String getRootCauseErrorTypeName() {
        return "Attachment error";
    }
}
