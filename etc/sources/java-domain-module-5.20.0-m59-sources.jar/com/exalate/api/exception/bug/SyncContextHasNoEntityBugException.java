package com.exalate.api.exception.bug;


public class SyncContextHasNoEntityBugException extends BugException {

    public SyncContextHasNoEntityBugException(String message) {
        super(message);
    }

    public SyncContextHasNoEntityBugException(String message, Throwable cause) {
        super(message, cause);
    }

    public SyncContextHasNoEntityBugException(Throwable cause) {
        super(cause);
    }

    @Override
    public String getDocsLink() {
        return "";
    }

}
