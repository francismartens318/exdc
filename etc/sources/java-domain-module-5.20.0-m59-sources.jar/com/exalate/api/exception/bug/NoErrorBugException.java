package com.exalate.api.exception.bug;


public class NoErrorBugException extends BugException {

    public NoErrorBugException(String message) {
        super(message);
    }

    public NoErrorBugException(String message, Throwable cause) {
        super(message, cause);
    }

    public NoErrorBugException(Throwable cause) {
        super(cause);
    }

    @Override
    public String getDocsLink() {
        return "";
    }

    @Override
    public String getRootCauseErrorTypeName() {
        return "Unexpected error";
    }
}
