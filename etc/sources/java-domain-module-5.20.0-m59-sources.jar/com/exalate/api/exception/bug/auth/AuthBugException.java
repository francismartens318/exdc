package com.exalate.api.exception.bug.auth;

import com.exalate.api.exception.bug.BugException;

public class AuthBugException extends BugException {

    public AuthBugException(String message) {
        super(message);
    }

    public AuthBugException(String message, Throwable cause) {
        super(message, cause);
    }

    public AuthBugException(Throwable cause) {
        super(cause);
    }

    @Override
    public String getDocsLink() {
        return "";
    }

    @Override
    public String getRootCauseErrorTypeName() {
        return "Unexpected auth error";
    }
}
