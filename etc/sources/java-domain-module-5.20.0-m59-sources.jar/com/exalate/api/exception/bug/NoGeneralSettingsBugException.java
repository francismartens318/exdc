package com.exalate.api.exception.bug;


public class NoGeneralSettingsBugException extends BugException {

    public NoGeneralSettingsBugException(String message) {
        super(message);
    }

    public NoGeneralSettingsBugException(String message, Throwable cause) {
        super(message, cause);
    }

    public NoGeneralSettingsBugException(Throwable cause) {
        super(cause);
    }

    @Override
    public String getDocsLink() {
        return "";
    }

    @Override
    public String getRootCauseErrorTypeName() {
        return "General configuration error";
    }
}
