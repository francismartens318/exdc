package com.exalate.api.exception.bug;


public class NoBlobFilePathBugException extends BugException {

    public NoBlobFilePathBugException(String message) {
        super(message);
    }

    public NoBlobFilePathBugException(String message, Throwable cause) {
        super(message, cause);
    }

    public NoBlobFilePathBugException(Throwable cause) {
        super(cause);
    }

    @Override
    public String getDocsLink() {
        return "https://docs.exalate.com/docs/error-handling";
    }

    @Override
    public String getRootCauseErrorTypeName() {
        return "NoBlobFilePathBugException";
    }
}
