package com.exalate.api.exception.bug;


public class NoBlobEventBugException extends BugException {

    public NoBlobEventBugException(String message) {
        super(message);
    }

    public NoBlobEventBugException(String message, Throwable cause) {
        super(message, cause);
    }

    public NoBlobEventBugException(Throwable cause) {
        super(cause);
    }

    @Override
    public String getDocsLink() {
        return "";
    }

    @Override
    public String getRootCauseErrorTypeName() {
        return "Attachment error";
    }
}
