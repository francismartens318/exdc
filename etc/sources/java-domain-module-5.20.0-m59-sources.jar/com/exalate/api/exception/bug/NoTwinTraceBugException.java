package com.exalate.api.exception.bug;


public class NoTwinTraceBugException extends BugException {

    public NoTwinTraceBugException(String message) {
        super(message);
    }

    public NoTwinTraceBugException(String message, Throwable cause) {
        super(message, cause);
    }

    public NoTwinTraceBugException(Throwable cause) {
        super(cause);
    }

    @Override
    public String getDocsLink() {
        return "";
    }

}
