package com.exalate.api.exception.bug;


public class NoBlobInFilePathBugException extends BugException {

    public NoBlobInFilePathBugException(String message) {
        super(message);
    }

    public NoBlobInFilePathBugException(String message, Throwable cause) {
        super(message, cause);
    }

    public NoBlobInFilePathBugException(Throwable cause) {
        super(cause);
    }

    @Override
    public String getDocsLink() {
        return "";
    }

    @Override
    public String getRootCauseErrorTypeName() {
        return "Attachment error";
    }
}
