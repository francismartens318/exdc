package com.exalate.api.exception.bug;


public class NoExternalJWTfoundBugException extends BugException {

    public NoExternalJWTfoundBugException(String message) {
        super(message);
    }

    public NoExternalJWTfoundBugException(String message, Throwable cause) {
        super(message, cause);
    }

    public NoExternalJWTfoundBugException(Throwable cause) {
        super(cause);
    }

    @Override
    public String getDocsLink() {
        return "";
    }

    @Override
    public String getRootCauseErrorTypeName() {
        return "Unexpected error";
    }
}
