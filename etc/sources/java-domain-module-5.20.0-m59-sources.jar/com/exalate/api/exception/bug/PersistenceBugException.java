package com.exalate.api.exception.bug;

public class PersistenceBugException extends BugException {
    public PersistenceBugException(String message) {
        super(message);
    }

    public PersistenceBugException(String message, Throwable cause) {
        super(message, cause);
    }

    public PersistenceBugException(Throwable cause) {
        super(cause);
    }

    @Override
    public String getDocsLink() {
        return "";
    }

    @Override
    public String getRootCauseErrorTypeName() {
        return "Database error";
    }
}
