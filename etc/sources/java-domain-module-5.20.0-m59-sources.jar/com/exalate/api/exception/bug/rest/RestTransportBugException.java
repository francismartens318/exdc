package com.exalate.api.exception.bug.rest;

import com.exalate.api.exception.bug.BugException;

public class RestTransportBugException extends BugException {

    public RestTransportBugException(String message) {
        super(message);
    }

    public RestTransportBugException(String message, Throwable cause) {
        super(message, cause);
    }

    public RestTransportBugException(Throwable cause) {
        super(cause);
    }

    @Override
    public String getDocsLink() {
        return "";
    }

}
