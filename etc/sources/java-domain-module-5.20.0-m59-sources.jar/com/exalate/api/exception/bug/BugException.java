package com.exalate.api.exception.bug;

import com.exalate.api.domain.ErrorEntityType;
import com.exalate.api.exception.CategorizedException;

public class BugException extends CategorizedException {
    public BugException(String message) {
        super(message);
    }

    public BugException(String message, Throwable cause) {
        super(message, cause);
    }

    public BugException(Throwable cause) {
        super(cause);
    }

    @Override
    public String getDocsLink() {
        return "";
    }

    @Override
    public String getRootCauseErrorTypeName() {
        return "Unexpected error";
    }

    @Override
    public ErrorEntityType getErrorEntityType() {
        return ErrorEntityType.ISSUE;
    }
}
