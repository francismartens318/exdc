package com.exalate.api.exception.bug;


public class GettingLocalNodeInfoFailedBugException extends BugException {

    public GettingLocalNodeInfoFailedBugException(String message) {
        super(message);
    }

    public GettingLocalNodeInfoFailedBugException(String message, Throwable cause) {
        super(message, cause);
    }

    public GettingLocalNodeInfoFailedBugException(Throwable cause) {
        super(cause);
    }

    @Override
    public String getDocsLink() {
        return "";
    }

}
