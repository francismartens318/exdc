package com.exalate.api.exception.bug;


public class AutocompleteBugException extends BugException {

    public AutocompleteBugException(String message) {
        super(message);
    }

    public AutocompleteBugException(String message, Throwable cause) {
        super(message, cause);
    }

    public AutocompleteBugException(Throwable cause) {
        super(cause);
    }

    @Override
    public String getDocsLink() {
        return "https://docs.exalate.com/docs/error-handling";
    }

}
