package com.exalate.api.exception.bug;


public class JsonConvertingFailedBugException extends BugException {

    public JsonConvertingFailedBugException(String message) {
        super(message);
    }

    public JsonConvertingFailedBugException(String message, Throwable cause) {
        super(message, cause);
    }

    public JsonConvertingFailedBugException(Throwable cause) {
        super(cause);
    }

    @Override
    public String getDocsLink() {
        return "";
    }

}
