package com.exalate.api.exception.bug;


public class NoBlobRequestBugException extends BugException {

    public NoBlobRequestBugException(String message) {
        super(message);
    }

    public NoBlobRequestBugException(String message, Throwable cause) {
        super(message, cause);
    }

    public NoBlobRequestBugException(Throwable cause) {
        super(cause);
    }

    @Override
    public String getDocsLink() {
        return "";
    }

    @Override
    public String getRootCauseErrorTypeName() {
        return "Attachment error";
    }
}
