package com.exalate.api.exception.bug;


public class NoConnectionForReceivedJWTBugException extends BugException {

    public NoConnectionForReceivedJWTBugException(String message) {
        super(message);
    }

    public NoConnectionForReceivedJWTBugException(String message, Throwable cause) {
        super(message, cause);
    }

    public NoConnectionForReceivedJWTBugException(Throwable cause) {
        super(cause);
    }

    @Override
    public String getDocsLink() {
        return "";
    }

    @Override
    public String getRootCauseErrorTypeName() {
        return "Connection error";
    }
}
