package com.exalate.api.exception.bug;


public class NoConnectionBugException extends BugException {

    public NoConnectionBugException(String message) {
        super(message);
    }

    public NoConnectionBugException(String message, Throwable cause) {
        super(message, cause);
    }

    public NoConnectionBugException(Throwable cause) {
        super(cause);
    }

    @Override
    public String getDocsLink() {
        return "";
    }

    @Override
    public String getRootCauseErrorTypeName() {
        return "Connection error";
    }
}
