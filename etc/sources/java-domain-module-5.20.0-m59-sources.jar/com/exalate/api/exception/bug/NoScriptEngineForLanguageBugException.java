package com.exalate.api.exception.bug;


public class NoScriptEngineForLanguageBugException extends BugException {

    public NoScriptEngineForLanguageBugException(String message) {
        super(message);
    }

    public NoScriptEngineForLanguageBugException(String message, Throwable cause) {
        super(message, cause);
    }

    public NoScriptEngineForLanguageBugException(Throwable cause) {
        super(cause);
    }

    @Override
    public String getDocsLink() {
        return "";
    }

}
