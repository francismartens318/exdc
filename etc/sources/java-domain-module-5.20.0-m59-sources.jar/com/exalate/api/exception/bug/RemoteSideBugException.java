package com.exalate.api.exception.bug;

public class RemoteSideBugException extends BugException {

    public RemoteSideBugException(String message) {
        super(message);
    }

    public RemoteSideBugException(String message, Throwable cause) {
        super(message, cause);
    }

    public RemoteSideBugException(Throwable cause) {
        super(cause);
    }

    @Override
    public String getDocsLink() {
        return "";
    }

    @Override
    public String getRootCauseErrorTypeName() {
        return "Unexpected error on destination side";
    }
}
