package com.exalate.api.exception

trait RetriableException extends Exception
