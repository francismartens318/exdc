package com.exalate.api.exception.config;

import com.exalate.api.exception.CategorizedException;

public abstract class ExalateConfigException extends CategorizedException {

    public ExalateConfigException(String message) {
        super(message);
    }

    public ExalateConfigException(String message, Throwable cause) {
        super(message, cause);
    }

    public ExalateConfigException(Throwable cause) {
        super(cause);
    }
}
