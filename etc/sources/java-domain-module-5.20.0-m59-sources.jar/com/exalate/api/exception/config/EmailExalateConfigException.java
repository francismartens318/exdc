package com.exalate.api.exception.config;

public class EmailExalateConfigException extends ExalateConfigException {

    public EmailExalateConfigException(String message) {
        super(message);
    }

    public EmailExalateConfigException(String message, Throwable cause) {
        super(message, cause);
    }

    public EmailExalateConfigException(Throwable cause) {
        super(cause);
    }

    @Override
    public String getDocsLink() {
        return "";
    }

    @Override
    public String getRootCauseErrorTypeName() {
        return "Email configuration error";
    }
}
