package com.exalate.api.exception;


import com.exalate.api.domain.ErrorEntityType;


public class IssueTrackerException extends CategorizedException {

    public IssueTrackerException(String message) {
        super(message);
    }

    public IssueTrackerException(String message, Throwable t) {
        super(message,t);
    }

    public IssueTrackerException(Throwable t) {
        super(t);
    }

    @Override
    public String getDocsLink() {
        return "";
    }

    @Override
    public String getRootCauseErrorTypeName() {
        return "Issue Tracker Error";
    }

    @Override
    public ErrorEntityType getErrorEntityType() {
        return ErrorEntityType.ISSUE;
    }
}
