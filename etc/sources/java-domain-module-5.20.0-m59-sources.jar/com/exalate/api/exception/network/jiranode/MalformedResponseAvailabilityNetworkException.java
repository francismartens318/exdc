package com.exalate.api.exception.network.jiranode;


import com.exalate.api.exception.network.AvailabilityNetworkException;

import javax.net.ssl.SSLException;

/**
 * Indicates that server returned a malformed response
 */

public class MalformedResponseAvailabilityNetworkException extends AvailabilityNetworkException {

    public MalformedResponseAvailabilityNetworkException(String message) {
        super(message);
    }

    public MalformedResponseAvailabilityNetworkException(String message, Exception cause) {
        super(message, cause);
    }

    public MalformedResponseAvailabilityNetworkException(Exception cause) {
        super(cause);
    }

    @Override
    public synchronized SSLException getCause() {
        return (SSLException) super.getCause();
    }

}
