package com.exalate.api.exception.network.jiranode;


import com.exalate.api.exception.network.AvailabilityNetworkException;


public class IOAvailabilityNetworkException extends AvailabilityNetworkException {

    public IOAvailabilityNetworkException(String message) {
        super(message);
    }

    public IOAvailabilityNetworkException(String message, Exception cause) {
        super(message, cause);
    }

    public IOAvailabilityNetworkException(Exception cause) {
        super(cause);
    }

}
