package com.exalate.api.exception.network;


import com.exalate.api.exception.bug.BugException;

public class RetriesForBlobExceededAvailabilityNetworkException extends AvailabilityNetworkException {

    public RetriesForBlobExceededAvailabilityNetworkException(String message) {
        super(message);
    }

    public RetriesForBlobExceededAvailabilityNetworkException(String message, Throwable cause) {
        super(message, cause);
    }

    public RetriesForBlobExceededAvailabilityNetworkException(Throwable cause) {
        super(cause);
    }

}
