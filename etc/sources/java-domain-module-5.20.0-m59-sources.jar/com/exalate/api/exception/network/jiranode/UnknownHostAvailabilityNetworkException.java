package com.exalate.api.exception.network.jiranode;


import com.exalate.api.exception.network.AvailabilityNetworkException;

import java.net.UnknownHostException;


public class UnknownHostAvailabilityNetworkException extends AvailabilityNetworkException {

    public UnknownHostAvailabilityNetworkException(String message) {
        super(message);
    }

    public UnknownHostAvailabilityNetworkException(String message, UnknownHostException cause) {
        super(message, cause);
    }

    public UnknownHostAvailabilityNetworkException(UnknownHostException cause) {
        super(cause);
    }

}
