package com.exalate.api.exception.network;

import com.exalate.api.domain.ErrorEntityType;
import com.exalate.api.exception.CategorizedException;

public class AvailabilityNetworkException extends CategorizedException {

    public AvailabilityNetworkException(String message) {
        super(message);
    }

    public AvailabilityNetworkException(String message, Throwable cause) {
        super(message, cause);
    }

    public AvailabilityNetworkException(Throwable cause) {
        super(cause);
    }

    @Override
    public String getDocsLink() {
        return "https://docs.exalate.com/docs/error-handling";
    }

    @Override
    public ErrorEntityType getErrorEntityType() {
        return ErrorEntityType.ISSUE;
    }

    @Override
    public String getRootCauseErrorTypeName() {
        return "Network error";
    }
}
