package com.exalate.api.exception.network.jiranode;

import com.exalate.api.exception.network.AvailabilityNetworkException;

import javax.net.ssl.SSLException;

public class SslAvailabilityNetworkException extends AvailabilityNetworkException {

    public SslAvailabilityNetworkException(String message) {
        super(message);
    }

    public SslAvailabilityNetworkException(String message, SSLException cause) {
        super(message, cause);
    }

    public SslAvailabilityNetworkException(SSLException cause) {
        super(cause);
    }

    @Override
    public synchronized SSLException getCause() {
        return (SSLException) super.getCause();
    }

    @Override
    public String getDocsLink() {
        return "https://docs.idalko.com/exalate/x/IQAM";
    }
}