package com.exalate.api.exception.network;

public class ChecksumMismatchNetworkException extends AvailabilityNetworkException {

    public ChecksumMismatchNetworkException(String message) {
        super(message);
    }

    public ChecksumMismatchNetworkException(String message, Throwable cause) {
        super(message, cause);
    }

    public ChecksumMismatchNetworkException(Throwable cause) {
        super(cause);
    }

    @Override
    public String getRootCauseErrorTypeName() {
        return "Checksum mismatch network error";
    }

}
