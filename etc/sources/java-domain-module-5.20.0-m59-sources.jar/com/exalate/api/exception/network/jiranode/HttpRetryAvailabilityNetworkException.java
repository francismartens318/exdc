package com.exalate.api.exception.network.jiranode;

import com.exalate.api.exception.network.AvailabilityNetworkException;

import java.net.HttpRetryException;

/**
 * Indicates that HTTP request automatic retry is not performed due to streaming mode being enabled.
 */
public class HttpRetryAvailabilityNetworkException extends AvailabilityNetworkException {

    public HttpRetryAvailabilityNetworkException(String message) {
        super(message);
    }

    public HttpRetryAvailabilityNetworkException(String message, HttpRetryException cause) {
        super(message, cause);
    }

    public HttpRetryAvailabilityNetworkException(HttpRetryException cause) {
        super(cause);
    }

}
