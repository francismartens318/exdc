package com.exalate.api.exception.network.retriable;

import com.exalate.api.exception.RetriableException;
import com.exalate.api.exception.network.AvailabilityNetworkException;

public class TimeoutTransportAvailabilityNetworkException extends AvailabilityNetworkException implements RetriableException {

    public TimeoutTransportAvailabilityNetworkException(String message) {
        super(message);
    }

    public TimeoutTransportAvailabilityNetworkException(String message, Throwable cause) {
        super(message, cause);
    }

    public TimeoutTransportAvailabilityNetworkException(Throwable cause) {
        super(cause);
    }
}
