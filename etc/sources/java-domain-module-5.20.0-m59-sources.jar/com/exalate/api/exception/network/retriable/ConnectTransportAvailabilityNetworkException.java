package com.exalate.api.exception.network.retriable;

import com.exalate.api.domain.ErrorEntityType;
import com.exalate.api.exception.RetriableException;
import com.exalate.api.exception.network.AvailabilityNetworkException;

public class ConnectTransportAvailabilityNetworkException extends AvailabilityNetworkException implements RetriableException {

    public ConnectTransportAvailabilityNetworkException(String message) {
        super(message);
    }

    public ConnectTransportAvailabilityNetworkException(String message, Throwable cause) {
        super(message, cause);
    }

    public ConnectTransportAvailabilityNetworkException(Throwable cause) {
        super(cause);
    }

    @Override
    public ErrorEntityType getErrorEntityType() {
        return ErrorEntityType.ISSUE;
    }
}