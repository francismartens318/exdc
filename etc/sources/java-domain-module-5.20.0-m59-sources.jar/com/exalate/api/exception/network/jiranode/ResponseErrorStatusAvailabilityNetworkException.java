package com.exalate.api.exception.network.jiranode;


import com.exalate.api.exception.network.AvailabilityNetworkException;



public class ResponseErrorStatusAvailabilityNetworkException extends AvailabilityNetworkException {

    public ResponseErrorStatusAvailabilityNetworkException(String message) {
        super(message);
    }

    public ResponseErrorStatusAvailabilityNetworkException(String message, Exception cause) {
        super(message, cause);
    }

    public ResponseErrorStatusAvailabilityNetworkException(Exception cause) {
        super(cause);
    }

}
