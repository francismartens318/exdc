package com.exalate.api.exception.lifecycle;

import com.exalate.api.domain.ErrorEntityType;
import com.exalate.api.exception.CategorizedException;

public class LifecycleExpirationWarningException extends CategorizedException {

    public LifecycleExpirationWarningException(String message) {
        super(message);
    }

    public LifecycleExpirationWarningException(String message, Throwable cause) {
        super(message, cause);
    }

    public LifecycleExpirationWarningException(Throwable cause) {
        super(cause);
    }

    @Override
    public String getDocsLink() {
        return "https://docs.exalate.com/docs/release-history";
    }

    @Override
    public ErrorEntityType getErrorEntityType() {
        return ErrorEntityType.WARNING;
    }

    @Override
    public String getRootCauseErrorTypeName() {
        return "Lifecycle expiration warning error";
    }
}