package com.exalate.api.exception.connection;

import com.exalate.api.exception.CategorizedException;

public class NoConnectionException extends CategorizedException {
    public NoConnectionException(String message) {
        super(message);
    }

    public NoConnectionException(String message, Throwable cause) {
        super(message, cause);
    }

    public NoConnectionException(Throwable cause) {
        super(cause);
    }

    @Override
    public String getDocsLink() {
        return "";
    }

    @Override
    public String getRootCauseErrorTypeName() {
        return "Connection not found";
    }
}

