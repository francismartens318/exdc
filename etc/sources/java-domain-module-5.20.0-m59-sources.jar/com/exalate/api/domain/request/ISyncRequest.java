package com.exalate.api.domain.request;


import com.exalate.api.domain.*;
import com.exalate.api.domain.license.ISubscriptionContext;
import com.exalate.api.domain.connection.IConnection;
import com.exalate.api.domain.twintrace.ITrace;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.List;



public interface ISyncRequest {

    /**
     * @return The unique identifier of this request.
     */
    public int getId();

    /**
     * @return The unique identifier of the sync event on the destination instance that lead to this sync request.
     */
    public int getRemoteSyncEventId();

    /**
     * Every sync event of an issue has a sequence number so they can be processed in chronological order.
     *
     * @return Long sequence number of the remote sync event
     */
    public Long getRemoteSyncEventNumber();


    /**
     * @return The remote twin trace id the remote event creating this request is related with.
     */
    @Nullable
    public Integer getRemoteTwinTraceId();

    /**
     * @return String the URN of a local issue requested to be
     * connected to the remote issue from the replica
     */
    public String getConnectIssueUrn();

    public IPersistentConnectContext getConnectContext();

    /**
     * @return String the URN of a remote issue, which has
     * previously been connected to the local issue and has
     * been deleted
     */
    public String getDeletedRemoteIssueUrn();

    /**
     * @return String the URN of a remote issue, which has
     * previously been connected to the local issue and has
     * been unexalated
     *
     */
    public String getUnexalateRemoteIssueUrn();

    public String getErrorResponseMessage();

    public void setErrorResponseMessage(String errorResponseMessage);

    /**
     * @return The relation that specifies how and where the issue should be synced to.
     */
    public IConnection getConnection();

    /**
     * @return IPersistentReplica of the issue to pair. This is the remote issue.
     */
    public IPersistentReplica getReplica();

    /**
     * returns a list of blobs (blob meta info) to be received
     */
    @Nonnull
    public List<IBlobMetadata> getBlobMetadataList();

    @Nonnull
    public List<ITrace> getTraces();

    /**
     * @return The IIssueKey that was created for the replica in the request or null if no issue was created (yet)
     */
    public IIssueKey getCreatedIssueKey();

    /**
     * Sets the key of the issue that was created for the replica in the request.
     */
    public void setCreatedIssueKey(IIssueKey createdIssueKey);

    /**
     * @return The IIssueKey of the issue in the sending side that will be synchronized, null on pair requests.
     * <p>
     * Example:
     * If JIRA A syncs to JIRA B,
     * issue A1 is exalated to B
     * the sync request, sent from A has:
     * {
     * "replica": {
     * ...
     * "issueKey": {
     * "id": 10000,
     * "urn": "A-1"
     * }
     * },
     * "syncedTo": null
     * }
     * <p>
     * if issue A1 is synced to B1,
     * and an update occurred on A1, then
     * the sync request sent from A has:
     * <p>
     * {
     * "replica": {
     * ...
     * "issueKey": {
     * "id": 10000,
     * "urn": "A-1"
     * }
     * },
     * "syncedTo": {
     * "id": 20000,
     * "urn": "B-1"
     * }
     * }
     */
    @Nullable
    public IIssueKey getSyncedTo();

    public IPersistentReplica getUpdatedReplica();

    public void setUpdatedReplica(IPersistentReplica replica);

    /**
     * @return The status indicating whether this request still needs to be processed or not.
     */
    public RequestStatus getStatus();

    public void setStatus(RequestStatus status);

    /**
     * @return ErrorReason that has been set during a state transition.
     */
    public ErrorReason getErrorReason();

    public void setErrorReason(ErrorReason errorReason);

    public boolean isPayed();
    public ISubscriptionContext getSubscriptionContext();

    /**
     * user that will be used to perform interactions with the issue tracker during the request processing
     * */
    public String getProxyUser();

    /**
     * state if this request is currently updating an issue
     * */
    public boolean isChangingIssue();
    public void setChangingIssue(boolean changingIssue);

    /**
     * one of SyncRequestEventType, represents type of sync request
     */
    public SyncRequestEventType getSyncType();
    public void setSyncType(SyncRequestEventType type);

    Integer getPriority();
    void setPriority(Integer priority);
}
