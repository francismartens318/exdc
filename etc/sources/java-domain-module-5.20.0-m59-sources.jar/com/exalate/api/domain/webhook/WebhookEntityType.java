package com.exalate.api.domain.webhook;

public enum WebhookEntityType {
    WORKLOG_CREATED,
    WORKLOG_UPDATED,
    COMMENT_CREATED,
    COMMENT_UPDATED,
    ISSUE_CREATED
}
