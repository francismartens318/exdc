package com.exalate.api.domain.webhook;



import javax.annotation.Nonnull;
import javax.annotation.Nullable;


public interface IWebhookInfo {

    @Nonnull
    int getId();

    @Nonnull
    String getIssueId();

    @Nonnull
    String getIssueUrn();

    @Nonnull
    String getUserKey();

    @Nonnull
    WebhookEntityType getEntityType();

    @Nonnull
    String getEntityId();

    @Nonnull
    String getEntityJson();

}
