package com.exalate.api.domain.error;

public enum RetryStrategy {
    FIXED_INTERVAL
}
