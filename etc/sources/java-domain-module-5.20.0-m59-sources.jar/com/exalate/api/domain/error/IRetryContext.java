package com.exalate.api.domain.error;

import com.exalate.api.domain.blob.event.IBlobEvent;
import com.exalate.api.domain.blob.request.IBlobRequest;
import com.exalate.api.domain.event.ISyncEvent;
import com.exalate.api.domain.request.ISyncRequest;

import java.util.Date;

public interface IRetryContext {

    public int getId();

    public Date getNextRetry();

    public int getAttemptedRetries();

    public RetryStrategy getRetryStrategy();

    public ISyncEvent getSyncEvent();

    public ISyncRequest getSyncRequest();

    public IBlobEvent getBlobEvent();

    public IBlobRequest getBlobRequest();
}
