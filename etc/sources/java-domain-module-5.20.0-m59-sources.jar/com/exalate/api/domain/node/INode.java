/*
 * Copyright (C) 2015, Exalate NV
 * All rights reserved.
 *
 *
 * THIS SOURCE CODE IS AN UNPUBLISHED PROPRIETARY TRADE SECRET OF iDalko NV, unless stated otherwise
 * in the license text.
 *
 *
 * The copyright notice above does not evidence any actual or intended publication of such source code.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
 */
package com.exalate.api.domain.node;


import com.exalate.api.domain.nodeinfo.INodeInfo;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;


public interface INode {
    public int getId();

    public String getProxyUser();

    /**
     * @return whether (true if) email notifications are sent when an error blocks the sync
     * */
    public boolean isEmailNotificationEnabled();
    /**
     * @return whether (true if) jira notifications are shown when an error blocks the sync
     * */
    public boolean isJiraNotificationEnabled();

    public boolean isAuthenticationRequired();

    public boolean isPollOnly();

    public boolean isExalateEnabled();

    public boolean isUnexalateEnabled();

    public boolean isShowDisabledConnections();

    public String getPublicUrl();

    public long getPollingFrequency();

    @Nullable
    public String getInstanceUid();

    /**
     * are the input parameters for a {@link INode} creation / modification
     */
    public interface Parameters {
        public String getProxyUser();
        public boolean isEmailNotification();
        public boolean isJiraNotification();
        public boolean isAuthRequired();
        public boolean isPollOnly();
        public boolean isExalateEnabled();
        public boolean isUnexalateEnabled();
        public boolean isShowDisabledConnections();
        public String getPublicUrl();
        public long getPollingFrequency();
        public String getInstanceUid();

        public interface Builder {
            public Builder addProxyUser(@Nonnull String proxyUser);

            public Builder addEmailNotifications(boolean emailNotifications);

            public Builder addJiraNotifications(boolean jiraNotifications);

            public Builder addAuthRequired(boolean authRequired);

            public Builder addPollOnly(boolean pollOnly);

            public Builder addExalateEnabled(boolean exalateEnabled);

            public Builder addUnexalateEnabled(boolean unexalateEnabled);

            public Builder addShowDisabledConnections(boolean showDisabledConnections);

            public Builder addPublicUrl(String publicUrl);

            public Builder addPollingFrequency(long pollingFrequency);

            public Builder addInstanceUid(String instanceUid);

            public Parameters build();
        }
    }
}
