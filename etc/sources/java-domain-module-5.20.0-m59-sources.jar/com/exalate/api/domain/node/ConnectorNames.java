package com.exalate.api.domain.node;

public class ConnectorNames {

    public static final String AZURE_DEVOPS = "azurenode";
    public static final String GITHUB = "githubnode";
    public static final String JCLOUD = "jcloudnode";
    public static final String SERVICE_NOW = "snownode";
    public static final String SALESFORCE = "salesforcenode";
    public static final String ZENDESK = "zendesknode";

    public static final String[] ALL = {AZURE_DEVOPS, GITHUB, JCLOUD, SERVICE_NOW, SALESFORCE, ZENDESK};
}
