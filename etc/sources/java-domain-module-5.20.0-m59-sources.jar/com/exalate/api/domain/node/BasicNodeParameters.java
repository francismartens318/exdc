/*
 * Copyright (C) 2015, Exalate NV
 * All rights reserved.
 *
 *
 * THIS SOURCE CODE IS AN UNPUBLISHED PROPRIETARY TRADE SECRET OF iDalko NV, unless stated otherwise
 * in the license text.
 *
 *
 * The copyright notice above does not evidence any actual or intended publication of such source code.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
 */
package com.exalate.api.domain.node;



import javax.annotation.Nonnull;


public final class BasicNodeParameters implements INode.Parameters, INode.Parameters.Builder {

    private final String proxyUser;
    private final boolean emailNotifications;
    private final boolean jiraNotifications;
    private final boolean authRequired;
    private final boolean pollOnly;
    private final boolean exalateEnabled;
    private final boolean unexalateEnabled;
    private final boolean showDisabledConnections;
    private final String publicUrl;
    private final long pollingFrequency;
    private final String instanceUid;

    private BasicNodeParameters(String proxyUser, boolean emailNotifications, boolean jiraNotifications, boolean authRequired, boolean pollOnly,
                                boolean exalateEnabled, boolean unexalateEnabled, boolean showDisabledConnections, String publicUrl, long pollingFrequency, String instanceUid) {
        this.proxyUser = proxyUser;
        this.emailNotifications = emailNotifications;
        this.jiraNotifications = jiraNotifications;
        this.authRequired = authRequired;
        this.pollOnly = pollOnly;
        this.exalateEnabled = exalateEnabled;
        this.unexalateEnabled = unexalateEnabled;
        this.showDisabledConnections = showDisabledConnections;
        this.publicUrl = publicUrl;
        this.pollingFrequency = pollingFrequency;
        this.instanceUid = instanceUid;
    }

    @Override
    public String getProxyUser() {
        return proxyUser;
    }

    @Override
    public boolean isEmailNotification() {
        return emailNotifications;
    }

    @Override
    public boolean isJiraNotification() {
        return jiraNotifications;
    }

    @Override
    public boolean isAuthRequired(){
        return authRequired;
    }

    @Override
    public boolean isPollOnly() {
        return pollOnly;
    }

    public boolean isExalateEnabled(){
        return exalateEnabled;
    }

    public boolean isUnexalateEnabled(){
        return unexalateEnabled;
    }

    @Override
    public boolean isShowDisabledConnections() {
        return showDisabledConnections;
    }

    @Override
    public String getPublicUrl() {
        return publicUrl;
    }

    @Override
    public long getPollingFrequency() {
        return pollingFrequency;
    }

    @Override
    public String getInstanceUid() {
        return instanceUid;
    }

    @Override
    public BasicNodeParameters addProxyUser(@Nonnull String proxyUser) {
        return new BasicNodeParameters(proxyUser, emailNotifications, jiraNotifications, authRequired, pollOnly, exalateEnabled, unexalateEnabled, showDisabledConnections, publicUrl, pollingFrequency, instanceUid);
    }

    @Override
    public BasicNodeParameters addEmailNotifications(boolean emailNotifications) {
        return new BasicNodeParameters(proxyUser, emailNotifications, jiraNotifications, authRequired, pollOnly, exalateEnabled, unexalateEnabled, showDisabledConnections, publicUrl, pollingFrequency, instanceUid);
    }

    @Override
    public BasicNodeParameters addJiraNotifications(boolean jiraNotifications) {
        return new BasicNodeParameters(proxyUser, emailNotifications, jiraNotifications, authRequired, pollOnly, exalateEnabled, unexalateEnabled, showDisabledConnections, publicUrl, pollingFrequency, instanceUid);
    }

    @Override
    public Builder addAuthRequired(boolean authRequired) {
        return new BasicNodeParameters(proxyUser, emailNotifications, jiraNotifications, authRequired, pollOnly, exalateEnabled, unexalateEnabled, showDisabledConnections, publicUrl, pollingFrequency, instanceUid);
    }

    @Override
    public Builder addPollOnly(boolean pollOnly) {
        return new BasicNodeParameters(proxyUser, emailNotifications, jiraNotifications, authRequired, pollOnly, exalateEnabled, unexalateEnabled, showDisabledConnections, publicUrl, pollingFrequency, instanceUid);
    }

    public Builder addExalateEnabled(boolean exalateEnabled) {
        return new BasicNodeParameters(proxyUser, emailNotifications, jiraNotifications, authRequired, pollOnly, exalateEnabled, unexalateEnabled, showDisabledConnections, publicUrl, pollingFrequency, instanceUid);
    }

    public Builder addUnexalateEnabled(boolean unexalateEnabled) {
        return new BasicNodeParameters(proxyUser, emailNotifications, jiraNotifications, authRequired, pollOnly, exalateEnabled, unexalateEnabled, showDisabledConnections, publicUrl, pollingFrequency, instanceUid);
    }

    public Builder addShowDisabledConnections(boolean showDisabledConnections) {
        return new BasicNodeParameters(proxyUser, emailNotifications, jiraNotifications, authRequired, pollOnly, exalateEnabled, unexalateEnabled, showDisabledConnections, publicUrl, pollingFrequency, instanceUid);
    }

    @Override
    public Builder addPublicUrl(String publicUrl) {
        return new BasicNodeParameters(proxyUser, emailNotifications, jiraNotifications, authRequired, pollOnly, exalateEnabled, unexalateEnabled, showDisabledConnections, publicUrl, pollingFrequency, instanceUid);
    }

    @Override
    public Builder addPollingFrequency(long pollingFrequency) {
        return new BasicNodeParameters(proxyUser, emailNotifications, jiraNotifications, authRequired, pollOnly, exalateEnabled, unexalateEnabled, showDisabledConnections, publicUrl, pollingFrequency, instanceUid);
    }

    @Override
    public Builder addInstanceUid(String instanceUid) {
        return new BasicNodeParameters(proxyUser, emailNotifications, jiraNotifications, authRequired, pollOnly, exalateEnabled, unexalateEnabled, showDisabledConnections, publicUrl, pollingFrequency, instanceUid);
    }

    @Override
    public BasicNodeParameters build() {
        return this;
    }

    public static BasicNodeParameters builder() {
        //noinspection ConstantConditions
        return new BasicNodeParameters(null, false, false, false, false, true, true, true,null, 0L, null);
    }
}
