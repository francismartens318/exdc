package com.exalate.api.domain.node.storeblob;

public enum BlobStorageType {
    FILE_SYSTEM,
    S3,
    GOOGLE_STORE
}
