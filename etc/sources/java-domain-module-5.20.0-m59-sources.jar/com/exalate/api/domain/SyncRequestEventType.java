/*
 * Copyright (C) 2015, iDalko NV
 * All rights reserved.
 *
 *
 * THIS SOURCE CODE IS AN UNPUBLISHED PROPRIETARY TRADE SECRET OF iDalko NV, unless stated otherwise
 * in the license text.
 *
 *
 * The copyright notice above does not evidence any actual or intended publication of such source code.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
 */
package com.exalate.api.domain;

import com.google.common.base.Predicate;
import com.google.common.collect.Iterables;

import java.util.Arrays;


public enum SyncRequestEventType {
    EXALATE,
    UNEXALATE,
    UPDATE,
    CONNECT,
    DELETE,
    /**
     * Cleanup Events/Requests are special
     * They are processed before any other Sync Events/Requests
     * They are not blocked by any errors
     */
    CLEANUP,
    UNSUPPORTED;

    //!IMPORTANT use getValue instead of valueOf to handle unsupported sync types.
    public static SyncRequestEventType getValue(final String valueStr) {
        return Iterables.find(Arrays.asList(SyncRequestEventType.values()), new Predicate<SyncRequestEventType>(){
            public boolean apply(SyncRequestEventType t) {
                return t.name().equals(valueStr);
            }
        },UNSUPPORTED);
    }
}
