package com.exalate.api.domain;


import com.exalate.annotations.llm.LlmClass;
import com.exalate.annotations.llm.LlmMethod;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.Map;

import static com.exalate.api.domain.node.ConnectorNames.*;

@LlmClass(
        connectors = {AZURE_DEVOPS, GITHUB, JCLOUD, SERVICE_NOW, SALESFORCE, ZENDESK},
        description = "An interface representing a key for an issue in the issue tracker, providing methods to access key-specific information"
)
public interface IIssueKey {

    /**
     * The long id is a unique (for the whole issue tracker) identifier of the issue in an underlying database.
     * @return the issue unique identifier
     */
    @Nullable
    @LlmMethod(
            description = "Retrieves the unique (for the whole issue tracker) identifier of the issue in the underlying database"
    )
    public String getIdStr();

    /**
     * The urn is the uniform resource name as it can be used by humans to access the issue
     * @return the issue urn
     */
    @Nonnull
    @LlmMethod(
            description = "Retrieves the uniform resource name (URN) of the issue"
    )
    public String getURN();


    @Nonnull
    @LlmMethod(
            description = "Retrieves the type of the entity associated with the issue key"
    )
    public String getEntityType();

    /**
     * Contains extra logic for the key.
     * Ex: {"repo":"Exalate-team/test"}
     * @return map of field values
     */
    @Nonnull
    @LlmMethod(
            description = "Retrieves a map of additional field values associated with the issue key. Ex: {\"repo\":\"Exalate-team/test\"}"
    )
    public Map<String, String> getFieldValues();
}
