package com.exalate.api.domain;



/**
 * Is needed to say what blobs would be sent from sending side to receiving side.
 *
 * A blob metadata is created within one SyncEvent/ SyncRequest for one attachment (blob) to be sent.
 * The blob metadata is deleted when the synchronization act has finished.
 * */

public interface IBlobMetadata {

    public int getId();

    public String getBlobId();

    void setBlobId(String blobId);

    public String getBlobFilePath();

    public void setBlobFilePath(String blobPath);

    public String getChecksum();

    public void setChecksum(String checksum);

}
