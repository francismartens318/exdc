/*
 * Copyright (C) 2015, Exalate NV
 * All rights reserved.
 *
 *
 * THIS SOURCE CODE IS AN UNPUBLISHED PROPRIETARY TRADE SECRET OF iDalko NV, unless stated otherwise
 * in the license text.
 *
 *
 * The copyright notice above does not evidence any actual or intended publication of such source code.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
 */

package com.exalate.api.domain.instance;


import com.exalate.api.domain.nodeinfo.INodeInfo;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.net.URL;
import java.util.Map;


public interface IInstance {

    public int getID();

    public String getName();
    public void setName(String name);

    public String getDescription();
    public void setDescription(String description);

    /**
     * @return every instance has an url (even the ones which are not accessible over the net)
     */
    public URL getUrl();
    public void setUrl(URL url);

    @Nullable
    public URL getIssueTrackerUrl();
    public void setIssueTrackerUrl(@Nullable URL issueTrackerUrl);

    @Nonnull
    public InstanceStatus getStatus();

    @Nullable
    public INodeInfo getNodeInfo();

    public IInstanceIssueTrackerSettings getIssueTrackerSettings();

    public boolean isAuthenticationRequired();

    public String getRemoteUsername();
    public String getRemoteUserPassword();

    public String getCustomFieldValues();

    public Map<String, String> getFieldValues();
}
