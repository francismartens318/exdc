package com.exalate.api.domain.instance;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.net.URL;

public interface IInstanceIssueTrackerSettings {

    public int getID();

    @Nullable
    public String getUsername();

    @Nullable
    public String getPassword();

    @Nullable
    public Integer getPollingFrequency();

    @Nullable
    public URL getIssueTrackerUrl();

    @Nonnull
    public String getIssueTrackerType();

    @Nullable
    public String getClientKey();

    @Nullable
    public String getPublicKey();

    @Nullable
    public String getOAuthClientId();

    @Nullable
    public String getSharedSecret();

    @Nonnull
    public boolean isPollOnly();

    @Nonnull
    public boolean isShowExalateConnect();

    @Nonnull
    public boolean isShowUnexalate();

    @Nonnull
    public boolean isShowDisabledConnections();

    public String getPublicUrl();

}
