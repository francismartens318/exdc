package com.exalate.api.domain.instance;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.net.URL;

public interface INonPersistentInstanceIssueTrackerSettings {

    @Nullable
    public URL getIssueTrackerUrl();

    @Nullable
    public String getUsername();

    @Nullable
    public String getPassword();

    @Nullable
    public Integer getPollingFrequency();

    @Nonnull
    public String getIssueTrackerType();

    @Nullable
    public String getClientKey();

    @Nullable
    public String getPublicKey();

    @Nullable
    public String getOAuthClientId();

    @Nullable
    public String getSharedSecret();

    @Nonnull
    public boolean isPollOnly();

    @Nonnull
    public boolean isShowExalateConnect();

    @Nonnull
    public boolean isShowUnexalate();

    @Nonnull
    public boolean isShowDisabledConnections();

    @Nullable
    public String getPublicUrl();

    public interface Builder {
        @Nonnull
        public Builder setIssueTrackerUrl(URL url);

        @Nonnull
        public Builder setUsername(String username);

        @Nonnull
        public Builder setPassword(String password);

        @Nonnull
        public Builder setPollingFrequency(Integer pollingFrequency);

        @Nonnull
        public Builder setIssueTrackerType(String type);

        @Nonnull
        public Builder setClientKey(String clientKey);

        @Nonnull
        public Builder setPublicKey(String publicKey);

        @Nonnull
        public Builder setOAuthClientId(String oauthClientId);

        @Nonnull
        public Builder setSharedSecret(String sharedSecret);

        public Builder setPollOnly(boolean pollOnly);

        public Builder setShowExalateConnect(boolean showExalateConnect);

        public Builder setShowUnexalate(boolean showUnexalate);

        public Builder setShowDisabledConnections(boolean showDisabledConnections);

        public Builder setPublicUrl(String publicUrl);

        @Nonnull
        public INonPersistentInstanceIssueTrackerSettings build();
    }
}
