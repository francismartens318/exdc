package com.exalate.api.domain.twintrace;



import javax.annotation.Nonnull;
import javax.annotation.Nullable;

/**
 * Provides a trace from a field on a local issue to the same field on the remote issue. This is useful for fields that
 * can have multiple entries, like comments and attachments, to identify which entries have to be updated or deleted.
 */

public interface ITrace {

    public int getId();

    /**
     * @return The field type of this trace, e.g. "COMMENT", "ATTACHMENT", ...
     */
    @Nonnull
    public TraceType getType();

    /**
     * @return The local id of the field
     */
    @Nullable
    public String getLocalId();

    /**
     * @return The remote id of the field
     */
    @Nullable
    public String getRemoteId();

    /**
     * describes, what has happened lately to the local trace-able:
     * {@link TraceAction#NONE} - nothing happened to the trace-able
     * {@link TraceAction#CHANGE} - the trace-able has changed
     * {@link TraceAction#REMOVE} - the trace-able has been removed
     * @return traceAction
     */
    @Nonnull
    public TraceAction getAction();

    public boolean isToSynchronize();

    @Nullable
    public Integer getRequestId();

    @Nullable
    public Integer getTwinTraceId();

    @Nullable
    public Integer getEventId();
}
