/*
 * Copyright (C) 2015, iDalko NV
 * All rights reserved.
 *
 *
 * THIS SOURCE CODE IS AN UNPUBLISHED PROPRIETARY TRADE SECRET OF iDalko NV, unless stated otherwise
 * in the license text.
 *
 *
 * The copyright notice above does not evidence any actual or intended publication of such source code.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
 */
package com.exalate.api.domain.twintrace;

import com.exalate.annotations.llm.LlmClass;
import com.exalate.annotations.llm.LlmMethod;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import static com.exalate.api.domain.node.ConnectorNames.*;

@LlmClass(
        connectors = {AZURE_DEVOPS, GITHUB, JCLOUD, SERVICE_NOW, SALESFORCE, ZENDESK},
        description = "An interface representing a non-persistent trace in the synchronization context, providing methods to access trace-specific information"
)
public interface INonPersistentTrace {
    /**
     * @return The field type (the type of the trace-able) of this trace, e.g. "COMMENT", "ATTACHMENT", ...
     */
    @Nonnull
    @LlmMethod(
            description = "Retrieves the type of the trace-able field, such as 'COMMENT', 'ATTACHMENT', etc."
    )
    public TraceType getType();

    /**
     * @return The local id of the field (a trace-able)
     */
    @Nullable
    @LlmMethod(
            description = "Retrieves the local ID of the trace-able field"
    )
    public String getLocalId();

    /**
     * @return The remote id of the field (a trace-able)
     */
    @Nullable
    @LlmMethod(
            description = "Retrieves the remote ID of the trace-able field"
    )
    public String getRemoteId();

    /**
     * describes, what has happened lately to the local trace-able:
     * {@link TraceAction#NONE} - nothing happened to the trace-able
     * {@link TraceAction#CHANGE} - the trace-able has changed
     * {@link TraceAction#REMOVE} - the trace-able has been removed
     */
    @Nonnull
    @LlmMethod(
            description = "Retrieves the latest action that happened to the local trace-able field. " +
                    "TraceAction.NONE - nothing happened to the trace-able, " +
                    "TraceAction.CHANGE - the trace-able has changed, " +
                    "TraceAction.REMOVE - the trace-able has been removed."
    )
    public TraceAction getAction();

    @Nonnull
    @LlmMethod(
            description = "Checks whether the trace is set to be synchronized"
    )
    public boolean isToSynchronize();

    @Nullable
    @LlmMethod(
            description = "Retrieves the request ID associated with the trace"
    )
    public Integer getRequestId();

    @Nullable
    @LlmMethod(
            description = "Retrieves the twin trace ID associated with the trace"
    )
    public Integer getTwinTraceId();

    @Nullable
    @LlmMethod(
            description = "Retrieves the event ID associated with the trace"
    )
    public Integer getEventId();

    public interface Builder {
        @Nonnull
        public Builder setType(@Nonnull TraceType traceType);

        @Nonnull
        public Builder setLocalId(@Nonnull String localId);

        @Nonnull
        public Builder setRemoteId(@Nonnull String remoteId);

        @Nonnull
        public Builder setAction(@Nonnull TraceAction traceAction);

        @Nonnull
        public Builder setToSynchronize(boolean toSynchronize);

        @Nonnull
        public Builder setRequestId(int requestId);

        @Nonnull
        public Builder setTwinTraceId(int twinTraceId);

        @Nonnull
        public Builder setEventId(int eventId);

        @Nonnull
        public Builder from(@Nonnull ITrace trace);

        @Nonnull
        public Builder from(@Nonnull INonPersistentTrace trace);

        @Nonnull
        public INonPersistentTrace build();
    }
}
