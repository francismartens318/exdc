/*
 * Copyright (C) 2015, iDalko NV
 * All rights reserved.
 *
 *
 * THIS SOURCE CODE IS AN UNPUBLISHED PROPRIETARY TRADE SECRET OF iDalko NV, unless stated otherwise
 * in the license text.
 *
 *
 * The copyright notice above does not evidence any actual or intended publication of such source code.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
 */
package com.exalate.api.domain.twintrace;


import com.exalate.api.domain.IPersistentReplica;


import javax.annotation.Nonnull;
import javax.annotation.Nullable;


public interface ITwinTraceUpdateOnCreateEventParameters {
    public boolean isLocalReplicaSet();
    public boolean isNumberOfEventsSet();

    @Nullable
    public IPersistentReplica getLocalReplica();
    public long getNumberOfEvents();

    public interface Builder {
        @Nonnull
        public Builder setLocalReplica(@Nullable IPersistentReplica localReplica);
        @Nonnull
        public Builder setNumberOfEvents(long nEvents);

        @Nonnull
        public ITwinTraceUpdateOnCreateEventParameters build();
    }
}
