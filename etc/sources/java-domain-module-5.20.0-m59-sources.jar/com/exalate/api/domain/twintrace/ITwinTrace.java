/*
 * Copyright (C) 2015, Exalate NV
 * All rights reserved.
 *
 *
 * THIS SOURCE CODE IS AN UNPUBLISHED PROPRIETARY TRADE SECRET OF iDalko NV, unless stated otherwise
 * in the license text.
 *
 *
 * The copyright notice above does not evidence any actual or intended publication of such source code.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
 */

package com.exalate.api.domain.twintrace;


import com.exalate.api.domain.IPersistentReplica;
import com.exalate.api.domain.connection.IConnection;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Represents a connection between between two synchronized issues
 * It also shows the current state of synchronization between the issues
 *
 * A twin trace is created when an issue is started to be synchronized to a remote issue.
 * Thousands of synchronization acts (SyncEvents) may get created, processed and removed within lifecycle of one twin trace.
 * The twin trace is deleted when issues no longer need to be synchronized.
 * */

public interface ITwinTrace {

    public int getId();

    /**
     * @return The remote twin trace id this twin trace is paired with.
     */
    @Nullable
    public Integer getRemoteTwinTraceId();

    /**
     * @return The relation that produced this twin trace.
     */
    public IConnection getConnection();

    /**
     * Returns the latest local replica of this twin trace. The twin trace's type (in the database table) indicates
     * whether this is the parent or the child.
     *
     * Is needed to check if something has changed since the latest synchronization.
     *
     * @return IPersistentReplica
     */
    public IPersistentReplica getLocalReplica();

    /**
     * Returns the latest remote replica of this twin trace.
     *
     * Is needed to compare, what has changed since the last synchronization. Is used to identify the .addedComments, .changedComments, .removedComments
     *
     * @return IPersistentReplica
     */
    public IPersistentReplica getRemoteReplica();

    /**
     * @return Long the number of sync events that were generated for the local issue.
     */
    public Long getNumberOfEvents();

    public TwinTraceStatus getStatus();

    /**
     * @return The id of the last sync event for which a response was received
     */
    public int getLastReceivedResponse();

    /**
     * @return The sync event number of the last sync request that was processed
     */
    public Long getLastProcessedRemoteEventNumber();

    /**
     *
     * @param traceType eather of comment, attachment
     * @return List of ITraces for the given field type
     */
    @Nonnull
    public List<ITrace> getFieldTraces(TraceType traceType);

    /**
     *
     * @return List of all ITraces for the twin trace
     */
    @Nonnull
    public List<ITrace> getAllFieldTraces();

    /**
     * @return Map of trace types to traces
     * */
    @Nonnull
    public Map<TraceType, List<ITrace>> getFieldTraces();

    /**
     * Checks if the given local replica contains changes compared to the replica that was synced last.
     * @param newLocalReplica - the local replica to check
     * @return true if the local replica contains changes, false if it does not.
     */
    public boolean hasChanges(@Nonnull IPersistentReplica newLocalReplica);

    /**
     * @return a twintrace type (either PARENT or CHILD)
     */
    public TwinType getType();


    public boolean isUseRemoteScope();

    public Date getPayedDate();

}
