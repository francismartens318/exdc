package com.exalate.api.domain.trigger.pollcontext;

import javax.annotation.Nullable;

public interface IPollContext {
    public int getId();

    /**
     * time aka epoch millis
     * @return time when the last polling has started
     * */
    @Nullable
    public String getLastPollTime();

    /**
     * @return offset for paging in the pair events poll
     * */
    public long getPairPollOffset();

    /**
     * @return limit for paging in the pair events poll
     * */
    public int getPairPollLimit();

    /**
     * @return last total results received as the part of the response for paging in the pair events poll
     * */
    @Nullable
    public Long getPairPollTotalResults();

    /**
     * @return offset for paging in the update events poll
     * */
    public long getSyncPollOffset();

    /**
     * @return limit for paging in the update events poll
     * */
    public int getSyncPollLimit();

    /**
     * @return the last total results received as the part of the response for paging in the update events poll
     * */
    @Nullable
    public Long getSyncPollTotalResults();

    public int getRelationId();

    /**
     * @return Quantity of retriable (API problems) errors that has occurred since last successful poll for this poll context
     */
    public int getErrorsSinceLastSuccess();
}
