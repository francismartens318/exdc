package com.exalate.api.domain.trigger;


import com.exalate.api.domain.connection.IConnection;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.Map;


public interface INonPersistentTrigger {

    @Nonnull
    String getJqlFilter();
    void setJqlFilter(@Nonnull String jqlFilter);

    @Nonnull
    String getEntityType();
    void setEntityType(@Nonnull String entityType);

    @Nonnull
    IConnection getConnection();
    void setConnection(@Nonnull IConnection relation);

    @Nullable
    String getNotes();
    void setNotes(@Nullable String notes);

    @Nonnull
    TriggerStatus getStatus();
    void setStatus(@Nonnull TriggerStatus status);

    String getProjectWhiteList();
    void setProjectWhiteList(String projectWhiteList);

    public Map<String, Object> getFieldValues();
    public void setFieldValues(Map<String, Object> fieldValues);

}
