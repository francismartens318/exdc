package com.exalate.api.domain.trigger;

public enum TriggerStatus {

    ACTIVE, DEACTIVATED
}
