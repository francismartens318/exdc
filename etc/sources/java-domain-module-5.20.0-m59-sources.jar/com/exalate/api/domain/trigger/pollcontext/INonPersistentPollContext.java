package com.exalate.api.domain.trigger.pollcontext;

import javax.annotation.Nullable;

public interface INonPersistentPollContext {
    /**
     * time when the last polling has started
     * time aka epoch millis
     * @return time when the last polling has started
     * */
    @Nullable
    public Long getLastPollTime();

    /**
     * offset for paging in the pair events poll
     * @return offset for paging in the pair events poll
     * */
    public long getPairPollOffset();

    /**
     * limit for paging in the pair events poll
     * @return limit for paging in the pair events poll
     * */
    public int getPairPollLimit();

    /**
     * the last total results received as the part of the response for paging in the pair events poll
     * @return last total results received as the part of the response for paging in the pair events poll
     * */
    @Nullable
    public Long getPairPollTotalResults();

    public int getRelationId();
}
