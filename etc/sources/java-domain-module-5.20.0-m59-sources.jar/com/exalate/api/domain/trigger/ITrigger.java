package com.exalate.api.domain.trigger;


import com.exalate.api.domain.connection.IConnection;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.Map;


public interface ITrigger {

    int getId();

    @Nonnull
    String getJqlFilter();

    String getEntityType();

    @Nonnull
    IConnection getConnection();

    @Nullable
    String getNotes();

    @Nonnull
    TriggerStatus getStatus();

    String getProjectWhiteList();

    public Map<String, Object> getFieldValues();
}
