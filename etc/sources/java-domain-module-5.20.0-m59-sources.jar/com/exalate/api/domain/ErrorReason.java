package com.exalate.api.domain;

/**
 * Represents different reasons why a sync request may have failed and its readable description.
 */
public enum ErrorReason {

    NO_ISSUE_TO_CONNECT_TO("No issue found by given connect issue URN."),
    UNEXALATED("Issue has been unexalated."),
    ISSUE_DELETED("Issue has been deleted."),
    OUT_OF_BAND_REQUEST("Request was referring to a twin trace that is not present anymore"),
    SYNC_NOT_PAID("The synchronization has not been paid by neither of the instances."),
    NOT_SUPPORTED_SYNC_TYPE("The sync type is not supported"),
    NOT_SUPPORTED("The error reason is not supported yet");

    ErrorReason(String description) {
        this.description = description;
    }

    private String description;

    @Override
    public String toString() {
        return this.description;
    }
}
