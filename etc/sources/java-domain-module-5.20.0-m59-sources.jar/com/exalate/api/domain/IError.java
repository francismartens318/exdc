package com.exalate.api.domain;


import com.exalate.api.domain.blob.event.IBlobEvent;
import com.exalate.api.domain.blob.request.IBlobRequest;
import com.exalate.api.domain.event.ISyncEvent;
import com.exalate.api.domain.instance.IInstance;
import com.exalate.api.domain.connection.IConnection;
import com.exalate.api.domain.request.ISyncRequest;
import com.exalate.api.domain.trigger.ITrigger;

import javax.annotation.Nullable;
import java.util.Date;
import java.util.Map;


public interface IError {

    public int getId();
    
    public Date getCreationTime();

    public String getStackTrace();

    public String getRootCauseErrorTypeName();

    public String getRootCauseDetails();

    public ErrorEntityType getErrorEntityType();

    public ErrorActType getActType();

    public String getConnectRemoteIssueUrn();

    public IConnection getConnection();

    public IInstance getInstance();

    @Nullable
    public IIssueKey getIssueKey();


    @Nullable
    public ISyncEvent getSyncEvent();

    @Nullable
    public ISyncRequest getSyncRequest();

    @Nullable
    public IBlobEvent getBlobEvent();

    @Nullable
    public IBlobRequest getBlobRequest();

    /**
     * if an error record references a trigger, the error should be of TRIGGER level
     * The error would then be only reporting the problems with the automatic exalate,
     * but it would not be blocking any following trigger executions
     * */
    @Nullable
    public ITrigger getTrigger();

    /**
     * Returns json as string which represents an array of users which declined popup with error notification.
     */
    @Nullable
    public String getUsersDismissed();

    //Connect reschedule context

    @Nullable
    public IIssueKey getRemoteIssueKey();

    @Nullable
    public IPersistentConnectContext getConnectContext();

    public String getKey();

    public Map<String, String> getFieldValues();

}
