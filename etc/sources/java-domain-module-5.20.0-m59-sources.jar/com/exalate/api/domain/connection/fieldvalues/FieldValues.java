package com.exalate.api.domain.connection.fieldvalues;


public enum FieldValues {
    LOCAL_INSTANCE_NAME("localInstanceName"),
    REMOTE_INSTANCE_NAME("remoteInstanceName"),
    LOCAL_URL("localUrl"),
    WAS_PUBLISHED("wasPublished"), // allows to know from this side, if the other side can sync with this editor connection
    MODE("mode"), // governs whether the pre 5.X interfaces with two scripts is shown for a connection or the editor is shown
    MAIN_FIELD_INFO("main_field_info"), // only for basic connection, holds Project/Repo info
    UPGRADE_DATE("upgradeDate"), // time when connection was upgraded from BASIC to advanced
    REFRESH_TOKEN("refresh_token"),
    ACCESS_TOKEN("access_token");

    private String name;

    FieldValues(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return name;
    }
}
