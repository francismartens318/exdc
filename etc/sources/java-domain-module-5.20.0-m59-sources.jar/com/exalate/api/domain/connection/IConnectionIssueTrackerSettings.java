package com.exalate.api.domain.connection;

import java.util.Map;

public interface IConnectionIssueTrackerSettings {

    public Boolean getCreateLinks();

    public Boolean getCreateSyncPanelLinks();

    public String getIssueFilter();

    public int getID();

    public String getIssueTrackerType();

    public String getHpqcProject();

    public String getHpqcDomain();

    public String getIssueLinkFieldName();

    public Map<String, String> getFieldValues();
}
