package com.exalate.api.domain.connection;

import com.exalate.api.domain.instance.INonPersistentInstance;

import javax.annotation.Nullable;
import java.util.Map;

public interface INonPersistentConnection {
    public String getName();
    public void setName(String name);

    public String getDescription();
    public void setDescription(String description);

    public ConnectionStatus getStatus();
    public void setStatus(ConnectionStatus status);

    public InvitationStatus getInvitationStatus();
    public void setInvitationStatus(InvitationStatus status);

    public INonPersistentInstance getRemoteInstance();
    public void setRemoteInstance(INonPersistentInstance instance1);

    public String getDataFilter();
    public void setDataFilter(String filter);

    public String getCreateProcessor();
    public void setCreateProcessor(String createProcessor);

    public String getChangeProcessor();
    public void setChangeProcessor(String processor);

    public IConnectionIssueTrackerSettings getTrackerSettings();
    public void setTrackerSettings(IConnectionIssueTrackerSettings settings);

    public boolean isAuthenticationRequired();

    public SendProtocol getSendProtocol();
    public void setSendProtocol(SendProtocol sendProtocol);


    public ReceiveProtocol getReceiveProtocol();
    public void setReceiveProtocol(ReceiveProtocol receiveProtocol);

    @Nullable
    public String getRemoteUsername();
    @Nullable
    public String getRemotePassword();

    public boolean isLocal();
    public void setIsLocal(boolean isLocal);

    public String getLocalUrl();
    public void setLocalUrl(String localUrl);

    public String getInvitationSecret();
    public void setInvitationSecret(String invitationSecret);

    public String getPostExalateProcessor();
    public void setPostExalateProcessor(String postExalateProcessor);


    public String getVersion();
    public void setVersion(String version);

    public String getIncomingProcessor();
    public void setIncomingProcessor(String incomingProcessor);

    public Map<String, String> getFieldValues();
    public void setFieldValues(Map<String, String> fieldValues);

    public String getLocalInstanceName();
    public void setLocalInstanceName(String localInstanceName);

    public String getMode();
    public void setMode(String mode);

    public String getSyncMainFieldInfo();
    public void setSyncMainFieldInfo(String mainFieldInfo);

    public String getUpgradeDate();
    public void setUpgradeDate(String upgradeDate);
}
