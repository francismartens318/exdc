/*
 * Copyright (C) 2015, Exalate NV
 * All rights reserved.
 *
 *
 * THIS SOURCE CODE IS AN UNPUBLISHED PROPRIETARY TRADE SECRET OF iDalko NV, unless stated otherwise
 * in the license text.
 *
 *
 * The copyright notice above does not evidence any actual or intended publication of such source code.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
 */

package com.exalate.api.domain.connection;


import com.exalate.annotations.llm.LlmClass;
import com.exalate.annotations.llm.LlmMethod;
import com.exalate.api.domain.instance.IInstance;

import java.util.Map;

import static com.exalate.api.domain.node.ConnectorNames.*;

@LlmClass(
        connectors = {AZURE_DEVOPS, GITHUB, JCLOUD, SERVICE_NOW, SALESFORCE, ZENDESK},
        description = "An Instance is an issue tracker with the entities that you want to synchronize. " +
                "A Connection defines how entities are synced between instances. " +
                "Each Connection has the following components: " +
                "Connection type, information about the destination instance (remote side), sync rules (Outgoing sync and Incoming sync information). " +
                "This is an interface representing a connection in the issue tracker, providing methods to access and manage connection-specific information"
)
public interface IConnection {

    @LlmMethod(
            description = "Retrieves the unique identifier of the connection"
    )
    public int getID();

    @LlmMethod(
            description = "Retrieves the name of the connection"
    )
    public String getName();

    @LlmMethod(
            description = "Sets the name of the connection"
    )
    public void setName(String name);

    @LlmMethod(
            description = "Retrieves the mode of the connection"
    )
    public String getMode();

    @LlmMethod(
            description = "Sets the mode of the connection"
    )
    public void setMode(String mode);

    @LlmMethod(
            description = "Retrieves the description of the connection"
    )
    public String getDescription();

    @LlmMethod(
            description = "Sets the description of the connection"
    )
    public void setDescription(String description);

    @LlmMethod(
            description = "Retrieves the status of the connection"
    )
    public ConnectionStatus getStatus();

    @LlmMethod(
            description = "Sets the status of the connection"
    )
    public void setStatus(ConnectionStatus status);


    @LlmMethod(
            description = "Retrieves the invitation status of the connection"
    )
    public InvitationStatus getInvitationStatus();

    @LlmMethod(
            description = "Sets the invitation status of the connection"
    )
    public void setInvitationStatus(InvitationStatus invitationStatus);

    @LlmMethod(
            description = "Retrieves the remote instance associated with the connection"
    )
    public IInstance getRemoteInstance();

    @LlmMethod(
            description = "Sets the remote instance associated with the connection"
    )
    public void setRemoteInstance(IInstance remoteInstance);


    @LlmMethod(
            description = "Retrieves the data filter for the connection"
    )
    public String getDataFilter();

    @LlmMethod(
            description = "Sets the data filter for the connection"
    )
    public void setDataFilter(String filter);

    @LlmMethod(
            description = "Retrieves the create processor for the connection"
    )
    public String getCreateProcessor();

    @LlmMethod(
            description = "Sets the create processor for the connection"
    )
    public void setCreateProcessor(String createProcessor);

    @LlmMethod(
            description = "Retrieves the change processor for the connection"
    )
    public String getChangeProcessor();

    @LlmMethod(
            description = "Sets the change processor for the connection"
    )
    public void setChangeProcessor(String processor);

    @LlmMethod(
            description = "Retrieves the tracker settings for the connection"
    )
    public IConnectionIssueTrackerSettings getTrackerSettings();

    @LlmMethod(
            description = "Sets the tracker settings for the connection"
    )
    public void setTrackerSettings(IConnectionIssueTrackerSettings trackerSettings);

    @LlmMethod(
            description = "Checks if authentication is required for the connection"
    )
    public boolean isAuthenticationRequired();

    @LlmMethod(
            description = "Checks if the connection is local"
    )
    public boolean isLocal();

    @LlmMethod(
            description = "Sets the connection as local or not"
    )
    public void setIsLocal(boolean isLocal);

    @LlmMethod(
            description = "Retrieves the send protocol for the connection"
    )
    public SendProtocol getSendProtocol();

    @LlmMethod(
            description = "Retrieves the receive protocol for the connection"
    )
    public ReceiveProtocol getReceiveProtocol();

    @LlmMethod(
            description = "Retrieves the remote username for the connection"
    )
    public String getRemoteUsername();

    @LlmMethod(
            description = "Retrieves the remote password for the connection"
    )
    public String getRemotePassword();

    @LlmMethod(
            description = "Retrieves the local URL for the connection"
    )
    public String getLocalUrl();

    @LlmMethod(
            description = "Retrieves the invitation secret for the connection"
    )
    public String getInvitationSecret();

    @LlmMethod(
            description = "Retrieves the version of the connection"
    )
    public String getVersion();

    @LlmMethod(
            description = "Retrieves the incoming processor for the connection"
    )
    public String getIncomingProcessor();

    @LlmMethod(
            description = "Sets the incoming processor for the connection"
    )
    public void setIncomingProcessor(String processor);

    @LlmMethod(
            description = "Retrieves the post-exalate processor for the connection"
    )
    public String getPostExalateProcessor();

    @LlmMethod(
            description = "Sets the post-exalate processor for the connection"
    )
    public void setPostExalateProcessor(String postExalateProcessor);

    @LlmMethod(
            description = "Retrieves the field values for the connection"
    )
    public Map<String, String> getFieldValues();

    @LlmMethod(
            description = "Sets the field values for the connection"
    )
    public void setFieldValues(Map<String, String> fieldValues);

    @LlmMethod(
            description = "Retrieves the local instance name for the connection"
    )
    public String getLocalInstanceName();

    @LlmMethod(
            description = "Sets the local instance name for the connection"
    )
    public void setLocalInstanceName(String localInstanceName);

    @LlmMethod(
            description = "Checks if the connection is visual"
    )
    public boolean isVisual();

    @LlmMethod(
            description = "Checks if the connection is basic"
    )
    public boolean isBasic();

    @LlmMethod(
            description = "Retrieves the sync main field information for the connection"
    )
    public String getSyncMainFieldInfo();

    @LlmMethod(
            description = "Sets the sync main field information for the connection"
    )
    public void setSyncMainFieldInfo(String syncMainFieldInfo);

    @LlmMethod(
            description = "Retrieves the upgrade date for the connection"
    )
    public String getUpgradeDate();

    @LlmMethod(
            description = "Sets the upgrade date for the connection"
    )
    public void setUpgradeDate(String upgradeDate);

    /**
     * @return copy of connection with invitation secret being wiped out.
     */
    @LlmMethod(
            description = "Retrieves a copy of the connection with the invitation secret being wiped out"
    )
    IConnection withWipedInvitationSecret();

    @LlmMethod(
            description = "Checks if the connection is managed remotely"
    )
    public boolean isManagedRemotely();

    @LlmMethod(
            description = "Sets the connection as managed remotely or not"
    )
    public void setManagedRemotely(boolean managedRemotely);

    @LlmMethod(
            description = "Retrieves the manager of the connection"
    )
    public String getManagedBy();

    @LlmMethod(
            description = "Sets the manager of the connection"
    )
    public void setManagedBy(String managedBy);

    @LlmMethod(
            description = "Retrieves the sync room ID for the connection"
    )
    public String getSyncRoomId();

    @LlmMethod(
            description = "Sets the sync room ID for the connection"
    )
    public void setSyncRoomId(String syncRoomId);

}
