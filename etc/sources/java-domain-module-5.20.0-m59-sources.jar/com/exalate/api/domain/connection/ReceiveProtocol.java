package com.exalate.api.domain.connection;

public enum ReceiveProtocol {
    DIRECT_HTTP, POLL
}
