package com.exalate.api.domain.connection;

/**
 * for distinguishing a status of initiated connection on the remote side
 */
public enum InvitationStatus {
    PENDING, ACCEPTED, DECLINED, SEND_ACCEPTED
}
