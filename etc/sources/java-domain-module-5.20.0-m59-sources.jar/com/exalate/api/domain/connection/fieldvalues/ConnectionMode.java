package com.exalate.api.domain.connection.fieldvalues;

/**
 * For distinguishing type of the connection
 */
public enum ConnectionMode {
    CONFIGURE_BOTH_SIDES, // a connection, created and intended for Single admins - administrators of both of the two synced instances
    BASIC, // a connection that has basic default rule without possibility to change them, but this mode can be upgraded to CONFIGURE_BOTH_SIDES or SCRIPT
    SCRIPT
}
