package com.exalate.api.domain.connection;


public enum ConnectionStatus {
    ACTIVE, DEACTIVATED
}
