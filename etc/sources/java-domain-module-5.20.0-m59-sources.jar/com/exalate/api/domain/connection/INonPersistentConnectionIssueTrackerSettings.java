package com.exalate.api.domain.connection;


import java.util.Map;

public interface INonPersistentConnectionIssueTrackerSettings {

    public Boolean getCreateLinks();
    public void setCreateLinks(Boolean createLinks);

    public Boolean getCreateSyncPanelLink();
    public void setCreateSyncPanelLink(Boolean createSyncPanelLink);

    public String getIssueFilter();
    public void setIssueFilter(String issueFilter);

    public String getIssueTrackerType();
    public void setIssueTrackerType(String type);

    public void setHpqcDomain(String hpqcDomain);
    public String getHpqcDomain();

    public String getHpqcProject();
    public void setHpqcProject(String hpqcProject);

    public String getIssueLinkFieldName();
    public void setIssueLinkFieldName(String issueLinkFieldName);

    public Map<String, String> getFieldValues();
    public void setFieldValues(Map<String, String> fieldValues);
}
