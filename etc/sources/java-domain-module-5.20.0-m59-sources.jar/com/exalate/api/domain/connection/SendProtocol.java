package com.exalate.api.domain.connection;

public enum SendProtocol {
    DIRECT_HTTP, WAIT_FOR_POLL
}
