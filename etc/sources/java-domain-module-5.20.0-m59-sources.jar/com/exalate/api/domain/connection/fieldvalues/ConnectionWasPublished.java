package com.exalate.api.domain.connection.fieldvalues;

/**
 * for distinguishing whether the connection was published on the remote side
 */
public enum ConnectionWasPublished {
    TRUE(true),
    FALSE(false);

    private final boolean published;

    ConnectionWasPublished(boolean wasPublished) {
        this.published = wasPublished;
    }

    public boolean isPublished() {
        return published;
    }
}
