package com.exalate.api.domain.progresstracker;

public enum TaskType {
	SUPPORT_ZIP_GENERATION
}
