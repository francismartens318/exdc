package com.exalate.api.domain.progresstracker;

public enum ProgressTrackerStatus {
	IN_PROGRESS, DONE
}
