package com.exalate.api.domain.progresstracker;




public interface IProgressTracker {

    public int getId();
    public void setId(int id);

    public TaskType getTaskType();
    public void setTaskType(TaskType type);

    public ProgressTrackerStatus getStatus();
    public void setStatus(ProgressTrackerStatus status);

    public String getResult();
    public void setResult(String result);

    public String getErrors();
    public void setErrors(String errors);
}
