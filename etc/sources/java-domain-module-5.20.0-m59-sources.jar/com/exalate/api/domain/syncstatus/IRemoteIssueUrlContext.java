package com.exalate.api.domain.syncstatus;

public interface IRemoteIssueUrlContext {

    String getRemoteIssueUrl();

    String getTrimmedSummary();

    String getIssueUrn();

    String getIssueId();
}
