package com.exalate.api.domain.editor.scopes;

import scala.Option;

public enum TriggerCriteria {
    AUTOMATIC, MANUAL, API;

    public static Option<TriggerCriteria> fromString(String str) {
        for (TriggerCriteria v : values()) {
            if (v.name().equals(str)) {
                return Option.apply(v);
            }
        }
        return Option.<TriggerCriteria>empty();
    }
}
