package com.exalate.api.domain.editor.error;

import scala.Option;
public enum EditorErrorSide {
    LOCAL, REMOTE;

    public static Option<EditorErrorSide> fromString(String str) {
        for (EditorErrorSide v : values()) {
            if (v.name().equals(str)) {
                return Option.apply(v);
            }
        }
        return Option.<EditorErrorSide>empty();
    }
}
