package com.exalate.api.domain.editor.mappings;

import scala.Option;

public enum MappingType {
    MAPPING,
    SCRIPT;

    public static Option<MappingType> fromString(String str) {
        for (MappingType mappingType : values()) {
            if (mappingType.name().equals(str)) {
                return Option.apply(mappingType);
            }
        }
        return Option.<MappingType>empty();
    }
}
