package com.exalate.api.domain.editor.error;

import scala.Option;

/**
 * help class to know where mapping we should locate error (where error belongs to)
 * */
public enum ErrorLocationType {
    SCOPE_MAIN_FIELD,
    SCOPE_QUERY,
    MAPPING_MAPS,
    OVERALL_MAPPING,
    MAPPING_BUTTON,
    RECOVERY_DEFAULT_VALUE,
    SCRIPT;

    public static Option<ErrorLocationType> fromString(String str) {
        for (ErrorLocationType v : values()) {
            if (v.name().equals(str)) {
                return Option.apply(v);
            }
        }
        return Option.<ErrorLocationType>empty();
    }
}
