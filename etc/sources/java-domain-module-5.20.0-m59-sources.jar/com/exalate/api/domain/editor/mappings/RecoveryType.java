package com.exalate.api.domain.editor.mappings;

import scala.Option;

public enum RecoveryType {
    DEFAULT, NONE, ERROR;

    public static Option<RecoveryType> fromString(String str) {
        for (RecoveryType v : values()) {
            if (v.name().equals(str)) {
                return Option.apply(v);
            }
        }
        return Option.<RecoveryType>empty();
    }
}
