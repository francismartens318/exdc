package com.exalate.api.domain.editor.scopes;

import scala.Option;

public enum SyncCriteria {
    QUERY, ALL, NONE;

    public static Option<SyncCriteria> fromString(String str) {
        for (SyncCriteria v : values()) {
            if (v.name().equals(str)) {
                return Option.apply(v);
            }
        }
        return Option.<SyncCriteria>empty();
    }
}
