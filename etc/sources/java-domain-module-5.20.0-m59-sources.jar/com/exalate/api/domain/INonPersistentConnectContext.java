package com.exalate.api.domain;





public interface INonPersistentConnectContext {

    public boolean isSynchronizeComments();

    public boolean isSynchronizeAttachments();

    public boolean isSynchronizeWorklogs();

    public boolean isTriggerSyncEvent();

    public boolean isTriggerUpdate();

    public boolean isTriggerUnexalate();
}
