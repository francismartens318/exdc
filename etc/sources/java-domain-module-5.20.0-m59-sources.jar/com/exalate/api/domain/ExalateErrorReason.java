package com.exalate.api.domain;

/**
 * Represents different Exalate configuration reasons why a sync may have failed and its readable description.
 */

public enum ExalateErrorReason {

    CONNECTION_NOT_FOUND("Connection was not found"),

    COULD_NOT_STORE_BLOB("It was not possible to store blob"),

    BUG("Unexpected error");

    ExalateErrorReason(String description) {
        this.description = description;
    }

    private String description;

    @Override
    public String toString() {
        return this.description;
    }
}
