package com.exalate.api.domain.exalateadmin;

import com.exalate.api.domain.ErrorEntityType;

public interface INonPersistentExalateAdmin {

    public ErrorEntityType getMinimumErrorLevel();
    public void setMinimumErrorLevel(ErrorEntityType minimumErrorLevel);

    public String getEmailAddress();
    public void setEmailAddress(String emailAddress);

    public String getName();
    public void setName(String name);
}
