package com.exalate.api.domain.exalateadmin;


import com.exalate.api.domain.ErrorEntityType;

public interface IPersistentExalateAdmin {


    public ErrorEntityType getMinimumErrorLevel();

    public String getEmailAddress();

    public String getName();

    public int getId();
}
