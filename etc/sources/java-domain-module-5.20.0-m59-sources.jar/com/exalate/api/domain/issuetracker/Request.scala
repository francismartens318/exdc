package com.exalate.api.domain.issuetracker

import scala.collection.JavaConverters

case class Request(
    method: String = "GET",
    path: String = "/",
    body: Option[String] = None,
    queryParams: Option[Map[String, Seq[String]]] = None,
    headers: Option[Map[String, Seq[String]]] = None
) {
  def getMethod(): String = method
  def getPath(): String = path
  def getBody(): String = body.orNull
  def getQueryParams(): java.util.Map[String, java.util.List[String]] = toJava(queryParams)
  def getHeaders(): java.util.Map[String, java.util.List[String]] = toJava(headers)

  def toJava(
      mapOpt: Option[Map[String, Seq[String]]]
  ): java.util.Map[String, java.util.List[String]] = mapOpt
    .map(map => JavaConverters.mapAsJavaMap(map.mapValues(JavaConverters.seqAsJavaList).toMap))
    .orNull

}
