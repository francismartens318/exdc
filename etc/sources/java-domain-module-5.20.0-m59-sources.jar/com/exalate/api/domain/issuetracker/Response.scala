package com.exalate.api.domain.issuetracker

import com.exalate.annotations.llm.{LlmClass, LlmMethod}
import com.exalate.api.domain.node.ConnectorNames.{
  AZURE_DEVOPS,
  GITHUB,
  JCLOUD,
  SALESFORCE,
  SERVICE_NOW,
  ZENDESK
}

import scala.collection.JavaConverters

@LlmClass(
  connectors = Array[String](AZURE_DEVOPS, GITHUB, JCLOUD, SERVICE_NOW, SALESFORCE, ZENDESK),
  description =
    "A Scala case class representing an HTTP response from an issue tracker, providing methods to access response-specific information."
)
case class Response(
    code: Int,
    bodyStrOpt: Option[String],
    bodyFn: Option[String] => Object,
    headerOpt: Option[Map[String, Seq[String]]]
) {

  @LlmMethod(
    description = "Retrieves the HTTP status code of the response."
  )
  def getCode(): Int = code

  @LlmMethod(
    description = "Retrieves the body of the response as a string."
  )
  def getBodyString(): String = bodyStrOpt.orNull

  @LlmMethod(
    description = "Retrieves the body of the response as an Object."
  )
  def getBody(): Object = bodyFn(bodyStrOpt)

  @LlmMethod(
    description = "Retrieves the headers of the response as a Java map."
  )
  def getHeaders(): java.util.Map[String, java.util.List[String]] = headerOpt
    .map(headers =>
      JavaConverters.mapAsJavaMap(headers.mapValues(JavaConverters.seqAsJavaList).toMap)
    )
    .orNull

}
