/*
 * Copyright (C) 2015, Exalate NV
 * All rights reserved.
 *
 *
 * THIS SOURCE CODE IS AN UNPUBLISHED PROPRIETARY TRADE SECRET OF iDalko NV, unless stated otherwise
 * in the license text.
 *
 *
 * The copyright notice above does not evidence any actual or intended publication of such source code.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
 */

package com.exalate.api.domain.event;


import com.exalate.api.domain.*;
import com.exalate.api.domain.connection.IConnection;
import com.exalate.api.domain.twintrace.ITrace;


import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.List;

/**
 * Represents one act of synchronization for one issue.
 * It symbolizes that something has happened to a local issue.
 * The sync event contains the replica, representing the latest state of the issue.
 *
 * A sync event is created whenever something has happened to a local issue,
 * which needs to be synchronized to the remote side
 * The sync event is deleted when the act of synchronization has finished.
 * */

public interface ISyncEvent {

    /**
     * @return The unique identifier of this event.
     */
    public int getId();


    /**
     * @return The twin trace id attached to the remote issue this event will be paired with.
     * Null in the case this is a pair/connect event and current state is before RESPONSE_READY state
     * After RESPONSE_READY state, it should be non null for all the event types if we are talking with a &gt; 1.0.0 node.
     */
    @Nullable
    public Integer getRemoteTwinTraceId();

    public void setRemoteTwinTraceId(@Nullable Integer remoteTwinTraceId);

    /**
     * All sync events for an issue get a sequence number so they can be processed in
     * chronological order. The event number is 1-based.
     *
     * @return Long sequence number
     */
    @Nonnull
    public Long getEventNumber();

    public void setEventNumber(Long eventNumber);

    /**
     * @return The relation that specifies how and where the issue should be synced to.
     */
    @Nonnull
    public IConnection getConnection();

    /**
     * @return The local replica of the issue to sync.
     */
    @Nonnull
    public IPersistentReplica getLocalReplica();

    public void setLocalReplica(IPersistentReplica localReplica);

    @Nullable
    public String getConnectRemoteIssueUrn();
    public IPersistentConnectContext getConnectContext();

    @Nullable
    public String getDeletedIssueUrn();

    @Nullable
    public String getUnexalateIssueUrn();

    /**
     * @return The remote replica of the synced issue.
     */
    @Nullable
    public IPersistentReplica getRemoteReplica();

    /**
     * @param remoteReplica The remote replica of the synced issue.
     */
    public void setRemoteReplica(@Nullable IPersistentReplica remoteReplica);

    /**
     * @return The status indicating whether this event still needs to be processed or not.
     */
    @Nonnull
    public EventStatus getStatus();

    public void setStatus(@Nonnull EventStatus status);

    public boolean canBeProcessed();

    /**
     * returns a list of blobs (blob meta info) to be sent in a sync request
     * */
    @Nonnull
    public List<IBlobMetadata> getBlobMetadataList();

    @Nonnull
    public List<ITrace> getTraces();

    public boolean isPayed();

    public void setPayed(boolean payed);
    /**
     * user that will be used to perform interactions with the issue tracker during the event processing
     * */
    public String getProxyUser();
    public void setProxyUser(String proxyUser);

    /**
     * state if this request is currently updating an issue
     * */
    public boolean isChangingIssue();
    public void setChangingIssue(boolean changingIssue);


    /**
     * @return ErrorReason that has been received on an error response.
     */
    @Nullable
    public ErrorReason getErrorReason();
    public void setErrorReason(ErrorReason errorReason);

    @Nullable
    public String getErrorResponseMessage();
    public void setErrorResponseMessage(String ErrorResponseMessage);

    /**
     * one of SyncRequestEventType, represents type of sync event
     */
    public SyncRequestEventType getSyncType();
    public void setSyncType(SyncRequestEventType type);

    public Integer getTwinTraceId();

    public void setTwinTraceId(Integer twinTraceId);

    String getOriginator();
    void setOriginator(String username);

    Integer getPriority();
    void setPriority(Integer priority);

    boolean canProcessSyncResponse();

}
