package com.exalate.api.domain.blob;

/**
 * Represents different reasons why a sync request may have failed and its readable description.
 */
public enum BlobErrorReason {

    CHECKSUM_MISMATCH("Checksums for blob don't match."),
    MISSING_BLOB("Impossible to retrieve a blob from the receiving side."), //stays here for compatibility reasons,
    NOT_SUPPORTED("The blob error reason is not supported yet");

    BlobErrorReason(String description) {
        this.description = description;
    }

    private String description;

    @Override
    public String toString() {
        return this.description;
    }
}