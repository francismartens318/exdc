/*
 * Copyright (C) 2015, Exalate NV
 * All rights reserved.
 *
 *
 * THIS SOURCE CODE IS AN UNPUBLISHED PROPRIETARY TRADE SECRET OF iDalko NV, unless stated otherwise
 * in the license text.
 *
 *
 * The copyright notice above does not evidence any actual or intended publication of such source code.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
 */
package com.exalate.api.domain.blob.request;


import com.exalate.api.domain.IBlobMetadata;
import com.exalate.api.domain.request.ISyncRequest;
import com.exalate.api.domain.blob.BlobErrorReason;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;


public interface IBlobRequest {
    public int getId();

    @Nonnull
    public BlobRequestStatus getStatus();

    public void setStatus(@Nonnull BlobRequestStatus status);

    @Nonnull
    public ISyncRequest getSyncRequest();

    @Nullable
    public Integer getRemoteBlobEventId();

    @Nonnull
    public IBlobMetadata getBlobMetadata();

    @Nullable
    public String getErrorResponseMessage();

    public void setErrorResponseMessage(String errorResponseMessage);

    /**
     * @return BlobErrorReason that has been set during a state transition.
     */
    public BlobErrorReason getBlobErrorReason();

    public void setBlobErrorReason(BlobErrorReason blobErrorReason);

    /**
     * @return true, if the blob request has not been assigned with any error response
     */
    public boolean isFinishedCorrectly();
}
