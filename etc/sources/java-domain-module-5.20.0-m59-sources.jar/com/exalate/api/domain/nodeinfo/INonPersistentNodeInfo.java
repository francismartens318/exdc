/*
 * Copyright (C) 2015, Exalate NV
 * All rights reserved.
 *
 *
 * THIS SOURCE CODE IS AN UNPUBLISHED PROPRIETARY TRADE SECRET OF iDalko NV, unless stated otherwise
 * in the license text.
 *
 *
 * The copyright notice above does not evidence any actual or intended publication of such source code.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
 */

package com.exalate.api.domain.nodeinfo;


import com.exalate.api.domain.hubobject.ISemanticVersion;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;


public interface INonPersistentNodeInfo {
    public String getName();

    public String getExalateUrl();

    public String getIssueTrackerUrl();

    public String getNodeType();

    public String getIssueTrackerVersion();

    public String getNodeVersion();

    public String getMinHubObjectsVersion();

    public String getMaxHubObjectsVersion();

    public String getMinRestVersion();

    public String getMaxRestVersion();

    public boolean isPollOnly();

    public String getExaCompVersion();

    public String getInstanceUid();

    public String getEditorValue();

    public String getIconUrl();

    public boolean isNameSet();

    public boolean isExalateUrlSet();

    public boolean isIssueTrackerUrlSet();

    public boolean isNodeTypeSet();

    public boolean isIssueTrackerVersionSet();

    public boolean isNodeVersionSet();

    public boolean isMinHubObjectsVersionSet();

    public boolean isMaxHubObjectsVersionSet();

    public boolean isMinRestVersionSet();

    public boolean isMaxRestVersionSet();

    public boolean isPollOnlySet();

    public boolean isExaCompVersionSet();

    public boolean isInstanceUidSet();

    public boolean isEditorValueSet();

    public boolean isIconUrlSet();

    public boolean isBasicConnectionValueSet();

    public String getBasicConnectionValue();

    public interface Builder {
        public INonPersistentNodeInfo build();

        @Nonnull
        public Builder from(@Nonnull INodeInfo nodeInfo);

        @Nonnull
        public Builder setName(@Nonnull String name);

        @Nonnull
        public Builder setExalateUrl(@Nonnull String exalateUrl);

        @Nonnull
        public Builder setIssueTrackerUrl(@Nonnull String issueTrackerUrl);

        @Nonnull
        public Builder setNodeType(@Nonnull String nodeType);

        @Nonnull
        public Builder setIssueTrackerVersion(@Nonnull ISemanticVersion issueTrackerVersion);

        @Nonnull
        public Builder setNodeVersion(@Nonnull ISemanticVersion nodeAppVersion);

        @Nonnull
        public Builder setMinHubObjectsVersion(@Nonnull ISemanticVersion hubObjectsVersion);

        @Nonnull
        public Builder setMaxHubObjectsVersion(@Nonnull ISemanticVersion hubObjectsVersion);

        @Nonnull
        public Builder setMinRestVersion(@Nonnull ISemanticVersion transportProtocolVersion);

        @Nonnull
        public Builder setMaxRestVersion(@Nonnull ISemanticVersion transportProtocolVersion);

        @Nonnull
        public Builder setPollOnly(@Nonnull boolean pollOnly);

        @Nonnull
        public Builder setExaCompVersion(@Nonnull String exaCompVersion);

        @Nonnull
        public Builder setInstanceUid(@Nonnull String instanceUid);

        @Nonnull
        public Builder setEditorValue(@Nonnull String editorValue);

        @Nonnull
        public Builder setIconUrl(@Nonnull String iconUrl);

        @Nonnull
        public Builder setBasicConnectionValue(String basicConnectionValue);
    }
}
