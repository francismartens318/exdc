package com.exalate.api.domain;

import com.exalate.api.domain.connection.IConnection;

import javax.annotation.Nonnull;

public interface IRelationRemoteTwinTraceId {

    /**
     * The issue key as a unique identifier of the issue on a node.
     * @return the issue unique identifier
     */
    @Nonnull
    public int getRemoteTwinTraceId();

    /**
     * The relation used to sync this issue with a remote one.
     * @return the relation
     */
    @Nonnull
    public IConnection getConnection();
}
