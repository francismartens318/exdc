package com.exalate.api.domain.oauth;

public enum AccessTokenStatus {
    PROVEN, NOT_PROVEN
}
