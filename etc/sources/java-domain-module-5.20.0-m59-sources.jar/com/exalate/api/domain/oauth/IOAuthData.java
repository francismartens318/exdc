package com.exalate.api.domain.oauth;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

public interface IOAuthData {

    public int getID();

    @Nonnull
    public String getUserKey();

    @Nonnull
    public String getAccessToken();

    @Nonnull
    public Long getExpiration();

    public String getSecret();

    public String getIssuer();

    public String getCode();

    public String getTokenType();
}
