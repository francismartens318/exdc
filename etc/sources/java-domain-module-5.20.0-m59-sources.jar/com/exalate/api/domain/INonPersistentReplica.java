/*
 * Copyright (C) 2015, Exalate NV
 * All rights reserved.
 *
 *
 * THIS SOURCE CODE IS AN UNPUBLISHED PROPRIETARY TRADE SECRET OF iDalko NV, unless stated otherwise
 * in the license text.
 *
 *
 * The copyright notice above does not evidence any actual or intended publication of such source code.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
 */
package com.exalate.api.domain;

import com.exalate.api.domain.hubobject.IHubPayload;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

public interface INonPersistentReplica {

    /**
     * This issue replica is valid on a certain date.
     * There might be other issue replicas that have superseded this one.
     *
     * @return ITimestamp
     */
    @Nonnull
    public ITimestamp getValidOn();

    /**
     * @return IIssueKey of the issue that the replica was created of.
     */
    @Nonnull
    public IIssueKey getIssueKey();

    /**
     * Every issue has a summary.
     *
     * @return ISummary
     */
    @Nullable
    public ISummary getSummary();

    /**
     * Each replica contains a payload. i.e. the data that is transferred between to issue trackers.
     *
     * @return IHubPayload
     */
    @Nonnull
    public IHubPayload getPayload();

    @Nonnull
    public String getPayloadAsString();

}
