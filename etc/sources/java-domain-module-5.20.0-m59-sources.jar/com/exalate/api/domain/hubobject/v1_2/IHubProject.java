/*
 * Copyright (C) 2015, iDalko NV
 * All rights reserved.
 *
 *
 * THIS SOURCE CODE IS AN UNPUBLISHED PROPRIETARY TRADE SECRET OF iDalko NV, unless stated otherwise
 * in the license text.
 *
 *
 * The copyright notice above does not evidence any actual or intended publication of such source code.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
 */
package com.exalate.api.domain.hubobject.v1_2;


import com.exalate.annotations.llm.LlmClass;
import com.exalate.annotations.llm.LlmMethod;
import com.exalate.api.domain.hubobject.ILockable;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.List;
import java.util.Set;

import static com.exalate.api.domain.node.ConnectorNames.*;


@LlmClass(
        connectors = {AZURE_DEVOPS, GITHUB, JCLOUD, SERVICE_NOW, SALESFORCE, ZENDESK},
        description =
                "An interface that represents a project in the issue tracker, encapsulating details such as project ID, key, name, lead, versions, and components."
)
public interface IHubProject extends ILockable {
    /**
     * @return the id of the project not null if set on the hub project
     */
    @Nullable
    @LlmMethod(
            description = "Retrieves the unique identifier of the project as a Long"
    )
    public Long getId();

    @Nullable
    @LlmMethod(
            description = "Retrieves the unique identifier of the project as a String"
    )
    public String getIdStr();

    /**
     * @return the Key of the project not null WHEN set on the hub project
     */
    @Nullable
    @LlmMethod(
            description = "Retrieves the unique key of the project"
    )
    public String getKey();

    /**
     * @return the Name of the project not null if set on the hub project
     */
    @Nullable
    @LlmMethod(
            description = "Retrieves the name of the project"
    )
    public String getName();

    /**
     * @return the Lead of the project, null - if not set on the node project, or if NOT YET set on the hub project
     */
    @Nullable
    @LlmMethod(
            description = "Retrieves the lead of the project"
    )
    public IHubUser getLead();

    @Nonnull
    @LlmMethod(
            description = "Retrieves a set of versions associated with the project",
            returnType = "Set<IHubVersion>"
    )
    public Set<IHubVersion> getVersions();

    @Nonnull
    @LlmMethod(
            description = "Retrieves a list of components associated with the project",
            returnType = "List<IHubComponent>"
    )
    public List<IHubComponent> getComponents();
}
