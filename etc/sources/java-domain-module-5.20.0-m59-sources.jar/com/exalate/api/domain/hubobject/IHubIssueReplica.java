/*
 * Copyright (C) 2015, Exalate NV
 * All rights reserved.
 *
 *
 * THIS SOURCE CODE IS AN UNPUBLISHED PROPRIETARY TRADE SECRET OF iDalko NV, unless stated otherwise
 * in the license text.
 *
 *
 * The copyright notice above does not evidence any actual or intended publication of such source code.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
 */
package com.exalate.api.domain.hubobject;

import com.exalate.annotations.llm.LlmClass;
import com.exalate.annotations.llm.LlmMethod;
import com.exalate.api.domain.IIssueKey;
import com.exalate.basic.domain.hubobject.v1.BasicHubAttachment;
import com.exalate.basic.domain.hubobject.v1.BasicHubComment;
import com.exalate.basic.domain.hubobject.v1.BasicHubWorkLog;

import javax.annotation.Nonnull;
import java.util.List;

import static com.exalate.api.domain.node.ConnectorNames.*;

/**
 * a marking interface
 * */
@LlmClass(
        connectors = {AZURE_DEVOPS, GITHUB, JCLOUD, SERVICE_NOW, SALESFORCE, ZENDESK},
        description = "An interface representing a replica of an entity, providing methods to access and manage replica-specific information. " +
                "A replica is a copy of the information that is getting transferred to the destination side."
)
public interface IHubIssueReplica {
    @LlmMethod(
            description = "Retrieves the name of the entity in the replica"
    )
    public String getEntityName();

    @LlmMethod(
            description = "Retrieves the unique identifier of the entity in the replica"
    )
    public String getId();

    @LlmMethod(
            description = "Retrieves the key of the entity in the replica"
    )
    public IIssueKey getEntityKey();

    @LlmMethod(
            description = "Retrieves the URL of the entity in the replica"
    )
    public String getEntityUrl();

    //TODO remove?
    @Nonnull
    @LlmMethod(
            description = "Retrieves the list of comments",
            returnType = "List<BasicHubComment>"
    )
    public List<BasicHubComment> getComments();

    @Nonnull
    @LlmMethod(
            description = "Retrieves the list of added comments",
            returnType = "List<BasicHubComment>"
    )
    public List<BasicHubComment> getAddedComments();


    @Nonnull
    @LlmMethod(
            description = "Retrieves the list of changed comments",
            returnType = "List<BasicHubComment>"
    )
    public List<BasicHubComment> getChangedComments();


    @Nonnull
    @LlmMethod(
            description = "Retrieves the list of removed comments in the replica",
            returnType = "List<BasicHubComment>"
    )
    public List<BasicHubComment> getRemovedComments();


    @Nonnull
    @LlmMethod(
            description = "Retrieves the list of added attachments",
            returnType = "List<BasicHubComment>"
    )
    public List<BasicHubAttachment> getAddedAttachments();


    @Nonnull
    @LlmMethod(
            description = "Retrieves the list of removed attachments",
            returnType = "List<BasicHubComment>"
    )
    public List<BasicHubAttachment> getRemovedAttachments();

    @LlmMethod(
            description = "Sets the list of removed comments"
    )
    public void setRemovedComments(@Nonnull List<BasicHubComment> removedComments);

    @LlmMethod(
            description = "Sets the list of changed comments in the replica"
    )
    public void setChangedComments(@Nonnull List<BasicHubComment> changedComments);

    @LlmMethod(
            description = "Sets the list of added comments in the replica"
    )
    public void setAddedComments(@Nonnull List<BasicHubComment> addedComments);

    @Nonnull
    @LlmMethod(
            description = "Retrieves the list of attachments associated with the replica",
            returnType = "List<BasicHubAttachment>"
    )
    public List<BasicHubAttachment> getAttachments();

    @LlmMethod(
            description = "Sets the list of added attachments"
    )
    public void setAddedAttachments(@Nonnull List<BasicHubAttachment> addedAttachments);

    @LlmMethod(
            description = "Sets the list of removed attachments in the replica"
    )
    public void setRemovedAttachments(@Nonnull List<BasicHubAttachment> removedAttachments);

    @Nonnull
    @LlmMethod(
            description = "Retrieves the list of work logs associated with the replica"
    )
    public List<BasicHubWorkLog> getWorkLogs();

    @LlmMethod(
            description = "Sets the list of removed work logs in the replica"
    )
    public void setRemovedWorkLogs(List<BasicHubWorkLog> removedWorkLogs);

    @LlmMethod(
            description = "Sets the list of changed work logs in the replica"
    )
    public void setChangedWorkLogs(List<BasicHubWorkLog> changedWorkLogs);

    @LlmMethod(
            description = "Sets the list of added work logs in the replica"
    )
    public void setAddedWorkLogs(List<BasicHubWorkLog> addedWorkLogs);

    @LlmMethod(
            description = "Retrieves the event trigger context associated with the replica"
    )
    EventTriggerContext getEventTriggerContext();

    @LlmMethod(
            description = "Sets the event trigger context for the replica"
    )
    void setEventTriggerContext(EventTriggerContext context);
    // END: remove
}
