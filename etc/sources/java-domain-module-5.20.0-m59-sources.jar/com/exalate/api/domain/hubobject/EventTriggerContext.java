package com.exalate.api.domain.hubobject;

import com.exalate.api.domain.request.ISyncRequest;



/**
 * <p>This class is used to deliver the context of how sync event was originated.
 * Used by priority assignment algorithm.</p>
 * <p>Can be passed either directly to event scheduling related methods, or via {@link IHubIssueReplica}
 * (when not possible to add new arguments to methods called by Groovy scripts)</p>
 */
public class EventTriggerContext {
	public final String user;
	public final ISyncRequest request;

	private EventTriggerContext(String user, ISyncRequest request) {
		this.user = user;
		this.request = request;
	}

	public static EventTriggerContext empty() {
		return new EventTriggerContext(null, null);
	}

	public static EventTriggerContext byUser(String user) {
		return new EventTriggerContext(user, null);
	}

	public static EventTriggerContext byRequest(ISyncRequest request) {
		return new EventTriggerContext(null, request);
	}

	public static EventTriggerContext merge(EventTriggerContext... contexts) {
		String user = null;
		ISyncRequest request = null;
		for(EventTriggerContext context: contexts) {
			if(context == null) continue;
			if(context.user != null) user = context.user;
			if(context.request != null) request = context.request;
		}
		return new EventTriggerContext(user, request);
	}

}
