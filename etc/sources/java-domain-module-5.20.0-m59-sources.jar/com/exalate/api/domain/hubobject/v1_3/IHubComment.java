/*
 * Copyright (C) 2015, iDalko NV
 * All rights reserved.
 *
 *
 * THIS SOURCE CODE IS AN UNPUBLISHED PROPRIETARY TRADE SECRET OF iDalko NV, unless stated otherwise
 * in the license text.
 *
 *
 * The copyright notice above does not evidence any actual or intended publication of such source code.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
 */
package com.exalate.api.domain.hubobject.v1_3;


import com.exalate.api.domain.hubobject.v1_2.IHubUser;
import com.exalate.api.domain.hubobject.ILockable;

import javax.annotation.Nullable;
import java.io.Serializable;
import java.util.Date;

/**
 * An entity to track an issue comment info at
 */

public interface IHubComment extends Serializable, ILockable {

    public String getIdStr();

    public String getRemoteIdStr();

    /**
     * @return the Author of the comment not null if set on the hub comment
     */
    @Nullable
    public IHubUser getAuthor();

    /**
     * @return the Update Author of the comment, null - if not set on the node comment, or if NOT YET set on the hub comment
     */
    @Nullable
    public IHubUser getUpdateAuthor();

    /**
     * @return the Body of the comment not null UNTIL set on the hub comment
     */
    @Nullable
    public String getBody();

    /**
     * @return the Created date of the comment not null if set on the hub comment
     */
    @Nullable
    public Date getCreated();

    /**
     * @return the Updated date of the comment, null - if not set on the node comment, or if NOT YET set on the hub comment
     */
    @Nullable
    public Date getUpdated();

    /**
     * @return the Group Level of the comment, null - if not set on the node comment, or if NOT YET set on the hub comment
     */
    @Nullable
    public String getGroupLevel();

    /**
     * @return the Role Level of the comment, null - if not set on the node issue, or if NOT YET set on the hub comment
     */
    @Nullable
    public String getRoleLevel();

    @Nullable
    public Long getRemoteId();

}
