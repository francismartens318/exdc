package com.exalate.api.domain.hubobject.v1_13;

public interface IHubVpOrigin extends com.exalate.api.domain.hubobject.v1_5.IHubVpOrigin {

    String getRequestTypeId();

    String getRequestTypeName();

    String getServiceDeskId();

    String getServiceDeskProjectName();

    String getServiceDeskProjectKey();

}
