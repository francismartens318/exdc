package com.exalate.api.domain.hubobject;

public interface IHubWorkflowHelper {
}
