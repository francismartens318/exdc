package com.exalate.api.domain.hubobject.v1_15;



public interface IHubChangeItem {
    public String getField();
    public String getFieldType();
    public String getFrom();
    public String getFromValue();
    public String getTo();
    public String getToValue();
}
