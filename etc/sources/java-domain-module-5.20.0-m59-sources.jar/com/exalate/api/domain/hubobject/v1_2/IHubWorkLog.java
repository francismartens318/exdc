/*
 * Copyright (C) 2015, Exalate NV
 * All rights reserved.
 *
 *
 * THIS SOURCE CODE IS AN UNPUBLISHED PROPRIETARY TRADE SECRET OF iDalko NV, unless stated otherwise
 * in the license text.
 *
 *
 * The copyright notice above does not evidence any actual or intended publication of such source code.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
 */
package com.exalate.api.domain.hubobject.v1_2;


import com.exalate.annotations.llm.LlmClass;
import com.exalate.annotations.llm.LlmMethod;
import com.exalate.api.domain.hubobject.ILockable;

import javax.annotation.Nullable;
import java.io.Serializable;
import java.util.Date;

import static com.exalate.api.domain.node.ConnectorNames.*;


@LlmClass(
        connectors = {AZURE_DEVOPS, GITHUB, JCLOUD, SERVICE_NOW, SALESFORCE, ZENDESK},
        description = "An interface representing a work log in the issue tracker, providing methods to access work log-specific information"
)
public interface IHubWorkLog extends Serializable, ILockable {

    /**
     * @return the id of the work log not null if set on the hub work log
     * */
    @Nullable
    @LlmMethod(
            description = "Retrieves the unique string identifier of the work log"
    )
    public String getIdStr();
    /**
     * Can be used to determine whether a worklog has come from local or destination instance.
     *
     * @return an id of the worklog on the remote side.
     */
    @Nullable
    @LlmMethod(
            description = "Retrieves the string ID of the work log on the remote side"
    )
    public String getRemoteIdStr();

    /**
     * @return Worklog author's object or null if is not existing
     */
    @Nullable
    @LlmMethod(
            description = "Retrieves the author of the work log"
    )
    public IHubUser getAuthor();

    /**
     * @return Worklog author update's object or null if is not existing
     * null - if not set on the node work log, or if NOT YET set on the hub work log
     */
    @Nullable
    @LlmMethod(
            description = "Retrieves the update author of the work log"
    )
    public IHubUser getUpdateAuthor();

    /**
     * @return the Start Date of the work log not null WHEN set on the hub work log
     * */
    @Nullable
    @LlmMethod(
            description = "Retrieves the start date of the work log"
    )
    public Date getStartDate();

    /**
     * @return the Time Spent of the work log not null WHEN set on the hub work log
     * */
    @Nullable
    @LlmMethod(
            description = "Retrieves the time spent on the work log"
    )
    public Long getTimeSpent();

    /**
     * @return the Group Level of the work log, null - if not set on the node work log, or if NOT YET set on the hub work log
     * */
    @Nullable
    @LlmMethod(
            description = "Retrieves the group level of the work log"
    )
    public String getGroupLevel();

    /**
     * @return the Role Level of the work log, null - if not set on the node work log, or if NOT YET set on the hub work log
     * */
    @Nullable
    @LlmMethod(
            description = "Retrieves the role level of the work log"
    )
    public String getRoleLevel();

    /**
     * @return the Comment of the work log, null - if not set on the node work log, or if NOT YET set on the hub work log
     * */
    @Nullable
    @LlmMethod(
            description = "Retrieves the comment associated with the work log"
    )
    public String getComment();

    /**
     * @return the Created date of the work log not null if set on the hub work log
     * */
    @Nullable
    @LlmMethod(
            description = "Retrieves the created date of the work log"
    )
    public Date getCreated();

    /**
     * @return the Updated date of the work log not null if set on the hub work log
     * */
    @Nullable
    @LlmMethod(
            description = "Retrieves the updated date of the work log"
    )
    public Date getUpdated();
}
