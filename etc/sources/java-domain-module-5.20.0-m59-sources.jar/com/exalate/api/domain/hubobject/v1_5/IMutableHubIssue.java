package com.exalate.api.domain.hubobject.v1_5;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
/**
 * @since 0.12
 * */
public interface IMutableHubIssue extends com.exalate.api.domain.hubobject.v1_3.IMutableHubIssue {

    /*
     * Search for a project within the node with the specified project key and assign it to the issue.
     */
    public void setProjectKey(@Nonnull String projectKey);

    /*
     * Search for an issue type within the node with the specified name and assign it to the issue.
     */
    public void setTypeName(@Nonnull String issueTypeName);

    @Nullable
    public String getProjectKey();

    @Nullable
    public String getTypeName();
}
