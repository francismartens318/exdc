package com.exalate.api.domain.hubobject.v1_17;

import com.exalate.api.domain.IIssueKey;
import com.exalate.api.domain.hubobject.v1_2.IHubUser;

import javax.annotation.Nullable;
import java.util.Set;

public interface IHubIssue extends com.exalate.api.domain.hubobject.v1_16.IHubIssue {
    @Nullable
    Set<IHubUser> getApprovers();
    @Nullable
    IIssueKey getParent();
}
