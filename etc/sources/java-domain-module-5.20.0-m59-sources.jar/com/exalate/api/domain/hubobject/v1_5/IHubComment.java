package com.exalate.api.domain.hubobject.v1_5;

import com.exalate.api.domain.hubobject.v1_2.IHubUser;

import javax.annotation.Nullable;

/**
 * @since 0.12
 */
public interface IHubComment extends com.exalate.api.domain.hubobject.v1_4.IHubComment {

    /**
     * @return a user, who executes any of CRUD operations on a comment
     * */
    @Nullable
    public IHubUser getExecutor();

    public boolean getRestrictSync();

}
