/*
 * Copyright (C) 2015, iDalko NV
 * All rights reserved.
 *
 *
 * THIS SOURCE CODE IS AN UNPUBLISHED PROPRIETARY TRADE SECRET OF iDalko NV, unless stated otherwise
 * in the license text.
 *
 *
 * The copyright notice above does not evidence any actual or intended publication of such source code.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
 */
package com.exalate.api.domain.hubobject.v1_2;


import com.exalate.annotations.llm.LlmClass;
import com.exalate.annotations.llm.LlmMethod;
import com.exalate.api.domain.hubobject.ILockable;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.io.Serializable;
import java.util.Date;

import static com.exalate.api.domain.node.ConnectorNames.*;

/**
 * serves to transport additional info about an attachment
 */

@LlmClass(
        connectors = {AZURE_DEVOPS, GITHUB, JCLOUD, SERVICE_NOW, SALESFORCE, ZENDESK},
        description = "An interface representing an attachment in the issue tracker, providing methods to access attachment-specific information"
)
public interface IHubAttachment extends Serializable, ILockable {
    @LlmMethod(
            description = "Retrieves the unique string identifier of the attachment"
    )
    public String getIdStr();


    /**
     * @return the mime type of the attachment not null if set on the hub attachment
     */
    @Nullable
    @LlmMethod(
            description = "Retrieves the mime type of the attachment"
    )
    public String getMimetype();

    /**
     * @return the Filename of the attachment not null if set on the hub attachment
     */
    @Nullable
    @LlmMethod(
            description = "Retrieves the filename of the attachment"
    )
    public String getFilename();

    /**
     * @return the Created date of the attachment not null if set on the hub attachment
     */
    @Nullable
    @LlmMethod(
            description = "Retrieves the created date of the attachment"
    )
    public Date getCreated();

    /**
     * @return the Filesize of the attachment not null if set on the hub attachment
     */
    @Nullable
    @LlmMethod(
            description = "Retrieves the filesize of the attachment"
    )
    public Long getFilesize();

    /**
     * @return the Author of the attachment not null if set on the hub attachment
     */
    @Nullable
    @LlmMethod(
            description = "Retrieves the author of the attachment"
    )
    public IHubUser getAuthor();

    /**
     * @return whether the attachment is Thumbnail-able, not null if set on the hub attachment
     */
    @Nullable
    @LlmMethod(
            description = "Checks whether the attachment is thumbnailable"
    )
    public Boolean isThumbnailable();

    /**
     * @return whether the attachment is a zip
     */
    @Nonnull
    @LlmMethod(
            description = "Checks whether the attachment is a zip file"
    )
    public boolean isZip();

    /**
     * Can be used to determine whether an attachment has come from local or destination instance.
     *
     * @return an id of the attachment on the remote side.
     */
    @Nullable
    @LlmMethod(
            description = "Retrieves the remote ID of the attachment as a Long"
    )
    public Long getRemoteId();

    @LlmMethod(
            description = "Retrieves the remote string ID of the attachment as a String"
    )
    public String getRemoteIdStr();
}
