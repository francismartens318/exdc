package com.exalate.api.domain.hubobject.v1_15;


public interface IHubIssueLink {

    /**
     *
     * @return the name of the link type, independently of the direction of the link
     */
    public String getLinkTypeName();

    /**
     *
     * @return the name of the link, it changes depending on the direction of the link
     */
    public String getLinkName();

    /**
     *
     * @return the id of the issue this link is connected to
     */
    public Long getOtherIssueId();

    public String getIssueLinkType();

    public String getUrl();

    public Boolean isOutward();
}
