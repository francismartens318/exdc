/*
 * Copyright (C) 2015, iDalko NV
 * All rights reserved.
 *
 *
 * THIS SOURCE CODE IS AN UNPUBLISHED PROPRIETARY TRADE SECRET OF iDalko NV, unless stated otherwise
 * in the license text.
 *
 *
 * The copyright notice above does not evidence any actual or intended publication of such source code.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
 */
package com.exalate.api.domain.hubobject.v1_2;


import com.exalate.annotations.llm.LlmClass;
import com.exalate.annotations.llm.LlmMethod;
import com.exalate.api.domain.hubobject.IHubIssueReplica;
import com.exalate.api.domain.hubobject.ILockable;
import com.exalate.basic.domain.hubobject.v1.BasicHubAttachment;
import com.exalate.basic.domain.hubobject.v1.BasicHubWorkLog;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static com.exalate.api.domain.node.ConnectorNames.*;

/**
 * @since 0.8
 */

@LlmClass(
        connectors = {AZURE_DEVOPS, GITHUB, JCLOUD, SERVICE_NOW, SALESFORCE, ZENDESK},
        description = "An interface representing an issue in the issue tracker, providing methods to access issue-specific information. " +
                "Extends IHubIssueReplica and ILockable."
)
public interface IHubIssue extends IHubIssueReplica, ILockable {
    /**
     * @return the key of the issue not null if set on the hub issue
     */
    @Nullable
    @LlmMethod(
            description = "Retrieves the unique key of the issue"
    )
    public String getKey();

    /**
     * @return the Summary of the issue not null if set on the hub issue
     */
    @Nullable
    @LlmMethod(
            description = "Retrieves the summary of the issue"
    )
    public String getSummary();

    /**
     * @return the Description of the issue null if not set on the node issue or if not set on the hub issue
     */
    @Nullable
    @LlmMethod(
            description = "Retrieves the description of the issue"
    )
    public String getDescription();

    /**
     * @return the Environment of the issue null if not set on the node issue or if not set on the hub issue
     */
    @Nullable
    @LlmMethod(
            description = "Retrieves the environment of the issue"
    )
    public String getEnvironment();

    /**
     * @return the Assignee of the issue null if not set (set to unassigned) on the node issue or if not set on the hub issue
     */
    @Nullable
    @LlmMethod(
            description = "Retrieves the assignee of the issue"
    )
    public IHubUser getAssignee();

    /**
     * @return the Reporter of the issue not null if set on the hub issue
     */
    @Nullable
    @LlmMethod(
            description = "Retrieves the reporter of the issue"
    )
    public IHubUser getReporter();

    /**
     * @return the Status of the issue not null if set on the hub issue
     */
    @Nullable
    @LlmMethod(
            description = "Retrieves the status of the issue"
    )
    public IHubStatus getStatus();

    /**
     * @return the Resolution of the issue null if not set on the node issue or if not set on the hub issue
     */
    @Nullable
    @LlmMethod(
            description = "Retrieves the resolution of the issue"
    )
    public IHubResolution getResolution();

    /**
     * @return the Type of the issue not null if set on the hub issue
     */
    @Nullable
    @LlmMethod(
            description = "Retrieves the type of the issue"
    )
    public IHubIssueType getType();

    /**
     * @return the Priority of the issue not null if set on the hub issue
     */
    @Nullable
    @LlmMethod(
            description = "Retrieves the priority of the issue"
    )
    public IHubPriority getPriority();

    @Nonnull
    @LlmMethod(
            description = "Retrieves the set of affected versions of the issue"
    )
    public Set<IHubVersion> getAffectedVersions();

    @Nonnull
    @LlmMethod(
            description = "Retrieves the set of fix versions of the issue"
    )
    public Set<IHubVersion> getFixVersions();

    /**
     * @return the Due date of the issue null if not set on the node issue or if not set on the hub issue
     */
    @Nullable
    @LlmMethod(
            description = "Retrieves the due date of the issue"
    )
    public Date getDue();

    /**
     * @return the Original Estimate of the issue null if not set on the node issue or if not set on the hub issue
     */
    @Nullable
    @LlmMethod(
            description = "Retrieves the original estimate of the issue"
    )
    public Long getOriginalEstimate();

    /**
     * @return the Remaining Estimate of the issue null if not set on the node issue or if not set on the hub issue
     */
    @Nullable
    @LlmMethod(
            description = "Retrieves the remaining estimate of the issue"
    )
    public Long getRemainingEstimate();

    /**
     * @return the Time Spent of the issue null if not set on the node issue or if not set on the hub issue
     */
    @Nullable
    @LlmMethod(
            description = "Retrieves the time spent on the issue"
    )
    public Long getTimeSpent();

    /**
     * @return the Project of the issue not null if set on the hub issue
     */
    @Nullable
    @LlmMethod(
            description = "Retrieves the project to which the issue belongs"
    )
    public IHubProject getProject();

    @Nonnull
    @LlmMethod(
            description = "Retrieves the list of components of the issue",
            returnType = "List<IHubComponent>"
    )
    public List<IHubComponent> getComponents();

    @Nonnull
    @LlmMethod(
            description = "Retrieves the list of work logs associated with the issue",
            returnType = "List<BasicHubWorkLog>"
    )
    public List<BasicHubWorkLog> getWorkLogs();

    @Nonnull
    @LlmMethod(
            description = "Retrieves the set of labels associated with the issue",
            returnType = "Set<IHubLabel>"
    )
    public Set<IHubLabel> getLabels();

    @Nonnull
    @LlmMethod(
            description = "Retrieves the list of attachments associated with the issue",
            returnType = "List<BasicHubAttachment>"
    )
    public List<BasicHubAttachment> getAttachments();

    /**
     * @return the Votes of the issue null if not set on the node issue or if not set on the hub issue
     */
    @Nullable
    @LlmMethod(
            description = "Retrieves the number of votes on the issue"
    )
    public Long getVotes();

    @Nonnull
    @LlmMethod(
            description = "Retrieves the set of users who voted for the issue",
            returnType = "Set<IHubUser>"
    )
    public Set<IHubUser> getVoters();

    /**
     * @return the Watches of the issue null if not set on the node issue or if not set on the hub issue
     */
    @Nullable
    @LlmMethod(
            description = "Retrieves the number of watches on the issue"
    )
    public Long getWatches();

    @Nonnull
    @LlmMethod(
            description = "Retrieves the set of users who are watching the issue",
            returnType = "Set<IHubUser>"
    )
    public Set<IHubUser> getWatchers();

    @Nonnull
    @LlmMethod(
            description = "Retrieves a map of custom keys associated with the issue",
            returnType = "Map<String, Object>"
    )
    public Map<String, Object> getCustomKeys();

    /**
     * Allows to share custom fields between issue trackers.
     * It is a map in order for the users to have easier access to fields.
     * The keys in the map are populated from the following properties in the hub customfields:
     * <pre>
     *     issue.customFields."${name}".value = "foo"   // ${name} = IHubCustomField.getName()
     *     issue.customFields."${uid}".value = "foo"    // ${uid} = IHubCustomField.getUid()
     * </pre>
     * Usually the uid entries are put only for the custom fields, which clash by name
     * */
    @Nonnull
    @LlmMethod(
            description = "Retrieves a map of custom fields associated with the issue",
            returnType = "Map<String, IHubCustomField>"
    )
    public Map<String, IHubCustomField> getCustomFields();

    @Override
    @LlmMethod(
            description = "Compares this issue with the specified object for equality"
    )
    public boolean equals(Object that);

    @Override
    @LlmMethod(
            description = "Returns the hash code for this issue"
    )
    public int hashCode();
}
