/*
 * Copyright (C) 2015, iDalko NV
 * All rights reserved.
 *
 *
 * THIS SOURCE CODE IS AN UNPUBLISHED PROPRIETARY TRADE SECRET OF iDalko NV, unless stated otherwise
 * in the license text.
 *
 *
 * The copyright notice above does not evidence any actual or intended publication of such source code.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
 */
package com.exalate.api.domain.hubobject.v1_3;


import com.exalate.api.domain.hubobject.IMutableHubIssueReplica;
import com.exalate.api.domain.hubobject.v1_2.*;
import com.exalate.basic.domain.hubobject.v1.BasicHubAttachment;
import com.exalate.basic.domain.hubobject.v1.BasicHubComment;
import com.exalate.basic.domain.hubobject.v1.BasicHubWorkLog;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;


public interface IMutableHubIssue extends com.exalate.api.domain.hubobject.v1_14.IHubIssue, IMutableHubIssueReplica {
    public void setKey(@Nonnull String key);

    public void setSummary(@Nonnull String summary);

    public void setDescription(@Nonnull String description);
    public void setEnvironment(@Nonnull String environment);

    public void setAssignee(@Nullable IHubUser assignee);
    public void setReporter(@Nullable IHubUser reporter);

    public void setStatus(@Nonnull IHubStatus status);
    public void setStatus(@Nonnull IHubOption status);
    public void setResolution(@Nullable IHubResolution resolution);

    public void setType(@Nonnull IHubIssueType issueType);
    public void setType(@Nonnull IHubOption issueType);

    public void setPriority(@Nonnull IHubPriority priority);
    public void setPriority(@Nonnull IHubOption priority);

    public void setAffectedVersions(@Nonnull Set<IHubVersion> affectedVersions);
    public void setFixVersions(@Nonnull Set<IHubVersion> fixVersions);
    public void setDue(@Nullable Date dueDate);
    public void setOriginalEstimate(@Nullable Long originalEstimate);
    public void setRemainingEstimate(@Nullable Long remainingEstimate);
    public void setTimeSpent(@Nullable Long timeSpent);

    public void setProject(@Nonnull IHubProject project);

    public void setComponents(@Nonnull List<IHubComponent> components);

    public void setLabels(@Nonnull Set<IHubLabel> labels);

    public void setWorkLogs(@Nonnull List<BasicHubWorkLog> worklogs);

    public void setAttachments(@Nonnull List<BasicHubAttachment> attachments);

    public void setComments(@Nonnull List<BasicHubComment> comments);

    public void setVotes(@Nonnull Long votes);
    public void setVoters(@Nonnull Set<IHubUser> voters);
    public void setWatches(@Nonnull Long watches);
    public void setWatchers(@Nonnull Set<IHubUser> watchers);

    public void setCustomKeys(@Nonnull Map<String, Object> customKeys);

    public void setCustomFields(@Nonnull Map<String, IHubCustomField> customFields);
    public void setEntityProperties(Map<String, Object> entityProperties);
    /**
     * Deprecated since 1.0.0. Use com.exalate.node.hubobject.v1_5.WorkflowHelper#transition().
     */
    @Deprecated
    @Nullable
    public String getDoTransition();


    /**
     * Deprecated since 1.0.0. Use com.exalate.node.hubobject.v1_5.WorkflowHelper#transition().
     */
    @Deprecated
    public void setDoTransition(@Nonnull String transitionName);

    public void setWorkflowContext(@Nonnull IWorkflowContext workflowContext);

    @Override
    public boolean equals(Object that);
    @Override
    public int hashCode();
}
