/**
 * @since 0.8
 */
package com.exalate.api.domain.hubobject.v1_2;