/*
 * Copyright (C) 2015, iDalko NV
 * All rights reserved.
 *
 *
 * THIS SOURCE CODE IS AN UNPUBLISHED PROPRIETARY TRADE SECRET OF iDalko NV, unless stated otherwise
 * in the license text.
 *
 *
 * The copyright notice above does not evidence any actual or intended publication of such source code.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
 */
package com.exalate.api.domain.hubobject.v1_2;


import com.exalate.annotations.llm.LlmClass;
import com.exalate.annotations.llm.LlmMethod;
import com.exalate.api.domain.hubobject.ILockable;

import javax.annotation.Nullable;

import static com.exalate.api.domain.node.ConnectorNames.*;

/**
 * A domain object representing a "working part" of a Project such that an
 * Issue can be raised against or be relevant only to some parts. Typical usage
 * in projects to develop a technology product have a ProjectComponent for each
 * subsystem or module, e.g. GUI, Database, Indexing, Importing.
 *
 * Components can have a lead, or user responsible for the issues raised against
 * that component.
 *
 * The AssigneeType value (com.atlassian.jira.project.AssigneeTypes)
 * refers to the default assignee for issues raised on that component.
 */
@LlmClass(
        connectors = {AZURE_DEVOPS, GITHUB, JCLOUD, SERVICE_NOW, SALESFORCE, ZENDESK},
        description = "An interface representing a project component in the issue tracker, providing methods to access component-specific information. " +
                "A coponent is a domain object representing a \"working part\" of a Project such that an Issue can be raised against or be relevant only to some parts. " +
                "Typical usage in projects to develop a technology product have a ProjectComponent for each subsystem or module, e.g. GUI, Database, Indexing, Importing. " +
                "Components can have a lead, or user responsible for the issues raised against that component."
)
public interface IHubComponent extends ILockable, IHubOption {
    /**
     * Returns the component description.
     *
     * @return component description
     */
    @Nullable
    @LlmMethod(
            description = "Retrieves the description of the component"
    )
    public String getDescription();

    /**
     * Returns the lead user for this project component.
     *
     * @return the lead user for this project component
     */
    @Nullable
    @LlmMethod(
            description = "Retrieves the lead user for this project component"
    )
    public IHubUser getLead();

    /**
     * Returns the name of this project component.
     *
     * @return name of this project component
     */
    @Nullable
    @LlmMethod(
            description = "Retrieves the name of this project component"
    )
    public String getName();

    /**
     * Returns the id of the project of this component.
     * @return the project's id.
     */
    @Nullable
    @LlmMethod(
            description = "Retrieves the ID of the project to which this component belongs"
    )
    public Long getProjectId();

    /**
     * Returns the key of the project of this component.
     * @return the project's key.
     */
    @Nullable
    @LlmMethod(
            description = "Retrieves the key of the project to which this component belongs"
    )
    public String getProjectKey();


    /**
     * Returns the assignee type.
     * @return the assignee type.
     *
     * see com.atlassian.jira.project.AssigneeTypes
     */
    @Nullable
    @LlmMethod(
            description = "Retrieves the default assignee for issues raised for this component"
    )
    public HubAssigneeType getAssigneeType();

    @Override
    @LlmMethod(
            description = "Compares this component with the specified object for equality"
    )
    public boolean equals(Object o);
    @Override
    @LlmMethod(
            description = "Returns the hash code for this component"
    )
    public int hashCode();
}
