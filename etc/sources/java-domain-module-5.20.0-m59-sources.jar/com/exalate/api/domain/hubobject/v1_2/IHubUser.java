/*
 * Copyright (C) 2015, Exalate NV
 * All rights reserved.
 *
 *
 * THIS SOURCE CODE IS AN UNPUBLISHED PROPRIETARY TRADE SECRET OF iDalko NV, unless stated otherwise
 * in the license text.
 *
 *
 * The copyright notice above does not evidence any actual or intended publication of such source code.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
 */
package com.exalate.api.domain.hubobject.v1_2;


import com.exalate.annotations.llm.LlmClass;
import com.exalate.annotations.llm.LlmMethod;
import com.exalate.api.domain.hubobject.ILockable;

import javax.annotation.Nullable;

import static com.exalate.api.domain.node.ConnectorNames.*;

/**
 * a presentation of a node application user
 * */

@LlmClass(
        connectors = {AZURE_DEVOPS, GITHUB, JCLOUD, SERVICE_NOW, SALESFORCE, ZENDESK},
        description = "An interface representing a user in the issue tracker, providing methods to access user-specific information such as key, username, email, display name, and active status."
)
public interface IHubUser extends ILockable {
    /**
     * Returns the key which distinguishes the ApplicationUser as unique.  The same key is
     * shared by all {@code User}s with the same username (ignoring case) across all user
     * directories.
     *
     * @return the key which distinguishes the ApplicationUser as unique
     */
    @Nullable
    @LlmMethod(
            description = "Retrieves the unique key that identifies the user within the application"
    )
    public String getKey();

    /**
     * Returns the key which distinguishes the ApplicationUser as unique.  The same key is
     * shared by all {@code User}s with the same username (ignoring case) across all user
     * directories.
     *
     * @return the login for the user
     */
    @Nullable
    @LlmMethod(
            description = "Retrieves the username of the user"
    )
    public String getUsername();

    /**
     * @return true if this user is active.
     */
    @LlmMethod(
            description = "Checks if the user is currently active within the issue tracker"
    )
    public boolean isActive();

    /**
     * @return email address of the user.
     */
    @Nullable
    @LlmMethod(
            description = "Retrieves the email address associated with the user"
    )
    public String getEmail();

    /**
     * Returns the display name of the user.
     * This is sometimes referred to as "full name".
     *
     * @return display name of the user, must never be null.
     */
    @Nullable
    @LlmMethod(
            description = "Retrieves the display name of the user",
            returnType = "java.lang.String. Must never be null."
    )
    public String getDisplayName();

    /**
     * Implementations must ensure equality based on getKey().
     *
     * @param obj object to compare to.
     * @return {@code true} if and only if the key matches.
     */
    @LlmMethod(
            description = "Compares this user with the specified object for equality. Equality based on getKey()"
    )
    public boolean equals(Object obj);

    /**
     * Implementations must produce a hashcode based on getKey().
     *
     * @return hashcode.
     */
    @LlmMethod(
            description = "Returns the hash code for this user"
    )
    public int hashCode();
}
