/*
 * Copyright (C) 2015, iDalko NV
 * All rights reserved.
 *
 *
 * THIS SOURCE CODE IS AN UNPUBLISHED PROPRIETARY TRADE SECRET OF iDalko NV, unless stated otherwise
 * in the license text.
 *
 *
 * The copyright notice above does not evidence any actual or intended publication of such source code.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
 */
package com.exalate.api.domain.hubobject.v1_2;



import com.exalate.annotations.llm.LlmClass;
import com.exalate.annotations.llm.LlmMethod;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.List;

import static com.exalate.api.domain.node.ConnectorNames.*;


@LlmClass(
        connectors = {AZURE_DEVOPS, GITHUB, JCLOUD, SERVICE_NOW, SALESFORCE, ZENDESK},
        description = "An interface representing an option in the issue tracker, providing methods to access option-specific information"
)
public interface IHubOption {

    /**
     * @return not all options have an id value due to the nature of the field or due to an issue tracker design decision
     */
    @Nullable
    @LlmMethod(
            description = "Retrieves the unique identifier of the option"
    )
    public String getId();

    /**
     * @return the Sequence of the option null - if not set on the node option, or if NOT YET set on the hub option
     * */
    @Nullable
    @LlmMethod(
            description = "Retrieves the sequence of the option"
    )
    public Long getSequence();

    /**
     * The current value of the option. This is the option displayed to the user.
     *
     * @return the value of the option. not null WHEN set on the hub option
     */
    @Nullable
    @LlmMethod(
            description = "Retrieves the current value of the option displayed to the user"
    )
    public String getValue();

    /**
     * @return the Disabled of the option, null - if not set on the node option, or if NOT YET set on the hub option
     * */
    @Nullable
    @LlmMethod(
            description = "Checks whether the option is disabled"
    )
    public Boolean isDisabled();

    /**
     * @return the Parent Option of the option, null - if not set on the node option, or if NOT YET set on the hub option
     * */
    @Nullable
    @LlmMethod(
            description = "Retrieves the parent option of the current option"
    )
    public IHubOption getParentOption();

    /**
     * Return a list of options that exist under this option (i.e. its children).
     *
     * @return the list of options that exist under this option. An empty list is returned when such options exist.
     */
    @Nonnull
    @LlmMethod(
            description = "Retrieves a list of child options that exist under this option",
            returnType = "List<IHubOption> - if there are no children, an empty list is returned"
    )
    public List<IHubOption> getChildOptions();
}
