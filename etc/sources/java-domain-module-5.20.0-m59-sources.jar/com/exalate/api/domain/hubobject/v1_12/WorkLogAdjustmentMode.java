package com.exalate.api.domain.hubobject.v1_12;

public enum WorkLogAdjustmentMode {

    AUTO_ADJUST("auto"),
    RETAIN("leave"),
    ADJUST_MANUALLY("manual"),
    SET_NEW("new");

    private String value;

    private WorkLogAdjustmentMode(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
