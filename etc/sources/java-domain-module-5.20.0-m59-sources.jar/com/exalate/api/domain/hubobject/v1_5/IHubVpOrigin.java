package com.exalate.api.domain.hubobject.v1_5;

public interface IHubVpOrigin {

    public String getPortalKey();

    public String getRequestTypeKey();

    public String getRepresentationValue();
}
