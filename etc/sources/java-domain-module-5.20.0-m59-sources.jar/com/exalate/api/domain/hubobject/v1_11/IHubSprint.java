package com.exalate.api.domain.hubobject.v1_11;

import com.exalate.api.domain.hubobject.IHubIssueReplica;

import java.util.Date;

public interface IHubSprint extends IHubIssueReplica {
    String getId();

    void setId(String id);

    String getState();

    void setState(String state);

    String getName();

    void setName(String name);

    Date getStartDate();

    void setStartDate(Object startDate);

    Date getEndDate();

    void setEndDate(Object endDate);

    Date getCompleteDate();

    void setCompleteDate(Object completeDate);

    String getGoal();

    void setGoal(String goal);

    Long getSequence();

    void setSequence(Object sequence);

    String getOriginBoardId();

    void setOriginBoardId(String originBoardId);
}
