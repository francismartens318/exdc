package com.exalate.api.domain.hubobject.v1_12;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

public interface IHubWorkLog extends com.exalate.api.domain.hubobject.v1_2.IHubWorkLog {



    /**
     *
     * @return the mode which represents the way the remaining estimate is being adjusted
     * while a workLog is being created / changed / removed.
     * By default AUTO_ADJUST mode is used.
     */
    @Nonnull
    public WorkLogAdjustmentMode getAdjustmentMode();

    /**
     *
     * @return the string in JIRA's duration format (i.e. "1h 35m") which represents a period of time which is used
     * to manually adjust remaining estimate while a workLog is being created / changed / removed.
     * Returns null if workLogEstimateMode != WorkLogEstimateMode.ADJUST_MANUALLY
     */
    @Nullable
    public String getAdjustRemainingBy();

    /**
     *
     * @return the string in JIRA's duration format (i.e. "5h 30m") which represents new remaining estimate set
     * while a workLog is being created / changed / removed.
     * Returns null if workLogEstimateMode != WorkLogEstimateMode.SET_NEW
     */
    @Nullable
    public String getNewEstimate();
}
