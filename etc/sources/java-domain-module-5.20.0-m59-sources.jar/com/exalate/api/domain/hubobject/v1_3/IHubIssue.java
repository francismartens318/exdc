/*
 * Copyright (C) 2015, Exalate NV
 * All rights reserved.
 *
 *
 * THIS SOURCE CODE IS AN UNPUBLISHED PROPRIETARY TRADE SECRET OF iDalko NV, unless stated otherwise
 * in the license text.
 *
 *
 * The copyright notice above does not evidence any actual or intended publication of such source code.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
 */
package com.exalate.api.domain.hubobject.v1_3;

import com.exalate.basic.domain.hubobject.v1.BasicHubAttachment;
import com.exalate.basic.domain.hubobject.v1.BasicHubComment;

import javax.annotation.Nonnull;
import java.util.List;

/**
 * @since 0.9
 */
public interface IHubIssue extends com.exalate.api.domain.hubobject.v1_2.IHubIssue {

    /**
     * @return a list of comments, currently present on an issue
     */
    @Nonnull
    public List<BasicHubComment> getComments();

    /**
     * @return a list of comments, which have been added during tha latest operation being synchronized
     */
    @Nonnull
    public List<BasicHubComment> getAddedComments();

    /**
     * @return a list of comments, which have been changed during tha latest operation being synchronized
     */
    @Nonnull
    public List<BasicHubComment> getChangedComments();

    /**
     * @return a list of comments, which have been removed during tha latest operation being synchronized
     */
    @Nonnull
    public List<BasicHubComment> getRemovedComments();

    /**
     * @return a list of attachments, which have been added during tha latest operation being synchronized
     */
    @Nonnull
    public List<BasicHubAttachment> getAddedAttachments();

    /**
     * @return a list of attachments, which have been removed during tha latest operation being synchronized
     */
    @Nonnull
    public List<BasicHubAttachment> getRemovedAttachments();

    /**
     * @return IWorkflowContext containing info about a transition to execute
     */
    @Nonnull
    public IWorkflowContext getWorkflowContext();
}
