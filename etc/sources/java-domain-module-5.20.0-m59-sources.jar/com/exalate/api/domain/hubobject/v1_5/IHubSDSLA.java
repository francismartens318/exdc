package com.exalate.api.domain.hubobject.v1_5;


public interface IHubSDSLA {
    public String getJsonRepresentation();

    public void setJsonRepresentation(String json);
}
