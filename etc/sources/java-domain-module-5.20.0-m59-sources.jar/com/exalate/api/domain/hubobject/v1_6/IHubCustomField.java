package com.exalate.api.domain.hubobject.v1_6;

import com.exalate.api.domain.hubobject.v1_2.IHubIssue;

import javax.annotation.Nullable;

public interface IHubCustomField extends com.exalate.api.domain.hubobject.v1_2.IHubCustomField {
    /**
     * the uid - similarly to the {@link #getId()} - symbolizes a node-unique identifier
     * only uid is a string identifier
     * while name is a human readable label, which may not be unique, uid is required to be unique
     * uid should also be present on the issue tracker's user interface such that
     * if an administrator fails to find a customfield by name, he can find the custom field by uid
     *
     * For JIRA custom field's uid is the custom field's Long id, thus
     * <pre>
     *     IHubCustomField cf = ...
     *     cf.getIdStr().toString().equals(cf.getUid()) // true for JIRA cf
     * </pre>
     *
     * The need for it is that custom fields may clash in the {@link IHubIssue#getCustomFields()} map, if put only by custom field name.
     * Thus for the clashing custom fields, they are put into the map by their uid:
     * <pre>
     *     //HPQC example:
     *     // GIVEN:
     *     IHubCustomField fooCf1 = ...
     *     IHubCustomField fooCf2 = ...
     *     IHubCustomField barCf = ...
     *
     *     fooCf1.getName() // "foo"
     *     fooCf2.getName() // "foo"
     *     fooCf1.getName().equals(fooCf2.getName()) // true
     *     barCf.getName() // "bar"
     *
     *     fooCf1.getUid() // "foo"
     *     fooCf2.getUid() // "foo"
     *
     *     fooCf1.getUid() // "BG_USER_03"
     *     fooCf2.getUid() // "BG_USER_10"
     *     fooCf1.getUid().equals(fooCf2.getUid()) // false
     *     barCf.getUid() // "BG_USER_49"
     *
     *     IHubIssue issue = ...
     *
     *     // WHEN (groovy code):
     *     // try to access via name clashing by name custom fields:
     *     issue.customFields."foo" // null
     *     // try to access via uid clashing by name custom fields:
     *     issue.customFields."BG_USER_03" // fooCf1
     *     issue.customFields."BG_USER_10" // fooCf2
     *
     *     // try to access via name non-clashing by name custom fields:
     *     issue.customFields."bar" // barCf
     * </pre>
     * */
    @Nullable
    public String getUid();
}
