/*
 * Copyright (C) 2015, Exalate NV
 * All rights reserved.
 *
 *
 * THIS SOURCE CODE IS AN UNPUBLISHED PROPRIETARY TRADE SECRET OF iDalko NV, unless stated otherwise
 * in the license text.
 *
 *
 * The copyright notice above does not evidence any actual or intended publication of such source code.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
 */
package com.exalate.api.domain.hubobject.v1_2;


import com.exalate.annotations.llm.LlmClass;
import com.exalate.annotations.llm.LlmMethod;
import com.exalate.api.domain.hubobject.ILockable;

import javax.annotation.Nullable;
import java.util.Date;

import static com.exalate.api.domain.node.ConnectorNames.*;

/**
 * a hub object representing the node's project version
 * */

@LlmClass(
        connectors = {AZURE_DEVOPS, GITHUB, JCLOUD, SERVICE_NOW, SALESFORCE, ZENDESK},
        description = "An interface representing a version in the issue tracker, providing methods to access version-specific information."
)
public interface IHubVersion extends ILockable, IHubOption {
    /**
     * @return the id of the version not null if set on the hub version
     * */
    @Nullable
    @LlmMethod(
            description = "Retrieves the unique identifier of the version."
    )
    public String getId();

    /**
     * @return the Name of the version not null WHEN set on the hub version
     * */
    @Nullable
    @LlmMethod(
            description = "Retrieves the name of the version."
    )
    public String getName();

    /**
     * @return the Description of the version, null - if not set on the node version, or if NOT YET set on the hub version
     * */
    @Nullable
    @LlmMethod(
            description = "Retrieves the description of the version."
    )
    public String getDescription();

    /**
     * @return the key of the project that this version belongs to.
     * key of the project for the version not null WHEN set on the hub version
     * */
    @Nullable
    @LlmMethod(
            description = "Retrieves the key of the project to which this version belongs"
    )
    public String getProjectKey();

    @LlmMethod(
            description = "Checks if the version is archived"
    )
    public boolean isArchived();

    @LlmMethod(
            description = "Checks if the version is released"
    )
    public boolean isReleased();

    /**
     * @return the Release Date of the version, null - if not set on the node version, or if NOT YET set on the hub version
     * */
    @Nullable
    @LlmMethod(
            description = "Retrieves the release date of the version"
    )
    public Date getReleaseDate();

    /**
     * @return The start date of the version
     * null - if not set on the node version, or if NOT YET set on the hub version
     * */
    @Nullable
    @LlmMethod(
            description = "Retrieves the start date of the version"
    )
    public Date getStartDate();

    @Override
    @LlmMethod(
            description = "Compares this version with the specified object for equality"
    )
    public boolean equals(Object that);
    @Override
    @LlmMethod(
            description = "Returns the hash code for this version."
    )
    public int hashCode();
}
