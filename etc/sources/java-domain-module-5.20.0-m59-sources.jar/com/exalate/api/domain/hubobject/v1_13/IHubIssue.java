package com.exalate.api.domain.hubobject.v1_13;

import com.exalate.basic.domain.hubobject.v1.BasicHubWorkLog;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.List;

public interface IHubIssue extends com.exalate.api.domain.hubobject.v1_12.IHubIssue {


    @Nonnull
    public String getId();

    @Nullable
    public String getParentId();
}
