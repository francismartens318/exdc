/*
 * Copyright (C) 2015, iDalko NV
 * All rights reserved.
 *
 *
 * THIS SOURCE CODE IS AN UNPUBLISHED PROPRIETARY TRADE SECRET OF iDalko NV, unless stated otherwise
 * in the license text.
 *
 *
 * The copyright notice above does not evidence any actual or intended publication of such source code.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
 */
package com.exalate.api.domain.hubobject.v1_2;


import com.exalate.annotations.llm.LlmClass;
import com.exalate.annotations.llm.LlmMethod;
import com.exalate.api.domain.hubobject.ILockable;

import javax.annotation.Nullable;

import static com.exalate.api.domain.node.ConnectorNames.*;


@LlmClass(
        connectors = {AZURE_DEVOPS, GITHUB, JCLOUD, SERVICE_NOW, SALESFORCE, ZENDESK},
        description = "An interface representing a custom field in the issue tracker, providing methods to access custom field-specific information"
)
public interface IHubCustomField extends ILockable {
    /**
     * @return the id of the custom field not null WHEN set on the hub custom field
     * */
    @Nullable
    @LlmMethod(
            description = "Retrieves the unique identifier of the custom field"
    )
    public Long getId();

    /**
     * @return the Name of the custom field not null WHEN set on the hub custom field
     * */
    @Nullable
    @LlmMethod(
            description = "Retrieves the name of the custom field"
    )
    public String getName();

    /**
     * @return the Description of the custom field, null if not set on the node custom field or UNTIL not set on the hub custom field
     * */
    @Nullable
    @LlmMethod(
            description = "Retrieves the description of the custom field"
    )
    public String getDescription();


    /**
     * @return the Type of the custom field not null WHEN set on the hub custom field
     * */
    @Nullable
    @LlmMethod(
            description = "Retrieves the type of the custom field"
    )
    public HubCustomFieldType getType();

    /**
     * @return the Value of the custom field, null if not set on the node custom field or UNTIL not set on the hub custom field
     * */
    @Nullable
    @LlmMethod(
            description = "Retrieves the value of the custom field"
    )
    public Object getValue();
}
