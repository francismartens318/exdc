package com.exalate.api.domain.hubobject.v1_15;


import com.exalate.api.domain.IIssueKey;
import com.exalate.api.domain.hubobject.v1_17.IHubIssue;
import com.exalate.api.domain.hubobject.v1_2.IHubUser;


public interface IMutableHubIssue extends com.exalate.api.domain.hubobject.v1_9.IMutableHubIssue, IHubIssue {
    public void setCreator(IHubUser creator);
    public void setSecurityLevel(IHubIssueSecurityLevel securityLevel);

    public void setParent(IIssueKey parent);
}
