/*
 * Copyright (C) 2015, iDalko NV
 * All rights reserved.
 *
 *
 * THIS SOURCE CODE IS AN UNPUBLISHED PROPRIETARY TRADE SECRET OF iDalko NV, unless stated otherwise
 * in the license text.
 *
 *
 * The copyright notice above does not evidence any actual or intended publication of such source code.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
 */
package com.exalate.api.domain.hubobject.v1_2;




public enum HubAssigneeType {
    /**
     * Assignee is set to the default for the project.
     *
     * see com.atlassian.jira.project.AssigneeTypes#PROJECT_DEFAULT
     */
    PROJECT_DEFAULT(0),
    /**
     * Assignee is set to the com.atlassian.jira.bc.project.component.ProjectComponent lead.
     *
     * see com.atlassian.jira.project.AssigneeTypes#COMPONENT_LEAD
     */
    COMPONENT_LEAD(1),
    /**
     * Assignee is set to the com.atlassian.jira.project.Project lead.
     *
     * see com.atlassian.jira.project.AssigneeTypes#PROJECT_LEAD
     */
    PROJECT_LEAD(2),
    /**
     * Issue is left with no assignee.
     *
     * see com.atlassian.jira.project.AssigneeTypes#UNASSIGNED
     */
    UNASSIGNED(3);

    private final long code;

    HubAssigneeType(long code) {
        this.code = code;
    }

    public long getCode() {
        return code;
    }
}
