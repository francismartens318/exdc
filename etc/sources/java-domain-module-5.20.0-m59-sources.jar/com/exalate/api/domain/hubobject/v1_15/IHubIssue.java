package com.exalate.api.domain.hubobject.v1_15;

import com.exalate.api.domain.hubobject.v1_2.IHubUser;
import com.exalate.basic.domain.hubobject.v1.BasicHubChangeHistory;
import com.exalate.basic.domain.hubobject.v1.BasicHubIssueLink;

import javax.annotation.Nonnull;
import java.util.List;

public interface IHubIssue extends com.exalate.api.domain.hubobject.v1_14.IHubIssue {
    @Nonnull
    List<BasicHubChangeHistory> getChangeHistory();
    IHubUser getCreator();

    @Nonnull
    List<BasicHubIssueLink> getIssueLinks();

    IHubIssueSecurityLevel getSecurityLevel();
}
