package com.exalate.api.domain.hubobject.v1_3;

import com.exalate.api.domain.hubobject.v1_2.IHubUser;
import com.exalate.basic.domain.hubobject.v1.BasicHubComment;

import javax.annotation.Nullable;

/**
 * Contains info about a transition to execute and the user that should perform the transition.
 */
public interface IWorkflowContext {

    @Nullable
    public String getTransitionName();

    public void setTransitionName(@Nullable String transitionName);

    public boolean hasTransitionName();

    @Nullable
    public IHubUser getExecutor();

    public void setExecutor(@Nullable IHubUser executor);

    public boolean isChecked();
    public void setChecked(boolean checked);


    public BasicHubComment getComment();

    public void setComment(BasicHubComment comment);

    /**
     * Checks whether an executor is specified and if it has a valid user key.
     * @return true if an executor with a valid key is specified, false if not
     */
    public boolean hasExecutor();
}
