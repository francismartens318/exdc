package com.exalate.api.domain.hubobject.v1_8;



import com.exalate.api.domain.hubobject.ILockable;
import com.exalate.api.domain.hubobject.v1_2.IHubOption;

import javax.annotation.Nonnull;

public interface IHubStatusCategory extends ILockable, IHubOption {
    @Nonnull
    public String getId();

    @Nonnull
    public String getKey();

    @Nonnull
    public String getName();
}
