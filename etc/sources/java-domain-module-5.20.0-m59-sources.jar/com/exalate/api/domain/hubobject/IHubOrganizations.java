package com.exalate.api.domain.hubobject;

import com.exalate.basic.domain.hubobject.v1.BasicHubOrganization;

import java.util.List;

/**
 * @deprecated use {@link com.exalate.api.domain.hubobject.IHubOrganization}
 */
@Deprecated
public interface IHubOrganizations {

    public List<IHubOrganization> getOrganizations();

}
