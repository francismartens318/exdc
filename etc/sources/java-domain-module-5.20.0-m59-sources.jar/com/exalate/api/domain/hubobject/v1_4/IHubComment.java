package com.exalate.api.domain.hubobject.v1_4;

/**
 * @since 0.10
 */
public interface IHubComment extends com.exalate.api.domain.hubobject.v1_3.IHubComment {
    /**
     * @return a boolean indicating if the comment is set as a internal or external on a Help Desk context
     */
    public boolean isInternal();
}
