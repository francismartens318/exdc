package com.exalate.api.domain.hubobject;

public class EntityType {

    public String name;
    public String label;
    public boolean queryLanguageSupported;
    public boolean allowEmptyQuery;
    static public String ALL = "All";

    public EntityType(String name, boolean queryLanguageSupported, boolean allowEmptyQuery) {
        this.name = name;
        this.label = name;
        this.queryLanguageSupported = queryLanguageSupported;
        this.allowEmptyQuery = allowEmptyQuery;
    }

    public EntityType(String name, boolean queryLanguageSupported, boolean allowEmptyQuery, String label) {
        this.name = name;
        this.label = label;
        this.queryLanguageSupported = queryLanguageSupported;
        this.allowEmptyQuery = allowEmptyQuery;
    }

    public EntityType(String name, boolean queryLanguageSupported, String label) {
        this.name = name;
        this.label = label;
        this.queryLanguageSupported = queryLanguageSupported;
    }

    public String getName() {
        return this.name;
    }

    public boolean isQueryLanguageSupported() {
        return this.queryLanguageSupported;
    }

    public boolean allowsEmptyQuery() {
        return this.allowEmptyQuery;
    }

}
