package com.exalate.api.domain.hubobject.v1_15;

import com.exalate.api.domain.hubobject.ILockable;

public interface IHubIssueSecurityLevel extends ILockable {

    public String getName();
    public String getId();
    public String getDescription();
}
