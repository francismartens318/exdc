package com.exalate.api.domain.hubobject.v1_7;


import java.util.Date;


public interface IMutableHubIssue extends com.exalate.api.domain.hubobject.v1_5.IMutableHubIssue, IHubIssue {
    public void setResolutionDate(Date resolutionDate);
    public void setSeverityName(String severityName);
}
