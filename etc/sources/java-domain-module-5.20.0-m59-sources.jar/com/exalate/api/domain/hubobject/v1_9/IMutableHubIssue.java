package com.exalate.api.domain.hubobject.v1_9;


import java.util.Date;


public interface IMutableHubIssue extends com.exalate.api.domain.hubobject.v1_7.IMutableHubIssue, IHubIssue {
    public void setCreated(Date created);
    public void setUpdated(Date updated);
}
