package com.exalate.api.domain.hubobject.v1_14;

import javax.annotation.Nonnull;
import java.util.Map;

public interface IHubIssue extends com.exalate.api.domain.hubobject.v1_13.IHubIssue {

    @Nonnull
    Map<String, Object> getEntityProperties();

}
