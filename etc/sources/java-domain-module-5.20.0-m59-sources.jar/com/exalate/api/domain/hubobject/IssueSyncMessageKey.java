package com.exalate.api.domain.hubobject;

public enum IssueSyncMessageKey {
    VERSION("version"),
    HUB_ISSUE("hubIssue"),
    ISSUE_URL("issueUrl");

    IssueSyncMessageKey(String jsonName) {
        this.jsonName = jsonName;
    }

    public final String jsonName;
}
