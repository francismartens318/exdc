/**
 * @since 0.9
 */
package com.exalate.api.domain.hubobject.v1_3;