package com.exalate.api.domain.hubobject.v1_10;

public interface IHubLexoRank {
    public String getValue();
}
