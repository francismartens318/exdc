package com.exalate.api.domain.hubobject.v1_11;

import com.exalate.api.domain.hubobject.v1_2.IHubOption;

public interface IHubCascadingSelect {
    public IHubOption getParent();
    public IHubOption getChild();
}
