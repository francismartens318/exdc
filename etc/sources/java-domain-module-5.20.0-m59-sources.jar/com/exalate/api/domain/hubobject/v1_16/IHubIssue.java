package com.exalate.api.domain.hubobject.v1_16;

import com.exalate.api.domain.hubobject.v1_2.IHubUser;

import java.util.Set;

public interface IHubIssue extends com.exalate.api.domain.hubobject.v1_15.IHubIssue {
    public Set<IHubUser> getAssignees();
}
