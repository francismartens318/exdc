package com.exalate.api.domain.hubobject;

import java.util.List;

public interface IHubOrganization {

    public List<String> getCustomers();
    public String getOrganizationName();

}
