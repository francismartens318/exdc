package com.exalate.api.domain.hubobject;

public interface ILockable {
    public void lock();
    /**
     * returns false until {@link #lock} is called on the object, returns true ever after
     * */
    public boolean isLocked();
}
