package com.exalate.api.domain.hubobject.v1_12;

import com.exalate.basic.domain.hubobject.v1.BasicHubWorkLog;

import javax.annotation.Nonnull;
import java.util.List;

public interface IHubIssue extends com.exalate.api.domain.hubobject.v1_9.IHubIssue {

    /**
     * @return a list of workLogs, which have been added during tha latest operation being synchronized
     */
    @Nonnull
    public List<BasicHubWorkLog> getAddedWorkLogs();

    /**
     * @return a list of workLogs, which have been changed during tha latest operation being synchronized
     */
    @Nonnull
    public List<BasicHubWorkLog> getChangedWorkLogs();

    /**
     * @return a list of workLogs, which have been removed during tha latest operation being synchronized
     */
    @Nonnull
    public List<BasicHubWorkLog> getRemovedWorkLogs();
}
