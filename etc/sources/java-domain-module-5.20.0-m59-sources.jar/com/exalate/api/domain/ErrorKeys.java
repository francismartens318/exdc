/*
 * Copyright (C) 2015, Exalate NV
 * All rights reserved.
 *
 *
 * THIS SOURCE CODE IS AN UNPUBLISHED PROPRIETARY TRADE SECRET OF iDalko NV, unless stated otherwise
 * in the license text.
 *
 *
 * The copyright notice above does not evidence any actual or intended publication of such source code.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
 */
package com.exalate.api.domain;


import com.exalate.api.exception.script.ScriptProcessors;
import scala.Option;


public enum ErrorKeys {
    REPLICATION_TRANSPORT("com.exalate.error.transport.replication."),
    POLLING_TRANSPORT("com.exalate.error.transport.polling."),
    EXPIRATION_LIFECYCLE("com.exalate.error.lifecycle.expiration."),
    SCHEDULING("com.exalate.error.scheduling."),
    LICENSE("com.exalate.error.license."),
    SCRIPT("com.exalate.error.script"),
    UNAUTHORIZED("com.exalate.error.unauthorized");

    // NOTE, that EditorCategorizedExceptions have their own method .getBlockingKey

    ErrorKeys(String key) {
        this.key = key;
    }


    private String key;

    @Override
    public String toString() {
        return this.key;
    }


    static public String getReplicationTransportErrorKey(int connectionId) {
        return ErrorKeys.REPLICATION_TRANSPORT.toString() + connectionId;
    }

    static public String getUnauthorizedErrorKey() { return ErrorKeys.UNAUTHORIZED.toString(); }

    static public String getPollingErrorKey(int connectionId) {
        return ErrorKeys.POLLING_TRANSPORT.toString() + connectionId;
    }

    static public String getScriptError(int connectionId, int syncEventRequestId, Integer errorLine, ScriptProcessors processor) {
        if(errorLine != null && processor != null){
            return ErrorKeys.SCRIPT.toString() + "." + connectionId + "." + syncEventRequestId + "." + processor.toString() + "." + errorLine;
        }
        return ErrorKeys.SCRIPT.toString() + "." + connectionId + "." + syncEventRequestId;
    }
    static public String getScriptSchedulingError(int connectionId, Integer errorLine, ScriptProcessors processor) {
        if(errorLine != null && processor != null){
            return ErrorKeys.SCRIPT.toString() + "." + connectionId + "." + processor.toString() + "." + errorLine;
        }
        return ErrorKeys.SCRIPT.toString() + "." + connectionId;
    }

    static public String getLicenseErrorKey(int connectionId, Option<IIssueKey> localIssueKeyOpt) {
        return ErrorKeys.LICENSE.toString() + connectionId +
                "." + localIssueKeyOpt.get().getEntityType() +
                "." + localIssueKeyOpt.get().getIdStr();
    }

    static public String getLicenseErrorKey(int connectionId, String localIssueId, String localEntityType) {
        return ErrorKeys.LICENSE.toString() + connectionId +
                "." + localEntityType +
                "." + localIssueId;
    }

    static public String getSchedulingErrorKey(int connectionId, Option<IIssueKey> localIssueKeyOpt) {
        if (localIssueKeyOpt.isDefined()) {
            return ErrorKeys.SCHEDULING.toString() + connectionId +
                    "." + localIssueKeyOpt.get().getEntityType() +
                    "." + localIssueKeyOpt.get().getIdStr();
        }
        return ErrorKeys.SCHEDULING.toString() + connectionId;
    }
}
