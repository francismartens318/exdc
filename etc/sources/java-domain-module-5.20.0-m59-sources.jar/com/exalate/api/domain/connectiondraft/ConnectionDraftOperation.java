package com.exalate.api.domain.connectiondraft;

public enum ConnectionDraftOperation {
    UPDATE,
    DELETE
}