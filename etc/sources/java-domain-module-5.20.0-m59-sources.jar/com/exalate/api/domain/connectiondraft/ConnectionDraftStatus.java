package com.exalate.api.domain.connectiondraft;

public enum ConnectionDraftStatus {
    SENDING,
    PUBLISHED,
    REJECTED
}