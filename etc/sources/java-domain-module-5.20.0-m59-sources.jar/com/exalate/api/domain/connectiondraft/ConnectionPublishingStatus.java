package com.exalate.api.domain.connectiondraft;

import javax.annotation.Nonnull;

public enum ConnectionPublishingStatus {
    PUBLISHING,
    PUBLISHED;

    public static ConnectionPublishingStatus fromDraftStatus(@Nonnull ConnectionDraftStatus connectionDraftStatus) {
        switch (connectionDraftStatus) {
            case SENDING: return PUBLISHING;
            default: return PUBLISHED;
        }
    }
}
