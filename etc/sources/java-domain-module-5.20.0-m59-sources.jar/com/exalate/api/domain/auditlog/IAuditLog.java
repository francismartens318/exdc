package com.exalate.api.domain.auditlog;

import com.exalate.api.domain.webhook.WebhookEntityType;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

/**
 * This entity represents:
 *  * The intention to create an issue entity (comment, worklogs ...) We call this Partial Audit Log
 *  * The record that an issue entity was created by Exalate. We call this Full Audit Log
 *
 * This is used to keep record that exalate is creating some entities, this is important when this
 * entities were created in behalf of other user. We need to keep track of this actions so we can handle
 * them correctly when receiving the issue updated webhook/event.
 */
public interface IAuditLog {

    @Nonnull
    int getId();

    @Nonnull
    String getIssueId();

    @Nonnull
    String getUserKey();

    @Nonnull
    WebhookEntityType getEntityType();

    @Nullable
    String getResultEntityId();

    @Nullable
    String getResultEntityJson();

}
