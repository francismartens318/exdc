package com.exalate.api.domain.auditlog;

import com.exalate.api.domain.webhook.WebhookEntityType;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

/**
 * Is used as intermediate stage, provided Persistance to save data to DB
 */
public interface INonPersistentAuditLog {

    @Nonnull
    String getIssueId();

    @Nonnull
    String getUserKey();

    @Nonnull
    WebhookEntityType getEntityType();

    @Nullable
    String getResultEntityId();

    @Nullable
    String getResultEntityJson();
}
