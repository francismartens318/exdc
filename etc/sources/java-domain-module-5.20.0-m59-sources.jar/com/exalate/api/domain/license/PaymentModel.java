package com.exalate.api.domain.license;




public enum PaymentModel {

    CONNECTION_BASED (0),
    USAGE_BASED(1),
    EDGE_NODE (2);

    private final int number;

    PaymentModel(int number) {
        this.number = number;
    }

    public int getNumber() {
        return number;
    }
}
