package com.exalate.api.domain.license;


public interface ISubscriptionContext {

    boolean isRemoteWithNodeSubscription();

    boolean isRemoteWithExalateSubscription();

    default boolean hasRemoteValidSubscription() {
        return isRemoteWithNodeSubscription() || isRemoteWithExalateSubscription();
    }

}
