package com.exalate.api.domain.license;




public interface IPersistentLicense {

    public int getId();
    /**
     * Contains the license payload, which is encoded using base64.
     */
    public String getPayload();
}
