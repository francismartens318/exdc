package com.exalate.api.domain.license;



import java.time.temporal.ChronoUnit;
import java.util.Date;


public interface ILicense {

    public int getId();
    /**
     * @return the version of the license allowing to evolve license processing code
     */
    public String getLicenseVersion();

    /**
     * @return the organisation or whom the license is meant
     */
    public String getOrganisation();

    /**
     * @return the start date of the license
     */
    public Date getStartDate();

    /**
     * @return the end date of the license
     */
    public Date getEndDate();

    /**
     * @return the Idalko based JIRA record which tracks the purchase of the license
     */
    public String getOpportunity();

    /**
     * @return the number of connections this license support
     */
    public long getConnections();

    /**
     * @return a calculated key from organisation, startDate, endDate and opportunity
     */
    public String getSignature();

    public boolean getIsEvaluation();
    public boolean getIsFreemium();

    public String getStripeSubscriptionId();

    public String getInstanceUid();

    public Long getPairNumber();

    public ChronoUnit getCalendarUnit();

}
