package com.exalate.api.domain.license;


import com.exalate.api.domain.instance.IInstance;


public interface IAssignedLicense {

    public int getId();

    public IInstance getInstance();

    public PaymentModel getPaymentModel();
}
