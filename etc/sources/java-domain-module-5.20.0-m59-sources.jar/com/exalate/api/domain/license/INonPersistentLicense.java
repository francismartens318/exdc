package com.exalate.api.domain.license;



import java.time.temporal.ChronoUnit;
import java.util.Date;


public interface INonPersistentLicense {

    public String getLicenseVersion();

    public String getOrganisation();

    public Date getStartDate();

    public Date getEndDate();

    public String getOpportunity();

    public Long getConnections();

    public String getSignature();
    public void setSignature(String signature);


    public boolean getIsEvaluation();
    public boolean getIsFreemium();

    public String getStripeSubscriptionId();

    public String getInstanceUid();

    public Long getPairNumber();

    public ChronoUnit getCalendarUnit();

    public Long getUseplan();
}
